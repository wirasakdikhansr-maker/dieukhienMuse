import sys
from pathlib import Path

# Bảo đảm `import app...` chạy được khi pytest chạy từ thư mục dự án.
sys.path.insert(0, str(Path(__file__).resolve().parent))
