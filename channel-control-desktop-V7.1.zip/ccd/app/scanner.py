"""Quét danh sách kênh của một hồ sơ qua CDP.

Luồng:
1. Bảo đảm Chrome của hồ sơ đang chạy (mở nếu cần) và kết nối CDP.
2. Điều hướng tới youtube.com, kiểm tra trạng thái đăng nhập.
3. Nếu CHƯA đăng nhập: điều hướng cửa sổ Chrome tới trang đăng nhập Google,
   ghi nhật ký "chờ đăng nhập" và DỪNG — cửa sổ để nguyên cho người dùng
   tự đăng nhập (mật khẩu/OTP chỉ người dùng nhập).
4. Nếu đã đăng nhập: gọi endpoint nội bộ ``/youtubei/v1/account/account_menu``
   bằng chính phiên trong trang, parse danh sách kênh (app.parser). Nếu
   endpoint không cho ra kênh nào (YouTube đổi cấu trúc), dự phòng bằng cách
   mở menu tài khoản ngay trên trang và đọc DOM, rồi tra channel ID từ trang
   @handle của từng kênh. Sau cùng mới lấy thêm số video cho từng kênh
   (best-effort), upsert vào DB và ghi nhật ký. Khi cả hai cách đều rỗng,
   nhật ký kèm tóm tắt cấu trúc JSON (chỉ tên khoá + số đếm) để chẩn đoán.

Lưu ý trung thực: account_menu là endpoint nội bộ của YouTube, không phải
API công khai — cấu trúc có thể thay đổi theo thời gian. Mỗi lần quét, app
lưu một snapshot (data/snapshots/) để gỡ lỗi khi parse thất bại.
"""

from __future__ import annotations

import time
from datetime import datetime

from . import cdp, config, cookies_vault, parser
from .chrome_manager import ChromeManager
from .store import Store

SIGNIN_URL = (
    "https://accounts.google.com/ServiceLogin?service=youtube"
    "&continue=https%3A%2F%2Fwww.youtube.com%2F"
)

CHECK_LOGIN_JS = """
(() => ({
  loggedIn: !!(window.ytcfg && ytcfg.get('LOGGED_IN')),
  href: location.href
}))()
"""

ACCOUNT_MENU_JS = """
/*ccd:menu*/
(async () => {
  try {
    const key = window.ytcfg && ytcfg.get('INNERTUBE_API_KEY');
    const ctx = window.ytcfg && ytcfg.get('INNERTUBE_CONTEXT');
    if (!key || !ctx) return { ok: false, error: 'no_ytcfg' };
    const res = await fetch('/youtubei/v1/account/account_menu?key=' + key, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ context: ctx })
    });
    return { ok: true, status: res.status, data: await res.json() };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
})()
"""

# Dự phòng khi account_menu đổi cấu trúc: mở menu tài khoản ngay trên trang
# và đọc chữ hiển thị (header = kênh đang active, items = các kênh còn lại).
ACCOUNT_MENU_DOM_JS = """
/*ccd:dom*/
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  try {
    const btn = document.querySelector('#avatar-btn');
    if (!btn) return { ok: false, error: 'no_avatar_btn' };
    btn.click();
    await sleep(1800);
    const header = document.querySelector('ytd-active-account-header-renderer');
    const items = [...document.querySelectorAll('ytd-account-item-renderer')]
      .map(el => (el.innerText || '').trim()).filter(Boolean);
    document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    return { ok: true, header: header ? (header.innerText || '').trim() : '', items };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
})()
"""

# Panel "Accounts" (avatar -> Switch account): phần đầu panel là danh
# tính Google (tên tài khoản + email), dưới là MỌI kênh của tài khoản.
# Đọc cả hai: tên tài khoản Google dùng để nhận diện và LOẠI kênh chính
# (kênh cá nhân trùng tên tài khoản) — chỉ lấy kênh thương hiệu.
ACCOUNTS_PANEL_JS = """
/*ccd:panel*/
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  try {
    const btn = document.querySelector('#avatar-btn');
    if (!btn) return { ok: false, error: 'no_avatar_btn' };
    btn.click();
    await sleep(1200);
    let menu = document.querySelector('ytd-multi-page-menu-renderer');
    if (!menu) return { ok: false, error: 'no_menu' };
    const links = [...menu.querySelectorAll('ytd-compact-link-renderer')];
    const switchRow = links.find(el => /switch account|chuyển đổi tài khoản|cambiar de cuenta/i.test(el.innerText || ''));
    if (switchRow) { switchRow.click(); await sleep(1500); }
    const panel = document.querySelector('ytd-multi-page-menu-renderer') || menu;
    const collect = () => [...panel.querySelectorAll('ytd-account-item-renderer')]
      .map(el => (el.innerText || '').trim()).filter(Boolean);
    let items = collect();
    let scroller = panel.querySelector('ytd-account-item-renderer');
    while (scroller && scroller !== panel) {
      if (scroller.scrollHeight > scroller.clientHeight + 10) break;
      scroller = scroller.parentElement;
    }
    if (scroller && scroller !== panel) {
      for (let i = 0; i < 10; i++) {
        scroller.scrollTop = scroller.scrollHeight;
        await sleep(450);
        const now = collect();
        if (now.length === items.length) break;
        items = now;
      }
      scroller.scrollTop = 0;
    }
    const lines = (panel.innerText || '').split('\\n').map(s => s.trim());
    let accountName = '', email = '';
    const emailIdx = lines.findIndex(l => /^[\\w.+-]+@[\\w-]+\\.[\\w.]+$/.test(l));
    if (emailIdx >= 0) {
      email = lines[emailIdx];
      for (let i = emailIdx - 1; i >= 0; i--) { if (lines[i]) { accountName = lines[i]; break; } }
    }
    return { ok: true, accountName, email, items };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
})()
"""

CHANNEL_SWITCHER_URL = "https://www.youtube.com/channel_switcher"

# Trang "View all channels" (channel_switcher): danh sách ĐẦY ĐỦ mọi
# kênh của tài khoản — quét các thẻ <a> trỏ tới /channel/UC... hoặc
# /@handle, cuộn dần để trang nạp hết (tài khoản nhiều kênh).
CHANNEL_SWITCHER_JS = """
/*ccd:switcher*/
(async () => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const pick = () => {
    const out = [];
    const seen = new Set();
    document.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href') || '';
      if (!/^\\/(channel\\/UC[\\w-]{10,30}|@[\\w.\\-]+)/.test(href)) return;
      if (seen.has(href)) return;
      seen.add(href);
      let el = a, text = '';
      for (let i = 0; i < 6 && el; i++) {
        text = el.innerText || '';
        if (text.split('\\n').filter(Boolean).length >= 2) break;
        el = el.parentElement;
      }
      out.push({ href, text: (text || a.innerText || '').trim() });
    });
    return out;
  };
  let prev = -1;
  for (let i = 0; i < 12; i++) {
    const entries = pick();
    if (entries.length === prev) return { ok: true, entries };
    prev = entries.length;
    window.scrollTo(0, document.documentElement.scrollHeight);
    await sleep(700);
  }
  return { ok: true, entries: pick() };
})()
"""

# Tra channel ID + số video từ HTML trang kênh (@handle): trang kênh luôn
# nhúng ID của chính nó trong ytInitialData / thẻ meta.
RESOLVE_CHANNEL_JS = """
/*ccd:resolve*/
(async () => {
  try {
    const res = await fetch(%(url_js)s, { credentials: 'include' });
    const html = await res.text();
    let m = html.match(/"channelId"\\s*:\\s*"(UC[\\w-]{22})"/)
      || html.match(/"externalId"\\s*:\\s*"(UC[\\w-]{22})"/)
      || html.match(/itemprop="channelId"\\s+content="(UC[\\w-]{22})"/)
      || html.match(/rel="canonical"\\s+href="https:\\/\\/www\\.youtube\\.com\\/channel\\/(UC[\\w-]{22})"/);
    const channelId = m ? m[1] : null;
    let v = html.match(/"videosCount"\\s*:\\s*\\{\\s*"simpleText"\\s*:\\s*"([\\d,\\.]+)"/);
    if (!v) v = html.match(/"videoCount"\\s*:\\s*"?(\\d[\\d,\\.]*)/);
    return { channelId, videoCount: v ? v[1] : null };
  } catch (e) {
    return { channelId: null, videoCount: null };
  }
})()
"""

VIDEO_COUNT_JS = """
(async () => {
  try {
    const res = await fetch(%(url_js)s, { credentials: 'include' });
    const html = await res.text();
    let m = html.match(/"videosCount"\\s*:\\s*\\{\\s*"simpleText"\\s*:\\s*"([\\d,\\.]+)"/);
    if (m) return m[1];
    m = html.match(/"videoCount"\\s*:\\s*"?(\\d[\\d,\\.]*)/);
    return m ? m[1] : null;
  } catch (e) {
    return null;
  }
})()
"""


def _wait_ready(client, timeout: float = 15.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            state = client.evaluate("document.readyState")
        except Exception:
            state = None
        if state in ("complete", "interactive"):
            return
        time.sleep(0.4)


def _save_snapshot(account_menu_json: dict, slug: str) -> str:
    folder = config.snapshots_dir()
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    path = folder / f"scan-{slug}-{stamp}.html"
    path.write_text(parser.build_snapshot_html(account_menu_json), encoding="utf-8")
    return str(path)


def _resolve_partials(client, partials, say) -> list[dict]:
    """Bổ sung channel_id (+ số video) cho các bản ghi chưa có ID bằng
    cách đọc trang @handle của từng kênh. Bản ghi đã có ID được giữ
    nguyên; bản ghi không tra được ID bị bỏ qua kèm dòng tiến độ
    (store bắt buộc phải có channel_id)."""
    resolved: list[dict] = []
    for record in partials:
        if record.get("channel_id"):
            resolved.append(record)
            continue
        if not record.get("url"):
            say(f"  - '{record['name']}': không có @handle nên chưa tra được ID kênh — bỏ qua.")
            continue
        try:
            import json as _json

            js = RESOLVE_CHANNEL_JS % {"url_js": _json.dumps(record["url"])}
            info = client.evaluate(js, timeout=30) or {}
        except Exception:
            info = {}
        channel_id = info.get("channelId") or ""
        if not channel_id:
            say(f"  - '{record['name']}': chưa tra được ID kênh từ {record['url']} — bỏ qua.")
            continue
        record["channel_id"] = channel_id
        raw_count = info.get("videoCount")
        if raw_count:
            try:
                record["video_count"] = int(str(raw_count).replace(",", "").replace(".", ""))
            except (TypeError, ValueError):
                pass
        resolved.append(record)
    return resolved


def _channels_via_dom(client, say) -> list[dict]:
    """Dự phòng cuối: đọc menu tài khoản trên DOM rồi tra channel ID."""
    try:
        dom = client.evaluate(ACCOUNT_MENU_DOM_JS, timeout=30) or {}
    except Exception:
        return []
    if not dom.get("ok"):
        return []
    partials = parser.parse_dom_menu_texts(dom.get("header") or "", dom.get("items") or [])
    return _resolve_partials(client, partials, say)


def _read_accounts_panel(client, say) -> dict:
    """Đọc panel Accounts (avatar -> Switch account): tên tài khoản
    Google + bản ghi kênh (chưa chắc có ID) của MỌI kênh trong panel.
    Trả về {"account_name": str, "records": [...]} — rỗng khi không
    đọc được, không bao giờ ném lỗi."""
    empty = {"account_name": "", "records": []}
    try:
        panel = client.evaluate(ACCOUNTS_PANEL_JS, timeout=45) or {}
    except Exception:
        return empty
    if not panel.get("ok"):
        return empty
    records = parser.parse_dom_menu_texts("", panel.get("items") or [])
    account_name = (panel.get("accountName") or "").strip()
    if records:
        say(
            f"Panel Accounts: đọc được {len(records)} kênh"
            + (f", tài khoản Google: {account_name}." if account_name else ".")
        )
    return {"account_name": account_name, "records": records}


def _read_channel_switcher(client, say) -> list[dict]:
    """Đọc trang 'View all channels' (channel_switcher) — danh sách đầy
    đủ nhất. Trả về bản ghi kênh (có thể đã có sẵn channel_id từ href).
    Rỗng khi không đọc được, không bao giờ ném lỗi."""
    try:
        client.navigate(CHANNEL_SWITCHER_URL)
        _wait_ready(client)
        result = client.evaluate(CHANNEL_SWITCHER_JS, timeout=60) or {}
    except Exception:
        return []
    if not result.get("ok"):
        return []
    records = parser.parse_switcher_entries(result.get("entries") or [])
    if records:
        say(f"Trang View all channels: đọc được {len(records)} kênh.")
    return records


def _try_cookie_restore(client, profile: dict, say) -> bool:
    """Nạp cookies đã lưu của hồ sơ vào Chrome rồi tải lại YouTube —
    đăng nhập lại bằng cookies có sẵn mà không cần mật khẩu (V3.2).
    Trả về True nếu ĐÃ nạp (caller tự kiểm tra lại trạng thái đăng nhập).
    Mọi lỗi đều nuốt gọn: không có kho / Chrome không chịu thì coi như
    chưa đăng nhập như cũ. Giá trị cookie không bao giờ vào log."""
    try:
        payload = cookies_vault.load_cookies(profile["slug"])
        if not payload or not payload["cookies"]:
            return False
        params = [cookies_vault.to_cdp_cookie(c) for c in payload["cookies"]]
        cdp.set_cookies(profile["port"], params)
        say(
            f"Hồ sơ '{profile['label']}': đã nạp {len(params)} cookies đã lưu "
            "— kiểm tra lại đăng nhập…"
        )
        client.navigate("https://www.youtube.com/")
        _wait_ready(client)
        return True
    except Exception:
        return False


def _export_cookies(store: Store, profile: dict, say) -> None:
    """Tự lưu cookies đăng nhập (chỉ domain Google/YouTube) sau một lần
    quét thành công, để lần sau app tự đăng nhập lại (V3.2). Best-effort:
    lỗi thì bỏ qua, không làm hỏng kết quả quét."""
    try:
        raw = cdp.get_all_cookies(profile["port"])
        cookies = cookies_vault.filter_google_youtube(
            cookies_vault.normalize_cdp_cookies(raw)
        )
        if not cookies:
            return
        summary = cookies_vault.save_cookies(
            profile["slug"], cookies, source="auto:scan"
        )
        say(
            f"Hồ sơ '{profile['label']}': đã tự lưu {summary['count']} cookies "
            "đăng nhập (Google/YouTube) — lần sau app tự nạp lại."
        )
    except Exception:
        pass


def scan_profile(store: Store, profile: dict, manager: ChromeManager, log=None) -> dict:
    """Chạy một lượt quét. ``log(msg)`` nhận các dòng tiến độ (UI truyền vào
    để vừa ghi DB vừa hiện lên màn hình). Trả về dict kết quả:
    {'status': 'ok'|'needs_login'|'paused'|'error', 'channels': [...], 'message': str}
    """
    say = log or (lambda msg: None)
    label = profile["label"]
    # V7.0: hồ sơ Facebook/TikTok → bộ quét riêng (page / kênh TikTok).
    from . import platforms

    if platforms.of(profile) != "youtube":
        return platforms.scan_profile(store, profile, manager, log=log)

    if profile.get("paused"):
        message = f"Hồ sơ '{label}' đang tạm dừng — bỏ qua quét."
        say(message)
        return {"status": "paused", "channels": [], "message": message}

    client = None
    try:
        state = manager.launch(profile)
        say(
            f"Chrome hồ sơ '{label}': "
            + ("đang chạy sẵn, dùng lại phiên." if state == "already_running" else "đã mở mới.")
        )
        client = manager.connect_page(profile)

        client.navigate("https://www.youtube.com/")
        _wait_ready(client)
        info = client.evaluate(CHECK_LOGIN_JS) or {}
        href = info.get("href") or ""
        logged_in = bool(info.get("loggedIn"))

        if "accounts.google.com" in href or not logged_in:
            # Ưu tiên đăng nhập lại bằng cookies đã lưu của chính hồ sơ.
            if _try_cookie_restore(client, profile, say):
                info = client.evaluate(CHECK_LOGIN_JS) or {}
                href = info.get("href") or ""
                logged_in = bool(info.get("loggedIn"))
                if logged_in and "accounts.google.com" not in href:
                    say(
                        f"Hồ sơ '{label}': đăng nhập lại thành công bằng "
                        "cookies đã lưu."
                    )
        if "accounts.google.com" in href or not logged_in:
            # Chưa đăng nhập: đưa cửa sổ tới trang đăng nhập và dừng tại đó.
            try:
                client.navigate(SIGNIN_URL)
            except Exception:
                pass
            message = (
                f"Hồ sơ '{label}': CHƯA đăng nhập — chờ đăng nhập. "
                "Cửa sổ Chrome của hồ sơ đang ở trang đăng nhập Google; "
                "hãy đăng nhập trong cửa sổ đó rồi bấm Quét kênh lại."
            )
            say(message)
            store.append_journal(message, profile["id"])
            return {"status": "needs_login", "channels": [], "message": message}

        result = client.evaluate(ACCOUNT_MENU_JS, timeout=30) or {}
        menu_data = result.get("data") or {}
        if not result.get("ok"):
            # account_menu gãy KHÔNG còn là lỗi chốt: vẫn còn đường đọc
            # giao diện Accounts + View all channels bên dưới.
            say(
                f"Hồ sơ '{label}': account_menu lỗi "
                f"({result.get('error', 'unknown')}) — chuyển sang đọc "
                "giao diện Accounts + View all channels."
            )
            result = {"status": None, "data": {}}
            menu_data = {}
        snapshot_path = (
            _save_snapshot(menu_data, profile["slug"]) if menu_data else "(không có)"
        )
        channels = parser.parse_account_menu(menu_data)

        # account_menu có thể THIẾU kênh (menu chỉ hiện vài kênh đầu),
        # nên luôn hợp nhất thêm panel Accounts + trang View all
        # channels để lấy ĐỦ toàn bộ kênh của tài khoản.
        panel = _read_accounts_panel(client, say)
        switcher_records = _read_channel_switcher(client, say)
        partials = list(panel["records"]) + list(switcher_records)
        if partials:
            resolved = _resolve_partials(client, partials, say)
            channels = parser.merge_channel_records(channels + resolved)
        if not channels:
            say(
                f"Hồ sơ '{label}': chưa đọc được kênh nào — thử lớp "
                "dự phòng cuối (menu DOM)…"
            )
            channels = _channels_via_dom(client, say)

        # Chỉ lấy kênh THƯƠNG HIỆU — bỏ kênh chính cá nhân (kênh trùng
        # tên tài khoản Google đọc được từ panel Accounts).
        kept, dropped = parser.exclude_personal_channel(
            channels, panel.get("account_name") or ""
        )
        if dropped is not None:
            say(
                f"Hồ sơ '{label}': bỏ qua kênh chính cá nhân "
                f"'{dropped['name']}' "
                f"({dropped.get('handle') or dropped.get('channel_id')}) "
                "— chỉ lấy kênh thương hiệu."
            )
            channels = kept
        if not channels:
            message = (
                f"Hồ sơ '{label}': đã đăng nhập nhưng không đọc được kênh nào "
                f"(account_menu HTTP {result.get('status', '?')}; snapshot: "
                f"{snapshot_path}). Chẩn đoán cấu trúc: "
                f"{parser.summarize_structure(menu_data)}"
            )
            say(message)
            store.append_journal(message, profile["id"])
            return {"status": "error", "channels": [], "message": message}

        # Số video cho từng kênh (best-effort — lỗi thì để None, không fail quét).
        for channel in channels:
            if channel.get("video_count") is not None:
                continue
            try:
                import json as _json

                js = VIDEO_COUNT_JS % {"url_js": _json.dumps(channel["url"])}
                raw = client.evaluate(js, timeout=30)
                if raw:
                    channel["video_count"] = int(str(raw).replace(",", "").replace(".", ""))
            except Exception:
                channel["video_count"] = None

        _export_cookies(store, profile, say)
        created = 0
        for ch in channels:
            if store.upsert_channel(profile["id"], ch):
                created += 1
            # Snapshot số liệu theo ngày — nền cho báo cáo/xu hướng kênh.
            try:
                store.record_channel_snapshot(profile["id"], ch)
            except Exception:
                pass
        store.mark_profile_scanned(profile["id"])
        message = (
            f"Quét xong hồ sơ '{label}': {len(channels)} kênh thương hiệu "
            f"({created} mới, {len(channels) - created} cập nhật). "
            + "; ".join(
                f"{ch['name']} ({ch['handle'] or ch['channel_id']}, "
                f"{ch['subs'] if ch['subs'] is not None else '?'} subs, "
                f"{ch['video_count'] if ch['video_count'] is not None else '?'} video)"
                for ch in channels
            )
        )
        say(message)
        store.append_journal(message, profile["id"])
        return {"status": "ok", "channels": channels, "message": message}

    except Exception as exc:  # Chrome không mở được, CDP lỗi, ...
        # Trường hợp hay gặp (V3.1): Chrome của hồ sơ đang chạy sẵn từ
        # trước mà KHÔNG có cờ --remote-allow-origins -> bắt tay CDP bị
        # 403. Nói thẳng nguyên nhân + cách sửa thay vì đổ lỗi thô.
        from .cdp import classify_ws_error

        friendly = classify_ws_error(exc)
        if friendly:
            message = f"Hồ sơ '{label}': quét thất bại — {friendly}"
        else:
            message = f"Hồ sơ '{label}': quét thất bại — {exc}"
        say(message)
        try:
            store.append_journal(message, profile["id"])
        except Exception:
            pass
        return {"status": "error", "channels": [], "message": message}
    finally:
        if client is not None:
            client.close()
