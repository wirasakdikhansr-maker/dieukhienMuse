"""Quản lý tiến trình Chrome theo hồ sơ.

Mỗi hồ sơ có: thư mục user-data riêng (``config.profile_dir``) + cổng
remote-debugging riêng (lưu trong DB lúc tạo hồ sơ). Chrome được mở theo
kiểu "detached" để việc đóng app KHÔNG kéo theo đóng Chrome.

Nếu cổng debug của hồ sơ đã có Chrome chạy (do app mở trước đó hoặc do
chính Muse mở bằng cùng user-data-dir + cổng), app dùng lại phiên đó.
"""

from __future__ import annotations

import socket
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from . import cdp, config

START_URL = "https://www.youtube.com/"


class ChromeManager:
    def __init__(self, chrome_path: str | None = None):
        # Các tiến trình do CHÍNH phiên app này mở (để tuỳ chọn tắt khi thoát).
        self._launched: dict[str, subprocess.Popen] = {}
        # V3.1: đường dẫn Chrome ép tay từ Cài đặt (rỗng/None = tự dò).
        self.chrome_path_override = chrome_path or ""
        # V5.3 (A8): mặc định mở THU NHỎ cho MỌI đường launch không
        # nói rõ (executor/scanner/cầu nối) khi chế độ chạy ẩn bật —
        # MainWindow đồng bộ cờ này từ setting browsers_hidden_mode.
        self.launch_minimized_default = False
        self._pid_cache: dict[int, int] = {}
        self._sweeper = None
        # V6.1 (CHỐNG ĐƠ): bộ đệm "Chrome của cổng X còn sống?" do một
        # LUỒNG NỀN dò song song. Trước V6.1, luồng giao diện gọi HTTP
        # tới cổng debug của TỪNG hồ sơ mỗi 600ms (tường/tự nhúng) và
        # mỗi 5 giây (thanh trạng thái) — trên Windows, cổng localhost
        # đang đóng không bị từ chối ngay mà treo tới hết timeout 0.6s,
        # nên N hồ sơ chưa mở Chrome = N×0.6s đơ cứng giao diện mỗi
        # nhịp. Bật ui_nonblocking (MainWindow bật) thì is_running()
        # gọi từ LUỒNG CHÍNH chỉ đọc bộ đệm — không bao giờ chặn.
        self.ui_nonblocking = False
        self._alive: dict[int, tuple[bool, float]] = {}
        self._watch: dict[int, float] = {}
        self._alive_lock = threading.Lock()
        self._prober: threading.Thread | None = None
        self._prober_stop = threading.Event()
        self._prober_wake = threading.Event()

    # Cờ mở Chrome BẮT BUỘC kèm theo (V3.1): Chrome bản mới từ chối bắt tay
    # WebSocket CDP từ mọi origin nếu thiếu --remote-allow-origins
    # ("Handshake status 403 Forbidden — Rejected an incoming WebSocket
    # connection..."). Cổng debug chỉ nghe trên localhost nên dùng '*'
    # là chấp nhận được trong mô hình đe doạ này (Tailscale + cổng nội bộ).
    LAUNCH_FLAGS = ("--remote-allow-origins=*",)
    # V7.0.1: TẮT các thông báo/bong bóng của Chrome làm vướng thao tác tự động:
    # dịch trang, "Khôi phục trang?" sau khi tắt đột ngột, lưu mật khẩu, xin
    # quyền thông báo, quảng bá đăng nhập Chrome, thanh "Chrome đang bị điều khiển".
    QUIET_FLAGS = (
        "--disable-features=Translate,TranslateUI,AutofillServerCommunication,"
        "PasswordLeakDetection,ChromeWhatsNewUI,PrivacySandboxSettings4",
        "--disable-translate",
        "--hide-crash-restore-bubble",
        "--disable-session-crashed-bubble",
        "--disable-notifications",
        "--disable-infobars",
        "--no-service-autorun",
        "--disable-search-engine-choice-screen",
        # V7.1: trình duyệt bị che / ngoài màn hình vẫn chạy ĐẦY ĐỦ (không "ngủ"):
        # Muse điều khiển + chụp trang đúng dù cửa sổ không hiện.
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
        "--disable-background-timer-throttling",
    )

    # ------------------------------------------------------------------ #
    def is_running(self, profile: dict) -> bool:
        port = int(profile["port"])
        if self.ui_nonblocking and threading.current_thread() is threading.main_thread():
            return self.is_running_cached(profile)
        alive = cdp.debug_port_open(port, timeout=0.6)
        self._remember(port, alive)
        return alive

    # ------------------------------------------------------------------ #
    # V6.1 — dò sống ở nền (không chặn giao diện)
    # ------------------------------------------------------------------ #
    PROBE_INTERVAL = 1.5
    WATCH_TTL = 90.0

    def is_running_cached(self, profile: dict) -> bool:
        """Trạng thái sống ĐÃ ĐỆM của Chrome hồ sơ — trả về ngay (O(1)).
        Cổng chưa từng dò → False lần đầu và được đưa vào danh sách
        dò nền; kết quả thật có sau ≤ ~1.5 giây."""
        port = int(profile["port"])
        now = time.monotonic()
        with self._alive_lock:
            first = port not in self._watch
            self._watch[port] = now
            entry = self._alive.get(port)
        self._ensure_prober()
        if first:
            self._prober_wake.set()
        return bool(entry[0]) if entry else False

    def _remember(self, port: int, alive: bool) -> None:
        with self._alive_lock:
            self._alive[int(port)] = (bool(alive), time.monotonic())

    def _ensure_prober(self) -> None:
        if self._prober is not None and self._prober.is_alive():
            return
        self._prober_stop.clear()
        self._prober = threading.Thread(
            target=self._prober_loop, name="ccd-chrome-prober", daemon=True
        )
        self._prober.start()

    def stop_prober(self) -> None:
        self._prober_stop.set()
        self._prober_wake.set()

    def _prober_loop(self) -> None:
        with ThreadPoolExecutor(max_workers=8, thread_name_prefix="ccd-probe") as pool:
            while not self._prober_stop.is_set():
                now = time.monotonic()
                with self._alive_lock:
                    for port, seen in list(self._watch.items()):
                        if now - seen > self.WATCH_TTL:
                            self._watch.pop(port, None)
                    ports = list(self._watch)
                if ports:
                    try:
                        results = list(pool.map(lambda p: (p, _probe_port(p, 0.6)), ports))
                    except Exception:
                        results = []
                    for port, alive in results:
                        self._remember(port, alive)
                self._prober_wake.wait(self.PROBE_INTERVAL)
                self._prober_wake.clear()

    # V6.5.2: cờ CHẠY NỀN thật sự cho Chrome muse.ai của Muse — Chrome trên
    # Windows thường BỎ QUA --start-minimized (cửa sổ vẫn bật lên màn
    # hình). Đặt cửa sổ ra NGOÀI màn hình + tắt cơ chế bóp nghẹt trang
    # nền để muse.ai vẫn chạy/chảy chữ bình thường khi không ai nhìn.
    HIDDEN_FLAGS = (
        "--window-position=-32000,-32000",
        "--window-size=1366,900",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
        "--disable-background-timer-throttling",
    )

    # V6.7: MẶC ĐỊNH mọi Chrome mở ra đều CẤT (ngoài màn hình + khỏi taskbar)
    # cho tới khi được nhúng vào app. Chỉ cửa sổ đăng nhập do bạn bấm tay
    # (start_minimized=False) mới hiện ra màn hình.
    launch_hidden_default = True

    def is_headless(self, profile: dict) -> bool:
        return profile.get("slug") in getattr(self, "_headless_slugs", set())

    def _stop_headless(self, profile: dict) -> None:
        """Tắt bản Chrome KHÔNG CỬA SỔ (headless) của hồ sơ để mở lại bản có
        cửa sổ (vd đăng nhập muse.ai cần người thao tác)."""
        slug = profile.get("slug")
        process = self._launched.get(slug)
        if process is not None and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        getattr(self, "_headless_slugs", set()).discard(slug)
        port = profile["port"]
        deadline = time.time() + 8
        while time.time() < deadline and cdp.debug_port_open(port, timeout=0.4):
            time.sleep(0.3)
        self._remember(port, False)

    def launch(self, profile: dict, start_minimized: bool | None = None, hidden: bool | None = None,
               headless: bool = False) -> str:
        """Mở Chrome cho hồ sơ. Trả về 'already_running' hoặc 'launched'.
        Ném RuntimeError nếu không tìm thấy Chrome / cổng không mở được.

        start_minimized (V5.3 A8 — chế độ chạy ẩn): mở kèm cờ
        --start-minimized để cửa sổ Chrome lên thẳng dạng thu nhỏ
        (vẫn điều khiển qua CDP bình thường). None = theo cờ mặc
        định của manager (launch_minimized_default)."""
        if hidden is None:
            hidden = bool(self.launch_hidden_default) and start_minimized is not False
        if start_minimized is None:
            start_minimized = self.launch_minimized_default
        port = profile["port"]
        if not hasattr(self, "_headless_slugs"):
            self._headless_slugs: set = set()
        if cdp.debug_port_open(port):
            if not headless and profile.get("slug") in self._headless_slugs:
                # V7.0: đang chạy KHÔNG CỬA SỔ mà cần cửa sổ → mở lại có cửa sổ
                self._stop_headless(profile)
            else:
                self._remember(port, True)
                return "already_running"
        chrome = config.find_chrome(self.chrome_path_override or None)
        if not chrome:
            raise RuntimeError(
                "Không tìm thấy Google Chrome. Cài Chrome hoặc đặt biến môi trường "
                "CCD_CHROME_PATH trỏ tới chrome.exe."
            )
        # Hồ sơ thường: thư mục data/profiles/<slug> + mở YouTube.
        # Pseudo-profile (vd tài khoản Muse) có thể chỉ định riêng
        # user_data_dir + start_url qua hai khoá cùng tên.
        override_dir = profile.get("user_data_dir")
        user_data_dir = (
            Path(override_dir) if override_dir else config.profile_dir(profile["slug"])
        )
        user_data_dir.mkdir(parents=True, exist_ok=True)
        quiet_preferences(user_data_dir)
        args = [
            chrome,
            f"--remote-debugging-port={port}",
            *self.LAUNCH_FLAGS,
            *self.QUIET_FLAGS,
            f"--user-data-dir={user_data_dir}",
            "--no-first-run",
            "--no-default-browser-check",
            profile.get("start_url") or START_URL,
        ]
        if headless:
            # V7.0: KHÔNG có cửa sổ nào (không khung trắng, không taskbar) —
            # cầu nối chat muse.ai chỉ cần CDP. UA giấu chữ "Headless".
            args[1:1] = ["--headless=new", "--window-size=1280,900", f"--user-agent={_desktop_ua(chrome)}",
                         *self.HIDDEN_FLAGS[2:]]
        elif hidden:
            args[1:1] = list(self.HIDDEN_FLAGS)
        elif start_minimized:
            args.append("--start-minimized")
        kwargs: dict = {"stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
        if sys.platform == "win32":
            kwargs["creationflags"] = (
                getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            )
        else:
            kwargs["start_new_session"] = True
        process = subprocess.Popen(args, **kwargs)
        self._launched[profile["slug"]] = process
        if headless:
            self._headless_slugs.add(profile["slug"])
        else:
            self._headless_slugs.discard(profile["slug"])
        deadline = time.time() + 20
        while time.time() < deadline:
            if cdp.debug_port_open(port, timeout=0.8):
                self._remember(port, True)
                if hidden:
                    self._keep_offscreen(profile)
                return "launched"
            time.sleep(0.4)
        raise RuntimeError(
            f"Đã mở Chrome cho hồ sơ '{profile['label']}' nhưng cổng debug {port} "
            "không phản hồi. Có thể thư mục profile đang bị một Chrome khác "
            "(không bật debug) chiếm — hãy đóng cửa sổ Chrome của hồ sơ đó rồi thử lại."
        )

    def _keep_offscreen(self, profile: dict, seconds: float = 8.0) -> None:
        """Lưới an toàn (Windows): Chrome có thể tự khôi phục vị trí cửa sổ
        đã lưu trong hồ sơ, bỏ qua --window-position → trong vài giây đầu
        cứ thấy cửa sổ là đẩy ra ngoài màn hình. Không thu nhỏ (thu nhỏ
        làm muse.ai chạy chậm/ngừng chảy chữ)."""
        if sys.platform != "win32":
            return

        def work():
            from . import docking

            deadline = time.time() + seconds
            while time.time() < deadline:
                try:
                    for hwnd in self.top_windows(profile):
                        docking.park_window(hwnd)
                except Exception:
                    pass
                time.sleep(0.4)

        threading.Thread(target=work, daemon=True, name="chrome-offscreen").start()

    def hide_window(self, profile: dict) -> bool:
        """Đẩy cửa sổ Chrome (đang chạy, chưa nhúng) của hồ sơ ra ngoài màn hình."""
        if sys.platform != "win32":
            return False
        from . import docking

        try:
            windows = self.top_windows(profile)
            for hwnd in windows:
                docking.park_window(hwnd)
            return bool(windows)
        except Exception:
            return False

    def top_windows(self, profile: dict) -> list[int]:
        """Cửa sổ Chrome TOP-LEVEL đang hiện của hồ sơ (cửa sổ đã nhúng là
        cửa sổ con nên không nằm trong danh sách này)."""
        if sys.platform != "win32":
            return []
        from . import docking

        pid = self.launched_pid(profile["slug"]) or self._pid_cache.get(int(profile["port"]))
        windows = docking.enumerate_windows_for_pid(pid) if pid else []
        if not windows:
            pid = docking.pid_listening_on_port(int(profile["port"]))
            if pid:
                self._pid_cache[int(profile["port"])] = pid
                windows = docking.enumerate_windows_for_pid(pid)
        return windows

    def start_window_sweeper(self, get_targets, interval: float = 2.5) -> None:
        """V6.7: luồng nền CẤT mọi cửa sổ Chrome chưa nhúng của app (hồ sơ +
        Muse) — kể cả cửa sổ bật lên sau này (popup, Chrome tự mở lại). 
        get_targets() → list[(profile_dict, allow_visible: bool)], gọi từ luồng nền
        nên chỉ được đọc dữ liệu đã chuẩn bị sẵn (không chạm kho SQLite)."""
        if sys.platform != "win32" or getattr(self, "_sweeper", None) is not None:
            return
        from . import docking

        def work():
            while True:
                time.sleep(interval)
                try:
                    targets = list(get_targets() or [])
                except Exception:
                    continue
                for profile, allow_visible in targets:
                    if allow_visible:
                        continue
                    try:
                        if not cdp.debug_port_open(int(profile["port"]), timeout=0.3):
                            continue
                        for hwnd in self.top_windows(profile):
                            docking.park_window(hwnd)
                    except Exception:
                        continue

        self._sweeper = threading.Thread(target=work, daemon=True, name="chrome-window-sweeper")
        self._sweeper.start()

    def connect_page(self, profile: dict) -> cdp.CDPClient:
        """Kết nối CDP tới một tab trang của hồ sơ (Chrome phải đang chạy).
        Client được cấp khả năng tự nối lại (xin URL websocket mới khi
        socket rớt) — xem CDPClient."""
        port = profile["port"]
        ws_url = cdp.page_websocket_url(port)
        return cdp.CDPClient(ws_url, reconnect=lambda: cdp.page_websocket_url(port))

    def launched_pid(self, slug: str) -> int | None:
        """PID của Chrome do CHÍNH phiên app này mở cho hồ sơ (None nếu
        phiên này không mở — vd Chrome do Muse mở từ trước). Phục vụ
        tính năng nhúng cửa sổ (app.docking) tìm đúng cửa sổ Chrome."""
        process = self._launched.get(slug)
        if process is not None and process.poll() is None:
            return process.pid
        return None

    def terminate_launched(self) -> None:
        """Tắt các Chrome do phiên app này mở (chỉ dùng khi cài đặt
        keep_chrome_open_on_exit = False)."""
        for process in self._launched.values():
            if process.poll() is None:
                process.terminate()
        self._launched.clear()


def quiet_preferences(user_data_dir) -> bool:
    """V7.0.1: sửa Preferences của hồ sơ Chrome TRƯỚC khi mở (Chrome đang tắt):
    - đánh dấu lần trước thoát SẠCH → không hiện "Khôi phục trang?";
    - tắt gợi ý dịch trang, lưu mật khẩu, tự điền, xin quyền thông báo.
    Lỗi gì cũng bỏ qua (không bao giờ chặn việc mở Chrome)."""
    import json

    try:
        default = Path(user_data_dir) / "Default"
        default.mkdir(parents=True, exist_ok=True)
        path = default / "Preferences"
        try:
            prefs = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
        except (OSError, ValueError):
            return False  # file đang hỏng/khoá — để Chrome tự xử lý
        if not isinstance(prefs, dict):
            return False

        def put(keys, value):
            node = prefs
            for key in keys[:-1]:
                if not isinstance(node.get(key), dict):
                    node[key] = {}
                node = node[key]
            node[keys[-1]] = value

        put(["profile", "exit_type"], "Normal")
        put(["profile", "exited_cleanly"], True)
        put(["translate", "enabled"], False)
        put(["translate_blocked_languages"], ["vi", "en", "ja", "es", "pt", "fr", "de", "zh-CN", "ko", "th", "id", "ru"])
        put(["credentials_enable_service"], False)
        put(["profile", "password_manager_enabled"], False)
        put(["autofill", "profile_enabled"], False)
        put(["autofill", "credit_card_enabled"], False)
        put(["profile", "default_content_setting_values", "notifications"], 2)
        put(["browser", "has_seen_welcome_page"], True)
        put(["browser", "check_default_browser"], False)
        put(["session", "restore_on_startup"], 5)  # mở trang mới, không khôi phục phiên cũ
        tmp = path.with_suffix(".ccdtmp")
        tmp.write_text(json.dumps(prefs, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
        return True
    except Exception:
        return False


def _chrome_version(chrome_path: str) -> str:
    """Bản Chrome cài trên máy: thư mục số phiên bản cạnh chrome.exe."""
    import re

    try:
        folder = Path(chrome_path).parent
        versions = sorted(
            (p.name for p in folder.iterdir() if p.is_dir() and re.fullmatch(r"\d+\.\d+\.\d+\.\d+", p.name)),
            key=lambda v: tuple(int(x) for x in v.split(".")), reverse=True)
        if versions:
            return versions[0]
    except Exception:
        pass
    return "131.0.0.0"


def _desktop_ua(chrome_path: str) -> str:
    major = _chrome_version(chrome_path).split(".")[0]
    platform = "Windows NT 10.0; Win64; x64" if sys.platform == "win32" else "X11; Linux x86_64"
    return (f"Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) "
            f"Chrome/{major}.0.0.0 Safari/537.36")


def _probe_port(port: int, timeout: float = 0.6) -> bool:
    """Dò nhanh Chrome trên cổng debug: thử TCP trước (cổng đóng thì
    thua sau ≤0.25s thay vì đợi HTTP timeout), mở mới hỏi /json/version."""
    try:
        with socket.create_connection(("127.0.0.1", int(port)), timeout=0.25):
            pass
    except OSError:
        return False
    return cdp.debug_port_open(int(port), timeout=timeout)
