"""V6.3 — ĐẨY tin chat của người dùng thẳng vào muse.ai (chat tức thì).

NGUYÊN NHÂN chat chậm (đã phân tích): Muse chạy trên SERVER của nó và
làm việc theo lượt — nó chỉ đọc tin trong app khi phiên của nó tự gọi
GET /api/agents/{id}/messages (nhịp hook ccd-bridge-watch, thường vài
phút một lần, hoặc khi đang bận việc dài thì tới lúc xong việc mới
đọc). Long-poll phía app đã trả về ngay, nhưng nếu phía Muse KHÔNG có
lời gọi nào đang treo thì tin vẫn nằm chờ. Đó là kéo (pull), không
phải đẩy (push).

KHẮC PHỤC: app đã có Chrome RIÊNG của từng tài khoản Muse, đã đăng
nhập muse.ai (đăng nhập hàng loạt V6.2). Khi người dùng gửi tin trong
app, app gõ một tin đánh thức vào ô chat muse.ai của đúng tài khoản đó
→ Muse nhận một lượt mới NGAY, đọc tin trong app và trả lời qua API.
Không có Chrome/chưa đăng nhập → lùi về cơ chế cũ (long-poll), không
lỗi.
"""

from __future__ import annotations

import json
import threading
import time

from . import agent_browser, cdp

COMPOSER_JS = r"""/*ccd:push-composer*/(() => {
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0; };
  const cands = [...document.querySelectorAll(
    'textarea, [contenteditable="true"], [role="textbox"], [data-testid="chat-input"]')].filter(visible);
  const el = cands[cands.length - 1];
  if (!el) return false;
  document.querySelectorAll('[data-ccd-push]').forEach(x => x.removeAttribute('data-ccd-push'));
  el.setAttribute('data-ccd-push', '1');
  el.focus();
  if (el.isContentEditable) {
    const range = document.createRange(); range.selectNodeContents(el);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
  } else if (el.select) { el.select(); }
  return true;
})()"""

SEND_JS = r"""/*ccd:push-send*/(() => {
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0; };
  const btn = [...document.querySelectorAll('button, [role="button"]')].filter(visible).find(b =>
    /send|gửi|submit/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')));
  if (btn && !btn.disabled) { btn.click(); return 'button'; }
  return 'none';
})()"""


def wake_text(agent: dict, body: str, api_hint: str = "") -> str:
    snippet = " ".join((body or "").split())
    if len(snippet) > 400:
        snippet = snippet[:400] + "…"
    return (
        f"📩 Người dùng vừa nhắn bạn trong Channel Control Desktop: «{snippet}». "
        f"Hãy đọc ngay GET /api/agents/{agent['id']}/messages?unread=1 bằng phiếu kết nối của bạn, "
        "xử lý và trả lời qua POST /api/agents/{id}/messages, rồi đánh dấu đã đọc."
        .replace("{id}", str(agent["id"]))
        + (f" {api_hint}" if api_hint else "")
    )


def _muse_page(port: int) -> dict | None:
    for target in cdp.http_json(port, "/json/list"):
        if target.get("type") == "page" and "muse.ai" in (target.get("url") or "") \
                and target.get("webSocketDebuggerUrl"):
            return target
    return None


def push_message(manager, agent: dict, text: str, launch_if_closed: bool = True,
                 client_factory=None, sleep=time.sleep) -> dict:
    """Gõ ``text`` vào ô chat muse.ai trong Chrome riêng của agent.
    Trả {'ok': bool, 'via': 'enter'|'button'|..., 'reason': str}."""
    pseudo = agent_browser.agent_profile(agent)
    port = pseudo["port"]
    try:
        running = manager.is_running(pseudo)
    except Exception:
        running = False
    if not running:
        if not launch_if_closed or agent.get("web_state") != "in":
            return {"ok": False, "reason": "Chrome muse.ai của tài khoản chưa mở/chưa đăng nhập"}
        try:
            manager.launch(pseudo, hidden=True)  # V6.5.2: chạy nền thật (ngoài màn hình)
        except TypeError:
            manager.launch(pseudo, start_minimized=True)
        sleep(3.0)
    target = _muse_page(port)
    if target is None:
        try:
            target = cdp.http_json(port, "/json/new?" + agent_browser.MUSE_URL, method="PUT")
        except Exception:
            target = cdp.http_json(port, "/json/new?" + agent_browser.MUSE_URL)
        sleep(5.0)
    factory = client_factory or (lambda ws: cdp.CDPClient(ws))
    client = factory(target["webSocketDebuggerUrl"])
    try:
        found = False
        for _ in range(10):
            if client.evaluate(COMPOSER_JS):
                found = True
                break
            sleep(1.0)
        if not found:
            return {"ok": False, "reason": "Không thấy ô chat trên muse.ai (có thể đã văng đăng nhập)"}
        client.call("Input.insertText", {"text": text})
        sleep(0.3)
        client.press_key("Enter")
        sleep(0.8)
        # Nếu Enter chỉ xuống dòng (ô vẫn còn chữ) thì bấm nút Gửi.
        still = client.evaluate(
            "(() => { const el = document.querySelector('[data-ccd-push]');"
            " return el ? (el.value || el.innerText || '').trim().length : 0; })()"
        )
        via = "enter"
        if still:
            via = client.evaluate(SEND_JS) or "none"
        return {"ok": via != "none", "via": via, "reason": "" if via != "none" else "Không bấm được nút gửi"}
    finally:
        try:
            client.close()
        except Exception:
            pass


class PushQueue:
    """Một luồng nền xếp hàng tin đẩy (không chặn giao diện; tin dồn
    dập cho cùng agent trong 5 giây gộp thành một lần đẩy)."""

    def __init__(self, manager, on_result=None, debounce_s: float = 5.0):
        self.manager = manager
        self.on_result = on_result or (lambda agent, result: None)
        self.debounce_s = debounce_s
        self._pending: dict[int, dict] = {}
        self._lock = threading.Lock()
        self._event = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True, name="muse-push")
        self._thread.start()

    def submit(self, agent: dict, body: str, raw: bool = False) -> None:
        """raw=True: gõ NGUYÊN VĂN ``body`` (vd lời nhắc kết nối lại),
        không bọc thành tin "người dùng vừa nhắn"."""
        with self._lock:
            entry = self._pending.setdefault(int(agent["id"]), {"agent": dict(agent), "bodies": [], "at": 0.0, "raw": False})
            entry["agent"] = dict(agent)
            entry["bodies"].append(body)
            entry["raw"] = entry.get("raw") or raw
            entry["at"] = time.monotonic()
        self._event.set()

    def _loop(self):
        while True:
            self._event.wait(1.0)
            self._event.clear()
            now = time.monotonic()
            ready = []
            with self._lock:
                for agent_id, entry in list(self._pending.items()):
                    if now - entry["at"] >= min(self.debounce_s, 1.5):
                        ready.append(self._pending.pop(agent_id))
            for entry in ready:
                agent = entry["agent"]
                body = " / ".join(entry["bodies"])
                try:
                    text = body if entry.get("raw") else wake_text(agent, body)
                    result = push_message(self.manager, agent, text)
                except Exception as exc:  # noqa: BLE001
                    result = {"ok": False, "reason": f"{type(exc).__name__}: {exc}"}
                try:
                    self.on_result(agent, result)
                except Exception:
                    pass
            if self._pending:
                self._event.set()
                time.sleep(0.5)


def dumps(result: dict) -> str:
    return json.dumps(result, ensure_ascii=False)
