"""Kho dữ liệu SQLite: hồ sơ (profiles), kênh (channels), nhật ký (journal).

Module này chỉ dùng thư viện chuẩn để dễ kiểm thử (pytest) mà không cần Qt.
Mọi hàm ghi đều commit ngay. ``Store`` nhận đường dẫn DB bất kỳ — test dùng
thư mục tạm, app dùng ``config.db_path()``.
"""

from __future__ import annotations

import json
import secrets
import shutil
import sqlite3
import uuid
from datetime import datetime, timedelta
from pathlib import Path

from . import config


def now_iso() -> str:
    """Mốc thời gian địa phương dạng ISO, chính xác tới giây."""
    return datetime.now().astimezone().isoformat(timespec="seconds")


SCHEMA = """
CREATE TABLE IF NOT EXISTS profiles (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    slug        TEXT NOT NULL UNIQUE,
    label       TEXT NOT NULL,
    gmail       TEXT NOT NULL DEFAULT '',
    note        TEXT NOT NULL DEFAULT '',
    port        INTEGER NOT NULL,
    paused      INTEGER NOT NULL DEFAULT 0,
    last_scan_at TEXT,
    created_at  TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS channels (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id   INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    channel_id   TEXT NOT NULL,
    name         TEXT NOT NULL DEFAULT '',
    handle       TEXT NOT NULL DEFAULT '',
    url          TEXT NOT NULL DEFAULT '',
    subs         INTEGER,
    video_count  INTEGER,
    niche        TEXT NOT NULL DEFAULT '',
    last_scan_at TEXT,
    UNIQUE (profile_id, channel_id)
);
CREATE TABLE IF NOT EXISTS journal (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER REFERENCES profiles(id) ON DELETE CASCADE,
    ts         TEXT NOT NULL,
    message    TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS commands (
    id           TEXT PRIMARY KEY,
    source       TEXT NOT NULL DEFAULT 'ui',
    type         TEXT NOT NULL,
    profile_id   INTEGER REFERENCES profiles(id) ON DELETE CASCADE,
    profile_slug TEXT,
    channel_id   TEXT NOT NULL DEFAULT '',
    instruction  TEXT NOT NULL DEFAULT '',
    payload      TEXT NOT NULL DEFAULT '{}',
    status       TEXT NOT NULL DEFAULT 'queued',
    result       TEXT,
    result_json  TEXT,
    error        TEXT,
    scheduled_at TEXT,
    created_at   TEXT NOT NULL,
    started_at   TEXT,
    finished_at  TEXT,
    updated_at   TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS automation_rules (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    action         TEXT NOT NULL,
    profile_id     INTEGER REFERENCES profiles(id) ON DELETE CASCADE,
    schedule_kind  TEXT NOT NULL DEFAULT 'daily',
    daily_time     TEXT NOT NULL DEFAULT '08:00',
    interval_hours REAL,
    enabled        INTEGER NOT NULL DEFAULT 0,
    last_run_at    TEXT,
    next_run_at    TEXT,
    created_at     TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS profile_checks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    ts         TEXT NOT NULL,
    items      TEXT NOT NULL DEFAULT '[]',
    summary    TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS videos (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id   INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    channel_id   TEXT NOT NULL DEFAULT '',
    video_id     TEXT NOT NULL,
    title        TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT '',
    scheduled_at TEXT,
    url          TEXT NOT NULL DEFAULT '',
    created_at   TEXT NOT NULL,
    updated_at   TEXT NOT NULL,
    UNIQUE (profile_id, video_id)
);
"""

# Trạng thái hợp lệ của một lệnh công việc (V3; V3.1 thêm 'interrupted' —
# lệnh đang 'running' khi app thoát/sập, được khôi phục lúc khởi động và
# có thể xếp hàng chạy lại từ panel Lệnh công việc; V4.0 thêm 'needs_user'
# — lệnh chờ Muse dừng lại vì cần con người xử lý (2FA/CAPTCHA/hết
# phiên...), xử lý xong bấm "Đã xử lý — chạy tiếp" là về 'queued').
COMMAND_STATUSES = (
    "queued", "running", "waiting_muse", "needs_user",
    "done", "failed", "interrupted",
)
# Loại lệnh app tự chạy được tại chỗ / loại phải chờ Muse làm qua trình duyệt.
LOCAL_COMMAND_TYPES = ("open_browser", "scan", "check")
CLAUDE_COMMAND_TYPES = (
    "optimize", "upload", "free", "create_video", "create_channel",
    # V6.0: 'review' — VIỆC KIỂM TRA giám sát chéo: một lệnh chờ
    # Muse như mọi lệnh Claude khác (claim/lease/progress/result),
    # do app tự sinh và gắn thẳng cho Muse giám sát (xem
    # app.supervision). Bộ chạy tại chỗ bỏ qua như mọi loại Muse.
    "review",
)
# Hành động được phép đặt trong QUY TẮC TỰ ĐỘNG: các lệnh app tự chạy
# + 'create_video' (lệnh chờ Muse — bộ máy tự động tạo lệnh gắn đúng
# Muse phụ trách hồ sơ, xem automation.AutomationEngine).
RULE_ACTIONS = LOCAL_COMMAND_TYPES + ("create_video",)
# Các loại 'cdp_*' chỉ do Muse tạo qua Agent API (worker của agent_server
# chạy), không hiện trong dropdown tạo lệnh của UI và không qua executor
# của UI. V4.3: thêm cdp_evaluate/cdp_click/cdp_type bọc quanh primitive
# CDP sẵn có (evaluate/dispatch_mouse/dispatch_key trong app.cdp) — trước
# đó API chỉ có cdp_navigate nên Muse mở/điều hướng được trình duyệt
# nhúng nhưng KHÔNG bấm/gõ được, lệnh tương tác phải quay vòng needs_user.
# V4.4: 'studio_script' — kịch bản nhiều bước chạy trong Chrome nhúng
# (app/studio_script.py), thực thi CẢ ở agent_server LẪN executor của
# UI; đây là ngoại lệ DUY NHẤT của nhóm CDP có mặt trong dropdown tạo
# lệnh của UI để người dùng tự tạo/chạy thử.
CDP_COMMAND_TYPES = (
    "cdp_navigate", "cdp_evaluate", "cdp_click", "cdp_type", "studio_script",
    # V6.3: đọc trang (mắt của Muse khi thao tác từ xa).
    "cdp_snapshot",
)
COMMAND_TYPES = LOCAL_COMMAND_TYPES + CLAUDE_COMMAND_TYPES + CDP_COMMAND_TYPES
# V6.1 — HẠN CHÓT MẶC ĐỊNH (phút) theo loại lệnh: mọi việc được giao
# đều có thời hạn cụ thể để trưởng phòng/giám sát đo tiến độ so với
# hạn. Cài đặt 'deadline_minutes' ghi đè từng loại (MainWindow /
# AgentServer đẩy vào Store.deadline_minutes khi mở/lưu cài đặt).
DEFAULT_DEADLINE_MINUTES = {
    "create_video": 240,
    "create_channel": 120,
    "optimize": 60,
    "upload": 60,
    "free": 120,
    "review": 60,
    "studio_script": 30,
    "scan": 15,
    "check": 15,
    "open_browser": 10,
}

COMMAND_TYPE_LABELS = {
    "open_browser": "Mở trình duyệt",
    "scan": "Quét kênh",
    "check": "Kiểm tra kênh",
    "optimize": "Tối ưu kênh",
    "upload": "Tải video lên",
    "free": "Lệnh tự do",
    "create_video": "Tạo video (Muse)",
    "create_channel": "Tạo kênh mới (Muse)",
    "review": "Kiểm tra chéo (giám sát)",
    "cdp_navigate": "Điều hướng CDP",
    "cdp_evaluate": "Chạy JS trong trang (CDP)",
    "cdp_click": "Bấm phần tử (CDP)",
    "cdp_type": "Gõ chữ (CDP)",
    "cdp_snapshot": "Đọc trang (CDP)",
    "studio_script": "Kịch bản Studio (nhúng)",
}


# --------------------------------------------------------------------------- #
# Di trú schema (V3.1) — PRAGMA user_version là mốc phiên bản.
# DB tạo ở thời V1–V3 chưa hề đặt user_version (mặc định 0) nhưng ĐÃ có các
# bảng của SCHEMA; di trú v1 dùng lại chính SCHEMA (mọi câu lệnh đều
# IF NOT EXISTS) nên chạy lại bao nhiêu lần cũng an toàn (idempotent).
# --------------------------------------------------------------------------- #
SCHEMA_VERSION = 12  # V7.0: v12 = đa nền tảng (platform)

_META_DDL = """
CREATE TABLE IF NOT EXISTS app_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL DEFAULT ''
);
"""


def _migration_v2(conn: sqlite3.Connection) -> None:
    """v2: bảng app_meta (chẩn đoán khởi động...) + cột attempts cho commands
    (đếm số lần thử lại của bộ máy hàng đợi V3.1). ALTER TABLE không có
    IF NOT EXISTS nên kiểm tra table_info trước — idempotent."""
    conn.executescript(_META_DDL)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    if "attempts" not in columns:
        conn.execute(
            "ALTER TABLE commands ADD COLUMN attempts INTEGER NOT NULL DEFAULT 0"
        )


def _migration_v3(conn: sqlite3.Connection) -> None:
    """v3 (V3.2): cột progress (0–100) + step (mô tả bước hiện tại) cho
    commands — nền cho việc theo dõi tiến độ từng công việc của Muse
    ngay trong app (panel Lệnh + thẻ 'Muse đang làm' ở Tổng quan)."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    if "progress" not in columns:
        conn.execute(
            "ALTER TABLE commands ADD COLUMN progress INTEGER NOT NULL DEFAULT 0"
        )
    if "step" not in columns:
        conn.execute("ALTER TABLE commands ADD COLUMN step TEXT NOT NULL DEFAULT ''")


_AGENTS_DDL = """
CREATE TABLE IF NOT EXISTS agents (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    name               TEXT NOT NULL DEFAULT '',
    email              TEXT NOT NULL UNIQUE,
    token              TEXT NOT NULL DEFAULT '',
    note               TEXT NOT NULL DEFAULT '',
    revoked            INTEGER NOT NULL DEFAULT 0,
    last_seen_at       TEXT,
    current_command_id TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL,
    updated_at         TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS agent_assignments (
    agent_id   INTEGER NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    profile_id INTEGER NOT NULL UNIQUE REFERENCES profiles(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    PRIMARY KEY (agent_id, profile_id)
);
"""


def _migration_v4(conn: sqlite3.Connection) -> None:
    """v4 (V3.3): tài khoản Muse (agents) + bảng phân công
    agent_assignments (mỗi hồ sơ tối đa MỘT Muse chính — profile_id
    UNIQUE; một Muse phụ trách được NHIỀU hồ sơ/kênh) + cột
    commands.agent_id ghi lệnh đang do Muse nào giữ."""
    conn.executescript(_AGENTS_DDL)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    if "agent_id" not in columns:
        conn.execute("ALTER TABLE commands ADD COLUMN agent_id INTEGER")


def _migration_v5(conn: sqlite3.Connection) -> None:
    """v5 (V3.4): kênh có logo (channels.avatar_url) + bảng
    channel_snapshots — một dòng mỗi kênh mỗi NGÀY (subs + số video tại
    lần quét trong ngày) làm nền cho báo cáo/phân tích/xu hướng kênh."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(channels)")}
    if "avatar_url" not in columns:
        conn.execute(
            "ALTER TABLE channels ADD COLUMN avatar_url TEXT NOT NULL DEFAULT ''"
        )
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS channel_snapshots (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            profile_id  INTEGER NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
            channel_id  TEXT NOT NULL,
            day         TEXT NOT NULL,
            subs        INTEGER,
            video_count INTEGER,
            captured_at TEXT NOT NULL,
            UNIQUE (profile_id, channel_id, day)
        );
        """
    )


def _migration_v6(conn: sqlite3.Connection) -> None:
    """v6 (V3.5): agents.web_state — trạng thái đăng nhập muse.ai của
    tài khoản Muse trong Chrome riêng của nó ('unknown' chưa kiểm
    tra, 'waiting' đang mở chờ đăng nhập, 'in' đã đăng nhập, 'out'
    chưa đăng nhập) + mốc kiểm tra cuối."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(agents)")}
    if "web_state" not in columns:
        conn.execute(
            "ALTER TABLE agents ADD COLUMN web_state TEXT NOT NULL DEFAULT 'unknown'"
        )
    if "web_checked_at" not in columns:
        conn.execute("ALTER TABLE agents ADD COLUMN web_checked_at TEXT")


_MESSAGES_DDL = """
CREATE TABLE IF NOT EXISTS agent_messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id   INTEGER NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    direction  TEXT NOT NULL DEFAULT 'user',
    body       TEXT NOT NULL DEFAULT '',
    command_id TEXT,
    created_at TEXT NOT NULL,
    read_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_agent_messages_unread
    ON agent_messages (agent_id, read_at);
CREATE INDEX IF NOT EXISTS idx_agent_messages_thread
    ON agent_messages (agent_id, id);
"""


def _migration_v8(conn: sqlite3.Connection) -> None:
    """v8 (V4.6): bảng agent_messages — luồng CHAT hai chiều giữa
    người dùng và TỪNG tài khoản Muse ngay trong app. direction:
    'user' (người dùng → Muse), 'agent' (Muse → người dùng),
    'system' (app tự chèn, vd khi lệnh kẹt needs_user). read_at NULL
    = phía nhận chưa đọc. Chỉ THÊM bảng + index, không đụng dữ liệu
    cũ."""
    conn.executescript(_MESSAGES_DDL)


_REVIEWS_DDL = """
CREATE TABLE IF NOT EXISTS reviews (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    command_id         TEXT NOT NULL,
    review_command_id  TEXT,
    worker_agent_id    INTEGER,
    supervisor_agent_id INTEGER,
    trigger_kind       TEXT NOT NULL DEFAULT 'done',
    round              INTEGER NOT NULL DEFAULT 0,
    status             TEXT NOT NULL DEFAULT 'open',
    checklist          TEXT NOT NULL DEFAULT '[]',
    verdict            TEXT,
    notes              TEXT NOT NULL DEFAULT '',
    created_at         TEXT NOT NULL,
    decided_at         TEXT
);
CREATE INDEX IF NOT EXISTS idx_reviews_command
    ON reviews (command_id, id);
CREATE INDEX IF NOT EXISTS idx_reviews_status
    ON reviews (status, id);
"""


def _migration_v9(conn: sqlite3.Connection) -> None:
    """v9 (V6.0 — giám sát chéo): bảng reviews (mỗi vòng kiểm tra của
    một lệnh gốc: ai làm, ai chấm, kích hoạt vì sao, kết luận gì) +
    hai cột trên commands: review_round (đã làm lại mấy vòng) và
    last_verdict (kết luận kiểm tra gần nhất). Chỉ THÊM — dữ liệu cũ
    nguyên vẹn, lệnh cũ có round 0 / verdict rỗng = chưa từng chấm."""
    conn.executescript(_REVIEWS_DDL)
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    if "review_round" not in columns:
        conn.execute(
            "ALTER TABLE commands ADD COLUMN review_round"
            " INTEGER NOT NULL DEFAULT 0"
        )
    if "last_verdict" not in columns:
        conn.execute(
            "ALTER TABLE commands ADD COLUMN last_verdict"
            " TEXT NOT NULL DEFAULT ''"
        )


def _migration_v10(conn: sqlite3.Connection) -> None:
    """v10 (V6.1): (a) HẠN CHÓT cho mọi việc — cột due_at trên
    commands (ISO, NULL = chưa đặt hạn; lệnh cũ được gán hạn ở lần
    đầu bảng giám sát cần tới qua backfill_due_dates); (b) CHỈ MỤC
    cho các truy vấn nóng mà các nhịp làm mới chạy liên tục (trước
    V6.1 bảng commands/journal không có chỉ mục nào ngoài khoá chính →
    mọi đếm/lọc theo trạng thái là quét toàn bảng, chậm dần theo
    lịch sử tích luỹ)."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    if "due_at" not in columns:
        conn.execute("ALTER TABLE commands ADD COLUMN due_at TEXT")
    conn.executescript(
        """
        CREATE INDEX IF NOT EXISTS idx_commands_status_created
            ON commands (status, created_at);
        CREATE INDEX IF NOT EXISTS idx_commands_created
            ON commands (created_at);
        CREATE INDEX IF NOT EXISTS idx_commands_profile
            ON commands (profile_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_commands_agent
            ON commands (agent_id, status);
        CREATE INDEX IF NOT EXISTS idx_commands_due
            ON commands (status, due_at);
        CREATE INDEX IF NOT EXISTS idx_journal_profile
            ON journal (profile_id, id);
        """
    )


def _migration_v11(conn: sqlite3.Connection) -> None:
    """v11 (V6.3): LỊCH SỬ TỪNG BƯỚC của mỗi việc — mỗi lần Muse/bộ
    chạy báo tiến độ có chữ bước mới là một dòng (bảng việc hiện đủ
    các bước agent đã làm, không chỉ bước cuối) + nhật ký quyết định
    của trưởng phòng (lead_decisions) để chấm KPI giám sát."""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS command_steps (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            command_id  TEXT NOT NULL,
            at          TEXT NOT NULL,
            progress    INTEGER NOT NULL DEFAULT 0,
            step        TEXT NOT NULL DEFAULT '',
            actor       TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_command_steps_cmd
            ON command_steps (command_id, id);
        CREATE TABLE IF NOT EXISTS lead_decisions (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            at          TEXT NOT NULL,
            lead_id     INTEGER,
            issue_key   TEXT NOT NULL DEFAULT '',
            action      TEXT NOT NULL DEFAULT '',
            command_id  TEXT,
            agent_id    INTEGER,
            detail      TEXT NOT NULL DEFAULT '',
            outcome     TEXT NOT NULL DEFAULT 'pending'
        );
        CREATE INDEX IF NOT EXISTS idx_lead_decisions_at
            ON lead_decisions (at);
        """
    )


def _migration_v7(conn: sqlite3.Connection) -> None:
    """v7 (V4.0): nền của vòng tự động hoàn toàn cho lệnh chờ Muse —
    lease (lease_expires_at + lease_agent_id: Muse nào đang GIỮ lệnh
    và giữ tới khi nào), idempotency_key (chống tạo trùng; UNIQUE INDEX
    một phần chỉ áp cho key khác rỗng) và depends_on (id lệnh phải
    'done' trước khi dispatcher cho lệnh này sẵn sàng)."""
    columns = {row[1] for row in conn.execute("PRAGMA table_info(commands)")}
    additions = (
        ("lease_expires_at", "ALTER TABLE commands ADD COLUMN lease_expires_at TEXT"),
        ("lease_agent_id", "ALTER TABLE commands ADD COLUMN lease_agent_id INTEGER"),
        ("idempotency_key", "ALTER TABLE commands ADD COLUMN idempotency_key TEXT"),
        ("depends_on", "ALTER TABLE commands ADD COLUMN depends_on TEXT"),
    )
    for name, ddl in additions:
        if name not in columns:
            conn.execute(ddl)
    conn.execute(
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_commands_idempotency"
        " ON commands (idempotency_key)"
        " WHERE idempotency_key IS NOT NULL AND idempotency_key <> ''"
    )


def _migration_v12(conn: sqlite3.Connection) -> None:
    """v12 (V7.0): ĐA NỀN TẢNG — hồ sơ và kênh có 'platform'
    (youtube | facebook | tiktok). Dữ liệu cũ mặc định 'youtube'."""
    for table in ("profiles", "channels"):
        columns = {row[1] for row in conn.execute(f"PRAGMA table_info({table})")}
        if "platform" not in columns:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN platform TEXT NOT NULL DEFAULT 'youtube'")


MIGRATIONS = [
    (1, lambda conn: conn.executescript(SCHEMA)),
    (2, _migration_v2),
    (3, _migration_v3),
    (4, _migration_v4),
    (5, _migration_v5),
    (6, _migration_v6),
    (7, _migration_v7),
    (8, _migration_v8),
    (9, _migration_v9),
    (10, _migration_v10),
    (11, _migration_v11),
    (12, _migration_v12),
]


class Store:
    # V6.1: bảng phút hạn chót theo loại lệnh (chia sẻ mọi phiên Store
    # trong tiến trình — cài đặt ghi đè qua set_deadline_minutes).
    deadline_minutes: dict[str, int] = dict(DEFAULT_DEADLINE_MINUTES)

    @classmethod
    def set_deadline_minutes(cls, overrides: dict | None) -> None:
        merged = dict(DEFAULT_DEADLINE_MINUTES)
        for key, value in (overrides or {}).items():
            try:
                minutes = int(value)
            except (TypeError, ValueError):
                continue
            if minutes > 0:
                merged[str(key)] = minutes
        cls.deadline_minutes = merged

    @classmethod
    def default_due_at(cls, type: str, base: datetime | None = None) -> str | None:
        minutes = cls.deadline_minutes.get(type)
        if not minutes:
            return None
        base = base or datetime.now().astimezone()
        return (base + timedelta(minutes=int(minutes))).isoformat(timespec="seconds")

    def __init__(self, db_file: str | Path):
        self.db_file = Path(db_file)
        self.db_file.parent.mkdir(parents=True, exist_ok=True)
        # V6.4.4: chờ khoá tới 30 giây (bản cũ 5 giây) — trên Windows ổ
        # chậm/antivirus quét file, một lần ghi có thể bị giữ vài giây.
        self._conn = sqlite3.connect(str(self.db_file), timeout=30.0)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        # WAL (V3.1): nhiều kết nối ngắn hạn (UI, worker, Agent API) đọc/ghi
        # song song êm hơn hẳn chế độ journal xoá-cũ; busy_timeout giảm lỗi
        # "database is locked" khi hai luồng ghi cùng lúc.
        try:
            self._conn.execute("PRAGMA journal_mode = WAL")
        except sqlite3.Error:
            pass  # vd :memory: — giữ chế độ mặc định, không làm sập app
        self._conn.execute("PRAGMA busy_timeout = 30000")
        # V6.4.4: WAL + synchronous=NORMAL — mỗi lần chốt không phải
        # fsync cả file → giữ khoá ghi ngắn hơn nhiều (an toàn với WAL).
        try:
            self._conn.execute("PRAGMA synchronous = NORMAL")
        except sqlite3.Error:
            pass
        self._migrate()
        self._conn.commit()

    def _migrate(self) -> None:
        """Chạy các di trú schema còn thiếu theo PRAGMA user_version.
        Mỗi di trú tự nó idempotent nên gọi lại _migrate() là vô hại."""
        current = int(self._conn.execute("PRAGMA user_version").fetchone()[0])
        for version, step in MIGRATIONS:
            if version > current:
                step(self._conn)
                self._conn.execute(f"PRAGMA user_version = {int(version)}")
                self._conn.commit()
                current = version

    @property
    def schema_version(self) -> int:
        return int(self._conn.execute("PRAGMA user_version").fetchone()[0])

    def close(self) -> None:
        self._conn.close()

    def integrity_check(self) -> str:
        """PRAGMA integrity_check — 'ok' khi kho lành lặn."""
        try:
            row = self._conn.execute("PRAGMA integrity_check").fetchone()
            return str(row[0]) if row else "unknown"
        except sqlite3.Error as exc:
            return f"error: {exc}"

    # ------------------------------------------------------------------ #
    # Khoá–giá trị dùng chung (app_meta): chẩn đoán khởi động, ...
    # ------------------------------------------------------------------ #
    def set_meta(self, key: str, value: str) -> None:
        self._conn.execute(
            "INSERT INTO app_meta (key, value) VALUES (?, ?)"
            " ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )
        self._conn.commit()

    def get_meta(self, key: str) -> str | None:
        row = self._conn.execute(
            "SELECT value FROM app_meta WHERE key = ?", (key,)
        ).fetchone()
        return row[0] if row else None

    # ------------------------------------------------------------------ #
    # Cầu nối Muse (V3.8): bằng chứng "có Muse đang nghe lệnh hay
    # không". Mọi lời gọi API đã xác thực đều được ghi nhận (tiết lưu
    # 20 giây để không ghi đĩa liên tục khi Muse poll dày).
    # ------------------------------------------------------------------ #
    def note_bridge_activity(self, agent_id: int | None = None) -> None:
        now = datetime.now().astimezone()
        last_raw = self.get_meta("bridge_last_poll_at")
        if last_raw:
            try:
                last = datetime.fromisoformat(last_raw)
                if (now - last).total_seconds() < 20:
                    return
            except ValueError:
                pass
        self.set_meta("bridge_last_poll_at", now.isoformat(timespec="seconds"))
        if agent_id is not None:
            self.set_meta("bridge_last_agent_id", str(agent_id))

    def bridge_state(self) -> dict:
        """Trạng thái cầu nối suy từ dữ liệu thật: lần gọi API hợp lệ gần
        nhất + có Muse nào đang online (heartbeat < 120s) hay không.
        'connected' = có hoạt động trong 180 giây qua hoặc agent online —
        ngoài ra lệnh chờ Muse chắc chắn KHÔNG có ai nhận."""
        now = datetime.now().astimezone()
        last_raw = self.get_meta("bridge_last_poll_at")
        last = None
        seconds_ago = None
        if last_raw:
            try:
                last = datetime.fromisoformat(last_raw)
                seconds_ago = max(0.0, (now - last).total_seconds())
            except ValueError:
                last = None
        any_online = False
        for agent in self.list_agents():
            if agent.get("revoked"):
                continue
            seen = agent.get("last_seen_at")
            if not seen:
                continue
            try:
                delta = (now - datetime.fromisoformat(seen)).total_seconds()
            except ValueError:
                continue
            if delta < AGENT_ONLINE_SECONDS:
                any_online = True
                break
        return {
            "ever": last is not None or any_online,
            "last_poll_at": last_raw,
            "seconds_ago": seconds_ago,
            "any_agent_online": any_online,
            "connected": bool(any_online or (seconds_ago is not None and seconds_ago <= 180)),
        }

    # ------------------------------------------------------------------ #
    # Số liệu tổng quan (V3.1 — mục Tổng quan)
    # ------------------------------------------------------------------ #
    def stats(self) -> dict:
        """Đếm nhanh phục vụ thẻ KPI: tổng kênh, tổng subscribers, số video
        đang Scheduled trong kho, số lệnh đang chờ/đang chạy."""
        def _count(sql: str) -> int:
            return int(self._conn.execute(sql).fetchone()[0])

        subs_row = self._conn.execute(
            "SELECT COALESCE(SUM(subs), 0) FROM channels"
        ).fetchone()
        return {
            "channels": _count("SELECT COUNT(*) FROM channels"),
            "subscribers": int(subs_row[0]),
            "videos_scheduled": _count(
                "SELECT COUNT(*) FROM videos WHERE status = 'scheduled'"
            ),
            "commands_pending": _count(
                "SELECT COUNT(*) FROM commands WHERE status IN ('queued', 'waiting_muse')"
            ),
            "commands_running": _count(
                "SELECT COUNT(*) FROM commands WHERE status = 'running'"
            ),
            "profiles": _count("SELECT COUNT(*) FROM profiles"),
        }

    # ------------------------------------------------------------------ #
    # Xuất dữ liệu (V3.1 — mục Cài đặt > Dữ liệu)
    # ------------------------------------------------------------------ #
    def export_channels(self, fmt: str = "json") -> str:
        rows = [
            dict(r)
            for r in self._conn.execute(
                "SELECT c.*, p.label AS profile_label, p.slug AS profile_slug"
                " FROM channels c JOIN profiles p ON p.id = c.profile_id"
                " ORDER BY p.id, c.name"
            ).fetchall()
        ]
        return _export_rows(rows, fmt)

    def export_journal(self, fmt: str = "json", limit: int = 5000) -> str:
        rows = [
            dict(r)
            for r in self._conn.execute(
                "SELECT * FROM journal ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        ]
        rows.reverse()
        return _export_rows(rows, fmt)

    # ------------------------------------------------------------------ #
    # Hồ sơ
    # ------------------------------------------------------------------ #
    def _unique_slug(self, base_slug: str) -> str:
        slug, n = base_slug, 2
        while self._conn.execute("SELECT 1 FROM profiles WHERE slug = ?", (slug,)).fetchone():
            slug = f"{base_slug}-{n}"
            n += 1
        return slug

    def _unique_port(self, slug: str) -> int:
        port = config.port_for_slug(slug)
        used = {row[0] for row in self._conn.execute("SELECT port FROM profiles")}
        while port in used:
            port += 1
        return port

    def find_profile_by_gmail(self, gmail: str) -> dict | None:
        """Hồ sơ đang giữ một Gmail (không phân biệt hoa/thường, bỏ
        khoảng trắng thừa). Mỗi Gmail chỉ thuộc MỘT hồ sơ riêng (V3.2)."""
        normalized = (gmail or "").strip().lower()
        if not normalized:
            return None
        row = self._conn.execute(
            "SELECT * FROM profiles WHERE lower(trim(gmail)) = ?", (normalized,)
        ).fetchone()
        return _profile_row(row) if row else None

    def set_profile_platform(self, profile_id: int, platform: str) -> None:
        """V7.0: nền tảng của hồ sơ — youtube | facebook | tiktok."""
        if platform not in ("youtube", "facebook", "tiktok"):
            raise ValueError(f"Nền tảng không hỗ trợ: {platform}")
        self._conn.execute("UPDATE profiles SET platform = ? WHERE id = ?", (platform, int(profile_id)))
        self._conn.commit()

    def add_profile(self, label: str, gmail: str = "", note: str = "", platform: str = "youtube") -> dict:
        """Thêm hồ sơ mới; slug và cổng được suy ra tất định (xử lý trùng lặp
        bằng hậu tố -2, -3... và tăng cổng). Trả về dict hồ sơ đầy đủ.

        Quy tắc V3.2: mỗi tài khoản Gmail lưu đúng MỘT hồ sơ riêng — Gmail
        đã thuộc hồ sơ khác thì ném ValueError (nơi gọi tự hiển thị)."""
        existing = self.find_profile_by_gmail(gmail)
        if existing is not None:
            raise ValueError(
                f"Gmail {gmail.strip()} đã thuộc hồ sơ '{existing['label']}' "
                f"(slug {existing['slug']}) — mỗi Gmail chỉ có một hồ sơ riêng."
            )
        slug = self._unique_slug(config.slugify(label))
        port = self._unique_port(slug)
        cur = self._conn.execute(
            "INSERT INTO profiles (slug, label, gmail, note, port, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?)",
            (slug, label.strip(), gmail.strip(), note.strip(), port, now_iso()),
        )
        if platform and platform != "youtube":
            self._conn.execute("UPDATE profiles SET platform = ? WHERE id = ?", (platform, cur.lastrowid))
        self._conn.commit()
        return self.get_profile(cur.lastrowid)

    def get_profile(self, profile_id: int) -> dict | None:
        row = self._conn.execute("SELECT * FROM profiles WHERE id = ?", (profile_id,)).fetchone()
        return _profile_row(row) if row else None

    def update_profile(
        self,
        profile_id: int,
        label: str | None = None,
        gmail: str | None = None,
        note: str | None = None,
    ) -> dict:
        """Sửa nhãn / Gmail / ghi chú của một hồ sơ (V5.3.2 —
        M-PROFILE-EDIT). Trường None = giữ nguyên giá trị cũ.

        Slug và cổng debug KHÔNG đổi: chúng được suy tất định lúc
        tạo và đã gắn với thư mục Chrome + cấu hình nhúng của hồ
        sơ — đổi slug sẽ mồ côi dữ liệu trình duyệt. Quy tắc một
        Gmail–một hồ sơ của V3.2 áp y hệt lúc thêm: Gmail mới đã
        thuộc hồ sơ KHÁC thì ném ValueError (nơi gọi tự hiển thị).
        """
        profile = self.get_profile(profile_id)
        if profile is None:
            raise ValueError(f"Không tìm thấy hồ sơ #{profile_id}.")
        new_label = profile["label"] if label is None else label.strip()
        new_gmail = profile["gmail"] if gmail is None else gmail.strip()
        new_note = profile["note"] if note is None else note.strip()
        if not new_label or not new_gmail:
            raise ValueError("Nhãn hồ sơ và Gmail là bắt buộc.")
        if new_gmail != profile["gmail"]:
            existing = self.find_profile_by_gmail(new_gmail)
            if existing is not None and existing["id"] != profile_id:
                raise ValueError(
                    f"Gmail {new_gmail} đã thuộc hồ sơ "
                    f"'{existing['label']}' (slug {existing['slug']}) "
                    "— mỗi Gmail chỉ có một hồ sơ riêng."
                )
        self._conn.execute(
            "UPDATE profiles SET label = ?, gmail = ?, note = ?"
            " WHERE id = ?",
            (new_label, new_gmail, new_note, profile_id),
        )
        self._conn.commit()
        return self.get_profile(profile_id)

    def get_profile_by_slug(self, slug: str) -> dict | None:
        row = self._conn.execute("SELECT * FROM profiles WHERE slug = ?", (slug,)).fetchone()
        return _profile_row(row) if row else None

    def list_profiles(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM profiles ORDER BY id").fetchall()
        return [_profile_row(r) for r in rows]

    def delete_profile(self, profile_id: int) -> None:
        """Xoá hồ sơ khỏi DB; kênh và nhật ký của hồ sơ bị xoá theo
        (ON DELETE CASCADE). Thư mục Chrome trên đĩa KHÔNG bị đụng vào —
        tầng giao diện tự lưu trữ nó nếu cần."""
        self._conn.execute("DELETE FROM profiles WHERE id = ?", (profile_id,))
        self._conn.commit()

    def set_profile_paused(self, profile_id: int, paused: bool) -> None:
        self._conn.execute(
            "UPDATE profiles SET paused = ? WHERE id = ?", (1 if paused else 0, profile_id)
        )
        self._conn.commit()

    def mark_profile_scanned(self, profile_id: int, ts: str | None = None) -> None:
        self._conn.execute(
            "UPDATE profiles SET last_scan_at = ? WHERE id = ?", (ts or now_iso(), profile_id)
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Kênh
    # ------------------------------------------------------------------ #
    def upsert_channel(self, profile_id: int, channel: dict) -> bool:
        """Thêm mới hoặc cập nhật kênh theo (profile_id, channel_id).

        Trả về True nếu là kênh MỚI. Khi cập nhật: ghi đè tên/handle/url/subs;
        video_count và niche chỉ ghi đè khi giá trị mới khác None / khác rỗng
        (để lần quét thiếu dữ liệu không xoá dữ liệu cũ)."""
        channel_id = (channel.get("channel_id") or "").strip()
        if not channel_id:
            raise ValueError("channel dict thiếu 'channel_id'")
        ts = now_iso()
        existing = self._conn.execute(
            "SELECT id, video_count, niche, avatar_url FROM channels WHERE profile_id = ? AND channel_id = ?",
            (profile_id, channel_id),
        ).fetchone()
        video_count = channel.get("video_count")
        niche = (channel.get("niche") or "").strip()
        avatar_url = (channel.get("avatar_url") or "").strip()
        platform = (channel.get("platform") or "").strip()
        if not platform:
            prof = self._conn.execute("SELECT platform FROM profiles WHERE id = ?", (profile_id,)).fetchone()
            platform = (prof["platform"] if prof is not None and "platform" in prof.keys() else "") or "youtube"
        if existing is None:
            self._conn.execute(
                "INSERT INTO channels (profile_id, channel_id, name, handle, url,"
                " subs, video_count, niche, avatar_url, last_scan_at, platform)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    profile_id,
                    channel_id,
                    channel.get("name", ""),
                    channel.get("handle", ""),
                    channel.get("url", ""),
                    channel.get("subs"),
                    video_count,
                    niche,
                    avatar_url,
                    ts,
                    platform,
                ),
            )
            self._conn.commit()
            return True
        self._conn.execute(
            "UPDATE channels SET name = ?, handle = ?, url = ?, subs = ?,"
            " video_count = ?, niche = ?, avatar_url = ?, last_scan_at = ? WHERE id = ?",
            (
                channel.get("name", ""),
                channel.get("handle", ""),
                channel.get("url", ""),
                channel.get("subs"),
                video_count if video_count is not None else existing["video_count"],
                niche or existing["niche"],
                avatar_url or existing["avatar_url"],
                ts,
                existing["id"],
            ),
        )
        self._conn.commit()
        return False

    # ------------------------------------------------------------------ #
    # Ảnh chụp số liệu kênh theo ngày (V3.4) — nền báo cáo/xu hướng
    # ------------------------------------------------------------------ #
    def record_channel_snapshot(self, profile_id: int, channel: dict) -> None:
        """Ghi/cập nhật snapshot của kênh cho NGÀY HÔM NAY (mỗi kênh một
        dòng mỗi ngày — quét nhiều lần trong ngày thì cập nhật dòng đó).
        Chỉ ghi khi có ít nhất subs hoặc số video."""
        subs = channel.get("subs")
        video_count = channel.get("video_count")
        if subs is None and video_count is None:
            return
        day = datetime.now().astimezone().date().isoformat()
        self._conn.execute(
            "INSERT INTO channel_snapshots (profile_id, channel_id, day,"
            " subs, video_count, captured_at) VALUES (?, ?, ?, ?, ?, ?)"
            " ON CONFLICT(profile_id, channel_id, day) DO UPDATE SET"
            " subs = COALESCE(excluded.subs, channel_snapshots.subs),"
            " video_count = COALESCE(excluded.video_count,"
            " channel_snapshots.video_count),"
            " captured_at = excluded.captured_at",
            (
                profile_id,
                (channel.get("channel_id") or "").strip(),
                day,
                subs,
                video_count,
                now_iso(),
            ),
        )
        self._conn.commit()

    def list_channel_snapshots(
        self, profile_id: int, channel_id: str, limit: int = 60
    ) -> list[dict]:
        """Lịch sử snapshot của một kênh, MỚI NHẤT trước."""
        rows = self._conn.execute(
            "SELECT * FROM channel_snapshots WHERE profile_id = ?"
            " AND channel_id = ? ORDER BY day DESC LIMIT ?",
            (profile_id, channel_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def channel_growth(self, profile_id: int, channel_id: str) -> dict:
        """Tăng trưởng của một kênh từ snapshots: Δsubs/Δvideo so với
        hôm qua (ngày có dữ liệu gần nhất trước hôm nay) và so với ~7
        ngày trước; kèm chuỗi subs gần nhất (cũ -> mới) để vẽ xu hướng.
        Thiếu dữ liệu thì các Δ là None (báo cáo nói rõ 'chưa đủ dữ
        liệu' thay vì bịa số)."""
        snapshots = self.list_channel_snapshots(profile_id, channel_id, limit=60)
        result = {
            "snapshots": snapshots,
            "subs_delta_1d": None,
            "subs_delta_7d": None,
            "videos_delta_7d": None,
            "series": [],
        }
        if not snapshots:
            return result
        latest = snapshots[0]
        result["series"] = [
            s["subs"] for s in reversed(snapshots) if s["subs"] is not None
        ]

        def _delta(field, min_gap_days, max_gap_days=None):
            for snap in snapshots[1:]:
                try:
                    gap = (
                        datetime.fromisoformat(latest["day"]).date()
                        - datetime.fromisoformat(snap["day"]).date()
                    ).days
                except ValueError:
                    continue
                if gap < min_gap_days:
                    continue
                if max_gap_days is not None and gap > max_gap_days:
                    break
                if snap[field] is None or latest[field] is None:
                    return None
                return latest[field] - snap[field]
            return None

        result["subs_delta_1d"] = _delta("subs", 1, 3)
        result["subs_delta_7d"] = _delta("subs", 4, 14)
        result["videos_delta_7d"] = _delta("video_count", 4, 14)
        return result

    def list_channels(self, profile_id: int) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM channels WHERE profile_id = ? ORDER BY name COLLATE NOCASE",
            (profile_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    # ------------------------------------------------------------------ #
    # Nhật ký
    # ------------------------------------------------------------------ #
    def append_journal(self, message: str, profile_id: int | None = None) -> dict:
        cur = self._conn.execute(
            "INSERT INTO journal (profile_id, ts, message) VALUES (?, ?, ?)",
            (profile_id, now_iso(), message),
        )
        self._conn.commit()
        row = self._conn.execute("SELECT * FROM journal WHERE id = ?", (cur.lastrowid,)).fetchone()
        return dict(row)

    def list_journal(self, profile_id: int | None = None, limit: int = 300) -> list[dict]:
        """Đọc nhật ký theo thứ tự thời gian tăng dần. Nếu có profile_id:
        lấy dòng của hồ sơ đó cộng các dòng toàn cục (profile_id IS NULL)."""
        if profile_id is None:
            rows = self._conn.execute(
                "SELECT * FROM journal ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM journal WHERE profile_id = ? OR profile_id IS NULL"
                " ORDER BY id DESC LIMIT ?",
                (profile_id, limit),
            ).fetchall()
        return [dict(r) for r in reversed(rows)]

    # ------------------------------------------------------------------ #
    # Lệnh công việc (V3) — bảng dùng chung cho UI, automation và Agent API
    # ------------------------------------------------------------------ #
    @staticmethod
    def new_command_id() -> str:
        return uuid.uuid4().hex[:12]

    def create_command(
        self,
        type: str,
        source: str = "ui",
        profile_id: int | None = None,
        profile_slug: str | None = None,
        channel_id: str = "",
        instruction: str = "",
        payload: dict | None = None,
        status: str = "queued",
        scheduled_at: str | None = None,
        agent_id: int | None = None,
        idempotency_key: str | None = None,
        depends_on: str | None = None,
        due_at: str | None = None,
    ) -> dict:
        """Tạo lệnh mới: MỌI lệnh đều vào 'queued' (Đ5). Lệnh app tự
        chạy được do CommandRunner/worker nhận từ 'queued'; lệnh chờ
        Muse do dispatcher xét điều kiện dữ liệu rồi đẩy lên
        'waiting_muse' cho Muse claim — nơi tạo KHÔNG truyền thẳng
        'waiting_muse' nữa.

        V4.0: ``idempotency_key`` khác rỗng mà đã có lệnh mang key đó →
        trả NGAY lệnh cũ (kèm cờ 'deduplicated'=True trong dict trả về,
        không lưu xuống DB) thay vì tạo trùng; ``depends_on`` ghi id lệnh
        phải 'done' trước (dispatcher H2 dùng khi xét sẵn sàng)."""
        if type not in COMMAND_TYPES:
            raise ValueError(f"Loại lệnh không hợp lệ: {type}")
        if status not in COMMAND_STATUSES:
            raise ValueError(f"Trạng thái lệnh không hợp lệ: {status}")
        key = (idempotency_key or "").strip() or None
        if key is not None:
            existing = self.find_command_by_idempotency_key(key)
            if existing is not None:
                existing["deduplicated"] = True
                return existing
        # V3.7: lệnh chờ Muse mà chưa ghi danh người làm → tự gắn Muse
        # ĐANG PHỤ TRÁCH hồ sơ đích, để lệnh luôn chạy đúng tài khoản Muse
        # quản lý mail/kênh đó (nơi tạo không cần tự tra phân công).
        if agent_id is None and profile_id is not None and type in CLAUDE_COMMAND_TYPES:
            owner = self.agent_for_profile(profile_id)
            if owner is not None:
                agent_id = owner["id"]
        ts = now_iso()
        command_id = self.new_command_id()
        # V6.1: mọi việc có HẠN CHÓT — không truyền thì hạn mặc định
        # theo loại, tính từ giờ hẹn (nếu có) hoặc từ lúc tạo.
        if not due_at:
            base = _parse_iso(scheduled_at) if scheduled_at else None
            if base is not None and base.tzinfo is None:
                base = base.astimezone()
            due_at = self.default_due_at(type, base)
        try:
            self._conn.execute(
                "INSERT INTO commands (id, source, type, profile_id, profile_slug,"
                " channel_id, instruction, payload, status, scheduled_at,"
                " agent_id, idempotency_key, depends_on, due_at, created_at, updated_at)"
                " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    command_id,
                    source,
                    type,
                    profile_id,
                    profile_slug,
                    channel_id or "",
                    instruction or "",
                    json.dumps(payload or {}, ensure_ascii=False),
                    status,
                    scheduled_at,
                    agent_id,
                    key,
                    (depends_on or None),
                    due_at,
                    ts,
                    ts,
                ),
            )
        except sqlite3.IntegrityError:
            # Hai nơi tạo chạy đua cùng một idempotency_key: chỉ số UNIQUE
            # một phần chặn ở tầng DB — thua cuộc thì trả lệnh đã thắng.
            self._conn.rollback()
            if key is not None:
                existing = self.find_command_by_idempotency_key(key)
                if existing is not None:
                    existing["deduplicated"] = True
                    return existing
            raise
        self._conn.commit()
        return self.get_command(command_id)

    def find_command_by_idempotency_key(self, key: str) -> dict | None:
        """Lệnh đang mang idempotency_key này (V4.0 — chống tạo trùng)."""
        key = (key or "").strip()
        if not key:
            return None
        row = self._conn.execute(
            "SELECT * FROM commands WHERE idempotency_key = ?", (key,)
        ).fetchone()
        return _command_row(row) if row else None

    @staticmethod
    def default_idempotency_key(
        source: str, type: str, profile_key, payload: dict | None,
        window_minutes: int = 10, now: datetime | None = None,
        instruction: str = "", channel_id: str = "",
        agent_id: int | None = None, scheduled_at: str | None = None,
        depends_on: str | None = None,
    ) -> str:
        """Khoá chống trùng MẶC ĐỊNH (V4.0): hash của TOÀN BỘ yêu cầu
        đã chuẩn hoá theo cửa sổ thời gian — cùng một yêu cầu bấm/gửi
        lại trong cửa sổ là MỘT lệnh, qua cửa sổ là lệnh mới.

        V4.2 (O-02): khoá phải gồm cả instruction, channel_id, agent
        nhận lệnh, scheduled_at và depends_on — bản cũ chỉ lẫn
        type + hồ sơ + payload nên hai yêu cầu API khác nội dung/kênh
        nhưng cùng payload trong 10 phút bị coi là một, lệnh sau biến
        mất lặng lẽ. Các tham số ngữ cảnh là keyword có mặc định để
        nơi gọi cũ (4 tham số vị trí) vẫn chạy."""
        import hashlib

        now = now or datetime.now().astimezone()
        bucket = int(now.timestamp()) // max(1, int(window_minutes) * 60)
        canonical = json.dumps(
            {
                "payload": payload or {},
                "instruction": instruction or "",
                "channel_id": channel_id or "",
                "agent_id": agent_id,
                "scheduled_at": scheduled_at or "",
                "depends_on": depends_on or "",
            },
            ensure_ascii=False, sort_keys=True, default=str,
        )
        raw = f"{source}|{type}|{profile_key or ''}|{canonical}|{bucket}"
        return "auto:" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:32]

    def get_command(self, command_id: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM commands WHERE id = ?", (command_id,)
        ).fetchone()
        return _command_row(row) if row else None

    def list_commands(
        self,
        source: str | None = None,
        status: str | None = None,
        profile_id: int | None = None,
        limit: int = 200,
        offset: int = 0,
    ) -> list[dict]:
        """Danh sách lệnh, MỚI NHẤT trước; lọc tuỳ chọn theo nguồn/
        trạng thái/hồ sơ. ``offset`` (V4.2 — O-13) cho phép dispatcher/
        sweeper phân trang công bằng qua backlog lớn thay vì chỉ xét
        200 lệnh mới nhất rồi để lệnh cũ chết đói."""
        clauses, params = [], []
        if source is not None:
            clauses.append("source = ?")
            params.append(source)
        if status is not None:
            clauses.append("status = ?")
            params.append(status)
        if profile_id is not None:
            clauses.append("profile_id = ?")
            params.append(profile_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        rows = self._conn.execute(
            f"SELECT *, rowid AS _seq FROM commands {where}"
            " ORDER BY created_at DESC, rowid DESC LIMIT ? OFFSET ?",
            (*params, limit, max(0, int(offset or 0))),
        ).fetchall()
        return [_command_row(r) for r in rows]

    # ------------------------------------------------------------------ #
    # V4.2 — Số liệu tổng theo trạng thái (O-07): banner/header KHÔNG
    # đếm từ cache đã cắt limit nữa; aggregate SQL luôn đúng toàn cục.
    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    # V6.1 — Hạn chót + bảng giám sát + sự cố Văn phòng
    # ------------------------------------------------------------------ #
    OPEN_STATUSES = ("queued", "waiting_muse", "running", "needs_user", "interrupted")

    def set_command_due(self, command_id: str, due_at: str | None) -> dict | None:
        self._conn.execute(
            "UPDATE commands SET due_at = ?, updated_at = ? WHERE id = ?",
            (due_at, now_iso(), command_id),
        )
        self._conn.commit()
        self.update_command_payload_flags(command_id, clear_keys=("deadline_alerted",))
        return self.get_command(command_id)

    def extend_command_due(self, command_id: str, minutes: int) -> dict | None:
        """Gia hạn: hạn mới = max(hạn cũ, bây giờ) + minutes."""
        command = self.get_command(command_id)
        if command is None:
            return None
        now = datetime.now().astimezone()
        base = _parse_iso(command.get("due_at")) or now
        if base < now:
            base = now
        return self.set_command_due(
            command_id,
            (base + timedelta(minutes=int(minutes))).isoformat(timespec="seconds"),
        )

    def backfill_due_dates(self) -> int:
        """Gán hạn mặc định cho lệnh ĐANG MỞ chưa có hạn (dữ liệu từ
        trước V6.1) — tính từ lúc tạo. Trả số lệnh đã gán."""
        placeholders = ", ".join("?" for _ in self.OPEN_STATUSES)
        rows = self._conn.execute(
            f"SELECT id, type, created_at, scheduled_at FROM commands"
            f" WHERE due_at IS NULL AND status IN ({placeholders})",
            self.OPEN_STATUSES,
        ).fetchall()
        updated = 0
        for row in rows:
            base = _parse_iso(row["scheduled_at"]) or _parse_iso(row["created_at"])
            due = self.default_due_at(row["type"], base)
            if due:
                self._conn.execute(
                    "UPDATE commands SET due_at = ? WHERE id = ?", (due, row["id"])
                )
                updated += 1
        if updated:
            self._conn.commit()
        return updated

    def list_open_commands(self, limit: int = 500) -> list[dict]:
        """Mọi lệnh còn mở (chưa xong/thất bại), hạn gần trước."""
        placeholders = ", ".join("?" for _ in self.OPEN_STATUSES)
        rows = self._conn.execute(
            f"SELECT *, rowid AS _seq FROM commands WHERE status IN ({placeholders})"
            " ORDER BY (due_at IS NULL), due_at, created_at LIMIT ?",
            (*self.OPEN_STATUSES, int(limit)),
        ).fetchall()
        return [_command_row(r) for r in rows]

    def list_recent_failed(self, hours: int = 24, limit: int = 30) -> list[dict]:
        since = (datetime.now().astimezone() - timedelta(hours=hours)).isoformat(
            timespec="seconds"
        )
        rows = self._conn.execute(
            "SELECT *, rowid AS _seq FROM commands WHERE status = 'failed'"
            " AND COALESCE(finished_at, updated_at) >= ?"
            " ORDER BY COALESCE(finished_at, updated_at) DESC LIMIT ?",
            (since, int(limit)),
        ).fetchall()
        return [_command_row(r) for r in rows]

    def deadline_stats(self, agent_id: int | None, since_iso: str) -> dict:
        """Đúng hạn / trễ hạn của lệnh ĐÃ XONG từ mốc since (theo agent
        hoặc toàn đội khi agent_id None)."""
        clauses = ["status = 'done'", "finished_at >= ?", "due_at IS NOT NULL",
                   "type <> 'review'"]
        params: list = [since_iso]
        if agent_id is not None:
            clauses.append("agent_id = ?")
            params.append(int(agent_id))
        rows = self._conn.execute(
            f"SELECT finished_at, due_at FROM commands WHERE {' AND '.join(clauses)}",
            params,
        ).fetchall()
        on_time = late = 0
        for row in rows:
            finished = _parse_iso(row["finished_at"])
            due = _parse_iso(row["due_at"])
            if finished is None or due is None:
                continue
            if finished <= due:
                on_time += 1
            else:
                late += 1
        return {"on_time": on_time, "late": late}

    def command_status_counts(self) -> dict[str, int]:
        """Đếm lệnh theo từng trạng thái bằng đúng một câu aggregate."""
        rows = self._conn.execute(
            "SELECT status, COUNT(*) FROM commands GROUP BY status"
        ).fetchall()
        return {str(r[0]): int(r[1]) for r in rows}

    def count_done_today(self) -> int:
        """Số lệnh 'done' có finished_at trong NGÀY HÔM NAY (giờ địa
        phương của máy chạy app — finished_at lưu ISO kèm offset nên
        date() của SQLite đọc đúng ngày)."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM commands WHERE status = 'done'"
            " AND date(finished_at) = date('now', 'localtime')"
        ).fetchone()
        return int(row[0])

    def count_unassigned_claude_commands(self) -> int:
        """Số lệnh Muse đang 'queued' mà hiện KHÔNG có Muse còn
        hiệu lực nào phụ trách (O-04/O-07): suy từ dữ kiện HIỆN TẠI —
        hồ sơ chưa có phân công cho agent chưa thu hồi VÀ lệnh cũng
        không ghi danh một agent chưa thu hồi — thay vì cờ lịch sử
        dispatch_warned_no_owner trong payload (cờ đó có thể cũ)."""
        placeholders = ", ".join("?" for _ in CLAUDE_COMMAND_TYPES)
        row = self._conn.execute(
            f"SELECT COUNT(*) FROM commands c"
            f" WHERE c.status = 'queued' AND c.type IN ({placeholders})"
            " AND NOT EXISTS (SELECT 1 FROM agent_assignments a"
            "   JOIN agents ag ON ag.id = a.agent_id"
            "   WHERE a.profile_id = c.profile_id AND ag.revoked = 0)"
            " AND NOT EXISTS (SELECT 1 FROM agents ag2"
            "   WHERE ag2.id = c.agent_id AND ag2.revoked = 0)",
            tuple(CLAUDE_COMMAND_TYPES),
        ).fetchone()
        return int(row[0])

    def channel_counts_by_profile(self) -> dict[int, int]:
        """Số kênh theo từng hồ sơ trong MỘT câu aggregate (Văn phòng
        dùng cho panel chi tiết — thay vòng lặp list_channels từng hồ
        sơ vốn nuốt lỗi thành 0 kênh)."""
        rows = self._conn.execute(
            "SELECT profile_id, COUNT(*) FROM channels GROUP BY profile_id"
        ).fetchall()
        return {int(r[0]): int(r[1]) for r in rows}

    def running_claude_profile_ids(self) -> set[int]:
        """Hồ sơ đang có lệnh Muse 'running' (dispatcher dùng làm
        tập bận — một câu SQL thay vì nạp 200 lệnh rồi lọc Python,
        O-13)."""
        placeholders = ", ".join("?" for _ in CLAUDE_COMMAND_TYPES)
        rows = self._conn.execute(
            f"SELECT DISTINCT profile_id FROM commands"
            f" WHERE status = 'running' AND type IN ({placeholders})"
            # V6.0: việc KIỂM TRA đang chạy KHÔNG làm hồ sơ "bận" —
            # giám sát diễn ra song song, không chặn việc của hồ sơ.
            " AND type <> 'review'"
            " AND profile_id IS NOT NULL",
            tuple(CLAUDE_COMMAND_TYPES),
        ).fetchall()
        return {int(r[0]) for r in rows}

    def list_expired_lease_commands(self, now_text: str) -> list[dict]:
        """Lệnh Muse 'running' có lease_expires_at <= mốc truyền vào
        (sweeper lọc thẳng trong SQL — O-13; mốc ISO cùng định dạng/
        offset với now_iso() nên so chuỗi là so thời gian). Nơi gọi
        vẫn xác minh lại bằng datetime đã parse."""
        placeholders = ", ".join("?" for _ in CLAUDE_COMMAND_TYPES)
        rows = self._conn.execute(
            f"SELECT * FROM commands WHERE status = 'running'"
            f" AND type IN ({placeholders})"
            " AND lease_expires_at IS NOT NULL AND lease_expires_at <= ?"
            " ORDER BY lease_expires_at ASC",
            (*CLAUDE_COMMAND_TYPES, now_text),
        ).fetchall()
        return [_command_row(r) for r in rows]

    def claim_command(self, command_id: str) -> bool:
        """Nhận lệnh để chạy: chuyển 'queued' → 'running' một cách nguyên tử.
        Trả về False nếu lệnh không còn ở trạng thái queued (đã bị nơi khác nhận)."""
        ts = now_iso()
        cur = self._conn.execute(
            "UPDATE commands SET status = 'running', started_at = COALESCE(started_at, ?),"
            " updated_at = ? WHERE id = ? AND status = 'queued'",
            (ts, ts, command_id),
        )
        self._conn.commit()
        return cur.rowcount == 1

    def finish_command(
        self,
        command_id: str,
        status: str,
        result: str | None = None,
        result_json: dict | None = None,
        error: str | None = None,
    ) -> dict | None:
        """Chốt lệnh ở trạng thái cuối (done/failed) kèm kết quả và mốc kết thúc."""
        if status not in COMMAND_STATUSES:
            raise ValueError(f"Trạng thái lệnh không hợp lệ: {status}")
        ts = now_iso()
        existing = self.get_command(command_id)
        progress = 100 if status == "done" else ((existing or {}).get("progress") or 0)
        self._conn.execute(
            "UPDATE commands SET status = ?, result = ?,"
            " result_json = ?, error = ?, progress = ?, finished_at = ?,"
            " lease_agent_id = NULL, lease_expires_at = NULL,"
            " updated_at = ? WHERE id = ?",
            (
                status,
                result,
                json.dumps(result_json, ensure_ascii=False) if result_json is not None else None,
                error,
                progress,
                ts,
                ts,
                command_id,
            ),
        )
        self._conn.commit()
        row = self.get_command(command_id)
        if status == "failed":
            # V4.5: ghi nhận thất bại cho cơ chế TỰ CHẠY LẠI (lên
            # lịch sau 30s / ghi lý do chặn vào payload) — xem
            # app.auto_retry. Mọi đường chốt 'failed' đều qua đây
            # (executor, agent_server, dispatcher, huỷ lệnh…) nên
            # ghi nhận tại một chỗ này là đủ.
            self._note_failure_for_auto_retry(row)
            row = self.get_command(command_id)
        if status in ("done", "failed"):
            # V6.0: sinh VIỆC KIỂM TRA giám sát chéo tại cùng điểm
            # nghẽn này (mọi đường chốt lệnh đều qua finish_command)
            # — xem app.supervision. Kênh phụ, nuốt lỗi tại đó.
            self._note_finish_for_supervision(row)
            row = self.get_command(command_id)
        return row

    def _note_finish_for_supervision(self, command: dict | None) -> None:
        """V6.0: báo cho tầng giám sát chéo một lệnh vừa chốt
        done/failed (nó tự quyết có sinh việc kiểm tra hay không theo
        ma trận/cài đặt). Lỗi ở tầng phụ KHÔNG được làm hỏng thao tác
        chốt lệnh nên nuốt tại đây — cùng kỷ luật _note_failure..."""
        if not command or command.get("type") == "review":
            return
        try:
            from . import supervision

            supervision.on_command_finished(self, command)
        except Exception:
            pass

    def _note_failure_for_auto_retry(self, command: dict | None) -> None:
        """Lên lịch tự chạy lại cho một lệnh VỪA chốt 'failed' (hoặc
        ghi lý do chặn nếu vướng điều kiện). Lỗi ghi nhận KHÔNG được
        làm hỏng thao tác chốt lệnh nên nuốt tại đây."""
        if not command or command.get("status") != "failed":
            return
        try:
            from . import auto_retry

            updates = auto_retry.schedule_updates(
                command, datetime.now().astimezone()
            )
            self.update_command_payload_flags(command["id"], set_flags=updates)
        except Exception:
            pass

    def update_command(
        self,
        command_id: str,
        status: str | None = None,
        result: str | None = None,
        error: str | None = None,
    ) -> dict | None:
        """Cập nhật mềm (Muse báo tiến độ qua API...): chỉ đổi các trường
        được truyền; tự đóng dấu started_at/finished_at theo trạng thái."""
        if status is not None and status not in COMMAND_STATUSES:
            raise ValueError(f"Trạng thái lệnh không hợp lệ: {status}")
        existing = self.get_command(command_id)
        if existing is None:
            return None
        ts = now_iso()
        started_at = existing["started_at"]
        finished_at = existing["finished_at"]
        if status == "running" and not started_at:
            started_at = ts
        if status in ("done", "failed"):
            finished_at = ts
        self._conn.execute(
            "UPDATE commands SET status = ?, result = ?, error = ?,"
            " started_at = ?, finished_at = ?, updated_at = ? WHERE id = ?",
            (
                status if status is not None else existing["status"],
                result if result is not None else existing["result"],
                error if error is not None else existing["error"],
                started_at,
                finished_at,
                ts,
                command_id,
            ),
        )
        self._conn.commit()
        return self.get_command(command_id)

    def clear_command_schedule(self, command_id: str) -> dict | None:
        """Xoá hẹn giờ chạy của một lệnh (V4.1.1): nút "▶ Chạy ngay"
        nghĩa là chạy NGAY — dispatcher không còn được giữ lệnh vì
        scheduled_at tương lai nữa. Lệnh không có hẹn giờ thì giữ
        nguyên (không chạm DB)."""
        existing = self.get_command(command_id)
        if existing is None:
            return None
        if existing.get("scheduled_at"):
            self._conn.execute(
                "UPDATE commands SET scheduled_at = NULL, updated_at = ?"
                " WHERE id = ?",
                (now_iso(), command_id),
            )
            self._conn.commit()
            return self.get_command(command_id)
        return existing

    # ------------------------------------------------------------------ #
    # V4.0 — Claim + Lease cho lệnh chờ Muse (H1)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _lease_deadline(lease_seconds: int, now: datetime | None = None) -> str:
        now = now or datetime.now().astimezone()
        seconds = max(10, int(lease_seconds or 120))
        return (now + timedelta(seconds=seconds)).isoformat(timespec="seconds")

    def claim_claude_command(
        self, command_id: str, agent_id: int | None, lease_seconds: int = 120,
    ) -> dict | None:
        """NHẬN một lệnh chờ Muse — NGUYÊN TỬ bằng đúng MỘT câu UPDATE
        có điều kiện (không đọc–sửa–ghi): chỉ thắng khi lệnh đang
        'waiting_muse'. Thắng → 'running' + ghi chủ lease + hạn lease +
        đóng dấu started_at; trả hàng lệnh sau claim. Thua (đã có người
        giữ / sai trạng thái) → None, nơi gọi tự phân biệt bằng cách đọc
        lại lệnh hiện tại (409/403 ở tầng API)."""
        ts = now_iso()
        cur = self._conn.execute(
            "UPDATE commands SET status = 'running',"
            " lease_agent_id = ?, lease_expires_at = ?,"
            " agent_id = COALESCE(?, agent_id),"
            " started_at = COALESCE(started_at, ?), updated_at = ?"
            " WHERE id = ? AND status = 'waiting_muse'",
            (
                agent_id,
                self._lease_deadline(lease_seconds),
                agent_id,
                ts,
                ts,
                command_id,
            ),
        )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        return self.get_command(command_id)

    def touch_command_lease(
        self, command_id: str, agent_id: int | None, lease_seconds: int = 120,
    ) -> dict | None:
        """Gia hạn lease cho CHÍNH chủ lease (agent_id khớp lease_agent_id
        hiện tại; admin gọi với agent_id=None thì gia hạn giữ nguyên chủ).
        Không phải chủ / lệnh không còn running → None."""
        if agent_id is not None:
            cur = self._conn.execute(
                "UPDATE commands SET lease_expires_at = ?, updated_at = ?"
                " WHERE id = ? AND status = 'running' AND lease_agent_id = ?",
                (self._lease_deadline(lease_seconds), now_iso(), command_id, agent_id),
            )
        else:
            cur = self._conn.execute(
                "UPDATE commands SET lease_expires_at = ?, updated_at = ?"
                " WHERE id = ? AND status = 'running'",
                (self._lease_deadline(lease_seconds), now_iso(), command_id),
            )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        return self.get_command(command_id)

    def release_claude_command(
        self, command_id: str, agent_id: int | None,
    ) -> dict | None:
        """Chủ lease TRẢ lệnh sớm (không làm được/bận): về 'waiting_muse',
        xoá lease, attempts GIỮ NGUYÊN. Chỉ chủ lease (hoặc admin với
        agent_id=None) trả được; không khớp → None."""
        condition = "AND lease_agent_id = ?" if agent_id is not None else ""
        params: tuple = (now_iso(), command_id)
        if agent_id is not None:
            params = (now_iso(), command_id, agent_id)
        cur = self._conn.execute(
            "UPDATE commands SET status = 'waiting_muse',"
            " lease_agent_id = NULL, lease_expires_at = NULL, updated_at = ?"
            f" WHERE id = ? AND status = 'running' {condition}",
            params,
        )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        return self.get_command(command_id)

    def set_command_needs_user(
        self, command_id: str, message: str = "",
    ) -> dict | None:
        """Đặt lệnh sang 'needs_user' (Chờ người — H3): nhả lease, ghi
        việc người dùng phải làm vào result/error + step. attempts KHÔNG
        tăng (dừng vì cần người, không phải lỗi của Muse). Tầng API đã
        kiểm tra chủ lease/admin trước khi gọi."""
        existing = self.get_command(command_id)
        if existing is None or existing["status"] in ("done", "failed"):
            return None
        text = (message or "").strip()
        ts = now_iso()
        self._conn.execute(
            "UPDATE commands SET status = 'needs_user',"
            " lease_agent_id = NULL, lease_expires_at = NULL,"
            " result = ?, error = NULL, step = ?, updated_at = ? WHERE id = ?",
            (text or existing.get("result"), (text[:300] or existing.get("step") or ""), ts, command_id),
        )
        self._conn.commit()
        # V4.5: lệnh ĐÃ TỪNG dừng vì cần người (đăng nhập/OTP/
        # CAPTCHA) thì về sau KHÔNG tự chạy lại khi thất bại — đặt
        # cờ chặn vào payload (app.auto_retry đọc cờ này).
        try:
            from . import auto_retry

            self.update_command_payload_flags(
                command_id,
                set_flags={auto_retry.KEY_HIT_NEEDS_USER: True},
            )
        except Exception:
            pass
        # V4.6: báo vào luồng CHAT của Muse phụ trách (đúng một
        # tin hệ thống cho mỗi lần dừng) — người dùng thấy ngay
        # trong app và trả lời tại đó để Muse chạy tiếp.
        try:
            self._note_needs_user_in_chat(existing, text)
        except Exception:
            pass
        return self.get_command(command_id)

    def resume_command(self, command_id: str) -> dict | None:
        """Nút "Đã xử lý — chạy tiếp" (H3): lệnh 'needs_user' → 'queued'
        để dispatcher xét lại từ đầu (preflight), xoá dấu vết lần dừng.
        Lệnh khác trạng thái → None."""
        existing = self.get_command(command_id)
        if existing is None or existing["status"] != "needs_user":
            return None
        ts = now_iso()
        # V4.2 (O-04): vào vòng đời MỚI thì dọn cờ payload của vòng
        # đời cũ (đã cảnh báo chưa chủ / đã cảnh báo chờ lâu…).
        # V4.5: người dùng đã xử lý tay → dọn cả cụm tự-chạy-lại +
        # cờ từng-dừng-needs_user: lệnh bắt đầu vòng đời sạch.
        payload = dict(existing.get("payload") or {})
        for flag in self.INTERNAL_PAYLOAD_FLAGS:
            payload.pop(flag, None)
        self._clear_auto_retry_payload(payload)
        self._conn.execute(
            "UPDATE commands SET status = 'queued', result = NULL,"
            " error = NULL, progress = 0, step = '', lease_agent_id = NULL,"
            " lease_expires_at = NULL, payload = ?, updated_at = ?"
            " WHERE id = ?",
            (json.dumps(payload, ensure_ascii=False), ts, command_id),
        )
        self._conn.commit()
        return self.get_command(command_id)

    # V4.2 (O-04): cờ vận hành nội bộ trong payload của lệnh — vòng
    # đời do Store quản tại một chỗ: đặt khi điều kiện xuất hiện, DỌN
    # khi điều kiện hết (có chủ / được promote / resume / requeue).
    # Dispatcher/sweeper KHÔNG tự đọc–sửa–ghi payload qua _conn nữa.
    INTERNAL_PAYLOAD_FLAGS = (
        "dispatch_warned_no_owner",
        "preflight_errors",
        "warned_no_agent",
    )

    def update_command_payload_flags(
        self,
        command_id: str,
        set_flags: dict | None = None,
        clear_keys: tuple[str, ...] | list[str] = (),
    ) -> dict | None:
        """Đặt/xoá cờ trong payload của một lệnh tại TẦNG STORE (đọc–
        sửa–ghi tập trung, chỉ ghi khi thật sự thay đổi). Trả hàng lệnh
        hiện tại; None nếu không thấy lệnh."""
        existing = self.get_command(command_id)
        if existing is None:
            return None
        payload = dict(existing.get("payload") or {})
        changed = False
        for key in clear_keys or ():
            if key in payload:
                del payload[key]
                changed = True
        for key, value in (set_flags or {}).items():
            if payload.get(key) != value:
                payload[key] = value
                changed = True
        if changed:
            self._conn.execute(
                "UPDATE commands SET payload = ?, updated_at = ? WHERE id = ?",
                (json.dumps(payload, ensure_ascii=False), now_iso(), command_id),
            )
            self._conn.commit()
            existing = self.get_command(command_id)
        return existing

    def promote_command_to_waiting(self, command_id: str) -> dict | None:
        """Dispatcher (H2): lệnh chờ Muse đã đủ điều kiện → 'waiting_muse'
        (sẵn sàng cho Muse claim). Một UPDATE có điều kiện như claim.

        V4.2 (O-03): promote đặt LUÔN step hiện tại trong cùng UPDATE
        nguyên tử — bản cũ chỉ đổi status nên lệnh đã 'waiting_muse'
        vẫn hiện lý do bị giữ của giai đoạn trước ("Chưa có Muse phụ
        trách…"). Đồng thời dọn các cờ payload của vòng đời bị giữ."""
        cur = self._conn.execute(
            "UPDATE commands SET status = 'waiting_muse',"
            " step = 'Đang chờ Muse nhận lệnh…', updated_at = ?"
            " WHERE id = ? AND status = 'queued'",
            (now_iso(), command_id),
        )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        self.update_command_payload_flags(
            command_id, clear_keys=self.INTERNAL_PAYLOAD_FLAGS
        )
        return self.get_command(command_id)

    def update_command_progress(
        self,
        command_id: str,
        progress: int | None = None,
        step: str | None = None,
        agent_id: int | None = None,
        lease_seconds: int = 120,
    ) -> dict | None:
        """Báo tiến độ một công việc (V3.2): Muse báo qua Agent API,
        bộ chạy lệnh tại chỗ tự cập nhật theo giai đoạn. progress bị kẹp
        0–100; báo lần đầu (progress > 0) trên lệnh đang chờ sẽ chuyển
        lệnh sang 'running' + đóng dấu started_at. None nếu không thấy lệnh.

        V4.0 (Đ1 — tương thích ngược): lần báo đầu tiên trên lệnh
        'waiting_muse' vẫn TỰ CLAIM như cũ nhưng nay CẤP LEASE luôn
        (ghi lease_agent_id = agent báo cáo + hạn lease); các lần báo
        sau của chính chủ lease tự gia hạn lease qua touch_command_lease.
        agent_id=None (admin/bộ chạy tại chỗ) thì không đụng lease.

        V4.2 (O-05): lệnh còn 'queued' KHÔNG được tự claim bằng
        progress nữa — progress > 0 trên lệnh queued bị BỎ QUA (giữ
        nguyên % và trạng thái; chỉ step vẫn được ghi để dispatcher
        ghi lý do chờ). Đường queued → running duy nhất là dispatcher
        promote → claim, để không ai đi vòng qua hẹn giờ/phụ thuộc/
        phân công/tuần tự theo hồ sơ. Tầng API còn trả 409 tường minh
        cho progress > 0 trên lệnh queued."""
        existing = self.get_command(command_id)
        if existing is None:
            return None
        ts = now_iso()
        new_progress = existing.get("progress") or 0
        if progress is not None and existing["status"] != "queued":
            new_progress = max(0, min(100, int(progress)))
        new_step = existing.get("step") or ""
        if step is not None:
            new_step = str(step)[:300]
        status = existing["status"]
        started_at = existing["started_at"]
        lease_agent_id = existing.get("lease_agent_id")
        lease_expires_at = existing.get("lease_expires_at")
        if new_progress > 0 and status == "waiting_muse":
            status = "running"
            started_at = started_at or ts
            if existing["type"] in CLAUDE_COMMAND_TYPES:
                # Tự claim kiểu cũ (Đ1) — từ V4.0 có lease đi kèm.
                if lease_agent_id is None and agent_id is not None:
                    lease_agent_id = agent_id
                lease_expires_at = self._lease_deadline(lease_seconds)
        self._conn.execute(
            "UPDATE commands SET progress = ?, step = ?, status = ?,"
            " started_at = ?, lease_agent_id = ?, lease_expires_at = ?,"
            " updated_at = ? WHERE id = ?",
            (
                new_progress, new_step, status, started_at,
                lease_agent_id, lease_expires_at, ts, command_id,
            ),
        )
        # V6.3: ghi LỊCH SỬ bước — chỉ khi chữ bước đổi (báo % lặp lại
        # cùng bước không sinh dòng mới), để bảng việc hiện đủ chuỗi bước.
        if step is not None and new_step and new_step != (existing.get("step") or ""):
            self._conn.execute(
                "INSERT INTO command_steps (command_id, at, progress, step, actor)"
                " VALUES (?, ?, ?, ?, ?)",
                (command_id, ts, new_progress, new_step,
                 f"agent:{agent_id}" if agent_id is not None else "app"),
            )
        self._conn.commit()
        if status == "running" and agent_id is not None:
            # Chủ lease báo tiếp → gia hạn (không-op nếu không phải chủ).
            self.touch_command_lease(command_id, agent_id, lease_seconds)
        return self.get_command(command_id)

    # ------------------------------------------------------------------ #
    # V6.3: lịch sử bước + quyết định của trưởng phòng
    # ------------------------------------------------------------------ #
    def list_command_steps(self, command_id: str, limit: int = 200) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM command_steps WHERE command_id = ? ORDER BY id LIMIT ?",
            (command_id, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def steps_for_commands(self, command_ids: list[str], per_command: int = 30) -> dict[str, list[dict]]:
        """{command_id: [bước cũ → mới]} cho nhiều lệnh một lượt (bảng việc)."""
        ids = [c for c in command_ids or [] if c]
        out: dict[str, list[dict]] = {c: [] for c in ids}
        for start in range(0, len(ids), 400):
            chunk = ids[start:start + 400]
            marks = ",".join("?" * len(chunk))
            rows = self._conn.execute(
                f"SELECT * FROM command_steps WHERE command_id IN ({marks}) ORDER BY id",
                chunk,
            ).fetchall()
            for row in rows:
                out.setdefault(row["command_id"], []).append(dict(row))
        for key, value in out.items():
            if len(value) > per_command:
                out[key] = value[-per_command:]
        return out

    def add_lead_decision(self, lead_id, issue_key: str, action: str, command_id=None,
                          agent_id=None, detail: str = "", outcome: str = "done") -> dict:
        ts = now_iso()
        cur = self._conn.execute(
            "INSERT INTO lead_decisions (at, lead_id, issue_key, action, command_id,"
            " agent_id, detail, outcome) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (ts, lead_id, issue_key or "", action, command_id, agent_id, detail[:500], outcome),
        )
        self._conn.commit()
        return dict(self._conn.execute(
            "SELECT * FROM lead_decisions WHERE id = ?", (cur.lastrowid,)
        ).fetchone())

    def list_lead_decisions(self, since_iso: str | None = None, limit: int = 200) -> list[dict]:
        if since_iso:
            rows = self._conn.execute(
                "SELECT * FROM lead_decisions WHERE at >= ? ORDER BY id DESC LIMIT ?",
                (since_iso, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM lead_decisions ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [dict(r) for r in rows]

    def last_lead_decision_for(self, issue_key: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM lead_decisions WHERE issue_key = ? ORDER BY id DESC LIMIT 1",
            (issue_key,),
        ).fetchone()
        return dict(row) if row else None

    def data_version(self) -> int:
        """PRAGMA data_version — đổi mỗi khi MỘT KẾT NỐI KHÁC ghi DB
        (cầu nối, bộ chạy nền...). Nền của làm mới realtime V6.3."""
        try:
            return int(self._conn.execute("PRAGMA data_version").fetchone()[0])
        except Exception:
            return 0

    def list_active_commands(self, limit: int = 20) -> list[dict]:
        """Các lệnh đang chờ/đang chạy (cho thẻ theo dõi tiến độ ở Tổng
        quan), lệnh cập nhật gần nhất trước."""
        rows = self._conn.execute(
            "SELECT * FROM commands WHERE status IN ('queued', 'running',"
            " 'waiting_muse', 'needs_user') ORDER BY updated_at DESC, rowid DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [_command_row(r) for r in rows]

    def delete_command(self, command_id: str) -> None:
        self._conn.execute("DELETE FROM commands WHERE id = ?", (command_id,))
        self._conn.commit()
        # V4.4: dọn file đính kèm của lệnh (data/command_files/<id>/ —
        # vd video giao cho lệnh studio_script) theo vòng đời lệnh:
        # xoá lệnh là xoá luôn file, không để rác đĩa. Lỗi dọn file
        # không được làm hỏng thao tác xoá lệnh.
        try:
            from . import config as _config

            files_dir = _config.command_files_dir(
                command_id, base=self.db_file.parent
            )
            shutil.rmtree(files_dir, ignore_errors=True)
        except Exception:
            pass

    def recover_interrupted_commands(self) -> int:
        """Khôi phục sau khi app thoát/sập giữa chừng (V3.1): mọi lệnh còn
        kẹt ở 'running' được đánh dấu 'interrupted' (KHÔNG tự chạy lại —
        người dùng bấm Thử lại trong panel Lệnh khi sẵn sàng).
        Trả về số lệnh đã đánh dấu."""
        ts = now_iso()
        # V4.0: lệnh đang có lease còn hạn thuộc về cơ chế lease/sweeper —
        # KHÔNG đánh dấu interrupted ở đây: app vừa mở lại, Muse giữ
        # lease có thể vẫn đang làm; sweeper sẽ thu hồi khi lease hết
        # hạn thật. Lệnh running không lease (bộ chạy tại chỗ) giữ
        # nguyên hành vi V3.1.
        cur = self._conn.execute(
            "UPDATE commands SET status = 'interrupted', finished_at = ?,"
            " updated_at = ? WHERE status = 'running'"
            " AND (lease_expires_at IS NULL OR lease_expires_at <= ?)",
            (ts, ts, ts),
        )
        self._conn.commit()
        return cur.rowcount

    def requeue_command(self, command_id: str) -> dict | None:
        """Xếp hàng lại một lệnh đã 'failed'/'interrupted' (nút Thử lại):
        lệnh app-tự-làm được về 'queued' (CommandRunner sẽ nhận); lệnh chờ
        Muse cũng về 'queued' từ V4.0 (Đ5 — dispatcher xét lại điều
        kiện rồi mới đẩy lên 'waiting_muse'). Xoá dấu vết lần chạy trước
        (kể cả lease cũ)."""
        existing = self.get_command(command_id)
        if existing is None or existing["status"] not in ("failed", "interrupted"):
            return None
        status = "queued"
        ts = now_iso()
        # V4.2 (O-04): thử lại = vòng đời mới — dọn cờ payload cũ.
        # V4.5: thử lại TAY cũng dọn cụm tự-chạy-lại (bộ đếm về 0,
        # bỏ chặn needs_user cũ) — người dùng đã chủ động ra tay.
        payload = dict(existing.get("payload") or {})
        for flag in self.INTERNAL_PAYLOAD_FLAGS:
            payload.pop(flag, None)
        self._clear_auto_retry_payload(payload)
        self._conn.execute(
            "UPDATE commands SET status = ?, result = NULL, result_json = NULL,"
            " error = NULL, started_at = NULL, finished_at = NULL,"
            " attempts = 0, progress = 0, step = '', agent_id = NULL,"
            " lease_agent_id = NULL, lease_expires_at = NULL,"
            " payload = ?, updated_at = ? WHERE id = ?",
            (status, json.dumps(payload, ensure_ascii=False), ts, command_id),
        )
        self._conn.commit()
        return self.get_command(command_id)

    # ------------------------------------------------------------------ #
    # V4.5 — Tự chạy lại lệnh thất bại (app.auto_retry giữ luật thuần;
    # Store là nơi áp dụng DUY NHẤT: trạng thái nằm trong payload nên
    # sống sót qua khởi động lại app, không đổi schema)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _clear_auto_retry_payload(payload: dict) -> None:
        """Dọn cụm khoá tự-chạy-lại + cờ từng-dừng-needs_user khỏi
        một dict payload (tại chỗ) — dùng khi lệnh vào vòng đời mới
        do NGƯỜI DÙNG chủ động (Thử lại / Đã xử lý — chạy tiếp)."""
        from . import auto_retry

        for key in auto_retry.ALL_KEYS + (auto_retry.KEY_HIT_NEEDS_USER,):
            payload.pop(key, None)

    def cancel_auto_retry(self, command_id: str) -> dict | None:
        """Nút "Huỷ chạy lại": bỏ mốc hẹn tự chạy lại của một lệnh
        'failed' — lệnh giữ nguyên thất bại, không tự đứng dậy nữa
        (Thử lại tay vẫn dùng được)."""
        from . import auto_retry

        existing = self.get_command(command_id)
        if existing is None or existing["status"] != "failed":
            return None
        return self.update_command_payload_flags(
            command_id,
            set_flags={auto_retry.KEY_CANCELLED: True},
            clear_keys=[auto_retry.KEY_AT],
        )

    def auto_requeue_command(self, command_id: str) -> dict | None:
        """Tới hạn tự chạy lại: 'failed' → 'queued' bằng UPDATE CÓ
        ĐIỀU KIỆN (hai nhịp xử lý chạy đua nhau thì chỉ một nhịp
        thắng). Khác Thử lại tay: GIỮ agent_id + bộ đếm
        auto_retry_count (trần 3 lần phải đếm xuyên các lần chạy),
        chỉ xoá mốc hẹn + dấu vết lần chạy hỏng."""
        from . import auto_retry

        existing = self.get_command(command_id)
        if existing is None or existing["status"] != "failed":
            return None
        payload = dict(existing.get("payload") or {})
        count = int(payload.get(auto_retry.KEY_COUNT) or 0)
        payload.pop(auto_retry.KEY_AT, None)
        ts = now_iso()
        cur = self._conn.execute(
            "UPDATE commands SET status = 'queued', result = NULL,"
            " result_json = NULL, error = NULL, started_at = NULL,"
            " finished_at = NULL, progress = 0, step = ?,"
            " lease_agent_id = NULL, lease_expires_at = NULL,"
            " payload = ?, updated_at = ?"
            " WHERE id = ? AND status = 'failed'",
            (
                f"Tự chạy lại lần {count}/{auto_retry.MAX_AUTO_RETRIES}…",
                json.dumps(payload, ensure_ascii=False), ts, command_id,
            ),
        )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        return self.get_command(command_id)

    def process_auto_retries(self, now: datetime | None = None) -> list[dict]:
        """Một nhịp TỰ CHẠY LẠI: mọi lệnh 'failed' đã tới hạn hẹn
        trong payload (kể cả hẹn quá hạn trong lúc app tắt — mở lại
        vẫn nhặt lên) được xếp hàng lại. Lệnh app-side về 'queued'
        cho CommandRunner nhận; lệnh Muse về 'queued' cho
        dispatcher xét lại rồi đẩy 'waiting_muse' như thường. Trả
        các lệnh vừa xếp lại ở nhịp này."""
        from . import auto_retry

        now = now or datetime.now().astimezone()
        rows = self._conn.execute(
            "SELECT * FROM commands WHERE status = 'failed'"
        ).fetchall()
        requeued: list[dict] = []
        for raw in rows:
            command = _command_row(raw)
            if auto_retry.retry_due(command, now):
                row = self.auto_requeue_command(command["id"])
                if row is not None:
                    requeued.append(row)
        return requeued

    def mark_command_attempt(self, command_id: str) -> None:
        """Tăng bộ đếm số lần thực thi (bộ máy hàng đợi V3.1 ghi nhận
        mỗi lần thử, kể cả thử lại sau lỗi tạm thời)."""
        self._conn.execute(
            "UPDATE commands SET attempts = attempts + 1, updated_at = ? WHERE id = ?",
            (now_iso(), command_id),
        )
        self._conn.commit()

    def set_command_agent(self, command_id: str, agent_id: int | None) -> None:
        """Gán lệnh cho một tài khoản Muse (khi Muse đó nhận/báo cáo
        lệnh qua cầu nối) — để app luôn biết lệnh nào do Muse nào giữ."""
        self._conn.execute(
            "UPDATE commands SET agent_id = ?, updated_at = ? WHERE id = ?",
            (agent_id, now_iso(), command_id),
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    # Tài khoản Muse (agents) — V3.3: mỗi tài khoản Muse là một thực
    # thể riêng có token cầu nối riêng; một Muse phụ trách được NHIỀU
    # hồ sơ/kênh, mỗi hồ sơ có tối đa một Muse chính (phân công).
    # ------------------------------------------------------------------ #
    def create_agent(self, name: str, email: str, note: str = "") -> dict:
        """Thêm một tài khoản Muse; tự sinh token cầu nối riêng.
        Email được chuẩn hoá chữ thường và là duy nhất — trùng sẽ
        ValueError kèm hồ sơ/agent hiện có để nơi gọi báo rõ."""
        email_norm = (email or "").strip().lower()
        if not email_norm or "@" not in email_norm:
            raise ValueError(f"Email tài khoản Muse không hợp lệ: {email!r}")
        existing = self.get_agent_by_email(email_norm)
        if existing:
            raise ValueError(
                f"Email {email_norm} đã có tài khoản Muse "
                f"'{existing['name']}' (#{existing['id']})."
            )
        ts = now_iso()
        cur = self._conn.execute(
            "INSERT INTO agents (name, email, token, note, created_at,"
            " updated_at) VALUES (?, ?, ?, ?, ?, ?)",
            (
                (name or "").strip() or email_norm,
                email_norm,
                secrets.token_urlsafe(24),
                note or "",
                ts,
                ts,
            ),
        )
        self._conn.commit()
        return self.get_agent(int(cur.lastrowid))

    def bulk_create_agents(self, entries: list[dict]) -> list[dict]:
        """Thêm HÀNG LOẠT tài khoản Muse. Mỗi mục {name, email, note?}
        cho một kết quả riêng: {'email', 'status': 'created'|'duplicate'|
        'error', 'agent'?, 'message'?} — một mục lỗi không chặn các mục
        còn lại; trùng trong cùng danh sách cũng tính duplicate."""
        results: list[dict] = []
        for entry in entries or []:
            email = ((entry or {}).get("email") or "").strip()
            try:
                agent = self.create_agent(
                    (entry or {}).get("name") or "",
                    email,
                    (entry or {}).get("note") or "",
                )
                results.append(
                    {"email": agent["email"], "status": "created", "agent": agent}
                )
            except ValueError as exc:
                message = str(exc)
                status = (
                    "duplicate" if "đã có tài khoản" in message else "error"
                )
                results.append(
                    {"email": email.lower(), "status": status, "message": message}
                )
        return results

    def get_agent(self, agent_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM agents WHERE id = ?", (agent_id,)
        ).fetchone()
        if row is None:
            return None
        agent = _agent_row(row)
        agent["profile_ids"] = self.profiles_for_agent(agent_id)
        return agent

    def get_agent_by_email(self, email: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM agents WHERE email = ?",
            ((email or "").strip().lower(),),
        ).fetchone()
        return _agent_row(row) if row else None

    def list_agents(self) -> list[dict]:
        rows = self._conn.execute(
            "SELECT * FROM agents ORDER BY id"
        ).fetchall()
        # V4.2 (O-12): phân công của MỌI agent nạp bằng MỘT câu truy
        # vấn rồi nhóm trong bộ nhớ — bản cũ gọi profiles_for_agent
        # riêng cho từng agent (N+1) mà list_agents lại nằm trên
        # đường nóng (bridge_state, Văn phòng, heartbeat…).
        assignments: dict[int, list[int]] = {}
        for agent_id, profile_id in self._conn.execute(
            "SELECT agent_id, profile_id FROM agent_assignments"
            " ORDER BY agent_id, profile_id"
        ).fetchall():
            assignments.setdefault(int(agent_id), []).append(int(profile_id))
        agents = []
        for row in rows:
            agent = _agent_row(row)
            agent["profile_ids"] = assignments.get(agent["id"], [])
            agents.append(agent)
        return agents

    def authenticate_agent(self, agent_id, token: str) -> dict | None:
        """Xác thực một tài khoản Muse qua cầu nối: đúng id + đúng
        token riêng + chưa bị thu hồi thì trả agent, ngược lại None."""
        try:
            agent_id = int(agent_id)
        except (TypeError, ValueError):
            return None
        agent = self.get_agent(agent_id)
        if not agent or agent["revoked"] or not token:
            return None
        if not secrets.compare_digest(str(agent["token"]), str(token)):
            return None
        return agent

    def update_agent(
        self, agent_id: int, name: str | None = None, note: str | None = None
    ) -> dict | None:
        existing = self.get_agent(agent_id)
        if existing is None:
            return None
        self._conn.execute(
            "UPDATE agents SET name = ?, note = ?, updated_at = ? WHERE id = ?",
            (
                name if name is not None else existing["name"],
                note if note is not None else existing["note"],
                now_iso(),
                agent_id,
            ),
        )
        self._conn.commit()
        return self.get_agent(agent_id)

    def regenerate_agent_token(self, agent_id: int) -> dict | None:
        if self.get_agent(agent_id) is None:
            return None
        self._conn.execute(
            "UPDATE agents SET token = ?, updated_at = ? WHERE id = ?",
            (secrets.token_urlsafe(24), now_iso(), agent_id),
        )
        self._conn.commit()
        return self.get_agent(agent_id)

    def set_agent_web_state(self, agent_id: int, state: str) -> dict | None:
        """Cập nhật trạng thái đăng nhập muse.ai của tài khoản Muse
        ('unknown'|'waiting'|'in'|'out') sau mỗi lần mở/kiểm tra cửa sổ
        Chrome riêng của nó."""
        if state not in ("unknown", "waiting", "in", "out"):
            raise ValueError(f"Trạng thái web không hợp lệ: {state}")
        cur = self._conn.execute(
            "UPDATE agents SET web_state = ?, web_checked_at = ?, updated_at = ?"
            " WHERE id = ?",
            (state, now_iso(), now_iso(), agent_id),
        )
        self._conn.commit()
        return self.get_agent(agent_id) if cur.rowcount else None

    def set_agent_revoked(self, agent_id: int, revoked: bool) -> dict | None:
        if self.get_agent(agent_id) is None:
            return None
        self._conn.execute(
            "UPDATE agents SET revoked = ?, updated_at = ? WHERE id = ?",
            (1 if revoked else 0, now_iso(), agent_id),
        )
        self._conn.commit()
        return self.get_agent(agent_id)

    def delete_agent(self, agent_id: int) -> None:
        self._conn.execute("DELETE FROM agents WHERE id = ?", (agent_id,))
        self._conn.commit()

    # ------------------------- phân công ------------------------- #
    def profiles_for_agent(self, agent_id: int) -> list[int]:
        rows = self._conn.execute(
            "SELECT profile_id FROM agent_assignments WHERE agent_id = ?"
            " ORDER BY profile_id",
            (agent_id,),
        ).fetchall()
        return [int(r[0]) for r in rows]

    def agent_for_profile(self, profile_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT agent_id FROM agent_assignments WHERE profile_id = ?",
            (profile_id,),
        ).fetchone()
        if row is None:
            return None
        return self.get_agent(int(row[0]))

    def assign_profiles(self, agent_id: int, profile_ids: list[int]) -> dict:
        """Đặt phân công của MỘT Muse = đúng danh sách hồ sơ truyền
        vào: hồ sơ đang thuộc Muse khác sẽ được chuyển sang (mỗi hồ
        sơ một Muse chính); hồ sơ của Muse này không còn trong
        danh sách sẽ bỏ phân công. Trả về agent sau cập nhật."""
        if self.get_agent(agent_id) is None:
            raise ValueError(f"Không có tài khoản Muse #{agent_id}")
        wanted = {int(p) for p in profile_ids or []}
        ts = now_iso()
        self._conn.execute(
            "DELETE FROM agent_assignments WHERE agent_id = ?", (agent_id,)
        )
        for profile_id in sorted(wanted):
            self._conn.execute(
                "INSERT INTO agent_assignments (agent_id, profile_id,"
                " created_at) VALUES (?, ?, ?)"
                " ON CONFLICT(profile_id) DO UPDATE SET"
                " agent_id = excluded.agent_id, created_at = excluded.created_at",
                (agent_id, profile_id, ts),
            )
        # V3.9.1 — CHỮA LỆNH MỒ CÔI: lệnh "Chờ Muse" được tạo TRƯỚC khi
        # hồ sơ có người phụ trách thì agent_id để trống (nơi tạo không
        # gắn ngược được). Khi phân công, gắn luôn những lệnh đang chờ
        # của các hồ sơ này cho Muse mới — khớp theo profile_id, và cả
        # theo profile_slug phòng khi id hồ sơ đã mục (hồ sơ bị xoá/tạo
        # lại giữa chừng; slug chụp tại lúc tạo lệnh là dấu vết bền).
        if wanted:
            slugs = [
                str(r[0])
                for r in self._conn.execute(
                    "SELECT slug FROM profiles WHERE id IN (%s)"
                    % ", ".join("?" for _ in wanted),
                    tuple(sorted(wanted)),
                ).fetchall()
            ]
            id_ph = ", ".join("?" for _ in wanted)
            slug_clause = ""
            slug_params: tuple = ()
            if slugs:
                slug_clause = " OR profile_slug IN (%s)" % ", ".join(
                    "?" for _ in slugs
                )
                slug_params = tuple(slugs)
            self._conn.execute(
                "UPDATE commands SET agent_id = ?, updated_at = ?"
                " WHERE agent_id IS NULL AND status IN ('waiting_muse', 'queued')"
                f" AND (profile_id IN ({id_ph}){slug_clause})",
                (agent_id, ts, *sorted(wanted), *slug_params),
            )
        self._conn.commit()
        return self.get_agent(agent_id)

    def unassign_profile(self, profile_id: int) -> None:
        self._conn.execute(
            "DELETE FROM agent_assignments WHERE profile_id = ?", (profile_id,)
        )
        self._conn.commit()

    def auto_assign_email_matches(self) -> list[tuple[int, int]]:
        """V4.1.1 — TỰ PHÂN CÔNG THEO EMAIL: tài khoản Muse nào có
        email đăng nhập TRÙNG email (gmail) của một hồ sơ thì Muse đó
        CHÍNH LÀ người phụ trách hồ sơ ấy — không cần ai bấm phân công
        tay. Sự cố thật 29/10: agent dabnire34@gmail.com tồn tại nhưng
        0 phân công → dispatcher giữ lệnh mãi ở 'queued' với bước
        "Chưa có Muse phụ trách hồ sơ này" dù người dùng đã giao việc.

        Quy tắc an toàn:
        - Chỉ gán cho hồ sơ CHƯA CÓ bất kỳ ai phụ trách — không giật
          hồ sơ đã có chủ, không gán chồng thêm người thứ hai.
        - Agent đã bị thu hồi (revoked) thì bỏ qua.
        - Khớp không phân biệt hoa/thường + bỏ khoảng trắng hai đầu;
          agent thiếu email thì lấy ``name`` khi name có dạng email.
        - Idempotent: gọi lại khi đã gán rồi → không thêm gì.

        Gán qua đúng đường ``assign_profiles`` (giữ nguyên danh sách
        hiện có của agent + hồ sơ mới) để hưởng luôn cơ chế gắn lại
        agent_id cho lệnh mồ côi (V3.9.1). Mỗi cặp mới ghi một dòng
        nhật ký. Trả về danh sách (agent_id, profile_id) VỪA gán."""
        added: list[tuple[int, int]] = []
        taken = {
            int(r[0])
            for r in self._conn.execute(
                "SELECT profile_id FROM agent_assignments"
            ).fetchall()
        }
        profiles = self.list_profiles()
        for agent in self.list_agents():
            if agent["revoked"]:
                continue
            email = (agent.get("email") or "").strip().lower()
            if not email:
                # Agent đời cũ thiếu email: name có dạng email thì dùng.
                name = (agent.get("name") or "").strip()
                if "@" in name and "." in name.rsplit("@", 1)[-1]:
                    email = name.lower()
            if not email or "@" not in email:
                continue
            for profile in profiles:
                if profile["id"] in taken:
                    continue
                gmail = (profile.get("gmail") or "").strip().lower()
                if not gmail or gmail != email:
                    continue
                self.assign_profiles(
                    agent["id"],
                    list(agent["profile_ids"]) + [profile["id"]],
                )
                agent["profile_ids"] = list(agent["profile_ids"]) + [
                    profile["id"]
                ]
                taken.add(profile["id"])
                added.append((agent["id"], profile["id"]))
                self.append_journal(
                    f"Tự phân công: hồ sơ {profile.get('gmail')} → Muse "
                    f"{agent['name']} (trùng email)",
                    profile["id"],
                )
        return added

    def ensure_agent_assignment(self, agent_id: int, profile_id: int) -> bool:
        """V4.1.1 — ĐẢM BẢO một cặp phân công agent ↔ hồ sơ tồn tại khi
        người dùng CHỈ ĐỊNH TƯỜNG MINH Muse nhận lệnh ngay ở tab Lệnh
        (ô chọn "Tài khoản Muse nhận lệnh" / nút "🎯 Đổi Muse nhận
        lệnh…"). Khác tự phân công theo email ở hai điểm: không cần
        trùng email, và hồ sơ đang thuộc Muse khác sẽ CHUYỂN chủ —
        vì đây là lựa chọn có chủ đích của người dùng, đi qua đúng
        đường ``assign_profiles`` (giữ các hồ sơ khác của agent, kèm
        gắn lại agent_id cho lệnh mồ côi của hồ sơ).

        Trả True nếu VỪA gán mới (kèm một dòng nhật ký), False nếu
        agent này vốn đã phụ trách hồ sơ."""
        agent = self.get_agent(agent_id)
        if agent is None:
            raise ValueError(f"Không có tài khoản Muse #{agent_id}")
        profile = self.get_profile(profile_id)
        if profile is None:
            raise ValueError(f"Không có hồ sơ #{profile_id}")
        if int(profile_id) in agent["profile_ids"]:
            return False
        self.assign_profiles(
            agent_id, list(agent["profile_ids"]) + [int(profile_id)]
        )
        self.append_journal(
            f"Phân công thủ công ở tab Lệnh: hồ sơ "
            f"{profile.get('gmail') or profile['label']} → Muse "
            f"{agent['name']} (người dùng chỉ định Muse nhận lệnh)",
            int(profile_id),
        )
        return True

    # ------------------------- chat với Muse (V4.6) ------------------------- #
    MESSAGE_DIRECTIONS = ("user", "agent", "system")
    MESSAGE_BODY_LIMIT = 4000

    def add_message(
        self, agent_id: int, direction: str, body: str,
        command_id: str | None = None,
    ) -> dict:
        """Thêm một tin vào luồng chat của một tài khoản Muse.
        direction: 'user' (người dùng → Muse), 'agent' (Muse →
        người dùng), 'system' (app tự chèn). Tin mới luôn ở trạng
        thái chưa đọc (read_at NULL) cho phía nhận."""
        if direction not in self.MESSAGE_DIRECTIONS:
            raise ValueError(f"Chiều tin nhắn không hợp lệ: {direction!r}")
        if self.get_agent(int(agent_id)) is None:
            raise ValueError(f"Không có tài khoản Muse #{agent_id}")
        cur = self._conn.execute(
            "INSERT INTO agent_messages"
            " (agent_id, direction, body, command_id, created_at, read_at)"
            " VALUES (?, ?, ?, ?, ?, NULL)",
            (int(agent_id), direction, body or "", command_id or None, now_iso()),
        )
        self._conn.commit()
        return self.get_message(int(cur.lastrowid))

    def get_message(self, message_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM agent_messages WHERE id = ?", (int(message_id),)
        ).fetchone()
        return _message_row(row) if row else None

    def list_messages(
        self, agent_id: int, limit: int = 100, before_id: int | None = None,
    ) -> list[dict]:
        """Lịch sử luồng chat: `limit` tin GẦN NHẤT (trước mốc
        `before_id` nếu có), trả theo thứ tự cũ → mới để UI vẽ thẳng."""
        limit = max(1, min(int(limit or 100), 500))
        if before_id:
            rows = self._conn.execute(
                "SELECT * FROM agent_messages WHERE agent_id = ? AND id < ?"
                " ORDER BY id DESC LIMIT ?",
                (int(agent_id), int(before_id), limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM agent_messages WHERE agent_id = ?"
                " ORDER BY id DESC LIMIT ?",
                (int(agent_id), limit),
            ).fetchall()
        return [_message_row(r) for r in reversed(rows)]

    def list_unread_messages(
        self, agent_id: int, direction: str, limit: int = 200,
    ) -> list[dict]:
        """Tin CHƯA ĐỌC của một chiều trong luồng (cũ → mới) — phía
        Muse đọc tin 'user', phía người dùng đọc tin 'agent'."""
        limit = max(1, min(int(limit or 200), 500))
        rows = self._conn.execute(
            "SELECT * FROM agent_messages WHERE agent_id = ?"
            " AND direction = ? AND read_at IS NULL ORDER BY id ASC LIMIT ?",
            (int(agent_id), direction, limit),
        ).fetchall()
        return [_message_row(r) for r in rows]

    def messages_signature(self, agent_id: int) -> tuple:
        """Vân NHẸ của một luồng chat (V5.2 — hiệu năng §15): một truy
        vấn gộp duy nhất (số tin, id lớn nhất, số tin đến chưa đọc)
        để UI quyết định có cần nạp lại + dựng lại bong bóng hay
        không, thay vì SELECT * 200 tin mỗi nhịp 5 giây."""
        row = self._conn.execute(
            "SELECT COUNT(*), MAX(id),"
            " SUM(CASE WHEN direction IN ('agent', 'system')"
            "     AND read_at IS NULL THEN 1 ELSE 0 END),"
            " SUM(LENGTH(body))"
            " FROM agent_messages WHERE agent_id = ?",
            (int(agent_id),),
        ).fetchone()
        # V6.4.3: phần tử thứ 4 = tổng độ dài chữ → tin Muse đang CHẢY
        # chữ (cập nhật tại chỗ) cũng làm vân đổi, khung chat vẽ lại.
        return (int(row[0] or 0), int(row[1] or 0), int(row[2] or 0), int(row[3] or 0))

    def update_message_body(self, message_id: int, body: str) -> None:
        """V6.4.3: cập nhật chữ của một tin tại chỗ (câu trả lời Muse
        đang chảy chữ từ muse.ai)."""
        self._conn.execute(
            "UPDATE agent_messages SET body = ? WHERE id = ?",
            ((body or "")[: self.MESSAGE_BODY_LIMIT * 4], int(message_id)),
        )
        self._conn.commit()

    def list_commands_light(self, limit: int = 500) -> list[dict]:
        """Chỉ các cột mà vân bảng công việc cần (V5.2): id/status/
        progress/updated_at — tránh SELECT * + json.loads payload của
        hàng trăm lệnh ở MỌI nhịp so vân."""
        limit = max(1, min(int(limit or 500), 2000))
        rows = self._conn.execute(
            "SELECT id, status, progress, updated_at FROM commands"
            " ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]

    def list_agents_light(self) -> list[dict]:
        """Bản nhẹ của list_agents cho vân nhịp nền (V5.2): chỉ id/
        last_seen_at/revoked — đủ tính status y hệt _agent_row."""
        rows = self._conn.execute(
            "SELECT id, last_seen_at, revoked FROM agents ORDER BY id"
        ).fetchall()
        result = []
        for row in rows:
            data = dict(row)
            data["revoked"] = bool(data["revoked"])
            data["status"] = agent_status(
                data.get("last_seen_at"), data["revoked"]
            )
            result.append(data)
        return result

    def unread_counts(self) -> dict[int, dict[str, int]]:
        """Số tin chưa đọc theo TỪNG agent và TỪNG chiều:
        {agent_id: {'user': n, 'agent': n, 'system': n}} — chiều là
        hướng của tin (phía nhận là phía còn lại). Agent không có
        tin chưa đọc thì vắng mặt trong dict."""
        counts: dict[int, dict[str, int]] = {}
        for agent_id, direction, total in self._conn.execute(
            "SELECT agent_id, direction, COUNT(*) FROM agent_messages"
            " WHERE read_at IS NULL GROUP BY agent_id, direction"
        ).fetchall():
            counts.setdefault(int(agent_id), {})[str(direction)] = int(total)
        return counts

    def mark_read(
        self, agent_id: int, direction: str, up_to_id: int | None = None,
    ) -> int:
        """Đánh dấu đã đọc mọi tin của `direction` trong luồng của
        agent (tới `up_to_id` nếu cho). Trả số tin vừa đánh dấu."""
        sql = (
            "UPDATE agent_messages SET read_at = ? WHERE agent_id = ?"
            " AND direction = ? AND read_at IS NULL"
        )
        params: list = [now_iso(), int(agent_id), direction]
        if up_to_id:
            sql += " AND id <= ?"
            params.append(int(up_to_id))
        cur = self._conn.execute(sql, params)
        self._conn.commit()
        return int(cur.rowcount)

    def _note_needs_user_in_chat(self, command: dict, message: str) -> None:
        """V4.6 — Chèn tin HỆ THỐNG vào luồng chat của Muse phụ
        trách khi một lệnh kẹt 'needs_user': chat là nơi Muse hỏi
        và người dùng trả lời để chạy tiếp. KHỬ TRÙNG: tin gần nhất
        gắn với chính lệnh này đã là tin hệ thống CÙNG nội dung (hai
        đường code cùng đặt needs_user cho một lần dừng, hoặc Muse
        báo lại) thì không chèn thêm; đã có trao đổi mới về lệnh
        (tin user/agent chen vào) hoặc lần dừng mới với lý do khác
        thì chèn bình thường."""
        agent_id = command.get("agent_id") or command.get("lease_agent_id")
        if not agent_id and command.get("profile_id"):
            owner = self.agent_for_profile(int(command["profile_id"]))
            agent_id = owner["id"] if owner else None
        if not agent_id:
            return
        reason = (
            (message or "").strip()
            or (command.get("step") or "").strip()
            or "cần bạn xử lý trong app"
        )
        body = f"⏸ Lệnh #{command['id']} đang chờ bạn xử lý: {reason}"
        latest = self._conn.execute(
            "SELECT direction, body FROM agent_messages"
            " WHERE agent_id = ? AND command_id = ? ORDER BY id DESC LIMIT 1",
            (int(agent_id), command["id"]),
        ).fetchone()
        if (
            latest is not None
            and latest["direction"] == "system"
            and latest["body"] == body
        ):
            return
        self.add_message(int(agent_id), "system", body, command_id=command["id"])

    # ------------------------- nhịp sống ------------------------- #
    def touch_agent_heartbeat(
        self, agent_id: int, current_command_id: str | None = None
    ) -> dict | None:
        """Ghi nhịp heartbeat của một Muse (đang sống + lệnh đang giữ).
        current_command_id=None: giữ nguyên; '' : không giữ lệnh nào."""
        if self.get_agent(agent_id) is None:
            return None
        if current_command_id is None:
            self._conn.execute(
                "UPDATE agents SET last_seen_at = ?, updated_at = ?"
                " WHERE id = ?",
                (now_iso(), now_iso(), agent_id),
            )
        else:
            self._conn.execute(
                "UPDATE agents SET last_seen_at = ?, current_command_id = ?,"
                " updated_at = ? WHERE id = ?",
                (now_iso(), str(current_command_id)[:64], now_iso(), agent_id),
            )
        self._conn.commit()
        return self.get_agent(agent_id)

    def touch_agent_heartbeat_light(
        self, agent_id: int, current_command_id: str | None = None,
        min_interval_seconds: float = 5.0,
    ) -> dict | None:
        """Bản NHẸ của touch_agent_heartbeat (V4.2 — O-12): chỉ
        UPDATE khi nhịp trước đã quá ``min_interval_seconds`` HOẶC
        lệnh đang giữ thay đổi; đọc trạng thái bằng một SELECT hẹp
        (không nạp full agent hai lần như bản đầy đủ). Trả agent hiện
        tại (nạp đầy đủ đúng MỘT lần khi cần trả về); None nếu không
        có agent. Dùng cho endpoint heartbeat tường minh — nơi bị ghi
        trùng hai lần mỗi nhịp trước V4.2."""
        row = self._conn.execute(
            "SELECT last_seen_at, current_command_id FROM agents"
            " WHERE id = ?",
            (agent_id,),
        ).fetchone()
        if row is None:
            return None
        last_seen = None
        if row[0]:
            try:
                parsed = datetime.fromisoformat(str(row[0]))
                last_seen = parsed if parsed.tzinfo else parsed.astimezone()
            except ValueError:
                last_seen = None
        current_stored = row[1]
        wanted = (
            current_stored
            if current_command_id is None
            else str(current_command_id)[:64]
        )
        fresh = (
            last_seen is not None
            and (datetime.now().astimezone() - last_seen).total_seconds()
            < min_interval_seconds
        )
        if fresh and wanted == current_stored:
            return self.get_agent(agent_id)
        return self.touch_agent_heartbeat(agent_id, current_command_id)

    def _profile_slugs_for_agent(self, agent_id: int) -> list[str]:
        profile_ids = self.profiles_for_agent(agent_id)
        if not profile_ids:
            return []
        placeholders = ", ".join("?" for _ in profile_ids)
        rows = self._conn.execute(
            f"SELECT slug FROM profiles WHERE id IN ({placeholders})",
            tuple(profile_ids),
        ).fetchall()
        return [str(r[0]) for r in rows]

    def list_commands_for_agent(
        self, agent_id: int, limit: int = 200,
        status: str | None = None, source: str | None = None,
    ) -> list[dict]:
        """Lệnh thuộc phạm vi của một Muse: lệnh gắn thẳng agent_id
        HOẶC lệnh của các hồ sơ Muse đó phụ trách. V3.9.1: cộng lệnh
        MỒ CÔI — chưa ghi danh ai (agent_id trống, vì được tạo trước
        khi hồ sơ có người phụ trách) nhưng slug hồ sơ chụp lúc tạo
        khớp một hồ sơ Muse này phụ trách: slug là danh tính bền của
        mail, id số có thể đã mục khi hồ sơ bị xoá/tạo lại.

        V4.2 (O-28): ``status``/``source`` lọc NGAY TRONG SQL, TRƯỚC
        LIMIT — bản cũ lấy 50 lệnh mới nhất trong phạm vi rồi mới lọc
        ở Python nên một lệnh 'waiting_muse' cũ hơn bị các lệnh mới
        trạng thái khác chen mất, không bao giờ tới được Muse."""
        profile_ids = self.profiles_for_agent(agent_id)
        clauses = ["agent_id = ?"]
        params: list = [agent_id]
        if profile_ids:
            placeholders = ", ".join("?" for _ in profile_ids)
            clauses.append(f"profile_id IN ({placeholders})")
            params.extend(profile_ids)
            slugs = self._profile_slugs_for_agent(agent_id)
            if slugs:
                slug_ph = ", ".join("?" for _ in slugs)
                clauses.append(
                    f"(agent_id IS NULL AND profile_slug IN ({slug_ph}))"
                )
                params.extend(slugs)
        where = f"({' OR '.join(clauses)})"
        if status is not None:
            where += " AND status = ?"
            params.append(status)
        if source is not None:
            where += " AND source = ?"
            params.append(source)
        rows = self._conn.execute(
            f"SELECT * FROM commands WHERE {where}"
            " ORDER BY created_at DESC, rowid DESC LIMIT ?",
            (*params, limit),
        ).fetchall()
        return [_command_row(r) for r in rows]

    def agent_can_access_command(self, agent_id: int, command: dict) -> bool:
        """Chống giẫm chân: Muse chỉ thao tác được lệnh gắn cho mình
        hoặc lệnh thuộc hồ sơ mình phụ trách. V3.9.1: lệnh mồ côi
        (agent_id trống) khớp slug hồ sơ mình phụ trách cũng thuộc
        phạm vi — cùng quy tắc với list_commands_for_agent."""
        if not command:
            return False
        if command.get("agent_id") == agent_id:
            return True
        profile_id = command.get("profile_id")
        if profile_id is not None:
            owner = self.agent_for_profile(int(profile_id))
            if owner and owner["id"] == agent_id:
                return True
        if command.get("agent_id") is None and command.get("profile_slug"):
            return str(command["profile_slug"]) in self._profile_slugs_for_agent(
                agent_id
            )
        return False

    # ------------------------------------------------------------------ #
    # V6.0 — Giám sát chéo: bảng reviews (vòng kiểm tra của lệnh gốc).
    # Logic điều phối (ma trận, sinh việc, watchdog, áp kết luận) nằm ở
    # app.supervision; ở đây chỉ là tầng dữ liệu thuần.
    # ------------------------------------------------------------------ #
    REVIEW_OPEN = "open"
    REVIEW_DECIDED = ("passed", "rework", "escalated", "skipped")

    def create_review(
        self,
        command_id: str,
        worker_agent_id: int | None,
        supervisor_agent_id: int | None,
        trigger_kind: str,
        round: int = 0,
        checklist: list | None = None,
    ) -> dict:
        """Mở một vòng kiểm tra cho lệnh gốc (trạng thái 'open').
        review_command_id gắn SAU bằng set_review_command (việc kiểm
        tra phải có bản ghi review trước để payload mang review_id)."""
        cur = self._conn.execute(
            "INSERT INTO reviews (command_id, worker_agent_id,"
            " supervisor_agent_id, trigger_kind, round, status,"
            " checklist, created_at) VALUES (?, ?, ?, ?, ?, 'open', ?, ?)",
            (
                command_id,
                worker_agent_id,
                supervisor_agent_id,
                trigger_kind,
                int(round or 0),
                json.dumps(checklist or [], ensure_ascii=False),
                now_iso(),
            ),
        )
        self._conn.commit()
        return self.get_review(int(cur.lastrowid))

    def get_review(self, review_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM reviews WHERE id = ?", (int(review_id),)
        ).fetchone()
        return _review_row(row) if row else None

    def get_review_by_review_command(self, review_command_id: str) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM reviews WHERE review_command_id = ?"
            " ORDER BY id DESC LIMIT 1",
            (str(review_command_id or ""),),
        ).fetchone()
        return _review_row(row) if row else None

    def set_review_command(self, review_id: int, review_command_id: str) -> dict | None:
        self._conn.execute(
            "UPDATE reviews SET review_command_id = ? WHERE id = ?",
            (review_command_id, int(review_id)),
        )
        self._conn.commit()
        return self.get_review(int(review_id))

    def open_review_for_command(self, command_id: str) -> dict | None:
        """Vòng kiểm tra ĐANG MỞ của một lệnh gốc (bất biến V6.0: tối
        đa MỘT vòng mở cho mỗi lệnh tại một thời điểm)."""
        row = self._conn.execute(
            "SELECT * FROM reviews WHERE command_id = ? AND status = 'open'"
            " ORDER BY id DESC LIMIT 1",
            (command_id,),
        ).fetchone()
        return _review_row(row) if row else None

    def list_reviews(
        self, status: str | None = None, limit: int = 100,
    ) -> list[dict]:
        """Danh sách vòng kiểm tra, MỚI NHẤT trước; lọc theo trạng thái
        vòng ('open' hoặc một kết luận) khi truyền ``status``."""
        limit = max(1, min(int(limit or 100), 500))
        if status is not None:
            rows = self._conn.execute(
                "SELECT * FROM reviews WHERE status = ?"
                " ORDER BY id DESC LIMIT ?",
                (status, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM reviews ORDER BY id DESC LIMIT ?", (limit,)
            ).fetchall()
        return [_review_row(r) for r in rows]

    def list_reviews_for_command(self, command_id: str) -> list[dict]:
        """Toàn bộ lịch sử kiểm tra của một lệnh gốc, cũ → mới."""
        rows = self._conn.execute(
            "SELECT * FROM reviews WHERE command_id = ? ORDER BY id ASC",
            (command_id,),
        ).fetchall()
        return [_review_row(r) for r in rows]

    def decide_review(
        self,
        review_id: int,
        status: str,
        verdict: str,
        notes: str = "",
        checklist: list | None = None,
    ) -> dict | None:
        """Chốt một vòng kiểm tra đang mở bằng một kết luận. Chỉ chốt
        được vòng 'open' — vòng đã chốt giữ nguyên (trả None)."""
        if status not in self.REVIEW_DECIDED:
            raise ValueError(f"Trạng thái vòng kiểm tra không hợp lệ: {status}")
        sets = "status = ?, verdict = ?, notes = ?, decided_at = ?"
        params: list = [status, verdict, notes or "", now_iso()]
        if checklist is not None:
            sets += ", checklist = ?"
            params.append(json.dumps(checklist, ensure_ascii=False))
        params.append(int(review_id))
        cur = self._conn.execute(
            f"UPDATE reviews SET {sets} WHERE id = ? AND status = 'open'",
            tuple(params),
        )
        self._conn.commit()
        if cur.rowcount != 1:
            return None
        return self.get_review(int(review_id))

    def reviews_signature(self) -> tuple:
        """Vân NHẸ của bảng reviews cho cổng làm mới của tab Giám sát
        (§16: truy vấn gộp trước mọi khâu nạp): (tổng số, id lớn nhất,
        số vòng đang mở)."""
        row = self._conn.execute(
            "SELECT COUNT(*), MAX(id),"
            " SUM(CASE WHEN status = 'open' THEN 1 ELSE 0 END)"
            " FROM reviews"
        ).fetchone()
        return (int(row[0] or 0), int(row[1] or 0), int(row[2] or 0))

    def set_command_review_state(
        self, command_id: str, round: int | None = None,
        last_verdict: str | None = None,
    ) -> dict | None:
        """Ghi cột truy vết kiểm tra trên lệnh gốc (review_round /
        last_verdict) — chỉ đổi trường được truyền."""
        existing = self.get_command(command_id)
        if existing is None:
            return None
        self._conn.execute(
            "UPDATE commands SET review_round = ?, last_verdict = ?,"
            " updated_at = ? WHERE id = ?",
            (
                existing.get("review_round") or 0 if round is None else int(round),
                existing.get("last_verdict") or "" if last_verdict is None else last_verdict,
                now_iso(),
                command_id,
            ),
        )
        self._conn.commit()
        return self.get_command(command_id)

    def review_verdict_counts(
        self, worker_agent_id: int, since_iso: str,
    ) -> dict[str, int]:
        """Đếm vòng kiểm tra ĐÃ CHỐT theo trạng thái cho một người làm
        kể từ mốc truyền vào (thẻ điểm V6.0)."""
        rows = self._conn.execute(
            "SELECT status, COUNT(*) FROM reviews"
            " WHERE worker_agent_id = ? AND decided_at IS NOT NULL"
            " AND decided_at >= ? GROUP BY status",
            (int(worker_agent_id), since_iso),
        ).fetchall()
        return {str(r[0]): int(r[1]) for r in rows}

    def review_round_zero_pass_rate(
        self, worker_agent_id: int, since_iso: str,
    ) -> tuple[int, int]:
        """(số vòng 0 chấm 'passed', tổng số vòng 0 đã chốt) — tử/mẫu
        của '% đạt ngay lần đầu' trong thẻ điểm."""
        row = self._conn.execute(
            "SELECT SUM(CASE WHEN status = 'passed' THEN 1 ELSE 0 END),"
            " COUNT(*) FROM reviews WHERE worker_agent_id = ?"
            " AND round = 0 AND decided_at IS NOT NULL AND decided_at >= ?",
            (int(worker_agent_id), since_iso),
        ).fetchone()
        return (int(row[0] or 0), int(row[1] or 0))

    def review_stuck_count(self, worker_agent_id: int, since_iso: str) -> int:
        """Số lần agent bị watchdog bắt 'treo' kể từ mốc (mọi vòng
        trigger='stuck' đã mở cho lệnh của agent này)."""
        row = self._conn.execute(
            "SELECT COUNT(*) FROM reviews WHERE worker_agent_id = ?"
            " AND trigger_kind = 'stuck' AND created_at >= ?",
            (int(worker_agent_id), since_iso),
        ).fetchone()
        return int(row[0] or 0)

    def command_completion_stats(
        self, agent_id: int, since_iso: str,
    ) -> tuple[int, float | None]:
        """(số lệnh 'done', thời gian hoàn thành trung bình giây) của
        một agent kể từ mốc — tính từ created_at → finished_at của
        chính lệnh. (0, None) khi chưa có lệnh xong nào."""
        rows = self._conn.execute(
            "SELECT created_at, finished_at FROM commands"
            " WHERE agent_id = ? AND status = 'done'"
            " AND finished_at IS NOT NULL AND finished_at >= ?"
            " AND type <> 'review'",
            (int(agent_id), since_iso),
        ).fetchall()
        durations = []
        for created_raw, finished_raw in rows:
            created = _parse_iso(created_raw)
            finished = _parse_iso(finished_raw)
            if created is not None and finished is not None:
                durations.append((finished - created).total_seconds())
        if not durations:
            return (len(rows), None)
        return (len(rows), sum(durations) / len(durations))

    # ------------------------------------------------------------------ #
    # Quy tắc tự động (V3)
    # ------------------------------------------------------------------ #
    def add_rule(
        self,
        action: str,
        profile_id: int | None = None,
        schedule_kind: str = "daily",
        daily_time: str = "08:00",
        interval_hours: float | None = None,
        enabled: bool = False,
        next_run_at: str | None = None,
    ) -> dict:
        if action not in RULE_ACTIONS:
            raise ValueError(f"Hành động tự động không hợp lệ: {action}")
        if schedule_kind not in ("daily", "interval"):
            raise ValueError(f"Kiểu lịch không hợp lệ: {schedule_kind}")
        cur = self._conn.execute(
            "INSERT INTO automation_rules (action, profile_id, schedule_kind,"
            " daily_time, interval_hours, enabled, next_run_at, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                action,
                profile_id,
                schedule_kind,
                daily_time or "08:00",
                interval_hours,
                1 if enabled else 0,
                next_run_at,
                now_iso(),
            ),
        )
        self._conn.commit()
        return self.get_rule(cur.lastrowid)

    def get_rule(self, rule_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM automation_rules WHERE id = ?", (rule_id,)
        ).fetchone()
        return _rule_row(row) if row else None

    def list_rules(self) -> list[dict]:
        rows = self._conn.execute("SELECT * FROM automation_rules ORDER BY id").fetchall()
        return [_rule_row(r) for r in rows]

    _RULE_FIELDS = {
        "action",
        "profile_id",
        "schedule_kind",
        "daily_time",
        "interval_hours",
        "enabled",
        "last_run_at",
        "next_run_at",
    }

    def update_rule(self, rule_id: int, **fields) -> dict | None:
        unknown = set(fields) - self._RULE_FIELDS
        if unknown:
            raise ValueError(f"Trường quy tắc không hợp lệ: {sorted(unknown)}")
        if "enabled" in fields:
            fields["enabled"] = 1 if fields["enabled"] else 0
        if fields:
            assignments = ", ".join(f"{name} = ?" for name in fields)
            self._conn.execute(
                f"UPDATE automation_rules SET {assignments} WHERE id = ?",
                (*fields.values(), rule_id),
            )
            self._conn.commit()
        return self.get_rule(rule_id)

    def delete_rule(self, rule_id: int) -> None:
        self._conn.execute("DELETE FROM automation_rules WHERE id = ?", (rule_id,))
        self._conn.commit()

    def seed_default_rules(self) -> None:
        """Gieo 2 quy tắc mặc định (đều TẮT) nếu bảng quy tắc còn trống:
        quét kênh hằng ngày 08:00 và kiểm tra kênh mỗi 6 giờ. Idempotent."""
        count = self._conn.execute("SELECT COUNT(*) FROM automation_rules").fetchone()[0]
        if count:
            return
        self.add_rule("scan", schedule_kind="daily", daily_time="08:00", enabled=False)
        self.add_rule("check", schedule_kind="interval", interval_hours=6, enabled=False)

    # ------------------------------------------------------------------ #
    # Kết quả kiểm tra (V3)
    # ------------------------------------------------------------------ #
    def save_check(self, profile_id: int, items: list[dict], summary: str) -> dict:
        cur = self._conn.execute(
            "INSERT INTO profile_checks (profile_id, ts, items, summary) VALUES (?, ?, ?, ?)",
            (profile_id, now_iso(), json.dumps(items, ensure_ascii=False), summary),
        )
        self._conn.commit()
        row = self._conn.execute(
            "SELECT * FROM profile_checks WHERE id = ?", (cur.lastrowid,)
        ).fetchone()
        return _check_row(row)

    def get_last_check(self, profile_id: int) -> dict | None:
        row = self._conn.execute(
            "SELECT * FROM profile_checks WHERE profile_id = ? ORDER BY id DESC LIMIT 1",
            (profile_id,),
        ).fetchone()
        return _check_row(row) if row else None

    # ------------------------------------------------------------------ #
    # Video (V3, tối thiểu) — phục vụ mục kiểm tra "video đang Scheduled"
    # ------------------------------------------------------------------ #
    def upsert_video(self, profile_id: int, video: dict) -> bool:
        """Thêm/cập nhật bản ghi video theo (profile_id, video_id). True nếu mới."""
        video_id = (video.get("video_id") or "").strip()
        if not video_id:
            raise ValueError("video dict thiếu 'video_id'")
        ts = now_iso()
        existing = self._conn.execute(
            "SELECT id FROM videos WHERE profile_id = ? AND video_id = ?",
            (profile_id, video_id),
        ).fetchone()
        if existing is None:
            self._conn.execute(
                "INSERT INTO videos (profile_id, channel_id, video_id, title, status,"
                " scheduled_at, url, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    profile_id,
                    video.get("channel_id", ""),
                    video_id,
                    video.get("title", ""),
                    video.get("status", ""),
                    video.get("scheduled_at"),
                    video.get("url", ""),
                    ts,
                    ts,
                ),
            )
            self._conn.commit()
            return True
        self._conn.execute(
            "UPDATE videos SET channel_id = ?, title = ?, status = ?,"
            " scheduled_at = ?, url = ?, updated_at = ? WHERE id = ?",
            (
                video.get("channel_id", ""),
                video.get("title", ""),
                video.get("status", ""),
                video.get("scheduled_at"),
                video.get("url", ""),
                ts,
                existing["id"],
            ),
        )
        self._conn.commit()
        return False

    def list_videos(self, profile_id: int, status: str | None = None) -> list[dict]:
        if status is None:
            rows = self._conn.execute(
                "SELECT * FROM videos WHERE profile_id = ? ORDER BY id", (profile_id,)
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM videos WHERE profile_id = ? AND status = ? ORDER BY id",
                (profile_id, status),
            ).fetchall()
        return [dict(r) for r in rows]


def _export_rows(rows: list[dict], fmt: str) -> str:
    """Định dạng danh sách dòng thành JSON hoặc CSV (cho nút xuất dữ liệu)."""
    if fmt == "json":
        return json.dumps(rows, ensure_ascii=False, indent=2)
    if fmt == "csv":
        import csv
        import io

        if not rows:
            return ""
        buffer = io.StringIO()
        writer = csv.DictWriter(buffer, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
        return buffer.getvalue()
    raise ValueError(f"Định dạng xuất không hợp lệ: {fmt}")


def _profile_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["paused"] = bool(data["paused"])
    return data


def _command_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    try:
        data["payload"] = json.loads(data.get("payload") or "{}")
    except (TypeError, json.JSONDecodeError):
        data["payload"] = {}
    raw_json = data.pop("result_json", None)
    try:
        data["result_data"] = json.loads(raw_json) if raw_json else None
    except (TypeError, json.JSONDecodeError):
        data["result_data"] = None
    return data


def _review_row(row: sqlite3.Row) -> dict:
    """Hàng reviews → dict, checklist giải JSON (V6.0)."""
    data = dict(row)
    try:
        data["checklist"] = json.loads(data.get("checklist") or "[]")
    except (TypeError, json.JSONDecodeError):
        data["checklist"] = []
    if not isinstance(data["checklist"], list):
        data["checklist"] = []
    return data


def _parse_iso(value) -> datetime | None:
    """Parse mốc ISO đã lưu (kèm offset) — None khi rỗng/hỏng."""
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


AGENT_ONLINE_SECONDS = 120
AGENT_IDLE_SECONDS = 900


def agent_status(last_seen_at: str | None, revoked: bool = False) -> str:
    """Trạng thái sống của một tài khoản Muse từ heartbeat gần nhất:
    'online' (< 2 phút), 'idle' (2–15 phút), 'offline' (còn lại/chưa
    từng), 'revoked' (đã thu hồi — ưu tiên hơn mọi trạng thái)."""
    if revoked:
        return "revoked"
    if not last_seen_at:
        return "offline"
    try:
        seen = datetime.fromisoformat(str(last_seen_at))
    except ValueError:
        return "offline"
    age = (datetime.now().astimezone() - seen).total_seconds()
    if age < AGENT_ONLINE_SECONDS:
        return "online"
    if age < AGENT_IDLE_SECONDS:
        return "idle"
    return "offline"


def _agent_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["revoked"] = bool(data["revoked"])
    data["status"] = agent_status(data.get("last_seen_at"), data["revoked"])
    return data


def _message_row(row: sqlite3.Row) -> dict:
    """Một tin chat (V4.6) thành dict JSON-an toàn cho API/UI."""
    data = dict(row)
    data["agent_id"] = int(data["agent_id"])
    return data


def _rule_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["enabled"] = bool(data["enabled"])
    return data


def _check_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    try:
        data["items"] = json.loads(data.get("items") or "[]")
    except (TypeError, json.JSONDecodeError):
        data["items"] = []
    return data
