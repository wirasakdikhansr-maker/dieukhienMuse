"""Agent API (V2) — "cầu nối" để Muse điều khiển app từ xa qua Tailscale.

App chạy một HTTP server nhỏ (chỉ thư viện chuẩn) trong luồng nền:

- Muse (ở phía bên kia mạng Tailscale) gửi lệnh + file tới API này.
- App thực thi bằng chính các module sẵn có (chrome_manager, scanner,
  store, cdp) và ghi nhật ký mọi thao tác với tiền tố ``[API]``.

Bảo mật: server bind ``0.0.0.0`` mặc định (hoặc chỉ ``127.0.0.1`` nếu
bật ``agent_bind_localhost`` trong Cài đặt, V3.1) nên MỌI endpoint (trừ
``GET /api/health``) bắt buộc có header ``X-Agent-Token`` khớp token
riêng của bản cài, lưu ở ``data/settings.json`` (``"agent_token"`` —
tự sinh ở lần chạy đầu và lưu lại). Không có token đúng → 401.
Token + Tailscale là hai lớp khoá.

Ghi chú luồng: ``Store`` giữ một kết nối sqlite dùng trong luồng đã tạo nó,
nên server KHÔNG dùng chung Store của UI. Mỗi request/lệnh mở một Store
riêng (kết nối riêng tới cùng file DB) trong đúng luồng đang chạy rồi đóng
lại; SQLite tự xử lý tranh chấp ghi bằng busy-timeout mặc định.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
import sqlite3
import threading
import time
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import cdp, command_schema, config, cookies_vault, scanner, studio_script
from .chrome_manager import ChromeManager
from .store import now_iso, CDP_COMMAND_TYPES, CLAUDE_COMMAND_TYPES, COMMAND_STATUSES, Store

APP_NAME = "Channel Control Desktop"
# 2.5 (V4.4): bề mặt API đổi — thêm loại lệnh studio_script (kịch bản
# Studio trong Chrome nhúng) + header X-Command-Id cho /api/inbox
# (giao file ĐÍNH KÈM một lệnh). Schema DB giữ nguyên 7.
# 2.6 (V4.6): thêm CHAT hai chiều theo từng tài khoản Muse —
# GET/POST /api/agents/{id}/messages (+ /read) với long-poll tin
# chưa đọc; schema DB 7 → 8 (bảng agent_messages).
# 2.7 (V6.0): GIÁM SÁT CHÉO — loại lệnh 'review' chạy qua chính các
# endpoint lệnh hiện có; thêm POST /api/commands/{id}/verdict (giám
# sát viên gửi kết luận) và GET /api/agents/{id}/scorecard (thẻ điểm
# tuần); schema DB 8 → 9 (bảng reviews + cột truy vết trên commands).
AGENT_API_VERSION = "2.8"
DEFAULT_AGENT_PORT = 19500

# Loại lệnh Muse được phép TẠO qua API (app tự thực thi tại chỗ).
# V4.3: worker thi hành thêm cdp_evaluate/cdp_click/cdp_type (hành động
# TRONG trang nhúng) cạnh cdp_navigate — xem app.store.CDP_COMMAND_TYPES.
COMMAND_TYPES = ("open_browser", "scan") + CDP_COMMAND_TYPES


def api_command_shape(row: dict) -> dict:
    """Định hình một dòng lệnh trong kho thành JSON trả cho phía Muse.

    Bảng commands là nơi DÙNG CHUNG: lệnh do người dùng tạo trong UI
    (source='ui'), do tự động hoá tạo ('auto') và do API tạo ('api') đều
    nằm ở đây; ``result`` ưu tiên dữ liệu có cấu trúc (result_data),
    không có thì trả text kết quả thuần.
    """
    return {
        "id": row["id"],
        "source": row["source"],
        "type": row["type"],
        "profile": row["profile_slug"],
        "profile_id": row["profile_id"],
        "channel_id": row["channel_id"],
        "instruction": row["instruction"],
        "payload": row["payload"],
        "status": row["status"],
        "agent_id": row.get("agent_id"),
        "progress": row.get("progress") or 0,
        "step": row.get("step") or "",
        "result": row["result_data"] if row.get("result_data") is not None else row["result"],
        "error": row["error"],
        "scheduled_at": row["scheduled_at"],
        # V6.1: hạn chót của việc — Muse lên kế hoạch theo mốc này.
        "due_at": row.get("due_at"),
        "created_at": row["created_at"],
        "started_at": row["started_at"],
        "finished_at": row["finished_at"],
        # V4.0 — lease + phụ thuộc + chống trùng (không có gì nhạy cảm:
        # chỉ id của Muse đang giữ và mốc hạn giữ lệnh).
        "attempts": row.get("attempts") or 0,
        # V6.0: trạng thái kiểm tra chéo của lệnh (vòng làm lại +
        # kết luận gần nhất) để phiên Muse đối chiếu khi làm lại.
        "review_round": row.get("review_round") or 0,
        "last_verdict": row.get("last_verdict") or "",
        "lease_agent_id": row.get("lease_agent_id"),
        "lease_expires_at": row.get("lease_expires_at"),
        "depends_on": row.get("depends_on"),
        "idempotency_key": row.get("idempotency_key"),
        "deduplicated": bool(row.get("deduplicated")),
        # V6.3: BỘ QUY TẮC bắt buộc + chỉ tiêu KPI áp cho lệnh này
        # (lệnh 'review' nhận quy tắc giám sát, còn lại quy tắc nhân viên).
        "rules": _rules_for(row),
    }


_RULES_CACHE: dict = {"mtime": None, "settings": None}


def _rules_for(row: dict) -> dict | None:
    """Quy tắc kèm lệnh — settings đọc lại chỉ khi file settings.json
    đổi (mtime), không đọc đĩa cho từng lệnh trong danh sách."""
    try:
        from . import kpi

        path = config.settings_path() if hasattr(config, "settings_path") else config.data_dir() / "settings.json"
        mtime = path.stat().st_mtime if path.exists() else 0
        if _RULES_CACHE["mtime"] != mtime or _RULES_CACHE["settings"] is None:
            _RULES_CACHE["settings"] = config.load_settings()
            _RULES_CACHE["mtime"] = mtime
        return kpi.rules_for_command(row, _RULES_CACHE["settings"])
    except Exception:
        return None


def _parse_ui_owner(value) -> bool:
    """True nếu cửa sổ app vừa nhận vai chạy trưởng phòng (< 2 phút)."""
    if not value:
        return False
    try:
        at = datetime.fromisoformat(str(value))
    except ValueError:
        return False
    if at.tzinfo is None:
        at = at.astimezone()
    return (datetime.now().astimezone() - at).total_seconds() < 120


class _QuietHTTPServer(ThreadingHTTPServer):
    """V6.3: máy Muse (qua Tailscale) hay đóng ngang kết nối giữ-sống
    (keep-alive) → WinError 10054 'forcibly closed by the remote host'
    in nguyên traceback ra console mỗi lần. Đó là chuyện bình thường
    của HTTP keep-alive, không phải lỗi app → nuốt êm nhóm lỗi đứt kết
    nối; lỗi khác vẫn in như cũ."""

    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys

        exc = sys.exc_info()[1]
        if isinstance(exc, sqlite3.OperationalError):
            # V6.4.4: một dòng ngắn thay vì nguyên traceback.
            print(f"[Agent API] Dữ liệu đang bận ({exc}) — lời gọi từ {client_address[0]} được báo thử lại.")
            return
        if isinstance(exc, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, TimeoutError)):
            return
        if isinstance(exc, OSError) and getattr(exc, "winerror", None) in (10053, 10054, 10060):
            return
        super().handle_error(request, client_address)


# --------------------------------------------------------------------------- #
# Tiện ích
# --------------------------------------------------------------------------- #
def api_agent_shape(agent: dict, include_token: bool = False) -> dict:
    """Định hình một tài khoản Muse (agent) trả qua API. Token riêng
    CHỈ kèm theo khi include_token=True (phía quản trị/phiếu kết nối);
    các lời gọi thường không bao giờ nhận token của agent khác."""
    shape = {
        "id": agent["id"],
        "name": agent["name"],
        "email": agent["email"],
        "note": agent.get("note") or "",
        "revoked": bool(agent.get("revoked")),
        "status": agent.get("status") or "offline",
        "last_seen_at": agent.get("last_seen_at"),
        "current_command_id": agent.get("current_command_id") or "",
        "web_state": agent.get("web_state") or "unknown",
        "profile_ids": agent.get("profile_ids") or [],
        "created_at": agent.get("created_at"),
    }
    if include_token:
        shape["token"] = agent.get("token") or ""
    return shape


def api_message_shape(row: dict) -> dict:
    """Định hình một tin chat (V4.6) trả qua API: đúng các trường
    hai phía cần — KHÔNG kèm gì ngoài luồng của chính agent đó."""
    return {
        "id": row["id"],
        "agent_id": row["agent_id"],
        "direction": row["direction"],
        "body": row["body"],
        "command_id": row.get("command_id"),
        "created_at": row["created_at"],
        "read_at": row.get("read_at"),
    }


def sanitize_file_name(raw: str | None) -> str:
    """Rút tên file về basename an toàn (bỏ mọi phần thư mục, cả '/' lẫn
    '\\\\'), thay ký tự lạ bằng '_'. Rỗng/không hợp lệ → 'file'."""
    name = (raw or "").strip()
    name = name.replace("\\", "/").split("/")[-1]
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name).strip("._")
    return name or "file"


def ensure_agent_token(settings: dict, base: Path | None = None) -> str:
    """Lấy token từ settings; chưa có thì sinh mới và LƯU vào settings.json."""
    token = str(settings.get("agent_token") or "").strip()
    if not token:
        token = secrets.token_urlsafe(32)
        settings["agent_token"] = token
        config.save_settings(settings, base)
    return token


# --------------------------------------------------------------------------- #
# AgentServer
# --------------------------------------------------------------------------- #
class AgentServer:
    """HTTP server + hàng đợi lệnh một-luồng-thực-thi.

    Tham số tiêm (inject) phục vụ kiểm thử:
    - ``manager``: ChromeManager (hoặc bản giả có launch/is_running/connect_page).
    - ``scan_fn``: hàm quét theo chữ ký ``scanner.scan_profile(store, profile,
      manager, log=None)``.
    """

    def __init__(
        self,
        data_dir: str | Path | None = None,
        settings: dict | None = None,
        manager: ChromeManager | None = None,
        scan_fn=None,
        auto_hooks=None,
        auto_tick_fn=None,
    ):
        self._data_dir = Path(data_dir) if data_dir is not None else config.data_dir()
        self._data_dir.mkdir(parents=True, exist_ok=True)
        self._settings = settings if settings is not None else config.load_settings(self._data_dir)
        self.port = int(self._settings.get("agent_port", DEFAULT_AGENT_PORT))
        # V3.1: tuỳ chọn chỉ nghe localhost (an toàn hơn khi không cần
        # Tailscale) — mặc định giữ hành vi cũ là mọi interface.
        self.bind_host = (
            "127.0.0.1" if self._settings.get("agent_bind_localhost") else "0.0.0.0"
        )
        # Mốc lần gọi API gần nhất của phía Muse (cho thanh trạng thái
        # của app biết cầu nối có đang "sống" không).
        self._last_client_at: float | None = None
        self.token = ensure_agent_token(self._settings, self._data_dir)
        # V6.1: hạn chót theo loại lệnh lấy từ cài đặt (dùng chung lớp Store).
        Store.set_deadline_minutes(self._settings.get("deadline_minutes") or {})
        self._manager = manager if manager is not None else ChromeManager()
        self._scan_fn = scan_fn if scan_fn is not None else scanner.scan_profile

        self._httpd: ThreadingHTTPServer | None = None
        self._server_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._worker_thread: threading.Thread | None = None
        self._running = False

        # V4.0 — Vòng tự động (Đ4): dispatcher + sweeper lease chạy trong
        # vòng lặp worker sẵn có của server, nhịp 15 giây, KHÔNG QTimer.
        # ``auto_hooks``: tham số cũ (preflight trình duyệt/đăng nhập)
        # — từ V4.1.2 KHÔNG còn được dùng cho đường giao lệnh (lệnh
        # tới thẳng Muse, xem _run_auto_tick); giữ thuộc tính để
        # tương thích nơi khởi tạo cũ. ``auto_tick_fn``: thay toàn bộ nhịp
        # tự động (kiểm thử). Long-poll (H6) dùng Condition + số thế hệ:
        # mỗi lần có lệnh chuyển 'waiting_muse' thì notify_commands_changed
        # đánh thức mọi lời gọi GET ?wait= đang treo.
        self._auto_hooks = auto_hooks
        self._auto_tick_fn = auto_tick_fn
        self._auto_tick_interval = 15.0
        self._last_auto_tick = 0.0
        self._commands_cond = threading.Condition()
        self._commands_gen = 0
        # V4.6: long-poll TIN NHẮN CHAT dùng Condition + số thế hệ
        # riêng (cùng mẫu H6 của lệnh): tin user mới (do UI ghi qua
        # notify_messages_changed, hoặc chính server nhận qua API)
        # đánh thức ngay lời gọi GET messages?unread=1&wait= đang treo.
        self._messages_cond = threading.Condition()
        self._messages_gen = 0
        # V4.1.1: "gọi điều phối NGAY" — UI (nút ▶ Chạy ngay) set event
        # này để vòng worker chạy một nhịp dispatcher tức thì thay vì
        # chờ đủ khoảng 15 giây. Vòng worker đang rảnh thì chờ trên
        # chính event này (timeout 0.1s giữ nhịp rà kho cũ) nên event
        # vừa set là worker thức ngay; _maybe_auto_tick tiêu thụ
        # (clear) event và bỏ qua cổng khoảng thời gian đúng một nhịp.
        self._dispatch_event = threading.Event()
        # V6.3: nhận FILE LỚN theo khúc / kéo từ link (app/large_files.py).
        from .large_files import LargeFiles

        self.large_files = LargeFiles(
            self._data_dir,
            max_bytes=int(float(self._settings.get("large_file_max_gb", 50) or 50) * 1024 ** 3),
            journal=lambda message: self._journal(message),
            command_dir_for=lambda command_id: config.command_files_dir(command_id, base=self._data_dir),
        )

    # ------------------------------------------------------------------ #
    # V4.0 — Tiện ích vòng tự động + long-poll
    # ------------------------------------------------------------------ #
    def _lease_seconds(self) -> int:
        try:
            return max(10, int(self._settings.get("lease_seconds", 120)))
        except (TypeError, ValueError):
            return 120

    def notify_commands_changed(self) -> None:
        """Đánh thức các lời gọi long-poll đang treo (H6): có lệnh vừa
        chuyển trạng thái đáng chú ý (thường là sang 'waiting_muse')."""
        with self._commands_cond:
            self._commands_gen += 1
            self._commands_cond.notify_all()

    def _wait_commands_change(self, generation: int, timeout: float) -> None:
        with self._commands_cond:
            self._commands_cond.wait_for(
                lambda: self._commands_gen != generation, timeout=timeout
            )

    def notify_messages_changed(self) -> None:
        """V4.6 — Đánh thức các lời gọi long-poll tin nhắn đang treo:
        có tin chat mới ở bất kỳ luồng nào (UI gọi sau khi người dùng
        gửi tin; handler API gọi sau khi một Muse trả lời). An toàn
        đa luồng — UI gọi từ luồng giao diện thoải mái."""
        with self._messages_cond:
            self._messages_gen += 1
            self._messages_cond.notify_all()

    def _wait_messages_change(self, generation: int, timeout: float) -> None:
        with self._messages_cond:
            self._messages_cond.wait_for(
                lambda: self._messages_gen != generation, timeout=timeout
            )

    def request_dispatch_now(self) -> None:
        """V4.1.1 — Yêu cầu dispatcher xét lệnh NGAY ở nhịp worker kế
        (an toàn đa luồng, gọi từ luồng UI thoải mái). Chỉ bỏ qua cổng
        KHOẢNG THỜI GIAN 15 giây — công tắc vòng tự động
        (full_auto_enabled) và auto_tick_fn tiêm vào vẫn giữ nguyên
        hiệu lực như nhịp thường."""
        self._dispatch_event.set()

    def _maybe_auto_tick(self) -> None:
        import time as _time

        forced = self._dispatch_event.is_set()
        if forced:
            self._dispatch_event.clear()
        now_m = _time.monotonic()
        if not forced and now_m - self._last_auto_tick < self._auto_tick_interval:
            return
        self._last_auto_tick = now_m
        try:
            if self._auto_tick_fn is not None:
                self._auto_tick_fn(self)
                return
            if not self._settings.get("full_auto_enabled", True):
                return
            self._run_auto_tick()
        except Exception as exc:
            # V4.2 (O-06): nhịp tự động lỗi KHÔNG được làm sập vòng
            # worker/API — nhưng cũng KHÔNG còn nuốt lặng: ghi log
            # có cấu trúc + trạng thái sức khoẻ để UI cảnh báo.
            self._record_automation_error("auto_tick", exc)

    def _record_automation_error(self, source: str, exc: BaseException) -> None:
        """Ghi nhận lỗi vòng tự động vào automation health (best
        effort — chính việc ghi nhận cũng không được phép nổ)."""
        from . import automation_health

        try:
            store = self._new_store()
            try:
                automation_health.record_error(store, source, exc)
            finally:
                store.close()
        except Exception:
            pass

    def _run_auto_tick(self) -> None:
        from . import automation_health
        from .dispatcher import Dispatcher
        from .lease_sweeper import LeaseSweeper

        store = self._new_store()
        swept: dict = {}
        promoted: list = []
        healthy = True
        try:
            # V4.2 (O-06): sweeper và dispatcher lỗi ĐỘC LẬP — một
            # bên lỗi không chặn bên kia chạy, và lỗi nào cũng được
            # ghi vào automation health thay vì nuốt lặng.
            try:
                sweeper = LeaseSweeper(
                    store,
                    lease_seconds=self._lease_seconds(),
                    max_attempts=int(self._settings.get("max_attempts", 3) or 3),
                    wait_alert_minutes=int(
                        self._settings.get("wait_alert_minutes", 10) or 10
                    ),
                )
                swept = sweeper.sweep_once()
            except Exception as exc:
                healthy = False
                automation_health.record_error(store, "sweeper", exc)
            # V4.5: TỰ CHẠY LẠI lệnh thất bại đã tới hạn 30s — chạy
            # TRƯỚC dispatcher để lệnh Muse vừa xếp lại được xét
            # điều kiện và đẩy lên 'waiting_muse' ngay trong cùng
            # nhịp (hook sẽ đánh thức Muse như lệnh mới).
            # V6.0: WATCHDOG giám sát chéo — quét lệnh nghi treo và
            # sinh việc kiểm tra 'stuck' (app.supervision tự tiết lưu
            # 30s + cổng enabled). Chạy TRƯỚC dispatcher để việc kiểm
            # tra vừa sinh được xét promote ngay trong cùng nhịp. Lỗi
            # độc lập như sweeper/dispatcher (O-06).
            try:
                from . import supervision

                watchdog_created = supervision.watchdog_scan(
                    store, settings=self._settings
                )
                if watchdog_created:
                    swept["supervision_reviews"] = [
                        r["id"] for r in watchdog_created
                    ]
            except Exception as exc:
                healthy = False
                automation_health.record_error(store, "supervision", exc)
            # V6.3: TRƯỞNG PHÒNG tự xử lý sự cố trong phạm vi cho phép
            # (tự tiết lưu 60 giây) + tự thay trưởng phòng khi KPI kém.
            try:
                from . import lead_autopilot

                # V6.5: cửa sổ app đang chạy trưởng phòng (có đường gửi
                # thật qua chat muse.ai) → cầu nối API nhường, không chạy trùng.
                owner_at = _parse_ui_owner(store.get_meta(lead_autopilot.UI_OWNER_KEY))
                decided = [] if owner_at else lead_autopilot.run(
                    store, self._settings,
                    save_settings=lambda data: config.save_settings(data, self._data_dir),
                )
                if decided:
                    swept["lead_decisions"] = [d["id"] for d in decided]
                    self.notify_messages_changed()
                    self.notify_commands_changed()
            except Exception as exc:
                healthy = False
                automation_health.record_error(store, "lead_autopilot", exc)
            try:
                retried = store.process_auto_retries()
                for row in retried:
                    self._journal(
                        f"[Tự động] Lệnh #{row['id']} ({row['type']}) thất bại"
                        " — đã tự xếp hàng chạy lại sau 30 giây.",
                        row.get("profile_id"),
                    )
                if retried:
                    swept["auto_retried"] = [r["id"] for r in retried]
            except Exception as exc:
                healthy = False
                automation_health.record_error(store, "auto_retry", exc)
            try:
                # V4.1.2 (yêu cầu người dùng 2026-10-29): dispatcher
                # chạy KHÔNG hooks preflight trình duyệt/đăng nhập —
                # dù nơi tạo server có truyền auto_hooks, đường giao
                # lệnh cũng không dùng chúng. Lệnh đã cấp là tới
                # thẳng Muse; việc mở web/đăng nhập do Muse xử lý
                # trong lúc chạy lệnh. (V4.2: tham số hooks đã là
                # tương thích cũ, dispatcher bỏ qua hoàn toàn.)
                dispatcher = Dispatcher(
                    store,
                    hooks=None,
                    data_dir=self._data_dir,
                    on_error=lambda src, exc: automation_health.record_error(
                        store, src, exc
                    ),
                )
                promoted = dispatcher.tick()
            except Exception as exc:
                healthy = False
                automation_health.record_error(store, "dispatcher", exc)
            if healthy:
                automation_health.record_ok(store)
        finally:
            store.close()
        if promoted or swept.get("requeued") or swept.get("failed") or swept.get("auto_retried") or swept.get("supervision_reviews"):
            self.notify_commands_changed()

    # ------------------------------------------------------------------ #
    # Vòng đời
    # ------------------------------------------------------------------ #
    @property
    def last_client_at(self) -> float | None:
        """Epoch giây của lần gọi API gần nhất (None = chưa ai gọi)."""
        return self._last_client_at

    def start(self) -> None:
        if self._running:
            return
        handler_cls = _make_handler(self)
        self._httpd = _QuietHTTPServer((self.bind_host, self.port), handler_cls)
        self._httpd.daemon_threads = True
        # Cổng thực tế (hữu ích khi cấu hình cổng 0 = hệ điều hành tự chọn).
        self.port = int(self._httpd.server_address[1])
        self._running = True
        self._worker_thread = threading.Thread(
            target=self._worker_loop, name="agent-command-worker", daemon=True
        )
        self._worker_thread.start()
        self._server_thread = threading.Thread(
            target=self._httpd.serve_forever, name="agent-http", daemon=True
        )
        self._server_thread.start()
        self._journal(f"[API] Agent API khởi động tại {self.bind_host}:{self.port} (V2).")
        print(f"[Agent API] Lắng nghe tại http://{self.bind_host}:{self.port} — token trong data/settings.json")

    def stop(self) -> None:
        if not self._running:
            return
        self._running = False
        self._stop_event.set()  # worker đang rà kho sẽ thoát vòng lặp
        self._dispatch_event.set()  # thức worker đang chờ event ngay
        if self._httpd is not None:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
        if self._server_thread is not None:
            self._server_thread.join(timeout=5)
            self._server_thread = None
        if self._worker_thread is not None:
            self._worker_thread.join(timeout=5)
            self._worker_thread = None

    @property
    def running(self) -> bool:
        return self._running

    # ------------------------------------------------------------------ #
    # Truy cập dữ liệu (Store ngắn hạn trong đúng luồng gọi)
    # ------------------------------------------------------------------ #
    def _new_store(self) -> Store:
        return Store(config.db_path(self._data_dir))

    def _journal(self, message: str, profile_id: int | None = None) -> None:
        try:
            store = self._new_store()
            try:
                store.append_journal(message, profile_id)
            finally:
                store.close()
        except Exception:
            pass  # ghi nhật ký lỗi không được phép làm sập API

    def _get_profile(self, slug: str) -> dict | None:
        store = self._new_store()
        try:
            return store.get_profile_by_slug(slug)
        finally:
            store.close()

    # ------------------------------------------------------------------ #
    # Thực thi thao tác (dùng chung cho endpoint trực tiếp và hàng đợi)
    # ------------------------------------------------------------------ #
    def _do_open_browser(self, profile: dict) -> dict:
        state = self._manager.launch(profile)
        self._journal(
            f"[API] Mở Chrome hồ sơ '{profile['label']}' ({profile['slug']}): {state}.",
            profile["id"],
        )
        return {"slug": profile["slug"], "chrome": state}

    def _do_scan(self, profile: dict) -> dict:
        store = self._new_store()
        try:
            result = self._scan_fn(store, profile, self._manager)
        finally:
            store.close()
        channels = result.get("channels") or []
        summary = {
            "slug": profile["slug"],
            "status": result.get("status", "ok"),
            "channels_found": len(channels),
            "message": result.get("message", ""),
        }
        self._journal(
            f"[API] Quét hồ sơ '{profile['label']}' ({profile['slug']}): "
            f"trạng thái {summary['status']}, {summary['channels_found']} kênh.",
            profile["id"],
        )
        return summary

    def _do_navigate(self, profile: dict, url: str) -> dict:
        client = self._manager.connect_page(profile)
        try:
            client.navigate(url)
        finally:
            client.close()
        self._journal(
            f"[API] Điều hướng Chrome hồ sơ '{profile['label']}' ({profile['slug']}) tới {url}.",
            profile["id"],
        )
        return {"slug": profile["slug"], "url": url}

    # ------------------------------------------------------------------ #
    # V4.3 — Hành động CDP TRONG trang nhúng (cdp_evaluate/cdp_click/
    # cdp_type): bọc quanh primitive sẵn có của app.cdp (evaluate,
    # dispatch_mouse, dispatch_key/call) và CHỤP ẢNH XÁC NHẬN sau mỗi
    # hành động vào data/screenshots/ — Muse đọc tên file ảnh trong
    # kết quả để tự kiểm chứng thay vì đoán trang đã đổi chưa.
    # ------------------------------------------------------------------ #
    def _do_cdp_act(self, profile: dict, record: dict) -> dict:
        import json as _json

        from . import cdp_vision

        ctype = record["type"]
        payload = record.get("payload") or {}
        client = self._manager.connect_page(profile)
        who = self._agent_label_for(record)
        try:
            if ctype == "cdp_snapshot":
                cdp_vision.overlay(client, f"🤖 {who}: đang đọc trang")
                outcome = {"snapshot": cdp_vision.snapshot(client, int(payload.get("max_elements") or 150))}
            elif ctype == "cdp_evaluate":
                expression = str(payload.get("expression") or "").strip()
                if not expression:
                    raise ValueError("Lệnh cdp_evaluate thiếu payload.expression")
                value = client.evaluate(expression)
                if not isinstance(value, (str, int, float, bool, type(None))):
                    value = _json.dumps(value, ensure_ascii=False, default=str)
                if isinstance(value, str) and len(value) > 4000:
                    value = value[:4000] + "…(cắt bớt)"
                outcome = {"value": value}
            elif ctype == "cdp_click":
                outcome = {"clicked": self._cdp_click(client, payload)}
                clicked = outcome["clicked"]
                cdp_vision.overlay(client, f"🤖 {who}: bấm «{clicked.get('text') or clicked.get('tag')}»",
                                   clicked.get("x"), clicked.get("y"))
            elif ctype == "cdp_type":
                outcome = {"typed": self._cdp_type(client, payload)}
                cdp_vision.overlay(client, f"🤖 {who}: gõ {outcome['typed'].get('chars')} ký tự")
            else:  # chốt chặn cuối — _execute chỉ rẽ nhánh CDP vào đây
                raise ValueError(f"Loại lệnh không hỗ trợ: {ctype}")
            if ctype != "cdp_snapshot" and payload.get("snapshot", True):
                # V6.3: Muse "nhìn" được trang sau thao tác (chữ + phần tử).
                import time as _t

                _t.sleep(float(payload.get("settle_seconds") or 0.8))
                try:
                    outcome["page"] = cdp_vision.compact(cdp_vision.snapshot(client))
                except Exception:
                    pass
            shot = self._save_cdp_screenshot(client, record["id"])
            if shot:
                outcome["screenshot"] = shot
                outcome["screenshot_api"] = f"/api/screenshots/{shot}"
            self._record_parent_step(record, ctype, outcome)
        finally:
            client.close()
        self._journal(
            f"[API] {ctype} trong Chrome hồ sơ '{profile['label']}' "
            f"({profile['slug']}): {str(outcome)[:200]}",
            profile["id"],
        )
        return {"slug": profile["slug"], **outcome}

    def _agent_label_for(self, record: dict) -> str:
        agent_id = record.get("agent_id") or record.get("lease_agent_id")
        if not agent_id:
            return "Muse"
        store = self._new_store()
        try:
            agent = store.get_agent(int(agent_id))
        except Exception:
            agent = None
        finally:
            store.close()
        return (agent or {}).get("name") or "Muse"

    def _record_parent_step(self, record: dict, ctype: str, outcome: dict) -> None:
        """V6.3: thao tác CDP ghi thành MỘT BƯỚC của lệnh cha (payload
        parent_command_id) → bảng việc chi tiết hiện đúng Muse đã bấm/gõ gì."""
        parent = str((record.get("payload") or {}).get("parent_command_id") or "").strip()
        if not parent:
            return
        detail = {
            "cdp_click": lambda o: f"Bấm «{(o.get('clicked') or {}).get('text') or ''}»",
            "cdp_type": lambda o: f"Gõ {(o.get('typed') or {}).get('chars')} ký tự",
            "cdp_navigate": lambda o: f"Mở {o.get('url') or ''}",
            "cdp_evaluate": lambda o: "Đọc dữ liệu trang",
        }.get(ctype, lambda o: ctype)(outcome)
        page = (outcome.get("page") or {}).get("title")
        store = self._new_store()
        try:
            parent_row = store.get_command(parent)
            if parent_row is None:
                return
            store._conn.execute(
                "INSERT INTO command_steps (command_id, at, progress, step, actor) VALUES (?, ?, ?, ?, ?)",
                (parent, now_iso(), int(parent_row.get("progress") or 0),
                 f"🖱 {detail}" + (f" — trang: {page}" if page else ""),
                 f"agent:{record.get('agent_id')}" if record.get("agent_id") else "cdp"),
            )
            store._conn.commit()
        except Exception:
            pass
        finally:
            store.close()

    @staticmethod
    def _cdp_click(client, payload: dict) -> dict:
        """Tìm phần tử (theo selector, hoặc theo chữ nhìn thấy) trong
        trang, cuộn tới, rồi dispatch chuột THẬT vào tâm phần tử.
        Trả mô tả phần tử đã bấm; không thấy → ValueError rõ lý do."""
        import json as _json

        from . import cdp_vision

        selector = str(payload.get("selector") or "")
        text = str(payload.get("text") or "")
        # V6.3: bộ tìm rộng (selector / element số thứ tự snapshot /
        # aria-label / chữ — khớp đúng trước) trên MỌI vai trò tương tác.
        info = cdp_vision.find(client, payload)
        if info and info.get("visible"):
            x, y = float(info["x"]), float(info["y"])
            for event_type in ("mousePressed", "mouseReleased"):
                client.dispatch_mouse({"type": event_type, "x": x, "y": y,
                                       "button": "left", "clickCount": 1})
            return {"tag": info.get("tag"), "text": info.get("text"), "x": x, "y": y}
        finder = """
(() => {
  const selector = %s, wanted = %s;
  let el = null;
  if (selector) el = document.querySelector(selector);
  if (!el && wanted) {
    const needle = wanted.trim().toLowerCase();
    const candidates = document.querySelectorAll(
      'button, a, [role="button"], input[type="button"], input[type="submit"]');
    for (const node of candidates) {
      const label = (node.innerText || node.value || '').trim().toLowerCase();
      if (label && label.includes(needle)) { el = node; break; }
    }
  }
  if (!el) return null;
  el.scrollIntoView({block: 'center', inline: 'center'});
  const rect = el.getBoundingClientRect();
  return {
    tag: el.tagName, text: (el.innerText || el.value || '').trim().slice(0, 80),
    x: rect.left + rect.width / 2, y: rect.top + rect.height / 2,
    visible: rect.width > 0 && rect.height > 0,
  };
})()
""" % (_json.dumps(selector), _json.dumps(text))
        info = client.evaluate(finder)
        if not info:
            raise ValueError(
                "Không tìm thấy phần tử để bấm "
                f"(selector={selector!r}, text={text!r})"
            )
        if not info.get("visible"):
            raise ValueError(f"Phần tử đã tìm thấy nhưng không hiển thị: {info}")
        x, y = float(info["x"]), float(info["y"])
        for event_type in ("mousePressed", "mouseReleased"):
            client.dispatch_mouse(
                {
                    "type": event_type, "x": x, "y": y,
                    "button": "left", "clickCount": 1,
                }
            )
        return {"tag": info.get("tag"), "text": info.get("text"), "x": x, "y": y}

    @staticmethod
    def _cdp_type(client, payload: dict) -> dict:
        """Gõ chữ: có selector thì focus đúng ô trước (bấm vào ô), rồi
        chèn chữ bằng Input.insertText (kích hoạt sự kiện input như gõ
        thật). Không selector = gõ vào phần tử đang focus."""
        text = str(payload.get("text") or "")
        if not text:
            raise ValueError("Lệnh cdp_type thiếu payload.text")
        selector = str(payload.get("selector") or "")
        if selector:
            import json as _json

            focused = client.evaluate(
                "(() => { const el = document.querySelector(%s);"
                " if (!el) return false; el.focus();"
                " if (typeof el.select === 'function') el.select();"
                " return true; })()" % _json.dumps(selector)
            )
            if not focused:
                raise ValueError(f"Không tìm thấy ô để gõ: selector={selector!r}")
        client.call("Input.insertText", {"text": text})
        return {"chars": len(text), "selector": selector or None}

    @staticmethod
    def _save_cdp_screenshot(client, command_id: str) -> str | None:
        """Chụp khung hình trang sau hành động, lưu vào thư mục
        screenshots của app. Chụp hỏng KHÔNG làm hỏng hành động —
        trả None và bỏ qua (hành động đã xong, ảnh chỉ để xác nhận)."""
        try:
            png = client.capture_screenshot_png()
            folder = config.screenshots_dir()
            folder.mkdir(parents=True, exist_ok=True)
            name = f"cdp-{str(command_id)[:8]}.png"
            (folder / name).write_bytes(png)
            return name
        except Exception:
            return None

    def _do_studio_script(self, profile: dict | None, record: dict) -> dict:
        """V4.4: chạy kịch bản Studio (payload.steps) trong Chrome
        NHÚNG của hồ sơ đích bằng runner dùng chung
        app/studio_script.py. Chrome chưa chạy thì mở lên đúng hồ sơ.
        File của bước upload được resolve trong thư mục file RIÊNG
        của lệnh (data/command_files/<id>/ — file giao qua
        POST /api/inbox kèm header X-Command-Id). Tiến độ ghi thẳng
        vào lệnh (progress % + mô tả bước) để UI/API theo dõi được.
        StudioNeedsUser/StudioStepError propagate lên _execute."""
        if profile is None:
            raise ValueError("Lệnh studio_script cần hồ sơ đích (profile)")
        payload = record.get("payload") or {}
        steps = payload.get("steps") or []
        errors = studio_script.validate_steps(steps)
        if errors:
            raise ValueError("Kịch bản Studio không hợp lệ: " + "; ".join(errors[:4]))
        command_id = str(record.get("id") or "")
        store = self._new_store()

        def resolve_file(name):
            if not studio_script.is_safe_file_ref(name):
                raise ValueError(f"Tên file không hợp lệ trong bước upload: {name!r}")
            path = config.command_files_dir(command_id, base=self._data_dir) / name
            if not path.is_file():
                raise FileNotFoundError(
                    f"Chưa có file '{name}' được giao kèm lệnh này "
                    "(POST /api/inbox với header X-Command-Id trước khi chạy)"
                )
            return path

        client_holder: dict = {}

        def save_screenshot(name):
            png = client_holder["client"].capture_screenshot_png()
            folder = config.screenshots_dir(self._data_dir)
            folder.mkdir(parents=True, exist_ok=True)
            file_name = f"studio-{command_id[:8]}-{name}.png"
            (folder / file_name).write_bytes(png)
            return file_name

        def report_progress(percent, step_text):
            try:
                store.update_command_progress(
                    command_id, progress=int(percent), step=str(step_text)[:160]
                )
            except Exception:
                pass  # tiến độ là phụ

        client = None
        try:
            if not self._manager.is_running(profile):
                self._manager.launch(profile)
            client = self._manager.connect_page(profile)
            client_holder["client"] = client
            return studio_script.run_studio_script(
                client,
                steps,
                resolve_file=resolve_file,
                save_screenshot=save_screenshot,
                progress=report_progress,
            )
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass
            store.close()

    # ------------------------------------------------------------------ #
    # Hàng đợi lệnh — bền vững trong bảng commands của kho (dùng chung UI)
    # ------------------------------------------------------------------ #
    def enqueue_command(self, command: dict, agent_id: int | None = None) -> dict:
        slug = command.get("profile")
        profile = self._get_profile(slug) if slug else None
        store = self._new_store()
        try:
            row = store.create_command(
                command.get("type"),
                source="api",
                profile_id=profile["id"] if profile else None,
                profile_slug=slug,
                channel_id=str(command.get("channel_id") or ""),
                instruction=str(command.get("instruction") or ""),
                payload=command.get("payload") or {},
                status="queued",
                agent_id=agent_id,
                idempotency_key=command.get("idempotency_key"),
                depends_on=command.get("depends_on"),
                # V6.1: Muse/hook có thể tự đặt hạn chót (ISO); không
                # truyền → hạn mặc định theo loại lệnh.
                due_at=(str(command["due_at"]) if command.get("due_at") else None),
            )
        finally:
            store.close()
        return api_command_shape(row)

    def get_command(self, command_id: str) -> dict | None:
        store = self._new_store()
        try:
            row = store.get_command(command_id)
        finally:
            store.close()
        return api_command_shape(row) if row else None

    def list_commands(
        self, status: str | None = None, source: str | None = None, limit: int = 100
    ) -> list[dict]:
        store = self._new_store()
        try:
            rows = store.list_commands(source=source, status=status, limit=limit)
        finally:
            store.close()
        return [api_command_shape(r) for r in rows]

    def _worker_loop(self) -> None:
        """Rà kho tìm lệnh API đang 'queued', nhận (claim) và thực thi —
        một lệnh một lúc, theo thứ tự tạo."""
        while not self._stop_event.is_set():
            # V4.0 (Đ4): nhịp dispatcher + sweeper lease chạy tại đây.
            self._maybe_auto_tick()
            store = self._new_store()
            try:
                queued = store.list_commands(source="api", status="queued", limit=50)
                queued.reverse()  # list_commands mới-nhất-trước -> chạy cũ trước
                claimed_id = None
                for row in queued:
                    # V4.0: worker này chỉ thi hành lệnh app-tự-làm được;
                    # lệnh chờ Muse ở 'queued' thuộc về dispatcher —
                    # KHÔNG claim ở đây (sẽ thành "loại lệnh không hỗ trợ").
                    if row["type"] not in COMMAND_TYPES:
                        continue
                    if store.claim_command(row["id"]):
                        claimed_id = row["id"]
                        break
            finally:
                store.close()
            if claimed_id is None:
                # V4.1.1: chờ trên event "điều phối ngay" — có yêu cầu
                # Chạy ngay thì thức TỨC THÌ để _maybe_auto_tick ở đầu
                # vòng kế chạy dispatcher; không có thì giữ nhịp rà
                # 0.1s như cũ (điều kiện dừng vẫn xét ở đầu vòng lặp).
                self._dispatch_event.wait(0.1)
                continue
            self._execute(claimed_id)

    def _execute(self, command_id: str) -> None:
        record = self.get_command(command_id)
        if record is None:
            return
        profile = None
        store = self._new_store()
        try:
            try:
                if record["profile"]:
                    profile = self._get_profile(record["profile"])
                    if profile is None:
                        raise LookupError(f"Không thấy hồ sơ '{record['profile']}'")
                ctype = record["type"]
                if ctype == "open_browser":
                    result = self._do_open_browser(profile)
                elif ctype == "scan":
                    result = self._do_scan(profile)
                elif ctype == "cdp_navigate":
                    url = str(record["payload"].get("url") or "").strip()
                    if not url:
                        raise ValueError("Lệnh cdp_navigate thiếu payload.url")
                    result = self._do_navigate(profile, url)
                elif ctype == "studio_script":
                    result = self._do_studio_script(profile, record)
                elif ctype in CDP_COMMAND_TYPES:
                    result = self._do_cdp_act(profile, record)
                else:  # đã validate ở tầng HTTP, đây là chốt chặn cuối
                    raise ValueError(f"Loại lệnh không hỗ trợ: {ctype}")
                store.finish_command(command_id, "done", result_json=result)
            except studio_script.StudioNeedsUser as exc:
                # V4.4: kịch bản chạm tường đăng nhập/OTP/CAPTCHA —
                # lệnh chờ NGƯỜI xử lý trong Chrome nhúng, không fail.
                store.set_command_needs_user(command_id, str(exc))
                self._journal(
                    f"[API] Lệnh studio_script (hồ sơ: {record['profile'] or '—'})"
                    f" CHỜ NGƯỜI: {exc}",
                    profile["id"] if profile else None,
                )
            except studio_script.StudioStepError as exc:
                # Kèm kết quả dở dang (bước nào xong/hỏng, ảnh lỗi) để
                # phía Muse đọc được mà không phải đoán.
                store.finish_command(
                    command_id, "failed", error=str(exc), result_json=exc.result
                )
                self._journal(
                    f"[API] Lệnh studio_script (hồ sơ: {record['profile'] or '—'})"
                    f" THẤT BẠI: {exc}",
                    profile["id"] if profile else None,
                )
            except Exception as exc:
                store.finish_command(command_id, "failed", error=str(exc))
                self._journal(
                    f"[API] Lệnh {record['type']} (hồ sơ: {record['profile'] or '—'})"
                    f" THẤT BẠI: {exc}",
                    profile["id"] if profile else None,
                )
        finally:
            store.close()

    # ------------------------------------------------------------------ #
    # Điều phối HTTP — trả (status_code, dict) để dễ kiểm thử
    # ------------------------------------------------------------------ #
    def dispatch(
        self,
        method: str,
        raw_path: str,
        headers: dict,
        body: bytes,
    ) -> tuple[int, dict]:
        parsed = urlparse(raw_path)
        parts = [p for p in parsed.path.split("/") if p]
        query = parse_qs(parsed.query)

        # /api/health là endpoint DUY NHẤT không cần token.
        if method == "GET" and parts == ["api", "health"]:
            import time as _time

            self._last_client_at = _time.time()
            return 200, {"ok": True, "app": APP_NAME, "version": AGENT_API_VERSION}

        caller = self._authenticate(headers)
        if caller is None:
            return 401, {"ok": False, "error": "unauthorized: thiếu hoặc sai X-Agent-Token"}

        import time as _time

        self._last_client_at = _time.time()
        # V3.8: ghi nhận hoạt động cầu nối (mọi lời gọi ĐÃ XÁC THỰC) —
        # đây là bằng chứng duy nhất đáng tin rằng "có Muse đang nghe
        # lệnh"; UI dùng nó để cảnh báo khi chưa ai kết nối thay vì để
        # lệnh nằm im ở trạng thái Chờ Muse vô thời hạn.
        _bridge_store = self._new_store()
        try:
            _bridge_store.note_bridge_activity(
                caller["agent"]["id"] if caller["kind"] == "agent" else None
            )
        finally:
            _bridge_store.close()
        if caller["kind"] == "agent":
            # Mọi lời gọi hợp lệ của một Muse đều là nhịp sống của nó.
            # V4.2 (O-12): NGOẠI TRỪ chính endpoint heartbeat tường
            # minh — handler của nó tự ghi nhịp (kèm lệnh đang giữ +
            # gia hạn lease); ghi ở đây nữa là hai lần chạm DB cho
            # một nhịp (lỗi ghi trùng bản cũ).
            is_own_heartbeat = (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "agents"]
                and parts[3] == "heartbeat"
                and parts[2] == str(caller["agent"]["id"])
            )
            if not is_own_heartbeat:
                # V6.4.4: nhịp sống KHÔNG được làm hỏng lời gọi — bản nhẹ
                # (chỉ ghi khi đã quá 15 giây) và bận khoá thì bỏ qua nhịp này.
                try:
                    store = self._new_store()
                    try:
                        store.touch_agent_heartbeat_light(
                            caller["agent"]["id"], min_interval_seconds=15.0)
                    finally:
                        store.close()
                except sqlite3.OperationalError:
                    pass
        try:
            if method == "GET" and parts == ["api", "profiles"]:
                return 200, {"ok": True, "profiles": self._profiles_with_channels()}

            if method == "GET" and parts == ["api", "journal"]:
                limit = self._parse_limit(query)
                store = self._new_store()
                try:
                    entries = store.list_journal(limit=limit)
                finally:
                    store.close()
                return 200, {"ok": True, "entries": entries}

            if method == "POST" and parts == ["api", "inbox"]:
                return self._handle_inbox(headers, body)

            # -------- V6.3: file lớn + quy tắc + KPI -------- #
            if len(parts) >= 3 and parts[:2] == ["api", "files"]:
                return self._handle_files(method, parts, body)
            if method == "GET" and parts == ["api", "files"]:
                return 200, {"ok": True, "files": self.large_files.list_recent()}
            if method == "GET" and len(parts) == 3 and parts[:2] == ["api", "screenshots"]:
                import base64 as _b64

                name = sanitize_file_name(parts[2])
                path = config.screenshots_dir() / name
                if not path.exists():
                    return 404, {"ok": False, "error": f"Không thấy ảnh '{name}'"}
                return 200, {"ok": True, "name": name, "mime": "image/png",
                             "base64": _b64.b64encode(path.read_bytes()).decode("ascii")}
            if method == "GET" and parts == ["api", "rules"]:
                from . import kpi

                cfg = kpi.rules_settings(self._settings)
                return 200, {
                    "ok": True,
                    "agent_rules": cfg["agent_rules"],
                    "supervisor_rules": cfg["supervisor_rules"],
                    "kpi_targets": cfg["targets"],
                    "mandatory": cfg["enforce"],
                }

            if method == "POST" and parts == ["api", "profiles"]:
                return self._handle_create_profile(body)

            # -------- Tài khoản Muse (agents) — V3.3 -------- #
            if parts == ["api", "agents"]:
                if method == "GET":
                    return self._handle_list_agents(caller)
                if method == "POST":
                    return self._handle_create_agent(caller, body)
                return 404, {"ok": False, "error": f"Không có endpoint {method} {parsed.path}"}

            if method == "POST" and parts == ["api", "agents", "bulk"]:
                return self._handle_bulk_agents(caller, body)

            if len(parts) >= 3 and parts[:2] == ["api", "agents"]:
                try:
                    agent_id = int(parts[2])
                except ValueError:
                    return 404, {"ok": False, "error": f"Không thấy tài khoản Muse '{parts[2]}'"}
                if len(parts) == 3 and method == "GET":
                    return self._handle_get_agent(caller, agent_id)
                if len(parts) == 3 and method == "DELETE":
                    return self._handle_delete_agent(caller, agent_id)
                if len(parts) == 4 and method == "POST":
                    action = parts[3]
                    if action == "heartbeat":
                        return self._handle_agent_heartbeat(caller, agent_id, body)
                    if action == "assignments":
                        return self._handle_agent_assignments(caller, agent_id, body)
                    if action == "regenerate-token":
                        return self._handle_agent_token(caller, agent_id)
                    if action == "revoke":
                        return self._handle_agent_revoke(caller, agent_id, body)
                # V4.6: chat hai chiều — /api/agents/{id}/messages[/read]
                if len(parts) == 4 and parts[3] == "messages":
                    if method == "GET":
                        return self._handle_list_messages(caller, agent_id, query)
                    if method == "POST":
                        return self._handle_post_message(caller, agent_id, body)
                if (
                    len(parts) == 5
                    and parts[3] == "messages"
                    and parts[4] == "read"
                    and method == "POST"
                ):
                    return self._handle_mark_messages_read(caller, agent_id, body)
                # V6.3: KPI tuần — /api/agents/{id}/kpi
                if len(parts) == 4 and parts[3] == "kpi" and method == "GET":
                    if caller.get("kind") == "agent" and int(caller["agent"]["id"]) != agent_id:
                        return 403, {"ok": False, "error": "Chỉ xem được KPI của chính mình"}
                    from . import kpi

                    store = self._new_store()
                    try:
                        data = kpi.agent_kpi(store, agent_id, self._settings)
                        from . import supervision as _sup

                        lead = _sup.lead_agent_id(store, self._settings)
                        if lead is not None and int(lead) == agent_id:
                            data["lead"] = kpi.lead_kpi(store, agent_id, self._settings)
                    finally:
                        store.close()
                    return 200, {"ok": True, "kpi": data}
                # V6.0: thẻ điểm tuần — /api/agents/{id}/scorecard
                if len(parts) == 4 and parts[3] == "scorecard" and method == "GET":
                    return self._handle_agent_scorecard(caller, agent_id)
                return 404, {"ok": False, "error": f"Không có endpoint {method} {parsed.path}"}

            if method == "POST" and parts == ["api", "commands"]:
                return self._handle_enqueue(body, caller)

            if (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "commands"]
                and parts[3] == "progress"
            ):
                return self._handle_command_progress(parts[2], body, caller)

            # V4.0 (H1): claim/release nguyên tử cho lệnh chờ Muse.
            if (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "commands"]
                and parts[3] == "claim"
            ):
                return self._handle_command_claim(parts[2], caller)

            if (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "commands"]
                and parts[3] == "release"
            ):
                return self._handle_command_release(parts[2], caller)

            # V6.0: giám sát viên gửi KẾT LUẬN kiểm tra chéo cho một
            # LỆNH KIỂM TRA (loại 'review').
            if (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "commands"]
                and parts[3] == "verdict"
            ):
                return self._handle_command_verdict(parts[2], body, caller)


            if method == "GET" and parts == ["api", "commands"]:
                limit = self._parse_limit(query)
                status_filter = (query.get("status") or [None])[0]
                source_filter = (query.get("source") or [None])[0]
                # V4.0 (H6): long-poll — ?wait=N (kẹp 0–50 giây) chỉ có
                # nghĩa với lọc waiting_muse: chưa có lệnh trong phạm vi
                # thì treo tới khi có lệnh mới chuyển waiting_muse
                # (dispatcher/sweeper gọi notify_commands_changed) hoặc
                # hết giờ thì trả danh sách rỗng như poll thường.
                wait_seconds = self._parse_wait(query)
                generation = self._commands_gen
                payload = self._commands_listing(
                    caller, limit, status_filter, source_filter
                )
                if (
                    wait_seconds > 0
                    and status_filter == "waiting_muse"
                    and not payload["commands"]
                ):
                    self._wait_commands_change(generation, wait_seconds)
                    payload = self._commands_listing(
                        caller, limit, status_filter, source_filter
                    )
                return 200, payload

            if method == "GET" and len(parts) == 3 and parts[:2] == ["api", "commands"]:
                if caller["kind"] == "agent":
                    store = self._new_store()
                    try:
                        row = store.get_command(parts[2])
                        allowed = bool(
                            row
                            and store.agent_can_access_command(
                                caller["agent"]["id"], row
                            )
                        )
                    finally:
                        store.close()
                    if row is None:
                        return 404, {"ok": False, "error": f"Không thấy lệnh '{parts[2]}'"}
                    if not allowed:
                        return 403, {"ok": False, "error": "Lệnh này không thuộc phạm vi kênh bạn phụ trách"}
                    return 200, {"ok": True, "command": api_command_shape(row)}
                record = self.get_command(parts[2])
                if record is None:
                    return 404, {"ok": False, "error": f"Không thấy lệnh '{parts[2]}'"}
                return 200, {"ok": True, "command": record}

            if (
                method == "POST"
                and len(parts) == 4
                and parts[:2] == ["api", "commands"]
                and parts[3] == "result"
            ):
                return self._handle_command_result(parts[2], body, caller)

            if len(parts) == 5 and parts[:2] == ["api", "profiles"] and parts[3] == "cookies":
                profile = self._get_profile(parts[2])
                if profile is None:
                    return 404, {"ok": False, "error": f"Không thấy hồ sơ '{parts[2]}'"}
                if method == "POST" and parts[4] == "apply":
                    return self._handle_cookies_apply(profile)
                if method == "POST" and parts[4] == "export":
                    return self._handle_cookies_export(profile)
                return 404, {"ok": False, "error": f"Không có endpoint {method} {parsed.path}"}

            if len(parts) == 4 and parts[:2] == ["api", "profiles"]:
                slug, action = parts[2], parts[3]
                profile = self._get_profile(slug)
                if profile is None:
                    return 404, {"ok": False, "error": f"Không thấy hồ sơ '{slug}'"}
                if method == "GET" and action == "cookies":
                    return 200, {"ok": True, "slug": slug, "cookies": cookies_vault.summarize(slug, base=self._data_dir)}
                if method == "POST" and action == "cookies":
                    return self._handle_cookies_import(profile, headers, body)
                if method == "GET" and action == "channels":
                    store = self._new_store()
                    try:
                        channels = store.list_channels(profile["id"])
                    finally:
                        store.close()
                    return 200, {"ok": True, "slug": slug, "channels": channels}
                if method == "POST" and action == "open":
                    return 200, {"ok": True, **self._do_open_browser(profile)}
                if method == "POST" and action == "scan":
                    return 200, {"ok": True, **self._do_scan(profile)}

            return 404, {"ok": False, "error": f"Không có endpoint {method} {parsed.path}"}
        except Exception as exc:
            return 500, {"ok": False, "error": str(exc)}

    @staticmethod
    def _header(headers: dict, name: str) -> str:
        for key, value in headers.items():
            if key.lower() == name:
                return value or ""
        return ""

    def _authorized(self, headers: dict) -> bool:
        return self._authenticate(headers) is not None

    def _authenticate(self, headers: dict) -> dict | None:
        """Nhận diện phía gọi (V3.3): có header X-Agent-Id -> xác thực
        bằng TOKEN RIÊNG của tài khoản Muse đó (trả {'kind': 'agent',
        'agent': {...}}); không có -> token cầu nối chung của bản cài
        (trả {'kind': 'admin'} — phía quản trị, thấy và làm được mọi
        thứ như trước). Không hợp lệ -> None (401)."""
        token = self._header(headers, "x-agent-token")
        agent_id = self._header(headers, "x-agent-id").strip()
        if agent_id:
            store = self._new_store()
            try:
                agent = store.authenticate_agent(agent_id, token)
            finally:
                store.close()
            if agent is None:
                return None
            return {"kind": "agent", "agent": agent}
        if token and hmac.compare_digest(token, self.token):
            return {"kind": "admin"}
        return None

    @staticmethod
    def _actor_label(caller: dict) -> str:
        """Tiền tố nhật ký theo phía gọi: lệnh do một Muse cụ thể báo
        cáo thì ghi rõ tên Muse đó thay cho [API] chung chung."""
        if caller and caller.get("kind") == "agent":
            return f"[Muse: {caller['agent']['name']}]"
        return "[API]"

    @staticmethod
    def _parse_limit(query: dict) -> int:
        try:
            limit = int((query.get("limit") or ["50"])[0])
        except (TypeError, ValueError):
            limit = 50
        return max(1, min(limit, 500))

    @staticmethod
    def _parse_wait(query: dict) -> float:
        """Tham số long-poll ?wait=N giây (V4.0 H6) — kẹp 0–50, sai
        định dạng → 0 (poll thường)."""
        try:
            wait = float((query.get("wait") or ["0"])[0])
        except (TypeError, ValueError):
            return 0.0
        return max(0.0, min(wait, 50.0))

    def _commands_listing(
        self, caller: dict, limit: int,
        status_filter: str | None, source_filter: str | None,
    ) -> dict:
        """Thân của GET /api/commands (tách ra để long-poll gọi lại sau
        khi được đánh thức mà không lặp logic phân quyền)."""
        if caller["kind"] == "agent":
            # Muse chỉ thấy lệnh trong phạm vi kênh mình phụ trách.
            # V4.2 (O-28): status/source lọc NGAY TRONG SQL trước
            # LIMIT — bản cũ lấy ``limit`` lệnh mới nhất rồi lọc ở
            # Python nên lệnh waiting_muse cũ hơn bị lệnh mới trạng
            # thái khác chen mất, không bao giờ tới được Muse.
            store = self._new_store()
            try:
                rows = store.list_commands_for_agent(
                    caller["agent"]["id"], limit=limit,
                    status=status_filter, source=source_filter,
                )
            finally:
                store.close()
            return {
                "ok": True,
                "commands": [api_command_shape(r) for r in rows],
            }
        commands = self.list_commands(
            status=status_filter, source=source_filter, limit=limit
        )
        return {"ok": True, "commands": commands}

    def _profiles_with_channels(self) -> list[dict]:
        store = self._new_store()
        try:
            profiles = store.list_profiles()
            result = []
            for profile in profiles:
                entry = dict(profile)
                try:
                    entry["chrome_running"] = bool(self._manager.is_running(profile))
                except Exception:
                    entry["chrome_running"] = False
                if entry["paused"]:
                    entry["session_status"] = "paused"
                elif entry["chrome_running"]:
                    entry["session_status"] = "chrome_running"
                else:
                    entry["session_status"] = "chrome_stopped"
                entry["channels"] = store.list_channels(profile["id"])
                entry["cookies"] = cookies_vault.summarize(profile["slug"], base=self._data_dir)
                entry["last_check"] = store.get_last_check(profile["id"])
                result.append(entry)
            return result
        finally:
            store.close()

    def _handle_inbox(self, headers: dict, body: bytes) -> tuple[int, dict]:
        raw_name = ""
        expected_sha = ""
        command_id = ""
        for key, value in headers.items():
            lowered = key.lower()
            if lowered == "x-file-name":
                raw_name = value or ""
            elif lowered == "x-file-sha256":
                expected_sha = (value or "").strip().lower()
            elif lowered == "x-command-id":
                # V4.4: giao file ĐÍNH KÈM một lệnh cụ thể (vd video
                # cho lệnh studio_script) thay vì inbox dùng chung.
                command_id = (value or "").strip()
        name = sanitize_file_name(raw_name)
        digest = hashlib.sha256(body).hexdigest()
        if expected_sha and expected_sha != digest:
            return 400, {
                "ok": False,
                "error": "sha256 không khớp — file bị từ chối, không lưu.",
                "sha256": digest,
            }
        if command_id:
            return self._save_command_file(command_id, name, body, digest)
        inbox_dir = self._data_dir / "inbox"
        inbox_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = inbox_dir / f"{stamp}_{name}"
        counter = 2
        while path.exists():
            path = inbox_dir / f"{stamp}-{counter}_{name}"
            counter += 1
        path.write_bytes(body)
        self._journal(f"[API] Nhận file '{name}' ({len(body)} bytes) vào inbox: {path.name}.")
        return 200, {
            "ok": True,
            "saved": str(path),
            "name": path.name,
            "size": len(body),
            "sha256": digest,
        }

    def _handle_files(self, method: str, parts: list[str], body: bytes) -> tuple[int, dict]:
        """V6.3 — /api/files/upload[/{id}[/complete]] và /api/files/fetch[/{id}]
        (PUT khúc dữ liệu được handler HTTP ghi thẳng xuống đĩa, xem
        _make_handler)."""
        from .large_files import LargeFileError

        try:
            if parts[2] == "upload":
                if len(parts) == 3 and method == "POST":
                    payload, error = self._parse_json_body(body)
                    if error:
                        return error
                    return 200, {"ok": True, "upload": self.large_files.init_upload(payload)}
                if len(parts) == 4 and method == "GET":
                    return 200, {"ok": True, "upload": self.large_files.status(parts[3])}
                if len(parts) == 5 and parts[4] == "complete" and method == "POST":
                    return 200, {"ok": True, "upload": self.large_files.complete(parts[3])}
            if parts[2] == "fetch":
                if len(parts) == 3 and method == "POST":
                    payload, error = self._parse_json_body(body)
                    if error:
                        return error
                    return 202, {"ok": True, "fetch": self.large_files.start_fetch(payload)}
                if len(parts) == 4 and method == "GET":
                    return 200, {"ok": True, "fetch": self.large_files.status(parts[3])}
        except LargeFileError as exc:
            return exc.status, {"ok": False, "error": str(exc)}
        return 404, {"ok": False, "error": f"Không có endpoint {method} /{'/'.join(parts)}"}

    def stream_upload_chunk(self, headers: dict, path: str, stream, length: int) -> tuple[int, dict]:
        """PUT /api/files/upload/{id}?offset=N — ghi khúc theo luồng."""
        from .large_files import LargeFileError

        if self._authenticate(headers) is None:
            return 401, {"ok": False, "error": "Thiếu hoặc sai token"}
        parsed = urlparse(path)
        parts = [p for p in parsed.path.split("/") if p]
        if len(parts) != 4 or parts[:3] != ["api", "files", "upload"]:
            return 404, {"ok": False, "error": "Không có endpoint PUT này"}
        query = parse_qs(parsed.query)
        try:
            offset = int((query.get("offset") or ["0"])[0])
        except ValueError:
            return 400, {"ok": False, "error": "offset không hợp lệ"}
        try:
            return 200, {"ok": True, "upload": self.large_files.write_chunk(parts[3], offset, stream, length)}
        except LargeFileError as exc:
            return exc.status, {"ok": False, "error": str(exc)}

    def _save_command_file(
        self, command_id: str, name: str, body: bytes, digest: str
    ) -> tuple[int, dict]:
        """V4.4: lưu file vào thư mục RIÊNG của lệnh
        (data/command_files/<command_id>/<tên thuần>) để các bước
        upload của lệnh đó resolve theo tên. Chặn: mã lệnh lạ (404
        định dạng), lệnh không tồn tại (404), lệnh đã kết thúc
        done/failed (409 — giao file cho lệnh chết là vô nghĩa), file
        quá giới hạn MAX_COMMAND_FILE_BYTES (413). Tên file đã được
        sanitize_file_name bóc đường dẫn từ trước; gửi lại cùng tên =
        ghi đè (đúng ngữ nghĩa 'bản file của lệnh')."""
        if not re.fullmatch(r"[A-Za-z0-9_-]+", command_id):
            return 404, {"ok": False, "error": f"Mã lệnh không hợp lệ: {command_id!r}"}
        if len(body) > config.MAX_COMMAND_FILE_BYTES:
            return 413, {
                "ok": False,
                "error": (
                    f"File quá giới hạn {config.MAX_COMMAND_FILE_BYTES} bytes "
                    f"({len(body)} bytes) — không lưu."
                ),
            }
        store = self._new_store()
        try:
            record = store.get_command(command_id)
        finally:
            store.close()
        if record is None:
            return 404, {"ok": False, "error": f"Không thấy lệnh '{command_id}'"}
        if record["status"] in ("done", "failed"):
            return 409, {
                "ok": False,
                "error": f"Lệnh '{command_id}' đã kết thúc ({record['status']}) — không nhận thêm file.",
            }
        folder = config.command_files_dir(command_id, base=self._data_dir)
        path = folder / name
        path.write_bytes(body)
        self._journal(
            f"[API] Nhận file '{name}' ({len(body)} bytes) đính kèm lệnh {command_id}: {path}."
        )
        return 200, {
            "ok": True,
            "saved": str(path),
            "name": name,
            "size": len(body),
            "sha256": digest,
            "command_id": command_id,
        }

    def _handle_enqueue(self, body: bytes, caller: dict | None = None) -> tuple[int, dict]:
        try:
            command = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return 400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"}
        if not isinstance(command, dict):
            return 400, {"ok": False, "error": "Body phải là một JSON object"}
        ctype = command.get("type")
        allowed_types = COMMAND_TYPES + CLAUDE_COMMAND_TYPES
        if ctype not in allowed_types:
            return 400, {
                "ok": False,
                "error": f"type phải là một trong {list(allowed_types)}",
            }
        slug = command.get("profile")
        if not slug:
            return 400, {"ok": False, "error": "Lệnh cần trường 'profile' (slug của hồ sơ)"}
        profile = self._get_profile(slug)
        if profile is None:
            return 404, {"ok": False, "error": f"Không thấy hồ sơ '{slug}'"}
        # V4.0 (H5): kiểm tra payload theo loại lệnh NGAY ở cửa — lỗi
        # cấu hình bị chặn tại đây thay vì đợi Muse chạy rồi mới vỡ.
        store = self._new_store()
        try:
            channels = store.list_channels(profile["id"])
        finally:
            store.close()
        errors = command_schema.validate_command(
            ctype,
            channel_id=str(command.get("channel_id") or ""),
            instruction=str(command.get("instruction") or ""),
            payload=command.get("payload") or {},
            channel_ids=[c["channel_id"] for c in channels],
        )
        if errors:
            return 400, {
                "ok": False,
                "error": "Lệnh chưa hợp lệ theo loại lệnh",
                "errors": errors,
            }
        agent_id = None
        if caller and caller.get("kind") == "agent":
            agent_id = caller["agent"]["id"]
            owner = None
            store = self._new_store()
            try:
                owner = store.agent_for_profile(profile["id"])
            finally:
                store.close()
            if not owner or owner["id"] != agent_id:
                return 403, {
                    "ok": False,
                    "error": "Hồ sơ này không thuộc phạm vi kênh bạn phụ trách",
                }
        # V4.0 (H5 + Đ5): chống trùng — nơi gọi không truyền key thì app
        # tự sinh key mặc định (chỉ cho lệnh chờ Muse; lệnh local giữ
        # hành vi cũ). Mọi lệnh tạo qua API đều vào 'queued': lệnh local
        # do worker thi hành, lệnh Muse do dispatcher xét điều kiện.
        # V4.2 (O-02): key mặc định gồm TOÀN BỘ yêu cầu (instruction,
        # channel, agent, lịch hẹn, phụ thuộc + payload) — bản cũ chỉ
        # lẫn payload nên hai yêu cầu khác nội dung bị coi là một.
        if ctype in CLAUDE_COMMAND_TYPES and not command.get("idempotency_key"):
            command["idempotency_key"] = Store.default_idempotency_key(
                "api", ctype, slug, command.get("payload") or {},
                instruction=str(command.get("instruction") or ""),
                channel_id=str(command.get("channel_id") or ""),
                agent_id=agent_id,
                scheduled_at=(
                    str(command["scheduled_at"])
                    if command.get("scheduled_at") else None
                ),
                depends_on=(
                    str(command["depends_on"])
                    if command.get("depends_on") else None
                ),
            )
        record = self.enqueue_command(command, agent_id=agent_id)
        # V4.2 (O-27): lệnh Muse mới qua API cũng đánh thức
        # dispatcher NGAY (như nút Chạy ngay của UI) — không đợi nhịp
        # 15 giây thường lệ.
        if ctype in CLAUDE_COMMAND_TYPES:
            self.request_dispatch_now()
        response = {
            "ok": True,
            "command_id": record["id"],
            "status": record["status"],
        }
        if record.get("deduplicated"):
            response["deduplicated"] = True
        return 202, response

    def _check_agent_command_access(
        self, caller: dict | None, command_id: str, enforce_lease: bool = False
    ) -> tuple[dict | None, tuple[int, dict] | None]:
        """Chốt chống giẫm chân cho progress/result: phía gọi là một
        Muse cụ thể thì lệnh phải thuộc phạm vi của Muse đó.
        Trả (hàng lệnh hiện tại, None) khi được phép; (None, lỗi) khi
        bị chặn/không thấy lệnh. Phía admin (token chung) luôn qua.

        V4.0: ``enforce_lease=True`` (progress/result/claim/release) —
        lệnh đang 'running' CÓ chủ lease thì chỉ chủ lease mới thao
        tác được (kể cả Muse khác cùng phụ trách hồ sơ); lệnh running
        chưa có lease mà đã ghi danh agent_id khác cũng bị chặn."""
        store = self._new_store()
        try:
            row = store.get_command(command_id)
            if row is None:
                return None, (404, {"ok": False, "error": f"Không thấy lệnh '{command_id}'"})
            if caller and caller.get("kind") == "agent":
                agent_id = caller["agent"]["id"]
                if not store.agent_can_access_command(agent_id, row):
                    return None, (
                        403,
                        {"ok": False, "error": "Lệnh này không thuộc phạm vi kênh bạn phụ trách"},
                    )
                if row.get("agent_id") is None:
                    # Nhận lệnh: ghi danh Muse đang giữ lệnh này.
                    store.set_command_agent(command_id, agent_id)
                    row = store.get_command(command_id)
                if enforce_lease and row["status"] == "running":
                    holder = row.get("lease_agent_id")
                    if holder is not None and holder != agent_id:
                        return None, (
                            403,
                            {
                                "ok": False,
                                "error": "Lệnh đang do một Muse khác giữ (lease) — không thao tác được",
                            },
                        )
                    if holder is None:
                        recorded = row.get("agent_id")
                        if recorded is not None and recorded != agent_id:
                            return None, (
                                403,
                                {
                                    "ok": False,
                                    "error": "Lệnh đang do một Muse khác giữ — không thao tác được",
                                },
                            )
            return row, None
        finally:
            store.close()

    # ------------------------------------------------------------------ #
    # V4.0 (H1) — claim / release
    # ------------------------------------------------------------------ #
    def _handle_command_claim(
        self, command_id: str, caller: dict | None
    ) -> tuple[int, dict]:
        """Nhận lệnh chờ Muse: nguyên tử ở tầng Store (một UPDATE có
        điều kiện) — thắng thì lệnh 'running' + có lease; thua → 409
        kèm trạng thái hiện tại để phía gọi khỏi đoán."""
        _row, blocked = self._check_agent_command_access(caller, command_id)
        if blocked is not None:
            return blocked
        agent_id = caller["agent"]["id"] if caller and caller.get("kind") == "agent" else None
        store = self._new_store()
        try:
            claimed = store.claim_claude_command(
                command_id, agent_id, self._lease_seconds()
            )
            current = claimed or store.get_command(command_id)
        finally:
            store.close()
        if claimed is None:
            return 409, {
                "ok": False,
                "error": (
                    f"Lệnh đang ở trạng thái '{current['status'] if current else '?'}'"
                    " — không claim được (chỉ claim được lệnh 'waiting_muse')"
                ),
                "command": api_command_shape(current) if current else None,
            }
        self._journal(
            f"{self._actor_label(caller)} đã NHẬN lệnh #{command_id} "
            f"({claimed['type']}) — lease {self._lease_seconds()}s.",
            claimed["profile_id"],
        )
        return 200, {"ok": True, "command": api_command_shape(claimed)}

    def _handle_command_release(
        self, command_id: str, caller: dict | None
    ) -> tuple[int, dict]:
        """Chủ lease trả lệnh sớm: về 'waiting_muse', xoá lease,
        attempts giữ nguyên. Không phải chủ lease → 403/409 rõ ràng."""
        _row, blocked = self._check_agent_command_access(
            caller, command_id, enforce_lease=True
        )
        if blocked is not None:
            return blocked
        agent_id = caller["agent"]["id"] if caller and caller.get("kind") == "agent" else None
        store = self._new_store()
        try:
            released = store.release_claude_command(command_id, agent_id)
            current = released or store.get_command(command_id)
        finally:
            store.close()
        if released is None:
            return 409, {
                "ok": False,
                "error": (
                    f"Lệnh đang ở trạng thái '{current['status'] if current else '?'}'"
                    " — không release được (chỉ chủ lease của lệnh 'running' mới trả được)"
                ),
                "command": api_command_shape(current) if current else None,
            }
        self.notify_commands_changed()
        self._journal(
            f"{self._actor_label(caller)} đã TRẢ lệnh #{command_id} "
            f"({released['type']}) về hàng chờ.",
            released["profile_id"],
        )
        return 200, {"ok": True, "command": api_command_shape(released)}

    def _handle_command_result(
        self, command_id: str, body: bytes, caller: dict | None = None
    ) -> tuple[int, dict]:
        """Muse báo tiến độ/kết quả cho một lệnh trong bảng dùng chung —
        điển hình là các lệnh 'waiting_muse' do người dùng tạo trong UI
        (Tối ưu kênh / Tải video lên / Lệnh tự do)."""
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return 400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"}
        if not isinstance(payload, dict):
            return 400, {"ok": False, "error": "Body phải là một JSON object"}
        status = payload.get("status")
        if status is not None and status not in COMMAND_STATUSES:
            return 400, {
                "ok": False,
                "error": f"status phải là một trong {list(COMMAND_STATUSES)}",
            }
        result = payload.get("result")
        if result is not None and not isinstance(result, str):
            result = json.dumps(result, ensure_ascii=False)
        error = payload.get("error")
        message = payload.get("message")
        if message is not None and not isinstance(message, str):
            message = json.dumps(message, ensure_ascii=False)
        _row, blocked = self._check_agent_command_access(
            caller, command_id, enforce_lease=True
        )
        if blocked is not None:
            return blocked
        agent_id = caller["agent"]["id"] if caller and caller.get("kind") == "agent" else None

        # V6.0: lệnh KIỂM TRA không chốt bằng result thường — kết
        # luận phải qua POST /api/commands/{id}/verdict để vòng
        # kiểm tra đóng đúng quy trình (Đạt/làm lại/leo thang).
        if _row.get("type") == "review" and status in ("done", "failed"):
            return 400, {
                "ok": False,
                "error": "Lệnh kiểm tra phải chốt bằng POST /api/commands/"
                f"{command_id}/verdict với verdict pass|rework|escalate",
            }

        # V4.0 (H3): needs_user — chỉ chủ lease/admin (đã qua chốt
        # enforce_lease ở trên); đặt trạng thái này = nhả lease, không
        # tăng attempts, việc cần người làm nằm trong 'message'.
        if status == "needs_user":
            store = self._new_store()
            try:
                row = store.set_command_needs_user(
                    command_id, message or result or ""
                )
            finally:
                store.close()
            if row is None:
                return 409, {
                    "ok": False,
                    "error": "Lệnh đã ở trạng thái cuối — không đặt 'needs_user' được",
                }
            self._journal(
                f"{self._actor_label(caller)} ⏸ Lệnh #{command_id} ({row['type']}) "
                f"CHỜ NGƯỜI XỬ LÝ: {message or result or ''}",
                row["profile_id"],
            )
            return 200, {"ok": True, "command": api_command_shape(row)}

        store = self._new_store()
        try:
            if status in ("done", "failed"):
                # Chốt lệnh qua finish_command: đóng dấu finished_at +
                # xoá lease (V4.0) — cùng đường với bộ chạy tại chỗ.
                row = store.finish_command(
                    command_id, status, result=result, error=error
                )
            else:
                row = store.update_command(
                    command_id, status=status, result=result, error=error
                )
                if row is not None and status == "running":
                    # Báo cáo trung gian "vẫn đang chạy" của chủ lease
                    # cũng là một lần gia hạn lease (H1).
                    store.touch_command_lease(
                        command_id, agent_id, self._lease_seconds()
                    )
                    row = store.get_command(command_id)
        finally:
            store.close()
        if row is None:
            return 404, {"ok": False, "error": f"Không thấy lệnh '{command_id}'"}
        if status in ("done", "failed"):
            # Một chỗ trống trình duyệt vừa trống — đánh thức long-poll
            # để dispatcher/Muse khác biết sớm.
            self.notify_commands_changed()
        self._journal(
            f"{self._actor_label(caller)} báo cáo lệnh #{command_id} ({row['type']}): "
            f"trạng thái {row['status']}"
            + (f" — {result}" if result else "")
            + (f" — lỗi: {error}" if error else ""),
            row["profile_id"],
        )
        return 200, {"ok": True, "command": api_command_shape(row)}


    # ------------------------------------------------------------------ #
    # V3.2: tạo hồ sơ / tiến độ lệnh / kho cookies
    # ------------------------------------------------------------------ #
    def _handle_create_profile(self, body: bytes) -> tuple[int, dict]:
        """Tạo hồ sơ riêng cho một Gmail (Muse gọi khi có tài khoản mới).
        Gmail đã có hồ sơ -> 409 kèm hồ sơ hiện có, không tạo trùng."""
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return 400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"}
        if not isinstance(payload, dict):
            return 400, {"ok": False, "error": "Body phải là một JSON object"}
        label = str(payload.get("label") or "").strip()
        gmail = str(payload.get("gmail") or "").strip()
        if not label or not gmail:
            return 400, {"ok": False, "error": "Cần 'label' và 'gmail'"}
        store = self._new_store()
        try:
            try:
                profile = store.add_profile(label, gmail, str(payload.get("note") or ""))
            except ValueError as exc:
                existing = store.find_profile_by_gmail(gmail)
                return 409, {"ok": False, "error": str(exc), "profile": existing}
        finally:
            store.close()
        self._journal(
            f"[API] Đã tạo hồ sơ '{profile['label']}' ({gmail}) — slug "
            f"{profile['slug']}, cổng debug {profile['port']}.",
            profile["id"],
        )
        return 201, {"ok": True, "profile": profile}

    def _handle_command_progress(
        self, command_id: str, body: bytes, caller: dict | None = None
    ) -> tuple[int, dict]:
        """Muse báo TIẾN ĐỘ một công việc đang làm (0–100 + mô tả bước)
        — người dùng theo dõi trực tiếp trong app (V3.2). Đổi bước mới
        ghi nhật ký một dòng; báo % thuần thì không ghi để khỏi rác."""
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return 400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"}
        if not isinstance(payload, dict):
            return 400, {"ok": False, "error": "Body phải là một JSON object"}
        progress = payload.get("progress")
        if progress is not None:
            try:
                progress = int(progress)
            except (TypeError, ValueError):
                return 400, {"ok": False, "error": "'progress' phải là số 0–100"}
        step = payload.get("step")
        if step is not None:
            step = str(step)
        before, blocked = self._check_agent_command_access(
            caller, command_id, enforce_lease=True
        )
        if blocked is not None:
            return blocked
        # V4.2 (O-05): lệnh còn 'queued' thì progress > 0 bị TỪ CHỐI
        # tường minh (409) — đường tự-claim tương thích (Đ1) chỉ còn
        # áp dụng từ 'waiting_muse'. Không cho ai báo tiến độ để đi
        # vòng qua điều kiện dispatcher (hẹn giờ/phụ thuộc/phân
        # công/tuần tự). Tầng Store cũng tự chặn (phòng thủ hai lớp).
        if (
            before["status"] == "queued"
            and progress is not None
            and progress > 0
        ):
            return 409, {
                "ok": False,
                "error": (
                    "Lệnh còn đang 'queued' (chưa được điều phối) — "
                    "không nhận báo tiến độ. Hãy claim lệnh ở trạng "
                    "thái 'waiting_muse' trước."
                ),
            }
        agent_id = caller["agent"]["id"] if caller and caller.get("kind") == "agent" else None
        store = self._new_store()
        try:
            row = store.update_command_progress(
                command_id, progress=progress, step=step,
                agent_id=agent_id, lease_seconds=self._lease_seconds(),
            )
        finally:
            store.close()
        if (
            before["status"] == "waiting_muse"
            and row is not None
            and row["status"] == "running"
            and progress is not None
            and progress > 0
        ):
            # V4.2 (O-05): ghi sổ MỘT lần khi đường claim-ngầm kiểu cũ
            # (Đ1) thật sự được dùng, để còn truy vết client cũ.
            self._journal(
                f"{self._actor_label(caller)} ⚠ Lệnh #{command_id} ({row['type']}) "
                "được nhận qua đường báo-tiến-độ kiểu cũ (chưa claim tường "
                "minh) — client nên chuyển sang POST /claim.",
                row["profile_id"],
            )
        if step and step != (before.get("step") or ""):
            self._journal(
                f"{self._actor_label(caller)} ⏳ Lệnh #{command_id} ({row['type']}): "
                f"{row.get('progress') or 0}% — {step}",
                row["profile_id"],
            )
        return 200, {"ok": True, "command": api_command_shape(row)}

    # ------------------------------------------------------------------ #
    # V3.3: tài khoản Muse (agents) — quản trị qua token chung; từng
    # Muse tự gọi bằng token riêng của mình (header X-Agent-Id).
    # ------------------------------------------------------------------ #
    @staticmethod
    def _parse_json_body(body: bytes):
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return None, (400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"})
        if not isinstance(payload, dict):
            return None, (400, {"ok": False, "error": "Body phải là một JSON object"})
        return payload, None

    @staticmethod
    def _admin_only(caller: dict) -> tuple[int, dict] | None:
        if caller and caller.get("kind") == "agent":
            return 403, {
                "ok": False,
                "error": "Thao tác quản trị tài khoản Muse cần token cầu nối chung",
            }
        return None

    def _handle_list_agents(self, caller: dict) -> tuple[int, dict]:
        if caller.get("kind") == "agent":
            me = caller["agent"]
            return 200, {"ok": True, "agents": [api_agent_shape(me)]}
        store = self._new_store()
        try:
            agents = store.list_agents()
        finally:
            store.close()
        return 200, {
            "ok": True,
            "agents": [api_agent_shape(a, include_token=True) for a in agents],
        }

    # ------------------------------------------------------------------ #
    # V4.6 — Chat hai chiều theo từng tài khoản Muse
    # ------------------------------------------------------------------ #
    def _check_message_scope(
        self, caller: dict, agent_id: int
    ) -> tuple[int, dict] | None:
        """Chốt phạm vi chat (CHẶT như lệnh): phía 'agent' CHỈ được
        chạm luồng của chính mình — đọc/gửi/đánh dấu đọc luồng của
        Muse khác → 403; agent không tồn tại → 404 (kể cả với
        admin). Trả None khi được phép đi tiếp."""
        if caller.get("kind") == "agent" and caller["agent"]["id"] != agent_id:
            return 403, {
                "ok": False,
                "error": "Bạn chỉ được truy cập luồng chat của chính mình",
            }
        store = self._new_store()
        try:
            exists = store.get_agent(agent_id) is not None
        finally:
            store.close()
        if not exists:
            return 404, {
                "ok": False,
                "error": f"Không thấy tài khoản Muse #{agent_id}",
            }
        return None

    def _unread_for_caller(self, store: Store, caller: dict, agent_id: int):
        """Tin chưa đọc TỪ GÓC NHÌN phía gọi: Muse chờ tin 'user';
        phía quản trị (app/hook) chờ tin 'agent'."""
        direction = "user" if caller.get("kind") == "agent" else "agent"
        return store.list_unread_messages(agent_id, direction)

    def _handle_list_messages(
        self, caller: dict, agent_id: int, query: dict
    ) -> tuple[int, dict]:
        """GET /api/agents/{id}/messages — lịch sử gần nhất; kèm
        ?unread=1 thì CHỈ tin chưa đọc của phía gọi, và ?wait=N
        (0–50) biến nó thành long-poll: chưa có tin chưa đọc thì
        treo tới khi có tin mới (notify_messages_changed) hoặc hết
        giờ — cùng mẫu long-poll lệnh chờ (H6)."""
        blocked = self._check_message_scope(caller, agent_id)
        if blocked:
            return blocked
        unread_only = (query.get("unread") or ["0"])[0] in ("1", "true", "yes")
        if unread_only:
            generation = self._messages_gen
            store = self._new_store()
            try:
                rows = self._unread_for_caller(store, caller, agent_id)
            finally:
                store.close()
            wait_seconds = self._parse_wait(query)
            if wait_seconds > 0 and not rows:
                self._wait_messages_change(generation, wait_seconds)
                store = self._new_store()
                try:
                    rows = self._unread_for_caller(store, caller, agent_id)
                finally:
                    store.close()
            return 200, {
                "ok": True,
                "messages": [api_message_shape(r) for r in rows],
                "unread": len(rows),
            }
        limit = self._parse_limit(query)
        before_raw = (query.get("before") or [None])[0]
        try:
            before_id = int(before_raw) if before_raw else None
        except (TypeError, ValueError):
            before_id = None
        store = self._new_store()
        try:
            rows = store.list_messages(agent_id, limit=limit, before_id=before_id)
            counts = store.unread_counts().get(agent_id, {})
        finally:
            store.close()
        return 200, {
            "ok": True,
            "messages": [api_message_shape(r) for r in rows],
            "unread_counts": counts,
        }

    def _handle_post_message(
        self, caller: dict, agent_id: int, body: bytes
    ) -> tuple[int, dict]:
        """POST /api/agents/{id}/messages — Muse gửi một tin trả
        lời {body, command_id?} vào luồng của CHÍNH mình (phía quản
        trị cũng gửi được, vẫn direction='agent': tin từ phía điều
        hành). Body rỗng → 400; dài hơn trần 4000 ký tự → 413; JSON
        hỏng → 400."""
        blocked = self._check_message_scope(caller, agent_id)
        if blocked:
            return blocked
        payload, error = self._parse_json_body(body)
        if error:
            return error
        text = payload.get("body")
        if not isinstance(text, str) or not text.strip():
            return 400, {"ok": False, "error": "Cần 'body': nội dung tin nhắn khác rỗng"}
        if len(text) > Store.MESSAGE_BODY_LIMIT:
            return 413, {
                "ok": False,
                "error": f"Tin nhắn quá dài (tối đa {Store.MESSAGE_BODY_LIMIT} ký tự)",
            }
        command_id = payload.get("command_id")
        command_id = str(command_id).strip() if command_id else None
        store = self._new_store()
        try:
            if command_id and store.get_command(command_id) is None:
                return 400, {
                    "ok": False,
                    "error": f"Không thấy lệnh '{command_id}' để gắn vào tin",
                }
            message = store.add_message(
                agent_id, "agent", text.strip(), command_id=command_id
            )
        finally:
            store.close()
        self.notify_messages_changed()
        return 201, {"ok": True, "message": api_message_shape(message)}

    def _handle_mark_messages_read(
        self, caller: dict, agent_id: int, body: bytes
    ) -> tuple[int, dict]:
        """POST /api/agents/{id}/messages/read — phía gọi đánh dấu
        đã đọc tin gửi TỚI mình: Muse đọc tin 'user', quản trị đọc
        tin 'agent'. Body {} hoặc {up_to_id} (thiếu = đọc hết)."""
        blocked = self._check_message_scope(caller, agent_id)
        if blocked:
            return blocked
        up_to_id = None
        if body:
            payload, error = self._parse_json_body(body)
            if error:
                return error
            raw = payload.get("up_to_id")
            if raw is not None:
                try:
                    up_to_id = int(raw)
                except (TypeError, ValueError):
                    return 400, {"ok": False, "error": "'up_to_id' phải là số nguyên"}
        direction = "user" if caller.get("kind") == "agent" else "agent"
        store = self._new_store()
        try:
            marked = store.mark_read(agent_id, direction, up_to_id)
        finally:
            store.close()
        self.notify_messages_changed()
        return 200, {"ok": True, "marked": marked}

    def _handle_create_agent(self, caller: dict, body: bytes) -> tuple[int, dict]:
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        payload, error = self._parse_json_body(body)
        if error:
            return error
        name = str(payload.get("name") or "").strip()
        email = str(payload.get("email") or "").strip()
        if not email:
            return 400, {"ok": False, "error": "Cần 'email' của tài khoản Muse"}
        store = self._new_store()
        try:
            try:
                agent = store.create_agent(name, email, str(payload.get("note") or ""))
            except ValueError as exc:
                existing = store.get_agent_by_email(email)
                return 409, {
                    "ok": False,
                    "error": str(exc),
                    "agent": api_agent_shape(existing, include_token=True) if existing else None,
                }
        finally:
            store.close()
        self._journal(
            f"[API] Đã thêm tài khoản Muse '{agent['name']}' ({agent['email']}) "
            f"— id #{agent['id']}, token riêng đã sinh (chỉ xem trong app/phiếu kết nối)."
        )
        return 201, {"ok": True, "agent": api_agent_shape(agent, include_token=True)}

    def _handle_bulk_agents(self, caller: dict, body: bytes) -> tuple[int, dict]:
        """Nhập HÀNG LOẠT tài khoản Muse: body {agents: [{name, email,
        note?}, ...]} — trả kết quả từng mục (created/duplicate/error)."""
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        payload, error = self._parse_json_body(body)
        if error:
            return error
        entries = payload.get("agents")
        if not isinstance(entries, list) or not entries:
            return 400, {"ok": False, "error": "Cần 'agents': danh sách {name, email} khác rỗng"}
        store = self._new_store()
        try:
            results = store.bulk_create_agents(entries)
        finally:
            store.close()
        shaped = []
        created = 0
        for item in results:
            entry = {"email": item["email"], "status": item["status"]}
            if item.get("agent"):
                entry["agent"] = api_agent_shape(item["agent"], include_token=True)
                created += 1
            if item.get("message"):
                entry["message"] = item["message"]
            shaped.append(entry)
        self._journal(
            f"[API] Nhập hàng loạt tài khoản Muse: thêm mới {created}/"
            f"{len(results)} (còn lại trùng hoặc lỗi định dạng)."
        )
        return 200, {"ok": True, "results": shaped, "created": created}

    def _handle_command_verdict(
        self, command_id: str, body: bytes, caller: dict | None
    ) -> tuple[int, dict]:
        """V6.0 — giám sát viên gửi KẾT LUẬN cho một LỆNH KIỂM TRA:
        body {verdict: 'pass'|'rework'|'escalate', notes, checklist}.
        Chốt truy cập như result (phạm vi agent + chủ lease khi đang
        running); việc áp kết luận (đóng vòng / trả làm lại / leo
        thang) do app.supervision.apply_verdict làm tại một chỗ."""
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            return 400, {"ok": False, "error": f"Body không phải JSON hợp lệ: {exc}"}
        if not isinstance(payload, dict):
            return 400, {"ok": False, "error": "Body phải là một JSON object"}
        verdict = str(payload.get("verdict") or "").strip()
        if verdict not in ("pass", "rework", "escalate"):
            return 400, {
                "ok": False,
                "error": "verdict phải là 'pass', 'rework' hoặc 'escalate'",
            }
        notes = payload.get("notes")
        if notes is not None and not isinstance(notes, str):
            notes = json.dumps(notes, ensure_ascii=False)
        checklist = payload.get("checklist")
        if checklist is not None and not isinstance(checklist, list):
            return 400, {"ok": False, "error": "checklist phải là một danh sách các mục đã chấm"}
        command_row, blocked = self._check_agent_command_access(
            caller, command_id, enforce_lease=True
        )
        if blocked is not None:
            return blocked
        # V6.0 — CHẶN TỰ CHẤM Ở TẦNG API: lệnh kiểm tra mang profile
        # của lệnh gốc nên kiểm tra truy cập theo profile có thể cho
        # NGƯỜI LÀM chạm vào việc kiểm tra của chính mình. Kết luận
        # chỉ được đến từ ĐÚNG agent được giao chấm (trường agent_id
        # của lệnh) hoặc token quản trị.
        if caller.get("kind") == "agent" and (
            command_row.get("agent_id") != caller["agent"]["id"]
        ):
            return 403, {
                "ok": False,
                "error": "Chỉ giám sát viên được giao mới gửi được kết luận cho việc kiểm tra này",
            }
        from . import supervision

        store = self._new_store()
        try:
            outcome = supervision.apply_verdict(
                store,
                command_id,
                verdict,
                notes=notes or "",
                checklist=checklist,
                actor="supervisor",
                settings=self._settings,
            )
        except ValueError as exc:
            return 409, {"ok": False, "error": str(exc)}
        finally:
            store.close()
        self.notify_commands_changed()
        self._journal(
            f"{self._actor_label(caller)} ⚖ Kết luận kiểm tra chéo cho lệnh "
            f"#{outcome['target']['id']}: {outcome['outcome']}"
            + (f" — {notes}" if notes else ""),
            outcome["target"].get("profile_id"),
        )
        return 200, {
            "ok": True,
            "outcome": outcome["outcome"],
            "review": outcome["review"],
            "command": api_command_shape(outcome["target"]),
        }

    def _handle_agent_scorecard(
        self, caller: dict, agent_id: int
    ) -> tuple[int, dict]:
        """V6.0 — thẻ điểm tuần của một tài khoản Muse: agent chỉ
        xem được thẻ của chính mình; token quản trị xem được tất cả
        (cùng quy tắc _handle_get_agent)."""
        if caller.get("kind") == "agent" and caller["agent"]["id"] != agent_id:
            return 403, {"ok": False, "error": "Chỉ xem được thẻ điểm của chính bạn"}
        from . import supervision

        store = self._new_store()
        try:
            agent = store.get_agent(agent_id)
            if agent is None:
                return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
            card = supervision.scorecard(store, agent_id)
        finally:
            store.close()
        return 200, {"ok": True, "scorecard": card}

    def _handle_get_agent(self, caller: dict, agent_id: int) -> tuple[int, dict]:
        if caller.get("kind") == "agent" and caller["agent"]["id"] != agent_id:
            return 403, {"ok": False, "error": "Chỉ xem được chính tài khoản của bạn"}
        store = self._new_store()
        try:
            agent = store.get_agent(agent_id)
        finally:
            store.close()
        if agent is None:
            return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
        return 200, {"ok": True, "agent": api_agent_shape(agent, include_token=True)}

    def _handle_delete_agent(self, caller: dict, agent_id: int) -> tuple[int, dict]:
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        store = self._new_store()
        try:
            agent = store.get_agent(agent_id)
            if agent is None:
                return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
            store.delete_agent(agent_id)
        finally:
            store.close()
        self._journal(
            f"[API] Đã XOÁ tài khoản Muse '{agent['name']}' ({agent['email']})."
        )
        return 200, {"ok": True, "deleted": agent_id}

    def _handle_agent_heartbeat(
        self, caller: dict, agent_id: int, body: bytes
    ) -> tuple[int, dict]:
        if caller.get("kind") == "agent" and caller["agent"]["id"] != agent_id:
            return 403, {"ok": False, "error": "Chỉ gửi heartbeat được cho chính bạn"}
        payload, error = self._parse_json_body(body)
        if error:
            return error
        current = payload.get("current_command_id")
        store = self._new_store()
        try:
            # V4.2 (O-12): bản nhẹ — bỏ qua UPDATE khi nhịp vừa ghi
            # <5s trước và lệnh đang giữ không đổi (heartbeat 10 giây
            # của hook không còn ghi đĩa hai lần/vòng nữa).
            agent = store.touch_agent_heartbeat_light(
                agent_id, None if current is None else str(current)
            )
            # V4.0 (H1): heartbeat kèm lệnh đang giữ = gia hạn lease
            # của chính lệnh đó (chỉ khi người gọi là chủ lease).
            if current:
                holder = (
                    caller["agent"]["id"]
                    if caller.get("kind") == "agent"
                    else None
                )
                store.touch_command_lease(
                    str(current), holder, self._lease_seconds()
                )
        finally:
            store.close()
        if agent is None:
            return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
        return 200, {"ok": True, "agent": api_agent_shape(agent)}

    def _handle_agent_assignments(
        self, caller: dict, agent_id: int, body: bytes
    ) -> tuple[int, dict]:
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        payload, error = self._parse_json_body(body)
        if error:
            return error
        profile_ids = payload.get("profile_ids")
        if not isinstance(profile_ids, list):
            return 400, {"ok": False, "error": "Cần 'profile_ids': danh sách id hồ sơ"}
        store = self._new_store()
        try:
            try:
                agent = store.assign_profiles(agent_id, profile_ids)
            except ValueError as exc:
                return 404, {"ok": False, "error": str(exc)}
        finally:
            store.close()
        self._journal(
            f"[API] Phân công Muse '{agent['name']}': phụ trách "
            f"{len(agent['profile_ids'])} hồ sơ (id: {agent['profile_ids']})."
        )
        return 200, {"ok": True, "agent": api_agent_shape(agent, include_token=True)}

    def _handle_agent_token(self, caller: dict, agent_id: int) -> tuple[int, dict]:
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        store = self._new_store()
        try:
            agent = store.regenerate_agent_token(agent_id)
        finally:
            store.close()
        if agent is None:
            return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
        self._journal(
            f"[API] Đã cấp lại token cho tài khoản Muse '{agent['name']}' "
            f"({agent['email']}) — token cũ hết hiệu lực."
        )
        return 200, {"ok": True, "agent": api_agent_shape(agent, include_token=True)}

    def _handle_agent_revoke(
        self, caller: dict, agent_id: int, body: bytes
    ) -> tuple[int, dict]:
        blocked = self._admin_only(caller)
        if blocked:
            return blocked
        payload, error = self._parse_json_body(body)
        if error:
            return error
        revoked = bool(payload.get("revoked", True))
        store = self._new_store()
        try:
            agent = store.set_agent_revoked(agent_id, revoked)
        finally:
            store.close()
        if agent is None:
            return 404, {"ok": False, "error": f"Không thấy tài khoản Muse #{agent_id}"}
        self._journal(
            f"[API] Tài khoản Muse '{agent['name']}' ({agent['email']}): "
            + ("đã THU HỒI quyền truy cập cầu nối." if revoked else "đã mở lại quyền truy cập.")
        )
        return 200, {"ok": True, "agent": api_agent_shape(agent, include_token=True)}

    def _handle_cookies_import(self, profile: dict, headers: dict, body: bytes) -> tuple[int, dict]:
        """Nhận file cookies (JSON / Netscape .txt) và lưu vào kho riêng
        của hồ sơ. Giá trị cookie không bao giờ vào nhật ký — chỉ số đếm."""
        raw_name = ""
        for key, value in headers.items():
            if key.lower() == "x-file-name":
                raw_name = value or ""
                break
        cookies = cookies_vault.parse_cookies_bytes(body)
        if not cookies:
            return 400, {
                "ok": False,
                "error": "Không đọc được cookie nào — file phải là JSON "
                "(mảng cookie / EditThisCookie) hoặc Netscape cookies.txt.",
            }
        summary = cookies_vault.save_cookies(
            profile["slug"], cookies,
            source=f"import:{sanitize_file_name(raw_name)}", base=self._data_dir,
        )
        self._journal(
            f"[API] Đã nhập {summary['count']} cookies cho hồ sơ "
            f"'{profile['label']}' (cookie đăng nhập Google: "
            f"{', '.join(summary['auth_cookies']) or 'chưa thấy'}).",
            profile["id"],
        )
        return 200, {"ok": True, "slug": profile["slug"], "cookies": summary}

    def _handle_cookies_apply(self, profile: dict) -> tuple[int, dict]:
        """Nạp kho cookies của hồ sơ vào Chrome đang chạy của hồ sơ đó."""
        payload = cookies_vault.load_cookies(profile["slug"], base=self._data_dir)
        if not payload or not payload["cookies"]:
            return 404, {"ok": False, "error": "Hồ sơ chưa có cookies nào trong kho"}
        if not self._manager.is_running(profile):
            return 409, {
                "ok": False,
                "error": "Chrome của hồ sơ chưa chạy — cookies sẽ tự nạp ở lần quét kế tiếp",
            }
        params = [cookies_vault.to_cdp_cookie(c) for c in payload["cookies"]]
        cdp.set_cookies(profile["port"], params)
        self._journal(
            f"[API] Đã nạp {len(params)} cookies vào Chrome hồ sơ '{profile['label']}'.",
            profile["id"],
        )
        return 200, {"ok": True, "applied": len(params)}

    def _handle_cookies_export(self, profile: dict) -> tuple[int, dict]:
        """Xuất cookies hiện tại từ Chrome của hồ sơ vào kho (chỉ giữ
        domain Google/YouTube)."""
        if not self._manager.is_running(profile):
            return 409, {"ok": False, "error": "Chrome của hồ sơ chưa chạy"}
        raw = cdp.get_all_cookies(profile["port"])
        cookies = cookies_vault.filter_google_youtube(
            cookies_vault.normalize_cdp_cookies(raw)
        )
        if not cookies:
            return 200, {"ok": True, "slug": profile["slug"], "cookies": cookies_vault.summarize(profile["slug"], base=self._data_dir), "exported": 0}
        summary = cookies_vault.save_cookies(profile["slug"], cookies, source="export:api", base=self._data_dir)
        self._journal(
            f"[API] Đã xuất {summary['count']} cookies (Google/YouTube) "
            f"của hồ sơ '{profile['label']}' vào kho.",
            profile["id"],
        )
        return 200, {"ok": True, "slug": profile["slug"], "cookies": summary, "exported": summary["count"]}


# --------------------------------------------------------------------------- #
# HTTP handler (mỏng — mọi logic nằm ở AgentServer.dispatch)
# --------------------------------------------------------------------------- #
def _make_handler(agent: AgentServer):
    class AgentRequestHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def _handle(self, method: str) -> None:
            try:
                length = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                length = 0
            headers = {key: value for key, value in self.headers.items()}
            if method == "PUT" and self.path.startswith("/api/files/upload/"):
                # V6.3: khúc file lớn — ghi THẲNG xuống đĩa theo luồng,
                # không đọc cả khúc vào RAM.
                status, payload = agent.stream_upload_chunk(headers, self.path, self.rfile, length)
                self._send(status, payload)
                return
            body = self.rfile.read(length) if length > 0 else b""
            # V6.4.4: kho bận khoá ("database is locked") → thử lại một lần,
            # vẫn bận thì trả 503 + retry_after (JSON) thay vì cắt ngang.
            for attempt in range(2):
                try:
                    status, payload = agent.dispatch(method, self.path, headers, body)
                    break
                except sqlite3.OperationalError as exc:
                    if "locked" not in str(exc).lower() and "busy" not in str(exc).lower():
                        raise
                    if attempt == 0:
                        time.sleep(0.5)
                        continue
                    status, payload = 503, {"ok": False, "error": "database_busy",
                                            "message": "Dữ liệu đang bận, thử lại sau 2 giây.",
                                            "retry_after": 2}
            self._send(status, payload)

        def _send(self, status: int, payload: dict) -> None:
            data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self) -> None:
            self._handle("GET")

        def do_POST(self) -> None:
            self._handle("POST")

        def do_PUT(self) -> None:
            self._handle("PUT")

        def log_message(self, format, *args):  # tắt log mặc định ra stderr
            pass

    return AgentRequestHandler
