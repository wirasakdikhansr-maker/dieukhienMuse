"""Tự chạy lại lệnh THẤT BẠI (V4.5) — logic THUẦN, không Qt/DB.

Quy tắc của người dùng: lệnh vào trạng thái 'failed' thì sau 30 giây
TỰ xếp hàng chạy lại, tối đa 3 lần — TRỪ khi vướng điều kiện chặn:

- đã từng dừng ở 'needs_user' (đăng nhập / OTP / CAPTCHA) trong vòng
  đời này — cờ ``hit_needs_user`` trong payload, Store đặt khi lệnh
  vào needs_user; chạy lại mù quáng chỉ đập vào cùng một tường;
- người dùng đã HUỶ lệnh (lỗi chốt "Đã huỷ bởi người dùng.") hoặc đã
  bấm "Huỷ chạy lại" (cờ ``auto_retry_cancelled``);
- phụ thuộc gãy: lệnh phụ thuộc đã thất bại / không tồn tại;
- lỗi CẤU HÌNH/PAYLOAD không hợp lệ (sai schema, loại lệnh không tự
  chạy được, không thấy hồ sơ đích…) — chạy lại y hệt chỉ lỗi y hệt;
- đã tự chạy lại đủ 3 lần.

Trạng thái retry nằm TRỌN trong payload của lệnh (không đổi schema):
``auto_retry_count`` (số lần đã lên lịch), ``auto_retry_at`` (mốc ISO
tới hạn chạy lại), ``auto_retry_last_error``, ``auto_retry_blocked``
(lý do chặn — để UI nói rõ vì sao không tự chạy lại). Nhờ nằm trong
DB nên sống sót qua khởi động lại app: quá hạn lúc app tắt thì nhịp
xử lý đầu tiên sau khi mở lại vẫn nhặt lên chạy.

Store là nơi DUY NHẤT áp dụng module này (``finish_command`` ghi
nhận, ``process_auto_retries`` xử lý tới hạn) — dispatcher/executor/
agent_server không tự chạm payload.
"""

from __future__ import annotations

from datetime import datetime, timedelta

RETRY_DELAY_SECONDS = 30
MAX_AUTO_RETRIES = 3

KEY_COUNT = "auto_retry_count"
KEY_AT = "auto_retry_at"
KEY_CANCELLED = "auto_retry_cancelled"
KEY_BLOCKED = "auto_retry_blocked"
KEY_LAST_ERROR = "auto_retry_last_error"
KEY_HIT_NEEDS_USER = "hit_needs_user"

#: Mọi khoá retry — vòng đời mới (Thử lại tay / Đã xử lý — chạy tiếp)
#: dọn sạch cả cụm để lệnh bắt đầu lại từ đầu.
ALL_KEYS = (KEY_COUNT, KEY_AT, KEY_CANCELLED, KEY_BLOCKED, KEY_LAST_ERROR)

# Dấu hiệu lỗi CẤU HÌNH trong text lỗi: chạy lại nguyên trạng chắc
# chắn lỗi lại đúng chỗ đó.
_INVALID_MARKERS = (
    "không hợp lệ",          # payload/schema/kịch bản không hợp lệ
    "không tự chạy tại app được",
    "loại lệnh không xác định",
    "không tìm thấy hồ sơ đích",
    "không hỗ trợ",          # loại lệnh không hỗ trợ (đường API)
)

_CANCELLED_MARKER = "Đã huỷ bởi người dùng"
_DEPENDENCY_MARKER = "Lệnh phụ thuộc"


def parse_iso(value) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


def blocked_reason(command: dict) -> str | None:
    """Lý do lệnh failed này KHÔNG được tự chạy lại (None = được phép).

    Đọc thuần từ dict lệnh (payload + error + result) — nơi gọi là
    Store sau khi lệnh vừa chốt 'failed'."""
    payload = command.get("payload") or {}
    if payload.get(KEY_CANCELLED):
        return "cancelled"
    if payload.get(KEY_HIT_NEEDS_USER):
        return "needs_user"
    error = str(command.get("error") or "")
    result = str(command.get("result") or "")
    text = error or result
    if _CANCELLED_MARKER in text:
        return "cancelled"
    if _DEPENDENCY_MARKER in text:
        # "Lệnh phụ thuộc #… đã thất bại/không tồn tại" — gốc chưa
        # xong thì con chạy lại cũng vô ích.
        return "dependency"
    lowered = text.lower()
    if any(marker in lowered for marker in _INVALID_MARKERS):
        return "invalid"
    if int(payload.get(KEY_COUNT) or 0) >= MAX_AUTO_RETRIES:
        return "max_retries"
    return None


def schedule_updates(command: dict, now: datetime) -> dict:
    """Payload updates để LÊN LỊCH lần chạy lại kế: {khoá: giá trị}
    cho Store áp qua update_command_payload_flags. Lệnh bị chặn →
    chỉ ghi lý do chặn (không đặt mốc hẹn)."""
    payload = command.get("payload") or {}
    reason = blocked_reason(command)
    if reason is not None:
        return {KEY_BLOCKED: reason}
    count = int(payload.get(KEY_COUNT) or 0) + 1
    due = now + timedelta(seconds=RETRY_DELAY_SECONDS)
    return {
        KEY_COUNT: count,
        KEY_AT: due.isoformat(timespec="seconds"),
        KEY_LAST_ERROR: str(command.get("error") or command.get("result") or "")[:300],
    }


def retry_due(command: dict, now: datetime) -> bool:
    """Lệnh failed này đã TỚI HẠN tự chạy lại chưa (có mốc hẹn, chưa
    bị huỷ hẹn, chưa bị chặn)."""
    if command.get("status") != "failed":
        return False
    payload = command.get("payload") or {}
    if payload.get(KEY_CANCELLED) or payload.get(KEY_BLOCKED):
        return False
    due = parse_iso(payload.get(KEY_AT))
    return due is not None and due <= now


def pending_countdown(command: dict, now: datetime) -> int | None:
    """Số giây còn lại tới lần tự chạy lại (None = không có hẹn đang
    chờ). UI dùng để hiện đếm ngược ở dòng lệnh."""
    if command.get("status") != "failed":
        return None
    payload = command.get("payload") or {}
    if payload.get(KEY_CANCELLED) or payload.get(KEY_BLOCKED):
        return None
    due = parse_iso(payload.get(KEY_AT))
    if due is None:
        return None
    return max(0, int((due - now).total_seconds()))
