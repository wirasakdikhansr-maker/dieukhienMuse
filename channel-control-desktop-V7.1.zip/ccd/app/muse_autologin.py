"""Đăng nhập HÀNG LOẠT muse.ai bằng hộp thư tinyhost.shop (V6.2).

Mỗi tài khoản Muse dùng một địa chỉ email tạm trên tinyhost.shop. Với
từng tài khoản, app làm đúng các bước người dùng vẫn làm tay — ngay
trong Chrome RIÊNG của tài khoản đó (data/agents/agent-<id>, xem
agent_browser) để phiên đăng nhập được giữ lại cho lần sau:

1. Mở tab https://tinyhost.shop/ → dán email vào ô địa chỉ → bấm
   "Check Inbox" (để hộp thư hiện ra, đồng thời ghi nhận các thư CŨ
   để lát nữa không lấy nhầm mã cũ).
2. Sang tab https://muse.ai/ → dán email vào ô "Mobile number or
   email" → bấm Continue.
3. Chờ ô nhập MÃ hiện ra trên muse.ai.
4. Quay lại tab tinyhost → bấm "Check Inbox" lặp lại, đọc bảng thư
   (kèm API công khai của tinyhost làm đường dự phòng) cho tới khi
   có thư MỚI chứa mã đăng nhập.
5. Quay lại muse.ai → dán mã → bấm xác nhận.
6. Kiểm tra đã đăng nhập (thấy ô soạn chat) → đóng tab tinyhost và
   thoát Chrome của tài khoản (phiên vẫn nằm trong thư mục Chrome
   riêng), chuyển sang tài khoản kế tiếp.

Gặp bước app không tự xử lý được (muse đòi thêm thông tin tạo tài
khoản, CAPTCHA, báo lỗi email...) thì DỪNG ở tài khoản đó, để nguyên
cửa sổ Chrome cho người dùng tự hoàn tất, và đi tiếp tài khoản sau.

Module thuần logic + CDP, không phụ thuộc Qt — kiểm thử bằng client giả.
"""

from __future__ import annotations

import json
import re
import time
import urllib.parse
import urllib.request

from . import agent_browser, cdp

TINYHOST_URL = "https://tinyhost.shop/"
TINYHOST_API = "https://tinyhost.shop/api/email/{domain}/{user}/?limit=20"

# Thời gian chờ mặc định (giây) — có thể ghi đè khi gọi.
DEFAULT_TIMEOUTS = {
    "page_ready": 25.0,
    "email_field": 40.0,
    "code_field": 45.0,
    "code_mail": 150.0,
    "resend_after": 60.0,
    "logged_in": 45.0,
}

MARK = "data-ccd-al"

# --------------------------------------------------------------------------- #
# Phân tích email / mã
# --------------------------------------------------------------------------- #


def split_address(email: str) -> tuple[str, str]:
    """'abc@domain.tld' -> ('abc', 'domain.tld'); sai định dạng -> ValueError."""
    value = (email or "").strip().lower()
    if value.count("@") != 1:
        raise ValueError(f"Email không hợp lệ: {email!r}")
    user, domain = value.split("@", 1)
    if not user or "." not in domain:
        raise ValueError(f"Email không hợp lệ: {email!r}")
    return user, domain


_KEYWORD_CODE = re.compile(
    r"(?:code|otp|m[ãa](?:\s*x[áa]c\s*(?:nh[ậa]n|minh))?|verification|confirm\w*|"
    r"login|log\s*in|sign\s*in|passcode)"
    r"[^A-Za-z0-9]{0,40}?(?:is|l[àa]|:)?[^A-Za-z0-9]{0,6}([A-Z0-9]{4,8})\b",
    re.IGNORECASE,
)
_CODE_BEFORE_KEYWORD = re.compile(
    r"\b(\d{4,8})\b[^A-Za-z0-9]{0,6}(?:is your|là mã|is the)", re.IGNORECASE
)
_DIGITS = re.compile(r"(?<![\d.:/-])(\d{4,8})(?![\d.:/-])")
_NOISE = [
    re.compile(r"\b\d{1,2}[:.]\d{2}(?::\d{2})?\b"),           # giờ
    re.compile(r"\b\d{4}-\d{2}-\d{2}(?:[T ]\S+)?"),            # ngày ISO
    re.compile(r"\b\d{1,2}/\d{1,2}/\d{2,4}\b"),                # ngày d/m/y
    re.compile(r"https?://\S+"),                               # link
    re.compile(r"#[0-9a-fA-F]{3,8}\b"),                        # mã màu
]


def _strip_noise(text: str) -> str:
    out = text or ""
    for pattern in _NOISE:
        out = pattern.sub(" ", out)
    return out


def _looks_like_code(token: str) -> bool:
    if not token:
        return False
    if token.isdigit():
        if len(token) == 4 and 1900 <= int(token) <= 2100:
            return False  # năm
        return 4 <= len(token) <= 8
    # mã chữ+số: phải có ít nhất một chữ số và viết HOA (tránh bắt chữ thường)
    return token.isupper() and any(c.isdigit() for c in token) and 5 <= len(token) <= 8


def extract_code(text: str) -> str | None:
    """Lấy mã đăng nhập từ tiêu đề/nội dung thư. Ưu tiên số đứng cạnh
    từ khoá 'code / mã / verification', rồi tới chuỗi 6 chữ số, rồi
    chuỗi 4-8 chữ số bất kỳ (đã lọc giờ/ngày/năm/link)."""
    if not text:
        return None
    clean = _strip_noise(text)
    for pattern in (_KEYWORD_CODE, _CODE_BEFORE_KEYWORD):
        for match in pattern.finditer(clean):
            token = match.group(1)
            if _looks_like_code(token):
                return token
    digits = [m.group(1) for m in _DIGITS.finditer(clean)]
    digits = [d for d in digits if _looks_like_code(d)]
    for token in digits:
        if len(token) == 6:
            return token
    return digits[0] if digits else None


def _mail_text(mail: dict) -> str:
    parts = [str(mail.get(key) or "") for key in ("subject", "body", "text")]
    html = str(mail.get("html_body") or "")
    if html and not mail.get("body"):
        parts.append(re.sub(r"<[^>]+>", " ", html))
    return "\n".join(p for p in parts if p)


def _mail_key(mail: dict) -> str:
    if mail.get("id") not in (None, ""):
        return f"id:{mail['id']}"
    return "t:" + " ".join(_mail_text(mail).split())[:300]


def pick_new_code(mails: list[dict], seen: set[str], seen_codes: set[str] | None = None) -> str | None:
    """Thư MỚI (khoá chưa nằm trong ``seen``) đầu tiên có mã → mã đó.
    Mã đã thấy trong thư CŨ (``seen_codes``) bị bỏ qua — dòng bảng có
    thể đổi chữ (vd "1 phút trước") nên khoá thư không đủ chắc.
    Ưu tiên thư đến từ Muse/Meta."""
    seen_codes = seen_codes or set()
    fresh = [m for m in mails or [] if _mail_key(m) not in seen]

    def rank(mail):
        sender = (str(mail.get("sender") or "") + " " + str(mail.get("subject") or "")).lower()
        return 0 if ("muse" in sender or "meta" in sender) else 1

    for mail in sorted(fresh, key=rank):
        code = extract_code(_mail_text(mail))
        if code and code not in seen_codes:
            return code
    return None


# --------------------------------------------------------------------------- #
# JavaScript chạy trong trang
# --------------------------------------------------------------------------- #

_JS_HELPERS = r"""
  const MARK = 'data-ccd-al';
  const visible = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (!(r.width > 0 && r.height > 0)) return false;
    const st = getComputedStyle(el);
    return st.visibility !== 'hidden' && st.display !== 'none' && st.opacity !== '0';
  };
  const meta = el => [el.name, el.id, el.placeholder, el.getAttribute('aria-label'),
    el.getAttribute('autocomplete'), el.getAttribute('inputmode'),
    (el.labels && el.labels[0] ? el.labels[0].innerText : '')].join(' ').toLowerCase();
  const mark = (el, key) => {
    document.querySelectorAll('[' + MARK + '="' + key + '"]').forEach(x => x.removeAttribute(MARK));
    el.setAttribute(MARK, key);
  };
  const textInputs = () => [...document.querySelectorAll('input, textarea')].filter(el => {
    const t = (el.type || 'text').toLowerCase();
    return visible(el) && !el.disabled && !el.readOnly &&
      ['text', 'email', 'tel', 'number', 'search', 'textarea', ''].includes(t);
  });
  const clickables = () => [...document.querySelectorAll(
    'button, a, [role="button"], input[type="button"], input[type="submit"], label'
  )].filter(el => visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
  const labelOf = el => ((el.innerText || el.value || el.getAttribute('aria-label') || '') + '').trim();
"""

# Đánh dấu nút có chữ khớp regex (để Python bấm bằng chuột thật).
MARK_BUTTON_JS = (
    "/*ccd:al-mark-button*/(() => {" + _JS_HELPERS + r"""
  const re = new RegExp(%(pattern)s, 'i');
  const hit = clickables().find(el => re.test(labelOf(el)));
  if (!hit) return null;
  mark(hit, %(key)s);
  return labelOf(hit).slice(0, 60);
})()"""
)

# Ô địa chỉ của tinyhost: điền cả email, hoặc phần tên + chọn tên miền
# nếu trang tách thành ô tên + danh sách tên miền.
TINYHOST_PREPARE_JS = (
    "/*ccd:al-tinyhost-prepare*/(() => {" + _JS_HELPERS + r"""
  const email = %(email)s, user = %(user)s, domain = %(domain)s;
  const inputs = textInputs().filter(el => !/search|tìm/.test(meta(el)));
  if (!inputs.length) return { ok: false, reason: 'no-input' };
  const ranked = inputs.slice().sort((a, b) => {
    const score = el => (/mail|user|name|address|địa chỉ|login/.test(meta(el)) ? 0 : 1);
    return score(a) - score(b);
  });
  const input = ranked[0];
  let mode = 'full';
  const select = [...document.querySelectorAll('select')].find(s => visible(s) &&
    [...s.options].some(o => /\.[a-z]{2,}/i.test(o.value || o.text)));
  if (select) {
    let opt = [...select.options].find(o =>
      (o.value || '').toLowerCase().replace(/^@/, '') === domain ||
      (o.text || '').trim().toLowerCase().replace(/^@/, '') === domain);
    if (!opt) {
      opt = document.createElement('option');
      opt.value = domain; opt.text = domain;
      select.appendChild(opt);
    }
    select.value = opt.value;
    select.dispatchEvent(new Event('input', { bubbles: true }));
    select.dispatchEvent(new Event('change', { bubbles: true }));
    mode = 'split';
  }
  mark(input, 'th-email');
  return { ok: true, mode, value: mode === 'split' ? user : email };
})()"""
)

# Bảng hộp thư tinyhost: mỗi dòng một chuỗi chữ (người gửi, tiêu đề, ...).
TINYHOST_ROWS_JS = r"""/*ccd:al-tinyhost-rows*/(() => {
  const rows = [...document.querySelectorAll('table tbody tr, table tr')]
    .map(tr => (tr.innerText || '').replace(/\s+/g, ' ').trim())
    .filter(t => t && !/^sender\s+subject/i.test(t));
  const extra = [...document.querySelectorAll('.modal, [role="dialog"], .email-body, .mail-body, iframe')]
    .map(el => { try { return el.tagName === 'IFRAME'
      ? (el.contentDocument && el.contentDocument.body ? el.contentDocument.body.innerText : '')
      : el.innerText; } catch (e) { return ''; } })
    .filter(Boolean).map(t => t.replace(/\s+/g, ' ').trim().slice(0, 2000));
  return { rows: [...new Set(rows)].slice(0, 50), extra };
})()"""

# Gọi API công khai của tinyhost NGAY trong tab tinyhost (cùng origin).
TINYHOST_API_JS = r"""/*ccd:al-tinyhost-api*/
fetch('/api/email/' + encodeURIComponent(%(domain)s) + '/' + encodeURIComponent(%(user)s) + '/?limit=20',
      { cache: 'no-store' })
  .then(r => r.ok ? r.json() : { emails: [] })
  .then(d => (d.emails || []).map(m => ({ id: m.id, subject: m.subject || '', sender: m.sender || '',
       date: m.date || '', body: (m.body || '').slice(0, 3000),
       html_body: m.body ? '' : (m.html_body || '').slice(0, 6000) })))
  .catch(() => null)"""

# Trạng thái trang muse.ai + đánh dấu ô email / ô mã.
MUSE_LOGIN_STATE_JS = (
    "/*ccd:al-muse-state*/(() => {" + _JS_HELPERS + r"""
  const text = (document.body ? document.body.innerText : '').slice(0, 5000);
  const inputs = textInputs();
  const askCodeEarly = /enter (the )?code|check your (email|inbox)|we sent|verification code|confirmation code|nhập mã/i.test(text);
  const codeRe = /one-time-code|otp|code|mã|verification|passcode|pin/;
  const boxes = inputs.filter(el => String(el.maxLength) === '1');
  let codeCount = 0;
  if (boxes.length >= 4) {
    boxes.forEach((el, i) => mark(el, 'muse-code-' + i));
    codeCount = boxes.length;
  } else {
    const code = inputs.find(el => codeRe.test(meta(el))) ||
      inputs.find(el => /numeric/.test(el.getAttribute('inputmode') || '') &&
                        el.maxLength > 0 && el.maxLength <= 8);
    if (!code && askCodeEarly && inputs.length === 1) code = inputs[0];
    if (code) { mark(code, 'muse-code-0'); codeCount = 1; }
  }
  let hasEmail = false;
  if (!codeCount) {
    const email = inputs.find(el => (el.type === 'email') ||
      /mail|mobile|phone|điện thoại|identifier|username|contact/.test(meta(el)));
    const lone = inputs.length === 1 && /log in|sign in|create (an )?account|đăng nhập/i.test(text) &&
      !document.querySelector('textarea') ? inputs[0] : null;
    const target = email || lone;
    if (target) { mark(target, 'muse-email'); hasEmail = true; }
  }
  const composer = !hasEmail && !codeCount && !!document.querySelector(
    'textarea, [contenteditable="true"], [data-testid="chat-input"]');
  const loginish = /log in|sign in|sign up|get started|create (your )?account|đăng nhập/i.test(text);
  const askCode = /enter (the )?code|check your (email|inbox)|we sent|verification code|confirmation code|nhập mã/i.test(text);
  const errorText = (/(invalid|incorrect|wrong|expired|try again|something went wrong|không hợp lệ|sai mã)[^\n]{0,80}/i.exec(text) || [''])[0];
  const captcha = !!document.querySelector('iframe[src*="captcha"], iframe[title*="challenge" i], #captcha') ||
    /captcha|i'?m not a robot|security check/i.test(text);
  const profileForm = /birthday|date of birth|ngày sinh|your name|full name|create your account|họ và tên/i.test(text);
  return { url: location.href, hasEmail, codeCount, hasComposer: composer, loginish,
           askCode, errorText, captcha, profileForm };
})()"""
)

READY_JS = "document.readyState"


# --------------------------------------------------------------------------- #
# Kết nối tab
# --------------------------------------------------------------------------- #


def _ws_for_target(port: int, target_id: str) -> str:
    for target in cdp.http_json(port, "/json/list"):
        if target.get("id") == target_id and target.get("webSocketDebuggerUrl"):
            return target["webSocketDebuggerUrl"]
    raise cdp.CDPError(f"Tab {target_id} không còn trên cổng {port}")


def _open_tab(port: int, url: str) -> dict:
    path = "/json/new?" + url
    try:
        return cdp.http_json(port, path, method="PUT")
    except Exception:
        return cdp.http_json(port, path)


def _first_page(port: int, exclude: tuple[str, ...] = ()) -> dict | None:
    for target in cdp.http_json(port, "/json/list"):
        if target.get("type") != "page" or not target.get("webSocketDebuggerUrl"):
            continue
        url = target.get("url") or ""
        if any(token in url for token in exclude):
            continue
        return target
    return None


class _Tab:
    """Một tab CDP gắn theo targetId (tự xin lại websocket khi rớt)."""

    def __init__(self, port: int, target: dict, client_factory=None):
        self.port = port
        self.id = target["id"]
        factory = client_factory or (
            lambda ws, reconnect: cdp.CDPClient(ws, reconnect=reconnect)
        )
        self.client = factory(
            target["webSocketDebuggerUrl"],
            lambda: _ws_for_target(port, self.id),
        )

    def close(self, close_tab: bool = False):
        try:
            self.client.close()
        except Exception:
            pass
        if close_tab:
            try:
                cdp.http_json(self.port, f"/json/close/{self.id}")
            except Exception:
                pass


# --------------------------------------------------------------------------- #
# Luồng đăng nhập một tài khoản
# --------------------------------------------------------------------------- #


class StopRequested(Exception):
    pass


class MuseAutoLogin:
    """Chạy luồng đăng nhập cho MỘT tài khoản. ``manager`` là
    ChromeManager; ``say(msg)`` báo tiến độ; ``should_stop()`` True thì
    dừng sớm. Các tham số sleep/clock/http_get/tab_factory để kiểm thử."""

    def __init__(
        self,
        manager,
        agent: dict,
        say=None,
        should_stop=None,
        timeouts: dict | None = None,
        close_on_success: bool = True,
        hidden: bool = False,
        sleep=time.sleep,
        clock=time.monotonic,
        http_get=None,
        tab_factory=None,
    ):
        self.manager = manager
        self.agent = agent
        self.email = (agent.get("email") or "").strip().lower()
        self.user, self.domain = split_address(self.email)
        self.say = say or (lambda _m: None)
        self.should_stop = should_stop or (lambda: False)
        self.timeouts = dict(DEFAULT_TIMEOUTS, **(timeouts or {}))
        self.close_on_success = close_on_success
        # V6.5.2: đăng nhập lại TỰ ĐỘNG (nền) → Chrome chạy ngoài màn hình,
        # không bật lên giao diện; bấm tay "Đăng nhập hàng loạt" vẫn hiện.
        self.hidden = hidden
        self.sleep = sleep
        self.clock = clock
        self.http_get = http_get or _http_get_json
        self.tab_factory = tab_factory
        self.pseudo = agent_browser.agent_profile(agent)
        self.port = self.pseudo["port"]
        self.muse: _Tab | None = None
        self.mail: _Tab | None = None
        self.seen: set[str] = set()
        self.seen_codes: set[str] = set()
        self.name = agent.get("name") or self.email

    # -------------------------------------------------------------- tiện ích
    def _log(self, msg: str):
        self.say(f"[{self.name}] {msg}")

    def _check_stop(self):
        if self.should_stop():
            raise StopRequested("Người dùng đã dừng đăng nhập hàng loạt.")

    def _wait(self, seconds: float):
        end = self.clock() + seconds
        while self.clock() < end:
            self._check_stop()
            self.sleep(min(0.5, max(0.0, end - self.clock())))

    def _eval(self, tab: _Tab, js: str, timeout: float = 15.0):
        try:
            return tab.client.evaluate(js, timeout=timeout)
        except Exception:
            return None

    def _wait_ready(self, tab: _Tab):
        end = self.clock() + self.timeouts["page_ready"]
        self._wait(1.0)
        while self.clock() < end:
            if self._eval(tab, READY_JS) == "complete":
                self._wait(0.8)
                return
            self._wait(0.5)

    def _click_text(self, tab: _Tab, pattern: str, key: str) -> str | None:
        label = self._eval(
            tab,
            MARK_BUTTON_JS % {"pattern": json.dumps(pattern), "key": json.dumps(key)},
        )
        if not label:
            return None
        try:
            tab.client.click_element(selector=f'[{MARK}="{key}"]')
        except Exception:
            # Chuột thật lỗi → bấm bằng JS.
            self._eval(tab, f'document.querySelector(\'[{MARK}="{key}"]\').click()')
        return label

    def _fill(self, tab: _Tab, key: str, value: str):
        tab.client.fill_element(f'[{MARK}="{key}"]', value)

    # -------------------------------------------------------------- tinyhost
    def _mail_snapshot(self) -> list[dict]:
        """Danh sách thư hiện có: bảng trên trang + API trong tab +
        API gọi thẳng từ app (dự phòng). Mỗi thư là dict có subject/body."""
        mails: list[dict] = []
        api = self._eval(
            self.mail,
            TINYHOST_API_JS % {"domain": json.dumps(self.domain), "user": json.dumps(self.user)},
            timeout=20,
        )
        if isinstance(api, list):
            mails.extend(api)
        else:
            try:
                data = self.http_get(TINYHOST_API.format(
                    domain=urllib.parse.quote(self.domain), user=urllib.parse.quote(self.user)))
                mails.extend((data or {}).get("emails") or [])
            except Exception:
                pass
        rows = self._eval(self.mail, TINYHOST_ROWS_JS) or {}
        for text in (rows.get("rows") or []) + (rows.get("extra") or []):
            mails.append({"subject": text})
        return mails

    def _open_tinyhost(self):
        self._log("Mở tinyhost.shop và dán email…")
        target = _open_tab(self.port, TINYHOST_URL)
        self.mail = _Tab(self.port, target, self.tab_factory)
        self._wait_ready(self.mail)
        prep = self._eval(
            self.mail,
            TINYHOST_PREPARE_JS % {
                "email": json.dumps(self.email),
                "user": json.dumps(self.user),
                "domain": json.dumps(self.domain),
            },
        ) or {}
        if prep.get("ok"):
            try:
                self._fill(self.mail, "th-email", prep.get("value") or self.email)
                self._wait(0.4)
                if not self._click_text(self.mail, r"check\s*inbox|^check$|kiểm tra|xem hộp thư", "th-check"):
                    self.mail.client.press_key("Enter")
            except Exception as exc:
                self._log(f"Không điền được ô email trên tinyhost ({exc}) — dùng API hộp thư.")
        else:
            self._log("Không thấy ô email trên tinyhost — dùng API hộp thư để đọc mã.")
        self._wait(2.0)
        # Ghi nhận thư CŨ để không lấy nhầm mã của lần trước.
        for mail in self._mail_snapshot():
            self.seen.add(_mail_key(mail))
            old = extract_code(_mail_text(mail))
            if old:
                self.seen_codes.add(old)

    def _wait_for_code(self) -> str | None:
        self._log("Đợi mã đăng nhập về hộp thư tinyhost…")
        try:
            self.mail.client.bring_to_front()
        except Exception:
            pass
        start = self.clock()
        resent = False
        while self.clock() - start < self.timeouts["code_mail"]:
            self._click_text(self.mail, r"check\s*inbox|^check$|refresh|làm mới|kiểm tra", "th-check")
            self._wait(2.5)
            mails = self._mail_snapshot()
            code = pick_new_code(mails, self.seen, self.seen_codes)
            if code:
                return code
            if any(_mail_key(m) not in self.seen for m in mails):
                # Có thư mới nhưng tiêu đề không chứa mã → mở thư để đọc nội dung.
                if self._click_text(self.mail, r"^(view|open|read|xem|mở)\b", "th-open"):
                    self._wait(2.0)
                    code = pick_new_code(self._mail_snapshot(), self.seen, self.seen_codes)
                    if code:
                        return code
            if not resent and self.clock() - start > self.timeouts["resend_after"]:
                resent = True
                if self._click_text(self.muse, r"resend|send (a )?new code|gửi lại", "muse-resend"):
                    self._log("Chưa thấy mã — đã bấm gửi lại mã trên muse.ai.")
            self._wait(3.0)
        return None

    # -------------------------------------------------------------- muse
    def _muse_state(self) -> dict:
        return self._eval(self.muse, MUSE_LOGIN_STATE_JS) or {}

    def _is_in(self, state: dict) -> bool:
        if state.get("hasEmail") or state.get("codeCount"):
            return False
        return agent_browser.classify_muse_state(state) == "in"

    def _wait_state(self, predicate, timeout: float) -> dict:
        end = self.clock() + timeout
        state: dict = {}
        while self.clock() < end:
            state = self._muse_state()
            if predicate(state):
                return state
            self._wait(1.0)
        return state

    def _enter_code(self, code: str, count: int):
        if count > 1:
            for i, ch in enumerate(code[:count]):
                self._fill(self.muse, f"muse-code-{i}", ch)
                self._wait(0.12)
        else:
            self._fill(self.muse, "muse-code-0", code)
        self._wait(0.6)
        if not self._click_text(
            self.muse, r"^(continue|next|verify|confirm|submit|log ?in|sign ?in|tiếp tục|xác nhận|đăng nhập)$", "muse-submit"
        ):
            try:
                self.muse.client.press_key("Enter")
            except Exception:
                pass

    # -------------------------------------------------------------- chính
    def run(self) -> dict:
        """Trả {'status': 'already'|'ok'|'needs_user'|'no_code'|'error'|
        'stopped', 'message': str}."""
        try:
            return self._run()
        except StopRequested as exc:
            return {"status": "stopped", "message": str(exc)}
        except Exception as exc:  # noqa: BLE001 — báo lỗi cho từng tài khoản
            return {"status": "error", "message": f"{type(exc).__name__}: {exc}"}
        finally:
            for tab in (self.mail, self.muse):
                if tab is not None:
                    tab.close()

    def _run(self) -> dict:
        self._check_stop()
        self._log("Mở Chrome riêng của tài khoản…")
        # V6.7: luôn chạy nền (ngoài màn hình + khỏi taskbar) — tiến trình
        # đăng nhập hiện trong nhật ký, không bật cửa sổ ra màn hình.
        try:
            self.manager.launch(self.pseudo, hidden=True)
        except TypeError:
            self.manager.launch(self.pseudo)
        target = _first_page(self.port, exclude=("tinyhost",))
        if target is None:
            target = _open_tab(self.port, agent_browser.MUSE_URL)
        self.muse = _Tab(self.port, target, self.tab_factory)
        self.muse.client.navigate(agent_browser.MUSE_URL)
        self._wait_ready(self.muse)

        state = self._muse_state()
        if self._is_in(state):
            self._finish(success=True)
            return {"status": "already", "message": "Đã đăng nhập muse.ai sẵn."}

        # Bước 1: tinyhost — dán email, ghi nhận thư cũ.
        self._open_tinyhost()

        # Bước 2: muse — dán email, bấm Continue.
        self._log("Dán email vào muse.ai…")
        try:
            self.muse.client.bring_to_front()
        except Exception:
            pass
        state = self._wait_state(lambda s: s.get("hasEmail") or s.get("codeCount") or self._is_in(s), 4.0)
        if not state.get("hasEmail") and not state.get("codeCount"):
            self._click_text(self.muse, r"^(log ?in|sign ?in|đăng nhập)$", "muse-open-login")
            state = self._wait_state(
                lambda s: s.get("hasEmail") or s.get("codeCount") or self._is_in(s),
                self.timeouts["email_field"],
            )
        if self._is_in(state):
            self._finish(success=True)
            return {"status": "already", "message": "Đã đăng nhập muse.ai sẵn."}
        if not state.get("codeCount"):
            if not state.get("hasEmail"):
                return self._needs_user("không tìm thấy ô nhập email trên muse.ai")
            self._fill(self.muse, "muse-email", self.email)
            self._wait(0.5)
            if not self._click_text(
                self.muse, r"^(continue|next|tiếp tục|tiếp|send code|gửi mã|log ?in|sign ?in)$", "muse-continue"
            ):
                self.muse.client.press_key("Enter")

            # Bước 3: chờ ô nhập mã hiện ra.
            self._log("Đã bấm Continue — chờ ô nhập mã…")
            state = self._wait_state(
                lambda s: s.get("codeCount") or s.get("captcha") or self._is_in(s),
                self.timeouts["code_field"],
            )
            if self._is_in(state):
                self._finish(success=True)
                return {"status": "ok", "message": "Đăng nhập thành công."}
            if state.get("captcha"):
                return self._needs_user("muse.ai yêu cầu CAPTCHA/kiểm tra bảo mật")
            if not state.get("codeCount"):
                detail = state.get("errorText") or "không thấy ô nhập mã"
                return self._needs_user(f"sau khi bấm Continue: {detail}")

        # Bước 4: lấy mã từ tinyhost.
        code = self._wait_for_code()
        if not code:
            self._leave_open()
            return {"status": "no_code", "message": "Hết thời gian chờ mà không nhận được mã trong hộp thư tinyhost."}
        self._log(f"Đã có mã ({code[:2]}…) — dán vào muse.ai.")

        # Bước 5: dán mã.
        try:
            self.muse.client.bring_to_front()
        except Exception:
            pass
        state = self._muse_state()
        self._enter_code(code, int(state.get("codeCount") or 1))

        # Bước 6: kiểm tra đăng nhập thành công.
        state = self._wait_state(
            lambda s: self._is_in(s) or s.get("profileForm") or s.get("captcha"),
            self.timeouts["logged_in"],
        )
        if self._is_in(state):
            self._finish(success=True)
            return {"status": "ok", "message": "Đăng nhập thành công."}
        if state.get("profileForm"):
            return self._needs_user("muse.ai đòi điền thêm thông tin tạo tài khoản")
        detail = state.get("errorText") or "chưa thấy giao diện đã đăng nhập"
        return self._needs_user(f"sau khi dán mã: {detail}")

    def _needs_user(self, reason: str) -> dict:
        self._leave_open()
        return {
            "status": "needs_user",
            "message": f"Cần bạn tự hoàn tất ({reason}) — cửa sổ Chrome của tài khoản để nguyên.",
        }

    def _leave_open(self):
        if self.mail is not None:
            self.mail.close(close_tab=False)
            self.mail = None

    def _finish(self, success: bool):
        if self.mail is not None:
            self.mail.close(close_tab=True)
            self.mail = None
        if success and self.close_on_success:
            self._log("Đăng nhập xong — thoát Chrome của tài khoản (phiên được giữ lại).")
            if self.muse is not None:
                self.muse.close()
                self.muse = None
            self._wait(1.0)  # để cookie phiên kịp ghi xuống đĩa
            try:
                cdp.browser_call(self.port, "Browser.close")
            except Exception:
                pass


def _http_get_json(url: str, timeout: float = 15.0):
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def run_batch(manager, agents: list[dict], say=None, should_stop=None, on_result=None,
              close_on_success: bool = True, pause_s: float = 2.0, **kwargs) -> list[dict]:
    """Đăng nhập lần lượt từng tài khoản. ``on_result(agent, result)``
    được gọi sau mỗi tài khoản. Trả danh sách kết quả."""
    say = say or (lambda _m: None)
    should_stop = should_stop or (lambda: False)
    sleep = kwargs.get("sleep", time.sleep)
    results: list[dict] = []
    total = len(agents)
    for index, agent in enumerate(agents, start=1):
        if should_stop():
            break
        say(f"({index}/{total}) Bắt đầu đăng nhập {agent.get('email')}…")
        try:
            runner = MuseAutoLogin(manager, agent, say=say, should_stop=should_stop,
                                   close_on_success=close_on_success, **kwargs)
            result = runner.run()
        except ValueError as exc:
            result = {"status": "error", "message": str(exc)}
        result = dict(result, agent_id=agent.get("id"), email=agent.get("email"))
        results.append(result)
        if on_result is not None:
            on_result(agent, result)
        if result["status"] == "stopped":
            break
        if index < total:
            sleep(pause_s)
    return results
