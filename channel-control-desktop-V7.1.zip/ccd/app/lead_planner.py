"""V7.0.1 — TRƯỞNG PHÒNG TỰ LÊN KẾ HOẠCH & GIAO VIỆC cho mọi agent.

Mỗi nhịp (tự tiết lưu ``PLAN_EVERY_MIN`` phút, chỉ trong giờ làm việc):

1. Duyệt từng KÊNH (YouTube / fanpage / kênh TikTok) của mọi hồ sơ không tạm dừng.
2. Kênh chưa có ai phụ trách → giao hồ sơ cho agent ÍT VIỆC nhất (phân bố đều).
3. Kênh chưa đủ ``quota`` việc nội dung hôm nay, KHÔNG có việc nội dung nào đang
   mở, và đã cách lần giao trước ≥ ``min_gap_hours`` → tạo 1 việc cho agent phụ
   trách kênh (agent đang ôm quá ``max_open`` việc thì chuyển cho agent rảnh nhất
   và phân công hồ sơ cho người đó).
4. CHỐNG TRÙNG: mỗi việc có khoá ``plan:<kênh>:<ngày>:<lượt>`` (store không tạo
   trùng khoá), và nội dung việc liệt kê các tiêu đề/chủ đề kênh đã làm gần đây
   + của các kênh khác cùng hồ sơ để agent KHÔNG lặp lại.
5. CHUẨN KIẾM TIỀN / KHÔNG SPAM: mỗi việc kèm bộ quy tắc của nền tảng (nội dung
   gốc, không reup, không mẫu lặp hàng loạt, tiêu đề/thumbnail đúng nội dung,
   bản quyền nhạc/hình, nhịp đăng giãn cách) và yêu cầu nghiên cứu chủ đề đang
   có lượt xem trong ngách trước khi làm.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from . import platforms
from .store import Store, _parse_iso

THROTTLE_KEY = "lead_planner_last_run"
PLAN_EVERY_MIN = 10
CONTENT_TYPES = ("create_video", "upload")
OPEN = ("queued", "waiting_muse", "running", "needs_user")

DEFAULTS = {
    "lead_autoplan": True,
    "lead_plan_quota": {"youtube": 1, "facebook": 1, "tiktok": 1},
    "lead_plan_min_gap_hours": 6,
    "lead_plan_max_open": 3,
}

RULES = {
    "youtube": [
        "Nội dung GỐC, có giá trị riêng (lời bình, kịch bản, giọng đọc, dựng của mình) — KHÔNG reup, không ghép clip người khác, "
        "không video hàng loạt cùng một khuôn chỉ đổi chữ (YouTube coi là nội dung lặp lại / tái sử dụng → không được bật kiếm tiền).",
        "Nhạc, hình, footage: chỉ dùng nguồn có giấy phép / thư viện YouTube / tự tạo — không dính Content ID.",
        "Tiêu đề + thumbnail ĐÚNG nội dung (không giật tít sai sự thật), mô tả có giá trị, 3–8 thẻ liên quan, không nhồi từ khoá.",
        "Không vi phạm Nguyên tắc cộng đồng; không nội dung nhạy cảm, gây hiểu lầm, nhắm trẻ em mà không đánh dấu 'Dành cho trẻ em'.",
        "Giữ đúng ngách + phong cách kênh để tích luỹ giờ xem (điều kiện 1.000 người đăng ký + 4.000 giờ xem/12 tháng hoặc 10 triệu lượt xem Shorts/90 ngày).",
    ],
    "facebook": [
        "Nội dung GỐC của page — không đăng lại video/ảnh của người khác (Facebook hạn chế kiếm tiền với nội dung không gốc).",
        "Không câu tương tác (xin like/share/tag), không tiêu đề giật tít sai sự thật, không link spam.",
        "Không đăng dồn dập: giãn cách bài, không đăng cùng một bài lên nhiều page.",
        "Nhạc chỉ dùng thư viện nhạc được phép của Facebook/Meta.",
    ],
    "tiktok": [
        "Video GỐC quay/dựng riêng, ≥ 1 phút nếu nhắm Creator Rewards — không reup, không watermark nền tảng khác.",
        "Không nội dung lặp hàng loạt, không caption/hashtag spam (3–5 hashtag liên quan).",
        "Nhạc trong thư viện thương mại TikTok; tuân thủ Nguyên tắc cộng đồng.",
    ],
}
VIEW_RULES = [
    "Trước khi làm: xem 10 video/bài đang có nhiều lượt xem nhất trong ngách (7–30 ngày gần đây) → chọn chủ đề đang lên mà kênh CHƯA làm.",
    "Câu mở đầu (3–5 giây đầu) phải giữ chân người xem; nhịp dựng nhanh, có cao trào; kết bằng lời mời xem video tiếp theo của kênh.",
    "Đăng vào khung giờ khán giả chính hoạt động nhiều nhất; báo cáo kèm lý do chọn chủ đề + từ khoá.",
]
TASK_LABEL = {
    "youtube": ("create_video", "Video mới chuẩn kiếm tiền"),
    "facebook": ("upload", "Reels/bài mới cho page"),
    "tiktok": ("create_video", "Video TikTok mới"),
}


def cfg(settings: dict | None) -> dict:
    out = dict(DEFAULTS)
    for key in DEFAULTS:
        if settings and key in settings:
            out[key] = settings[key]
    quota = dict(DEFAULTS["lead_plan_quota"])
    quota.update(out.get("lead_plan_quota") or {})
    out["lead_plan_quota"] = quota
    return out


def _load(store: Store, agent_id: int) -> int:
    row = store._conn.execute(
        "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND status IN (?,?,?,?)",
        (int(agent_id), *OPEN)).fetchone()
    return int(row[0] if row else 0)


def _agents(store: Store) -> list[dict]:
    return [a for a in store.list_agents() if not a.get("revoked")]


def _least_loaded(store: Store, exclude: set[int] | None = None) -> dict | None:
    candidates = [a for a in _agents(store) if int(a["id"]) not in (exclude or set())]
    if not candidates:
        return None
    return min(candidates, key=lambda a: (_load(store, a["id"]), int(a["id"])))


def _channel_commands(store: Store, profile_id: int, channel_id: str, since: str) -> list[dict]:
    from .store import _command_row

    rows = store._conn.execute(
        "SELECT * FROM commands WHERE profile_id = ? AND channel_id = ? AND type IN (?, ?)"
        " AND (status IN (?,?,?,?) OR created_at >= ?) ORDER BY created_at DESC LIMIT 60",
        (int(profile_id), channel_id, *CONTENT_TYPES, *OPEN, since)).fetchall()
    return [_command_row(r) for r in rows]


def _recent_titles(store: Store, profile_id: int, channel_id: str | None, limit: int = 10) -> list[str]:
    from .store import _command_row

    if channel_id is None:
        rows = store._conn.execute(
            "SELECT * FROM commands WHERE profile_id = ? AND type IN (?, ?) AND status = 'done'"
            " ORDER BY finished_at DESC LIMIT ?", (int(profile_id), *CONTENT_TYPES, limit)).fetchall()
    else:
        rows = store._conn.execute(
            "SELECT * FROM commands WHERE profile_id = ? AND channel_id = ? AND type IN (?, ?)"
            " AND status IN ('done','running','waiting_muse','queued') ORDER BY created_at DESC LIMIT ?",
            (int(profile_id), channel_id, *CONTENT_TYPES, limit)).fetchall()
    titles = []
    for row in rows:
        c = _command_row(row)
        payload = c.get("payload") or {}
        result = (c.get("result") or "").strip()
        if result:
            first = next((ln for ln in result.splitlines() if ln.strip()), "")
            text = first.split(":", 1)[1] if first.upper().startswith(("KẾT QUẢ", "TIÊU ĐỀ")) and ":" in first else first
        elif payload.get("plan"):
            continue  # việc trưởng phòng vừa giao, chưa có chủ đề cụ thể
        else:
            text = payload.get("title") or (c.get("instruction") or "").splitlines()[0] if c.get("instruction") else ""
        text = " ".join((text or "").split())
        if text and text not in titles:
            titles.append(text[:120])
    return titles


def build_instruction(channel: dict, profile: dict, platform: str, own_titles: list[str],
                      sibling_titles: list[str], slot: int, quota: int) -> str:
    meta = platforms.info(platform)
    name = channel.get("name") or channel.get("handle") or profile.get("label") or ""
    lines = [
        f"Trưởng phòng giao: làm 1 nội dung MỚI cho {meta['unit']} '{name}' ({platforms.label(platform)}) — "
        f"lượt {slot}/{quota} hôm nay. Tự chọn chủ đề theo ngách kênh, làm trọn: nghiên cứu → kịch bản → dựng → đăng.",
        "",
        "ĐẢM BẢO CÓ VIEW:",
        *[f"- {r}" for r in VIEW_RULES],
        "",
        "CHUẨN KIẾM TIỀN & KHÔNG SPAM:",
        *[f"- {r}" for r in RULES.get(platform, RULES["youtube"])],
    ]
    if own_titles:
        lines += ["", "KHÔNG LẶP LẠI các chủ đề kênh đã làm/đang làm gần đây:", *[f"- {t}" for t in own_titles[:10]]]
    if sibling_titles:
        lines += ["", "KHÔNG trùng nội dung với các kênh khác cùng tài khoản (đang/đã làm):",
                  *[f"- {t}" for t in sibling_titles[:8]]]
    lines += ["", "Báo KẾT QUẢ kèm: tiêu đề, link đã đăng, chủ đề + lý do chọn, từ khoá chính."]
    return "\n".join(lines)


def plan(store: Store, settings: dict | None, now: datetime | None = None) -> list[dict]:
    """Một lượt lên kế hoạch. Trả danh sách việc vừa giao (dict lệnh)."""
    c = cfg(settings)
    if not c["lead_autoplan"]:
        return []
    now = now or datetime.now().astimezone()
    day = now.date().isoformat()
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0).isoformat(timespec="seconds")
    gap = timedelta(hours=float(c["lead_plan_min_gap_hours"]))
    max_open = int(c["lead_plan_max_open"])
    created: list[dict] = []
    if not _agents(store):
        return []
    for profile in store.list_profiles():
        if profile.get("paused"):
            continue
        platform = platforms.of(profile)
        quota = int(c["lead_plan_quota"].get(platform, 1) or 0)
        if quota <= 0:
            continue
        channels = store.list_channels(profile["id"])
        if not channels:
            continue
        owner = store.agent_for_profile(int(profile["id"]))
        if owner is None or owner.get("revoked"):
            owner = _least_loaded(store)
            if owner is None:
                continue
            store.ensure_agent_assignment(int(owner["id"]), int(profile["id"]))
        for channel in channels:
            channel_id = channel.get("channel_id") or ""
            history = _channel_commands(store, profile["id"], channel_id, day_start)
            if any(h["status"] in OPEN for h in history):
                continue  # đang có việc nội dung → không giao chồng
            today = [h for h in history if (h.get("created_at") or "") >= day_start]
            if len(today) >= quota:
                continue
            last = max((_parse_iso(h.get("created_at")) for h in history if h.get("created_at")), default=None)
            if last is not None and now - last < gap:
                continue
            agent = owner
            if _load(store, agent["id"]) >= max_open:
                spare = _least_loaded(store, exclude={int(owner["id"])})
                if spare is None or _load(store, spare["id"]) >= max_open:
                    continue  # mọi người đều đang đủ việc — để lượt sau
                agent = spare
                store.ensure_agent_assignment(int(agent["id"]), int(profile["id"]))
            slot = len(today) + 1
            ctype, title = TASK_LABEL.get(platform, TASK_LABEL["youtube"])
            own = _recent_titles(store, profile["id"], channel_id)
            siblings = []
            for other in channels:
                if other.get("channel_id") != channel_id:
                    siblings += _recent_titles(store, profile["id"], other.get("channel_id"), 3)
            instruction = build_instruction(channel, profile, platform, own, siblings, slot, quota)
            row = store.create_command(
                ctype, source="lead", profile_id=profile["id"], profile_slug=profile.get("slug"),
                channel_id=channel_id, instruction=instruction, agent_id=int(agent["id"]),
                payload={"title": f"{title} · {channel.get('name') or channel_id}",
                         "plan": {"day": day, "slot": slot, "platform": platform, "by": "lead"}},
                idempotency_key=f"plan:{profile['id']}:{channel_id}:{day}:{slot}",
            )
            if row.get("deduplicated"):
                continue
            created.append(row)
            try:
                store.add_lead_decision(None, f"plan:{channel_id}:{day}", "plan", command_id=row["id"],
                                        agent_id=int(agent["id"]), outcome="done",
                                        detail=f"Giao {title.lower()} cho {agent.get('name')} — "
                                               f"{channel.get('name') or channel_id} (lượt {slot}/{quota} hôm nay).")
            except Exception:
                pass
    return created


def run(store: Store, settings: dict | None, now: datetime | None = None, force: bool = False) -> list[dict]:
    """Tự tiết lưu PLAN_EVERY_MIN phút; chỉ chạy trong giờ làm việc."""
    from . import office_feed

    now = now or datetime.now().astimezone()
    if not cfg(settings)["lead_autoplan"]:
        return []
    if not force:
        if office_feed.work_mode(settings or {}) == "off":
            return []
        last = _parse_iso(store.get_meta(THROTTLE_KEY) or "")
        if last and now - last < timedelta(minutes=PLAN_EVERY_MIN):
            return []
    store.set_meta(THROTTLE_KEY, now.isoformat(timespec="seconds"))
    return plan(store, settings, now)
