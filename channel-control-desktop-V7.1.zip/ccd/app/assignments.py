"""Mô hình giao việc theo kênh (V5.0) — mẫu việc, checklist thường
trực theo kênh và đường tạo lệnh hàng loạt cho bảng Theo Agent.

Dữ liệu người dùng sở hữu nằm ở FILE trong thư mục dữ liệu (cùng triết
lý với thư viện skill ``<data>/skills/*.md``), KHÔNG vào DB — vì vậy
bản này không cần migration (schema giữ nguyên 8):

- ``<data>/task_templates.json`` — danh sách mẫu việc dùng chung:
  ``[{id, title, type, instruction}]``. ``type`` là một loại lệnh hợp
  lệ của store; ``instruction`` là mẫu nội dung gửi cho Muse, hỗ trợ
  biến ``{channel}`` (thay bằng tên kênh khi giao). Chưa có file →
  dùng :data:`DEFAULT_TEMPLATES`; người dùng sửa/thêm/xoá mẫu trong
  hộp thoại Giao việc thì file được ghi ra.
- ``<data>/channel_checklists.json`` — checklist THƯỜNG TRỰC theo
  kênh: ``{"<channel_row_id>": {"template_ids": [...],
  "skill_slug": str | null}}``. Đây là bộ việc "Muse phải làm cho
  kênh này" — mở xem/sửa bất cứ lúc nào, bấm một nút là tạo đủ lệnh.
  Bản V5.0 KHÔNG tự phát sinh lệnh theo lịch từ checklist này (cơ chế
  Tự động hiện có chưa nối sạch được — để dành bản sau); trường
  ``auto`` không tồn tại trong file để khỏi gây hiểu nhầm.

Skill đính kèm (thư viện :mod:`app.skills_lib`): khi giao việc có chọn
skill, nội dung skill (đã render biến {profile}/{channel}/{topic})
được NỐI VÀO instruction của MỌI lệnh trong lượt giao, và payload mỗi
lệnh ghi ``assignment.skill_slug/skill_name`` để chi tiết lệnh tra
được. Chuẩn payload của lượt giao::

    {"assignment": {"source": "agent_board",
                    "template_id": ..., "template_title": ...,
                    "skill_slug": ... | None,
                    "skill_name": ... | None,
                    "note": "..."},
     "batch_id": ..., "batch_index": i, "batch_total": n}  # khi >1

Module thuần (chỉ thư viện chuẩn), mọi hàm nhận ``base`` là thư mục
dữ liệu (None → ``config.data_dir()``) như skills_lib.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from . import config, skills_lib

TEMPLATES_FILE = "task_templates.json"
CHECKLISTS_FILE = "channel_checklists.json"

# Bộ mẫu mặc định theo đúng danh sách người dùng duyệt (V5.0).
DEFAULT_TEMPLATES: list[dict] = [
    {
        "id": "tao-video-moi",
        "title": "Tạo video mới",
        "type": "create_video",
        "instruction": (
            "Tạo một video mới cho kênh {channel} theo đúng phong cách, "
            "định dạng và quy trình của kênh. Xong việc báo cáo: tiêu đề, "
            "độ dài và đường dẫn file video."
        ),
    },
    {
        "id": "toi-uu-tieu-de-mo-ta-tags",
        "title": "Tối ưu tiêu đề + mô tả + tags",
        "type": "optimize",
        "instruction": (
            "Tối ưu SEO cho các video gần nhất của kênh {channel} theo "
            "thứ tự bắt buộc: TIÊU ĐỀ trước, rồi mô tả, tags, kiểm tra "
            "thumbnail. Ghi lại cũ → mới cho từng mục đã đổi."
        ),
    },
    {
        "id": "kiem-tra-tinh-trang-kenh",
        "title": "Kiểm tra tình trạng kênh",
        "type": "check",
        "instruction": (
            "Kiểm tra tình trạng kênh {channel}: số video, lịch đăng sắp "
            "tới, video nào lỗi hoặc thiếu tối ưu. Báo cáo ngắn gọn."
        ),
    },
    {
        "id": "len-lich-phat-hanh",
        "title": "Lên lịch phát hành",
        "type": "upload",
        "instruction": (
            "Lên lịch phát hành video tiếp theo của kênh {channel} vào "
            "khung giờ tốt nhất của kênh. Kiểm chứng lại lịch trong "
            "Studio trước khi báo xong."
        ),
    },
    {
        "id": "ghim-binh-luan",
        "title": "Ghim bình luận sau khi đăng",
        "type": "free",
        "instruction": (
            "Khi video mới nhất của kênh {channel} đã đăng công khai, "
            "đăng bình luận mở đầu đúng giọng kênh và ghim lên đầu."
        ),
    },
    {
        "id": "tra-loi-binh-luan",
        "title": "Trả lời bình luận mới",
        "type": "free",
        "instruction": (
            "Đọc và trả lời các bình luận mới trên kênh {channel} theo "
            "đúng giọng của kênh. Bình luận nhạy cảm thì KHÔNG trả lời, "
            "để lại và liệt kê trong báo cáo."
        ),
    },
]


def _data_dir(base: Path | None) -> Path:
    return Path(base) if base is not None else config.data_dir()


def templates_path(base: Path | None = None) -> Path:
    return _data_dir(base) / TEMPLATES_FILE


def checklists_path(base: Path | None = None) -> Path:
    return _data_dir(base) / CHECKLISTS_FILE


def _read_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError):
        return None


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


# --------------------------------------------------------------------------- #
# Mẫu việc
# --------------------------------------------------------------------------- #
def load_templates(base: Path | None = None) -> list[dict]:
    """Danh sách mẫu việc: file người dùng (nếu có và hợp lệ) hoặc bộ
    mặc định. Mục lỗi cấu trúc bị bỏ qua thay vì làm sập cả danh sách."""
    raw = _read_json(templates_path(base))
    if isinstance(raw, list):
        templates = []
        for entry in raw:
            if not isinstance(entry, dict):
                continue
            title = str(entry.get("title") or "").strip()
            template_id = str(entry.get("id") or "").strip()
            if not title or not template_id:
                continue
            templates.append(
                {
                    "id": template_id,
                    "title": title,
                    "type": str(entry.get("type") or "free"),
                    "instruction": str(entry.get("instruction") or ""),
                }
            )
        if templates:
            return templates
    return [dict(t) for t in DEFAULT_TEMPLATES]


def save_templates(templates: list[dict], base: Path | None = None) -> None:
    clean = [
        {
            "id": str(t.get("id") or ""),
            "title": str(t.get("title") or ""),
            "type": str(t.get("type") or "free"),
            "instruction": str(t.get("instruction") or ""),
        }
        for t in templates
        if str(t.get("id") or "").strip() and str(t.get("title") or "").strip()
    ]
    _write_json(templates_path(base), clean)


def new_template_id(title: str, existing: list[dict]) -> str:
    slug = config.slugify(title or "") or "viec-mau"
    taken = {t["id"] for t in existing}
    candidate, n = slug, 2
    while candidate in taken:
        candidate = f"{slug}-{n}"
        n += 1
    return candidate


# --------------------------------------------------------------------------- #
# Checklist thường trực theo kênh
# --------------------------------------------------------------------------- #
def load_checklists(base: Path | None = None) -> dict:
    """Toàn bộ checklist thường trực: ``{channel_key: {...}}``."""
    raw = _read_json(checklists_path(base))
    if isinstance(raw, dict):
        return raw
    return {}


def load_checklist(channel_key, base: Path | None = None) -> dict | None:
    """Checklist của MỘT kênh (khoá = id dòng kênh trong DB, dạng str)
    hoặc None nếu kênh chưa có checklist thường trực."""
    entry = load_checklists(base).get(str(channel_key))
    if not isinstance(entry, dict):
        return None
    return {
        "template_ids": [str(t) for t in entry.get("template_ids") or []],
        "skill_slug": entry.get("skill_slug") or None,
    }


def save_checklist(
    channel_key,
    template_ids: list[str],
    skill_slug: str | None,
    base: Path | None = None,
) -> dict:
    """Lưu (ghi đè) checklist thường trực của một kênh; rỗng cả hai
    phần → xoá mục của kênh khỏi file. Trả bản đã chuẩn hoá."""
    checklists = load_checklists(base)
    key = str(channel_key)
    entry = {
        "template_ids": [str(t) for t in template_ids or []],
        "skill_slug": skill_slug or None,
    }
    if entry["template_ids"] or entry["skill_slug"]:
        checklists[key] = entry
    else:
        checklists.pop(key, None)
    _write_json(checklists_path(base), checklists)
    return entry


# --------------------------------------------------------------------------- #
# Dựng instruction + tạo lệnh
# --------------------------------------------------------------------------- #
def build_instruction(
    template: dict,
    *,
    channel_name: str = "",
    profile_label: str = "",
    note: str = "",
    skill: skills_lib.Skill | None = None,
) -> str:
    """Instruction cuối cho một lệnh: thân mẫu (đã thay {channel}) +
    ghi chú của người dùng (nếu có) + khối skill đính kèm (nếu có)."""
    body = str(template.get("instruction") or "").strip()
    body = body.replace("{channel}", channel_name or "")
    parts = [body] if body else []
    note = (note or "").strip()
    if note:
        parts.append(f"Ghi chú của người dùng: {note}")
    if skill is not None:
        rendered = skills_lib.render_body(
            skill.body,
            profile=profile_label or "",
            channel=channel_name or "",
            topic="",
        ).strip()
        parts.append(
            f"--- Skill đính kèm: {skill.name} ---\n{rendered}"
            if rendered
            else f"--- Skill đính kèm: {skill.name} ---"
        )
    return "\n\n".join(parts).strip()


# Các loại lệnh do APP tự chạy (store.LOCAL_COMMAND_TYPES) — không gắn
# agent; còn lại là lệnh chờ Muse → gắn đúng agent phụ trách.
LOCAL_TYPES = ("open_browser", "scan", "check")


def create_assignments(
    store,
    *,
    agent: dict,
    profile: dict,
    channel: dict,
    templates: list[dict],
    skill: skills_lib.Skill | None = None,
    note: str = "",
) -> list[dict]:
    """Tạo ĐÚNG một lệnh cho mỗi mẫu đã tick, gắn đúng agent (trừ loại
    app tự chạy), đúng hồ sơ + kênh; cả lượt dùng chung một batch_id
    khi có từ 2 lệnh. Trả danh sách lệnh đã tạo (dict của store)."""
    templates = list(templates or [])
    batch_id = uuid.uuid4().hex[:12] if len(templates) > 1 else None
    channel_name = channel.get("name") or channel.get("handle") or ""
    created: list[dict] = []
    for index, template in enumerate(templates):
        payload: dict = {
            "assignment": {
                "source": "agent_board",
                "template_id": template.get("id"),
                "template_title": template.get("title"),
                "skill_slug": skill.slug if skill else None,
                "skill_name": skill.name if skill else None,
                "note": (note or "").strip(),
            }
        }
        if batch_id is not None:
            payload["batch_id"] = batch_id
            payload["batch_index"] = index + 1
            payload["batch_total"] = len(templates)
        command_type = str(template.get("type") or "free")
        created.append(
            store.create_command(
                command_type,
                source="ui",
                profile_id=profile.get("id"),
                profile_slug=profile.get("slug"),
                channel_id=channel.get("channel_id") or "",
                instruction=build_instruction(
                    template,
                    channel_name=channel_name,
                    profile_label=profile.get("label") or "",
                    note=note,
                    skill=skill,
                ),
                payload=payload,
                agent_id=(
                    agent.get("id") if command_type not in LOCAL_TYPES else None
                ),
            )
        )
    return created
