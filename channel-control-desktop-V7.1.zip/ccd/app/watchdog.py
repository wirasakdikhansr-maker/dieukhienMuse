"""Watchdog (V4.0 — H4.3): tiến trình cha giám sát app, sập thì mở lại.

Chạy qua cờ ``--watchdog`` ở run.py / run_exe.py: cha KHÔNG chạy app
trực tiếp mà spawn con (cùng điểm vào, bỏ cờ --watchdog); con thoát
bất thường (exit code ≠ 0 hoặc bị kill) → cha mở lại sau
``restart_delay`` giây, tối đa ``max_restarts`` lần trong cửa sổ một
giờ — vượt trần thì dừng hẳn và ghi log, tránh vòng lặp sập–mở vô hạn.

Thoát sạch (exit code 0) = người dùng chủ động tắt → không mở lại.
Chính sách đếm nằm ở ``RestartPolicy`` (thuần, có test); vòng giám sát
nhận hàm spawn/now/sleep tiêm vào để kiểm thử không cần tiến trình
thật.
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

MAX_RESTARTS_PER_HOUR = 5
WINDOW_SECONDS = 3600
RESTART_DELAY_S = 5


class RestartPolicy:
    """Đếm số lần mở lại trong cửa sổ trượt: còn ngân sách không?"""

    def __init__(
        self,
        max_restarts: int = MAX_RESTARTS_PER_HOUR,
        window_seconds: int = WINDOW_SECONDS,
    ):
        self.max_restarts = max(1, int(max_restarts))
        self.window_seconds = max(1, int(window_seconds))
        self._stamps: list[float] = []

    def allow_restart(self, now: float) -> bool:
        """Ghi nhận một lần mở lại tại ``now``; True nếu còn trong trần."""
        horizon = now - self.window_seconds
        self._stamps = [t for t in self._stamps if t > horizon]
        if len(self._stamps) >= self.max_restarts:
            return False
        self._stamps.append(now)
        return True

    @property
    def restarts_in_window(self) -> int:
        return len(self._stamps)


def run_watchdog(
    spawn,
    policy: RestartPolicy | None = None,
    log=None,
    sleep_fn=time.sleep,
    now_fn=time.time,
    restart_delay: float = RESTART_DELAY_S,
) -> int:
    """Vòng giám sát. ``spawn()`` chạy con và trả exit code.
    Trả: 0 khi con thoát sạch; exit code cuối khi vượt trần mở lại."""
    policy = policy or RestartPolicy()
    say = log or (lambda _msg: None)
    while True:
        code = spawn()
        if code == 0:
            say("[Watchdog] App thoát sạch — không mở lại.")
            return 0
        now = now_fn()
        if not policy.allow_restart(now):
            say(
                f"[Watchdog] App thoát bất thường (code={code}) và đã "
                f"hết ngân sách mở lại ({policy.max_restarts} lần/giờ) — "
                "dừng giám sát. Xem data/logs/watchdog.log."
            )
            return code
        say(
            f"[Watchdog] App thoát bất thường (code={code}) — mở lại "
            f"sau {restart_delay}s (lần {policy.restarts_in_window}/"
            f"{policy.max_restarts} trong giờ)."
        )
        sleep_fn(restart_delay)


def watchdog_main(
    args: list[str], entry_argv: list[str], log_path: Path | None = None
) -> int:
    """Điểm vào thật của chế độ --watchdog (run.py/run_exe.py gọi):
    spawn chính điểm vào đó (``entry_argv`` = [exe] hoặc
    [python, run.py]; ``args`` = các cờ, bỏ --watchdog) làm con."""
    from .instance_guard import split_child_argv

    child_argv = [*entry_argv, *split_child_argv(args)]

    def _log(message: str) -> None:
        print(message, file=sys.stderr)
        if log_path is not None:
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                with log_path.open("a", encoding="utf-8") as handle:
                    handle.write(message + "\n")
            except OSError:
                pass

    def _spawn() -> int:
        return subprocess.call(child_argv)

    return run_watchdog(_spawn, log=_log)
