"""V6.1 — SỰ CỐ CẦN XỬ LÝ cho tab Văn phòng (hàm thuần trên Store).

Trước V6.1, Văn phòng chỉ có bong bóng "Chờ người xử lý" + 0% mà không
nói lỗi gì, ở đâu, phải làm gì. Module này gom MỌI tình trạng cần người
can thiệp thành danh sách sự cố cụ thể:

    {key, severity, kind, title, detail, fix, actions: [(action, label)],
     command_id, agent_id, profile_id}

- severity: 'critical' (đỏ — việc đang đứng), 'warning' (vàng — sắp
  hỏng/chậm), 'info' (xám — nên làm).
- fix: CÁCH XỬ LÝ cụ thể bằng tiếng Việt, suy từ lý do thật (đăng nhập,
  2FA/OTP, CAPTCHA, thiếu file, hết quota…).
- actions: mã thao tác mà OfficeView/MainWindow biết thực thi.

Không Qt — test độc lập được.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from .store import CLAUDE_COMMAND_TYPES, COMMAND_TYPE_LABELS, Store, _parse_iso

SEVERITY_ORDER = {"critical": 0, "warning": 1, "info": 2}

# (từ khoá trong lý do, cách xử lý, thao tác chính)
_FIX_RULES: tuple[tuple[tuple[str, ...], str, str], ...] = (
    (("captcha", "robot", "recaptcha"),
     "Mở trình duyệt của hồ sơ, tự giải CAPTCHA trong khung nhúng, rồi bấm “Chạy tiếp”.",
     "open_profile"),
    (("2fa", "otp", "mã xác minh", "xác minh", "verify", "2-step", "hai bước", "điện thoại"),
     "Mở trình duyệt của hồ sơ, nhập mã xác minh (OTP/2 bước) trên điện thoại của bạn, rồi bấm “Chạy tiếp”.",
     "open_profile"),
    (("đăng nhập", "login", "sign in", "signin", "phiên", "session", "cookie", "hết hạn"),
     "Mở trình duyệt của hồ sơ và đăng nhập lại Google/YouTube (hoặc 🍪 nạp cookies mới), rồi bấm “Chạy tiếp”.",
     "open_profile"),
    (("file", "tệp", "inbox", "video_id", "không thấy video", "thiếu video"),
     "Gửi đúng file video vào lệnh (Muse gửi qua /api/inbox kèm X-Command-Id) hoặc sửa video_id, rồi “Thử lại”.",
     "chat"),
    (("quota", "giới hạn", "limit", "rate", "429", "too many"),
     "YouTube đang giới hạn tài khoản — đợi 30–60 phút rồi “Thử lại”, hoặc giãn lịch đăng của kênh.",
     "retry"),
    (("mạng", "network", "timeout", "kết nối", "connection", "econn", "dns"),
     "Lỗi mạng tạm thời — kiểm tra Internet/Tailscale của PC rồi “Thử lại”.",
     "retry"),
    (("bản quyền", "copyright", "vi phạm", "policy", "chính sách"),
     "Nội dung vướng chính sách/bản quyền — nhắn Muse làm lại phần nội dung bị báo, không đăng lại nguyên bản.",
     "chat"),
    (("cdp", "chrome", "trình duyệt", "websocket", "debug"),
     "Trình duyệt của hồ sơ không phản hồi — mở lại trình duyệt hồ sơ (Hồ sơ → Mở trình duyệt) rồi “Thử lại”.",
     "open_profile"),
)


def suggest_fix(reason: str, default: str) -> tuple[str, str | None]:
    """(cách xử lý, thao tác gợi ý) suy từ lý do lỗi/kẹt."""
    text = (reason or "").lower()
    for keywords, fix, action in _FIX_RULES:
        if any(word in text for word in keywords):
            return fix, action
    return default, None


def _short(text, limit: int = 160) -> str:
    text = " ".join(str(text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _cmd_title(command: dict, profiles: dict) -> str:
    label = COMMAND_TYPE_LABELS.get(command.get("type"), command.get("type") or "")
    profile = profiles.get(command.get("profile_id")) or {}
    where = profile.get("label") or command.get("profile_slug") or "—"
    return f"{label} · {where}"


def _owner(command: dict, owner_by_profile: dict) -> int | None:
    agent_id = command.get("agent_id") or command.get("lease_agent_id")
    if agent_id is None and command.get("profile_id") is not None:
        agent_id = owner_by_profile.get(int(command["profile_id"]))
    return int(agent_id) if agent_id is not None else None


def _ago(seconds: float) -> str:
    minutes = int(seconds // 60)
    if minutes < 60:
        return f"{max(1, minutes)} phút"
    hours = minutes // 60
    if hours < 24:
        return f"{hours} giờ {minutes % 60} phút"
    return f"{hours // 24} ngày"


def collect_issues(
    store: Store, now: datetime | None = None, limit: int = 40,
    bridge_enabled: bool = True,
) -> list[dict]:
    """Danh sách sự cố hiện hành, nặng nhất trước."""
    now = now or datetime.now().astimezone()
    issues: list[dict] = []
    agents = store.list_agents()
    agents_by_id = {int(a["id"]): a for a in agents}
    profiles = {p["id"]: p for p in store.list_profiles()}
    owner_by_profile: dict[int, int] = {}
    for agent in agents:
        if agent.get("revoked"):
            continue
        for pid in agent.get("profile_ids") or []:
            owner_by_profile[int(pid)] = int(agent["id"])

    def agent_name(agent_id) -> str:
        agent = agents_by_id.get(int(agent_id)) if agent_id is not None else None
        if not agent:
            return "—"
        return agent.get("name") or agent.get("email") or f"Muse #{agent_id}"

    # 1) Cầu nối Muse
    try:
        bridge = store.bridge_state()
    except Exception:
        bridge = {}
    if bridge_enabled and agents and not bridge.get("connected"):
        never = not bridge.get("ever")
        issues.append({
            "key": "bridge",
            "severity": "critical",
            "kind": "bridge",
            "title": "Cầu nối Muse chưa kết nối" if never else "Cầu nối Muse đã mất kết nối",
            "detail": (
                "Chưa từng có Muse nào gọi vào app — mọi lệnh của Muse sẽ nằm ở “Chờ Muse”."
                if never else
                f"Lần cuối Muse gọi vào app cách đây {_ago(bridge.get('seconds_ago') or 0)}."
            ),
            "fix": "Kiểm tra Tailscale trên PC (cùng tài khoản với Muse), cho phép cổng 19500 qua Firewall, "
                   "và nạp đúng phiếu kết nối cho từng Muse.",
            "actions": [("connect_bridge", "🔌 Kết nối Muse…")],
            "command_id": None, "agent_id": None, "profile_id": None,
        })

    # 2) Tự động hoá lỗi
    try:
        from . import automation_health

        health = automation_health.read_health(store)
    except Exception:
        health = None
    if health and health.get("degraded"):
        issues.append({
            "key": "auto_health",
            "severity": "warning",
            "kind": "auto_error",
            "title": f"Vòng tự động đang lỗi ({health.get('source') or '?'})",
            "detail": _short(health.get("error")),
            "fix": "Xem Nhật ký để biết chi tiết; nếu lỗi lặp lại hãy khởi động lại cầu nối trong Cài đặt.",
            "actions": [("open_journal", "📓 Xem nhật ký")],
            "command_id": None, "agent_id": None, "profile_id": None,
        })

    open_commands = store.list_open_commands(limit=500)

    # 3) Lệnh chờ người xử lý — GỘP theo (hồ sơ, lý do): 5 lệnh cùng kẹt
    # "đăng nhập lại Studio" của một hồ sơ là MỘT việc phải làm.
    groups: dict[tuple, list[dict]] = {}
    for command in open_commands:
        if command.get("status") != "needs_user":
            continue
        reason = (command.get("result") or command.get("step") or command.get("error") or "").strip()
        groups.setdefault((command.get("profile_id"), _short(reason, 120)), []).append(command)
    for (profile_id, reason), members in groups.items():
        command = members[0]
        fix, primary = suggest_fix(
            reason,
            "Đọc tin của Muse trong khung chat, xử lý điều Muse cần, rồi bấm “Chạy tiếp”.",
        )
        owner = _owner(command, owner_by_profile)
        actions = []
        if primary == "open_profile" and profile_id:
            actions.append(("open_profile", "🌐 Mở trình duyệt hồ sơ"))
        actions.append(("resume", "▶ Chạy tiếp" + (f" ({len(members)})" if len(members) > 1 else "")))
        if owner:
            actions.append(("chat", "💬 Nhắn Muse"))
        title = (
            f"{len(members)} lệnh cần bạn xử lý · "
            f"{(profiles.get(profile_id) or {}).get('label') or command.get('profile_slug') or '—'}"
            if len(members) > 1 else f"Cần bạn xử lý: {_cmd_title(command, profiles)}"
        )
        issues.append({
            "key": f"needs:{profile_id}:{reason}",
            "severity": "critical",
            "kind": "needs_user",
            "title": title,
            "detail": f"Lý do: {reason or 'Muse chưa ghi lý do'} · Muse: {agent_name(owner)}",
            "fix": fix,
            "actions": actions,
            "command_id": command["id"],
            "command_ids": [m["id"] for m in members],
            "agent_id": owner,
            "profile_id": profile_id,
        })

    # 4) Lệnh thất bại 24h (chưa được thử lại)
    try:
        failed = store.list_recent_failed(hours=24, limit=30)
    except Exception:
        failed = []
    seen_failed_profiles: set = set()
    for command in failed:
        if command.get("type") == "review":
            continue
        # Gộp: mỗi hồ sơ + loại lệnh chỉ báo lỗi mới nhất.
        group = (command.get("profile_id"), command.get("type"))
        if group in seen_failed_profiles:
            continue
        seen_failed_profiles.add(group)
        reason = (command.get("error") or command.get("result") or "").strip()
        fix, primary = suggest_fix(
            reason, "Xem lý do, sửa điều kiện (đăng nhập/file/nội dung) rồi “Thử lại” — hoặc hỏi Muse."
        )
        owner = _owner(command, owner_by_profile)
        actions = [("retry", "↻ Thử lại")]
        if primary == "open_profile" and command.get("profile_id"):
            actions.insert(0, ("open_profile", "🌐 Mở trình duyệt hồ sơ"))
        if owner and command.get("type") in CLAUDE_COMMAND_TYPES:
            actions.append(("chat", "💬 Hỏi Muse"))
        actions.append(("open_command", "📋 Chi tiết"))
        issues.append({
            "key": f"failed:{command['id']}",
            "severity": "warning",
            "kind": "failed",
            "title": f"Thất bại: {_cmd_title(command, profiles)}",
            "detail": f"Lỗi: {_short(reason) or 'không có mô tả'}",
            "fix": fix,
            "actions": actions,
            "command_id": command["id"], "agent_id": owner,
            "profile_id": command.get("profile_id"),
        })

    # 5) Trễ hạn / chờ nhận quá lâu / Muse ngoại tuyến đang ôm việc
    from . import supervision

    offline_load: dict[int, int] = {}
    overdue_count: dict = {}
    for command in open_commands:
        if command.get("type") == "review":
            continue
        status = command.get("status")
        owner = _owner(command, owner_by_profile)
        health = supervision.deadline_health(command, now)
        if health["health"] == supervision.HEALTH_OVERDUE and status != "needs_user":
            overdue_count[owner] = overdue_count.get(owner, 0) + 1
            if overdue_count[owner] > 2:
                continue  # mỗi Muse hiện tối đa 2 việc trễ; còn lại gộp ở dòng tóm tắt
            issues.append({
                "key": f"overdue:{command['id']}",
                "severity": "warning",
                "kind": "overdue",
                "title": f"Trễ hạn: {_cmd_title(command, profiles)}",
                "detail": (
                    f"{supervision.format_left(health['seconds_left']).capitalize()} · tiến độ "
                    f"{health['progress']}% · Muse: {agent_name(owner)}"
                ),
                "fix": "Nhắc Muse báo tiến độ ngay; nếu việc lớn hơn dự kiến thì gia hạn, "
                       "nếu Muse không phản hồi thì thu hồi để giao người khác.",
                "actions": (
                    [("remind", "💬 Nhắc Muse")] if owner else []
                ) + [("extend", "⏱ +1 giờ"), ("open_command", "📋 Chi tiết")],
                "command_id": command["id"], "agent_id": owner,
                "profile_id": command.get("profile_id"),
            })
        if command.get("type") in CLAUDE_COMMAND_TYPES and status in ("queued", "waiting_muse"):
            if owner is None:
                if command.get("profile_id") is not None:
                    pid = int(command["profile_id"])
                    key = f"unassigned:{pid}"
                    if not any(i["key"] == key for i in issues):
                        issues.append({
                            "key": key,
                            "severity": "critical",
                            "kind": "unassigned",
                            "title": f"Hồ sơ “{(profiles.get(pid) or {}).get('label') or pid}” chưa có Muse phụ trách",
                            "detail": "Lệnh của hồ sơ này không có ai nhận nên sẽ nằm chờ mãi.",
                            "fix": "Vào Tài khoản Muse → 🎯 Phân công kênh… và giao hồ sơ cho một Muse.",
                            "actions": [("assign", "🎯 Phân công")],
                            "command_id": command["id"], "agent_id": None, "profile_id": pid,
                        })
                continue
            agent = agents_by_id.get(owner) or {}
            if agent.get("status") not in ("online", "idle"):
                offline_load[owner] = offline_load.get(owner, 0) + 1
                continue
            created = _parse_iso(command.get("updated_at")) or _parse_iso(command.get("created_at"))
            if status == "waiting_muse" and created and now - created > timedelta(minutes=10):
                issues.append({
                    "key": f"unclaimed:{command['id']}",
                    "severity": "info",
                    "kind": "unclaimed",
                    "title": f"Muse chưa nhận việc: {_cmd_title(command, profiles)}",
                    "detail": f"Đã chờ {_ago((now - created).total_seconds())} · Muse: {agent_name(owner)} (đang online).",
                    "fix": "Phiên của Muse có thể đang bận việc dài — nhắc Muse, hoặc đổi sang Muse khác ở mục Công việc.",
                    "actions": [("remind", "💬 Nhắc Muse"), ("open_command", "📋 Chi tiết")],
                    "command_id": command["id"], "agent_id": owner,
                    "profile_id": command.get("profile_id"),
                })
    for owner, count in overdue_count.items():
        if count > 2:
            issues.append({
                "key": f"overdue_more:{owner}",
                "severity": "warning",
                "kind": "overdue",
                "title": f"{agent_name(owner) if owner else 'App tự chạy'}: còn {count - 2} việc trễ hạn khác",
                "detail": f"Tổng {count} việc của {agent_name(owner) if owner else 'app'} đã quá hạn.",
                "fix": "Mở tab Giám sát → lọc “Trễ hạn” để gia hạn/thu hồi hàng loạt.",
                "actions": [("open_supervision", "🔍 Mở Giám sát")],
                "command_id": None, "agent_id": owner, "profile_id": None,
            })
    for agent_id, count in offline_load.items():
        agent = agents_by_id.get(agent_id) or {}
        never = not agent.get("last_seen_at")
        issues.append({
            "key": f"offline:{agent_id}",
            "severity": "critical",
            "kind": "agent_offline",
            "title": f"{agent_name(agent_id)} {'chưa kết nối' if never else 'đang ngoại tuyến'} — {count} việc đang chờ",
            "detail": (
                "Muse này chưa từng gọi vào app bằng phiếu kết nối của nó."
                if never else "Không nhận được nhịp tim của Muse này quá 15 phút."
            ),
            "fix": "Bấm 🔌 Kết nối để xem lý do + xuất phiếu kết nối; hoặc đổi các việc sang Muse đang online.",
            "actions": [("agent_connect", "🔌 Kết nối"), ("chat", "💬 Nhắn Muse")],
            "command_id": None, "agent_id": agent_id, "profile_id": None,
        })

    issues.sort(key=lambda i: (SEVERITY_ORDER.get(i["severity"], 9), i["kind"], i["title"]))
    return issues[:limit]


def issues_by_agent(issues: list[dict]) -> dict[int, dict]:
    """{agent_id: {count, worst, top}} — huy hiệu ⚠ trên bàn + panel."""
    result: dict[int, dict] = {}
    for issue in issues:
        agent_id = issue.get("agent_id")
        if agent_id is None:
            continue
        entry = result.setdefault(int(agent_id), {"count": 0, "worst": "info", "top": issue})
        entry["count"] += 1
        if SEVERITY_ORDER[issue["severity"]] < SEVERITY_ORDER[entry["worst"]]:
            entry["worst"] = issue["severity"]
            entry["top"] = issue
    return result
