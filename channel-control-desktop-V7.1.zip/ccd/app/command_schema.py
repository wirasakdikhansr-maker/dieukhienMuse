"""Kiểm tra payload theo loại lệnh (V4.0 — H5).

Một bảng khai báo DUY NHẤT dùng chung cho mọi nơi tạo lệnh chờ Muse:
form trong app (báo lỗi ngay khi bấm Tạo lệnh) và Agent API
(``_handle_enqueue`` trả 400 kèm danh sách lỗi cụ thể). Mục đích: lỗi
cấu hình bị chặn Ở CỬA — không đợi Muse nhận lệnh, chạy dở rồi mới
vỡ (vd lệnh upload không có file nào để tải).

Nguyên tắc khoan dung: trường lạ trong payload KHÔNG bị cấm (payload
là túi dữ liệu mở cho Muse); chỉ kiểm tra trường BẮT BUỘC + kiểu của
trường đã biết. Loại lệnh local (open_browser/scan/check) gần như
không có payload bắt buộc trừ cdp_navigate (cần url — worker đã kiểm
tra riêng, ở đây khai luôn cho đủ).
"""

from __future__ import annotations

import re

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

# Khai báo theo loại lệnh:
# - required_payload: các khoá payload bắt buộc khác rỗng.
# - any_of_payload: ít nhất MỘT trong các khoá phải khác rỗng.
# - payload_types: kiểu mong đợi của khoá khi có mặt.
# - require_instruction: instruction (cột riêng của lệnh) phải khác rỗng.
# - require_channel: channel_id phải có VÀ thuộc hồ sơ (nơi gọi truyền
#   danh sách channel_id hiện có của hồ sơ để đối chiếu).
COMMAND_SCHEMAS: dict[str, dict] = {
    "upload": {
        "any_of_payload": ("file", "video_id"),
        "payload_types": {"file": str, "video_id": str, "title": str},
        "require_channel": True,
    },
    "optimize": {
        "payload_types": {"title": str},
        "require_channel": True,
    },
    "create_video": {
        "require_instruction": True,
        "payload_types": {"topic": str},
    },
    "create_channel": {
        "payload_types": {"gmail": str, "channel_name": str},
        "payload_formats": {"gmail": "email"},
    },
    "free": {
        "require_instruction": True,
    },
    # V6.0: việc KIỂM TRA giám sát chéo do app tự sinh (payload mang
    # review_id + gói bằng chứng) — không trường bắt buộc ở tầng này;
    # tính hợp lệ của gói do app.supervision bảo đảm lúc sinh.
    "review": {},
    "cdp_navigate": {
        "required_payload": ("url",),
        "payload_types": {"url": str},
    },
    # V4.3: hành động CDP trong trang nhúng — worker agent_server thi
    # hành bằng primitive sẵn có và chụp ảnh xác nhận sau mỗi hành động.
    "cdp_evaluate": {
        "required_payload": ("expression",),
        "payload_types": {"expression": str},
    },
    "cdp_click": {
        # Bấm theo CSS selector, chữ nhìn thấy, aria-label (label) hoặc
        # số thứ tự phần tử trong snapshot (element) — V6.3.
        "any_of_payload": ("selector", "text", "label", "element"),
        "payload_types": {"selector": str, "text": str, "label": str},
    },
    # V6.3: đọc trang dạng chữ (URL, chữ, danh sách phần tử tương tác).
    "cdp_snapshot": {},
    "cdp_type": {
        "required_payload": ("text",),
        "payload_types": {"text": str, "selector": str},
    },
    # V4.4: kịch bản Studio trong Chrome nhúng — kiểm tra sâu từng
    # bước do studio_script.validate_steps đảm nhiệm (xem dưới).
    "studio_script": {
        "required_payload": ("steps",),
        "payload_types": {"steps": list},
    },
}


def _blank(value) -> bool:
    return value is None or (isinstance(value, str) and not value.strip())


def validate_command(
    command_type: str,
    channel_id: str = "",
    instruction: str = "",
    payload: dict | None = None,
    channel_ids: list[str] | None = None,
    skip_any_of: bool = False,
) -> list[str]:
    """Trả danh sách lỗi (rỗng = hợp lệ). ``channel_ids``: khi nơi gọi
    biết kênh của hồ sơ đích thì truyền vào để kiểm tra channel_id
    thuộc hồ sơ thật; None = chỉ kiểm tra có/không.
    ``skip_any_of=True``: bỏ qua nhóm "ít nhất một trong…" — form UI
    tạo lệnh upload khi file còn trên đường tới (dispatcher có cổng
    chờ-file riêng); API giữ kiểm tra chặt mặc định."""
    schema = COMMAND_SCHEMAS.get(command_type)
    if schema is None:
        return []
    payload = payload or {}
    errors: list[str] = []

    for key in schema.get("required_payload", ()):  # noqa: B007 — giữ thứ tự khai báo
        if _blank(payload.get(key)):
            errors.append(f"payload.{key}: bắt buộc cho lệnh '{command_type}'")

    any_of = schema.get("any_of_payload", ())
    if any_of and not skip_any_of and all(_blank(payload.get(key)) for key in any_of):
        errors.append(
            "payload: cần ít nhất một trong "
            + " / ".join(f"'{key}'" for key in any_of)
            + f" cho lệnh '{command_type}'"
        )

    for key, expected in schema.get("payload_types", {}).items():
        value = payload.get(key)
        if value is not None and not isinstance(value, expected):
            errors.append(
                f"payload.{key}: phải là {expected.__name__}, "
                f"đang là {type(value).__name__}"
            )

    for key, fmt in schema.get("payload_formats", {}).items():
        value = payload.get(key)
        if _blank(value):
            continue
        if fmt == "email" and not _EMAIL_RE.match(str(value).strip()):
            errors.append(f"payload.{key}: không đúng định dạng email")

    if schema.get("require_instruction") and _blank(instruction):
        errors.append(
            f"instruction: bắt buộc khác rỗng cho lệnh '{command_type}'"
        )

    if command_type == "studio_script" and isinstance(payload.get("steps"), list):
        # V4.4: kiểm tra TỪNG BƯỚC của kịch bản (action hợp lệ, trường
        # bắt buộc theo từng loại bước, tên file upload phải là tên
        # thuần…) — chặn kịch bản hỏng ngay ở cửa tạo lệnh.
        from . import studio_script as _studio_script

        errors.extend(_studio_script.validate_steps(payload["steps"]))

    if command_type == "create_channel":
        # Gmail đích: hoặc khai payload.gmail (kiểm tra định dạng ở
        # payload_formats), hoặc chính hồ sơ đích là gmail đó và
        # instruction mô tả yêu cầu (đường UI "Tạo kênh đầu tiên cho
        # mail này" đi theo cách này — payload trống, instruction đầy đủ).
        if _blank(payload.get("gmail")) and _blank(instruction):
            errors.append(
                "payload.gmail: bắt buộc cho lệnh 'create_channel' "
                "(hoặc ghi yêu cầu trong instruction)"
            )

    if schema.get("require_channel"):
        if _blank(channel_id):
            errors.append(
                f"channel_id: bắt buộc cho lệnh '{command_type}' "
                "(chọn kênh thuộc hồ sơ đích)"
            )
        elif channel_ids is not None and channel_id not in channel_ids:
            errors.append(
                f"channel_id '{channel_id}': không thuộc hồ sơ đích"
            )

    return errors
