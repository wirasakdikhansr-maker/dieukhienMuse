"""Channel Control Desktop — trung tâm điều khiển kênh YouTube đa tài khoản.

Mỗi tài khoản Google = một hồ sơ (profile) có thư mục Chrome user-data riêng
và một cổng remote-debugging riêng, suy ra tất định từ slug của hồ sơ.
"""

# V4.0: PHIÊN BẢN DUY NHẤT của app nằm tại đây — giao diện đọc từ
# hằng số này, hết cảnh nhiều trục phiên bản lệch nhau (trước V4.0:
# __version__ kẹt 0.1.0 trong khi UI ghi V3.9.2). V4.1: bản giao diện
# Văn phòng diorama — hiển thị "V4.1". V4.1.1: hotfix tự phân công
# theo email + Chạy ngay tức thì — hiển thị "V4.1.1". V4.2: bản tối
# ưu theo kiểm toán (điều phối sự kiện toàn đường, dọn vòng đời cờ,
# sức khoẻ vòng tự động, Văn phòng/panel kỷ luật làm mới) — hiển
# thị "V4.2". V4.3: bảng việc theo từng Muse (3 dạng xem) + gộp
# điều hướng 11 → 7 mục, Văn phòng co giãn 100+ agent, thư viện
# Skill cho tạo lệnh, cài đặt Giao diện (theme tokens), zoom trình
# duyệt nhúng 75% + canh đăng nhập, sức khoẻ kết nối trong app, và
# lệnh hành động CDP (cdp_evaluate/cdp_click/cdp_type) cho Agent
# API — hiển thị "V4.3". V4.3.1: THỐNG NHẤT toàn bộ giao diện theo
# phong cách Concept D (tab điều hướng lớn icon-trên/nhãn-dưới, thẻ
# bo lớn, pill trạng thái + pill %, chip màu trong bảng — qua theme
# tokens của preset Mission Control) + mục Công việc chia HAI CỘT
# (bảng việc trái / khối lệnh phải, splitter nhớ tỉ lệ, hẹp thì xếp
# dọc) — hiển thị "V4.3.1". V4.3.2: vòng sửa lỗi nghiệm thu máy
# thật — hiển thị "V4.3.2". V4.4: ĐIỀU KHIỂN STUDIO QUA TRÌNH DUYỆT
# NHÚNG — CDP client có chờ sự kiện/chờ phần tử/bấm/điền/phím/đọc/
# nạp file; loại lệnh mới studio_script (payload steps) chạy kịch
# bản nhiều bước trong Chrome nhúng của đúng hồ sơ ở cả executor UI
# lẫn Agent API; file giao kèm lệnh qua /api/inbox + X-Command-Id
# (data/command_files/<id>/, giới hạn 2 GiB, dọn theo vòng đời
# lệnh); Agent API 2.4 → 2.5, schema DB giữ 7 — hiển thị "V4.4".
__version__ = "7.1.0"
# V4.6: CHAT TRỰC TIẾP VỚI TỪNG CLAUDE NGAY TRONG APP — mục Tài
# khoản Muse thành hai cột (danh sách/quản lý | khung chat theo
# agent đang chọn, huy hiệu tin chưa đọc); "💬 Hỏi về lệnh này" ở
# bảng lệnh + hàng đợi rút gọn và "💬 Nhắn tin" ở panel chi tiết
# Văn phòng mở chat gắn ngữ cảnh lệnh; lệnh kẹt needs_user tự để
# lại tin hệ thống trong luồng của Muse phụ trách để người dùng
# trả lời tại đó. Agent API 2.5 → 2.6 (GET/POST
# /api/agents/{id}/messages + /read, long-poll tin chưa đọc, phạm
# vi chặt theo từng agent); schema DB 7 → 8 (bảng agent_messages).
# Hiển thị "V4.6".
# V4.5: ĐỒNG BỘ THIẾT KẾ "MetaMint" (một màu nhấn xanh lá #3ECF6A
# trên nền gần-đen trung tính, một kiểu panel/pill/thanh tiến độ
# cho cả 7 mục; preset mặc định mới 'metamint', di trú an toàn từ
# CẢ HAI bộ gốc Mission-cyan V4.3 và Concept D V4.3.1 — ai đã tuỳ
# biến thì giữ nguyên). TƯỜNG TRÌNH DUYỆT NHÚNG ở mục Hồ sơ:
# nhiều Chrome hồ sơ đang chạy tự xếp LƯỚI trong app (2/2×2/3×2/
# 3×3/4 cột), tự ẩn panel dữ liệu khi ≥3 trình duyệt, nút ⛶ về
# khung đơn; TỰ MỞ TRÌNH DUYỆT KHI CÓ VIỆC (lệnh running mà
# Chrome của hồ sơ chưa chạy → app tự mở, chặn dội 45s/hồ sơ).
# Tab Tài khoản Muse dời cạnh Hệ thống (Văn phòng · Hồ sơ ·
# Công việc · Báo cáo · Tự động · Tài khoản Muse · Hệ thống).
# CÔNG VIỆC THIẾT KẾ LẠI: cột trái "Giao việc" (form một cột dọc
# + Hàng đợi lệnh rút gọn), cột phải "Ai đang làm gì" (dải pill
# tổng quan + bảng việc 3 dạng xem + bảng lệnh trong splitter
# dọc); splitter dùng khoá settings MỚI work_split_h2/v2 (đảo
# cột so với V4.3.1). KÊNH LIÊN QUAN = CHECKBOX NHIỀU KÊNH: tick
# N kênh → tạo một LÔ N lệnh (mỗi kênh một lệnh đúng hồ sơ của
# nó, chung batch_id trong payload — KHÔNG đổi schema); hàng
# đợi + bảng việc hiển thị lô gộp x/N. LỆNH THẤT BẠI TỰ CHẠY LẠI
# sau 30 giây, tối đa 3 lần (app/auto_retry.py): đếm ngược + số
# lần lưu trong payload JSON (sống sót qua khởi động lại, KHÔNG
# đổi schema), chặn khi needs_user / đã huỷ / phụ thuộc lỗi /
# payload không hợp lệ; nút Huỷ chạy lại ở dòng lệnh. API giữ
# 2.5, schema DB giữ 7 — hiển thị "V4.5".
# V5.0: BẢN GỘP — toàn bộ V4.6 (chat tại Văn phòng + Tài khoản,
# tin hệ thống needs_user, sửa lỗi click mất hình Văn phòng, trình
# duyệt nhúng đầy kích thước, nút Kết nối từng dòng agent) CỘNG
# mô hình GIAO VIỆC THEO DÒNG AGENT: bảng Theo Agent là view chính
# của mục Công việc (agent → kênh, chuột phải trên dòng kênh: Giao
# việc theo checklist mẫu + đính skill từ thư viện / nhập skill mới
# ngay trong hộp thoại, checklist THƯỜNG TRỰC riêng từng kênh lưu
# file trong data/ — app/assignments.py + docs/ASSIGNMENT_MODEL.md).
# Mẫu việc + checklist lưu FILE nên schema DB giữ 8, API giữ 2.6 —
# hiển thị "V5.0".
# V5.1: BẢN THIẾT KẾ LẠI theo phương án duyệt 2026-10-30 13:17
# (UI_V51_DESIGN_PLAN.md, ảnh mẫu ui_v51_concepts/): (1) KỶ NGUYÊN
# GIAO DIỆN — token theo plan §1.1 (nền #0B0E11, panel #15181D bo
# 20, thẻ #1B1F26 bo 16, nhấn #4ADE80, tiến độ 10px, scrollbar 8px)
# áp VÔ ĐIỀU KIỆN ở lần chạy đầu (settings theme_epoch; bộ cũ sao
# lưu theme_backup_pre_v51 + nút khôi phục/áp lại ở mục Giao diện)
# — thay cơ chế di trú khớp-tuyệt-đối đã thất bại trên máy thật;
# (2) panel chi tiết Văn phòng dựng lại: header cố định 76px
# (avatar 56 + tên/mail + pill, bỏ nhãn "CHI TIẾT AGENT" và 2 nút
# nhảy mục), thân QScrollArea cuộn dọc, chat ghim đáy panel ngoài
# vùng cuộn + tự làm mới 5 giây; (3) Công việc: bảng Theo Agent
# dạng THẺ (agent → thẻ con kênh), menu chuột phải giữ nguyên;
# (4) Hồ sơ: thanh chip hồ sơ trên cùng + bố cục focus khi vào mục
# (cột thẻ + panel dữ liệu thu gọn, trình duyệt đầy vùng nội dung),
# tường trình duyệt giữ nguyên; (5) Tự động: quy tắc dạng thẻ +
# công tắc pill + banner sức khoẻ + Chạy ngay/Sửa; Hệ thống thêm
# thẻ Cầu nối. API giữ 2.6, schema DB giữ 8 — hiển thị "V5.1".
# V5.2: VÒNG SỬA LỖI MÁY THẬT (chủ kênh bác V5.1): (1) HIỆU NĂNG —
# QSS áp TRƯỚC khi dựng UI + bỏ setStyleSheet trùng (khởi động đo
# trên fixture cỡ máy thật 8,7s → mục tiêu <2s); vân RẺ cho chat
# (messages_signature) + vân NHẸ cho bảng công việc
# (list_commands_light/list_agents_light); cache QFont cảnh Văn
# phòng; gate setText/setStyleSheet các nhịp nền; MonitorPanel hết
# timer mồ côi; mục Hệ thống hiện dòng "Hiệu năng" đo thật.
# (2) HỒ SƠ — BỎ hẳn thanh chip V5.1 + bố cục focus (chọn hồ sơ về
# cột thẻ); tường trình duyệt: thứ tự ô cố định theo id, reset toàn
# bộ stretch lưới mỗi lần dựng, nhãn ô 1 hàng; CHỈ NHÚNG — nhúng
# lỗi thì đỗ khuất cửa sổ + placeholder lỗi kèm nút "Nhúng lại"
# trong app, cửa sổ tự mở chưa nhúng cũng bị đỗ khuất; ZOOM đã lưu
# áp qua CDP ở MỌI lần nhúng/lại nhúng (khung đơn, ô tường,
# watchdog). (3) HÌNH ẢNH THẬT — assets robot_avatar.png +
# office_floor.jpg đóng gói: avatar robot thật (vòng màu theo
# agent) ở panel chi tiết Văn phòng/bảng Tài khoản/thẻ Công việc/
# đầu khối chat; nền cảnh Văn phòng là ảnh isometric thật, chữ
# trần chuyển bản sáng. API giữ 2.6, schema DB giữ 8 — "V5.2".
# V5.2.1: CHAT TRONG PANEL CHI TIẾT VĂN PHÒNG THU/MỞ ĐƯỢC (góp ý
# máy thật trên V5.2: khung chat chiếm hơn nửa panel, bóp khối
# "Việc hiện tại" không đọc được). AgentChatWidget thêm chế độ
# collapsible (chỉ bản Văn phòng bật; bản Tài khoản giữ nguyên):
# thanh tiêu đề luôn hiện (huy hiệu chưa đọc + nút thu/mở), mặc
# định THU GỌN khi không có gì chờ, TỰ BUNG khi có tin chưa đọc/
# câu hỏi needs_user đang chờ/người dùng mở, TỰ THU sau khi đọc/
# gửi xong và hết chờ (mở tay thì không tự thu); khi bung, luồng
# tin chặn chiều cao 120–200px cuộn bên trong. Panel bỏ ép chiều
# cao tối thiểu 250px cho khung chat. API giữ 2.6, schema DB
# giữ 8 — hiển thị "V5.2.1".
# V5.3: VÒNG GỌN GIAO DIỆN + TRÌNH DUYỆT LINH HOẠT (phương án
# UI_V53_PLAN.md, chủ kênh duyệt 2026-10-30 18:10): (A2) BỎ HẾT
# label thông báo — banner needs_user lớn, hệ toast, đoạn hướng
# dẫn dài dưới form tạo lệnh (sự kiện vẫn vào Nhật ký; trạng thái
# chờ-người vẫn ở pill/huy hiệu ngắn vốn có); (A3) hàng "Cầu nối
# Muse" chuyển vào CÙNG HÀNG với bộ lọc của danh sách lệnh, nút
# cao 24px; (A4) bỏ 3 nút Chạy ngay/Xoá lệnh/Làm mới ở tab Công
# việc (menu chuột phải có đủ cả ba); (A5) bảng gọn toàn app —
# đệm dọc ô 2px, chiều cao hàng suy từ font qua
# theme.compact_row_height, cột Kết quả của bảng lệnh hiện TÓM
# TẮT NGẮN thay repr dict thô; (A6) quét bỏ nhãn giải thích dài
# ở mọi tab (nội dung cần thiết chuyển vào tooltip); (A7) TRÌNH
# DUYỆT KHỞI ĐỘNG CÙNG TOOL (mặc định mới của
# auto_open_browsers_on_start = BẬT) + tường trình duyệt ĐỔI QUY
# CÁCH theo lệnh mới nhất của chủ kênh: ô CỐ ĐỊNH 600×800px, tối
# đa 3 ô/hàng, thừa xuống dòng, cuộn dọc (thay cột dọc V5.2);
# (A8) CHẠY ẨN NGOÀI APP (setting browsers_hidden_mode — ngoại
# lệ do chủ kênh trực tiếp ra lệnh cho quy tắc chỉ-nhúng): trình
# duyệt mở cửa sổ riêng/thu nhỏ (--start-minimized qua
# ChromeManager.launch_minimized_default cho mọi đường mở), app
# không nhúng, watchdog/tự-nhúng đứng yên, CDP nguyên vẹn;
# (A9) NỀN VĂN PHÒNG ĐỔI ĐƯỢC: chọn ảnh trong mục Giao diện
# (sao vào data/office_bg/, setting office_bg_image) + khôi
# phục mặc định, scene dùng qua office_background_pixmap với
# fallback ảnh đóng gói. Giữ nguyên mục chat thu/mở của V5.2.1.
# API giữ 2.6, schema DB giữ 8 — hiển thị "V5.3".
# V5.3.1: VÒNG GÓP Ý MÁY THẬT ĐẦU TIÊN TRÊN V5.3 (chủ kênh
# 2026-10-30 19:31): (M1) khối đầu bảng việc "Ai đang làm gì" từ
# 5 tầng layout nén còn TỐI ĐA 2 dòng ở 1920/1460 — một
# FlowLayout duy nhất (tiêu đề + đếm rút gọn + tìm kiếm + sắp
# xếp + dạng xem + 6 pill LỌC bấm được mang số đếm, gộp hàng
# pill và hàng Lọc làm một; hẹp hơn thì xuống dòng, không cắt
# chữ); (M2) Cài đặt → Giao diện chỉnh được KÍCH THƯỚC Ô TƯỜNG
# trình duyệt (setting wall_tile_width/height, mặc định 600×800,
# thay hằng số cứng A7) và ĐỘ CAO NÚT HÀNG LỆNH (setting
# row_action_button_height, mặc định 24, qua
# theme.row_action_height cho mọi nút từng ghim 24px), áp một
# lần khi Lưu qua MainWindow._apply_settings; (M3) chat Văn
# phòng: bong bóng PHẲNG bỏ viền (+ thời gian chữ thường không
# khung), trần luồng mặc định 200→160, panel chi tiết KÉO RỘNG
# 280–560px bằng splitter ngang (lưu office_detail_width), panel
# SÁT MẸP PHẢI (lề phải gốc = 0, header/toolbar tự giữ lề), và
# SPLITTER DỌC trong panel cho chiều cao luồng chat kéo tay
# 100–420px (lưu office_chat_thread_height, thắng trần 160);
# (M4) nền Văn phòng "không ăn": chẩn đoán render thật cho thấy
# đường sơn ĐÚNG — lỗi ở tầng điều khiển/phản hồi: hai hàng chọn
# ảnh giống hệt nhau ("Ảnh nền" cửa sổ vs "Nền Văn phòng") gây
# chọn nhầm + báo thành công vô điều kiện khi ảnh không nạp
# được. Sửa: nhãn/nút phân biệt rõ + kiểm chứng QPixmap trước
# khi lưu/báo thành công (hỏng → báo lỗi có hướng dẫn, không
# lưu); (M5) sửa pin chiều cao dòng ≥52px sót từ V5.3 trong
# test_v37 theo công thức gọn A5 (parent bắt qua full-suite).
# API giữ 2.6, schema DB giữ 8 — hiển thị "V5.3.1".
# V5.3.2: (CHAT) trình bày lại ô chat theo PHƯƠNG ÁN 1 chủ kênh
# duyệt — BỎ HẲN bong bóng: tin là hàng chữ trần trên nền panel
# (Muse trái: avatar 28px + tên "Muse · <nhãn>" + giờ mờ cùng
# hàng, thân thụt thẳng hàng; Bạn phải: giờ + tên accent; hệ
# thống giữa màu cảnh báo), đầu ô chat thêm trạng thái đọc chữ
# mờ, ô nhập trên dải tối hơn panel không viền + nút Gửi viên
# accent, khung chat Văn phòng bỏ khung Panel riêng + panel bỏ
# lề ngang nên nội dung tràn hết bề ngang panel chứa; hành vi
# thu/mở/vân/đã đọc giữ nguyên. (M-BULK) menu chuột phải Danh
# sách lệnh thêm "✕ Huỷ tất cả lệnh" + "🗑 Xoá tất cả" (xác
# nhận kèm số đếm thật, huỷ qua _cancel_one dùng chung với nút
# đơn, xoá giữ lại lệnh đang chạy và báo số bỏ qua).
# (M-PROFILE-EDIT) thẻ hồ sơ thêm nút "✎ Sửa hồ sơ" RowAction +
# mục sửa trong menu chuột phải, mở AddProfileDialog chế độ sửa
# (Store.update_profile mới — nhãn/Gmail/ghi chú; slug/cổng giữ
# nguyên). API giữ 2.6, schema DB giữ 8 — hiển thị "V5.3.2".
# V5.3.3: (V1) ô nhập chat theo ảnh duyệt chat_redesign_v3 —
# dải nhập CAO CỐ ĐỊNH ~88px (theme.chat_composer_height từ
# line-height thật), một hàng: ô soạn chiếm hết chiều cao dải,
# chữ căn giữa theo chiều cao khi ngắn (viewport margin), tràn
# thì cuộn trong ô với thanh cuộn mảnh; nút Gửi neo phải-dưới;
# placeholder "Nhắn cho Muse…" + tooltip phím. (V2) DIỆT VIỀN
# TRẮNG MỜ quanh khung/ô chat: tắt khung StyledPanel chìm
# native của QPlainTextEdit ở mức C++ (NoFrame), nút thu/mở +
# nút ✕ chip bỏ hộp "ghost" sang style phẳng scope objectName,
# huy hiệu chưa đọc bỏ viền/nền tint thành chữ đậm phẳng.
# (V3) mép dưới khối chat cách viền dưới panel Văn phòng đúng
# 1px (margin layout 16 → 1); tab Tài khoản tương tự. (V4) sửa
# lệch 28px khôi phục chiều cao luồng kéo tay: phần cố định đo
# bằng sizeHint (fixed_chrome_height) thay vì hiệu số hình học
# thoáng qua + ép layout phân phối lại đồng bộ khi đổi dải
# chiều cao/lưu (full-suite V5.3.2: lưu 160 → khôi phục 132).
# API giữ 2.6, schema DB giữ 8 — hiển thị "V5.3.3".
# V6.0: GIÁM SÁT CHÉO GIỮA CÁC TÀI KHOẢN CLAUDE (UI_V60_PLAN) —
# việc kiểm tra là MỘT LOẠI LỆNH 'review' trong hệ thống sẵn có
# (claim/lease/tiến độ như lệnh thường): ma trận giám sát (mặc
# định vòng chéo theo id, CHẶN tự chấm ở tầng dữ liệu), watchdog
# trong app (treo tiến độ/lease chết/mất heartbeat → vòng 'stuck'),
# gói bằng chứng + checklist tách từ skill đính kèm, 3 kết luận
# (Đạt / làm lại tối đa 2 vòng / leo thang needs_user), tab Giám
# sát (hàng đợi + cảnh báo + thẻ điểm tuần), lịch sử kiểm tra
# trong chi tiết lệnh kèm override của chủ kênh, thẻ điểm tóm tắt
# ở tab Báo cáo. Agent API 2.6 → 2.7 (POST
# /api/commands/{id}/verdict + GET /api/agents/{id}/scorecard);
# schema DB 8 → 9 (bảng reviews + review_round/last_verdict trên
# lệnh). Hiển thị "V6.0".
# V6.1: TRƯỞNG PHÒNG + HẠN CHÓT + SỰ CỐ + CHỐNG ĐƠ — (1) chế độ giám
# sát "lead": chọn MỘT tài khoản Muse làm trưởng phòng chấm mọi tài
# khoản khác (việc của trưởng phòng do người kế tiếp trong vòng chấm),
# đổi ngay trên tab Giám sát; (2) MỌI lệnh có hạn chót due_at (mặc định
# theo loại, cài đặt deadline_minutes ghi đè; gia hạn/đặt hạn tại tab
# Giám sát), watchdog báo trễ hạn một lần cho trưởng phòng + người
# làm; tab Giám sát vẽ lại: dải chỉ số, BẢNG TIẾN ĐỘ THEO HẠN (thanh %
# + vạch thời gian đã dùng), sơ đồ đội, thẻ điểm có % đúng hạn; (3)
# Văn phòng có khối "Sự cố cần xử lý" (lỗi thật + cách xử lý + nút
# làm ngay), huy hiệu ⚠ trên bàn, bong bóng chờ-người hiện lý do kẹt;
# (4) chống đơ: dò cổng Chrome ở luồng nền song song (bản cũ dò từng
# hồ sơ trên luồng giao diện mỗi 600ms — N hồ sơ tắt = N×0.6s treo),
# opener localhost không proxy, chỉ mục cho bảng commands/journal,
# bộ chạy lệnh dùng lại kết nối DB, bảng sơn lại sau nạp lô; chỉ việc
# của Muse mới sinh kiểm tra chéo (bản cũ sinh cả cho quét/kiểm tra).
# API 2.7 → 2.8 (due_at trong lệnh), schema DB 9 → 10.
# V6.2: ĐĂNG NHẬP HÀNG LOẠT muse.ai qua tinyhost.shop — nút 🔐 ở tab
# Tài khoản Muse: dán danh sách email (email mới tự thành tài khoản),
# app lần lượt mở Chrome riêng của từng tài khoản, dán email vào
# tinyhost + muse.ai, chờ ô nhập mã, bấm Check Inbox lấy mã MỚI (bỏ
# mã cũ), dán mã, kiểm tra đã đăng nhập rồi tự thoát Chrome; bước nào
# không tự xử lý được thì để nguyên cửa sổ cho người dùng (app/muse_autologin.py).
# V6.3: TỰ VẬN HÀNH — bộ quy tắc + KPI (nhân viên/giám sát) trong Cài
# đặt, gửi kèm mọi lệnh; trưởng phòng tự xử lý sự cố + tự thay khi KPI
# kém; bảng việc chi tiết từng bước thay danh sách lệnh; chat tức thì
# (đẩy tin vào muse.ai); realtime theo PRAGMA data_version; Văn phòng
# 2D/3D; tường trình duyệt ưu tiên Muse + bố cục cột/lấp đầy + kéo
# giãn đồng loạt + tự tắt Chrome rảnh; "mắt" cho Muse (snapshot trang,
# lớp phủ giám sát); file lớn theo khúc/kéo từ link; báo cáo kênh 8h.
# Schema DB 10 → 11 (command_steps, lead_decisions).
# V6.3.1: giao diện đồng bộ AI Studio V31.1 (bảng màu, nút, nền, header 56px, một kiểu thanh tiến độ); sửa tab Tài khoản mất danh sách (ép vẽ lại khi chuyển mục).
# V6.4: Văn phòng 3D mới — khoang làm việc isometric, robot khối 3D chuyển động, thẻ việc nổi, bấm cả khoang để chọn agent (app/ui/office_3d.py); sàn ảnh nền cũ giữ ở nút "Sàn cũ".
# V6.4.1: Văn phòng 3D nhẹ hơn ~6 lần (đệm phần tĩnh, chỉ vẽ lại vùng robot đang động, giảm nhịp khi không focus/không ai làm).
# V6.4.2: tự nối lại khi mất kết nối Muse — Tailscale thử lại giãn dần, cầu nối tự kiểm + khởi động lại, Muse mất nhịp tim được nhắc kết nối lại qua muse.ai (app/reconnect.py).
# V6.4.3: chat trực tiếp muse.ai qua cầu nối trình duyệt (app/muse_chat_bridge.py) — gõ tin/giao việc thẳng vào chat muse.ai, đọc câu trả lời trên trang, không cần phiếu/connector.
# V6.4.4: sửa "database is locked" ở Agent API — chờ khoá 30 giây, WAL synchronous=NORMAL, nhịp sống không làm hỏng lời gọi, kho bận trả 503 + retry_after.
# V6.5: tab Công việc Kanban (app/ui/kanban_view.py) + nạp skill từ thư mục; tab Báo cáo dạng bảng điều khiển (app/ui/report_dashboard.py); Giám sát cạnh Báo cáo; trưởng phòng toàn quyền + bắt buộc báo tiến độ; Muse điều khiển trình duyệt nhúng qua khối ```ccd``` (app/muse_control.py); zoom trang theo ô/hàng/tất cả (app/page_zoom.py); chat bám đáy.
# V6.5.1: Chrome mở thu nhỏ rồi được nhúng không còn co thành một thanh nhỏ — khôi phục cửa sổ trước khi giãn đầy ô (app/docking.py ensure_restored), ô đã nhúng bị thu nhỏ tự lành ở nhịp kế.
# V6.5.2: Chrome muse.ai không còn bật lên liên tục — mở chạy nền ngoài màn hình (ChromeManager.launch hidden), bỏ tự đăng nhập lại theo nhịp 30s, chỉ đăng nhập lại khi trang báo đăng xuất thật (tối đa 15 phút/lần).
# V6.6: Văn phòng 3D mới (app/ui/office_iso.py + app/office_feed.py) — phòng trưởng phòng, bàn agent theo trạng thái, hiệu ứng giao việc/nhận việc/báo cáo, chế độ làm việc/ngoài giờ, luồng trao đổi hai chiều; giao thức ĐÃ NHẬN/TIẾN ĐỘ/KẾT QUẢ/LỖI, trưởng phòng hỏi lại khi chưa xác nhận (ack_watch).
# V6.7: sửa đọc nhầm tin của chính app thành trả lời Muse; tin trưởng phòng luôn kèm nội dung việc + tự gửi lại khi Muse báo thiếu; Chrome cất ngoài màn hình + khỏi taskbar, chỉ mở khi cần, tự tắt khi rảnh, giới hạn số Chrome muse.ai; văn phòng 3D bong bóng ẩn/hiện theo sự kiện + chip trạng thái; bảng sự cố có duyệt hàng loạt + ghi chú trưởng phòng; Sổ giao việc; tạo hồ sơ hàng loạt mail|pass + giao agent.
# V6.8: hình agent 3D tuỳ chỉnh (app/ui/avatars.py + avatar_dialog.py) — 5 mẫu nhân vật, màu thân/nhấn/da/tóc, kích thước, chung hoặc riêng từng agent/trưởng phòng, xem trước trực tiếp; mở từ Văn phòng 3D hoặc Cài đặt → Giao diện.
# V6.8: + giao diện CĂN PHÒNG (app/ui/office_themes.py): 5 mẫu văn phòng, màu sàn/tường/bàn/màu nhấn, kiểu sàn, đồ trang trí (cây, thảm, sofa, bảng KPI, kệ sách, máy nước).
# V6.9: menu chuột phải + chọn nhiều/xoá/giao việc hàng loạt ở Bảng việc chi tiết (app/command_actions.py); popup "kẹt gì" khi rê chuột lên mọi nút trạng thái; chọn nhiều kênh nổi viền ở Theo Agent; mọi nút có trạng thái đang xử lý (button_feedback.py); thanh Hồ sơ: nút ra ngoài, trạng thái chạy ẩn thật, zoom kéo áp cho Tường.
# V7.0: CSDL tự sửa khi hỏng + sao lưu 30 phút (db_health.py); Chrome muse.ai chạy không cửa sổ (headless); Luồng trao đổi đầy đủ + kéo rộng; ĐA NỀN TẢNG Facebook fanpage/TikTok, đăng nhập bằng cookie (platforms.py); logo kênh ở bảng Agents; trưởng phòng TRẢ LỜI THAY chủ kênh (lead_answer.py); hiển thị từng bước Muse thao tác trên trình duyệt; danh sách kênh kéo cao được.
# V7.0.1: cột Tạo lệnh ↔ Ai đang làm gì kéo rộng/hẹp tự do; Chrome tắt bong bóng dịch trang / khôi phục trang / lưu mật khẩu / thông báo; quét Facebook bấm "Xem thêm" + gộp hết page; ô nội dung lệnh kéo cao được.
# V7.1: LƯỚI XEM TRỰC TIẾP — trình duyệt chạy nền kích thước cố định, không nhúng/không che nhau, chống "ngủ", Muse thao tác có focus + viewport desktop; bấm 🖐 để tự điều khiển (live_grid.py). Văn phòng có CỘT TIẾN ĐỘ từng agent: việc cụ thể, kênh, %, tiến độ con "cảnh 20/30", ai giao (progress_board.py, office_progress.py).
DISPLAY_VERSION = "V7.1"
