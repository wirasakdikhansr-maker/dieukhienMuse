"""Client CDP (Chrome DevTools Protocol) tối giản qua websocket.

Chỉ cần 3 việc: ``Page.navigate``, ``Runtime.evaluate``,
``Page.captureScreenshot`` (+ ``Page.bringToFront``). Thư viện
``websocket-client`` được import lười (lazy) để các module khác vẫn import
được khi chưa cài — lỗi chỉ phát sinh khi thực sự kết nối.
"""

from __future__ import annotations

import json
import urllib.request

DEFAULT_TIMEOUT = 15.0


class CDPError(Exception):
    pass


class CDPConnectionDropped(CDPError, ConnectionError):
    """Socket CDP bị đóng/rớt giữa chừng — vừa là CDPError vừa là
    ConnectionError để logic nối-lại (is_connection_drop) nhận diện."""


# --------------------------------------------------------------------------- #
# Nhận diện lỗi bắt tay WebSocket bị Chrome từ chối vì origin (403)
# --------------------------------------------------------------------------- #
# Chrome bản mới chặn kết nối WebSocket CDP từ origin lạ nếu Chrome không
# được mở bằng cờ --remote-allow-origins. App luôn tự mở Chrome kèm cờ đó
# (xem chrome_manager), nhưng nếu Chrome của hồ sơ đã chạy sẵn từ trước
# (không qua app) thì bắt tay sẽ 403. Hai hằng dưới biến lỗi thô thành câu
# tiếng Việt rõ nguyên nhân + cách khắc phục cho UI/nhật ký.
ORIGIN_REJECTED_MESSAGE = (
    "Chrome của hồ sơ này đang chạy mà không có cờ cho phép điều khiển "
    "(--remote-allow-origins) nên Chrome từ chối kết nối điều khiển (403). "
    "Hãy đóng hẳn Chrome của hồ sơ (kể cả biểu tượng ở khay hệ thống) "
    "rồi bấm Mở trình duyệt lại trong app."
)

def classify_ws_error(exc: BaseException | str | None) -> str | None:
    """Nếu lỗi là vụ Chrome từ chối WebSocket vì origin (403) → trả về câu
    hướng dẫn tiếng Việt ở trên; không phải → None."""
    if exc is None:
        return None
    text = str(exc).lower()
    if "rejected an incoming websocket" in text:
        return ORIGIN_REJECTED_MESSAGE
    if "handshake status 403" in text or "403 forbidden" in text:
        return ORIGIN_REJECTED_MESSAGE
    if "remote-allow-origins" in text:
        return ORIGIN_REJECTED_MESSAGE
    return None


def is_connection_drop(exc: BaseException) -> bool:
    """Lỗi thuộc nhóm 'socket rớt' (đóng/reset/pipe vỡ) — nhóm DUY NHẤT được
    phép nối lại + thử lại lệnh, khác với timeout (không thử lại vì lệnh
    có thể đã chạy dở trong trang)."""
    if isinstance(exc, (ConnectionError, EOFError)):
        return True
    name = type(exc).__name__
    return name in (
        "WebSocketConnectionClosedException",
        "WebSocketBadStatusException",
    )


# --------------------------------------------------------------------------- #
# Chất lượng ảnh thích ứng cho luồng trực tiếp
# --------------------------------------------------------------------------- #
class AdaptiveQuality:
    """Điều tiết chất lượng JPEG của ảnh chụp CDP theo tốc độ chụp thật:
    khung chụp chậm liên tục → hạ bậc chất lượng; nhanh thong thả → nâng
    lại dần. Logic thuần (không IO) để kiểm thử độc lập.

    ``target_interval``: thời gian mục tiêu cho một khung (giây) — vd
    0.2 với luồng 5 fps. Ngưỡng: chậm = elapsed > target; nhanh =
    elapsed < target/2. 3 khung chậm liên tiếp → hạ 1 bậc; 10 khung
    nhanh liên tiếp → nâng 1 bậc (chống dao động qua lại).
    """

    def __init__(self, levels=(60, 45, 30, 20), target_interval: float = 0.2):
        self._levels = list(levels) or [60]
        self._index = 0
        self._target = max(0.02, float(target_interval))
        self._slow_streak = 0
        self._fast_streak = 0

    def quality(self) -> int:
        return self._levels[self._index]

    def note_frame(self, elapsed: float) -> int:
        """Ghi nhận thời gian chụp một khung; trả về chất lượng hiện hành."""
        if elapsed > self._target:
            self._slow_streak += 1
            self._fast_streak = 0
        elif elapsed < self._target / 2:
            self._fast_streak += 1
            self._slow_streak = 0
        else:
            self._slow_streak = 0
            self._fast_streak = 0
        if self._slow_streak >= 3 and self._index < len(self._levels) - 1:
            self._index += 1
            self._slow_streak = 0
        elif self._fast_streak >= 10 and self._index > 0:
            self._index -= 1
            self._fast_streak = 0
        return self.quality()


# V6.1: opener KHÔNG proxy cho localhost — urlopen mặc định trên Windows
# đọc cấu hình proxy từ registry ở MỖI lời gọi (chậm, và proxy công ty
# có thể chặn/giữ cả 127.0.0.1).
_LOCAL_OPENER = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def http_json(port: int, path: str, method: str = "GET", timeout: float = 3.0):
    """Gọi endpoint HTTP của Chrome remote debugging (vd /json/list)."""
    url = f"http://127.0.0.1:{port}{path}"
    request = urllib.request.Request(url, method=method)
    with _LOCAL_OPENER.open(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def debug_port_open(port: int, timeout: float = 1.0) -> bool:
    try:
        http_json(port, "/json/version", timeout=timeout)
        return True
    except Exception:
        return False


def page_websocket_url(port: int) -> str:
    """Tìm websocket của một tab trang (page target). Ưu tiên tab YouTube;
    nếu chưa có tab nào thì tạo tab mới."""
    targets = http_json(port, "/json/list")
    pages = [t for t in targets if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
    if not pages:
        try:
            http_json(port, "/json/new?https://www.youtube.com/", method="PUT")
        except Exception:
            http_json(port, "/json/new?https://www.youtube.com/")
        targets = http_json(port, "/json/list")
        pages = [t for t in targets if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
    if not pages:
        raise CDPError(f"Không tìm thấy tab trang nào trên cổng {port}")
    for page in pages:
        if "youtube" in (page.get("url") or ""):
            return page["webSocketDebuggerUrl"]
    return pages[0]["webSocketDebuggerUrl"]


def browser_websocket_url(port: int) -> str:
    """WebSocket cấp TRÌNH DUYỆT (browser target) từ /json/version —
    cần cho các lệnh cấp trình duyệt như Storage.getCookies/setCookies
    (V3.2, kho cookies đăng nhập)."""
    info = http_json(port, "/json/version")
    url = info.get("webSocketDebuggerUrl")
    if not url:
        raise CDPError(f"Cổng {port} không trả webSocketDebuggerUrl cấp trình duyệt")
    return url


def browser_call(port: int, method: str, params: dict | None = None, timeout: float = 15.0) -> dict:
    """Gọi MỘT lệnh CDP cấp trình duyệt rồi đóng kết nối (one-shot).
    websocket-client không gửi Origin header nên không dính lỗi 403
    bắt tay đã xử lý ở V3.1."""
    try:
        import websocket  # websocket-client
    except ImportError as exc:  # pragma: no cover
        raise CDPError(
            "Thiếu thư viện websocket-client. Cài bằng: pip install -r requirements.txt"
        ) from exc
    connection = websocket.create_connection(browser_websocket_url(port), timeout=timeout)
    try:
        connection.send(json.dumps({"id": 1, "method": method, "params": params or {}}))
        while True:
            message = json.loads(connection.recv())
            if message.get("id") == 1:
                if "error" in message:
                    raise CDPError(f"{method} lỗi: {message['error']}")
                return message.get("result") or {}
    finally:
        connection.close()


def get_all_cookies(port: int) -> list[dict]:
    """Toàn bộ cookie thô (định dạng CDP) của trình duyệt hồ sơ."""
    result = browser_call(port, "Storage.getCookies")
    return result.get("cookies") or []


def set_cookies(port: int, cookies: list[dict]) -> None:
    """Nạp danh sách cookie (tham số CDP, xem cookies_vault.to_cdp_cookie)
    vào trình duyệt hồ sơ."""
    if cookies:
        browser_call(port, "Storage.setCookies", {"cookies": cookies})


class CDPClient:
    """Một kết nối CDP tới MỘT tab. Không thread-safe — mỗi luồng dùng
    một client riêng.

    V3.1 — tự nối lại: nếu socket RỚT giữa chừng (Chrome/tab bị tải lại,
    mạng nội bộ chập chờn), client tự xin URL websocket mới qua callable
    ``reconnect`` (nếu được cấp) và thử lại lệnh, tối đa
    ``max_reconnects`` lần với thời gian chờ tăng dần (backoff). Timeout
    KHÔNG thuộc nhóm được thử lại (lệnh có thể đã chạy dở trong trang).
    """

    def __init__(
        self,
        websocket_url: str,
        timeout: float = DEFAULT_TIMEOUT,
        reconnect=None,
        max_reconnects: int = 3,
        sleep=None,
        clock=None,
    ):
        try:
            import websocket  # websocket-client
        except ImportError as exc:  # pragma: no cover
            raise CDPError(
                "Thiếu thư viện websocket-client. Cài bằng: pip install -r requirements.txt"
            ) from exc
        self._websocket = websocket
        self._url = websocket_url
        self._timeout = timeout
        self._reconnect = reconnect
        self._max_reconnects = max(0, int(max_reconnects))
        import time as _time

        self._sleep = sleep or _time.sleep
        self._clock = clock or _time.monotonic
        self._ws = websocket.create_connection(websocket_url, timeout=timeout)
        self._next_id = 0
        # V4.4: bộ đệm thông điệp lệch nhịp — sự kiện (event) và phản hồi
        # của lời gọi KHÁC đến trong lúc chờ một phản hồi/sự kiện cụ thể
        # được GIỮ LẠI ở đây thay vì vứt đi như bản cũ (bản cũ bỏ qua
        # mọi message không khớp id → Page.loadEventFired bị mất hút).
        self._event_buffer: list[dict] = []
        self._response_buffer: list[dict] = []

    def _reconnect_now(self) -> None:
        """Đóng socket cũ, mở socket mới tới cùng tab (URL xin lại qua
        callable reconnect vì URL cũ có thể đã chết theo tab)."""
        try:
            self._ws.close()
        except Exception:
            pass
        new_url = self._reconnect() if self._reconnect is not None else self._url
        self._url = new_url
        self._ws = self._websocket.create_connection(new_url, timeout=self._timeout)

    def call(self, method: str, params: dict | None = None, timeout: float | None = None) -> dict:
        attempts_left = self._max_reconnects
        backoff = 0.5
        while True:
            try:
                return self._call_once(method, params, timeout)
            except Exception as exc:
                if (
                    attempts_left <= 0
                    or self._reconnect is None
                    or not is_connection_drop(exc)
                ):
                    raise
                attempts_left -= 1
                self._sleep(backoff)
                backoff *= 2
                try:
                    self._reconnect_now()
                except Exception:
                    raise exc  # nối lại cũng hỏng → trả lỗi gốc cho rõ

    def _stash_message(self, message: dict) -> None:
        """Giữ lại thông điệp không phải thứ đang chờ: sự kiện (có
        'method', không id) → đệm sự kiện; phản hồi của lời gọi khác
        (có id) → đệm phản hồi. V4.4 — nền cho wait_event."""
        if message.get("id") is not None:
            self._response_buffer.append(message)
        elif message.get("method"):
            self._event_buffer.append(message)

    def _call_once(self, method: str, params: dict | None = None, timeout: float | None = None) -> dict:
        # Phản hồi có thể đã về từ trước trong lúc chờ sự kiện — kiểm
        # tra đệm trước khi gửi (id chưa cấp nên chỉ khớp sau khi gửi;
        # vòng này giữ đúng thứ tự: gửi trước, rà đệm trong lúc chờ).
        self._next_id += 1
        call_id = self._next_id
        self._ws.settimeout(timeout or self._timeout)
        self._ws.send(json.dumps({"id": call_id, "method": method, "params": params or {}}))
        while True:
            raw = self._ws.recv()
            if not raw:
                raise CDPConnectionDropped(f"Kết nối CDP đóng khi chờ {method}")
            message = json.loads(raw)
            if message.get("id") != call_id:
                self._stash_message(message)  # V4.4: giữ lại thay vì vứt
                continue
            if "error" in message:
                raise CDPError(f"{method}: {message['error']}")
            return message.get("result", {})

    # ------------------------------------------------------------------ #
    # V4.4 — chờ sự kiện CDP (Page.loadEventFired…) + thao tác trang cấp
    # cao cho kịch bản Studio (app/studio_script.py dùng các hàm này).
    # ------------------------------------------------------------------ #
    def wait_event(self, method: str, timeout: float = 30.0) -> dict:
        """Chờ một sự kiện CDP theo tên (vd 'Page.loadEventFired');
        trả về params của sự kiện. Quá hạn → CDPError nêu rõ sự kiện +
        số giây đã chờ. Thông điệp khác đến trong lúc chờ được đệm lại
        (không mất phản hồi/sự kiện khác)."""
        for index, message in enumerate(self._event_buffer):
            if message.get("method") == method:
                del self._event_buffer[index]
                return message.get("params") or {}
        deadline = self._clock() + max(0.0, float(timeout))
        while True:
            remaining = deadline - self._clock()
            if remaining <= 0:
                raise CDPError(
                    f"Chờ sự kiện {method} quá {timeout:g} giây mà không thấy"
                )
            self._ws.settimeout(min(0.25, remaining))
            try:
                raw = self._ws.recv()
            except Exception as exc:
                if _is_timeout_exc(exc):
                    continue
                raise
            if not raw:
                raise CDPConnectionDropped(f"Kết nối CDP đóng khi chờ sự kiện {method}")
            message = json.loads(raw)
            if message.get("method") == method and message.get("id") is None:
                return message.get("params") or {}
            self._stash_message(message)

    def navigate_and_wait(self, url: str, timeout: float = 30.0) -> None:
        """Điều hướng rồi chờ trang tải xong (Page.loadEventFired).
        Lỗi mạng cấp trang (net::ERR…) cũng thành CDPError rõ ràng."""
        self.call("Page.enable")
        # Bỏ sự kiện tải-xong CŨ còn sót trong đệm (của lần điều hướng
        # trước) — không thì wait_event khớp ngay sự kiện đã qua.
        self._event_buffer = [
            m for m in self._event_buffer if m.get("method") != "Page.loadEventFired"
        ]
        result = self.call("Page.navigate", {"url": url})
        if result.get("errorText"):
            raise CDPError(f"Điều hướng tới {url} lỗi: {result['errorText']}")
        self.wait_event("Page.loadEventFired", timeout=timeout)

    def navigate(self, url: str) -> None:
        self.call("Page.enable")
        self.call("Page.navigate", {"url": url})

    # ------------------------------------------------------------------ #
    # V4.4 — thao tác phần tử cấp cao (dùng cho kịch bản Studio).
    # Mọi lỗi đều là CDPError kèm ngữ cảnh (selector/text/timeout) để
    # runner báo đúng bước nào hỏng.
    # ------------------------------------------------------------------ #
    def _find_element(self, selector: str | None, text: str | None) -> dict | None:
        """Tìm phần tử theo selector CSS hoặc theo chữ hiển thị chứa
        `text`; trả {'tag','text','x','y','visible'} hoặc None."""
        script = _FIND_ELEMENT_JS % (
            json.dumps(selector or ""),
            json.dumps(text or ""),
        )
        found = self.evaluate(script)
        return found if isinstance(found, dict) else None

    def wait_for(
        self,
        selector: str | None = None,
        text: str | None = None,
        timeout_s: float = 10.0,
        poll_s: float = 0.25,
    ) -> dict:
        """Chờ phần tử xuất hiện (theo selector hoặc chữ hiển thị).
        Trả info của phần tử; quá hạn → CDPError nêu rõ tiêu chí + số
        giây đã chờ."""
        if not selector and not text:
            raise CDPError("Bước chờ thiếu cả selector lẫn text — không biết chờ gì")
        deadline = self._clock() + max(0.0, float(timeout_s))
        while True:
            info = self._find_element(selector, text)
            if info:
                return info
            remaining = deadline - self._clock()
            if remaining <= 0:
                criteria = (
                    f"selector={selector!r}" if selector else f"text chứa {text!r}"
                )
                raise CDPError(
                    f"Chờ phần tử quá {timeout_s:g} giây mà không thấy ({criteria})"
                )
            self._sleep(min(poll_s, remaining))

    def click_element(
        self, selector: str | None = None, text: str | None = None
    ) -> dict:
        """Bấm phần tử bằng chuột thật tại tâm của nó (cùng cơ chế đã
        kiểm chứng của lệnh cdp_click)."""
        info = self._find_element(selector, text)
        if not info:
            raise CDPError(
                f"Không tìm thấy phần tử để bấm (selector={selector!r}, text={text!r})"
            )
        if not info.get("visible"):
            raise CDPError(
                f"Phần tử cần bấm đang ẩn/không có kích thước "
                f"(selector={selector!r}, text={text!r}, tag={info.get('tag')})"
            )
        x, y = float(info["x"]), float(info["y"])
        for event_type in ("mousePressed", "mouseReleased"):
            self.dispatch_mouse(
                {
                    "type": event_type,
                    "x": x,
                    "y": y,
                    "button": "left",
                    "clickCount": 1,
                }
            )
        return {"tag": info.get("tag"), "text": info.get("text"), "x": x, "y": y}

    def fill_element(self, selector: str, text: str) -> dict:
        """Điền chữ vào ô nhập: focus + chọn toàn bộ nội dung cũ rồi
        Input.insertText (gõ thật theo cơ chế trình duyệt — các form
        React của Studio nhận đúng như người gõ)."""
        if not selector:
            raise CDPError("Bước điền chữ thiếu selector của ô nhập")
        focused = self.evaluate(_FOCUS_AND_SELECT_JS % json.dumps(selector))
        if not focused:
            raise CDPError(f"Không tìm thấy ô nhập để điền chữ (selector={selector!r})")
        self.call("Input.insertText", {"text": text})
        return {"chars": len(text), "selector": selector}

    def press_key(self, key: str) -> dict:
        """Nhấn một phím: Enter/Tab/Escape/Backspace/Delete/Space/
        ArrowUp|Down|Left|Right/Home/End/PageUp/PageDown hoặc 1 ký tự.
        Gửi keyDown + keyUp qua Input.dispatchKeyEvent."""
        name = str(key or "").strip()
        if not name:
            raise CDPError("Bước nhấn phím thiếu tên phím")
        spec = _KEY_MAP.get(name) or _KEY_MAP.get(name.capitalize())
        if spec is None and len(name) == 1:
            spec = {
                "key": name,
                "code": f"Key{name.upper()}" if name.isalpha() else "",
                "windowsVirtualKeyCode": ord(name.upper()),
                "text": name,
            }
        if spec is None:
            raise CDPError(
                f"Không hỗ trợ phím {name!r} — dùng Enter/Tab/Escape/"
                "Backspace/Delete/Space/ArrowUp/ArrowDown/ArrowLeft/"
                "ArrowRight/Home/End/PageUp/PageDown hoặc 1 ký tự"
            )
        for event_type in ("keyDown", "keyUp"):
            params = {"type": event_type, "key": spec["key"]}
            if spec.get("code"):
                params["code"] = spec["code"]
            params["windowsVirtualKeyCode"] = spec["windowsVirtualKeyCode"]
            if event_type == "keyDown" and spec.get("text"):
                params["text"] = spec["text"]
            self.dispatch_key(params)
        return {"key": spec["key"]}

    def read_text(self, selector: str, attr: str | None = None) -> str:
        """Đọc text của phần tử (đã cắt khoảng trắng đầu/cuối), hoặc
        thuộc tính `attr` nếu có. Không thấy phần tử → CDPError."""
        if not selector:
            raise CDPError("Bước đọc thiếu selector của phần tử cần đọc")
        value = self.evaluate(
            _READ_TEXT_JS % (json.dumps(selector), json.dumps(attr or ""))
        )
        if value is None:
            raise CDPError(f"Không tìm thấy phần tử để đọc (selector={selector!r})")
        return str(value)

    def set_file_input(self, selector: str, files: list[str]) -> dict:
        """Gán file thật vào <input type=file> qua DOM.setFileInputFiles
        (cách duy nhất nạp file vào ô upload mà không cần hộp thoại hệ
        thống). files = danh sách đường dẫn TUYỆT ĐỐI phía app."""
        if not selector:
            raise CDPError("Bước nạp file thiếu selector của ô <input type=file>")
        if not files:
            raise CDPError("Bước nạp file không có file nào")
        document = self.call("DOM.getDocument", {"depth": 1})
        root_id = (document.get("root") or {}).get("nodeId")
        if not root_id:
            raise CDPError("Không lấy được DOM của trang để nạp file")
        found = self.call("DOM.querySelector", {"nodeId": root_id, "selector": selector})
        node_id = found.get("nodeId") or 0
        if not node_id:
            raise CDPError(f"Không tìm thấy ô nạp file trên trang (selector={selector!r})")
        self.call(
            "DOM.setFileInputFiles",
            {"nodeId": node_id, "files": [str(f) for f in files]},
        )
        return {"files": [str(f) for f in files], "selector": selector}

    def scroll_into_view(self, selector: str) -> dict:
        """Cuộn tới phần tử (scrollIntoView, canh giữa khung hình)."""
        done = self.evaluate(
            "(() => { const el = document.querySelector(%s);"
            " if (!el) return false;"
            " el.scrollIntoView({block: 'center', inline: 'center'});"
            " return true; })()" % json.dumps(selector)
        )
        if not done:
            raise CDPError(f"Không tìm thấy phần tử để cuộn tới (selector={selector!r})")
        return {"selector": selector}

    def scroll_by(self, dy: int = 600) -> dict:
        """Cuộn trang theo chiều dọc dy pixel (âm = lên)."""
        self.evaluate(f"window.scrollBy(0, {int(dy)})")
        return {"dy": int(dy)}

    def evaluate(self, expression: str, timeout: float | None = None):
        """Chạy JavaScript trong trang, chờ Promise, trả về giá trị thuần."""
        result = self.call(
            "Runtime.evaluate",
            {
                "expression": expression,
                "awaitPromise": True,
                "returnByValue": True,
            },
            timeout=timeout,
        )
        if result.get("exceptionDetails"):
            details = result["exceptionDetails"]
            text = details.get("text") or "JavaScript exception"
            raise CDPError(f"Runtime.evaluate lỗi: {text}")
        return result.get("result", {}).get("value")

    def capture_screenshot_png(self) -> bytes:
        import base64

        result = self.call(
            "Page.captureScreenshot",
            {"format": "png", "fromSurface": True, "captureBeyondViewport": False},
        )
        return base64.b64decode(result["data"])

    def bring_to_front(self) -> None:
        self.call("Page.bringToFront")

    def dispatch_mouse(self, params: dict) -> None:
        """Input.dispatchMouseEvent: type/x/y/button/deltaY..."""
        self.call("Input.dispatchMouseEvent", params)

    def dispatch_key(self, params: dict) -> None:
        """Input.dispatchKeyEvent: type/key/code/windowsVirtualKeyCode/text..."""
        self.call("Input.dispatchKeyEvent", params)

    def close(self) -> None:
        try:
            self._ws.close()
        except Exception:
            pass


def _is_timeout_exc(exc: BaseException) -> bool:
    """Nhận diện lỗi 'hết giờ chờ' của tầng websocket/socket: lớp lỗi
    là TimeoutError hoặc tên lớp chứa 'timeout' (vd
    WebSocketTimeoutException của websocket-client) — dùng khi chờ sự
    kiện CDP theo lát cắt ngắn trong wait_event."""
    if isinstance(exc, TimeoutError):
        return True
    return "timeout" in type(exc).__name__.lower()


# JS tìm phần tử (V4.4): ưu tiên selector; không có selector thì quét
# các phần tử tương tác có nhãn/innerText CHỨA text. Trả về tâm phần
# tử + trạng thái hiển thị, hoặc null. Cùng họ với bản trong
# agent_server cho lệnh cdp_click — giữ độc lập để client tự đủ dùng.
_FIND_ELEMENT_JS = """(() => {
  const sel = %s, wanted = %s;
  let el = null;
  if (sel) { el = document.querySelector(sel); }
  else if (wanted) {
    const nodes = document.querySelectorAll(
      'button, a, [role="button"], input, textarea, [tabindex], ytcp-button, tp-yt-paper-button');
    for (const node of nodes) {
      const label = (node.innerText || node.value || node.getAttribute('aria-label') || '').trim();
      if (label && label.includes(wanted)) { el = node; break; }
    }
  }
  if (!el) return null;
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  const visible = rect.width > 0 && rect.height > 0 &&
    style.visibility !== 'hidden' && style.display !== 'none';
  return {
    tag: el.tagName,
    text: (el.innerText || el.value || '').trim().slice(0, 120),
    x: rect.left + rect.width / 2,
    y: rect.top + rect.height / 2,
    visible: visible
  };
})()"""

# JS focus ô nhập + chọn toàn bộ nội dung cũ (để insertText ghi đè
# sạch): input/textarea dùng .select(); contenteditable dùng
# Selection.selectAllChildren.
_FOCUS_AND_SELECT_JS = """(() => {
  const el = document.querySelector(%s);
  if (!el) return false;
  el.focus();
  if (typeof el.select === 'function') { el.select(); }
  else {
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.selectAllChildren(el);
  }
  return true;
})()"""

# JS đọc text/thuộc tính: null khi không thấy phần tử (phân biệt với
# chuỗi rỗng hợp lệ).
_READ_TEXT_JS = """(() => {
  const el = document.querySelector(%s);
  if (!el) return null;
  const attr = %s;
  if (attr) { const value = el.getAttribute(attr); return value === null ? '' : value; }
  const raw = (el.innerText !== undefined && el.innerText !== null) ? el.innerText : (el.textContent || '');
  return raw.trim();
})()"""

# Bảng phím cho press_key: tên → key/code/mã phím ảo Windows/text.
_KEY_MAP = {
    "Enter": {"key": "Enter", "code": "Enter", "windowsVirtualKeyCode": 13, "text": "\r"},
    "Tab": {"key": "Tab", "code": "Tab", "windowsVirtualKeyCode": 9},
    "Escape": {"key": "Escape", "code": "Escape", "windowsVirtualKeyCode": 27},
    "Backspace": {"key": "Backspace", "code": "Backspace", "windowsVirtualKeyCode": 8},
    "Delete": {"key": "Delete", "code": "Delete", "windowsVirtualKeyCode": 46},
    "Space": {"key": " ", "code": "Space", "windowsVirtualKeyCode": 32, "text": " "},
    "ArrowUp": {"key": "ArrowUp", "code": "ArrowUp", "windowsVirtualKeyCode": 38},
    "ArrowDown": {"key": "ArrowDown", "code": "ArrowDown", "windowsVirtualKeyCode": 40},
    "ArrowLeft": {"key": "ArrowLeft", "code": "ArrowLeft", "windowsVirtualKeyCode": 37},
    "ArrowRight": {"key": "ArrowRight", "code": "ArrowRight", "windowsVirtualKeyCode": 39},
    "Home": {"key": "Home", "code": "Home", "windowsVirtualKeyCode": 36},
    "End": {"key": "End", "code": "End", "windowsVirtualKeyCode": 35},
    "PageUp": {"key": "PageUp", "code": "PageUp", "windowsVirtualKeyCode": 33},
    "PageDown": {"key": "PageDown", "code": "PageDown", "windowsVirtualKeyCode": 34},
}
