"""Hồ sơ Chrome riêng cho từng TÀI KHOẢN CLAUDE (lớp đăng nhập B —
GĐ3/V3.5): mỗi tài khoản Muse có một thư mục Chrome riêng
``data/agents/agent-<id>/`` và cổng debug riêng, để người dùng bấm
"Đăng nhập muse.ai" ngay trong app, đăng nhập bằng chính tài khoản
Muse đó, và phiên đăng nhập được GIỮ LẠI trong thư mục này (lần sau
mở là còn đăng nhập, như hồ sơ Gmail).

Phân biệt hai lớp kết nối:
- Lớp A (cầu nối): Muse gọi Agent API bằng X-Agent-Id + token riêng
  trong "phiếu kết nối" — không cần đăng nhập web.
- Lớp B (ở đây): cửa sổ Chrome riêng của tài khoản để người dùng tự
  đăng nhập muse.ai và làm việc với Muse của tài khoản đó; Muse đó
  dùng phiếu kết nối (lớp A) để điều khiển kênh qua app.

Trạng thái đăng nhập muse.ai được dò bằng cách đọc trang muse.ai
trong chính Chrome của tài khoản: thấy ô soạn chat = đã đăng nhập;
thấy màn hình đăng nhập = chưa; đang ở trang xác thực Google = chưa
rõ (đang giữa chừng).
"""

from __future__ import annotations

from pathlib import Path

from . import config

MUSE_URL = "https://muse.ai/"

# JS đọc trạng thái trang muse.ai trong Chrome của tài khoản.
MUSE_STATE_JS = """
/*ccd:muse-state*/
(() => {
  const text = (document.body ? document.body.innerText : '').slice(0, 4000);
  const composer = document.querySelector(
    'textarea, [contenteditable="true"], [data-testid="chat-input"]'
  );
  const loginish = /log in|sign in|sign up|get started|create (your )?account|đăng nhập/i.test(text);
  return { url: location.href, hasComposer: !!composer, loginish };
})()
"""


def agent_slug(agent: dict) -> str:
    return f"agent-{agent['id']}"


def agent_data_dir(agent: dict, base: Path | None = None) -> Path:
    folder = (Path(base) if base is not None else config.data_dir()) / "agents" / agent_slug(agent)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def agent_profile(agent: dict, base: Path | None = None) -> dict:
    """Hồ sơ GIẢ (pseudo-profile) để dùng chung ChromeManager/docking:
    id ÂM (phân biệt với hồ sơ kênh), slug/cổng riêng, user-data-dir
    riêng dưới data/agents/, trang khởi đầu là muse.ai."""
    slug = agent_slug(agent)
    return {
        "id": -int(agent["id"]),
        "slug": slug,
        "port": config.port_for_slug(slug),
        "label": f"Muse {agent['name']}",
        "gmail": agent.get("email", ""),
        "user_data_dir": str(agent_data_dir(agent, base)),
        "start_url": MUSE_URL,
        "agent_id": int(agent["id"]),
    }


def classify_muse_state(state: dict | None) -> str:
    """Phân loại kết quả đọc trang: 'in' (đã đăng nhập), 'out' (chưa),
    'unknown' (đang giữa flow xác thực / trang lạ)."""
    if not state:
        return "unknown"
    url = state.get("url") or ""
    if "accounts.google.com" in url or "/auth" in url or "oauth" in url:
        return "unknown"
    if state.get("hasComposer"):
        return "in"
    if state.get("loginish"):
        return "out"
    return "unknown"
