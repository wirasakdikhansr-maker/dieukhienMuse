"""V6.3 — CHUYỂN FILE LỚN (tới hàng chục GB) từ server của Muse về máy
chạy app.

Vấn đề: Muse làm việc trên server của nó (muse.ai), còn app chạy ở PC
của người dùng. Video/tài nguyên Muse tạo nằm ở server Muse; endpoint
cũ /api/inbox đọc NGUYÊN body vào RAM (một file vài GB là treo/sập)
và đứt mạng giữa chừng là mất trắng.

Giải pháp hai đường, cả hai đều NỐI TIẾP được khi đứt mạng:

1. ĐẨY theo khúc (Muse → app):
   POST /api/files/upload            {name, size, sha256?, command_id?}
        → {upload_id, chunk_size, received}
   PUT  /api/files/upload/{id}?offset=N   (thân = khúc nhị phân, ghi
        thẳng xuống đĩa theo luồng — không giữ cả file trong RAM)
   GET  /api/files/upload/{id}       → {received, size, done}  (hỏi lại
        offset để nối tiếp sau khi đứt)
   POST /api/files/upload/{id}/complete → kiểm sha256 → chuyển vào
        data/inbox/ hoặc thư mục file của lệnh.

2. KÉO từ link (app → server Muse / Google Drive / S3 presigned…):
   POST /api/files/fetch {url, name?, sha256?, command_id?}
        → {fetch_id}; app tải nền bằng HTTP Range (đứt thì tải tiếp
        từ byte đã có, thử lại tối đa 20 lần).
   GET  /api/files/fetch/{id} → {status, received, size, saved}

File đang nhận nằm ở data/incoming/<id>.part + <id>.json (trạng thái),
nên cả khi app khởi động lại vẫn nối tiếp được.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import threading
import time
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path

CHUNK_SIZE = 16 * 1024 * 1024          # khúc gợi ý cho phía Muse
STREAM_BUFFER = 1024 * 1024            # đệm ghi đĩa
_ID_RE = re.compile(r"^[a-f0-9]{32}$")


def sanitize_name(raw: str | None) -> str:
    name = Path(str(raw or "")).name.strip().replace("\x00", "")
    name = re.sub(r'[<>:"/\\|?*]+', "_", name)
    return name[:180] or "file.bin"


class LargeFileError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status = status


class LargeFiles:
    def __init__(self, data_dir: Path, max_bytes: int, journal=None,
                 command_dir_for=None, opener=None):
        self.data_dir = Path(data_dir)
        self.incoming = self.data_dir / "incoming"
        self.incoming.mkdir(parents=True, exist_ok=True)
        self.max_bytes = int(max_bytes)
        self._journal = journal or (lambda _m: None)
        self._command_dir_for = command_dir_for
        self._opener = opener or urllib.request.urlopen
        self._lock = threading.Lock()
        self._fetch_threads: dict[str, threading.Thread] = {}

    # ------------------------------------------------------------ trạng thái
    def _meta_path(self, uid: str) -> Path:
        return self.incoming / f"{uid}.json"

    def _part_path(self, uid: str) -> Path:
        return self.incoming / f"{uid}.part"

    def _load(self, uid: str) -> dict:
        if not _ID_RE.match(uid or ""):
            raise LargeFileError(404, f"Mã tải lên không hợp lệ: {uid!r}")
        path = self._meta_path(uid)
        if not path.exists():
            raise LargeFileError(404, f"Không thấy phiên tải lên '{uid}'")
        meta = json.loads(path.read_text("utf-8"))
        part = self._part_path(uid)
        meta["received"] = part.stat().st_size if part.exists() else 0
        return meta

    def _save(self, meta: dict) -> None:
        data = {k: v for k, v in meta.items() if k != "received"}
        self._meta_path(meta["id"]).write_text(json.dumps(data, ensure_ascii=False), "utf-8")

    def _public(self, meta: dict) -> dict:
        return {
            "id": meta["id"],
            "kind": meta.get("kind", "upload"),
            "name": meta["name"],
            "size": meta.get("size"),
            "received": meta.get("received", 0),
            "status": meta.get("status", "receiving"),
            "saved": meta.get("saved"),
            "error": meta.get("error"),
            "command_id": meta.get("command_id"),
            "chunk_size": CHUNK_SIZE,
        }

    # ------------------------------------------------------------ đẩy theo khúc
    def init_upload(self, payload: dict) -> dict:
        name = sanitize_name(payload.get("name"))
        try:
            size = int(payload.get("size"))
        except (TypeError, ValueError):
            raise LargeFileError(400, "Cần 'size' (số byte của file)")
        if size < 0:
            raise LargeFileError(400, "'size' không hợp lệ")
        if size > self.max_bytes:
            raise LargeFileError(413, f"File {size} bytes vượt trần {self.max_bytes} bytes")
        sha = str(payload.get("sha256") or "").strip().lower()
        command_id = str(payload.get("command_id") or "").strip() or None
        # Nối tiếp: cùng tên + size + sha (hoặc resume_key) mà phiên cũ chưa xong → trả lại phiên cũ.
        key = str(payload.get("resume_key") or f"{name}|{size}|{sha}")
        for meta_file in self.incoming.glob("*.json"):
            try:
                meta = json.loads(meta_file.read_text("utf-8"))
            except Exception:
                continue
            if meta.get("resume_key") == key and meta.get("status") == "receiving":
                return self._public(self._load(meta["id"]))
        uid = uuid.uuid4().hex
        meta = {
            "id": uid, "kind": "upload", "name": name, "size": size, "sha256": sha,
            "command_id": command_id, "status": "receiving", "resume_key": key,
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        }
        self._save(meta)
        self._part_path(uid).touch()
        return self._public(dict(meta, received=0))

    def status(self, uid: str) -> dict:
        return self._public(self._load(uid))

    def write_chunk(self, uid: str, offset: int, stream, length: int) -> dict:
        """Ghi ``length`` byte đọc từ ``stream`` vào vị trí ``offset``.
        offset phải bằng số byte đã nhận (ghi tuần tự, chống lỗ hổng)."""
        with self._lock:
            meta = self._load(uid)
            if meta.get("status") != "receiving":
                raise LargeFileError(409, f"Phiên '{uid}' không còn nhận dữ liệu ({meta.get('status')})")
            if offset != meta["received"]:
                raise LargeFileError(
                    409, f"offset {offset} khác số byte đã nhận {meta['received']} — hỏi GET để nối tiếp")
            if meta["size"] is not None and offset + length > meta["size"]:
                raise LargeFileError(413, "Khúc vượt quá kích thước đã khai báo")
        remaining = length
        with open(self._part_path(uid), "ab") as fh:
            while remaining > 0:
                block = stream.read(min(STREAM_BUFFER, remaining))
                if not block:
                    break
                fh.write(block)
                remaining -= len(block)
        meta = self._load(uid)
        if remaining:
            raise LargeFileError(400, f"Kết nối đứt giữa khúc — đã nhận tới byte {meta['received']}")
        return self._public(meta)

    def complete(self, uid: str) -> dict:
        meta = self._load(uid)
        if meta.get("status") == "done":
            return self._public(meta)
        if meta["size"] is not None and meta["received"] != meta["size"]:
            raise LargeFileError(409, f"Mới nhận {meta['received']}/{meta['size']} bytes")
        digest = _sha256_file(self._part_path(uid))
        if meta.get("sha256") and meta["sha256"] != digest:
            meta["status"] = "failed"
            meta["error"] = "sha256 không khớp"
            self._save(meta)
            self._part_path(uid).unlink(missing_ok=True)
            raise LargeFileError(400, "sha256 không khớp — file bị loại, hãy gửi lại")
        target = self._destination(meta)
        shutil.move(str(self._part_path(uid)), str(target))
        meta.update(status="done", saved=str(target), sha256=digest, received=target.stat().st_size)
        self._save(meta)
        self._journal(f"[File lớn] Đã nhận '{meta['name']}' ({_human(meta['received'])}) → {target}")
        return dict(self._public(meta), sha256=digest)

    def _destination(self, meta: dict) -> Path:
        if meta.get("command_id") and self._command_dir_for is not None:
            folder = Path(self._command_dir_for(meta["command_id"]))
            return folder / meta["name"]
        inbox = self.data_dir / "inbox"
        inbox.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        path = inbox / f"{stamp}_{meta['name']}"
        counter = 2
        while path.exists():
            path = inbox / f"{stamp}-{counter}_{meta['name']}"
            counter += 1
        return path

    # ------------------------------------------------------------ kéo từ link
    def start_fetch(self, payload: dict) -> dict:
        url = str(payload.get("url") or "").strip()
        if not re.match(r"^https?://", url):
            raise LargeFileError(400, "Cần 'url' http(s) tới file")
        name = sanitize_name(payload.get("name") or url.split("?")[0].rstrip("/").split("/")[-1])
        uid = uuid.uuid4().hex
        meta = {
            "id": uid, "kind": "fetch", "name": name, "size": None, "url": url,
            "sha256": str(payload.get("sha256") or "").strip().lower(),
            "command_id": str(payload.get("command_id") or "").strip() or None,
            "status": "receiving",
            "created_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        }
        self._save(meta)
        self._part_path(uid).touch()
        thread = threading.Thread(target=self._fetch_loop, args=(uid,), daemon=True, name=f"fetch-{uid[:6]}")
        self._fetch_threads[uid] = thread
        thread.start()
        return self._public(dict(meta, received=0))

    def _fetch_loop(self, uid: str, max_attempts: int = 20) -> None:
        attempt = 0
        while attempt < max_attempts:
            attempt += 1
            meta = self._load(uid)
            try:
                headers = {"User-Agent": "ChannelControlDesktop/6.3"}
                if meta["received"]:
                    headers["Range"] = f"bytes={meta['received']}-"
                request = urllib.request.Request(meta["url"], headers=headers)
                with self._opener(request, timeout=60) as response:
                    status = getattr(response, "status", 200)
                    if meta["received"] and status != 206:
                        # Server không hỗ trợ Range → tải lại từ đầu.
                        self._part_path(uid).write_bytes(b"")
                    total = response.headers.get("Content-Range", "")
                    if "/" in total and total.rsplit("/", 1)[1].isdigit():
                        meta["size"] = int(total.rsplit("/", 1)[1])
                    elif response.headers.get("Content-Length") and status == 200:
                        meta["size"] = int(response.headers["Content-Length"])
                    if meta["size"] and meta["size"] > self.max_bytes:
                        raise LargeFileError(413, "File vượt trần dung lượng cho phép")
                    self._save(meta)
                    with open(self._part_path(uid), "ab") as fh:
                        while True:
                            block = response.read(STREAM_BUFFER)
                            if not block:
                                break
                            fh.write(block)
                meta = self._load(uid)
                if meta["size"] is None or meta["received"] >= meta["size"]:
                    meta["size"] = meta["received"]
                    self._save(meta)
                    self.complete(uid)
                    return
            except LargeFileError as exc:
                meta = self._load(uid)
                meta.update(status="failed", error=str(exc))
                self._save(meta)
                return
            except Exception as exc:  # mạng chập chờn → tải tiếp
                meta = self._load(uid)
                meta["error"] = f"Lần {attempt}: {exc}"
                self._save(meta)
                time.sleep(min(30, 2 * attempt))
        meta = self._load(uid)
        meta.update(status="failed", error=f"Hết {max_attempts} lần thử: {meta.get('error')}")
        self._save(meta)

    def list_recent(self, limit: int = 30) -> list[dict]:
        rows = []
        for meta_file in sorted(self.incoming.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
            try:
                rows.append(self._public(self._load(meta_file.stem)))
            except Exception:
                continue
        return rows


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(STREAM_BUFFER), b""):
            digest.update(block)
    return digest.hexdigest()


def _human(n: int) -> str:
    size = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.1f} {unit}" if unit != "B" else f"{int(size)} B"
        size /= 1024
    return f"{n} B"
