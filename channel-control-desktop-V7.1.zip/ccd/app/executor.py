"""Bộ thực thi lệnh tại chỗ của app (V3).

Ba loại lệnh app tự làm được mà không cần Muse:

- ``open_browser``: mở Chrome của hồ sơ (chrome_manager.launch).
- ``scan``:         quét kênh (scanner.scan_profile).
- ``check``:        kiểm tra sức khoẻ hồ sơ (checks.run_profile_checks).

Các loại còn lại (optimize / upload / free) KHÔNG đi qua đây — chúng nằm ở
trạng thái ``waiting_muse`` chờ Muse nhận qua Agent API.

Hàm ``execute_local_command`` nhận một Store đã mở trong ĐÚNG luồng đang
chạy (mỗi worker thread tự mở Store riêng tới cùng file DB, theo tiền lệ
của agent_server) và trả về (status, result_text).
"""

from __future__ import annotations

from . import checks as checks_module
from . import scanner
from .chrome_manager import ChromeManager
from .store import LOCAL_COMMAND_TYPES, Store


def execute_local_command(
    store: Store,
    command: dict,
    manager: ChromeManager,
    scan_fn=None,
    log=None,
) -> tuple[str, str]:
    """Thực thi một lệnh thuộc nhóm app-tự-làm-được.
    Trả về ('done'|'failed', đoạn text kết quả để lưu vào lệnh + nhật ký)."""
    say = log or (lambda msg: None)
    ctype = command.get("type")
    # V4.4: studio_script là lệnh CDP nhưng app-side — executor của UI
    # chạy được như nhóm local (agent_server cũng chạy cùng module
    # runner app/studio_script.py).
    if ctype not in LOCAL_COMMAND_TYPES and ctype != "studio_script":
        return "failed", f"Loại lệnh '{ctype}' không tự chạy tại app được (chờ Muse)."

    profile = None
    if command.get("profile_id"):
        profile = store.get_profile(command["profile_id"])
    elif command.get("profile_slug"):
        profile = store.get_profile_by_slug(command["profile_slug"])
    if profile is None:
        return "failed", "Không tìm thấy hồ sơ đích của lệnh."
    if profile.get("paused"):
        return "failed", f"Hồ sơ '{profile['label']}' đang tạm dừng."

    try:
        if ctype == "studio_script":
            return _execute_studio_script(store, command, profile, manager, say)

        if ctype == "open_browser":
            state = manager.launch(profile)
            text = (
                f"Chrome hồ sơ '{profile['label']}': "
                + ("đang chạy sẵn, dùng lại phiên." if state == "already_running" else "đã mở mới.")
            )
            say(text)
            return "done", text

        if ctype == "scan":
            run_scan = scan_fn or scanner.scan_profile
            result = run_scan(store, profile, manager, log=say)
            status = result.get("status", "error")
            message = result.get("message", "")
            if status == "ok":
                return "done", message
            return "failed", message or f"Quét kết thúc với trạng thái {status}."

        if ctype == "check":
            saved = checks_module.run_profile_checks(store, profile, manager)
            text = f"Kiểm tra hồ sơ '{profile['label']}': {saved['summary']}."
            say(text)
            return "done", text
    except Exception as exc:
        return "failed", f"Lỗi khi chạy lệnh {ctype}: {exc}"

    return "failed", f"Loại lệnh không xác định: {ctype}"


# Gợi ý mốc tiến độ theo nội dung dòng tiến độ của scanner/checks (V3.2) —
# chỉ tăng, không giảm, để thanh tiến độ trong app đi đều về trước.
_STAGE_HINTS = (
    ("quét xong", 90),
    ("account_menu", 60),
    ("menu tài khoản", 60),
    ("cookies", 45),
    ("đăng nhập", 40),
    ("đã mở", 25),
    ("chạy sẵn", 25),
)


def _progress_log(store: Store, command_id: str, log):
    """Bọc callback log: chuyển tiếp dòng tiến độ như cũ, đồng thời cập
    nhật step + mốc % của lệnh để người dùng theo dõi trong app."""
    say = log or (lambda msg: None)
    state = {"percent": 10}

    def wrapped(message: str):
        say(message)
        try:
            lowered = (message or "").lower()
            for marker, percent in _STAGE_HINTS:
                if marker in lowered:
                    state["percent"] = max(state["percent"], percent)
                    break
            store.update_command_progress(
                command_id, progress=state["percent"], step=str(message)[:160]
            )
        except Exception:
            pass  # tiến độ là phụ — không được làm hỏng việc chính

    return wrapped


def run_command_by_id(
    db_path,
    command_id: str,
    manager: ChromeManager,
    scan_fn=None,
    log=None,
) -> dict | None:
    """Nhận + chạy + chốt một lệnh theo id, dùng Store riêng của luồng gọi.
    Đây là điểm vào mà worker thread của UI dùng. Trả về lệnh sau khi chốt
    (None nếu lệnh không còn ở trạng thái queued để nhận)."""
    store = Store(db_path)
    try:
        if not store.claim_command(command_id):
            return None
        command = store.get_command(command_id)
        try:
            store.update_command_progress(command_id, progress=10, step="Đang khởi động…")
        except Exception:
            pass
        outcome = execute_local_command(
            store, command, manager, scan_fn=scan_fn, log=_progress_log(store, command_id, log)
        )
        status, text = outcome[0], outcome[1]
        # V4.4: một số lệnh (studio_script) trả thêm dict kết quả có
        # cấu trúc (trạng thái từng bước, giá trị đọc được, ảnh chụp)
        # → lưu vào result_json của lệnh.
        result_json = outcome[2] if len(outcome) > 2 else None
        if status == "done":
            store.finish_command(command_id, "done", result=text, result_json=result_json)
        elif status == "needs_user":
            store.set_command_needs_user(command_id, text)
        else:
            store.finish_command(
                command_id, "failed", result=text, error=text, result_json=result_json
            )
        store.append_journal(
            f"Lệnh #{command_id} ({command['type']}) — {status}: {text}",
            command.get("profile_id"),
        )
        return store.get_command(command_id)
    finally:
        store.close()


# --------------------------------------------------------------------------- #
# V4.4 — lệnh studio_script phía UI: chạy kịch bản trong Chrome nhúng
# của hồ sơ đích bằng runner dùng chung app/studio_script.py (cùng
# bản với đường Agent API trong agent_server._do_studio_script).
# Trả bộ ba (status, text, result_dict): status có thêm 'needs_user'
# khi kịch bản chạm tường đăng nhập/xác minh.
# --------------------------------------------------------------------------- #
def _execute_studio_script(store, command, profile, manager, say):
    from . import config as _config
    from . import studio_script as _ss

    payload = command.get("payload") or {}
    steps = payload.get("steps") or []
    errors = _ss.validate_steps(steps)
    if errors:
        return "failed", "Kịch bản Studio không hợp lệ: " + "; ".join(errors[:4])
    base = store.db_file.parent
    command_id = command["id"]

    def resolve_file(name):
        if not _ss.is_safe_file_ref(name):
            raise ValueError(f"Tên file không hợp lệ trong bước upload: {name!r}")
        path = _config.command_files_dir(command_id, base=base) / name
        if not path.is_file():
            raise FileNotFoundError(
                f"Chưa có file '{name}' được giao kèm lệnh này "
                "(gửi file qua cầu nối với X-Command-Id trước khi chạy)"
            )
        return path

    client_holder: dict = {}

    def save_screenshot(name):
        data = client_holder["client"].capture_screenshot_png()
        target = _config.screenshots_dir(base) / f"studio-{command_id[:8]}-{name}.png"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        return target.name

    def report_progress(percent, step_text):
        say(f"[Studio {percent}%] {step_text}")
        try:
            store.update_command_progress(
                command_id, progress=int(percent), step=str(step_text)[:160]
            )
        except Exception:
            pass  # tiến độ là phụ

    client = None
    try:
        if not manager.is_running(profile):
            manager.launch(profile)
        client = manager.connect_page(profile)
        client_holder["client"] = client
        result = _ss.run_studio_script(
            client,
            steps,
            resolve_file=resolve_file,
            save_screenshot=save_screenshot,
            progress=report_progress,
        )
    except _ss.StudioNeedsUser as exc:
        return "needs_user", str(exc), exc.result or {}
    except _ss.StudioStepError as exc:
        return "failed", str(exc), exc.result or {}
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
    summary = (
        f"Kịch bản Studio xong {result['completed_steps']}/{result['total_steps']} bước "
        f"trên hồ sơ '{profile['label']}'."
    )
    if result.get("reads"):
        summary += " Đọc được: " + ", ".join(
            f"{key}={str(value)[:60]}" for key, value in result["reads"].items()
        ) + "."
    if result.get("screenshots"):
        summary += " Ảnh: " + ", ".join(result["screenshots"]) + "."
    return "done", summary, result
