"""V7.0 — SỨC KHOẺ CSDL: tự phát hiện & tự sửa "database disk image is malformed".

Khi khởi động:
1. ``quick_check`` file SQLite (kèm WAL). Lành → thôi.
2. Hỏng → chuyển file hỏng (+ -wal/-shm) vào ``data/backups/corrupt-<giờ>/``
   (KHÔNG xoá gì), dựng CSDL mới đủ schema rồi:
   a. CỨU từng bảng từ file hỏng, đọc từng dòng (dòng nằm trên trang hỏng thì bỏ);
   b. bù phần còn thiếu từ bản sao lưu lành gần nhất (INSERT OR IGNORE).
3. Ghi báo cáo (số dòng cứu được theo bảng) để app hiện cho người dùng.

Trong lúc chạy: ``backup_now`` dùng API backup của SQLite (an toàn khi đang
ghi) — giữ ``KEEP`` bản gần nhất, gọi định kỳ từ cửa sổ chính.
"""

from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

KEEP = 6
BACKUP_DIRNAME = "backups"
SKIP_TABLES = {"sqlite_sequence", "sqlite_stat1", "sqlite_stat4"}


def _stamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def backups_dir(db_file: Path) -> Path:
    return Path(db_file).parent / BACKUP_DIRNAME


def quick_check(db_file: Path) -> str:
    """'ok' nếu lành; ngược lại là mô tả lỗi."""
    db_file = Path(db_file)
    if not db_file.exists():
        return "ok"
    try:
        conn = sqlite3.connect(str(db_file), timeout=10)
        try:
            row = conn.execute("PRAGMA quick_check").fetchone()
            result = str(row[0]) if row else "unknown"
            if result == "ok":
                # đọc thử vài bảng chính — quick_check đôi khi bỏ sót trang chỉ mục
                for (name,) in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall():
                    if name in SKIP_TABLES:
                        continue
                    conn.execute(f'SELECT COUNT(*) FROM "{name}"').fetchone()
            return result
        finally:
            conn.close()
    except sqlite3.DatabaseError as exc:
        return f"error: {exc}"


def backup_now(db_file: Path, keep: int = KEEP, tag: str = "auto") -> Path | None:
    """Sao lưu nóng (API backup của SQLite). Chỉ lưu khi bản gốc LÀNH."""
    db_file = Path(db_file)
    if not db_file.exists():
        return None
    folder = backups_dir(db_file)
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{db_file.stem}-{tag}-{_stamp()}.sqlite3"
    try:
        src = sqlite3.connect(str(db_file), timeout=30)
        try:
            if str(src.execute("PRAGMA quick_check").fetchone()[0]) != "ok":
                return None  # không đè bản lành bằng bản hỏng
            dst = sqlite3.connect(str(target))
            try:
                src.backup(dst)
            finally:
                dst.close()
        finally:
            src.close()
    except sqlite3.Error:
        try:
            target.unlink()
        except OSError:
            pass
        return None
    _prune(folder, db_file.stem, keep)
    return target


def _prune(folder: Path, stem: str, keep: int) -> None:
    files = sorted(folder.glob(f"{stem}-*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in files[keep:]:
        try:
            old.unlink()
        except OSError:
            pass


def latest_good_backup(db_file: Path) -> Path | None:
    folder = backups_dir(db_file)
    if not folder.exists():
        return None
    for path in sorted(folder.glob(f"{Path(db_file).stem}-*.sqlite3"), key=lambda p: p.stat().st_mtime, reverse=True):
        if quick_check(path) == "ok":
            return path
    return None


def _columns(conn: sqlite3.Connection, table: str) -> list[str]:
    return [row[1] for row in conn.execute(f'PRAGMA table_info("{table}")').fetchall()]


def _copy_rows(src: sqlite3.Connection, dst: sqlite3.Connection, table: str) -> tuple[int, int]:
    """Chép từng dòng; dòng lỗi bỏ qua. Trả (chép được, lỗi)."""
    try:
        src_cols = _columns(src, table)
    except sqlite3.DatabaseError:
        return 0, 1
    dst_cols = _columns(dst, table)
    cols = [c for c in src_cols if c in dst_cols]
    if not cols:
        return 0, 0
    names = ", ".join(f'"{c}"' for c in cols)
    marks = ", ".join("?" for _ in cols)
    ok = bad = 0
    try:
        cursor = src.execute(f'SELECT {names} FROM "{table}"')
    except sqlite3.DatabaseError:
        return 0, 1
    while True:
        try:
            row = cursor.fetchone()
        except sqlite3.DatabaseError:
            bad += 1
            break  # trang hỏng: phần còn lại của bảng không đọc được theo thứ tự này
        if row is None:
            break
        try:
            dst.execute(f'INSERT OR IGNORE INTO "{table}" ({names}) VALUES ({marks})', tuple(row))
            ok += 1
        except sqlite3.Error:
            bad += 1
    # quét theo DẢI rowid để vớt các dòng nằm ngoài trang hỏng
    if bad:
        insert = f'INSERT OR IGNORE INTO "{table}" ({names}) VALUES ({marks})'
        try:
            top = int(src.execute(f'SELECT max(rowid) FROM "{table}"').fetchone()[0] or 0)
        except (sqlite3.DatabaseError, TypeError):
            top = 0
        top = top or 200_000
        start = 1
        misses = 0
        while start <= top and misses < 400:
            end = start + 63
            try:
                rows = src.execute(f'SELECT {names} FROM "{table}" WHERE rowid BETWEEN ? AND ?',
                                   (start, end)).fetchall()
                misses = 0 if rows else misses + 1
                for row in rows:
                    try:
                        if dst.execute(insert, tuple(row)).rowcount:
                            ok += 1
                    except sqlite3.Error:
                        pass
            except sqlite3.DatabaseError:
                misses = 0
            start = end + 1
    # đọc ngược theo rowid để vớt thêm các dòng nằm SAU trang hỏng
    if bad:
        try:
            cursor = src.execute(f'SELECT {names} FROM "{table}" ORDER BY rowid DESC')
            while True:
                try:
                    row = cursor.fetchone()
                except sqlite3.DatabaseError:
                    break
                if row is None:
                    break
                try:
                    if dst.execute(f'INSERT OR IGNORE INTO "{table}" ({names}) VALUES ({marks})', tuple(row)).rowcount:
                        ok += 1
                except sqlite3.Error:
                    pass
        except sqlite3.DatabaseError:
            pass
    return ok, bad


def _tables(conn: sqlite3.Connection) -> list[str]:
    try:
        return [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
                if r[0] not in SKIP_TABLES]
    except sqlite3.DatabaseError:
        return []


def repair(db_file: Path) -> dict:
    """Dựng lại CSDL từ file hỏng + bản sao lưu lành gần nhất."""
    from .store import Store

    db_file = Path(db_file)
    quarantine = backups_dir(db_file) / f"corrupt-{_stamp()}"
    quarantine.mkdir(parents=True, exist_ok=True)
    moved = []
    for suffix in ("", "-wal", "-shm", "-journal"):
        path = Path(str(db_file) + suffix)
        if path.exists():
            shutil.move(str(path), str(quarantine / path.name))
            moved.append(path.name)
    broken = quarantine / db_file.name
    # dựng file mới đủ schema
    fresh = Store(db_file)
    fresh.close()
    report = {"quarantine": str(quarantine), "salvaged": {}, "from_backup": {}, "backup": None}
    dst = sqlite3.connect(str(db_file))
    try:
        dst.execute("PRAGMA foreign_keys = OFF")
        if broken.exists():
            try:
                src = sqlite3.connect(f"file:{broken}?mode=ro", uri=True)
                # WAL đã bị chuyển cùng thư mục với tên gốc → SQLite vẫn đọc được
                for table in _tables(src):
                    ok, _bad = _copy_rows(src, dst, table)
                    if ok:
                        report["salvaged"][table] = ok
                src.close()
            except sqlite3.Error:
                pass
        backup = latest_good_backup(db_file)
        if backup is not None:
            report["backup"] = backup.name
            src = sqlite3.connect(f"file:{backup}?mode=ro", uri=True)
            try:
                for table in _tables(src):
                    before = dst.total_changes
                    _copy_rows(src, dst, table)
                    added = dst.total_changes - before
                    if added:
                        report["from_backup"][table] = added
            finally:
                src.close()
        dst.commit()
    finally:
        dst.close()
    report["ok"] = quick_check(db_file) == "ok"
    return report


def ensure_healthy(db_file: Path) -> dict | None:
    """Gọi TRƯỚC khi mở Store. Trả báo cáo sửa chữa nếu đã phải sửa, None nếu lành."""
    status = quick_check(db_file)
    if status == "ok":
        return None
    report = repair(db_file)
    report["problem"] = status
    return report


def describe(report: dict) -> str:
    salvaged = sum(report.get("salvaged", {}).values())
    restored = sum(report.get("from_backup", {}).values())
    parts = [f"CSDL bị hỏng ({report.get('problem', '')[:80]}) — đã tự sửa:"]
    parts.append(f"cứu được {salvaged} dòng từ file hỏng")
    if report.get("backup"):
        parts.append(f"bù {restored} dòng từ bản sao lưu {report['backup']}")
    parts.append(f"file hỏng giữ nguyên ở {report.get('quarantine')}")
    return "; ".join(parts) + "."
