"""Log file của app (V3.1) — ghi xoay vòng dưới data/logs/.

Một file log chính ``ccd.log`` (tối đa ~1 MB × 5 bản) bắt mọi dòng qua
``logging`` của Python. Các module cũ vẫn ghi nhật ký nghiệp vụ vào DB
(bảng journal) như trước — file log này là lớp kỹ thuật bổ sung: lỗi
khởi động, lỗi CDP, ngoại lệ trong worker... để mục "Nhật ký" trong app
xem lại được (tail) khi cần gỡ rối trên máy người dùng.
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

from . import config

LOG_FILE_NAME = "ccd.log"
_LOGGER_NAME = "ccd"
_configured_for: Path | None = None


def log_file_path(base: Path | None = None) -> Path:
    return config.logs_dir(base) / LOG_FILE_NAME


def setup_logging(base: Path | None = None) -> logging.Logger:
    """Cấu hình logger gốc 'ccd' ghi vào data/logs/ccd.log (xoay vòng).
    Idempotent: gọi lại với cùng thư mục dữ liệu thì không thêm handler."""
    global _configured_for
    logger = logging.getLogger(_LOGGER_NAME)
    logger.setLevel(logging.DEBUG)
    target_dir = config.logs_dir(base)
    if _configured_for == target_dir:
        return logger
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
        path = target_dir / LOG_FILE_NAME
        for handler in list(logger.handlers):
            if isinstance(handler, RotatingFileHandler) and Path(
                handler.baseFilename
            ) == path:
                _configured_for = target_dir
                return logger
        handler = RotatingFileHandler(
            path, maxBytes=1_000_000, backupCount=5, encoding="utf-8"
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        )
        logger.addHandler(handler)
        _configured_for = target_dir
    except OSError:
        # Không ghi được log (đĩa đầy/thư mục khoá) — app vẫn phải chạy.
        pass
    return logger


def get_logger(name: str | None = None) -> logging.Logger:
    return logging.getLogger(f"{_LOGGER_NAME}.{name}" if name else _LOGGER_NAME)


def read_log_tail(base: Path | None = None, max_lines: int = 400) -> str:
    """Đọc phần cuối file log hiện tại (cho trình xem log trong app).
    Chưa có file → chuỗi rỗng."""
    path = log_file_path(base)
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""
    lines = text.splitlines()
    return "\n".join(lines[-max_lines:])
