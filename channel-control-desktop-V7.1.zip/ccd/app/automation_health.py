"""Sức khoẻ vòng tự động (V4.2 — O-06): lỗi của pipeline điều phối
KHÔNG còn được nuốt im lặng.

Trước V4.2, nhịp dispatcher/sweeper trong AgentServer bọc trong
``except Exception: pass``: API vẫn khoẻ, worker vẫn lặp, nhưng lệnh
có thể đứng yên vô thời hạn mà không nơi nào nói "vòng tự động đang
hỏng". Module này là bề mặt sự thật tối thiểu:

- ``record_error(store, source, exc)``: ghi log có cấu trúc (logger
  ``ccd.automation``) + lưu trạng thái degraded vào app_meta (nguồn
  lỗi, thông điệp rút gọn, thời điểm, số lần liên tiếp). UI đọc lại
  để hiện dòng cảnh báo trên thanh trạng thái.
- ``record_ok(store, source)``: nhịp chạy sạch → xoá trạng thái
  degraded (chỉ ghi DB khi đang degraded — nhịp lành 15 giây không
  được ghi đĩa vô ích).
- ``read_health(store)``: trạng thái hiện tại hoặc None.

Mọi hàm tự nuốt lỗi của chính mình: ghi nhận sức khoẻ không bao giờ
được phép làm hỏng pipeline nó đang canh.
"""

from __future__ import annotations

import json
import logging

from .store import now_iso

logger = logging.getLogger("ccd.automation")

_META_KEY = "automation_health"


def _load(store) -> dict | None:
    try:
        raw = store.get_meta(_META_KEY)
        if not raw:
            return None
        data = json.loads(raw)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def record_error(store, source: str, exc: BaseException | str) -> None:
    """Đánh dấu vòng tự động degraded vì ``source`` (dispatcher /
    sweeper / auto_assign / dispatch_now…) vừa lỗi. Ghi log có cấu
    trúc kèm loại lỗi; KHÔNG ghi giá trị nhạy cảm nào."""
    message = str(exc)[:300]
    logger.error(
        "automation degraded: source=%s error=%s: %s",
        source, type(exc).__name__ if isinstance(exc, BaseException) else "Error",
        message,
    )
    try:
        previous = _load(store) or {}
        same = (
            previous.get("degraded")
            and previous.get("source") == source
            and previous.get("error") == message
        )
        state = {
            "degraded": True,
            "source": source,
            "error": message,
            "at": now_iso(),
            "count": int(previous.get("count") or 0) + 1 if same else 1,
        }
        store.set_meta(_META_KEY, json.dumps(state, ensure_ascii=False))
    except Exception:
        logger.exception("không ghi được trạng thái automation_health")


def record_ok(store, source: str = "") -> None:
    """Nhịp chạy sạch: nếu đang degraded thì ghi nhận đã hồi phục
    (kèm nguồn vừa lỗi gần nhất để UI thôi cảnh báo); đang lành thì
    KHÔNG chạm DB."""
    try:
        previous = _load(store)
        if not previous or not previous.get("degraded"):
            return
        state = {
            "degraded": False,
            "source": previous.get("source") or source,
            "error": "",
            "at": now_iso(),
            "count": 0,
            "recovered_from": previous.get("error") or "",
        }
        store.set_meta(_META_KEY, json.dumps(state, ensure_ascii=False))
        logger.info("automation recovered: source=%s", state["source"])
    except Exception:
        logger.exception("không ghi được trạng thái automation_health")


def read_health(store) -> dict | None:
    """Trạng thái sức khoẻ vòng tự động hiện tại (None = chưa từng
    ghi nhận lỗi nào)."""
    return _load(store)
