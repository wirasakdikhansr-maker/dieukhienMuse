"""V6.3 — "MẮT" cho Muse khi thao tác trình duyệt hồ sơ từ xa.

Phân tích cơ chế cũ (vì sao Muse "không thực sự thao tác và giám sát
được" ở tab Hồ sơ):
1. MÙ: sau mỗi cdp_click/cdp_type app chỉ trả TÊN file ảnh chụp lưu trên
   PC — Muse chạy trên server của nó không mở được file đó, nên không
   biết trang đang hiện gì, bấm trúng/trượt.
2. TÌM PHẦN TỬ HẸP: cdp_click chỉ dò button/a/[role=button]; menu,
   tab, checkbox, ô chọn của YouTube Studio (tp-yt-paper-item,
   ytcp-*, [role=menuitem|tab|option|checkbox]) không bấm được.
3. MỖI THAO TÁC LÀ MỘT LỆNH: Muse gửi 1 thao tác → chờ hàng đợi → hỏi
   kết quả → thao tác tiếp; mỗi vòng tốn cả lượt suy nghĩ của Muse.
4. NGƯỜI DÙNG KHÔNG THẤY Muse đang làm gì trên trang.

Khắc phục ở module này:
- SNAPSHOT dạng chữ của trang (URL, tiêu đề, chữ hiển thị, DANH SÁCH
  PHẦN TỬ TƯƠNG TÁC có số thứ tự + selector ổn định + toạ độ) trả kèm
  MỌI thao tác CDP và qua lệnh mới ``cdp_snapshot`` → Muse "nhìn" được
  trang bằng chữ, bấm theo ``element`` (số thứ tự) chính xác.
- Ảnh chụp trả về được qua API: GET /api/screenshots/{tên} (base64).
- Bộ tìm phần tử rộng: selector / số thứ tự snapshot / aria-label /
  chữ hiển thị (khớp đúng trước, chứa sau) trên mọi vai trò tương tác.
- LỚP PHỦ GIÁM SÁT: mỗi thao tác vẽ vòng tròn + nhãn "🤖 Muse: bấm …"
  ngay trên trang 2 giây → nhìn khung nhúng là thấy Muse làm gì.
"""

from __future__ import annotations

import json

INTERACTIVE = (
    "a[href], button, input, textarea, select, [role=button], [role=link], [role=menuitem],"
    " [role=tab], [role=option], [role=checkbox], [role=radio], [role=switch], [role=combobox],"
    " [role=textbox], [contenteditable=true], [tabindex]:not([tabindex='-1']), tp-yt-paper-item,"
    " ytcp-button, ytcp-icon-button, label"
)

SNAPSHOT_JS = r"""/*ccd:snapshot*/(() => {
  const SEL = %(sel)s, MAX = %(max)d;
  const vis = el => { const r = el.getBoundingClientRect(); if (r.width < 2 || r.height < 2) return false;
    const st = getComputedStyle(el); return st.visibility !== 'hidden' && st.display !== 'none'; };
  const path = el => {
    if (el.id && document.querySelectorAll('#' + CSS.escape(el.id)).length === 1) return '#' + CSS.escape(el.id);
    const parts = []; let node = el;
    while (node && node.nodeType === 1 && parts.length < 6) {
      let part = node.tagName.toLowerCase();
      if (node.id && document.querySelectorAll('#' + CSS.escape(node.id)).length === 1) { parts.unshift('#' + CSS.escape(node.id)); break; }
      const sib = node.parentElement ? [...node.parentElement.children].filter(c => c.tagName === node.tagName) : [];
      if (sib.length > 1) part += ':nth-of-type(' + (sib.indexOf(node) + 1) + ')';
      parts.unshift(part); node = node.parentElement;
    }
    return parts.join(' > ');
  };
  const label = el => (el.getAttribute('aria-label') || el.innerText || el.value || el.placeholder ||
    el.title || el.getAttribute('name') || '').replace(/\s+/g, ' ').trim().slice(0, 90);
  const els = [...document.querySelectorAll(SEL)].filter(vis);
  const seen = new Set(); const items = [];
  for (const el of els) {
    if (seen.has(el)) continue; seen.add(el);
    const r = el.getBoundingClientRect();
    const inView = r.bottom > 0 && r.right > 0 && r.top < innerHeight && r.left < innerWidth;
    items.push({ i: items.length, tag: el.tagName.toLowerCase(), role: el.getAttribute('role') || '',
      type: el.type || '', text: label(el), selector: path(el), in_view: inView,
      checked: el.checked === true || el.getAttribute('aria-checked') === 'true',
      disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true',
      x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
      w: Math.round(r.width), h: Math.round(r.height) });
    if (items.length >= MAX) break;
  }
  const text = (document.body ? document.body.innerText : '').replace(/\n{3,}/g, '\n\n').slice(0, 3500);
  const dialogs = [...document.querySelectorAll('[role=dialog], [role=alertdialog], tp-yt-paper-dialog')]
    .filter(vis).map(d => (d.innerText || '').replace(/\s+/g, ' ').slice(0, 300));
  return { url: location.href, title: document.title, viewport: [innerWidth, innerHeight],
           scroll_y: Math.round(scrollY), text, dialogs, elements: items };
})()"""

FIND_JS = r"""/*ccd:find*/(() => {
  const selector = %(selector)s, wanted = %(text)s, index = %(index)s, SEL = %(sel)s;
  const vis = el => { const r = el.getBoundingClientRect(); return r.width > 1 && r.height > 1; };
  let el = null;
  if (selector) { try { el = document.querySelector(selector); } catch (e) { el = null; } }
  if (!el && index !== null) {
    const els = [...document.querySelectorAll(SEL)].filter(vis);
    const uniq = [...new Set(els)];
    el = uniq[index] || null;
  }
  if (!el && wanted) {
    const needle = wanted.trim().toLowerCase();
    const cands = [...document.querySelectorAll(SEL)].filter(vis);
    const lab = n => (n.getAttribute('aria-label') || n.innerText || n.value || n.placeholder || n.title || '')
      .replace(/\s+/g, ' ').trim().toLowerCase();
    el = cands.find(n => lab(n) === needle) || cands.find(n => lab(n).includes(needle)) || null;
  }
  if (!el) return null;
  el.scrollIntoView({block: 'center', inline: 'center'});
  const r = el.getBoundingClientRect();
  return { tag: el.tagName, text: (el.getAttribute('aria-label') || el.innerText || el.value || '').trim().slice(0, 80),
           x: r.left + r.width / 2, y: r.top + r.height / 2, visible: r.width > 0 && r.height > 0 };
})()"""

OVERLAY_JS = r"""/*ccd:overlay*/(() => {
  const x = %(x)s, y = %(y)s, msg = %(msg)s;
  const host = document.createElement('div');
  host.setAttribute('data-ccd-overlay', '1');
  host.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483647';
  if (x !== null) {
    const dot = document.createElement('div');
    dot.style.cssText = `position:fixed;left:${x - 18}px;top:${y - 18}px;width:36px;height:36px;border-radius:50%%;` +
      'border:3px solid #3ECF6A;box-shadow:0 0 0 6px rgba(62,207,106,.25);transition:all .9s ease-out';
    host.appendChild(dot);
    setTimeout(() => { dot.style.transform = 'scale(1.8)'; dot.style.opacity = '0'; }, 50);
  }
  const tag = document.createElement('div');
  tag.textContent = msg;
  tag.style.cssText = 'position:fixed;left:12px;bottom:12px;background:rgba(15,17,16,.92);color:#e6e8e3;' +
    'font:600 13px Segoe UI,Arial;padding:8px 12px;border-radius:10px;border:1px solid #3ECF6A;max-width:60vw';
  host.appendChild(tag);
  document.documentElement.appendChild(host);
  setTimeout(() => host.remove(), 2200);
  return true;
})()"""


def snapshot(client, max_elements: int = 150) -> dict:
    value = client.evaluate(SNAPSHOT_JS % {"sel": json.dumps(INTERACTIVE), "max": int(max_elements)})
    return value if isinstance(value, dict) else {}


def find(client, payload: dict) -> dict | None:
    index = payload.get("element")
    try:
        index = int(index) if index is not None and str(index) != "" else None
    except (TypeError, ValueError):
        index = None
    value = client.evaluate(FIND_JS % {
        "selector": json.dumps(str(payload.get("selector") or "")),
        "text": json.dumps(str(payload.get("text") or payload.get("label") or "")),
        "index": "null" if index is None else str(index),
        "sel": json.dumps(INTERACTIVE),
    })
    return value if isinstance(value, dict) else None


def overlay(client, message: str, x: float | None = None, y: float | None = None) -> None:
    try:
        client.evaluate(OVERLAY_JS % {
            "x": "null" if x is None else str(float(x)),
            "y": "null" if y is None else str(float(y)),
            "msg": json.dumps(message[:160]),
        })
    except Exception:
        pass


def compact(snap: dict, max_elements: int = 80) -> dict:
    """Bản rút gọn để gửi kèm kết quả lệnh (giữ dung lượng vừa phải)."""
    if not snap:
        return {}
    elements = [e for e in snap.get("elements") or [] if e.get("in_view")][:max_elements]
    return {
        "url": snap.get("url"), "title": snap.get("title"),
        "dialogs": snap.get("dialogs") or [],
        "text": (snap.get("text") or "")[:1500],
        "elements": elements,
        "elements_total": len(snap.get("elements") or []),
    }
