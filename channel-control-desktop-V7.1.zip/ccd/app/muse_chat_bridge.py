"""V6.4.3 — CHAT TRỰC TIẾP với Muse qua chính trang muse.ai (cầu nối trình duyệt).

VÌ SAO: Muse chạy trên máy ảo trong cloud của Meta, không gọi được về
máy của bạn (localhost/Tailscale là mạng riêng) và chỉ dùng dịch vụ
ngoài qua Custom Connector mà người dùng phải tự tạo. → Cách "phiếu kết
nối + Agent API" không tự chạy được.

CÁCH MỚI (không cần tạo gì thêm): app đã có Chrome RIÊNG của từng tài
khoản Muse, đã đăng nhập muse.ai. Khi bạn gửi tin trong app:
  1. app gõ NGUYÊN VĂN tin vào ô chat muse.ai rồi bấm gửi (CDP),
  2. app đọc câu trả lời của Muse ngay trên trang, ~4 lần/giây, và
     ghi dần vào luồng chat trong app (chữ hiện ra dần như trên web),
  3. Muse trả lời xong (hết nút "Dừng", chữ đứng yên) → chốt tin.
Tốc độ = tốc độ của chính muse.ai. Chưa đăng nhập → app tự đăng nhập
lại (tinyhost) rồi gửi tiếp.

Việc giao cho Muse (lệnh trong bảng Công việc) đi cùng đường này:
app gõ nội dung việc + các bước vào chat, câu trả lời của Muse được
ghi thành bước và kết quả của lệnh.
"""

from __future__ import annotations

import json
import queue
import re
import threading
import time

from . import agent_browser, cdp

# --------------------------------------------------------------------------- #
# JS chạy trong trang muse.ai
# --------------------------------------------------------------------------- #
COMPOSER_JS = r"""/*ccd:bridge-composer*/(() => {
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0; };
  const cands = [...document.querySelectorAll(
    'textarea, [contenteditable="true"], [role="textbox"], [data-testid="chat-input"]')].filter(visible);
  const el = cands[cands.length - 1];
  if (!el) return false;
  document.querySelectorAll('[data-ccd-push]').forEach(x => x.removeAttribute('data-ccd-push'));
  el.setAttribute('data-ccd-push', '1');
  el.focus();
  if (el.isContentEditable) {
    const range = document.createRange(); range.selectNodeContents(el);
    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
  } else if (el.select) { el.select(); }
  return true;
})()"""

# Chụp "nền" chữ của trang TRƯỚC khi gửi: chữ có sẵn (chân trang, gợi ý,
# thanh bên) không bao giờ bị coi là câu trả lời mới.
BASELINE_JS = r"""/*ccd:bridge-base*/(() => {
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  window.__ccdBase = new Set((document.body.innerText || '').split('\n').map(norm).filter(Boolean));
  return window.__ccdBase.size;
})()"""

COMPOSER_LEFT_JS = (
    "(() => { const el = document.querySelector('[data-ccd-push]');"
    " return el ? (el.value || el.innerText || '').trim().length : 0; })()"
)

SEND_JS = r"""/*ccd:bridge-send*/(() => {
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0; };
  const btn = [...document.querySelectorAll('button, [role="button"]')].filter(visible).find(b =>
    /send|gửi|submit/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')));
  if (btn && !btn.disabled) { btn.click(); return 'button'; }
  return 'none';
})()"""

# Đọc câu trả lời SAU tin của mình. Hai tầng:
#  (1) trang có đánh dấu vai trò ([data-message-author-role], data-role…)
#      → lấy các lượt 'assistant' sau lượt 'user' khớp tin vừa gửi;
#  (2) không có → tìm bong bóng chứa tin vừa gửi, leo lên tới "hàng"
#      trong danh sách tin, đọc chữ của các hàng phía sau (bỏ nút/biểu
#      tượng/ô soạn tin).
# busy = đang sinh chữ (có nút Dừng/Stop hoặc aria-busy).
READ_JS = r"""/*ccd:bridge-read*/((needle, sent) => {
  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  // V6.7: bỏ mọi dòng thuộc CHÍNH tin app vừa gửi (bản cũ đọc nhầm phần
  // hướng dẫn ```ccd``` trong tin gửi đi thành câu trả lời của Muse).
  const own = new Set((sent || []).map(norm).filter(l => l.length >= 8));
  const strip = t => (t || '').split('\n').filter(l => !own.has(norm(l))).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  const visible = el => { if (!el) return false; const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0; };
  const busy = [...document.querySelectorAll('button, [role="button"]')].filter(visible).some(b =>
      /stop|dừng|cancel|hủy tạo|stop generating/i.test((b.getAttribute('aria-label') || '') + ' ' + (b.innerText || '')))
    || !!document.querySelector('[aria-busy="true"]');
  const clean = el => {
    const c = el.cloneNode(true);
    c.querySelectorAll('button,[role="button"],svg,textarea,[contenteditable="true"],style,script,[aria-hidden="true"]')
      .forEach(x => x.remove());
    return (c.innerText || c.textContent || '').replace(/\n{3,}/g, '\n\n').trim();
  };
  const key = norm(needle).slice(0, 80);
  // Tầng 1
  const roleEls = [...document.querySelectorAll('[data-message-author-role],[data-role],[data-author]')];
  const roleOf = el => (el.getAttribute('data-message-author-role') || el.getAttribute('data-role')
    || el.getAttribute('data-author') || '').toLowerCase();
  if (roleEls.some(e => /assistant|bot|ai|model/.test(roleOf(e)))) {
    let idx = -1;
    roleEls.forEach((e, i) => { if (/user|human|me/.test(roleOf(e)) && norm(e.innerText).includes(key)) idx = i; });
    if (idx >= 0) {
      const parts = roleEls.slice(idx + 1).filter(e => /assistant|bot|ai|model/.test(roleOf(e))).map(clean).filter(Boolean);
      return {found: true, mode: 'role', text: strip(parts.join('\n\n')), busy};
    }
  }
  // Tầng 2
  if (!key) return {found: false, text: '', busy};
  const all = [...document.querySelectorAll('body *')].filter(el =>
    !el.closest('[data-ccd-push]') && el.children.length < 40 && norm(el.innerText).includes(key));
  let bubble = null;
  for (const el of all) {               // phần tử NHỎ NHẤT, cuối cùng chứa tin
    if (![...el.children].some(ch => norm(ch.innerText).includes(key))) bubble = el;
  }
  if (!bubble) return {found: false, text: '', busy};
  let row = bubble;
  for (let depth = 0; depth < 12 && row.parentElement; depth++) {
    const sibs = [];
    let n = row.nextElementSibling;
    const base = window.__ccdBase || new Set();
    const fresh = el => (el.innerText || '').split('\n').map(norm).filter(Boolean).some(l => !base.has(l));
    while (n) { if (!n.querySelector('textarea,[contenteditable="true"]') && !n.matches('textarea,[contenteditable="true"]') && fresh(n)) sibs.push(n); n = n.nextElementSibling; }
    const text = strip(sibs.map(clean).filter(Boolean).join('\n\n'));
    if (text) return {found: true, mode: 'diff', text, busy};
    row = row.parentElement;
    if (row === document.body) break;
  }
  return {found: true, mode: 'diff', text: '', busy};
})"""


def read_expr(needle: str, sent_text: str = "") -> str:
    lines = [l for l in (sent_text or "").splitlines() if l.strip()]
    return READ_JS + "(" + json.dumps(needle or "") + "," + json.dumps(lines, ensure_ascii=False) + ")"


def pick_needle(text: str) -> str:
    """Dòng để định vị tin vừa gửi trên trang: dòng CUỐI có nghĩa (≥ 8 ký tự).
    Dùng dòng cuối → phần tử khớp là đuôi tin của mình, câu trả lời nằm ngay sau."""
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    for line in reversed(lines):
        if len(line) >= 8 and not line.startswith(("```", "{")):
            return line
    return lines[-1] if lines else ""


# --------------------------------------------------------------------------- #
# Ghép trạng thái chờ trả lời (thuần, test được)
# --------------------------------------------------------------------------- #
class ReplyTracker:
    """Quyết định khi nào câu trả lời đã XONG: không còn 'busy' và chữ
    đứng yên ≥ ``settle_s`` giây; chưa có chữ mà quá ``first_token_s``
    giây (và không busy) → coi là không có trả lời."""

    def __init__(self, settle_s: float = 1.6, first_token_s: float = 120.0,
                 max_s: float = 1800.0, clock=time.monotonic):
        self.clock = clock
        self.settle_s = settle_s
        self.first_token_s = first_token_s
        self.max_s = max_s
        self.start = clock()
        self.text = ""
        self.changed_at = self.start

    def feed(self, sample: dict) -> tuple[str, bool, bool]:
        """→ (text, changed, done)."""
        now = self.clock()
        text = (sample or {}).get("text") or ""
        busy = bool((sample or {}).get("busy"))
        changed = text != self.text
        if changed:
            self.text = text
            self.changed_at = now
        if now - self.start > self.max_s:
            return self.text, changed, True
        if busy:
            return self.text, changed, False
        if self.text:
            return self.text, changed, (now - self.changed_at) >= self.settle_s
        return self.text, changed, (now - self.start) >= self.first_token_s


# --------------------------------------------------------------------------- #
# Phiên CDP tới tab muse.ai của MỘT tài khoản
# --------------------------------------------------------------------------- #
def _muse_page(port: int) -> dict | None:
    try:
        targets = cdp.http_json(port, "/json/list")
    except Exception:
        return None
    for target in targets:
        if target.get("type") == "page" and "muse.ai" in (target.get("url") or "") \
                and target.get("webSocketDebuggerUrl"):
            return target
    return None


# V7.0: Chrome của cầu nối chat chạy KHÔNG CỬA SỔ (headless) — không còn
# khung chữ nhật trắng nổi trên app/desktop, không chiếm taskbar. Đăng nhập
# muse.ai (cần người thao tác) tự mở lại bản có cửa sổ. Tắt ở Cài đặt.
HEADLESS = True


def _launch_hidden(manager, pseudo: dict) -> None:
    """V6.5.2: mở Chrome muse.ai CHẠY NỀN, không bật lên giao diện.
    Manager cũ/giả không có tham số hidden/headless → lùi dần."""
    try:
        manager.launch(pseudo, hidden=True, headless=bool(HEADLESS))
        return
    except TypeError:
        pass
    try:
        manager.launch(pseudo, hidden=True)
    except TypeError:
        manager.launch(pseudo, start_minimized=True)


def login_state(client) -> str:
    """'in' / 'out' / 'unknown' — dò trạng thái đăng nhập muse.ai trên trang."""
    try:
        return agent_browser.classify_muse_state(client.evaluate(agent_browser.MUSE_STATE_JS, timeout=10))
    except Exception:
        return "unknown"


def open_muse_client(manager, agent: dict, sleep=time.sleep, client_factory=None):
    """Bảo đảm Chrome của tài khoản đang chạy + có tab muse.ai; trả
    CDPClient tới tab đó."""
    pseudo = agent_browser.agent_profile(agent)
    port = pseudo["port"]
    try:
        running = manager.is_running(pseudo)
    except Exception:
        running = False
    if not running:
        _launch_hidden(manager, pseudo)
        for _ in range(20):
            sleep(0.5)
            if cdp.debug_port_open(port):
                break
    target = _muse_page(port)
    if target is None:
        try:
            target = cdp.http_json(port, "/json/new?" + agent_browser.MUSE_URL, method="PUT")
        except Exception:
            target = cdp.http_json(port, "/json/new?" + agent_browser.MUSE_URL)
        sleep(3.0)
    factory = client_factory or (lambda ws: cdp.CDPClient(ws))
    return factory(target["webSocketDebuggerUrl"])


def wait_composer(client, seconds: float, sleep=time.sleep) -> bool:
    for attempt in range(max(1, int(seconds / 0.5))):
        try:
            if client.evaluate(COMPOSER_JS):
                return True
        except Exception:
            pass
        sleep(0.5)
    return False


def type_and_send(client, text: str, sleep=time.sleep) -> str:
    try:
        client.evaluate(BASELINE_JS)
    except Exception:
        pass
    client.call("Input.insertText", {"text": text})
    sleep(0.15)
    client.press_key("Enter")
    sleep(0.5)
    if client.evaluate(COMPOSER_LEFT_JS):
        return client.evaluate(SEND_JS) or "none"
    return "enter"


def stream_reply(client, needle: str, on_update, tracker: ReplyTracker | None = None, sent_text: str = "",
                 interval: float = 0.25, sleep=time.sleep) -> str:
    """Đọc câu trả lời ~4 lần/giây, gọi on_update(text, done) mỗi lần đổi."""
    tracker = tracker or ReplyTracker()
    while True:
        try:
            sample = client.evaluate(read_expr(needle, sent_text)) or {}
        except Exception:
            sample = {"text": tracker.text, "busy": True}
        text, changed, done = tracker.feed(sample)
        if changed or done:
            on_update(text, done)
        if done:
            return text
        sleep(interval)


# --------------------------------------------------------------------------- #
# Hàng đợi nền: mỗi tài khoản một luồng, giữ thứ tự tin
# --------------------------------------------------------------------------- #
class ChatBridge:
    """Mọi việc chạm CDP chạy ở luồng nền. Mọi việc chạm KHO (sqlite)
    đi qua ``emit(event: dict)`` — cửa sổ chính nhận ở luồng giao diện.

    Sự kiện:
      {'kind': 'reply', 'agent_id', 'job_id', 'text', 'done', 'command_id'}
      {'kind': 'sent',  'agent_id', 'job_id', 'command_id'}
      {'kind': 'login', 'agent_id'}                 → cần tự đăng nhập lại
      {'kind': 'error', 'agent_id', 'job_id', 'reason', 'command_id'}
    """

    LOGIN_WAIT_S = 180.0

    def __init__(self, manager, emit, sleep=time.sleep, client_factory=None):
        self.manager = manager
        self.emit = emit
        self.sleep = sleep
        self.client_factory = client_factory
        self._queues: dict[int, queue.Queue] = {}
        self._lock = threading.Lock()
        self._seq = 0
        self.busy: set[int] = set()
        # V6.5.2: cửa sổ muse.ai đang HIỆN trên màn hình (do bản cũ / đăng
        # nhập tay mở ra) → đẩy ra ngoài màn hình một lần, khi UI cho phép.
        self.may_hide = lambda agent_id: True
        self._hidden_once: set[int] = set()
        # V6.7: trình duyệt muse.ai CHỈ chạy khi cần — nhớ lần dùng cuối của
        # từng tài khoản, tự tắt khi rảnh lâu, giới hạn số trình duyệt mở cùng lúc.
        self.last_used: dict[int, float] = {}
        self._pseudo: dict[int, dict] = {}
        self.max_browsers = 6

    def _close_browser(self, agent_id: int) -> bool:
        pseudo = self._pseudo.get(int(agent_id))
        if pseudo is None:
            return False
        try:
            if not cdp.debug_port_open(int(pseudo["port"]), timeout=0.3):
                return False
            cdp.browser_call(int(pseudo["port"]), "Browser.close", timeout=5)
            self._hidden_once.discard(int(agent_id))
            return True
        except Exception:
            return False

    def _enforce_cap(self, keep_id: int) -> list[int]:
        """Đang mở quá max_browsers trình duyệt muse.ai → tắt cái lâu chưa dùng nhất."""
        closed = []
        candidates = sorted(
            (t, aid) for aid, t in self.last_used.items()
            if aid != keep_id and aid not in self.busy and self.pending(aid) == 0
            and self._pseudo.get(aid) and cdp.debug_port_open(int(self._pseudo[aid]["port"]), timeout=0.2))
        while len(candidates) + 1 > max(1, int(self.max_browsers)) and candidates:
            _t, aid = candidates.pop(0)
            if self._close_browser(aid):
                closed.append(aid)
        return closed

    def close_idle(self, minutes: float) -> list[int]:
        """Tắt trình duyệt muse.ai rảnh quá ``minutes`` phút (phiên đăng nhập vẫn giữ)."""
        if minutes <= 0:
            return []
        now = time.monotonic()
        closed = []
        for aid, t in list(self.last_used.items()):
            if aid in self.busy or self.pending(aid) or now - t < minutes * 60:
                continue
            if self._close_browser(aid):
                closed.append(aid)
                self.last_used.pop(aid, None)
        return closed

    def send(self, agent: dict, text: str, command_id: str | None = None) -> int:
        with self._lock:
            self._seq += 1
            job_id = self._seq
            agent_id = int(agent["id"])
            q = self._queues.get(agent_id)
            if q is None:
                q = self._queues[agent_id] = queue.Queue()
                threading.Thread(target=self._worker, args=(agent_id, q), daemon=True,
                                 name=f"muse-chat-{agent_id}").start()
        q.put({"job_id": job_id, "agent": dict(agent), "text": text, "command_id": command_id})
        return job_id

    def pending(self, agent_id: int) -> int:
        q = self._queues.get(int(agent_id))
        return (q.qsize() if q else 0) + (1 if int(agent_id) in self.busy else 0)

    def _worker(self, agent_id: int, q: queue.Queue):
        while True:
            job = q.get()
            self.busy.add(agent_id)
            try:
                self._run(job)
            except Exception as exc:  # noqa: BLE001
                self.emit({"kind": "error", "agent_id": agent_id, "job_id": job["job_id"],
                           "command_id": job.get("command_id"),
                           "reason": f"{type(exc).__name__}: {exc}"})
            finally:
                self.busy.discard(agent_id)
                self.last_used[agent_id] = time.monotonic()

    def _run(self, job: dict):
        agent = job["agent"]
        agent_id = int(agent["id"])
        base = {"agent_id": agent_id, "job_id": job["job_id"], "command_id": job.get("command_id")}
        self._pseudo[agent_id] = agent_browser.agent_profile(agent)
        self.last_used[agent_id] = time.monotonic()
        try:
            self._enforce_cap(agent_id)
        except Exception:
            pass
        client = open_muse_client(self.manager, agent, sleep=self.sleep, client_factory=self.client_factory)
        if agent_id not in self._hidden_once and hasattr(self.manager, "hide_window"):
            try:
                if self.may_hide(agent_id):
                    self.manager.hide_window(agent_browser.agent_profile(agent))
                    self._hidden_once.add(agent_id)
            except Exception:
                pass
        try:
            state = "in"
            if not wait_composer(client, 12.0, sleep=self.sleep):
                # V6.5.2: KHÔNG thấy ô chat chưa chắc là văng đăng nhập (trang
                # chưa tải xong / giao diện muse.ai khác). Chỉ khi trang báo
                # rõ là CHƯA đăng nhập mới nhờ UI đăng nhập lại — bản cũ coi
                # mọi lần thiếu ô chat là văng → mở trình duyệt đăng nhập liên tục.
                state = login_state(client)
                if state != "out":
                    try:
                        client.call("Page.reload", {})
                    except Exception:
                        pass
                    if not wait_composer(client, 20.0, sleep=self.sleep):
                        self.emit(dict(base, kind="error",
                                       reason="Không thấy ô chat trên muse.ai (trang chưa sẵn sàng) — "
                                              "sẽ thử lại ở lần gửi sau, KHÔNG đăng nhập lại."))
                        return
                    state = "in"
            if state == "out":
                # phiên văng thật → nhờ UI tự đăng nhập lại (chạy nền), chờ ô chat
                self.emit({"kind": "login", "agent_id": agent_id})
                try:
                    client.close()
                except Exception:
                    pass
                client = None
                for _ in range(int(self.LOGIN_WAIT_S / 4.0)):
                    self.sleep(4.0)
                    try:
                        client = open_muse_client(self.manager, agent, sleep=self.sleep,
                                                  client_factory=self.client_factory)
                        if wait_composer(client, 2.0, sleep=self.sleep):
                            break
                        client.close()
                    except Exception:
                        pass
                    client = None
                if client is None:
                    self.emit(dict(base, kind="error",
                                   reason="muse.ai chưa đăng nhập (đã thử tự đăng nhập lại 3 phút)"))
                    return
            via = type_and_send(client, job["text"], sleep=self.sleep)
            if via == "none":
                self.emit(dict(base, kind="error", reason="Không bấm được nút gửi trên muse.ai"))
                return
            self.emit(dict(base, kind="sent", text_head=job["text"][:40]))
            needle = pick_needle(job["text"])
            last_emit = [0.0, ""]

            def on_update(text, done):
                now = time.monotonic()
                # gộp nhịp ghi: ≤ 3 lần/giây khi đang chảy chữ
                if not done and now - last_emit[0] < 0.3:
                    return
                last_emit[0] = now
                last_emit[1] = text
                self.emit(dict(base, kind="reply", text=text, done=done))

            final = stream_reply(client, needle, on_update, sent_text=job["text"], sleep=self.sleep)
            if last_emit[1] != final:
                self.emit(dict(base, kind="reply", text=final, done=True))
        finally:
            if client is not None:
                try:
                    client.close()
                except Exception:
                    pass


def task_text(command: dict, channel: str = "", steps_text: str = "", agent_name: str = "",
              context: str = "") -> str:
    """Nội dung gõ vào chat khi TRƯỞNG PHÒNG GIAO VIỆC cho Muse qua muse.ai.
    V6.6: dạng hội thoại hai chiều — hỏi "nhận được chưa?" và yêu cầu Muse
    mở đầu câu trả lời bằng ĐÃ NHẬN việc #id để app biết chắc đã nhận."""
    payload = command.get("payload") or {}
    title = payload.get("title") or command_title_short(command)
    who = f"{agent_name} ơi, " if agent_name else ""
    lines = [f"[Trưởng phòng] {who}giao việc #{command.get('id')}: {title}"]
    note = command.get("instruction") or payload.get("note") or payload.get("prompt") or ""
    if note and note.strip() != title:
        lines.append(str(note).strip())
    if channel:
        lines.append(f"Kênh: {channel}")
    if context:
        lines.append(context)  # V7.0: nền tảng Facebook/TikTok — đúng site, đúng page
    if steps_text:
        lines.append("Các bước: " + steps_text.strip())
    lines.append(f"Nhận được việc chưa? Trả lời NGAY, mở đầu bằng: ĐÃ NHẬN việc #{command.get('id')} — <bước đầu tiên bạn làm>.")
    lines.append("Trong lúc làm: TIẾN ĐỘ: <số>% — <bước> kèm SỐ ĐẾM cụ thể nếu có (vd: TIẾN ĐỘ: 60% — Tạo video: cảnh 20/30). "
                 "Xong: KẾT QUẢ: … Lỗi/kẹt: LỖI: <lý do> (tự xử lý trước, "
                 "chỉ khi bắt buộc cần chủ kênh mới: CẦN BẠN: …).")
    lines.append("Phân vân (đăng luôn hay nháp, chủ đề, số lượng, định dạng…): TỰ QUYẾT phương án hợp lý nhất và ghi rõ "
                 "trong báo cáo — trưởng phòng đã giao toàn quyền, không cần hỏi chủ kênh.")
    from .muse_control import GUIDE

    lines.append(GUIDE)
    return "\n".join(lines)


def command_title_short(command: dict) -> str:
    text = (command.get("instruction") or "").strip()
    first = text.splitlines()[0] if text else ""
    return (first or command.get("type") or "Công việc")[:120]


_ACK = re.compile(r"(Đ|D)(Ã|A)\s*NH(Ậ|A)N", re.I)


def is_ack(text: str) -> bool:
    """Muse xác nhận đã nhận việc ("ĐÃ NHẬN việc #12 …")."""
    head = (text or "").strip()[:160]
    return bool(_ACK.search(head))


_PROGRESS = re.compile(r"TI[ẾE]N\s*[ĐD][ỘO]\s*[:：]\s*(\d{1,3})\s*%\s*[—–-]?\s*(.*)", re.I)


def parse_progress(text: str) -> tuple[int | None, str]:
    """Đọc dòng "TIẾN ĐỘ: 40% — bước vừa xong — bước tiếp" (dòng CUỐI cùng
    khớp mẫu) → (40, "bước vừa xong — bước tiếp")."""
    found = None
    for line in (text or "").splitlines():
        match = _PROGRESS.search(line)
        if match:
            found = match
    if not found:
        return None, ""
    return max(0, min(99, int(found.group(1)))), found.group(2).strip()[:200]


_MISSING = re.compile(
    r"(ch[ưu]a (nh[ậa]n|c[óo]) (đ[ưu][ợo]c )?n[ộo]i dung|ch[ỉi] c[óo] m[ãa]|kh[ôo]ng c[óo] n[ộo]i dung|"
    r"kh[ôo]ng (t[ìi]m|th[ấa]y).{0,30}(l[ệe]nh|vi[ệe]c)|m[ãa] n[àa]y kh[ôo]ng c[óo]|ch[ưu]a c[óo] n[ộo]i dung)", re.I)


def says_missing_task(text: str) -> bool:
    """Muse báo KHÔNG có nội dung việc (chỉ thấy mã) → app phải gửi lại trọn việc."""
    return bool(_MISSING.search(text or ""))


_DONE = re.compile(r"^\s*(k[ếe]t\s*qu[ảa]|result)[^\n:]{0,40}[:：]", re.I | re.M)
_ERR = re.compile(r"^\s*(l[ỗo]i|error)[^\n:]{0,40}[:：]", re.I | re.M)


def classify_reply(text: str) -> str:
    """'done' khi có "KẾT QUẢ:" (cho phép "KẾT QUẢ #id:"); 'needs_user' khi
    báo LỖI:/CẦN BẠN/mã xác minh; 'ack' khi mở đầu bằng ĐÃ NHẬN; còn lại 'running'."""
    low = (text or "").lower()
    if _DONE.search(text or ""):
        return "done"
    if _ERR.search((text or "")[:300]) or any(
            k in low for k in ("cần bạn", "can ban:", "captcha", "mã xác minh", "2fa", "need you")):
        return "needs_user"
    if is_ack(text):
        return "ack"
    return "running"
