"""V6.5 — dữ liệu cho tab Công việc (Kanban) và tab Báo cáo (bảng điều khiển).

Thuần dữ liệu (không Qt) để kiểm thử được: mọi con số đều đọc từ kho thật
(commands / command_steps / channels / channel_snapshots / agents).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from . import kpi
from .store import COMMAND_TYPE_LABELS, Store

COLUMNS = (
    ("waiting", "Chờ Muse nhận", ("queued", "waiting_muse")),
    ("running", "Đang làm", ("running",)),
    ("user", "Cần xử lý", ("needs_user", "interrupted", "failed")),
    ("done", "Xong hôm nay", ("done",)),
)

SHORT_TYPE = {
    "create_video": "Tạo video", "upload": "Đăng video", "optimize": "Tối ưu kênh",
    "free": "Việc tự do", "create_channel": "Tạo kênh", "review": "Kiểm tra chéo",
    "scan": "Quét kênh", "check": "Kiểm tra kênh", "open_browser": "Mở trình duyệt",
    "studio_script": "Kịch bản Studio",
}


def _parse(value) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.astimezone()


def _fmt_span(seconds: float) -> str:
    seconds = abs(int(seconds))
    if seconds < 3600:
        return f"{max(1, seconds // 60)}p"
    hours, rest = divmod(seconds, 3600)
    if hours < 48:
        return f"{hours}g{rest // 60:02d}p" if rest >= 60 else f"{hours}g"
    return f"{hours // 24} ngày"


def command_title(command: dict) -> str:
    payload = command.get("payload") or {}
    title = payload.get("title") or ""
    if not title:
        text = (command.get("instruction") or "").strip()
        title = text.splitlines()[0] if text else ""
    if not title:
        title = COMMAND_TYPE_LABELS.get(command.get("type") or "", command.get("type") or "Việc")
    return title[:140]


def due_info(command: dict, now: datetime) -> tuple[str, bool]:
    """→ (chữ hạn, đã trễ?)."""
    due = _parse(command.get("due_at"))
    if due is None:
        return "", False
    if command.get("status") == "done":
        return f"Hạn {due:%H:%M}", False
    delta = (due - now).total_seconds()
    if delta < 0:
        return f"Trễ {_fmt_span(delta)}", True
    if due.date() == now.date():
        return f"Hạn {due:%H:%M} · còn {_fmt_span(delta)}", False
    return f"Hạn {due:%d/%m %H:%M}", False


def card(command: dict, now: datetime, agents: dict, profiles: dict) -> dict:
    agent_id = command.get("agent_id") or command.get("lease_agent_id")
    agent = agents.get(int(agent_id)) if agent_id else None
    if agent is None and command.get("profile_id"):
        agent = next((a for a in agents.values()
                      if int(command["profile_id"]) in (a.get("profile_ids") or [])), None)
    profile = profiles.get(int(command["profile_id"])) if command.get("profile_id") else None
    due_text, overdue = due_info(command, now)
    status = command.get("status") or "queued"
    updated = _parse(command.get("updated_at"))
    return {
        "id": command["id"],
        "type": SHORT_TYPE.get(command.get("type") or "", command.get("type") or ""),
        "title": command_title(command),
        "channel": (profile or {}).get("label") or command.get("profile_slug") or "",
        "profile_id": command.get("profile_id"),
        "muse": (agent or {}).get("name") or "Chưa có Muse",
        "agent_id": (agent or {}).get("id"),
        "pct": 100 if status == "done" else int(command.get("progress") or 0),
        "step": command.get("step") or ("Chờ Muse nhận việc" if status in ("queued", "waiting_muse") else ""),
        "status": status,
        "due": due_text,
        "overdue": overdue,
        "error": command.get("error") or "",
        "age": _fmt_span((now - updated).total_seconds()) if updated else "",
    }


def kanban(store: Store, now: datetime | None = None, agent_id: int | None = None,
           search: str = "") -> dict:
    now = now or datetime.now().astimezone()
    agents = {int(a["id"]): a for a in store.list_agents()}
    profiles = {int(p["id"]): p for p in store.list_profiles()}
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    rows = store._conn.execute(
        "SELECT * FROM commands WHERE type <> 'review' AND ("
        " status IN ('queued','waiting_muse','running','needs_user','interrupted')"
        " OR (status = 'failed' AND updated_at >= ?)"
        " OR (status = 'done' AND finished_at >= ?)) ORDER BY updated_at DESC LIMIT 400",
        ((now - timedelta(days=2)).isoformat(timespec="seconds"), today.isoformat(timespec="seconds")),
    ).fetchall()
    from .store import _command_row

    needle = (search or "").strip().lower()
    columns = {key: [] for key, _label, _st in COLUMNS}
    for row in rows:
        command = _command_row(row)
        item = card(command, now, agents, profiles)
        if agent_id is not None and item["agent_id"] != agent_id:
            continue
        if needle and needle not in " ".join(
                str(item[k]) for k in ("title", "channel", "muse", "type", "id")).lower():
            continue
        for key, _label, statuses in COLUMNS:
            if item["status"] in statuses:
                columns[key].append(item)
                break
    # trễ hạn lên đầu mỗi cột
    for key in columns:
        columns[key].sort(key=lambda c: (not c["overdue"],))
    overdue = sum(1 for key in ("waiting", "running", "user") for c in columns[key] if c["overdue"])
    strip = {
        "running": len(columns["running"]),
        "waiting": len(columns["waiting"]),
        "user": len(columns["user"]),
        "overdue": overdue,
        "done": len(columns["done"]),
    }
    return {"columns": columns, "strip": strip,
            "labels": {key: label for key, label, _s in COLUMNS}}


def detail(store: Store, command_id: str, now: datetime | None = None) -> dict | None:
    now = now or datetime.now().astimezone()
    command = store.get_command(command_id)
    if command is None:
        return None
    agents = {int(a["id"]): a for a in store.list_agents()}
    profiles = {int(p["id"]): p for p in store.list_profiles()}
    info = card(command, now, agents, profiles)
    steps = []
    for step in store.list_command_steps(command_id):
        at = _parse(step.get("at"))
        steps.append({"icon": "✓", "label": step.get("step") or "",
                      "note": f"{at:%H:%M}" + (f" · {step.get('progress')}%" if step.get("progress") is not None else "")
                      if at else "", "actor": step.get("actor") or ""})
    if steps and command.get("status") in ("running", "waiting_muse", "queued"):
        steps[-1]["icon"] = "▶"
    elif steps and command.get("status") == "needs_user":
        steps[-1]["icon"] = "✋"
    elif steps and command.get("status") == "failed":
        steps[-1]["icon"] = "✕"
    info.update({
        "instruction": command.get("instruction") or "",
        "result": command.get("result") or "",
        "steps": steps,
        "created": command.get("created_at") or "",
    })
    return info


# --------------------------------------------------------------------------- #
# Báo cáo
# --------------------------------------------------------------------------- #
def _channels(store: Store) -> list[dict]:
    profiles = {int(p["id"]): p for p in store.list_profiles()}
    owner = {}
    for agent in store.list_agents():
        for pid in agent.get("profile_ids") or []:
            owner[int(pid)] = agent
    out = []
    for profile in profiles.values():
        for channel in store.list_channels(profile["id"]):
            channel = dict(channel)
            channel["profile_name"] = profile.get("label") or ""
            channel["muse"] = (owner.get(int(profile["id"])) or {}).get("name") or "—"
            channel["agent_id"] = (owner.get(int(profile["id"])) or {}).get("id")
            out.append(channel)
    return out


def _series(store: Store, channel: dict, days: int, now: datetime) -> list[tuple[str, int | None]]:
    snaps = {s["day"]: s for s in store.list_channel_snapshots(channel["profile_id"], channel["channel_id"], limit=90)}
    out = []
    last = None
    for i in range(days - 1, -1, -1):
        day = (now - timedelta(days=i)).date().isoformat()
        snap = snaps.get(day)
        if snap and snap.get("subs") is not None:
            last = int(snap["subs"])
        out.append((day, last))
    return out


def report(store: Store, days: int = 7, agent_id: int | None = None,
           now: datetime | None = None, settings: dict | None = None) -> dict:
    now = now or datetime.now().astimezone()
    days = max(1, int(days))
    since = (now - timedelta(days=days)).isoformat(timespec="seconds")
    channels = _channels(store)
    if agent_id is not None:
        channels = [c for c in channels if c.get("agent_id") == agent_id]
    rows = []
    attention = []
    total_subs = 0
    total_delta = 0
    total_videos = 0
    scan_times = []
    for ch in channels:
        series = _series(store, ch, max(days, 2), now)
        values = [v for _d, v in series if v is not None]
        subs = ch.get("subs") if ch.get("subs") is not None else (values[-1] if values else None)
        delta = (values[-1] - values[0]) if len(values) >= 2 else None
        snaps = store.list_channel_snapshots(ch["profile_id"], ch["channel_id"], limit=90)
        vids = [s.get("video_count") for s in snaps if s.get("day", "") >= since[:10] and s.get("video_count") is not None]
        new_videos = (max(vids) - min(vids)) if len(vids) >= 2 else 0
        work = store._conn.execute(
            "SELECT SUM(status='done'), SUM(status='failed') FROM commands"
            " WHERE profile_id = ? AND type <> 'review' AND updated_at >= ?",
            (ch["profile_id"], since)).fetchone()
        done, failed = int(work[0] or 0), int(work[1] or 0)
        scanned = _parse(ch.get("last_scan_at"))
        if scanned:
            scan_times.append(scanned)
        if failed:
            state, tip = "Có lỗi", f"{failed} việc lỗi — trưởng phòng đang xử lý lại"
        elif delta is not None and delta <= 0 and days >= 7:
            state, tip = "Đứng yên", "Giao Muse làm video mới / tối ưu tiêu đề"
        elif delta is not None and delta > 0:
            state, tip = "Tăng", "Giữ nhịp đăng"
        else:
            state, tip = "Thiếu dữ liệu", "Quét kênh để có số liệu"
        if scanned is None or (now - scanned).total_seconds() > 48 * 3600:
            attention.append({"title": f"Số liệu {ch.get('name') or ch['channel_id']} đã cũ",
                              "detail": "Chưa quét" if scanned is None else f"Quét lần cuối {scanned:%d/%m %H:%M}",
                              "action": "scan", "profile_id": ch["profile_id"]})
        if delta is not None and delta <= 0 and days >= 7:
            attention.append({"title": f"{ch.get('name')} đứng subs {days} ngày",
                              "detail": f"Δ subs = {delta}", "action": "assign", "profile_id": ch["profile_id"]})
        if failed:
            attention.append({"title": f"{failed} việc lỗi ở {ch.get('name')}",
                              "detail": f"Hồ sơ {ch.get('profile_name')}", "action": "open", "profile_id": ch["profile_id"]})
        total_subs += int(subs or 0)
        total_delta += int(delta or 0)
        total_videos += int(new_videos or 0)
        rows.append({
            "name": ch.get("name") or ch["channel_id"], "muse": ch.get("muse"),
            "subs": subs, "delta": delta, "videos": new_videos, "done": done, "failed": failed,
            "state": state, "tip": tip, "spark": [v for _d, v in series[-14:]],
            "profile_id": ch["profile_id"], "series": series,
        })
    rows.sort(key=lambda r: -(r["subs"] or 0))
    task_where = "type <> 'review' AND updated_at >= ?"
    params: list = [since]
    if agent_id is not None:
        task_where += " AND (agent_id = ? OR lease_agent_id = ?)"
        params += [agent_id, agent_id]
    t = store._conn.execute(
        f"SELECT SUM(status='done'), SUM(status='failed'), SUM(status IN ('running','waiting_muse','queued')),"
        f" SUM(status IN ('needs_user','interrupted')) FROM commands WHERE {task_where}", params).fetchone()
    muses = []
    for agent in store.list_agents():
        if agent.get("revoked") or (agent_id is not None and agent["id"] != agent_id):
            continue
        c = store._conn.execute(
            "SELECT SUM(status='done'), SUM(status IN ('running','waiting_muse','queued')), SUM(status='failed')"
            " FROM commands WHERE type <> 'review' AND updated_at >= ? AND (agent_id = ? OR lease_agent_id = ?)",
            (since, agent["id"], agent["id"])).fetchone()
        try:
            score = kpi.agent_kpi(store, agent["id"], settings or {}, now).get("score")
        except Exception:
            score = None
        muses.append({"name": agent.get("name") or agent.get("email"), "id": agent["id"],
                      "done": int(c[0] or 0), "running": int(c[1] or 0), "failed": int(c[2] or 0),
                      "kpi": score, "channels": len(agent.get("profile_ids") or [])})
    top = sorted([r for r in rows if any(v is not None for v in r["spark"])], key=lambda r: -(r["subs"] or 0))[:4]
    chart_days = [d for d, _v in (top[0]["series"] if top else _series_days(days, now))][-days:]
    lines = [{"name": r["name"], "values": [v for _d, v in r["series"]][-days:]} for r in top]
    tiles = [
        {"label": "Kênh", "value": f"{len(rows)}", "delta": f"{len(muses)} Muse phụ trách"},
        {"label": "Tổng subs", "value": f"{total_subs:,}".replace(",", "."),
         "delta": f"{'+' if total_delta >= 0 else ''}{total_delta:,} / {days} ngày".replace(",", ".")},
        {"label": "Video mới", "value": f"{total_videos}", "delta": f"{days} ngày"},
        {"label": "Việc xong", "value": f"{int(t[0] or 0)}", "delta": f"{int(t[1] or 0)} lỗi"},
        {"label": "Đang chạy / chờ bạn", "value": f"{int(t[2] or 0)} / {int(t[3] or 0)}", "delta": "realtime"},
    ]
    return {
        "days": days, "tiles": tiles, "rows": rows, "muses": muses, "attention": attention[:12],
        "chart": {"days": chart_days, "lines": lines},
        "last_scan": max(scan_times).strftime("%H:%M %d/%m") if scan_times else "chưa quét",
    }


def _series_days(days: int, now: datetime):
    return [((now - timedelta(days=i)).date().isoformat(), None) for i in range(days - 1, -1, -1)]


# --------------------------------------------------------------------------- #
# V6.7 — SỔ GIAO VIỆC của trưởng phòng
# --------------------------------------------------------------------------- #
LEDGER_ACTIONS = {"ack_ping": "hỏi đã nhận", "progress_ping": "đòi tiến độ", "reassign": "chuyển người",
                  "extend": "gia hạn", "self_fix": "bắt tự xử lý", "retry": "cho chạy lại",
                  "resume": "cho chạy tiếp", "nudge": "nhắc", "escalate": "báo bạn"}


def _mins(a: datetime | None, b: datetime | None) -> float | None:
    if a is None or b is None:
        return None
    return max(0.0, (b - a).total_seconds() / 60.0)


def assignment_ledger(store: Store, days: int = 7, now: datetime | None = None) -> dict:
    """Mỗi việc trưởng phòng đã giao: giao lúc → nhận lúc → tiến độ → báo cáo,
    số lần trưởng phòng phải nhắc/chuyển người, gom theo từng agent."""
    now = now or datetime.now().astimezone()
    since = (now - timedelta(days=days)).isoformat(timespec="seconds")
    agents = {int(a["id"]): a for a in store.list_agents()}
    profiles = {int(p["id"]): p for p in store.list_profiles()}
    decisions: dict[str, list[dict]] = {}
    for d in store.list_lead_decisions(limit=3000):
        if d.get("command_id"):
            decisions.setdefault(str(d["command_id"]), []).append(d)
    from .store import _command_row

    rows = store._conn.execute(
        "SELECT * FROM commands WHERE type <> 'review' AND updated_at >= ? ORDER BY created_at DESC LIMIT 1500",
        (since,)).fetchall()
    groups: dict[int, dict] = {}
    for row in rows:
        c = _command_row(row)
        payload = c.get("payload") or {}
        mine = decisions.get(str(c["id"]), [])
        if not payload.get("chat_sent_at") and not mine:
            continue  # chưa từng qua tay trưởng phòng
        owner = c.get("agent_id") or c.get("lease_agent_id")
        if owner is None and c.get("profile_id"):
            agent = next((a for a in agents.values() if int(c["profile_id"]) in (a.get("profile_ids") or [])), None)
            owner = agent["id"] if agent else None
        owner = int(owner) if owner else 0
        sent = _parse(payload.get("chat_sent_at"))
        acked = _parse(payload.get("acked_at"))
        finished = _parse(c.get("finished_at"))
        counts: dict[str, int] = {}
        for d in mine:
            counts[d.get("action")] = counts.get(d.get("action"), 0) + 1
        nudges = counts.get("ack_ping", 0) + counts.get("progress_ping", 0) + counts.get("nudge", 0)
        status = c.get("status")
        if status == "done":
            stage = "✓ Đã báo cáo"
        elif status in ("failed",):
            stage = "✕ Lỗi"
        elif status in ("needs_user", "interrupted"):
            stage = "✋ Kẹt — TP đang xử lý"
        elif payload.get("acked") or int(c.get("progress") or 0) > 10:
            stage = "▶ Đã nhận, đang làm"
        elif payload.get("chat_sent"):
            stage = "✉ Đã giao, chờ xác nhận"
        else:
            stage = "⏳ Chờ giao"
        entry = {
            "id": c["id"], "short": str(c["id"])[:6], "title": command_title(c),
            "channel": (profiles.get(int(c["profile_id"])) or {}).get("label") if c.get("profile_id") else "",
            "status": status, "stage": stage, "pct": 100 if status == "done" else int(c.get("progress") or 0),
            "step": c.get("step") or "",
            "sent": sent.strftime("%d/%m %H:%M") if sent else "—",
            "acked": acked.strftime("%H:%M") if acked else "—",
            "reported": finished.strftime("%H:%M") if finished and status in ("done", "failed") else "—",
            "ack_min": _mins(sent, acked), "nudges": nudges, "reassigned": counts.get("reassign", 0),
            "actions": ", ".join(f"{LEDGER_ACTIONS.get(k, k)}×{v}" for k, v in sorted(counts.items())),
        }
        group = groups.setdefault(owner, {
            "agent_id": owner, "name": (agents.get(owner) or {}).get("name") or "Chưa có người nhận",
            "items": [], "assigned": 0, "acked": 0, "running": 0, "done": 0, "stuck": 0, "nudges": 0, "ack_mins": []})
        group["items"].append(entry)
        group["assigned"] += 1
        group["acked"] += 1 if (acked or status == "done" or entry["pct"] > 10) else 0
        group["running"] += 1 if status == "running" else 0
        group["done"] += 1 if status == "done" else 0
        group["stuck"] += 1 if status in ("needs_user", "interrupted", "failed") else 0
        group["nudges"] += nudges
        if entry["ack_min"] is not None:
            group["ack_mins"].append(entry["ack_min"])
    out = []
    for g in sorted(groups.values(), key=lambda g: (-g["assigned"], g["name"])):
        mins = g.pop("ack_mins")
        g["avg_ack"] = (sum(mins) / len(mins)) if mins else None
        out.append(g)
    return {"groups": out, "total": sum(g["assigned"] for g in out)}
