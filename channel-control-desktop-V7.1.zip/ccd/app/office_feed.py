"""V6.6 — dữ liệu cho VĂN PHÒNG 3D mới: trạng thái từng bàn, sự kiện để
chạy hiệu ứng (giao việc ✉ / báo cáo 📄 / lỗi ⚠) và LUỒNG TRAO ĐỔI hai chiều.

Thuần dữ liệu (không Qt). Mọi thứ đọc từ kho thật:
- tin TRƯỞNG PHÒNG → agent: tin 'user' bắt đầu bằng "[Trưởng phòng]" (do
  trưởng phòng/app giao việc, hỏi xác nhận, đòi tiến độ);
- tin AGENT: tin 'agent' — CHỈ có khi Muse thật sự trả lời trên muse.ai;
- tin TRẠNG THÁI do app ghi ('system'): "đã chuyển tới…", "đang đọc…".
App không bao giờ tự đặt lời vào miệng agent.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from .store import Store, _parse_iso

LEAD_TAG = "[Trưởng phòng]"
EVENT_WINDOW_S = 25          # sự kiện mới trong 25 giây → chạy hiệu ứng bay
BUBBLE_WINDOW_S = 1800       # tin trong 30 phút gần nhất: rê chuột vào bàn để xem lại
BUBBLE_FRESH_S = 25          # V6.7: bong bóng TỰ HIỆN 25 giây khi có việc/báo cáo mới rồi tự ẩn
DEFAULT_HOURS = "08:00-22:00"


# --------------------------------------------------------------------------- #
# Giờ làm việc
# --------------------------------------------------------------------------- #
def parse_hours(text: str | None) -> tuple[int, int]:
    """'08:00-22:00' → (480, 1320) phút trong ngày."""
    try:
        start, end = (text or DEFAULT_HOURS).replace(" ", "").split("-")
        h1, m1 = (int(x) for x in start.split(":"))
        h2, m2 = (int(x) for x in end.split(":"))
        return h1 * 60 + m1, h2 * 60 + m2
    except Exception:
        return 8 * 60, 22 * 60


def work_mode(settings: dict | None, now: datetime | None = None) -> str:
    """'work' hoặc 'off'. settings['office_mode']: 'auto' (theo giờ) /
    'work' / 'off' (bạn ép tay từ thanh trên của Văn phòng)."""
    settings = settings or {}
    forced = str(settings.get("office_mode") or "auto")
    if forced in ("work", "off"):
        return forced
    now = now or datetime.now().astimezone()
    start, end = parse_hours(settings.get("office_work_hours"))
    minute = now.hour * 60 + now.minute
    if start <= end:
        inside = start <= minute < end
    else:  # ca qua đêm, vd 20:00-06:00
        inside = minute >= start or minute < end
    return "work" if inside else "off"


def next_work_start(settings: dict | None, now: datetime | None = None) -> datetime:
    now = now or datetime.now().astimezone()
    start, _end = parse_hours((settings or {}).get("office_work_hours"))
    candidate = now.replace(hour=start // 60, minute=start % 60, second=0, microsecond=0)
    return candidate if candidate > now else candidate + timedelta(days=1)


def is_urgent(command: dict) -> bool:
    """Việc vẫn chạy NGOÀI GIỜ: bạn tự giao (nguồn 'ui'/'chat') hoặc đánh dấu khẩn."""
    payload = command.get("payload") or {}
    return bool(payload.get("urgent")) or (command.get("source") or "ui") in ("ui", "chat", "user")


# --------------------------------------------------------------------------- #
# Phân loại tin
# --------------------------------------------------------------------------- #
def message_kind(message: dict) -> str:
    """'lead' | 'user' | 'agent' | 'sys'."""
    direction = message.get("direction")
    body = (message.get("body") or "").lstrip()
    if direction == "agent":
        return "agent"
    if body.startswith(LEAD_TAG) or body.startswith("[Việc #"):
        return "lead"
    if direction == "system":
        return "sys"
    if body.startswith("[CCD"):
        return "sys"
    return "user"


def agent_verdict(body: str) -> str:
    from .muse_chat_bridge import classify_reply, parse_progress

    verdict = classify_reply(body)
    if verdict == "running" and parse_progress(body)[0] is not None:
        return "progress"
    return verdict


_LONG_ID = __import__("re").compile(r"#([0-9a-f]{8,})")


def short_id(command_id) -> str:
    """Mã việc ngắn để HIỂN THỊ (12 ký tự hex → 6)."""
    return str(command_id or "")[:6]


def full_text(text: str, limit: int = 6000) -> str:
    """V7.0: nội dung ĐẦY ĐỦ cho Luồng trao đổi — giữ xuống dòng, bỏ thẻ nội bộ,
    rút gọn mã việc dài, bỏ phần hướng dẫn giao thức gửi kèm việc."""
    text = (text or "").replace(LEAD_TAG, "").strip()
    text = _LONG_ID.sub(lambda m: "#" + m.group(1)[:6], text)
    for cut in ("Trong lúc làm:", "[CCD]"):
        if cut in text:
            text = text.split(cut)[0].rstrip()
    lines = [line.rstrip() for line in text.splitlines()]
    out, blank = [], False
    for line in lines:
        if not line.strip():
            if not blank and out:
                out.append("")
            blank = True
            continue
        blank = False
        out.append(line)
    text = "\n".join(out).strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _excerpt(text: str, limit: int = 110) -> str:
    text = " ".join((text or "").replace(LEAD_TAG, "").split())
    text = _LONG_ID.sub(lambda m: "#" + m.group(1)[:6], text)
    # bỏ phần hướng dẫn dài gửi kèm việc
    for cut in ("Nhận được việc chưa?", "Trong lúc làm:", "[CCD]"):
        if cut in text:
            text = text.split(cut)[0].strip() + (" Nhận được chưa?" if cut == "Nhận được việc chưa?" else "")
    return text if len(text) <= limit else text[: limit - 1] + "…"


# --------------------------------------------------------------------------- #
# Cảnh
# --------------------------------------------------------------------------- #
def display_name(agent: dict) -> str:
    """Tên gọn trên sân khấu: tên đặt riêng; tên là email → phần trước @."""
    name = (agent.get("name") or agent.get("email") or f"Muse #{agent.get('id')}").strip()
    return name.split("@")[0] if "@" in name else name


def _bubble_from(m: dict, who: str, tone: str, now: datetime) -> dict:
    at = _parse_iso(m.get("created_at"))
    age = (now - at).total_seconds() if at else 9999
    return {"who": who, "text": _excerpt(m.get("body") or "", 140), "tone": tone, "real": True,
            "age": age, "fresh": age < BUBBLE_FRESH_S, "id": int(m["id"])}


def _owner_of(command: dict, agents: dict) -> int | None:
    for key in ("agent_id", "lease_agent_id"):
        if command.get(key) and int(command[key]) in agents:
            return int(command[key])
    pid = command.get("profile_id")
    if pid:
        for aid, agent in agents.items():
            if int(pid) in (agent.get("profile_ids") or []):
                return aid
    return None


def build(store: Store, settings: dict | None = None, now: datetime | None = None,
          feed_limit: int = 40) -> dict:
    settings = settings or {}
    now = now or datetime.now().astimezone()
    mode = work_mode(settings, now)
    try:
        from . import supervision

        lead_id = supervision.lead_agent_id(store, settings)
    except Exception:
        lead_id = None
    agents = {int(a["id"]): a for a in store.list_agents() if not a.get("revoked")}
    names = {aid: display_name(a) for aid, a in agents.items()}

    open_cmds: dict[int, list[dict]] = {}
    for command in store.list_open_commands(limit=500):
        if command.get("type") == "review":
            continue
        owner = _owner_of(command, agents)
        if owner is not None:
            open_cmds.setdefault(owner, []).append(command)

    since = (now - timedelta(seconds=BUBBLE_WINDOW_S)).isoformat(timespec="seconds")
    rows = store._conn.execute(
        "SELECT * FROM agent_messages WHERE created_at >= ? ORDER BY id DESC LIMIT 300", (since,)
    ).fetchall()
    recent = [dict(r) for r in reversed(rows)]
    feed_rows = store._conn.execute(
        "SELECT * FROM agent_messages ORDER BY id DESC LIMIT ?", (int(feed_limit),)
    ).fetchall()

    last_agent_msg: dict[int, dict] = {}
    last_lead_msg: dict | None = None
    events = []
    event_since = now - timedelta(seconds=EVENT_WINDOW_S)
    for m in recent:
        kind = message_kind(m)
        aid = int(m["agent_id"])
        at = _parse_iso(m.get("created_at"))
        if kind == "agent":
            last_agent_msg[aid] = m
            verdict = agent_verdict(m.get("body") or "")
            if at and at >= event_since and verdict in ("done", "needs_user", "ack"):
                events.append({"id": int(m["id"]), "kind": {"done": "report", "needs_user": "error",
                                                             "ack": "ack"}[verdict],
                               "agent_id": aid, "command_id": m.get("command_id")})
        elif kind == "lead":
            last_lead_msg = m
            if at and at >= event_since and aid != lead_id:
                events.append({"id": int(m["id"]), "kind": "assign", "agent_id": aid,
                               "command_id": m.get("command_id")})

    desks = []
    counts = {"working": 0, "receive": 0, "error": 0, "idle": 0, "queued": 0}
    for aid, agent in agents.items():
        commands = open_cmds.get(aid, [])
        running = next((c for c in commands if c["status"] == "running"), None)
        problem = next((c for c in commands if c["status"] in ("needs_user", "interrupted")), None)
        waiting = next((c for c in commands if c["status"] in ("waiting_muse", "queued")), None)
        current = running or problem or waiting
        state = "idle"
        if problem is not None and running is None:
            state = "error"
        elif running is not None:
            acked = bool((running.get("payload") or {}).get("acked"))
            state = "working" if acked or int(running.get("progress") or 0) > 10 else "receive"
        elif waiting is not None:
            payload = waiting.get("payload") or {}
            if payload.get("chat_sent"):
                state = "receive"
            elif mode == "off" and not is_urgent(waiting):
                state = "queued"
            else:
                state = "receive"
        if mode == "off" and state == "idle":
            state = "sleep"
        if mode == "off" and state in ("working", "receive") and current is not None:
            state = "night"
        bubble = None
        msg = last_agent_msg.get(aid)
        if msg is not None:
            verdict = agent_verdict(msg.get("body") or "")
            tone = {"done": "report", "needs_user": "error", "ack": "receive", "progress": "working"}.get(verdict, "talk")
            bubble = _bubble_from(msg, names[aid], tone, now)
            if verdict == "done" and bubble["fresh"] and state in ("idle", "sleep", "working", "receive"):
                state = "report"
        # V6.7: CHIP trạng thái gọn luôn hiện trên đầu robot (thay bong bóng chữ dài)
        pct = int((current or {}).get("progress") or 0)
        chip = {
            "working": ("▶", f"{pct}%", "working"), "night": ("▶", f"{pct}%", "working"),
            "receive": ("✉", "chờ nhận" if not (current or {}).get("payload", {}).get("acked") else "đã nhận", "receive"),
            "report": ("✓", "xong", "report"), "error": ("⚠", "lỗi", "error"),
            "queued": ("⏰", next_work_start(settings, now).strftime("%H:%M"), "queued"),
            "idle": ("💤", "rảnh", "idle"), "sleep": ("☾", "nghỉ", "idle"),
        }.get(state, ("•", "", "idle"))
        chip = {"icon": chip[0], "text": chip[1], "tone": chip[2]}
        counts_key = {"night": "working", "report": "working", "sleep": "idle"}.get(state, state)
        counts[counts_key] = counts.get(counts_key, 0) + 1
        desks.append({
            "agent_id": aid, "name": names[aid], "state": state, "lead": aid == lead_id,
            "pct": int((current or {}).get("progress") or 0), "command_id": (current or {}).get("id"),
            "step": (current or {}).get("step") or "", "bubble": bubble, "chip": chip, "open": len(commands),
            "web_state": agent.get("web_state") or "unknown",
        })
    desks.sort(key=lambda d: (not d["lead"], d["agent_id"]))
    lead_desk = next((d for d in desks if d["lead"]), None)
    if lead_desk is None:
        lead_desk = {"agent_id": None, "name": "App điều phối", "state": "lead", "lead": True, "pct": 0,
                     "command_id": None, "step": "", "bubble": None, "open": 0, "web_state": "in",
                     "chip": {"icon": "👑", "text": "điều phối", "tone": "lead"}}
    else:
        desks.remove(lead_desk)
        lead_desk = dict(lead_desk, state="lead" if mode == "work" else "night")
    deferred = sum(1 for d in desks if d["state"] == "queued")
    lead_desk["chip"] = ({"icon": "👑", "text": f"điều phối {len(desks)} agent", "tone": "lead"} if mode == "work"
                         else {"icon": "☾", "text": f"trực đêm · {deferred} chờ sáng", "tone": "lead"})
    if last_lead_msg is not None:
        target = names.get(int(last_lead_msg["agent_id"]), "")
        lead_desk["bubble"] = _bubble_from(last_lead_msg, f"Trưởng phòng → {target}", "lead", now)

    feed = []
    for row in reversed(feed_rows):
        m = dict(row)
        kind = message_kind(m)
        aid = int(m["agent_id"])
        at = _parse_iso(m.get("created_at"))
        entry = {"id": int(m["id"]), "kind": kind, "agent_id": aid, "agent": names.get(aid, f"#{aid}"),
                 "time": at.strftime("%H:%M") if at else "", "text": _excerpt(m.get("body") or "", 220),
                 "full": full_text(m.get("body") or ""),
                 "command_id": m.get("command_id")}
        if kind == "agent":
            entry["verdict"] = agent_verdict(m.get("body") or "")
        feed.append(entry)
    return {"mode": mode, "lead": lead_desk, "desks": desks, "events": events, "feed": feed,
            "counts": counts, "hours": settings.get("office_work_hours") or DEFAULT_HOURS,
            "forced": str(settings.get("office_mode") or "auto"), "now": now.strftime("%H:%M")}
