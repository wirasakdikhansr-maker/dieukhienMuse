"""V7.0 — ĐA NỀN TẢNG: YouTube · Facebook (fanpage) · TikTok.

Mô hình dùng chung với YouTube để mọi tính năng sẵn có (giao việc, trưởng
phòng, giám sát, Kanban, văn phòng 3D, tường trình duyệt) chạy y hệt:

- HỒ SƠ = một tài khoản đăng nhập trong một Chrome riêng (``profiles.platform``).
  · YouTube: một Gmail → N kênh.
  · Facebook: một tài khoản cá nhân (đăng nhập bằng COOKIES) → N fanpage nó quản lý.
  · TikTok: một tài khoản (cookies) → 1 kênh TikTok.
- KÊNH = đơn vị giao việc (``channels.platform``): kênh YouTube / fanpage / kênh TikTok.
- ĐĂNG NHẬP BẰNG COOKIES: dán chuỗi cookie ("c_user=…; xs=…"), JSON
  (EditThisCookie/J2TEAM) hoặc Netscape cookies.txt → lọc đúng domain của nền
  tảng → nạp vào Chrome qua CDP → kiểm tra cookie phiên (c_user/xs, sessionid).
  Cookie chỉ lưu ở máy (data/cookies/<slug>.json), không bao giờ ghi log giá trị.
- QUÉT: Facebook đọc danh sách page tài khoản quản lý; TikTok đọc hồ sơ + số
  follower/video. Kết quả ghi vào bảng kênh như YouTube (kèm logo).
- VIỆC: mẫu việc riêng cho page/TikTok (đăng bài, Reels, video TikTok, trả lời
  bình luận/tin nhắn, tạo page mới…) — Muse làm bằng trình duyệt nhúng của hồ sơ.
"""

from __future__ import annotations

import json
import re
import time

from . import cdp, cookies_vault

PLATFORMS: dict[str, dict] = {
    "youtube": {
        "label": "YouTube", "icon": "▶", "color": "#FF3B30",
        "home": "https://www.youtube.com/", "studio": "https://studio.youtube.com/",
        "domains": ("google.", "youtube.", "gmail.com", "googleapis.com"),
        "auth_cookies": ("SID", "SAPISID", "__Secure-1PSID", "LOGIN_INFO"),
        "unit": "kênh",
    },
    "facebook": {
        "label": "Facebook", "icon": "f", "color": "#1877F2",
        "home": "https://www.facebook.com/", "studio": "https://business.facebook.com/latest/home",
        "domains": ("facebook.com", "fb.com", "messenger.com", "fbcdn.net", "instagram.com"),
        "auth_cookies": ("c_user", "xs"),
        "cookie_domain": ".facebook.com",
        "unit": "page",
    },
    "tiktok": {
        "label": "TikTok", "icon": "♪", "color": "#25F4EE",
        "home": "https://www.tiktok.com/", "studio": "https://www.tiktok.com/tiktokstudio",
        "domains": ("tiktok.com", "tiktokv.com", "tiktokcdn.com", "byteoversea.com", "ttwstatic.com"),
        "auth_cookies": ("sessionid", "sid_tt"),
        "cookie_domain": ".tiktok.com",
        "unit": "kênh TikTok",
    },
}
ORDER = ("youtube", "facebook", "tiktok")


def info(platform: str | None) -> dict:
    return PLATFORMS.get(platform or "youtube", PLATFORMS["youtube"])


def label(platform: str | None) -> str:
    return info(platform)["label"]


def of(row: dict | None) -> str:
    value = str((row or {}).get("platform") or "youtube")
    return value if value in PLATFORMS else "youtube"


def detect_from_url(url: str) -> str | None:
    low = (url or "").lower()
    if "facebook.com" in low or "fb.com" in low:
        return "facebook"
    if "tiktok.com" in low:
        return "tiktok"
    if "youtube.com" in low or "youtu.be" in low:
        return "youtube"
    return None


# --------------------------------------------------------------------------- #
# Cookies
# --------------------------------------------------------------------------- #
def domain_matches(domain: str | None, platform: str) -> bool:
    base = (domain or "").strip().lstrip(".").lower()
    if not base:
        return False
    if platform == "youtube":
        return cookies_vault.is_google_youtube_domain(base)
    return any(d in base for d in info(platform)["domains"])


def parse_cookie_header(text: str, platform: str) -> list[dict]:
    """Chuỗi kiểu header: ``c_user=1000…; xs=…; datr=…`` (định dạng FB/TikTok
    cookie hay được chia sẻ) → cookie chuẩn nội bộ trên domain của nền tảng."""
    domain = info(platform).get("cookie_domain")
    if not domain:
        return []
    out = []
    expires = time.time() + 365 * 86400
    for part in re.split(r";\s*|\n", text or ""):
        if "=" not in part:
            continue
        name, value = part.split("=", 1)
        name, value = name.strip(), value.strip()
        if not name or name.lower() in ("path", "domain", "expires", "max-age", "secure", "httponly", "samesite"):
            continue
        cookie = cookies_vault.normalize_cookie({
            "name": name, "value": value, "domain": domain, "path": "/", "secure": True,
            "httpOnly": name in ("xs", "sessionid", "sid_tt", "sid_guard"), "sameSite": "None",
            "expires": expires,
        })
        if cookie:
            out.append(cookie)
    return out


def parse_cookies_text(text: str, platform: str) -> list[dict]:
    """Nhận MỌI kiểu người dùng hay dán: JSON / Netscape / chuỗi header.
    Chỉ giữ cookie đúng domain nền tảng."""
    text = (text or "").strip()
    if not text:
        return []
    cookies = cookies_vault.parse_cookies_bytes(text.encode("utf-8"))
    if not cookies and "=" in text:
        cookies = parse_cookie_header(text, platform)
    return [c for c in cookies if domain_matches(c.get("domain"), platform)]


def has_session(cookies: list[dict], platform: str) -> bool:
    names = {c.get("name") for c in cookies or []}
    need = info(platform)["auth_cookies"]
    if platform == "facebook":
        return "c_user" in names and "xs" in names
    return any(n in names for n in need)


def account_id_from_cookies(cookies: list[dict], platform: str) -> str:
    for c in cookies or []:
        if platform == "facebook" and c.get("name") == "c_user":
            return str(c.get("value") or "")
        if platform == "tiktok" and c.get("name") in ("uid_tt", "uid_tt_ss"):
            return str(c.get("value") or "")
    return ""


def inject_cookies(port: int, cookies: list[dict]) -> int:
    params = [cookies_vault.to_cdp_cookie(c) for c in cookies]
    cdp.set_cookies(int(port), params)
    return len(params)


def browser_session(port: int, platform: str) -> list[dict]:
    raw = cdp.get_all_cookies(int(port))
    cookies = cookies_vault.normalize_cdp_cookies(raw)
    return [c for c in cookies if domain_matches(c.get("domain"), platform)]


def login_with_cookies(store, profile: dict, manager, text: str | None = None, say=None) -> dict:
    """Đăng nhập Facebook/TikTok bằng cookies: dán mới (text) hoặc kho đã lưu.
    Trả {status: ok|no_cookies|invalid|error, message, account_id}."""
    say = say or (lambda _m: None)
    platform = of(profile)
    if text:
        cookies = parse_cookies_text(text, platform)
        if not cookies:
            return {"status": "no_cookies", "message": f"Không đọc được cookie {label(platform)} nào trong nội dung đã dán."}
        if not has_session(cookies, platform):
            need = ", ".join(info(platform)["auth_cookies"])
            return {"status": "invalid", "message": f"Thiếu cookie phiên đăng nhập ({need}) — cookie không đủ để đăng nhập."}
        cookies_vault.save_cookies(profile["slug"], cookies, source=f"import:{platform}")
    else:
        payload = cookies_vault.load_cookies(profile["slug"]) or {}
        cookies = [c for c in payload.get("cookies") or [] if domain_matches(c.get("domain"), platform)]
        if not cookies:
            return {"status": "no_cookies", "message": "Hồ sơ chưa có cookie đã lưu — dán cookie để đăng nhập."}
    try:
        manager.launch(profile, hidden=True)
    except TypeError:
        manager.launch(profile)
    count = inject_cookies(profile["port"], cookies)
    try:
        client = manager.connect_page(profile)
        try:
            client.navigate(info(platform)["home"])
            time.sleep(3.0)
        finally:
            client.close()
    except Exception:
        pass
    live = browser_session(profile["port"], platform)
    account = account_id_from_cookies(live or cookies, platform)
    if has_session(live, platform):
        message = f"Đã đăng nhập {label(platform)} bằng {count} cookie" + (f" (tài khoản {account})" if account else "") + "."
        say(message)
        store.append_journal(f"🍪 {message}", profile["id"])
        return {"status": "ok", "message": message, "account_id": account}
    return {"status": "invalid", "message": f"Đã nạp {count} cookie nhưng {label(platform)} không nhận phiên — cookie hết hạn?"}


# --------------------------------------------------------------------------- #
# Quét
# --------------------------------------------------------------------------- #
FB_PAGES_URL = "https://www.facebook.com/pages/?category=your_pages&ref=bookmarks"
FB_PAGES_JS = r"""(() => {
  const out = [], seen = new Set();
  const bad = /\/(pages|groups|watch|marketplace|gaming|events|friends|bookmarks|settings|help|policies|ads|business|notifications|messages|stories|reel|photo|search|hashtag|privacy|login|latest)\b/i;
  const main = document.querySelector('[role="main"]') || document.body;
  for (const a of main.querySelectorAll('a[href]')) {
    let href = a.href || '';
    if (!/^https:\/\/(www|web|m)\.facebook\.com\//.test(href)) continue;
    let id = '', m;
    if ((m = href.match(/profile\.php\?id=(\d+)/))) id = m[1];
    else {
      const path = href.replace(/^https:\/\/[^/]+\//, '').split(/[?#]/)[0].replace(/\/$/, '');
      if (!path || path.includes('/') || bad.test('/' + path)) continue;
      id = path;
    }
    if (!id || seen.has(id)) continue;
    const name = (a.innerText || a.getAttribute('aria-label') || '').trim().split('\n')[0];
    if (!name || name.length < 2 || name.length > 90) continue;
    const box = a.closest('[role="listitem"], [data-visualcompletion], div') || a;
    const img = box.querySelector('image, img');
    let avatar = '';
    if (img) avatar = img.getAttribute('xlink:href') || img.getAttribute('href') || img.src || '';
    seen.add(id);
    out.push({channel_id: 'fb:' + id, name: name, handle: /^\d+$/.test(id) ? '' : id,
              url: /^\d+$/.test(id) ? 'https://www.facebook.com/profile.php?id=' + id : 'https://www.facebook.com/' + id,
              avatar_url: avatar});
    if (out.length >= 200) break;
  }
  return out;
})()"""

TIKTOK_SELF_JS = r"""(() => {
  try {
    const el = document.getElementById('__UNIVERSAL_DATA_FOR_REHYDRATION__');
    const data = el ? JSON.parse(el.textContent) : null;
    const scope = (data && data.__DEFAULT_SCOPE__) || {};
    const app = scope['webapp.app-context'] || {};
    const u = app.user || {};
    const detail = (scope['webapp.user-detail'] || {}).userInfo || {};
    const du = detail.user || {}, st = detail.stats || {};
    return {uid: u.uid || du.id || '', uniqueId: u.uniqueId || du.uniqueId || '',
            nickName: u.nickName || du.nickname || '', avatar: (du.avatarLarger || du.avatarMedium ||
            (Array.isArray(u.avatarUri) ? u.avatarUri[0] : u.avatarUri) || ''),
            followers: st.followerCount, videos: st.videoCount, signature: du.signature || ''};
  } catch (e) { return {error: String(e)}; }
})()"""


# Bấm "Xem thêm / See more / Hiển thị thêm" trong danh sách page (không bấm nút
# điều hướng sang trang khác). Trả true nếu đã bấm.
FB_MORE_JS = r"""(() => {
  const words = /^(xem th[eê]m|hi[eể]n th[iị] th[eê]m|t[aả]i th[eê]m|see more|show more|load more|see all|xem t[aấ]t c[aả])$/i;
  const main = document.querySelector('[role="main"]') || document.body;
  for (const el of main.querySelectorAll('[role="button"], button, span, div[tabindex]')) {
    const t = (el.innerText || el.getAttribute('aria-label') || '').trim();
    if (!t || t.length > 30 || !words.test(t)) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 4 || r.height < 4) continue;
    const a = el.closest('a[href]');
    if (a && !/#$/.test(a.getAttribute('href') || '')) continue;  // link sang trang khác → bỏ qua
    el.scrollIntoView({block: 'center'});
    (el.closest('[role="button"]') || el).click();
    return true;
  }
  return false;
})()"""


def scan_fb_pages_live(client, say=None, max_rounds: int = 25, sleep=time.sleep) -> list[dict]:
    """V7.0.1: đọc HẾT danh sách page — mỗi vòng cuộn xuống + bấm "Xem thêm",
    GỘP kết quả từng vòng (Facebook ẩn bớt dòng cũ khi danh sách dài, nên
    đọc một lần cuối sẽ thiếu). Dừng khi 3 vòng liền không có page mới.
    Không tải lại trang giữa chừng."""
    say = say or (lambda _m: None)
    try:
        current = str(client.evaluate("location.href") or "")
    except Exception:
        current = ""
    if "category=your_pages" not in current:
        client.navigate(FB_PAGES_URL)
        sleep(4.0)
    found: dict[str, dict] = {}
    idle = 0
    for round_no in range(max_rounds):
        try:
            batch = parse_fb_pages(client.evaluate(FB_PAGES_JS, timeout=20))
        except Exception:
            batch = []
        before = len(found)
        for page in batch:
            found.setdefault(page["channel_id"], page)
            if not found[page["channel_id"]].get("avatar_url") and page.get("avatar_url"):
                found[page["channel_id"]]["avatar_url"] = page["avatar_url"]
        clicked = False
        try:
            clicked = bool(client.evaluate(FB_MORE_JS, timeout=10))
        except Exception:
            clicked = False
        try:
            client.evaluate("window.scrollBy(0, Math.max(800, window.innerHeight * 0.9))")
        except Exception:
            pass
        sleep(1.6 if clicked else 1.0)
        idle = idle + 1 if len(found) == before and not clicked else 0
        if round_no and round_no % 5 == 0:
            say(f"Facebook: đã đọc {len(found)} page…")
        if idle >= 3:
            break
    return list(found.values())


def parse_fb_pages(raw) -> list[dict]:
    pages = []
    for item in raw or []:
        if not isinstance(item, dict) or not item.get("channel_id") or not item.get("name"):
            continue
        pages.append({
            "channel_id": str(item["channel_id"])[:120],
            "name": str(item["name"])[:120],
            "handle": str(item.get("handle") or "")[:80],
            "url": str(item.get("url") or ""),
            "avatar_url": str(item.get("avatar_url") or "") if str(item.get("avatar_url") or "").startswith("http") else "",
            "platform": "facebook",
        })
    return pages


def parse_tiktok_self(raw: dict | None) -> dict | None:
    raw = raw or {}
    unique = str(raw.get("uniqueId") or "").strip()
    if not unique:
        return None
    return {
        "channel_id": "tt:" + str(raw.get("uid") or unique),
        "name": str(raw.get("nickName") or unique),
        "handle": "@" + unique,
        "url": f"https://www.tiktok.com/@{unique}",
        "subs": raw.get("followers") if isinstance(raw.get("followers"), int) else None,
        "video_count": raw.get("videos") if isinstance(raw.get("videos"), int) else None,
        "avatar_url": str(raw.get("avatar") or "") if str(raw.get("avatar") or "").startswith("http") else "",
        "platform": "tiktok",
    }


def scan_profile(store, profile: dict, manager, log=None) -> dict:
    """Quét Facebook page / kênh TikTok của hồ sơ. Cùng dạng kết quả với
    scanner.scan_profile của YouTube."""
    say = log or (lambda _m: None)
    platform = of(profile)
    name = profile["label"]
    if profile.get("paused"):
        return {"status": "paused", "channels": [], "message": f"Hồ sơ '{name}' đang tạm dừng — bỏ qua quét."}
    try:
        try:
            manager.launch(profile, hidden=True)
        except TypeError:
            manager.launch(profile)
        if not has_session(browser_session(profile["port"], platform), platform):
            restored = login_with_cookies(store, profile, manager, say=say)
            if restored.get("status") != "ok":
                message = (f"Hồ sơ '{name}': CHƯA đăng nhập {label(platform)} — dán cookie "
                           "(nút 🍪 Đăng nhập bằng cookie) hoặc đăng nhập tay trong trình duyệt nhúng.")
                say(message)
                store.append_journal(message, profile["id"])
                return {"status": "needs_login", "channels": [], "message": message}
        client = manager.connect_page(profile)
        try:
            if platform == "facebook":
                channels = scan_fb_pages_live(client, say=say)
            else:
                client.navigate("https://www.tiktok.com/profile")
                time.sleep(4.0)
                raw = client.evaluate(TIKTOK_SELF_JS, timeout=15) or {}
                if raw.get("uniqueId") and raw.get("followers") is None:
                    client.navigate(f"https://www.tiktok.com/@{raw['uniqueId']}")
                    time.sleep(3.5)
                    raw = {**raw, **{k: v for k, v in (client.evaluate(TIKTOK_SELF_JS, timeout=15) or {}).items() if v}}
                one = parse_tiktok_self(raw)
                channels = [one] if one else []
        finally:
            client.close()
    except Exception as exc:  # noqa: BLE001
        message = f"Quét {label(platform)} hồ sơ '{name}' lỗi: {type(exc).__name__}: {exc}"
        say(message)
        return {"status": "error", "channels": [], "message": message}
    new = 0
    for channel in channels:
        if store.upsert_channel(profile["id"], channel):
            new += 1
        try:
            store.record_channel_snapshot(profile["id"], channel)
        except Exception:
            pass
    unit = info(platform)["unit"]
    message = (f"Hồ sơ '{name}' ({label(platform)}): tìm thấy {len(channels)} {unit}"
               + (f", {new} mới" if new else "") + "."
               + ("" if channels else " Chưa thấy gì — giao việc 'Quét page' cho Muse để đọc bằng trình duyệt."))
    say(message)
    store.append_journal(message, profile["id"])
    return {"status": "ok", "channels": channels, "message": message}


# --------------------------------------------------------------------------- #
# Mẫu việc riêng cho Facebook / TikTok
# --------------------------------------------------------------------------- #
TEMPLATES: list[dict] = [
    {"id": "fb-dang-bai", "platform": "facebook", "title": "FB · Đăng bài lên page", "type": "free",
     "instruction": "Trên fanpage {channel}: soạn và ĐĂNG một bài viết mới đúng chủ đề page (ảnh/ chữ + hashtag). "
                    "Chuyển sang đúng page trước khi đăng. Báo link bài đã đăng."},
    {"id": "fb-dang-reels", "platform": "facebook", "title": "FB · Đăng Reels", "type": "upload",
     "instruction": "Trên fanpage {channel}: đăng 1 Reels (video dọc 60–90 giây) kèm mô tả + hashtag. Báo link Reels."},
    {"id": "fb-tra-loi", "platform": "facebook", "title": "FB · Trả lời bình luận & tin nhắn", "type": "free",
     "instruction": "Trên fanpage {channel}: trả lời bình luận mới và tin nhắn Messenger chưa đọc theo giọng page; "
                    "nội dung nhạy cảm thì bỏ qua và liệt kê trong báo cáo."},
    {"id": "fb-tao-page", "platform": "facebook", "title": "FB · Tạo fanpage mới", "type": "create_channel",
     "instruction": "Dùng tài khoản Facebook của hồ sơ tạo một fanpage mới cho chủ đề {channel}: tên, danh mục, ảnh "
                    "đại diện, ảnh bìa, giới thiệu, nút hành động. Báo link page mới."},
    {"id": "fb-toi-uu-page", "platform": "facebook", "title": "FB · Tối ưu page", "type": "optimize",
     "instruction": "Tối ưu fanpage {channel}: giới thiệu, danh mục, thông tin liên hệ, ảnh bìa, bài ghim. Ghi cũ → mới."},
    {"id": "tt-dang-video", "platform": "tiktok", "title": "TikTok · Đăng video", "type": "upload",
     "instruction": "Trên kênh TikTok {channel}: đăng 1 video dọc kèm caption, hashtag đang lên, ảnh bìa; chọn giờ đăng "
                    "tốt nhất. Báo link video."},
    {"id": "tt-tao-video", "platform": "tiktok", "title": "TikTok · Làm video mới", "type": "create_video",
     "instruction": "Làm 1 video TikTok 30–60 giây cho kênh {channel} theo xu hướng ngách kênh; xong đăng luôn và báo link."},
    {"id": "tt-tra-loi", "platform": "tiktok", "title": "TikTok · Trả lời bình luận", "type": "free",
     "instruction": "Trả lời các bình luận mới trên kênh TikTok {channel} đúng giọng kênh; báo số bình luận đã trả lời."},
    {"id": "tt-toi-uu", "platform": "tiktok", "title": "TikTok · Tối ưu hồ sơ kênh", "type": "optimize",
     "instruction": "Tối ưu hồ sơ kênh TikTok {channel}: tên, tiểu sử, ảnh đại diện, link, playlist. Ghi cũ → mới."},
]


def templates_for(platform: str) -> list[dict]:
    return [dict(t) for t in TEMPLATES if t["platform"] == platform]


def task_context(profile: dict | None, channel: dict | None = None) -> str:
    """Dòng bối cảnh nền tảng gửi kèm việc cho Muse (đúng site, đúng page)."""
    platform = of(channel or profile)
    if platform == "youtube":
        return ""
    meta = info(platform)
    target = (channel or {}).get("name") or (profile or {}).get("label") or ""
    url = (channel or {}).get("url") or meta["home"]
    extra = (" Tài khoản cá nhân quản lý page: chuyển sang đúng page trước khi làm "
             "(menu ảnh đại diện → Chuyển sang trang).") if platform == "facebook" else ""
    return (f"NỀN TẢNG: {meta['label']} — làm trên {meta['unit']} '{target}' ({url}) bằng trình duyệt nhúng của hồ sơ "
            f"(đã đăng nhập sẵn bằng cookie).{extra}")
