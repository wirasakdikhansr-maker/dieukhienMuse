"""Đăng nhập tài khoản cho một hồ sơ NGAY trong trình duyệt của app
(V3.4) — trình duyệt này luôn được nhúng vào giao diện (cài đặt nhúng
luôn bật mặc định), không dùng trình duyệt ngoài nào khác.

Thứ tự ưu tiên theo yêu cầu người dùng:
1. Đã đăng nhập sẵn -> xong.
2. Có COOKIES đã lưu của hồ sơ -> nạp cookies, kiểm tra lại.
3. Có MẬT KHẨU đã lưu (kho credentials_vault) -> mở trang đăng nhập
   Google trong Chrome của hồ sơ, TỰ ĐIỀN email + mật khẩu. Gặp bước
   xác minh (mã 2 bước, điện thoại, CAPTCHA, "Verify it's you") thì
   DỪNG NGAY và để người dùng tự hoàn tất trong trình duyệt nhúng —
   app không cố vượt qua xác minh.
4. Không có gì -> mở trang đăng nhập để người dùng tự đăng nhập.

Mật khẩu chỉ tồn tại trong bộ nhớ lúc điền + file kho riêng của hồ
sơ; không bao giờ vào nhật ký/thông báo (chỉ nói trạng thái).
"""

from __future__ import annotations

import json
import time

from . import credentials_vault, scanner

LOGIN_STATE_JS = """
/*ccd:login-state*/
(() => {
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const email = document.querySelector('#identifierId, input[type="email"], input[name="identifier"]');
  const pass = document.querySelector('input[type="password"], input[name="Passwd"]');
  const text = (document.body ? document.body.innerText : '').slice(0, 3000);
  const url = location.href;
  const challenge = url.includes('/challenge')
    || /verify it'?s you|2-step verification|xác minh danh tính|hai bước|unusual activity|confirm it'?s you/i.test(text);
  const wrongPassword = /wrong password|incorrect password|mật khẩu không đúng|sai mật khẩu/i.test(text);
  return {
    url,
    hasEmail: visible(email),
    hasPassword: visible(pass),
    challenge,
    wrongPassword
  };
})()
"""

LOGIN_FILL_JS = """
/*ccd:login-fill*/
(() => {
  const email = %(email_js)s;
  const password = %(password_js)s;
  const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  const setValue = (el, value) => {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const clickNext = id => {
    const btn = document.getElementById(id);
    if (btn) { btn.click(); return true; }
    const candidate = [...document.querySelectorAll('button, div[role="button"]')]
      .find(el => /^(next|tiếp theo|siguiente)$/i.test((el.innerText || '').trim()));
    if (candidate) { candidate.click(); return true; }
    return false;
  };
  const emailEl = document.querySelector('#identifierId, input[type="email"], input[name="identifier"]');
  if (email && visible(emailEl)) {
    setValue(emailEl, email);
    setTimeout(() => clickNext('identifierNext'), 350);
    return 'email';
  }
  const passEl = document.querySelector('input[type="password"], input[name="Passwd"]');
  if (password && visible(passEl)) {
    setValue(passEl, password);
    setTimeout(() => clickNext('passwordNext'), 350);
    return 'password';
  }
  return 'none';
})()
"""


def _is_logged_in(client) -> bool:
    try:
        info = client.evaluate(scanner.CHECK_LOGIN_JS) or {}
    except Exception:
        return False
    href = info.get("href") or ""
    return bool(info.get("loggedIn")) and "accounts.google.com" not in href


def attempt_login(client, profile: dict, say=None, timeout_s: float = 75.0, **_kw) -> dict:
    """Thử đăng nhập cho hồ sơ theo thứ tự cookies -> mật khẩu đã lưu.
    Trả {'status': 'already'|'cookies'|'password'|'needs_user'|
    'wrong_password'|'needs_manual'|'error', 'message': str}.
    ``client`` là trang CDP của Chrome hồ sơ (đã mở sẵn/được mở ở đây
    bởi nơi gọi qua ChromeManager).

    V3.9.2: ``say`` nhận cả bí danh ``log=`` — sự cố thật 28/10: nơi
    gọi truyền log= trong khi chữ ký chỉ có say, MỌI lần bấm Đăng nhập
    chết ngay "attempt_login() got an unexpected keyword argument
    'log'" trước khi làm bất cứ việc gì. Chữ ký từ nay khoan dung với
    bí danh để một lần đổi tên không giết cả luồng đăng nhập nữa."""
    if say is None:
        say = _kw.get("log") or (lambda _msg: None)
    label = profile["label"]
    try:
        client.navigate("https://www.youtube.com/")
        scanner._wait_ready(client)
        if _is_logged_in(client):
            return {
                "status": "already",
                "message": f"Hồ sơ '{label}': đã đăng nhập sẵn.",
            }

        # 1) Cookies đã lưu.
        if scanner._try_cookie_restore(client, profile, say):
            if _is_logged_in(client):
                return {
                    "status": "cookies",
                    "message": f"Hồ sơ '{label}': đăng nhập thành công bằng cookies đã lưu.",
                }

        # 2) Mật khẩu đã lưu -> tự điền trong trình duyệt của hồ sơ.
        creds = credentials_vault.load_password(profile["slug"])
        if not creds:
            try:
                client.navigate(scanner.SIGNIN_URL)
            except Exception:
                pass
            return {
                "status": "needs_manual",
                "message": (
                    f"Hồ sơ '{label}': chưa có cookies/mật khẩu đã lưu — "
                    "trang đăng nhập đang mở trong trình duyệt nhúng, hãy "
                    "tự đăng nhập một lần."
                ),
            }
        gmail = creds.get("gmail") or profile.get("gmail") or ""
        password = creds.get("password") or ""
        say(f"Hồ sơ '{label}': tự điền email + mật khẩu đã lưu để đăng nhập…")
        client.navigate(scanner.SIGNIN_URL)
        scanner._wait_ready(client)
        deadline = time.time() + timeout_s
        filled_email = False
        filled_password = False
        while time.time() < deadline:
            if _is_logged_in(client):
                return {
                    "status": "password",
                    "message": f"Hồ sơ '{label}': đăng nhập thành công bằng mật khẩu đã lưu.",
                }
            try:
                state = client.evaluate(LOGIN_STATE_JS, timeout=30) or {}
            except Exception:
                state = {}
            if state.get("wrongPassword"):
                return {
                    "status": "wrong_password",
                    "message": (
                        f"Hồ sơ '{label}': Google báo SAI MẬT KHẨU đã lưu — "
                        "cập nhật lại mật khẩu cho hồ sơ (Thêm/Sửa) rồi thử lại."
                    ),
                }
            if state.get("challenge"):
                return {
                    "status": "needs_user",
                    "message": (
                        f"Hồ sơ '{label}': Google yêu cầu XÁC MINH thêm — "
                        "hãy hoàn tất bước xác minh ngay trong trình duyệt "
                        "nhúng của hồ sơ, app không tự vượt qua bước này."
                    ),
                }
            step = None
            if state.get("hasEmail") and not filled_email:
                step = ("email", gmail)
                filled_email = True
            elif state.get("hasPassword") and not filled_password:
                step = ("password", password)
                filled_password = True
            if step is not None:
                js = LOGIN_FILL_JS % {
                    "email_js": json.dumps(step[1] if step[0] == "email" else ""),
                    "password_js": json.dumps(step[1] if step[0] == "password" else ""),
                }
                try:
                    client.evaluate(js, timeout=30)
                except Exception:
                    pass
                time.sleep(2.5)
            else:
                time.sleep(1.0)
        if _is_logged_in(client):
            return {
                "status": "password",
                "message": f"Hồ sơ '{label}': đăng nhập thành công bằng mật khẩu đã lưu.",
            }
        return {
            "status": "needs_user",
            "message": (
                f"Hồ sơ '{label}': chưa đăng nhập xong sau khi tự điền — "
                "kiểm tra trình duyệt nhúng của hồ sơ để hoàn tất."
            ),
        }
    except Exception as exc:
        return {
            "status": "error",
            "message": f"Hồ sơ '{label}': đăng nhập thất bại — {exc}",
        }
