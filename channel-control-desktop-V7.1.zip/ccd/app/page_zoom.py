"""V6.5 — ZOOM TRANG cho trình duyệt nhúng, áp được cho MỘT trang, CẢ HÀNG ô
hoặc MỌI trang đang mở, và GIỮ NGUYÊN khi trang tải lại / mở trang mới.

Cách cũ (Emulation.setPageScaleFactor) mất hiệu lực khi phiên CDP đóng và
không thu nhỏ dưới 100% trên máy tính. Cách mới: CSS zoom trên thẻ gốc của
trang (`document.documentElement.style.zoom`), do một luồng nền "giữ zoom"
kiểm tra ~1,5 giây/lần trên MỌI tab trang của các hồ sơ được chỉnh — trang
vừa tải lại hay tab mới mở đều được áp lại gần như ngay.
"""

from __future__ import annotations

import threading
import time

from . import cdp

SETTINGS_KEY = "page_zoom_pct"
MIN_PCT, MAX_PCT = 30, 200

ZOOM_JS = r"""/*ccd:page-zoom*/(() => {
  const want = %(pct)d;
  const root = document.documentElement;
  if (!root) return 'no-root';
  const cur = root.getAttribute('data-ccd-zoom');
  if (cur === String(want)) return 'same';
  if (want === 100) { root.style.zoom = ''; } else { root.style.zoom = (want / 100).toString(); }
  root.setAttribute('data-ccd-zoom', String(want));
  return 'set';
})()"""


def clamp(pct) -> int:
    try:
        value = int(round(float(pct)))
    except (TypeError, ValueError):
        value = 100
    return max(MIN_PCT, min(MAX_PCT, value))


def get_pct(settings: dict, slug: str) -> int | None:
    value = (settings.get(SETTINGS_KEY) or {}).get(slug)
    return None if value is None else clamp(value)


def set_pct(settings: dict, slugs, pct) -> int:
    pct = clamp(pct)
    table = dict(settings.get(SETTINGS_KEY) or {})
    for slug in slugs:
        table[str(slug)] = pct
    settings[SETTINGS_KEY] = table
    return pct


def scope_ids(scope: str, current: int | None, running: list[int], positions: dict[int, tuple[int, int]]) -> list[int]:
    """Hồ sơ chịu ảnh hưởng theo phạm vi: 'page' (ô đang chọn), 'row'
    (mọi ô cùng hàng với ô đang chọn trên tường), 'all' (mọi trang đang mở)."""
    if scope == "all":
        return list(running)
    if current is None:
        return []
    if scope == "row" and current in positions:
        row = positions[current][0]
        return [pid for pid in running if positions.get(pid, (-1, -1))[0] == row]
    return [current]


class ZoomKeeper:
    """Luồng nền giữ zoom: targets = {profile_id: (port, pct)}."""

    def __init__(self, interval: float = 1.5, client_factory=None, lister=None):
        self.interval = interval
        self._targets: dict[int, tuple[int, int]] = {}
        self._clients: dict[str, object] = {}
        self._lock = threading.Lock()
        self._factory = client_factory or (lambda ws: cdp.CDPClient(ws, timeout=5))
        self._lister = lister or (lambda port: cdp.http_json(port, "/json/list", timeout=1.5))
        self._wake = threading.Event()
        self._stop = False
        self._thread = threading.Thread(target=self._loop, daemon=True, name="page-zoom")
        self._thread.start()

    def set_targets(self, targets: dict[int, tuple[int, int]]) -> None:
        with self._lock:
            self._targets = dict(targets)
        self._wake.set()

    def stop(self):
        self._stop = True
        self._wake.set()

    def tick(self) -> int:
        """Một vòng áp; trả số trang vừa được đặt zoom mới."""
        with self._lock:
            targets = dict(self._targets)
        changed = 0
        alive: set[str] = set()
        for _pid, (port, pct) in targets.items():
            try:
                pages = [t for t in self._lister(port) if t.get("type") == "page" and t.get("webSocketDebuggerUrl")]
            except Exception:
                continue
            for page in pages:
                url = page.get("url") or ""
                if url.startswith(("devtools://", "chrome://", "chrome-extension://")):
                    continue
                ws = page["webSocketDebuggerUrl"]
                alive.add(ws)
                client = self._clients.get(ws)
                try:
                    if client is None:
                        client = self._factory(ws)
                        self._clients[ws] = client
                    if client.evaluate(ZOOM_JS % {"pct": int(pct)}) == "set":
                        changed += 1
                except Exception:
                    self._drop(ws)
        for ws in [ws for ws in self._clients if ws not in alive]:
            self._drop(ws)
        return changed

    def _drop(self, ws: str):
        client = self._clients.pop(ws, None)
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

    def _loop(self):
        while not self._stop:
            self._wake.wait(self.interval)
            self._wake.clear()
            if self._stop:
                break
            try:
                self.tick()
            except Exception:
                pass
            time.sleep(0.05)
        for ws in list(self._clients):
            self._drop(ws)
