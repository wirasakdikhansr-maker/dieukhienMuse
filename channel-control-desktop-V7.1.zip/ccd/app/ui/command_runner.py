"""Worker dùng chung + bộ chạy lệnh nền của UI.

- ``FuncWorker``: QThread mỏng chạy một callable rồi phát kết quả — giữ
  lại cho các việc lẻ không cần hàng đợi (panel Kiểm tra khi đứng độc
  lập...). Các luồng chính của cửa sổ đã chuyển qua JobEngine (V3.1).
- ``CommandRunner``: adapter Qt quanh ``app.job_engine.JobEngine`` —
  MỘT hàng đợi nền duy nhất cho lệnh (ui/auto), quét tay, kiểm tra và
  các việc nền khác của cửa sổ chính:

  * Timer rà bảng commands tìm lệnh nguồn 'ui'/'auto' đang 'queued' và
    tới giờ chạy (scheduled_at) → nộp vào engine (ưu tiên MANUAL).
  * Lệnh chạy bằng ``executor.run_command_by_id`` trong luồng engine;
    việc của CÙNG hồ sơ không bao giờ chạy chồng nhau (engine lo).
  * Lỗi tạm thời (CDP/socket) được thử lại theo chính sách của engine;
    trước mỗi lần thử lại, lệnh được đưa về 'queued' để nhận lại sạch.
  * Huỷ: ``cancel_command`` — việc đang chờ thì rút khỏi hàng đợi và
    chốt lệnh 'failed' (Đã huỷ); việc đang chạy thì bật token, và khi
    hàm việc quay về, lệnh được chốt 'failed' (Đã huỷ bởi người dùng).

  Mỗi lần chạm DB đều mở Store ngắn hạn trong đúng thread — theo tiền
  lệ agent_server (kết nối sqlite không dùng chéo thread được).
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QThread, QTimer, Signal

from .. import executor
from ..chrome_manager import ChromeManager
from ..job_engine import (
    PRIORITY_AUTO,
    PRIORITY_MANUAL,
    JobEngine,
    TransientJobError,
)
from ..store import CLAUDE_COMMAND_TYPES, Store

# Từ khoá nhận diện lỗi tạm thời đáng thử lại (khớp với thông điệp lỗi
# mà executor/scanner/CDP sinh ra khi kết nối chập chờn).
_TRANSIENT_MARKERS = (
    "cdp",
    "websocket",
    "kết nối",
    "connection",
    "socket",
    "timed out",
    "timeout",
    "temporarily",
)


def looks_transient(text: str | None) -> bool:
    lowered = (text or "").lower()
    return any(marker in lowered for marker in _TRANSIENT_MARKERS)


class FuncWorker(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self._fn = fn

    def run(self):
        try:
            self.done.emit(self._fn())
        except Exception as exc:  # báo về UI thay vì nuốt lỗi
            self.failed.emit(str(exc))


class CommandRunner(QObject):
    log_line = Signal(str)
    command_finished = Signal(dict)
    # V4.5: một lệnh app-side vừa BẮT ĐẦU chạy — MainWindow dùng để
    # tự mở trình duyệt của hồ sơ ngay (không đợi nhịp quét 5 giây).
    command_started = Signal(dict)
    # Sự kiện việc tuỳ ý (quét/kiểm tra nộp qua submit_custom) đã xong —
    # phát kèm job_id để nơi nộp đối chiếu.
    job_finished = Signal(str, object)

    def __init__(self, db_path, manager: ChromeManager, parent=None,
                 dispatch_now=None):
        super().__init__(parent)
        self._db_path = Path(db_path)
        self._manager = manager
        # V4.1.1: callback "ép dispatcher xét ngay" (MainWindow nối tới
        # AgentServer.request_dispatch_now). Không có (None) thì nút
        # Chạy ngay cho lệnh Muse thoái hoá về chờ nhịp dispatcher kế
        # tiếp như trước — không lỗi.
        self._dispatch_now = dispatch_now
        self._engine = JobEngine(num_workers=3, on_event=self._on_engine_event)
        self._submitted: set[str] = set()  # command_id đã nộp engine, chưa xong
        self._custom: dict[str, object] = {}  # job_id -> callback kết quả
        self._timer = QTimer(self)
        self._timer.setInterval(1500)
        self._timer.timeout.connect(self._poll)

    # ------------------------------------------------------------------ #
    # Vòng đời
    # ------------------------------------------------------------------ #
    def start(self):
        self._timer.start()

    def stop(self):
        self._timer.stop()
        store = getattr(self, "_poll_store", None)
        if store is not None:
            try:
                store.close()
            except Exception:
                pass
            self._poll_store = None
        self._engine.shutdown(wait=True, timeout=5)

    @property
    def busy(self) -> bool:
        return any(
            (job := self._engine.get(job_id)) is not None and job.status == "running"
            for job_id in list(self._submitted)
        )

    @property
    def engine(self) -> JobEngine:
        return self._engine

    # ------------------------------------------------------------------ #
    # Sự kiện engine (gọi TỪ LUỒNG ENGINE — phát Signal Qt là an toàn,
    # Qt tự xếp hàng về luồng của QObject này)
    # ------------------------------------------------------------------ #
    def _on_engine_event(self, job, event: str):
        if event == "finished":
            if job.command_id is not None:
                self._submitted.discard(job.command_id)
                row = self._read_command(job.command_id)
                if row is not None:
                    self.command_finished.emit(row)
            callback = self._custom.pop(job.id, None)
            self.job_finished.emit(job.id, job.result)
            if callback is not None:
                try:
                    callback(job)
                except Exception as exc:
                    self.log_line.emit(f"Lỗi hậu xử lý việc nền: {exc}")

    def _read_command(self, command_id: str) -> dict | None:
        store = Store(self._db_path)
        try:
            return store.get_command(command_id)
        finally:
            store.close()

    # ------------------------------------------------------------------ #
    # Nộp việc tuỳ ý (quét tay / kiểm tra / mở trình duyệt hàng loạt)
    # ------------------------------------------------------------------ #
    def submit_custom(self, fn, profile_id=None, priority=PRIORITY_MANUAL,
                      kind="custom", on_done=None):
        """Nộp một callable(token) vào hàng đợi chung; ``on_done(job)``
        được gọi (từ luồng engine) khi việc kết thúc. Trả về Job."""
        job = self._engine.submit(
            fn, profile_id=profile_id, priority=priority, kind=kind
        )
        if on_done is not None:
            self._custom[job.id] = on_done
        return job

    # ------------------------------------------------------------------ #
    # Hàng đợi lệnh trong DB
    # ------------------------------------------------------------------ #
    def _poll(self):
        # V6.1 (CHỐNG ĐƠ): nhịp 1.5 giây chạy trên LUỒNG GIAO DIỆN —
        # bản cũ MỞ + di trú + ĐÓNG một kết nối SQLite mới mỗi nhịp
        # (trên Windows có antivirus quét file DB, mỗi lần mở tốn hàng
        # chục ms). Nay giữ MỘT kết nối riêng của nhịp poll, dùng lại.
        store = getattr(self, "_poll_store", None)
        if store is None:
            store = Store(self._db_path)
            self._poll_store = store
        try:
            queued = store.list_commands(status="queued", limit=100)
        except Exception:
            try:
                store.close()
            except Exception:
                pass
            self._poll_store = None
            return
        now = datetime.now().astimezone()
        due = [
            cmd
            for cmd in queued
            if cmd["source"] in ("ui", "auto")
            # V4.0 (Đ5): lệnh chờ Muse cũng nằm ở 'queued' trước khi
            # dispatcher đẩy lên 'waiting_muse' — runner này KHÔNG
            # được nộp chúng vào executor (sẽ thành "không tự chạy
            # tại app được"); dispatcher trong AgentServer lo phần đó.
            and cmd["type"] not in CLAUDE_COMMAND_TYPES
            and cmd["id"] not in self._submitted
            and _is_due(cmd, now)
        ]
        due.reverse()  # list mới-nhất-trước -> nộp lệnh cũ trước
        for command in due:
            self._submit_command(command)

    def run_now(self, command_id: str):
        """Chạy ngay một lệnh queued (bỏ qua scheduled_at) — nút "Chạy ngay"."""
        if command_id in self._submitted:
            self.log_line.emit("Lệnh đã ở trong hàng đợi chạy.")
            return
        command = self._read_command(command_id)
        if command is None or command["status"] != "queued":
            self.log_line.emit("Lệnh không còn ở trạng thái chờ chạy.")
            return
        if command["type"] in CLAUDE_COMMAND_TYPES:
            # V4.1.1 — Chạy ngay cho lệnh Muse phải là NGAY THẬT:
            # (a) xoá hẹn giờ (run-now thắng scheduled_at — trước đây
            # nhánh này chỉ ghi một dòng log rồi trả về, lệnh hẹn giờ
            # tương lai vẫn nằm chờ và lệnh kẹt điều kiện thì chờ vô
            # hạn tới nhịp dispatcher 15 giây, tạo cảm giác "bấm mà
            # không ai nhận"); (b) ép vòng worker của AgentServer chạy
            # một nhịp dispatcher tức thì qua request_dispatch_now.
            # Runner tại chỗ vẫn không tự thi hành loại lệnh này.
            store = Store(self._db_path)
            try:
                store.clear_command_schedule(command_id)
            finally:
                store.close()
            if self._dispatch_now is not None:
                try:
                    self._dispatch_now()
                except Exception as exc:
                    # V4.2 (O-06): ép điều phối lỗi không làm hỏng nút
                    # bấm NHƯNG phải báo ra — không nuốt lặng.
                    self.log_line.emit(
                        f"⚠ Không gọi được điều phối ngay: {exc}"
                    )
            self.log_line.emit(
                "Lệnh của Muse — đã xoá hẹn giờ (nếu có) và yêu cầu "
                "dispatcher xét NGAY: đủ điều kiện là lệnh lên 'Chờ "
                "Muse' cho Muse phụ trách nhận; còn thiếu điều kiện "
                "thì lý do hiện ở cột Tiến độ của lệnh."
            )
            return
        self._submit_command(command, priority=PRIORITY_MANUAL)

    def cancel_command(self, command_id: str) -> None:
        """Huỷ một lệnh: đang chờ trong engine → rút ra + chốt 'failed';
        đang chạy → bật token (lệnh chốt 'failed' khi hàm việc quay về);
        chưa nộp engine (hẹn giờ tương lai) → chốt thẳng trong DB."""
        job = self._engine.find_by_command(command_id)
        if job is not None and job.status in ("queued", "running"):
            was_queued = job.status == "queued"
            self._engine.cancel(job.id)
            if was_queued:
                self._finish_cancelled(command_id)
            return
        command = self._read_command(command_id)
        if command is not None and command["status"] in ("queued", "waiting_muse"):
            # 'waiting_muse': huỷ = chốt luôn, phía Muse sẽ thấy trạng
            # thái cuối và không nhận việc nữa.
            self._finish_cancelled(command_id)
        else:
            self.log_line.emit("Lệnh không ở trạng thái huỷ được.")

    def _finish_cancelled(self, command_id: str):
        store = Store(self._db_path)
        try:
            store.finish_command(
                command_id, "failed", result="Đã huỷ bởi người dùng.",
                error="Đã huỷ bởi người dùng.",
            )
            store.append_journal(f"Lệnh #{command_id} — đã huỷ bởi người dùng.")
        finally:
            store.close()
        row = self._read_command(command_id)
        if row is not None:
            self.command_finished.emit(row)

    def _submit_command(self, command: dict, priority: int | None = None):
        command_id = command["id"]
        if command_id in self._submitted:
            return
        self._submitted.add(command_id)
        if priority is None:
            priority = PRIORITY_AUTO if command["source"] == "auto" else PRIORITY_MANUAL
        self.log_line.emit(
            f"Bắt đầu chạy lệnh #{command_id} ({command['type']})…"
        )
        self.command_started.emit(command)
        self._engine.submit(
            lambda token: self._execute_command(command_id, token),
            profile_id=command.get("profile_id"),
            priority=priority,
            kind="command",
            command_id=command_id,
        )

    def _execute_command(self, command_id: str, token):
        """Thân việc cho engine: chạy lệnh qua executor; lỗi tạm thời thì
        đưa lệnh về 'queued' rồi ném TransientJobError để engine thử lại;
        token huỷ bật giữa chừng → chốt lệnh là đã huỷ."""
        store = Store(self._db_path)
        try:
            store.mark_command_attempt(command_id)
        finally:
            store.close()
        result = executor.run_command_by_id(
            self._db_path,
            command_id,
            self._manager,
            log=self.log_line.emit,
        )
        if token.cancelled:
            self._finish_cancelled(command_id)
            return result
        if (
            result is not None
            and result.get("status") == "failed"
            and looks_transient(result.get("error") or result.get("result"))
        ):
            # Đưa lệnh về 'queued' để lần thử kế nhận (claim) lại được.
            store = Store(self._db_path)
            try:
                store.update_command(command_id, status="queued")
            finally:
                store.close()
            raise TransientJobError(result.get("error") or "Lỗi tạm thời khi chạy lệnh.")
        return result


def _is_due(command: dict, now: datetime) -> bool:
    scheduled = command.get("scheduled_at")
    if not scheduled:
        return True
    try:
        when = datetime.fromisoformat(str(scheduled))
    except ValueError:
        return True
    if when.tzinfo is None:
        when = when.astimezone()
    return when <= now
