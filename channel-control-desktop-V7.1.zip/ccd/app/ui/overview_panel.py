"""Panel "Tổng quan" (V3.1) — màn hình nhà của app.

Thẻ KPI lấy từ ``Store.stats()``: tổng kênh, tổng subscribers, video
đang Scheduled trong kho, lệnh đang chờ/đang chạy; bên dưới là dòng
hoạt động gần nhất (15 mục nhật ký mới nhất). Lỗi đọc dữ liệu hiện
thành banner có nút Thử lại thay vì làm trắng màn hình.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..store import COMMAND_TYPE_LABELS, Store
from . import theme

_ACTIVE_STATUS_LABELS = {
    "queued": "Đang chờ",
    "running": "Đang chạy",
    "waiting_muse": "Chờ Muse nhận",
}


class OverviewPanel(QWidget):
    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self._store = store
        self._build_ui()
        self.refresh()
        # V4.3.2 (F4): panel Tổng quan không còn nằm trong stack
        # điều hướng (V4.3) nhưng vẫn được cửa sổ chính dựng — timer
        # chỉ chạy khi panel THẬT SỰ hiện (showEvent), không còn
        # làm mới vô hình mỗi 15 giây suốt phiên.
        self._timer = QTimer(self)
        self._timer.setInterval(15_000)
        self._timer.timeout.connect(self.refresh)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        root.addWidget(theme.section_header("Tổng quan"))

        self.banner = QFrame()
        self.banner.setObjectName("ErrorBanner")
        banner_layout = QHBoxLayout(self.banner)
        banner_layout.setContentsMargins(12, 8, 12, 8)
        self.banner_text = QLabel("")
        self.banner_text.setObjectName("ErrorBannerText")
        banner_layout.addWidget(self.banner_text, 1)
        retry = QPushButton("Thử lại")
        retry.clicked.connect(self.refresh)
        banner_layout.addWidget(retry)
        self.banner.hide()
        root.addWidget(self.banner)

        kpi_row = QHBoxLayout()
        kpi_row.setSpacing(12)
        self.kpi_channels = self._kpi_card("TỔNG KÊNH", "—", "trên mọi hồ sơ")
        self.kpi_subs = self._kpi_card("TỔNG SUBSCRIBERS", "—", "cộng từ các kênh đã quét")
        self.kpi_scheduled = self._kpi_card("VIDEO ĐANG SCHEDULED", "—", "trong kho dữ liệu")
        self.kpi_commands = self._kpi_card("LỆNH ĐANG CHỜ / CHẠY", "—", "hàng đợi chung của app")
        for card in (
            self.kpi_channels,
            self.kpi_subs,
            self.kpi_scheduled,
            self.kpi_commands,
        ):
            kpi_row.addWidget(card, 1)
        root.addLayout(kpi_row)

        # Theo dõi tiến độ công việc của Muse (V3.2): lệnh đang chờ /
        # đang chạy kèm % và bước hiện tại, tự làm mới theo timer chung.
        root.addWidget(theme.section_header("Muse đang làm việc"))
        work_card = theme.card_frame()
        work_layout = QVBoxLayout(work_card)
        work_layout.setContentsMargins(16, 12, 16, 12)
        work_layout.setSpacing(6)
        self.work_host = QWidget()
        self.work_layout = QVBoxLayout(self.work_host)
        self.work_layout.setContentsMargins(0, 0, 0, 0)
        self.work_layout.setSpacing(8)
        self.work_layout.setAlignment(Qt.AlignTop)
        work_layout.addWidget(self.work_host)
        root.addWidget(work_card)

        root.addWidget(theme.section_header("Hoạt động gần nhất"))
        feed_card = theme.card_frame()
        feed_layout = QVBoxLayout(feed_card)
        feed_layout.setContentsMargins(16, 12, 16, 12)
        feed_layout.setSpacing(6)
        self.feed_host = QWidget()
        self.feed_layout = QVBoxLayout(self.feed_host)
        self.feed_layout.setContentsMargins(0, 0, 0, 0)
        self.feed_layout.setSpacing(5)
        self.feed_layout.setAlignment(Qt.AlignTop)
        feed_layout.addWidget(self.feed_host)
        root.addWidget(feed_card, 1)

    def _kpi_card(self, title: str, value: str, sub: str) -> QFrame:
        card = QFrame()
        card.setObjectName("KpiCard")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(2)
        title_label = QLabel(title)
        title_label.setObjectName("KpiTitle")
        value_label = QLabel(value)
        value_label.setObjectName("KpiValue")
        sub_label = QLabel(sub)
        sub_label.setObjectName("KpiSub")
        layout.addWidget(title_label)
        layout.addWidget(value_label)
        layout.addWidget(sub_label)
        card._value_label = value_label  # type: ignore[attr-defined]
        return card

    def _set_kpi(self, card: QFrame, text: str):
        card._value_label.setText(text)  # type: ignore[attr-defined]

    def _render_active_work(self, active: list[dict]):
        while self.work_layout.count():
            item = self.work_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                # V4.3.2: ẩn + gỡ parent ngay, tránh widget cũ vẽ
                # chồng trong lúc chờ deleteLater.
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        if not active:
            empty = QLabel("Không có công việc nào đang chạy — lệnh mới sẽ hiện ở đây kèm tiến độ từng bước.")
            empty.setObjectName("EmptyState")
            empty.setWordWrap(True)
            self.work_layout.addWidget(empty)
            return
        try:
            agent_names = {
                a["id"]: a["name"] for a in self._store.list_agents()
            }
        except Exception:
            agent_names = {}
        for command in active:
            row = QWidget()
            row_layout = QVBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(3)
            type_label = COMMAND_TYPE_LABELS.get(command["type"], command["type"])
            status_label = _ACTIVE_STATUS_LABELS.get(command["status"], command["status"])
            agent_name = agent_names.get(command.get("agent_id"))
            prefix = f"🤖 {agent_name} · " if agent_name else ""
            title = QLabel(
                f"{prefix}{type_label} · {command['profile_slug'] or '—'} — {status_label}"
            )
            title.setObjectName("Muted")
            title.setWordWrap(True)
            row_layout.addWidget(title)
            percent = int(command.get("progress") or 0)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(percent)
            step = (command.get("step") or "").strip()
            detail = step or (command.get("instruction") or "").strip()
            bar.setFormat(f"{percent}% — {detail}" if detail else f"{percent}%")
            if step:
                bar.setToolTip(step)
            row_layout.addWidget(bar)
            self.work_layout.addWidget(row)

    # ------------------------------------------------------------------ #
    def refresh(self):
        try:
            stats = self._store.stats()
            entries = self._store.list_journal(limit=15)
            active = self._store.list_active_commands(limit=6)
        except Exception as exc:
            self.banner_text.setText(f"Không đọc được dữ liệu tổng quan: {exc}")
            self.banner.show()
            return
        self.banner.hide()
        self._render_active_work(active)
        self._set_kpi(self.kpi_channels, f"{stats['channels']:,}")
        self._set_kpi(self.kpi_subs, f"{stats['subscribers']:,}")
        self._set_kpi(self.kpi_scheduled, f"{stats['videos_scheduled']:,}")
        self._set_kpi(
            self.kpi_commands,
            f"{stats['commands_pending']} / {stats['commands_running']}",
        )
        # Dọn dòng hoạt động cũ.
        while self.feed_layout.count():
            item = self.feed_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        if not entries:
            empty = QLabel("Chưa có hoạt động nào được ghi lại.")
            empty.setObjectName("EmptyState")
            self.feed_layout.addWidget(empty)
            return
        for entry in reversed(entries):  # mới nhất lên trên
            row = QLabel(f"[{_fmt_ts(entry['ts'])}]  {entry['message']}")
            row.setObjectName("Muted")
            row.setWordWrap(True)
            row.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.feed_layout.addWidget(row)
        self.feed_layout.addStretch(1)  # dồn dòng lên trên, không giãn đều


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m %H:%M")
    except ValueError:
        return str(value)
