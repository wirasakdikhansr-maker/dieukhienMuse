"""Hộp thoại nhỏ của app."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)


def split_login_line(text: str) -> tuple[str, str]:
    """Tách dòng dán nhanh dạng 'ten@gmail.com|matkhau' -> (gmail,
    mật khẩu). Không có '|' thì cả dòng là gmail, mật khẩu rỗng."""
    raw = (text or "").strip()
    if "|" not in raw:
        return raw, ""
    gmail, password = raw.split("|", 1)
    return gmail.strip(), password.strip()


class AddProfileDialog(QDialog):
    """Form thêm hồ sơ: nhãn + Gmail (+ ghi chú), kèm sẵn phần ĐĂNG
    NHẬP (V3.4): dán nhanh 'email|matkhau', mật khẩu lưu để app tự
    đăng nhập, và/hoặc file cookies có sẵn. Có cookies thì app đăng
    nhập bằng cookies; không có thì dùng gmail + mật khẩu đã lưu.

    V5.3.2 (M-PROFILE-EDIT): cùng hộp thoại này phục vụ cả SỬA hồ
    sơ — truyền `profile` (dict hồ sơ hiện có) thì form mở ở chế
    độ sửa: điền sẵn nhãn/Gmail/ghi chú, tiêu đề + nút chính đổi
    thành sửa/lưu. KHÔNG có hộp thoại sửa thứ hai; mật khẩu không
    bao giờ được nạp ngược ra form (để trống = giữ nguyên mật
    khẩu đã lưu trong kho riêng)."""

    def __init__(self, parent=None, profile: dict | None = None):
        super().__init__(parent)
        self._editing = profile is not None
        self.setWindowTitle("Sửa hồ sơ" if self._editing else "Thêm hồ sơ")
        self.setMinimumWidth(460)
        self._cookies_path = ""
        self.label_edit = QLineEdit()
        self.label_edit.setPlaceholderText("Ví dụ: AwakeInTheDark")
        self.gmail_edit = QLineEdit()
        self.gmail_edit.setPlaceholderText("Ví dụ: example@gmail.com")
        self.note_edit = QLineEdit()
        self.note_edit.setPlaceholderText("Không bắt buộc")
        if profile is not None:
            self.label_edit.setText(profile.get("label") or "")
            self.gmail_edit.setText(profile.get("gmail") or "")
            self.note_edit.setText(profile.get("note") or "")

        self.login_line_edit = QLineEdit()
        self.login_line_edit.setPlaceholderText("ten@gmail.com|matkhau — dán vào là tự tách")
        self.login_line_edit.textChanged.connect(self._apply_login_line)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_edit.setPlaceholderText(
            "Để trống nếu giữ nguyên mật khẩu đã lưu"
            if self._editing
            else "Tuỳ chọn — lưu trên máy này để app tự đăng nhập"
        )
        self.cookies_label = QLabel("Chưa chọn file cookies")
        self.cookies_label.setObjectName("Muted")
        cookies_button = QPushButton("Chọn file cookies…")
        cookies_button.clicked.connect(self._choose_cookies)
        cookies_row = QHBoxLayout()
        cookies_row.addWidget(cookies_button)
        cookies_row.addWidget(self.cookies_label, 1)

        # V7.0: NỀN TẢNG — YouTube (Gmail) · Facebook / TikTok (đăng nhập bằng cookie)
        from PySide6.QtWidgets import QComboBox as _Combo, QPlainTextEdit as _Plain

        from .. import platforms as _platforms

        self.platform_combo = _Combo()
        for key in _platforms.ORDER:
            meta = _platforms.info(key)
            self.platform_combo.addItem(f"{meta['icon']}  {meta['label']}", key)
        current = _platforms.of(profile) if profile is not None else "youtube"
        self.platform_combo.setCurrentIndex(max(0, list(_platforms.ORDER).index(current)))
        self.platform_combo.setEnabled(not self._editing)
        self.cookie_text = _Plain()
        self.cookie_text.setPlaceholderText(
            "Dán cookie Facebook/TikTok: chuỗi 'c_user=…; xs=…; datr=…' hoặc JSON (EditThisCookie/J2TEAM) "
            "hoặc nội dung cookies.txt — app lọc đúng domain, chỉ lưu trên máy này.")
        self.cookie_text.setMaximumHeight(90)
        self.platform_combo.currentIndexChanged.connect(self._sync_platform)

        form = QFormLayout()
        self._form = form
        form.addRow("Nền tảng", self.platform_combo)
        form.addRow("Nhãn hồ sơ *", self.label_edit)
        form.addRow("Gmail *", self.gmail_edit)
        form.addRow("Ghi chú", self.note_edit)
        form.addRow("Dán nhanh tài khoản", self.login_line_edit)
        form.addRow("Mật khẩu", self.password_edit)
        form.addRow("Cookies có sẵn", cookies_row)
        form.addRow("Dán cookie", self.cookie_text)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        ok_button = buttons.button(QDialogButtonBox.Ok)
        if ok_button is not None:
            ok_button.setProperty("variant", "primary")
            ok_button.setText("Lưu thay đổi" if self._editing else "Thêm hồ sơ")
        cancel_button = buttons.button(QDialogButtonBox.Cancel)
        if cancel_button is not None:
            cancel_button.setText("Huỷ")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(14)
        layout.addLayout(form)
        layout.addWidget(buttons)
        self._sync_platform()

    def platform(self) -> str:
        return str(self.platform_combo.currentData() or "youtube")

    def _sync_platform(self, *_args):
        social = self.platform() != "youtube"
        label = self._form.labelForField(self.gmail_edit)
        if label is not None:
            label.setText("Email/ID tài khoản *" if social else "Gmail *")
        self.gmail_edit.setPlaceholderText("Email hoặc ID tài khoản Facebook/TikTok" if social
                                           else "Ví dụ: example@gmail.com")
        for widget in (self.cookie_text, self._form.labelForField(self.cookie_text)):
            if widget is not None:
                widget.setVisible(social)
        for widget in (self.login_line_edit, self.password_edit,
                       self._form.labelForField(self.login_line_edit), self._form.labelForField(self.password_edit)):
            if widget is not None:
                widget.setVisible(not social)

    def _apply_login_line(self, text: str):
        gmail, password = split_login_line(text)
        if gmail:
            self.gmail_edit.setText(gmail)
        if password:
            self.password_edit.setText(password)

    def _choose_cookies(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn file cookies",
            "",
            "Cookies (*.json *.txt);;Tất cả các file (*)",
        )
        if path:
            self._cookies_path = path
            self.cookies_label.setText(path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1])

    def _accept(self):
        if not self.label_edit.text().strip() or not self.gmail_edit.text().strip():
            QMessageBox.warning(self, "Thiếu thông tin", "Nhãn hồ sơ và Gmail là bắt buộc.")
            return
        self.accept()

    def values(self) -> tuple[str, str, str]:
        return (
            self.label_edit.text().strip(),
            self.gmail_edit.text().strip(),
            self.note_edit.text().strip(),
        )

    def details(self) -> dict:
        """Toàn bộ dữ liệu form, gồm phần đăng nhập (mật khẩu + file
        cookies) — mật khẩu chỉ đi vào kho riêng của hồ sơ, không log."""
        label, gmail, note = self.values()
        return {
            "label": label,
            "gmail": gmail,
            "note": note,
            "password": self.password_edit.text() if self.platform() == "youtube" else "",
            "cookies_path": self._cookies_path,
            "platform": self.platform(),
            "cookie_text": self.cookie_text.toPlainText().strip(),
        }


class AgentPickerDialog(QDialog):
    """Chọn tài khoản Muse nhận lệnh (V4.1.1) — dùng cho nút "🎯 Đổi
    Muse nhận lệnh…" ở tab Lệnh: người dùng chỉ định thẳng Muse nào
    làm một lệnh đang chờ, không phải sang tab Tài khoản Muse phân
    công trước. ``agents``: danh sách agent (nơi gọi đã lọc revoked);
    ``current_agent_id``: Muse đang ghi danh trên lệnh (chọn sẵn)."""

    def __init__(self, agents: list[dict], current_agent_id=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Đổi Muse nhận lệnh")
        self.setMinimumWidth(420)
        label = QLabel(
            "Chọn tài khoản Muse sẽ nhận lệnh này. App sẽ ghi danh "
            "lệnh cho Muse đó và phân công hồ sơ đích cho Muse đó "
            "phụ trách (nếu chưa có) để dispatcher giao đúng người."
        )
        label.setWordWrap(True)
        self.agent_combo = QComboBox()
        for agent in agents:
            self.agent_combo.addItem(
                f"{agent['name']} — {agent['email']}", agent["id"]
            )
        if current_agent_id is not None:
            index = self.agent_combo.findData(current_agent_id)
            if index >= 0:
                self.agent_combo.setCurrentIndex(index)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        ok_button = buttons.button(QDialogButtonBox.Ok)
        if ok_button is not None:
            ok_button.setProperty("variant", "primary")
            ok_button.setText("🎯 Giao cho Muse này")
        cancel_button = buttons.button(QDialogButtonBox.Cancel)
        if cancel_button is not None:
            cancel_button.setText("Huỷ")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(18, 16, 18, 16)
        layout.setSpacing(14)
        layout.addWidget(label)
        layout.addWidget(self.agent_combo)
        layout.addWidget(buttons)

    def selected_agent_id(self):
        return self.agent_combo.currentData()
