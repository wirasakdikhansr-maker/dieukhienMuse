"""Bề rộng cột bảng: kéo chỉnh tự do + TỰ LƯU theo từng bảng (V4.3.2 — F7).

Yêu cầu nguyên văn của người dùng sau nghiệm thu máy thật: "tất cả
các cột của tất cả các bảng các tab đều chỉnh sửa tùy ý bề rộng các
cột tự do và tự lưu lại". Module này gắn cho MỌI QTableWidget (và
cây dạng cột QTreeWidget) trong app:

- Mọi cột nội dung chuyển sang ``Interactive`` — người dùng kéo
  mép cột để đổi bề rộng tuỳ ý. Chỉ cột cố định THẬT cần thiết
  (đánh dấu qua ``fixed_columns``: ô avatar 38px, cột nút thao tác)
  mới giữ ``Fixed``.
- Bề rộng đã kéo được lưu vào settings theo khóa riêng của bảng
  (``col_widths_<key>``) khi kéo xong (debounce 400ms) và NẠP LẠI
  khi bảng dựng — mở lại app là giữ nguyên như đã chỉnh.
- Bảng có ``objectName`` ổn định = ``key`` để định danh lâu dài.
"""

from __future__ import annotations

import contextlib

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QHeaderView, QTableWidget, QTreeWidget

from .. import config


@contextlib.contextmanager
def batch_update(widget):
    """Nạp dữ liệu hàng loạt vào bảng (V4.3.2 — F4): tắt repaint +
    chặn signals của BẢNG trong lúc nạp hàng trăm ô/widget con —
    tránh cơn mưa sơn lại từng ô trên Windows (nguồn "đơ" khi làm
    mới). Signals của widget con (nút/checkbox trong ô) KHÔNG bị
    ảnh hưởng. Luôn khôi phục trạng thái cũ khi thoát."""
    was_enabled = widget.updatesEnabled()
    was_blocked = widget.signalsBlocked()
    widget.setUpdatesEnabled(False)
    widget.blockSignals(True)
    try:
        yield
    finally:
        widget.blockSignals(was_blocked)
        widget.setUpdatesEnabled(was_enabled)
        # V6.1: bật lại cập nhật KHÔNG tự sơn lại viewport của bảng
        # (QAbstractScrollArea) — bảng vừa nạp có thể hiện TRỐNG tới khi
        # rê chuột/đổi kích thước. Ép sơn lại một lần (rẻ).
        if was_enabled:
            viewport = getattr(widget, "viewport", None)
            if callable(viewport):
                try:
                    viewport().update()
                except Exception:
                    pass
            widget.update()

_MIN_WIDTH = 24
_MAX_WIDTH = 2000


def _header_of(widget):
    if isinstance(widget, QTreeWidget):
        return widget.header()
    return widget.horizontalHeader()


def attach_column_persistence(
    widget,
    settings: dict | None,
    key: str,
    fixed_columns: tuple[int, ...] = (),
    default_widths: tuple[int, ...] = (),
):
    """Gắn kéo-chỉnh + lưu/nạp bề rộng cột cho một bảng/cây.

    ``settings``: dict settings DÙNG CHUNG của app (ghi + lưu ngay
    khi kéo xong). ``None`` → tự nạp dict từ đĩa (dùng độc lập).
    ``default_widths``: bề rộng khởi đầu — CHỈ áp khi bảng chưa có
    bề rộng đã lưu, và áp SAU khi đã chuyển cột sang Interactive:
    đặt setColumnWidth trong lúc header còn ResizeToContents/
    Stretch sẽ bị header tính lại theo nội dung nuốt mất (đã gặp
    thật ở V4.3.2 — cột mặc định 230px bị co về 133px).
    Trả về header đã cấu hình."""
    if settings is None:
        settings = config.load_settings()
    widget.setObjectName(key)
    header = _header_of(widget)
    header.setStretchLastSection(False)
    count = (
        widget.columnCount()
        if isinstance(widget, (QTableWidget, QTreeWidget))
        else header.count()
    )
    for index in range(count):
        if index in fixed_columns:
            header.setSectionResizeMode(index, QHeaderView.ResizeMode.Fixed)
        else:
            header.setSectionResizeMode(
                index, QHeaderView.ResizeMode.Interactive
            )

    settings_key = f"col_widths_{key}"
    saved = settings.get(settings_key)
    restoring = {"active": False}
    if isinstance(saved, list) and saved:
        restoring["active"] = True
        try:
            for index, width in enumerate(saved[:count]):
                try:
                    width = int(width)
                except (TypeError, ValueError):
                    continue
                if _MIN_WIDTH <= width <= _MAX_WIDTH:
                    widget.setColumnWidth(index, width)
        finally:
            restoring["active"] = False
    elif default_widths:
        for index, width in enumerate(default_widths[:count]):
            widget.setColumnWidth(index, int(width))

    timer = QTimer(widget)
    timer.setSingleShot(True)
    timer.setInterval(400)

    def _save():
        widths = [header.sectionSize(i) for i in range(header.count())]
        if widths and widths != settings.get(settings_key):
            settings[settings_key] = widths
            config.save_settings(settings)

    timer.timeout.connect(_save)

    def _on_resized(*_args):
        if not restoring["active"]:
            timer.start()

    header.sectionResized.connect(_on_resized)
    # Giữ tham chiếu timer trên widget để không bị thu gom.
    widget._col_persist_timer = timer  # type: ignore[attr-defined]
    return header
