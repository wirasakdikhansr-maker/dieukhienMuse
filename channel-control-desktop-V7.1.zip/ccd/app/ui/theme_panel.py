"""Khối "🎨 Giao diện" trong mục Hệ thống (V4.3 — G4).

Người dùng tự chỉnh diện mạo app: preset có sẵn (MetaMint = giao
diện mặc định hiện tại, Mission Control cũ, Sáng, Tương phản cao,
Diorama) hoặc tinh chỉnh
từng token — màu nền, ảnh nền, màu nút chính (accent), màu viền, bo
góc, độ sáng, font chữ, cỡ chữ — cộng preset RIÊNG lưu trong
settings. Mọi thay đổi ÁP DỤNG NGAY toàn app qua callback
``apply_theme(tokens)`` của cửa sổ chính (QSS tập trung sinh từ
tokens trong ``app.ui.theme``), không cần khởi động lại.

Ảnh nền: file được SAO vào ``data/themes/`` của app (không tham
chiếu file ngoài — di chuyển thư mục app là ảnh vẫn theo), cửa sổ
chính áp nó ở mức trang trí (xem MainWindow._apply_theme).
"""

from __future__ import annotations

import shutil
from dataclasses import replace
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtWidgets import (
    QButtonGroup,
    QColorDialog,
    QComboBox,
    QFileDialog,
    QFontComboBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from .. import config
from . import theme

PRESET_LABELS = {
    "metamint": "AI Studio (mặc định)",
    "mission": "Mission Control (cũ)",
    "light": "Sáng",
    "contrast": "Tương phản cao",
    "diorama": "Diorama",
}


class _ColorButton(QPushButton):
    """Nút hiển thị một màu (nền = màu hiện tại), bấm để mở bảng chọn."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._color = "#000000"
        self.setFixedSize(44, 26)

    def set_color(self, value: str):
        self._color = value or "#000000"
        self.setStyleSheet(
            f"background:{self._color}; border:1px solid {theme.BORDER};"
            " border-radius:6px;"
        )

    def color(self) -> str:
        return self._color


class ThemePanel(QWidget):
    def __init__(self, settings: dict, apply_theme=None, notify=None, parent=None):
        super().__init__(parent)
        self._settings = settings
        self._apply_theme = apply_theme or (lambda _tokens: None)
        self._notify = notify or (lambda _line: None)
        self._tokens = self._load_tokens()
        self._syncing = False
        # V4.3.2 (F4): kéo slider KHÔNG áp theme ngay từng tick —
        # mỗi lần áp là một lần setStyleSheet TOÀN APP (đo được
        # ~1.9 giây trên cửa sổ đầy đủ widget) nên kéo 20 tick là
        # app đơ đúng như người dùng phàn nàn. Gom các tick trong
        # 120ms yên ắng rồi áp MỘT lần với giá trị cuối; xem trước
        # trong panel vẫn cập nhật tức thì theo từng tick.
        self._apply_timer = QTimer(self)
        self._apply_timer.setSingleShot(True)
        self._apply_timer.setInterval(120)
        self._apply_timer.timeout.connect(self._flush_apply)
        self._build_ui()
        self._sync_controls()
        self._update_preview()

    def _flush_apply(self):
        self._apply_theme(self._tokens)

    # ------------------------------------------------------------------ #
    def _load_tokens(self) -> theme.ThemeTokens:
        # Cùng đường KỶ NGUYÊN với cửa sổ chính (V5.1): cửa sổ chính
        # đã áp epoch lúc khởi động nên ở đây epoch đã khớp và hàm
        # chỉ đọc token đang hiệu lực; panel dựng độc lập (kiểm thử)
        # thì epoch tự áp tại chỗ, nhất quán hai bề mặt.
        tokens, _changed = theme.apply_theme_epoch(self._settings)
        return tokens

    def refresh(self):
        self._tokens = self._load_tokens()
        self._sync_controls()
        self._update_preview()

    # ------------------------------------------------------------------ #
    # Dựng giao diện
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        # V4.3.2 (F3 — nghiệm thu máy thật): panel GỌN — lưới 2 cột
        # nhãn|điều khiển với cột điều khiển RỘNG VỪA (slider 300px,
        # không kéo dài toàn cửa sổ), khoảng giãn dọc nhỏ, bỏ caption
        # dài; khối xem trước nằm cạnh phải, nội dung ôm lên trên.
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(8)
        root.addWidget(theme.section_header("🎨 Giao diện — tuỳ chỉnh diện mạo app"))

        preset_row = QHBoxLayout()
        preset_row.setSpacing(6)
        preset_row.addWidget(theme.muted_label("Preset:"))
        self._preset_group = QButtonGroup(self)
        self._preset_group.setExclusive(True)
        self._preset_buttons: dict[str, QPushButton] = {}
        for key, label in PRESET_LABELS.items():
            button = QPushButton(label)
            button.setCheckable(True)
            button.clicked.connect(lambda _c=False, k=key: self._on_preset(k))
            self._preset_group.addButton(button)
            self._preset_buttons[key] = button
            preset_row.addWidget(button)
        self.custom_preset_combo = QComboBox()
        self.custom_preset_combo.setToolTip("Preset riêng đã lưu")
        self.custom_preset_combo.currentIndexChanged.connect(
            self._on_custom_preset
        )
        preset_row.addWidget(self.custom_preset_combo)
        self.save_preset_button = QPushButton("💾 Lưu preset riêng")
        self.save_preset_button.clicked.connect(self._on_save_custom_preset)
        preset_row.addWidget(self.save_preset_button)
        preset_row.addStretch(1)
        root.addLayout(preset_row)

        # V5.1 (plan §1.2): hai nút KỶ NGUYÊN GIAO DIỆN — khôi phục
        # bộ màu TRƯỚC V5.1 (đã sao lưu lúc bản này chạy lần đầu)
        # và áp lại bộ V5.1 khi đã khôi phục/đã nghịch màu. Sao lưu
        # không có (cài mới tinh) thì nút khôi phục tự vô hiệu.
        epoch_row = QHBoxLayout()
        epoch_row.setSpacing(6)
        epoch_row.addWidget(theme.muted_label("Giao diện V5.1:"))
        self.apply_v51_button = QPushButton("✨ Áp dụng giao diện V5.1")
        self.apply_v51_button.setProperty("variant", "primary")
        self.apply_v51_button.setToolTip(
            "Áp bộ màu theo phương án thiết kế V5.1 đã duyệt "
            "(nền #0C0D0F, nhấn xanh #CEFC19, panel bo 20px)."
        )
        self.apply_v51_button.clicked.connect(self._on_apply_v51)
        epoch_row.addWidget(self.apply_v51_button)
        self.restore_pre51_button = QPushButton(
            "↩ Khôi phục giao diện trước V5.1"
        )
        self.restore_pre51_button.setToolTip(
            "Quay lại đúng bộ màu bạn dùng TRƯỚC khi V5.1 áp giao "
            "diện mới (bản sao lưu tự động, không mất lựa chọn cũ)."
        )
        self.restore_pre51_button.clicked.connect(self._on_restore_pre51)
        epoch_row.addWidget(self.restore_pre51_button)
        epoch_row.addStretch(1)
        root.addLayout(epoch_row)

        body = QHBoxLayout()
        body.setSpacing(20)
        body.setAlignment(Qt.AlignTop)
        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(6)
        grid.setColumnMinimumWidth(0, 150)
        row = 0
        self.bg_button = self._color_row(
            grid, row, "Màu nền", lambda c: self._set_token(bg=c)
        )
        row += 1
        # V5.3.1 (M4): nhãn nói RÕ "cửa sổ" — trước đây hàng này
        # ghi chung chung "Ảnh nền" nằm ngay trên hàng "Nền Văn
        # phòng", cả hai cùng nút "🖼 Chọn ảnh…": chọn nhầm hàng
        # trên là đổi nền CỬA SỔ, tab Văn phòng không đổi gì nên
        # trông như tính năng nền Văn phòng hỏng.
        grid.addWidget(theme.muted_label("Ảnh nền cửa sổ"), row, 0)
        image_box = QHBoxLayout()
        image_box.setSpacing(6)
        self.bg_image_button = QPushButton("🖼 Chọn ảnh…")
        self.bg_image_button.setToolTip(
            "Ảnh nền cho CỬA SỔ chính của app — KHÔNG phải nền "
            "tab Văn phòng (nền Văn phòng ở hàng ngay dưới)."
        )
        self.bg_image_button.clicked.connect(self._on_pick_bg_image)
        image_box.addWidget(self.bg_image_button)
        self.bg_image_clear = QPushButton("Xoá")
        self.bg_image_clear.clicked.connect(self._on_clear_bg_image)
        image_box.addWidget(self.bg_image_clear)
        self.bg_image_label = QLabel("")
        self.bg_image_label.setObjectName("Faint12")
        image_box.addWidget(self.bg_image_label)
        image_box.addStretch(1)
        grid.addLayout(image_box, row, 1)
        row += 1
        # V5.3 (A9): nền VĂN PHÒNG đổi được — ảnh chọn được sao
        # vào data/office_bg/, đường dẫn lưu ở setting
        # office_bg_image; scene Văn phòng dùng ảnh đó qua cùng
        # đường cover-crop với nền đóng gói, nạp lỗi tự fallback.
        grid.addWidget(theme.muted_label("Nền Văn phòng"), row, 0)
        office_box = QHBoxLayout()
        office_box.setSpacing(6)
        self.office_bg_button = QPushButton("🖼 Chọn ảnh nền Văn phòng…")
        self.office_bg_button.setToolTip(
            "Chọn ảnh làm nền cho cảnh Văn phòng (robot) — ảnh "
            "được sao vào thư mục data của app nên xoá file gốc "
            "cũng không sao."
        )
        self.office_bg_button.clicked.connect(self._on_pick_office_bg)
        office_box.addWidget(self.office_bg_button)
        self.office_bg_reset = QPushButton("↩ Mặc định")
        self.office_bg_reset.setToolTip(
            "Bỏ ảnh tuỳ chọn, quay về nền Văn phòng đóng gói sẵn."
        )
        self.office_bg_reset.clicked.connect(self._on_reset_office_bg)
        office_box.addWidget(self.office_bg_reset)
        self.office_bg_label = QLabel("")
        self.office_bg_label.setObjectName("Faint12")
        office_box.addWidget(self.office_bg_label)
        office_box.addStretch(1)
        grid.addLayout(office_box, row, 1)
        row += 1
        self.accent_button = self._color_row(
            grid, row, "Màu nút chính (accent)",
            lambda c: self._set_token(accent=c),
        )
        row += 1
        self.border_button = self._color_row(
            grid, row, "Màu viền", lambda c: self._set_token(border=c)
        )
        row += 1
        self.radius_slider = self._slider_row(
            grid, row, "Bo góc", 0, 28, self._on_radius
        )
        row += 1
        self.brightness_slider = self._slider_row(
            grid, row, "Độ sáng (%)", 50, 150, self._on_brightness
        )
        row += 1
        grid.addWidget(theme.muted_label("Font chữ"), row, 0)
        self.font_combo = QFontComboBox()
        self.font_combo.setFixedWidth(300)
        self.font_combo.currentFontChanged.connect(self._on_font)
        grid.addWidget(self.font_combo, row, 1)
        row += 1
        self.font_scale_slider = self._slider_row(
            grid, row, "Cỡ chữ (%)", 90, 120, self._on_font_scale
        )
        body.addLayout(grid)

        preview_box = QVBoxLayout()
        preview_box.setSpacing(6)
        preview_box.addWidget(theme.muted_label("Xem trước"))
        self.preview_frame = QFrame()
        self.preview_frame.setObjectName("Panel")
        self.preview_frame.setMaximumWidth(480)
        preview_layout = QVBoxLayout(self.preview_frame)
        preview_layout.setContentsMargins(12, 10, 12, 10)
        preview_layout.setSpacing(6)
        title = QLabel("Thẻ mẫu — tiêu đề")
        title.setObjectName("CardTitle")
        preview_layout.addWidget(title)
        preview_layout.addWidget(QLabel("Dòng chữ thường để xem font + cỡ chữ."))
        muted = QLabel("Dòng chữ mờ phụ.")
        muted.setObjectName("Muted")
        preview_layout.addWidget(muted)
        buttons = QHBoxLayout()
        primary = QPushButton("Nút chính")
        primary.setProperty("variant", "primary")
        buttons.addWidget(primary)
        buttons.addWidget(QPushButton("Nút thường"))
        buttons.addStretch(1)
        preview_layout.addLayout(buttons)
        preview_box.addWidget(self.preview_frame)
        preview_box.addStretch(1)
        body.addLayout(preview_box)
        body.addStretch(1)
        root.addLayout(body)
        root.addStretch(1)

    def _color_row(self, grid: QGridLayout, row: int, label: str,
                   on_pick) -> _ColorButton:
        grid.addWidget(theme.muted_label(label), row, 0)
        button = _ColorButton()
        button.clicked.connect(lambda: self._pick_color(button, on_pick))
        grid.addWidget(button, row, 1)
        return button

    def _slider_row(self, grid: QGridLayout, row: int, label: str,
                    lo: int, hi: int, on_change) -> QSlider:
        grid.addWidget(theme.muted_label(label), row, 0)
        cell = QHBoxLayout()
        cell.setSpacing(8)
        slider = QSlider(Qt.Horizontal)
        slider.setRange(lo, hi)
        slider.setFixedWidth(300)
        slider.valueChanged.connect(on_change)
        cell.addWidget(slider)
        value_label = QLabel("")
        value_label.setObjectName("Faint12")
        value_label.setFixedWidth(34)
        slider.valueChanged.connect(
            lambda v: value_label.setText(str(v))
        )
        cell.addWidget(value_label)
        cell.addStretch(1)
        grid.addLayout(cell, row, 1)
        return slider

    # ------------------------------------------------------------------ #
    # Đồng bộ điều khiển ↔ tokens
    # ------------------------------------------------------------------ #
    def _sync_controls(self):
        self._syncing = True
        try:
            tokens = self._tokens
            self.bg_button.set_color(tokens.bg)
            self.accent_button.set_color(tokens.accent)
            self.border_button.set_color(tokens.border)
            self.radius_slider.setValue(int(tokens.radius))
            self.brightness_slider.setValue(round(tokens.brightness * 100))
            self.font_scale_slider.setValue(round(tokens.font_scale * 100))
            if tokens.font_family:
                from PySide6.QtGui import QFont

                self.font_combo.setCurrentFont(QFont(tokens.font_family))
            self.bg_image_label.setText(
                Path(tokens.bg_image).name if tokens.bg_image else "— chưa có ảnh —"
            )
            self._sync_office_bg_label()
            matched = None
            for key, preset in theme.PRESETS.items():
                if theme.tokens_to_dict(preset) == theme.tokens_to_dict(tokens):
                    matched = key
                    break
            for key, button in self._preset_buttons.items():
                button.setChecked(key == matched)
            self._reload_custom_combo()
            self._sync_epoch_buttons()
        finally:
            self._syncing = False

    def _reload_custom_combo(self):
        customs = self._settings.get("theme_custom_presets") or {}
        self.custom_preset_combo.blockSignals(True)
        try:
            self.custom_preset_combo.clear()
            self.custom_preset_combo.addItem("— Preset riêng —", None)
            for name in sorted(customs):
                self.custom_preset_combo.addItem(f"⭐ {name}", name)
        finally:
            self.custom_preset_combo.blockSignals(False)

    # ------------------------------------------------------------------ #
    # Thay đổi tokens → áp dụng ngay + xem trước
    # ------------------------------------------------------------------ #
    def _set_token(self, defer_apply: bool = False, **changes):
        if self._syncing:
            return
        self._tokens = replace(self._tokens, **changes)
        self._settings["theme_preset"] = "custom"
        if defer_apply:
            # Kéo slider: chỉ hẹn áp MỘT lần khi đã yên tay (F4).
            self._apply_timer.start()
        else:
            self._apply_timer.stop()
            self._apply_theme(self._tokens)
        self._sync_controls()
        self._update_preview()

    def _update_preview(self):
        self.preview_frame.setStyleSheet(theme.build_qss(self._tokens))

    def _pick_color(self, button: _ColorButton, on_pick):
        chosen = QColorDialog.getColor(
            QColor(button.color()), self, "Chọn màu"
        )
        if chosen.isValid():
            on_pick(chosen.name().upper())

    # ------------------------------------------------------------------ #
    # V5.1 — Kỷ nguyên giao diện: áp V5.1 / khôi phục trước V5.1
    # ------------------------------------------------------------------ #
    def _sync_epoch_buttons(self):
        backup = self._settings.get(theme.THEME_BACKUP_KEY)
        self.restore_pre51_button.setEnabled(
            isinstance(backup, dict) and bool(backup)
        )

    def _on_apply_v51(self):
        if self._syncing:
            return
        self._tokens = theme.apply_v51_theme(self._settings)
        self._settings["theme_preset"] = "metamint"
        config.save_settings(self._settings)
        self._apply_theme(self._tokens)
        self._sync_controls()
        self._update_preview()
        self._notify("🎨 Đã áp giao diện V5.1 (phương án thiết kế đã duyệt).")

    def _on_restore_pre51(self):
        if self._syncing:
            return
        tokens = theme.restore_theme_backup(self._settings)
        if tokens is None:
            self._notify(
                "Chưa có bản sao lưu giao diện trước V5.1 "
                "(bản này được cài mới hoặc chưa từng chạy bản cũ)."
            )
            return
        self._tokens = tokens
        self._settings["theme_preset"] = "custom"
        config.save_settings(self._settings)
        self._apply_theme(self._tokens)
        self._sync_controls()
        self._update_preview()
        self._notify("🎨 Đã khôi phục giao diện trước V5.1 (từ bản sao lưu).")

    def _on_preset(self, key: str):
        if self._syncing:
            return
        self._tokens = theme.PRESETS[key]
        self._settings["theme_preset"] = key
        self._apply_theme(self._tokens)
        self._sync_controls()
        self._update_preview()
        self._notify(f"🎨 Đã áp preset giao diện “{PRESET_LABELS[key]}”.")

    def _on_custom_preset(self, index: int):
        name = self.custom_preset_combo.itemData(index)
        if not name or self._syncing:
            return
        customs = self._settings.get("theme_custom_presets") or {}
        data = customs.get(name)
        if isinstance(data, dict):
            self._tokens = theme.tokens_from_dict(data)
            self._settings["theme_preset"] = "custom"
            self._apply_theme(self._tokens)
            self._sync_controls()
            self._update_preview()
            self._sync_controls()
            self._update_preview()

    def _on_save_custom_preset(self):
        name, accepted = QInputDialog.getText(
            self, "Lưu preset riêng", "Tên preset:"
        )
        if not accepted or not name.strip():
            return
        customs = dict(self._settings.get("theme_custom_presets") or {})
        customs[name.strip()] = theme.tokens_to_dict(self._tokens)
        self._settings["theme_custom_presets"] = customs
        config.save_settings(self._settings)
        self._reload_custom_combo()
        self._notify(f"🎨 Đã lưu preset riêng “{name.strip()}”.")

    def _on_pick_bg_image(self):
        chosen, _ = QFileDialog.getOpenFileName(
            self, "Chọn ảnh nền", "",
            "Ảnh (*.png *.jpg *.jpeg *.bmp *.webp)",
        )
        if not chosen:
            return
        folder = config.data_dir() / "themes"
        folder.mkdir(parents=True, exist_ok=True)
        source = Path(chosen)
        dest = folder / source.name
        try:
            if source.resolve() != dest.resolve():
                shutil.copyfile(source, dest)
        except OSError as exc:
            self._notify(f"⚠ Không sao được ảnh nền: {exc}")
            return
        self._set_token(bg_image=str(dest))
        self._notify(f"🎨 Đã đặt ảnh nền: {dest.name} (lưu trong data/themes/).")

    def _on_clear_bg_image(self):
        self._set_token(bg_image="")

    # ---- Nền Văn phòng (V5.3 A9) ---------------------------------- #
    def _sync_office_bg_label(self):
        path = str(self._settings.get("office_bg_image") or "")
        self.office_bg_label.setText(
            Path(path).name if path else "(mặc định)"
        )
        self.office_bg_reset.setEnabled(bool(path))

    def _set_office_bg(self, path: str):
        self._settings["office_bg_image"] = path
        config.save_settings(self._settings)
        theme.set_office_background_path(path or None)
        self._sync_office_bg_label()

    def _on_pick_office_bg(self):
        chosen, _ = QFileDialog.getOpenFileName(
            self, "Chọn ảnh nền Văn phòng", "",
            "Ảnh (*.png *.jpg *.jpeg *.bmp *.webp)",
        )
        if not chosen:
            return
        folder = config.data_dir() / "office_bg"
        folder.mkdir(parents=True, exist_ok=True)
        source = Path(chosen)
        dest = folder / source.name
        copied = False
        try:
            if source.resolve() != dest.resolve():
                shutil.copyfile(source, dest)
                copied = True
        except OSError as exc:
            self._notify(f"⚠ Không sao được ảnh nền Văn phòng: {exc}")
            return
        # V5.3.1 (M4): KIỂM CHỨNG ảnh nạp được TRƯỚC khi báo thành
        # công. Bản V5.3 lưu setting + báo "Đã đặt" vô điều kiện
        # sau khi sao file — nếu Qt không đọc được ảnh (định dạng
        # lạ/hỏng), theme.office_background_pixmap() lặng lẽ quay
        # về ảnh đóng gói và người dùng thấy "không đổi gì" dù app
        # vừa báo thành công (báo cáo sai sự thật). Nay: nạp thử
        # ngay tại đây; hỏng thì KHÔNG lưu setting, dọn file vừa
        # sao, và báo rõ lỗi + cách khắc phục.
        if QPixmap(str(dest)).isNull():
            if copied:
                try:
                    dest.unlink()
                except OSError:
                    pass
            self._notify(
                f"⚠ Ảnh '{source.name}' không đọc được nên CHƯA đặt "
                "làm nền Văn phòng. File có thể bị hỏng hoặc ở định "
                "dạng Qt không hỗ trợ — hãy chọn ảnh PNG hoặc JPG "
                "khác rồi thử lại."
            )
            return
        self._set_office_bg(str(dest))
        self._notify(
            f"🎨 Đã đặt nền Văn phòng: {dest.name} "
            "(lưu trong data/office_bg/)."
        )

    def _on_reset_office_bg(self):
        self._set_office_bg("")
        self._notify("🎨 Đã khôi phục nền Văn phòng mặc định.")

    def _on_radius(self, value: int):
        self._set_token(radius=int(value), defer_apply=True)

    def _on_brightness(self, value: int):
        self._set_token(brightness=value / 100.0, defer_apply=True)

    def _on_font(self, font):
        self._set_token(font_family=font.family())

    def _on_font_scale(self, value: int):
        self._set_token(font_scale=value / 100.0, defer_apply=True)
