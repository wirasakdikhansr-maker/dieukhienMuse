"""Theme — lớp trình bày dùng chung cho toàn app.

Một stylesheet trung tâm (APP_QSS) + các widget factory nhỏ (tiêu đề mục,
pill trạng thái phiên, avatar hồ sơ, chấm LIVE nhấp nháy).

V4.5: bảng màu THỐNG NHẤT theo mẫu "MetaMint" (chuẩn giao diện mới):
nền gần-đen TRUNG TÍNH #090A09, panel xám-đen #171A17, thẻ #1E211D,
viền mảnh #2D332B, MỘT màu nhấn duy nhất — xanh lá #CEFC19 (tiến độ /
tab đang chọn / nút chính; chữ trên nền nhấn là chữ TỐI), chữ chính
#ECEEF1, chữ phụ #9AA0A8, chữ mờ #6F7680; bo góc LỚN (panel 16px, thẻ
14px); màu ngữ nghĩa (xong/cảnh báo/lỗi) giữ nhưng GIẢM BÃO HOÀ cùng
phong cách phẳng. Preset mặc định là "metamint"; bảng màu Concept D
của V4.3.1 còn giữ làm preset "mission" (cũ) để ai muốn quay lại.

V4.3.1 (lịch sử): Concept D — nền navy #0B1220, accent xanh dương
#2E7CF6 — đã thay bởi MetaMint ở V4.5.
"""

from __future__ import annotations

import math
import zlib

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor, QFont, QPainter
from PySide6.QtWidgets import QFrame, QLabel, QWidget

# --------------------------------------------------------------------------- #
# Bảng màu
# --------------------------------------------------------------------------- #
BG = "#0C0D0F"
PANEL = "#16171B"
CARD = "#1B1D22"
BORDER = "#26282D"
ACCENT = "#CEFC19"
ACCENT2 = "#6CC7FF"
TEXT = "#ECEEF1"
MUTED = "#9AA0A8"
FAINT = "#6F7680"
SUCCESS = "#7DDC7A"
WARNING = "#F2C94C"
DANGER = "#FF7A7A"
#: V6.3 (đồng bộ AI Studio V31.1): chữ trên nền accent, màu "đang chạy"
#: (info) và bậc panel thứ ba — cùng token với static/style.css của AI Studio.
ACCENT_INK = "#141A05"
INFO = "#6CC7FF"
PANEL3 = "#212329"
PROGRESS_TRACK = "#24262B"
PROGRESS_HEIGHT = 4
#: Màu trạng thái việc DÙNG CHUNG toàn app (pill, chấm, dải màu thẻ):
#: chờ = vàng, đang chạy = xanh dương, xong = xanh lá, lỗi = đỏ, chờ người = tím.
STATUS_COLORS = {
    "queued": WARNING, "waiting_muse": WARNING, "waiting": WARNING,
    "running": INFO, "working": INFO,
    "done": SUCCESS, "in": SUCCESS,
    "failed": DANGER, "error": DANGER, "out": DANGER,
    "needs_user": "#C4A7FF", "user": "#C4A7FF",
    "interrupted": MUTED, "cancelled": MUTED, "idle": FAINT, "offline": "#3A3D44",
}


def status_color(status: str | None) -> str:
    return STATUS_COLORS.get(str(status or ""), MUTED)


def paint_progress(painter, rect, percent: float, color: str | None = None) -> None:
    """MỘT kiểu thanh tiến độ cho mọi nơi tự vẽ (Văn phòng 2D/3D, Giám
    sát…): rãnh PROGRESS_TRACK, phần đã chạy màu accent, cao 4px, bo tròn
    — giống .pbar của AI Studio V31.1."""
    from PySide6.QtCore import QRectF
    from PySide6.QtGui import QPainterPath

    h = PROGRESS_HEIGHT
    r = QRectF(rect.x(), rect.y() + (rect.height() - h) / 2, rect.width(), h)
    track = QPainterPath()
    track.addRoundedRect(r, h / 2, h / 2)
    painter.fillPath(track, QColor(PROGRESS_TRACK))
    pct = max(0.0, min(100.0, float(percent or 0)))
    if pct > 0:
        fill = QPainterPath()
        fill.addRoundedRect(QRectF(r.x(), r.y(), max(h, r.width() * pct / 100.0), h), h / 2, h / 2)
        painter.fillPath(fill, QColor(color or ACCENT))

CARD_HOVER = "#212329"
INPUT_BG = "#121316"
#: V5.3.2 (Phương án 1 đã duyệt): nền DẢI Ô NHẬP của khung chat —
#: tối hơn nền panel (#16171B) đúng một bậc, KHÔNG viền; ô soạn
#: trong suốt đặt trên dải này, nút Gửi là viên accent đặc. Đổi
#: màu dải chat thì đổi đúng hằng này.
CHAT_COMPOSER_BG = "#121316"

#: V5.3.3 (V1 — ảnh duyệt `ui_chat_redesign_preview/
#: chat_redesign_v3.png`, chủ kênh duyệt 2026-10-30 22:56): DẢI
#: Ô NHẬP chat cao CỐ ĐỊNH ~88px, KHÔNG tự giãn khi gõ dài —
#: chiều cao suy từ LINE-HEIGHT THẬT của font (đủ 2 dòng chữ)
#: cộng chiều cao viên Gửi neo ở góc dưới và đệm dọc hai phía.
#: Đổi công thức thì đổi đúng các hằng này; AgentChatWidget ghim
#: chiều cao dải bằng `chat_composer_height(font)` một lần lúc
#: dựng, không tính lại theo nhịp refresh (bài học hiệu năng).
CHAT_COMPOSER_TEXT_LINES = 2
CHAT_COMPOSER_BUTTON_HEIGHT = 30
CHAT_COMPOSER_VPAD = 8


def chat_composer_height(font) -> int:
    """Chiều cao CỐ ĐỊNH của dải ô nhập chat (V5.3.3): 2 dòng
    chữ theo line-height thật của `font` + viên Gửi + đệm dọc.
    Đo từ font thật nên an toàn theo DPI như compact_row_height
    (không hardcode số chết); với font app hiện hành ra ~88px
    đúng ảnh duyệt."""
    from PySide6.QtGui import QFontMetrics

    line = QFontMetrics(font).lineSpacing()
    return (
        CHAT_COMPOSER_TEXT_LINES * line
        + CHAT_COMPOSER_BUTTON_HEIGHT
        + 2 * CHAT_COMPOSER_VPAD
    )
BUTTON_BG = "#212329"
BUTTON_HOVER = "#2A2C33"
BUTTON_PRESSED = "#121316"

AVATAR_COLORS = ["#4A6741", "#6B5B2E", "#7A4A2B", "#54423A", "#3F5A4C", "#5C6644", "#71362A"]

#: V5.3 (A5): đệm dọc (px) của một ô bảng — khớp 1:1 với
#: `padding: 2px 10px` của QTableWidget::item trong APP_QSS. Mọi
#: panel tính chiều cao dòng từ hằng số này để dòng bảng chỉ đủ
#: chữ + đệm 2px trên/dưới như lệnh chủ kênh. Đổi đệm QSS thì
#: đổi cả hằng số này (test_v53 ghim chúng khớp nhau).
TABLE_ITEM_VPAD = 2


def compact_row_height(font, min_content: int = 0) -> int:
    """Chiều cao dòng bảng GỌN (V5.3 — A5): vừa đủ chiều cao chữ
    của `font` + đệm dọc 2px×2 + 2px thở; nếu dòng chứa widget
    (nút trong ô) thì `min_content` là chiều cao widget đó và
    dòng cao ít nhất widget + đệm. Đo từ font thật nên an toàn
    theo DPI như bài học V3.8 (không hardcode số chết)."""
    from PySide6.QtGui import QFontMetrics

    text_height = QFontMetrics(font).height() + 2 * TABLE_ITEM_VPAD + 2
    if min_content:
        return max(text_height, min_content + 2 * TABLE_ITEM_VPAD + 2)
    return text_height


#: V5.3.1 (M2): độ cao nút HÀNG LỆNH (kiểu RowAction + nút thao
#: tác trong dòng bảng) — người dùng chỉnh trong Cài đặt → Giao
#: diện (setting row_action_button_height); mặc định 24 như lệnh
#: V5.3, dải chặn 20–36 để chữ không bao giờ bị cắt (kiểu
#: RowAction có padding dọc 0 — xem bài học §18).
ROW_ACTION_HEIGHT_DEFAULT = 24
ROW_ACTION_HEIGHT_MIN = 20
ROW_ACTION_HEIGHT_MAX = 36


def row_action_height(settings) -> int:
    """Độ cao nút hàng lệnh HIỆU LỰC từ settings (None/không có
    khoá → mặc định 24; giá trị ngoài dải → kẹp về dải). Mọi nút
    ghim 24px trước V5.3.1 (nút thao tác trong dòng bảng lệnh,
    nút Kết nối Muse…, nút trong ô bảng tài khoản) đọc QUA đây
    để một chỗ đổi là mọi nơi theo."""
    try:
        value = int((settings or {}).get(
            "row_action_button_height", ROW_ACTION_HEIGHT_DEFAULT
        ))
    except (TypeError, ValueError):
        value = ROW_ACTION_HEIGHT_DEFAULT
    return max(ROW_ACTION_HEIGHT_MIN, min(ROW_ACTION_HEIGHT_MAX, value))


def button_row_height(floor: int = 54) -> int:
    """Chiều cao dòng bảng ĐỦ chứa trọn một nút bấm trong dòng — đo từ
    chính nút mẫu theo font + padding QSS hiện hành (đã gồm hiệu ứng
    DPI), cộng đệm trên/dưới. Dùng cho mọi bảng có nút trong dòng để
    nút không bao giờ bị che/cắt (lỗi V3.8: dòng 40px trong khi nút
    cần ~36px + đệm, ở DPI 125–150% là bị cắt thật)."""
    from PySide6.QtWidgets import QPushButton

    probe = QPushButton("▶ Chạy ngay")
    probe.ensurePolished()
    return max(floor, probe.sizeHint().height() + 18)


APP_QSS = """
/* ================= Nền & chữ chung ================= */
QMainWindow, QMessageBox {
    background: #0C0D0F;
}
/* V5.0 (khoá phong cách theo ảnh mẫu): hộp thoại là một TẤM PANEL
   nổi — nền sáng hơn nền app một bậc, đồng bộ với QFrame#Panel. */
QDialog {
    background: #16171B;
}
QWidget {
    color: #ECEEF1;
    font-family: "Segoe UI", "Segoe UI Variable", sans-serif;
    font-size: 13px;
}
QToolTip {
    background: #1B1D22;
    color: #ECEEF1;
    border: 1px solid #26282D;
    padding: 4px 8px;
}

/* ================= Khung / thẻ ================= */
QFrame#HeaderBar {
    background: #0A0B0C;
    border: none;
    border-bottom: 1px solid #1E2024;
}
QFrame#Panel {
    background: #16171B;
    border: 1px solid #26282D;
    border-radius: 12px;
}
QFrame#Card {
    background: #1B1D22;
    border: 1px solid #26282D;
    border-radius: 12px;
}
QFrame#ProfileCard {
    background: #1B1D22;
    border: 1px solid #26282D;
    border-radius: 12px;
}
QFrame#ProfileCard:hover {
    background: #212329;
}
QFrame#ProfileCard[selected="true"] {
    background: #212329;
    border: 1px solid #CEFC19;
}
QSplitter::handle {
    background: transparent;
}
QScrollArea {
    background: transparent;
    border: none;
}
/* V6.3.1: khung cuộn KHÔNG bao giờ hiện nền trắng mặc định của Qt. */
QScrollArea > QWidget#qt_scrollarea_viewport,
QScrollArea > QWidget#qt_scrollarea_viewport > QWidget {
    background: transparent;
}

/* ================= Nhãn ================= */
QLabel#AppTitle {
    font-size: 16px;
    font-weight: 700;
    color: #ECEEF1;
}
QLabel#AppSubtitle {
    font-size: 10px;
    font-weight: 600;
    color: #9AA0A8;
}
QLabel#SectionHeader {
    font-size: 13px;
    font-weight: 700;
    color: #ECEEF1;
    border-left: 3px solid #CEFC19;
    padding-left: 8px;
}
QLabel#Muted {
    color: #9AA0A8;
}
QLabel#Muted12 {
    color: #9AA0A8;
    font-size: 12px;
}
QLabel#Faint12 {
    color: #6F7680;
    font-size: 12px;
}
QLabel#Faint {
    color: #6F7680;
    font-size: 12px;
}
QLabel#PageTitle {
    font-size: 22px;
    font-weight: 700;
    color: #ECEEF1;
}
QLabel#DialogTitle {
    font-size: 18px;
    font-weight: 700;
    color: #ECEEF1;
}
QLabel#CardTitle {
    font-size: 13px;
    font-weight: 700;
    color: #ECEEF1;
}
QLabel#UrlLabel {
    color: #9AA0A8;
    font-size: 12px;
}
QLabel#FpsLabel {
    color: #6F7680;
    font-size: 12px;
    font-family: "Consolas", monospace;
}
QLabel#LiveCaption {
    color: #FF7A7A;
    font-size: 11px;
    font-weight: 700;
}
QLabel#Pill {
    border-radius: 11px;
    padding: 4px 11px;
    font-size: 11px;
    font-weight: 600;
}
QLabel#Pill[state="in"] {
    color: #CEFC19;
    background: rgba(206, 252, 25, 28);
    border: 1px solid rgba(206, 252, 25, 110);
}
QLabel#Pill[state="out"] {
    color: #FF7A7A;
    background: rgba(255, 122, 122, 28);
    border: 1px solid rgba(255, 122, 122, 110);
}
QLabel#Pill[state="unknown"] {
    color: #9AA0A8;
    background: rgba(154, 160, 168, 26);
    border: 1px solid rgba(154, 160, 168, 90);
}
QLabel#Pill[state="paused"] {
    color: #F2C94C;
    background: rgba(242, 201, 76, 26);
    border: 1px solid rgba(242, 201, 76, 100);
}

/* ================= Nút bấm ================= */
QPushButton {
    background: #212329;
    border: 1px solid #2E3036;
    border-radius: 8px;
    padding: 7px 14px;
    color: #ECEEF1;
    font-weight: 600;
}
/* V5.3 (A3/A5): nút GỌN cao 24px (hàng lọc lệnh + nút thao tác
   trong dòng bảng) — padding dọc của nút thường (8px) sẽ ĂN HẾT
   24px và CẮT CHỮ theo chiều dọc (đã thấy trên render nghiệm
   thu V5.3); kiểu này bỏ padding dọc + font 12px để chữ vừa hẳn
   trong 24px. */
QPushButton#RowAction {
    padding: 0px 10px;
    font-size: 12px;
}
QPushButton:hover {
    background: #212329;
    border-color: rgba(206, 252, 25, 128);
    color: #CEFC19;
}
QPushButton:pressed {
    background: #121316;
}
QPushButton:disabled {
    background: #16171B;
    border-color: #26282D;
    color: #6F7680;
}
QPushButton:checked {
    background: rgba(206, 252, 25, 26);
    border-color: rgba(206, 252, 25, 115);
    color: #CEFC19;
}
/* V5.0: nút CHÍNH = pill xanh đặc, chữ đen, bo tròn hoàn toàn;
   "quầng sáng" thể hiện bằng viền sáng #DBFD5E (cố ý KHÔNG dùng
   QGraphicsDropShadowEffect — tránh chi phí sơn lại toàn bề mặt,
   giữ bài học hiệu năng V4.3.2/V4.5). */
QPushButton[variant="primary"] {
    background: #CEFC19;
    border: 1px solid #CEFC19;
    border-radius: 8px;
    color: #141A05;
    font-weight: 700;
}
QPushButton[variant="primary"]:hover {
    background: #DBFD5E;
    border-color: #DBFD5E;
    color: #141A05;
}
QPushButton[variant="primary"]:pressed {
    background: #B8E214;
    border-color: #B8E214;
}
QPushButton[variant="primary"]:disabled {
    background: #1A1C20;
    border-color: #1A1C20;
    color: #6F7680;
}
QPushButton[variant="danger"] {
    background: rgba(255, 122, 122, 30);
    border: 1px solid rgba(255, 122, 122, 100);
    color: #FFB3B3;
}
QPushButton[variant="danger"]:hover {
    background: rgba(255, 122, 122, 30);
    border-color: #FF7A7A;
}
QPushButton[variant="danger"]:pressed {
    background: rgba(255, 122, 122, 55);
}
QPushButton[variant="ghost"] {
    background: transparent;
    border: 1px solid #26282D;
    color: #9AA0A8;
}
QPushButton[variant="ghost"]:hover {
    background: #212329;
    color: #ECEEF1;
}

/* ================= Segmented toggle ================= */
QFrame#Segmented {
    background: #121316;
    border: 1px solid #26282D;
    border-radius: 8px;
}
QFrame#Segmented QPushButton {
    background: transparent;
    border: none;
    border-radius: 9px;
    padding: 5px 14px;
    color: #9AA0A8;
    font-weight: 600;
}
QFrame#Segmented QPushButton:hover {
    color: #ECEEF1;
}
QFrame#Segmented QPushButton:checked {
    background: #CEFC19;
    color: #0C0D0F;
}

/* ================= Ô nhập ================= */
QLineEdit {
    background: #121316;
    border: 1px solid #2E3036;
    border-radius: 8px;
    padding: 7px 10px;
    color: #ECEEF1;
    selection-background-color: rgba(206, 252, 25, 90);
}
QLineEdit:focus {
    border-color: #CEFC19;
}
QFormLayout QLabel {
    color: #9AA0A8;
}

/* ================= Bảng kênh ================= */
/* V5.3 (A5): bảng GỌN toàn app — ô chỉ đệm dọc 2px (hằng số
   TABLE_ITEM_VPAD bên dưới, các panel tính chiều cao dòng từ
   đúng số này), viền + bo góc 16px theo token thẻ để bảng đọc
   như một THẺ NỔI trên nền panel. */
QTableWidget {
    background: #16171B;
    alternate-background-color: #101113;
    gridline-color: #26282D;
    border: 1px solid #26282D;
    border-radius: 8px;
    selection-background-color: rgba(206, 252, 25, 45);
    selection-color: #ECEEF1;
    outline: none;
}
QTableWidget::item {
    padding: 2px 10px;
    border: none;
}
QHeaderView {
    /* Nền của CHÍNH thanh header: thiếu rule này, phần header
       vượt ra ngoài cột cuối (bảng không kéo giãn hết bề rộng,
       vd bảng quy tắc Tự động) lộ nền trắng mặc định. */
    background: #212329;
}
QHeaderView::section {
    background: #212329;
    color: #9AA0A8;
    font-size: 11px;
    font-weight: 700;
    padding: 6px 10px;
    border: none;
    border-bottom: 1px solid #26282D;
}
QTableCornerButton::section {
    background: #212329;
    border: none;
}

/* ================= Thanh tiến độ (V4.3.1: thẻ việc) ============ */
QProgressBar {
    background: #24262B;
    border: none;
    border-radius: 2px;
    max-height: 4px;
    min-height: 4px;
    text-align: center;
    color: transparent;
}
QProgressBar::chunk {
    background: #CEFC19;
    border-radius: 2px;
}

/* ================= Nhật ký ================= */
QPlainTextEdit#Journal {
    background: #121316;
    border: 1px solid #26282D;
    border-radius: 8px;
    color: #C3C7CD;
    font-family: "Consolas", "Cascadia Mono", monospace;
    font-size: 12px;
    padding: 8px;
    selection-background-color: rgba(206, 252, 25, 90);
}

/* ================= Thanh cuộn ================= */
QScrollBar:vertical {
    background: transparent;
    width: 8px;
    margin: 0;
}
QScrollBar::handle:vertical {
    background: #2C2E34;
    border-radius: 4px;
    min-height: 28px;
}
QScrollBar::handle:vertical:hover {
    background: rgba(206, 252, 25, 153);
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}
QScrollBar:horizontal {
    background: transparent;
    height: 8px;
    margin: 0;
}
QScrollBar::handle:horizontal {
    background: #2C2E34;
    border-radius: 4px;
    min-width: 28px;
}
QScrollBar::handle:horizontal:hover {
    background: rgba(206, 252, 25, 153);
}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}
QScrollBar::add-page, QScrollBar::sub-page {
    background: transparent;
}

/* ============== V4.3.1: Điều hướng mục kiểu Concept D ============== */
/* Tab mục LỚN bo tròn: icon trên + nhãn dưới (chữ hai dòng trong nút),
   đang chọn = nền accent + chữ trắng; gạch chân accent nằm ở khung
   chứa dưới nút (MainWindow dựng kèm một thanh chỉ thị riêng). */
QPushButton#NavTab {
    background: transparent;
    border: 1px solid transparent;
    border-radius: 8px;
    padding: 6px 12px;
    color: #C3C7CD;
    font-weight: 600;
    font-size: 12px;
    text-align: center;
}
QPushButton#NavTab:hover {
    background: #1B1D22;
    color: #ECEEF1;
}
QPushButton#NavTab:checked {
    background: rgba(206, 252, 25, 30);
    border: 1px solid rgba(206, 252, 25, 115);
    color: #CEFC19;
}
/* Nút tiện ích nhỏ trên cùng thanh điều hướng (quét tất cả / toàn
   màn hình / thu-hiện nhãn): pill viền panel như nút phụ Concept D. */
QPushButton#NavButton {
    background: #212329;
    border: 1px solid #2E3036;
    border-radius: 8px;
    padding: 6px 12px;
    color: #ECEEF1;
    font-weight: 600;
    font-size: 12px;
}
QPushButton#NavButton:hover {
    border-color: rgba(206, 252, 25, 128);
    color: #CEFC19;
}
QPushButton#NavButton:checked {
    background: #212329;
    border-color: #CEFC19;
    color: #ECEEF1;
}

/* ================= V3: Pill trạng thái lệnh ================= */
QLabel#Pill[state="run"] {
    color: #CEFC19;
    background: rgba(206, 252, 25, 26);
    border: 1px solid rgba(206, 252, 25, 110);
}
QLabel#Pill[state="user"] {
    color: #C4A7FF;
    background: rgba(196, 167, 255, 26);
    border: 1px solid rgba(196, 167, 255, 110);
}

/* V5.3.1 (M1): pill LỌC bấm được ở đầu bảng việc — cùng bảng màu
   với QLabel#Pill theo property state; trạng thái ĐANG CHỌN
   (:checked) nền đậm hơn + viền trọn màu để phân biệt rõ pill
   nào đang lọc mà không đổi kích thước (không nhảy bố cục). */
QPushButton#FilterPill {
    border-radius: 11px;
    padding: 4px 11px;
    font-size: 11px;
    font-weight: 600;
}
QPushButton#FilterPill[state="run"] {
    color: #CEFC19;
    background: rgba(206, 252, 25, 26);
    border: 1px solid rgba(206, 252, 25, 110);
}
QPushButton#FilterPill[state="run"]:checked {
    background: rgba(206, 252, 25, 70);
    border: 1px solid #CEFC19;
}
QPushButton#FilterPill[state="paused"] {
    color: #F2C94C;
    background: rgba(242, 201, 76, 26);
    border: 1px solid rgba(242, 201, 76, 100);
}
QPushButton#FilterPill[state="paused"]:checked {
    background: rgba(242, 201, 76, 70);
    border: 1px solid #F2C94C;
}
QPushButton#FilterPill[state="user"] {
    color: #C4A7FF;
    background: rgba(196, 167, 255, 26);
    border: 1px solid rgba(196, 167, 255, 110);
}
QPushButton#FilterPill[state="user"]:checked {
    background: rgba(196, 167, 255, 70);
    border: 1px solid #C4A7FF;
}
QPushButton#FilterPill[state="out"] {
    color: #FF7A7A;
    background: rgba(255, 122, 122, 28);
    border: 1px solid rgba(255, 122, 122, 110);
}
QPushButton#FilterPill[state="out"]:checked {
    background: rgba(255, 122, 122, 70);
    border: 1px solid #FF7A7A;
}
QPushButton#FilterPill[state="in"] {
    color: #CEFC19;
    background: rgba(206, 252, 25, 28);
    border: 1px solid rgba(206, 252, 25, 110);
}
QPushButton#FilterPill[state="in"]:checked {
    background: rgba(206, 252, 25, 70);
    border: 1px solid #CEFC19;
}
QPushButton#FilterPill[state="unknown"] {
    color: #9AA0A8;
    background: rgba(154, 160, 168, 26);
    border: 1px solid rgba(154, 160, 168, 90);
}
QPushButton#FilterPill[state="unknown"]:checked {
    background: rgba(154, 160, 168, 70);
    border: 1px solid #9AA0A8;
    color: #ECEEF1;
}

/* ================= V3: Ô chọn / nhập liệu mở rộng ================= */
QComboBox {
    background: #121316;
    border: 1px solid #2E3036;
    border-radius: 8px;
    padding: 7px 10px;
    color: #ECEEF1;
    selection-background-color: rgba(206, 252, 25, 90);
}
QComboBox:focus {
    border-color: #CEFC19;
}
QComboBox::drop-down {
    border: none;
    width: 26px;
}
QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #9AA0A8;
    margin-right: 8px;
}
QComboBox QAbstractItemView {
    background: #1B1D22;
    color: #ECEEF1;
    border: 1px solid #26282D;
    selection-background-color: rgba(206, 252, 25, 60);
    outline: none;
}
QCheckBox {
    color: #ECEEF1;
    spacing: 8px;
}
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 1px solid #2E3036;
    background: #121316;
}
QCheckBox::indicator:hover {
    border-color: #3A3D44;
}
QCheckBox::indicator:checked {
    background: #CEFC19;
    border-color: #CEFC19;
}
QSpinBox, QTimeEdit, QDateTimeEdit {
    background: #121316;
    border: 1px solid #2E3036;
    border-radius: 8px;
    padding: 7px 10px;
    color: #ECEEF1;
    selection-background-color: rgba(206, 252, 25, 90);
}
QSpinBox:focus, QTimeEdit:focus, QDateTimeEdit:focus {
    border-color: #CEFC19;
}
QPlainTextEdit {
    background: #121316;
    border: 1px solid #26282D;
    border-radius: 8px;
    color: #ECEEF1;
    padding: 8px;
    selection-background-color: rgba(206, 252, 25, 90);
}
QPlainTextEdit:focus {
    border-color: #CEFC19;
}
QListWidget {
    background: #16171B;
    border: 1px solid #26282D;
    border-radius: 8px;
    outline: none;
}
QListWidget::item {
    padding: 8px 10px;
    border-bottom: 1px solid #212329;
    color: #ECEEF1;
}
QListWidget::item:selected {
    background: rgba(206, 252, 25, 45);
    color: #ECEEF1;
}

/* ================= V3: Mục kiểm tra (✓ / ✗ / –) ================= */
QLabel#CheckGlyphOk {
    color: #CEFC19;
    font-size: 15px;
    font-weight: 700;
}
QLabel#CheckGlyphFail {
    color: #FF7A7A;
    font-size: 15px;
    font-weight: 700;
}
QLabel#CheckGlyphNa {
    color: #6F7680;
    font-size: 15px;
    font-weight: 700;
}

/* ================= V3.1: Tab (dock dưới + khung ảnh + cài đặt) ===== */
QTabWidget::pane {
    background: transparent;
    border: none;
    top: -1px;
}
QTabBar {
    background: transparent;
}
QTabBar::tab {
    background: transparent;
    color: #9AA0A8;
    font-weight: 600;
    padding: 6px 12px;
    border: 1px solid transparent;
    border-radius: 6px;
    margin: 2px 2px 6px 0;
}
QTabBar::tab:hover {
    color: #ECEEF1;
}
QTabBar::tab:selected {
    color: #CEFC19;
    background: #212329;
    border: 1px solid rgba(206, 252, 25, 100);
    border-radius: 6px;
}

/* ================= V3.1: Thanh trạng thái dưới cùng =============== */
QStatusBar {
    background: #16171B;
    border-top: 1px solid #26282D;
    color: #9AA0A8;
    font-size: 12px;
}
QStatusBar QLabel {
    color: #9AA0A8;
    font-size: 12px;
    padding: 0 6px;
}
QStatusBar::item {
    border: none;
}

/* ================= V3.1: Menu tràn (⋯) ============================= */
QMenu {
    background: #1B1D22;
    border: 1px solid #26282D;
    padding: 6px;
}
QMenu::item {
    padding: 7px 22px 7px 12px;
    border-radius: 6px;
    color: #ECEEF1;
}
QMenu::item:selected {
    background: rgba(206, 252, 25, 45);
}
QMenu::separator {
    height: 1px;
    background: #26282D;
    margin: 5px 8px;
}

/* ================= V3.1: Thẻ KPI (Tổng quan) ====================== */
QFrame#KpiCard {
    background: #1B1D22;
    border: 1px solid #26282D;
    border-radius: 8px;
}
QLabel#KpiValue {
    font-size: 26px;
    font-weight: 700;
    color: #ECEEF1;
}
QLabel#KpiTitle {
    font-size: 11px;
    font-weight: 700;
    color: #9AA0A8;
}
QLabel#KpiSub {
    font-size: 12px;
    color: #6F7680;
}

/* (V5.3 — A2: kiểu Toast đã gỡ cùng hệ thống toast; sự kiện chỉ
   còn ghi vào Nhật ký.) */

/* ================= V3.1: Dock dưới (thu/mở) + banner lỗi ========== */
QFrame#DockHeader {
    background: transparent;
    border: none;
}
QWidget#TitleBar {
    background: #0A0B0C;
}
QLabel#TitleBarText {
    color: #ECEEF1;
    font-size: 12px;
    font-weight: 600;
}
QPushButton#WinBtn, QPushButton#WinBtnClose {
    background: transparent;
    border: none;
    color: #9AA0A8;
    min-width: 40px;
    max-width: 40px;
    min-height: 28px;
    max-height: 28px;
    font-size: 13px;
    padding: 0;
}
QPushButton#WinBtn:hover {
    background: #212329;
    color: #FFFFFF;
}
QPushButton#WinBtnClose:hover {
    background: #FF7A7A;
    color: #FFFFFF;
}
QPushButton#CardMenuBtn {
    background: transparent;
    border: 1px solid #26282D;
    border-radius: 8px;
    color: #9AA0A8;
    font-size: 15px;
    font-weight: 700;
    padding: 0;
}
QPushButton#CardMenuBtn:hover {
    background: #212329;
    color: #FFFFFF;
}
QPushButton#ChevronButton {
    background: transparent;
    border: none;
    border-radius: 6px;
    padding: 3px 10px;
    color: #9AA0A8;
    font-size: 13px;
    font-weight: 700;
}
QPushButton#ChevronButton:hover {
    background: #212329;
    color: #ECEEF1;
}
QFrame#ErrorBanner {
    background: rgba(255, 122, 122, 22);
    border: 1px solid rgba(255, 122, 122, 120);
    border-radius: 8px;
}
QLabel#ErrorBannerText {
    color: #FFB3B3;
    font-size: 12px;
    font-weight: 600;
}
QLabel#EmptyState {
    color: #6F7680;
    font-size: 12px;
    padding: 10px 4px;
}
"""


# --------------------------------------------------------------------------- #
# Widget factory
# --------------------------------------------------------------------------- #
def section_header(text: str) -> QLabel:
    """Tiêu đề mục: 11px, in hoa, giãn chữ, màu mờ."""
    label = QLabel(text.upper())
    label.setObjectName("SectionHeader")
    font = label.font()
    font.setLetterSpacing(QFont.AbsoluteSpacing, 1.4)
    label.setFont(font)
    return label


def card_frame() -> QFrame:
    """Thẻ nền (QFrame#Card) dùng cho các panel V3."""
    frame = QFrame()
    frame.setObjectName("Card")
    return frame


def muted_label(text: str) -> QLabel:
    """Nhãn chữ mờ (QLabel#Muted) — chú thích, nhãn trường nhập liệu."""
    label = QLabel(text)
    label.setObjectName("Muted")
    return label


def pill(text: str, state: str) -> QLabel:
    """Nhãn trạng thái dạng viên thuốc; state: in / out / unknown / paused."""
    label = QLabel(text)
    label.setObjectName("Pill")
    label.setProperty("state", state)
    label.setAlignment(Qt.AlignCenter)
    return label


def avatar_pixmap(text: str, seed: str, size: int = 28, color: str | None = None):
    """Pixmap avatar TRÒN cho icon trong danh sách/cây (V5.0): vòng
    tròn nền màu tất định theo seed + chữ cái đầu ở giữa. Khác
    :func:`avatar` (QLabel cho thẻ hồ sơ) — bản này để gắn làm icon
    cho các dòng agent/kênh trong danh sách mới. ``color`` truyền vào
    (vd xanh accent cho agent) thì dùng thẳng, chữ chuyển sang đen."""
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtGui import QColor, QFont, QPainter, QPixmap

    idx = zlib.crc32((seed or "").encode("utf-8")) % len(AVATAR_COLORS)
    pixmap = QPixmap(size, size)
    pixmap.fill(_Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setBrush(QColor(color or AVATAR_COLORS[idx]))
    painter.setPen(_Qt.PenStyle.NoPen)
    painter.drawEllipse(0, 0, size, size)
    painter.setPen(QColor("#090A09" if color else "#FFFFFF"))
    font = QFont()
    font.setBold(True)
    font.setPixelSize(max(11, size // 2))
    painter.setFont(font)
    painter.drawText(pixmap.rect(), _Qt.AlignmentFlag.AlignCenter, (text or "?")[:1].upper())
    painter.end()
    return pixmap


# --------------------------------------------------------------------------- #
# Tài sản ảnh THẬT đóng gói trong app (V5.2 — bài học §15: muốn gần
# ảnh mẫu thì phải dùng tài sản thật, không hứa bằng chữ). File nằm ở
# app/assets/: robot_avatar.png (robot 3D mắt xanh lá, nền gần đen)
# và office_floor.jpg (nền văn phòng isometric tối). Nạp MỘT lần rồi
# cache ở mức module — các nhịp refresh không bao giờ đọc lại đĩa.
# --------------------------------------------------------------------------- #
from pathlib import Path as _Path

ASSETS_DIR = _Path(__file__).resolve().parent.parent / "assets"

_asset_cache: dict = {}

# Vòng màu phân biệt agent (quanh avatar robot dùng chung): bảng màu
# sáng vừa trên nền tối, tất định theo seed/id của agent.
AGENT_RING_COLORS = [
    "#CEFC19", "#38BDF8", "#F59E0B", "#F472B6",
    "#A78BFA", "#F87171", "#2DD4BF", "#FACC15",
]


def agent_ring_color(seed) -> str:
    """Màu vòng phân biệt một agent — tất định từ seed (id/tên)."""
    idx = zlib.crc32(str(seed or "").encode("utf-8")) % len(AGENT_RING_COLORS)
    return AGENT_RING_COLORS[idx]


def _load_asset_pixmap(filename: str):
    """Nạp một ảnh trong app/assets (cache vĩnh viễn theo tên file)."""
    from PySide6.QtGui import QPixmap

    if filename not in _asset_cache:
        pixmap = QPixmap(str(ASSETS_DIR / filename))
        _asset_cache[filename] = pixmap if not pixmap.isNull() else None
    return _asset_cache[filename]


def office_floor_pixmap():
    """Ảnh nền văn phòng isometric (kích thước gốc, cache)."""
    return _load_asset_pixmap("office_floor.jpg")


#: V5.3 (A9): đường dẫn ảnh nền Văn phòng TUỲ CHỌN — setting
#: office_bg_image; MainWindow đẩy vào lúc khởi động, ThemePanel
#: đẩy vào mỗi lần người dùng chọn/khôi phục. Cache nạp theo
#: đường dẫn (đổi ảnh là nạp lại đúng một lần).
_office_bg_custom_path: str | None = None
_office_bg_custom_cache: tuple = ("", None)


def set_office_background_path(path) -> None:
    """Đặt ảnh nền Văn phòng tuỳ chọn (None/rỗng = nền đóng gói)."""
    global _office_bg_custom_path
    _office_bg_custom_path = str(path) if path else None


def office_background_path() -> str | None:
    return _office_bg_custom_path


def office_background_pixmap():
    """Ảnh nền Văn phòng HIỆU LỰC (V5.3 A9): ảnh tuỳ chọn của
    người dùng khi nạp được; thiếu file/nạp lỗi → rơi về ảnh
    đóng gói office_floor.jpg (bản thân nó có thể None khi cả
    assets hỏng — caller sơn vỏ phẳng trong trường hợp đó)."""
    global _office_bg_custom_cache
    path = _office_bg_custom_path
    if path:
        if _office_bg_custom_cache[0] != path:
            from PySide6.QtGui import QPixmap

            pixmap = QPixmap(path)
            _office_bg_custom_cache = (
                path, pixmap if not pixmap.isNull() else None,
            )
        if _office_bg_custom_cache[1] is not None:
            return _office_bg_custom_cache[1]
    return office_floor_pixmap()


def robot_avatar_pixmap(size: int = 56, ring: str | None = None,
                        grey: bool = False):
    """Avatar robot THẬT cắt tròn (V5.2): ảnh robot trong assets,
    cắt hình tròn; `ring` = màu vòng phân biệt agent (None = không
    vòng); `grey` = bản xám cho agent ngoại tuyến. Cache theo
    (size, ring, grey) — gọi lặp ở các nhịp refresh là miễn phí."""
    from PySide6.QtCore import Qt as _Qt
    from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap

    key = ("robot", int(size), ring, bool(grey))
    if key in _asset_cache:
        return _asset_cache[key]
    source = _load_asset_pixmap("robot_avatar.png")
    result = None
    if source is not None:
        side = min(source.width(), source.height())
        image = source.toImage().copy(
            (source.width() - side) // 2, (source.height() - side) // 2,
            side, side,
        )
        if grey:
            image = image.convertToFormat(QImage.Format_Grayscale8)
        image = image.scaled(
            int(size), int(size),
            _Qt.KeepAspectRatio, _Qt.SmoothTransformation,
        )
        result = QPixmap(int(size), int(size))
        result.fill(_Qt.GlobalColor.transparent)
        painter = QPainter(result)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setClipRegion(_circular_region(int(size)))
        painter.drawImage(0, 0, image)
        painter.setClipping(False)
        if ring:
            pen = QPen(QColor(ring))
            pen.setWidthF(max(2.0, size / 22.0))
            painter.setPen(pen)
            painter.setBrush(_Qt.BrushStyle.NoBrush)
            inset = pen.widthF() / 2.0
            painter.drawEllipse(
                int(inset), int(inset),
                int(size - 2 * inset), int(size - 2 * inset),
            )
        painter.end()
    _asset_cache[key] = result
    return result


def _circular_region(size: int):
    from PySide6.QtCore import QRect
    from PySide6.QtGui import QRegion

    return QRegion(QRect(0, 0, size, size), QRegion.Ellipse)


def avatar(initial: str, seed: str, size: int = 42) -> QLabel:
    """Avatar tròn: chữ cái đầu của hồ sơ trên nền màu tất định theo slug."""
    idx = zlib.crc32(seed.encode("utf-8")) % len(AVATAR_COLORS)
    color = AVATAR_COLORS[idx]
    label = QLabel((initial or "?")[:1].upper())
    label.setFixedSize(size, size)
    label.setAlignment(Qt.AlignCenter)
    radius = size // 2
    label.setStyleSheet(
        f"background:{color}; color:#FFFFFF; border-radius:{radius}px;"
        " border:1px solid rgba(255,255,255,36); font-size:16px; font-weight:700;"
    )
    return label


class PulsingDot(QWidget):
    """Chấm LIVE nhấp nháy (đỏ khi đang có luồng hình, xám khi chưa)."""

    def __init__(self, parent=None, diameter: int = 10):
        super().__init__(parent)
        self.setFixedSize(diameter + 4, diameter + 4)
        self._diameter = diameter
        self._active = False
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(50)
        self._timer.timeout.connect(self._tick)

    def set_active(self, active: bool):
        if active == self._active:
            return
        self._active = active
        if active:
            self._timer.start()
        else:
            self._timer.stop()
        self.update()

    def _tick(self):
        self._phase += 0.28
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        d = self._diameter
        x = (self.width() - d) / 2
        y = (self.height() - d) / 2
        if self._active:
            alpha = int(165 + 90 * math.sin(self._phase))
            color = QColor(214, 92, 92, max(60, min(255, alpha)))
        else:
            color = QColor("#47503F")
        painter.setBrush(color)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(int(x), int(y), d, d)


# --------------------------------------------------------------------------- #
# V4.3 — Theme tokens
# --------------------------------------------------------------------------- #
# Lớp tokens đặt TRÊN bảng màu / APP_QSS hiện hữu (không thay đổi chúng):
# một ThemeTokens mô tả trọn bảng màu + tỉ lệ bo góc / độ sáng / cỡ chữ,
# build_qss() suy ra stylesheet từ APP_QSS bằng cách thay màu một lượt.
# bg_image / bg_dim chỉ được lưu trong tokens (để UI / persistence dùng);
# build_qss() KHÔNG xử lý ảnh nền.

import re
from dataclasses import asdict as _tokens_asdict
from dataclasses import dataclass
from dataclasses import replace as _tokens_replace

DEFAULT_RADIUS = 8

# Các trường màu của ThemeTokens, theo đúng thứ tự khai báo trong dataclass.
_COLOR_FIELDS = (
    "bg",
    "panel",
    "card",
    "border",
    "accent",
    "accent2",
    "text",
    "muted",
    "faint",
    "input_bg",
    "button_bg",
    "button_hover",
    "button_pressed",
    "card_hover",
    "success",
    "warning",
    "danger",
)

_STRING_FIELDS = _COLOR_FIELDS + ("font_family", "bg_image")


@dataclass(frozen=True)
class ThemeTokens:
    """Bộ token giao diện: màu (chuỗi hex) + các hệ số trình bày."""

    bg: str = BG
    panel: str = PANEL
    card: str = CARD
    border: str = BORDER
    accent: str = ACCENT
    accent2: str = ACCENT2
    text: str = TEXT
    muted: str = MUTED
    faint: str = FAINT
    input_bg: str = INPUT_BG
    button_bg: str = BUTTON_BG
    button_hover: str = BUTTON_HOVER
    button_pressed: str = BUTTON_PRESSED
    card_hover: str = CARD_HOVER
    success: str = SUCCESS
    warning: str = WARNING
    danger: str = DANGER
    radius: int = DEFAULT_RADIUS
    brightness: float = 1.0
    font_scale: float = 1.0
    font_family: str = ""
    bg_image: str = ""
    bg_dim: float = 0.55


MISSION_TOKENS = ThemeTokens(
    bg=BG,
    panel=PANEL,
    card=CARD,
    border=BORDER,
    accent=ACCENT,
    accent2=ACCENT2,
    text=TEXT,
    muted=MUTED,
    faint=FAINT,
    input_bg=INPUT_BG,
    button_bg=BUTTON_BG,
    button_hover=BUTTON_HOVER,
    button_pressed=BUTTON_PRESSED,
    card_hover=CARD_HOVER,
    success=SUCCESS,
    warning=WARNING,
    danger=DANGER,
)

# V4.5: preset MẶC ĐỊNH là "MetaMint" — chính bộ token gốc hiện tại
# (MISSION_TOKENS giữ vai trò "bộ mặc định" cho build_qss/tokens_from_dict
# như các bản trước; từ V4.5 giá trị của nó là bảng MetaMint).
METAMINT_TOKENS = MISSION_TOKENS

# Bảng màu Concept D của V4.3.1 (navy + xanh dương) — giữ làm preset
# "mission" (cũ) cho ai muốn quay lại, và làm mốc DI TRÚ: người dùng
# đang ở đúng bộ gốc này (chưa tuỳ biến) được nâng lên MetaMint.
CONCEPT_D_TOKENS = ThemeTokens(
    bg="#0B1220",
    panel="#141E33",
    card="#1B2745",
    border="#26355C",
    accent="#2E7CF6",
    accent2="#2DD4BF",
    text="#E6EEF8",
    muted="#8FA3C8",
    faint="#64769A",
    input_bg="#0E1729",
    button_bg="#1C2A4A",
    button_hover="#263A66",
    button_pressed="#141F38",
    card_hover="#22335C",
    success="#2FBF71",
    warning="#F5A524",
    danger="#E5484D",
)

PRESETS: dict[str, ThemeTokens] = {
    "metamint": METAMINT_TOKENS,
    "mission": CONCEPT_D_TOKENS,
    "light": ThemeTokens(
        bg="#F2F5FA",
        panel="#FFFFFF",
        card="#FFFFFF",
        border="#D5DCE8",
        text="#16233C",
        muted="#5A6B87",
        faint="#8494AD",
        input_bg="#FFFFFF",
        button_bg="#E8EEF7",
        button_hover="#DCE6F5",
        button_pressed="#CFDDF2",
        card_hover="#EEF3FA",
        # accent / accent2 / success / warning / danger giữ mặc định.
    ),
    "contrast": ThemeTokens(
        bg="#000000",
        panel="#0A0A0A",
        card="#111111",
        border="#4A4A4A",
        accent="#00E5FF",
        accent2="#00FFC8",
        text="#FFFFFF",
        muted="#D8D8D8",
        faint="#A8A8A8",
        input_bg="#000000",
        button_bg="#1A1A1A",
        button_hover="#2A2A2A",
        button_pressed="#050505",
        card_hover="#1C1C1C",
        success="#00E676",
        warning="#FFD600",
        danger="#FF5252",
    ),
    "diorama": ThemeTokens(
        bg="#F7F0E3",
        panel="#FFF8EC",
        card="#FFFDF6",
        border="#E3D5BC",
        accent="#E8862E",
        accent2="#3FA796",
        text="#3D3225",
        muted="#8A7A5F",
        faint="#B3A284",
        input_bg="#FFFDF6",
        button_bg="#F3E7CF",
        button_hover="#EDDCBA",
        button_pressed="#E5D0A4",
        card_hover="#FBF3DF",
        success="#4CAF7D",
        warning="#E8A13A",
        danger="#D9534F",
    ),
}


def adjust_brightness(hex_color: str, factor: float) -> str:
    """Nhân độ sáng (HSL lightness) của một màu hex với ``factor``.

    Trả hex viết HOA dạng #RRGGBB. factor=1.0 trả lại đúng màu gốc
    (chuẩn hoá hoa, bỏ qua chuyển đổi HSL để tránh sai số làm tròn).
    Màu không hợp lệ → trả nguyên đầu vào.
    """
    if not isinstance(hex_color, str):
        return hex_color
    color = QColor(hex_color)
    if not color.isValid():
        return hex_color
    try:
        factor_value = float(factor)
    except (TypeError, ValueError):
        return color.name(QColor.HexRgb).upper()
    if factor_value == 1.0:
        return color.name(QColor.HexRgb).upper()
    hue, saturation, lightness, alpha = color.getHslF()
    new_lightness = max(0.0, min(1.0, lightness * factor_value))
    adjusted = QColor()
    adjusted.setHslF(
        hue if hue is not None and hue >= 0 else 0.0,
        max(0.0, min(1.0, saturation)),
        new_lightness,
        alpha,
    )
    if not adjusted.isValid():
        return hex_color
    return adjusted.name(QColor.HexRgb).upper()


def effective_colors(tokens: ThemeTokens) -> dict[str, str]:
    """Ánh xạ tên trường màu → màu sau khi áp hệ số brightness."""
    return {
        name: adjust_brightness(getattr(tokens, name), tokens.brightness)
        for name in _COLOR_FIELDS
    }


def build_qss(tokens: ThemeTokens) -> str:
    """Dựng stylesheet cho ``tokens`` từ APP_QSS.

    Tokens tương đương mặc định → trả APP_QSS nguyên văn. Ngược lại,
    thay các literal hex của bảng màu mặc định bằng màu token tương ứng
    trong MỘT lượt quét regex (alternation + hàm tra cứu), nên một màu
    đích tình cờ trùng hex mặc định của màu khác không bị thay chồng.
    """
    effective = effective_colors(tokens)
    mission = effective_colors(MISSION_TOKENS)
    is_default = (
        all(effective[name] == mission[name] for name in _COLOR_FIELDS)
        and tokens.radius == DEFAULT_RADIUS
        and tokens.font_scale == 1.0
        and not tokens.font_family
    )
    if is_default:
        return APP_QSS

    qss = APP_QSS

    replacement = {
        getattr(MISSION_TOKENS, name).lower(): effective[name]
        for name in _COLOR_FIELDS
    }
    alternation = "|".join(
        re.escape(getattr(MISSION_TOKENS, name))
        for name in _COLOR_FIELDS
    )
    color_pattern = re.compile(
        r"(?<![0-9A-Fa-f])(?:" + alternation + r")(?![0-9A-Fa-f])",
        re.IGNORECASE,
    )
    qss = color_pattern.sub(lambda m: replacement[m.group(0).lower()], qss)
    # V6.3: các sắc độ PHÁI SINH từ accent (nền nhạt rgba, hover sáng
    # hơn, nhấn tối hơn) đi theo accent người dùng chọn.
    if effective["accent"].lower() != mission["accent"].lower():
        acc = QColor(effective["accent"])
        qss = qss.replace("206, 252, 25", f"{acc.red()}, {acc.green()}, {acc.blue()}")
        qss = qss.replace("#DBFD5E", acc.lighter(115).name().upper())
        qss = qss.replace("#B8E214", acc.darker(112).name().upper())

    if tokens.font_scale != 1.0:
        def _scale_font(match: re.Match) -> str:
            size = max(9, round(int(match.group(1)) * tokens.font_scale))
            return f"font-size: {size}px"

        qss = re.sub(r"font-size: (\d+)px", _scale_font, qss)

    if tokens.radius != DEFAULT_RADIUS:
        ratio = tokens.radius / DEFAULT_RADIUS

        def _scale_radius(match: re.Match) -> str:
            # V4.3.1: trần nâng 28 → 48 — APP_QSS nay có bo góc panel
            # 16px (Concept D), trượt Bo góc kéo tối đa phải nhân đôi
            # được giá trị đó (test ghim tỉ lệ nhân đôi trong
            # test_v43_theme) thay vì bị kẹp cụt ở 28.
            size = max(0, min(48, round(int(match.group(1)) * ratio)))
            return f"border-radius: {size}px"

        qss = re.sub(r"border-radius: (\d+)px", _scale_radius, qss)

    if tokens.font_family:
        qss = qss.replace(
            '"Segoe UI", "Segoe UI Variable", sans-serif',
            f'"{tokens.font_family}", "Segoe UI", sans-serif',
        )

    return qss


def tokens_to_dict(tokens: ThemeTokens) -> dict:
    """Chuyển tokens thành dict JSON-safe chứa đủ mọi trường."""
    return dict(_tokens_asdict(tokens))


def _safe_int(value, fallback: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        try:
            return int(float(value))
        except (TypeError, ValueError):
            return fallback


def _safe_float(value, fallback: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def tokens_from_dict(data: dict | None) -> ThemeTokens:
    """Dựng ThemeTokens từ dict; thiếu trường → mặc định MISSION,
    trường lạ bị bỏ qua, giá trị số được ép kiểu an toàn."""
    if not isinstance(data, dict):
        return MISSION_TOKENS
    kwargs: dict = {}
    for name in _STRING_FIELDS:
        value = data.get(name)
        if isinstance(value, str):
            if name in _COLOR_FIELDS and not value:
                continue
            kwargs[name] = value
    if "radius" in data:
        kwargs["radius"] = _safe_int(data["radius"], MISSION_TOKENS.radius)
    for name in ("brightness", "font_scale", "bg_dim"):
        if name in data:
            kwargs[name] = _safe_float(data[name], getattr(MISSION_TOKENS, name))
    if not kwargs:
        return MISSION_TOKENS
    return _tokens_replace(MISSION_TOKENS, **kwargs)


# --------------------------------------------------------------------------- #
# Di trú bảng màu gốc cũ (V4.3.1 → V4.5)
# --------------------------------------------------------------------------- #
# Các bộ GỐC của các đời trước: Mission Control cyan của V4.3 và
# Concept D của V4.3.1–V4.4. Người dùng CHƯA từng tuỳ biến mà đang ở
# đúng một bộ gốc (kể cả khi app đã lưu theme_tokens vào settings lúc
# áp preset) thì tự nâng lên bộ mặc định MỚI (MetaMint); ai đã đổi
# bất kỳ màu/hệ số nào thì giữ nguyên lựa chọn đã lưu — không ghi đè.
# Bộ MetaMint ĐỜI ĐẦU (V4.5–V4.6) trước khi V5.0 khoá phong cách
# theo ảnh mẫu (accent #CEFC19 tươi hơn, panel sáng bậc, bo góc lớn):
# ai đang ở đúng bộ gốc này (chưa tuỳ biến) thì tự nâng lên bộ mới.
LEGACY_METAMINT_TOKENS = ThemeTokens(
    bg="#0B0C0A",
    panel="#141613",
    card="#191B17",
    border="#23261F",
    accent="#3ECF6A",
    accent2="#43D675",
    text="#E9EBE6",
    muted="#9BA196",
    faint="#666B60",
    input_bg="#0E0F0D",
    button_bg="#1A1C18",
    button_hover="#22241F",
    button_pressed="#101110",
    card_hover="#1F211C",
    success="#43D675",
    warning="#D9A441",
    danger="#D65C5C",
)

# Bộ mặc định của V5.0 (style lock đợt 1: BG #090A09 / PANEL #171A17
# / CARD #1E211D) — giữ làm mốc lịch sử; từ V5.1 bộ mặc định hiệu lực
# là token theo phương án thiết kế đã duyệt (plan §1.1: BG #0C0D0F /
# PANEL #16171B / CARD #1B1D22, viền #26282D, chữ #ECEEF1).
LEGACY_V50_TOKENS = ThemeTokens(
    bg="#090A09",
    panel="#171A17",
    card="#1E211D",
    border="#2D332B",
    accent="#CEFC19",
    accent2="#6CC7FF",
    text="#ECEEF1",
    muted="#9AA0A8",
    faint="#6F7680",
    input_bg="#0C0D0B",
    button_bg="#1F221E",
    button_hover="#272B25",
    button_pressed="#12140F",
    card_hover="#252923",
    success="#7DDC7A",
    warning="#F2C94C",
    danger="#FF7A7A",
)

LEGACY_MISSION_TOKENS = ThemeTokens(
    bg="#0A0F1C",
    panel="#101828",
    card="#141F36",
    border="#1E2A44",
    accent="#22D3EE",
    accent2="#2DD4BF",
    text="#E6EEF8",
    muted="#8CA3C3",
    faint="#5A6B87",
    input_bg="#0B1220",
    button_bg="#16233C",
    button_hover="#1D2F52",
    button_pressed="#101C33",
    card_hover="#182747",
    success="#34D399",
    warning="#FBBF24",
    danger="#F87171",
)


def _is_stock(tokens: ThemeTokens, reference: ThemeTokens) -> bool:
    """Đúng BỘ GỐC chưa tuỳ biến: mọi màu + bo góc + độ sáng + cỡ chữ
    + font đều khớp bộ tham chiếu (ảnh nền/độ phủ không tính — chúng
    là lựa chọn riêng được giữ lại khi di trú)."""
    same_colors = all(
        getattr(tokens, name) == getattr(reference, name)
        for name in _COLOR_FIELDS
    )
    same_shape = (
        tokens.radius == reference.radius
        and tokens.brightness == reference.brightness
        and tokens.font_scale == reference.font_scale
        and tokens.font_family == reference.font_family
    )
    return same_colors and same_shape


def migrate_saved_tokens(data: dict | None) -> ThemeTokens:
    """Tokens hiệu lực từ dict đã lưu: đúng một bộ GỐC cũ chưa tuỳ
    biến — Mission Control cyan của V4.3 (LEGACY_MISSION_TOKENS) hoặc
    Concept D của V4.3.1/V4.4 (CONCEPT_D_TOKENS) → trả bộ mặc định
    MỚI (MetaMint, giữ lại ảnh nền / độ phủ của người dùng); mọi tuỳ
    biến khác → giữ nguyên như tokens_from_dict."""
    tokens = tokens_from_dict(data)
    if (
        _is_stock(tokens, LEGACY_MISSION_TOKENS)
        or _is_stock(tokens, CONCEPT_D_TOKENS)
        or _is_stock(tokens, LEGACY_METAMINT_TOKENS)
        or _is_stock(tokens, LEGACY_V50_TOKENS)
    ):
        return _tokens_replace(
            METAMINT_TOKENS, bg_image=tokens.bg_image, bg_dim=tokens.bg_dim
        )
    return tokens


# --------------------------------------------------------------------------- #
# V5.1 — KỶ NGUYÊN GIAO DIỆN (theme epoch), plan §1.2
# --------------------------------------------------------------------------- #
# Bài học máy thật V5.0 (skill §13): di trú bằng "khớp tuyệt đối bộ
# gốc" THẤT BẠI vì settings lưu qua nhiều đời app luôn lệch vài
# trường → app giữ nguyên giao diện cũ đời này qua đời khác trong khi
# test di trú (dữ liệu sạch) vẫn xanh. Chuẩn V5.1: settings mang khoá
# `theme_epoch`; bản app mang THEME_EPOCH_CURRENT. Lần chạy đầu của
# một kỷ nguyên mới: áp bộ token của kỷ nguyên đó VÔ ĐIỀU KIỆN (chỉ
# giữ ảnh nền/độ phủ — lựa chọn riêng không thuộc bảng màu), bộ giá
# trị cũ sao lưu NGUYÊN VẸN sang `theme_backup_pre_v51` để khôi phục.
# Sau khi epoch đã khớp, lựa chọn của người dùng là tối cao: token
# đã lưu (kể cả bản khôi phục từ sao lưu) được tôn trọng tuyệt đối.
THEME_EPOCH_CURRENT = 63
THEME_EPOCH_KEY = "theme_epoch"
THEME_BACKUP_KEY = "theme_backup_pre_v51"


def apply_theme_epoch(settings: dict) -> tuple[ThemeTokens, bool]:
    """Giải quyết token hiệu lực lúc khởi động theo kỷ nguyên.

    Trả (tokens, changed): changed=True khi kỷ nguyên vừa được áp
    (settings đã bị sửa tại chỗ: theme_epoch + theme_tokens +
    theme_backup_pre_v51) — nơi gọi nên lưu settings ngay để lần
    chạy sau không áp lại (không thì khôi phục của người dùng sẽ bị
    ghi đè ở lần mở app kế tiếp)."""
    try:
        epoch = int(settings.get(THEME_EPOCH_KEY) or 0)
    except (TypeError, ValueError):
        epoch = 0
    saved = settings.get("theme_tokens")
    if epoch >= THEME_EPOCH_CURRENT:
        if isinstance(saved, dict) and saved:
            return tokens_from_dict(saved), False
        preset = str(settings.get("theme_preset") or "metamint")
        return PRESETS.get(preset, METAMINT_TOKENS), False
    old_tokens = (
        tokens_from_dict(saved)
        if isinstance(saved, dict) and saved
        else None
    )
    if old_tokens is not None and THEME_BACKUP_KEY not in settings:
        settings[THEME_BACKUP_KEY] = tokens_to_dict(old_tokens)
    new_tokens = METAMINT_TOKENS
    if old_tokens is not None:
        new_tokens = _tokens_replace(
            METAMINT_TOKENS,
            bg_image=old_tokens.bg_image,
            bg_dim=old_tokens.bg_dim,
        )
    settings["theme_tokens"] = tokens_to_dict(new_tokens)
    settings[THEME_EPOCH_KEY] = THEME_EPOCH_CURRENT
    return new_tokens, True


def restore_theme_backup(settings: dict) -> ThemeTokens | None:
    """Khôi phục bộ giao diện TRƯỚC kỷ nguyên hiện tại từ sao lưu.

    Trả tokens đã khôi phục (đã ghi vào settings["theme_tokens"];
    epoch GIỮ NGUYÊN để lần mở sau không áp lại kỷ nguyên lên bản
    khôi phục), hoặc None khi chưa có sao lưu."""
    backup = settings.get(THEME_BACKUP_KEY)
    if not isinstance(backup, dict) or not backup:
        return None
    tokens = tokens_from_dict(backup)
    settings["theme_tokens"] = tokens_to_dict(tokens)
    return tokens


def apply_v51_theme(settings: dict) -> ThemeTokens:
    """Áp lại bộ token V5.1 (nút "Áp dụng giao diện V5.1" trong mục
    Giao diện): ghi token kỷ nguyên hiện tại vào settings, giữ ảnh
    nền/độ phủ của bộ đang dùng."""
    current_data = settings.get("theme_tokens")
    current = (
        tokens_from_dict(current_data)
        if isinstance(current_data, dict) and current_data
        else METAMINT_TOKENS
    )
    tokens = _tokens_replace(
        METAMINT_TOKENS, bg_image=current.bg_image, bg_dim=current.bg_dim
    )
    settings["theme_tokens"] = tokens_to_dict(tokens)
    settings[THEME_EPOCH_KEY] = THEME_EPOCH_CURRENT
    return tokens
