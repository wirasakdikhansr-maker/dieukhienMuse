"""Panel "Báo cáo kênh" (V3.4): báo cáo hằng ngày + phân tích + xu
hướng + tiến độ phát triển cho TỪNG kênh, dựng từ bảng
channel_snapshots (mỗi lần quét kênh ghi một dòng mỗi kênh mỗi ngày).

Trung thực dữ liệu: kênh mới quét lần đầu chỉ có 1 điểm dữ liệu — các
cột Δ sẽ ghi "chưa đủ dữ liệu" thay vì số 0 giả; xu hướng rõ dần sau
vài ngày quét đều.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QMenu,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..store import Store
from . import theme

_SPARK_BLOCKS = "▁▂▃▄▅▆▇█"


def sparkline(series: list) -> str:
    """Chuỗi subs gần nhất -> biểu đồ mini bằng ký tự khối (▁..█).
    Ít hơn 2 điểm hoặc toàn bằng nhau -> '—' / '▬'."""
    values = [v for v in (series or []) if v is not None]
    if len(values) < 2:
        return "—"
    lo, hi = min(values), max(values)
    if hi == lo:
        return "▬" * len(values)
    span = hi - lo
    return "".join(
        _SPARK_BLOCKS[min(7, int((v - lo) / span * 7.99))] for v in values
    )


def _fmt_delta(value) -> str:
    if value is None:
        return "chưa đủ dữ liệu"
    if value > 0:
        return f"▲ +{value:,}"
    if value < 0:
        return f"▼ {value:,}"
    return "— 0"


class ReportsPanel(QWidget):
    def __init__(self, store: Store, settings: dict | None = None, parent=None):
        super().__init__(parent)
        self._store = store
        # V4.3.2 (F7): settings dùng chung để lưu bề rộng cột bảng.
        self._settings = settings
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        header = QHBoxLayout()
        header.addWidget(theme.section_header("Báo cáo kênh hằng ngày"))
        header.addStretch(1)
        self.date_label = QLabel("")
        self.date_label.setObjectName("Muted")
        header.addWidget(self.date_label)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        self.summary_label = QLabel("")
        self.summary_label.setObjectName("Muted")
        self.summary_label.setWordWrap(True)
        root.addWidget(self.summary_label)

        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Kênh",
                "Hồ sơ",
                "Subs hiện tại",
                "Δ hôm qua",
                "Δ 7 ngày",
                "Video",
                "Δ video 7 ngày",
                "Xu hướng subs",
            ]
        )
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header_view.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header_view.setSectionResizeMode(7, QHeaderView.ResizeMode.Stretch)
        # V4.3.2 (F7): mọi cột kéo chỉnh tự do + tự lưu bề rộng theo
        # bảng (mặc định chỉ áp khi chưa có số đã lưu).
        from . import table_persist

        table_persist.attach_column_persistence(
            self.table, self._settings, "reports_table",
            default_widths=(230, 140, 110, 100, 100, 80, 120, 170),
        )
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng gọn theo chuẩn chung (chỉ chữ).
        self.table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.table.font())
        )
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._table_menu)
        root.addWidget(self.table, 1)

        self.insight_label = QLabel("")
        self.insight_label.setObjectName("Muted")
        self.insight_label.setWordWrap(True)
        root.addWidget(self.insight_label)

        # V6.0 (GĐ2): tóm tắt GIÁM SÁT CHÉO tuần này (chi tiết từng
        # agent ở tab Giám sát).
        self.supervision_label = QLabel("")
        self.supervision_label.setObjectName("Muted")
        self.supervision_label.setWordWrap(True)
        root.addWidget(self.supervision_label)

    def select_channel(self, profile_id: int, channel_id: str) -> bool:
        """Chọn + cuộn tới dòng của (hồ sơ, kênh) — dùng bởi bảng
        tình trạng kênh phía trên (V4.3.1). True nếu thấy dòng."""
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item is not None and item.data(
                Qt.ItemDataRole.UserRole
            ) == f"{profile_id}|{channel_id}":
                self.table.selectRow(row)
                self.table.scrollToItem(item)
                return True
        return False

    # ------------------------------------------------------------------ #
    def _table_menu(self, pos):
        menu = QMenu(self)
        act = menu.addAction("↻ Làm mới ngay")
        act.triggered.connect(self.refresh)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _refresh_supervision_summary(self):
        """V6.0: một dòng tổng tuần của giám sát chéo — số vòng đã
        chấm theo kết luận + tỉ lệ đạt ngay lần đầu toàn đội."""
        from .. import supervision

        week_start = supervision.week_start_iso()
        counts: dict[str, int] = {}
        for review in self._store.list_reviews(limit=500):
            if str(review.get("created_at") or "") < week_start:
                continue
            counts[review["status"]] = counts.get(review["status"], 0) + 1
        agents = [a for a in self._store.list_agents() if not a.get("revoked")]
        passed0 = decided0 = 0
        for agent in agents:
            passed, decided = self._store.review_round_zero_pass_rate(
                int(agent["id"]), week_start
            )
            passed0 += passed
            decided0 += decided
        rate = f"{100.0 * passed0 / decided0:.0f}%" if decided0 else "—"
        self.supervision_label.setText(
            "🔍 Giám sát chéo tuần này (toàn đội): "
            f"đạt ngay lần đầu {rate} ({passed0}/{decided0} lệnh) · "
            f"đang chờ chấm {counts.get('open', 0)} · "
            f"đạt {counts.get('passed', 0)} · "
            f"làm lại {counts.get('rework', 0)} · "
            f"leo thang {counts.get('escalated', 0)}. "
            "Chi tiết từng agent ở tab Giám sát."
        )

    def refresh(self):
        self._refresh_supervision_summary()
        today = datetime.now().astimezone().strftime("%d/%m/%Y")
        self.date_label.setText(f"Ngày {today}")
        try:
            profiles = {p["id"]: p for p in self._store.list_profiles()}
            rows_data = []
            for profile_id, profile in profiles.items():
                for channel in self._store.list_channels(profile_id):
                    growth = self._store.channel_growth(
                        profile_id, channel["channel_id"]
                    )
                    rows_data.append((profile, channel, growth))
        except Exception as exc:
            self.summary_label.setText(f"Không đọc được dữ liệu báo cáo: {exc}")
            return

        total_subs = sum(c["subs"] or 0 for _, c, _ in rows_data)
        total_videos = sum(c["video_count"] or 0 for _, c, _ in rows_data)
        deltas_1d = [
            g["subs_delta_1d"] for _, _, g in rows_data if g["subs_delta_1d"] is not None
        ]
        deltas_7d = [
            g["subs_delta_7d"] for _, _, g in rows_data if g["subs_delta_7d"] is not None
        ]
        self.summary_label.setText(
            f"Tổng quan hôm nay: {len(rows_data)} kênh · {total_subs:,} subs"
            f" · {total_videos:,} video."
            + (
                f" Δ subs hôm qua (các kênh có dữ liệu): {sum(deltas_1d):+,}."
                if deltas_1d
                else " Chưa kênh nào có đủ 2 ngày dữ liệu để tính Δ hôm qua."
            )
            + (
                f" Δ subs 7 ngày: {sum(deltas_7d):+,}."
                if deltas_7d
                else ""
            )
            + " Số liệu lấy từ các lần Quét kênh — quét đều mỗi ngày để xu hướng rõ dần."
        )

        rows_data.sort(
            key=lambda item: (
                -(item[2]["subs_delta_7d"] or 0),
                -(item[1]["subs"] or 0),
            )
        )
        # V4.3.2 (F4): vân số liệu — không đổi thì giữ nguyên bảng.
        fingerprint = tuple(
            (
                profile["id"], channel["channel_id"], channel["name"],
                channel["subs"], channel["video_count"],
                growth["subs_delta_1d"], growth["subs_delta_7d"],
                growth["videos_delta_7d"], tuple(growth["series"] or []),
            )
            for profile, channel, growth in rows_data
        )
        if fingerprint == getattr(self, "_fingerprint", None):
            return
        self._fingerprint = fingerprint
        from . import table_persist

        with table_persist.batch_update(self.table):
            self._fill_rows(rows_data)

    def _fill_rows(self, rows_data):
        self.table.setRowCount(len(rows_data))
        for row, (profile, channel, growth) in enumerate(rows_data):
            values = [
                channel["name"] or channel["channel_id"],
                profile["label"],
                f"{channel['subs']:,}" if channel["subs"] is not None else "—",
                _fmt_delta(growth["subs_delta_1d"]),
                _fmt_delta(growth["subs_delta_7d"]),
                f"{channel['video_count']:,}"
                if channel["video_count"] is not None
                else "—",
                _fmt_delta(growth["videos_delta_7d"]),
                sparkline(growth["series"]),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(value)
                if col == 0:
                    # Neo (hồ sơ, kênh) trên dòng để bảng tình trạng
                    # kênh nhảy tới đúng dòng (V4.3.1). Dạng chuỗi —
                    # tuple qua QVariant sẽ hoá list, so sánh trượt.
                    item.setData(
                        Qt.ItemDataRole.UserRole,
                        f"{profile['id']}|{channel['channel_id']}",
                    )
                self.table.setItem(row, col, item)

        growing = [r for r in rows_data if (r[2]["subs_delta_7d"] or 0) > 0]
        declining = [r for r in rows_data if (r[2]["subs_delta_7d"] or 0) < 0]
        no_data = [r for r in rows_data if r[2]["subs_delta_7d"] is None]
        parts = []
        if growing:
            best = growing[0]
            parts.append(
                f"📈 Đang lên: {len(growing)} kênh — mạnh nhất: "
                f"{best[1]['name']} ({best[2]['subs_delta_7d']:+,} subs/7 ngày)."
            )
        if declining:
            worst = declining[-1]
            parts.append(
                f"📉 Đang xuống: {len(declining)} kênh — giảm nhất: "
                f"{worst[1]['name']} ({worst[2]['subs_delta_7d']:+,} subs/7 ngày)."
            )
        if no_data:
            parts.append(
                f"⏳ {len(no_data)} kênh chưa đủ dữ liệu 7 ngày "
                "(cần quét thêm vài ngày nữa)."
            )
        if not parts:
            parts.append("Chưa có kênh nào — quét kênh để bắt đầu có báo cáo.")
        self.insight_label.setText(" ".join(parts))
