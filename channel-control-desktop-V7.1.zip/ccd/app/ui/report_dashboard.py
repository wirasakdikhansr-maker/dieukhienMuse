"""V6.5 — tab Báo cáo dạng BẢNG ĐIỀU KHIỂN (theo bản thiết kế đã duyệt).

Hàng đầu: khoảng thời gian (Hôm nay · 7 ngày · 30 ngày) + lọc Muse +
mốc quét cuối + Quét lại + Xuất báo cáo ngày → 5 ô số → biểu đồ subs
theo ngày (đường) + việc theo Muse (cột chồng + KPI) → bảng từng kênh
(sparkline, tình trạng, đề xuất) + danh sách "Cần chú ý" có nút xử lý.
Mọi số đọc từ kho thật qua app/work_board.report.
"""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import work_board
from . import theme

LINE_COLORS = [theme.ACCENT, theme.ACCENT2, "#F2994A", "#BB86FC"]
STATE_COLORS = {"Tăng": theme.SUCCESS, "Đứng yên": theme.WARNING, "Có lỗi": theme.DANGER,
                "Thiếu dữ liệu": theme.FAINT}


def _card(object_name: str = "DashCard") -> QFrame:
    frame = QFrame()
    frame.setObjectName(object_name)
    frame.setStyleSheet(
        f"QFrame#{object_name} {{ background: {theme.PANEL}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}"
        f"QFrame#{object_name} QLabel {{ background: transparent; border: none; }}"
    )
    return frame


class LineChart(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.days: list[str] = []
        self.lines: list[dict] = []
        self.setMinimumHeight(200)

    def set_data(self, days, lines):
        self.days, self.lines = list(days), list(lines)
        self.update()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(52, 12, self.width() - 64, self.height() - 62)
        values = [v for line in self.lines for v in line["values"] if v is not None]
        p.setPen(QColor(theme.FAINT))
        if not values or not self.days:
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Chưa đủ dữ liệu quét kênh để vẽ (quét ≥ 2 ngày)")
            p.end()
            return
        lo, hi = min(values), max(values)
        if hi == lo:
            hi, lo = hi + 1, max(0, lo - 1)
        font = QFont(p.font())
        font.setPointSize(8)
        p.setFont(font)
        for i in range(4):
            y = rect.bottom() - rect.height() * i / 3
            p.setPen(QPen(QColor(theme.BORDER), 1))
            p.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            p.setPen(QColor(theme.FAINT))
            value = lo + (hi - lo) * i / 3
            p.drawText(QRectF(0, y - 8, 44, 16), Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
                       f"{value:,.0f}".replace(",", "."))
        n = len(self.days)
        step = max(1, n // 7)
        for i, day in enumerate(self.days):
            if i % step and i != n - 1:
                continue
            x = rect.left() + rect.width() * (i / max(1, n - 1))
            p.drawText(QRectF(x - 24, rect.bottom() + 6, 48, 14), Qt.AlignmentFlag.AlignCenter, f"{day[8:10]}/{day[5:7]}")
        legend_x = rect.left()
        for index, line in enumerate(self.lines):
            color = QColor(LINE_COLORS[index % len(LINE_COLORS)])
            path = QPainterPath()
            started = False
            for i, value in enumerate(line["values"][-n:]):
                if value is None:
                    continue
                x = rect.left() + rect.width() * (i / max(1, n - 1))
                y = rect.bottom() - rect.height() * (value - lo) / (hi - lo)
                if started:
                    path.lineTo(x, y)
                else:
                    path.moveTo(x, y)
                    started = True
            p.setPen(QPen(color, 2))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(color)
            p.drawEllipse(QPointF(legend_x + 4, self.height() - 12), 4, 4)
            p.setPen(QColor(theme.MUTED))
            label = line["name"][:22]
            p.drawText(QPointF(legend_x + 12, self.height() - 8), label)
            legend_x += 24 + p.fontMetrics().horizontalAdvance(label)
        p.end()


class MuseBars(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.muses: list[dict] = []
        self.setMinimumHeight(200)

    def set_data(self, muses):
        self.muses = list(muses)
        self.setMinimumHeight(max(200, 46 * len(self.muses) + 30))
        self.update()

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if not self.muses:
            p.setPen(QColor(theme.FAINT))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Chưa có tài khoản Muse")
            p.end()
            return
        top = max(1, max(m["done"] + m["running"] + m["failed"] for m in self.muses))
        font = QFont(p.font())
        font.setPointSize(9)
        p.setFont(font)
        y = 4
        bar_left = 130
        bar_w = max(60, self.width() - bar_left - 70)
        for m in self.muses:
            p.setPen(QColor(theme.TEXT))
            p.drawText(QRectF(0, y, bar_left - 8, 18), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       m["name"][:18])
            p.setPen(QColor(theme.FAINT))
            p.drawText(QRectF(0, y + 18, bar_left - 8, 16), Qt.AlignmentFlag.AlignLeft,
                       f"{m['channels']} kênh · {m['done']} xong")
            x = bar_left
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(theme.PROGRESS_TRACK))
            p.drawRoundedRect(QRectF(bar_left, y + 8, bar_w, 12), 6, 6)
            for key, color in (("done", theme.SUCCESS), ("running", theme.ACCENT), ("failed", theme.DANGER)):
                w = bar_w * m[key] / top
                if w > 0:
                    p.setBrush(QColor(color))
                    p.drawRoundedRect(QRectF(x, y + 8, w, 12), 4, 4)
                    x += w
            score = m.get("kpi")
            p.setPen(QColor(theme.SUCCESS if (score or 0) >= 70 else theme.WARNING if score else theme.FAINT))
            p.drawText(QRectF(bar_left + bar_w + 8, y + 2, 60, 22), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                       f"KPI {score:.0f}" if isinstance(score, (int, float)) else "KPI —")
            y += 46
        p.setPen(QColor(theme.MUTED))
        legend = [("Xong", theme.SUCCESS), ("Đang làm", theme.ACCENT), ("Lỗi", theme.DANGER)]
        lx = bar_left
        for text, color in legend:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(color))
            p.drawRoundedRect(QRectF(lx, self.height() - 16, 10, 10), 2, 2)
            p.setPen(QColor(theme.MUTED))
            p.drawText(QPointF(lx + 14, self.height() - 7), text)
            lx += 24 + p.fontMetrics().horizontalAdvance(text)
        p.end()


class Spark(QWidget):
    def __init__(self, values, parent=None):
        super().__init__(parent)
        self.values = [v for v in values if v is not None]
        self.setFixedSize(90, 26)

    def paintEvent(self, _event):
        if len(self.values) < 2:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        lo, hi = min(self.values), max(self.values)
        span = (hi - lo) or 1
        path = QPainterPath()
        for i, v in enumerate(self.values):
            x = 2 + (self.width() - 4) * i / (len(self.values) - 1)
            y = self.height() - 3 - (self.height() - 6) * (v - lo) / span
            path.lineTo(x, y) if i else path.moveTo(x, y)
        up = self.values[-1] >= self.values[0]
        p.setPen(QPen(QColor(theme.SUCCESS if up else theme.DANGER), 1.6))
        p.drawPath(path)
        p.end()


class ReportDashboard(QWidget):
    scan_requested = Signal()
    export_requested = Signal()
    assign_requested = Signal(int)      # profile_id → giao việc
    browser_requested = Signal(int)     # profile_id → mở trình duyệt
    scan_profile_requested = Signal(int)

    def __init__(self, store, settings: dict, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._days = int(settings.get("report_range_days", 7) or 7)
        self._fp = None
        self._build()
        self._timer = QTimer(self)
        self._timer.setInterval(15000)
        self._timer.timeout.connect(self.refresh)

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setStyleSheet(f"QScrollArea, QScrollArea > QWidget > QWidget {{ background: {theme.BG}; }}")
        host = QWidget()
        root = QVBoxLayout(host)
        root.setContentsMargins(16, 12, 16, 16)
        root.setSpacing(12)
        scroll.setWidget(host)
        outer.addWidget(scroll)

        head = QHBoxLayout()
        head.addWidget(theme.section_header("Báo cáo kênh"))
        self._range_group = QButtonGroup(self)
        for days, text in ((1, "Hôm nay"), (7, "7 ngày"), (30, "30 ngày")):
            button = QPushButton(text)
            button.setObjectName("FilterPill")
            button.setCheckable(True)
            button.setChecked(days == self._days)
            button.clicked.connect(lambda _c=False, d=days: self._set_days(d))
            self._range_group.addButton(button)
            head.addWidget(button)
        head.addSpacing(12)
        head.addWidget(theme.muted_label("Lọc Muse:"))
        self.muse_combo = QComboBox()
        self.muse_combo.setMinimumWidth(160)
        self.muse_combo.currentIndexChanged.connect(lambda _i: self._force())
        head.addWidget(self.muse_combo)
        head.addStretch(1)
        self.scan_label = theme.muted_label("")
        head.addWidget(self.scan_label)
        rescan = QPushButton("🔄 Quét lại")
        rescan.clicked.connect(self.scan_requested.emit)
        head.addWidget(rescan)
        export = QPushButton("📅 Xuất báo cáo ngày")
        export.setProperty("variant", "primary")
        export.clicked.connect(self.export_requested.emit)
        head.addWidget(export)
        root.addLayout(head)

        tiles = QHBoxLayout()
        tiles.setSpacing(10)
        self.tiles = []
        for _ in range(5):
            card = _card("DashTile")
            lay = QVBoxLayout(card)
            lay.setContentsMargins(14, 10, 14, 10)
            lay.setSpacing(2)
            label, value, delta = QLabel(), QLabel(), QLabel()
            label.setStyleSheet(f"color: {theme.MUTED}; font-size: 11px;")
            value.setStyleSheet(f"color: {theme.TEXT}; font-size: 22px; font-weight: 700;")
            delta.setStyleSheet(f"color: {theme.ACCENT}; font-size: 11px;")
            for w in (label, value, delta):
                lay.addWidget(w)
            self.tiles.append((label, value, delta))
            tiles.addWidget(card, 1)
        root.addLayout(tiles)

        charts = QHBoxLayout()
        charts.setSpacing(12)
        line_card = _card()
        lay = QVBoxLayout(line_card)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.addWidget(QLabel("<b>Subs theo ngày</b>"))
        self.line_chart = LineChart()
        lay.addWidget(self.line_chart, 1)
        charts.addWidget(line_card, 3)
        bars_card = _card()
        lay = QVBoxLayout(bars_card)
        lay.setContentsMargins(14, 10, 14, 10)
        self.bars_title = QLabel("<b>Việc theo Muse</b>")
        lay.addWidget(self.bars_title)
        self.bars = MuseBars()
        lay.addWidget(self.bars, 1)
        charts.addWidget(bars_card, 2)
        root.addLayout(charts)

        lower = QHBoxLayout()
        lower.setSpacing(12)
        table_card = _card()
        lay = QVBoxLayout(table_card)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.addWidget(QLabel("<b>Từng kênh</b>"))
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(["Kênh", "Muse", "Subs", "Δ", "Xu hướng", "Video mới",
                                              "Việc xong / lỗi", "Tình trạng · Đề xuất"])
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(7, QHeaderView.Stretch)
        self.table.setMinimumHeight(260)
        lay.addWidget(self.table, 1)
        lower.addWidget(table_card, 3)
        att_card = _card()
        lay = QVBoxLayout(att_card)
        lay.setContentsMargins(14, 10, 14, 10)
        self.att_title = QLabel("<b>Cần chú ý</b>")
        lay.addWidget(self.att_title)
        self.att_layout = QVBoxLayout()
        self.att_layout.setSpacing(8)
        lay.addLayout(self.att_layout)
        lay.addStretch(1)
        att_card.setMinimumWidth(300)
        lower.addWidget(att_card, 1)
        root.addLayout(lower, 1)

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        self._timer.start()
        self.refresh()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def _set_days(self, days: int):
        self._days = days
        self._settings["report_range_days"] = days
        self._force()

    def _force(self):
        self._fp = None
        self.refresh()

    def _sync_muses(self):
        agents = [a for a in self._store.list_agents() if not a.get("revoked")]
        wanted = [("Mọi Muse", None)] + [(a.get("name") or a.get("email"), int(a["id"])) for a in agents]
        current = [(self.muse_combo.itemText(i), self.muse_combo.itemData(i)) for i in range(self.muse_combo.count())]
        if wanted != current:
            keep = self.muse_combo.currentData()
            self.muse_combo.blockSignals(True)
            self.muse_combo.clear()
            for text, data in wanted:
                self.muse_combo.addItem(text, data)
            self.muse_combo.setCurrentIndex(max(0, self.muse_combo.findData(keep)))
            self.muse_combo.blockSignals(False)

    def refresh(self):
        try:
            self._sync_muses()
            data = work_board.report(self._store, self._days, self.muse_combo.currentData(),
                                     settings=self._settings)
        except Exception:
            return
        fp = repr((data["tiles"], [(r["name"], r["subs"], r["delta"], r["done"], r["failed"], r["state"]) for r in data["rows"]],
                   data["muses"], data["attention"], data["chart"]))
        if fp == self._fp:
            return
        self._fp = fp
        self.data = data
        self.scan_label.setText(f"Quét kênh lần cuối: {data['last_scan']}")
        for (label, value, delta), tile in zip(self.tiles, data["tiles"]):
            label.setText(tile["label"])
            value.setText(tile["value"])
            delta.setText(tile["delta"])
        self.line_chart.set_data(data["chart"]["days"], data["chart"]["lines"])
        self.bars_title.setText(f"<b>Việc theo Muse ({data['days']} ngày)</b>")
        self.bars.set_data(data["muses"])
        rows = data["rows"]
        self.table.setRowCount(len(rows))
        for i, r in enumerate(rows):
            delta = r["delta"]
            cells = [r["name"], r["muse"], "—" if r["subs"] is None else f"{r['subs']:,}".replace(",", "."),
                     "—" if delta is None else (f"+{delta}" if delta > 0 else str(delta)), "",
                     str(r["videos"]), f"{r['done']} / {r['failed']}", f"● {r['state']} — {r['tip']}"]
            for c, text in enumerate(cells):
                item = QTableWidgetItem(text)
                item.setData(Qt.ItemDataRole.UserRole, r["profile_id"])
                if c == 3 and delta is not None:
                    item.setForeground(QColor(theme.SUCCESS if delta > 0 else theme.DANGER if delta < 0 else theme.MUTED))
                if c == 7:
                    item.setForeground(QColor(STATE_COLORS.get(r["state"], theme.MUTED)))
                self.table.setItem(i, c, item)
            self.table.setCellWidget(i, 4, Spark(r["spark"]))
            self.table.setRowHeight(i, 32)
        while self.att_layout.count():
            item = self.att_layout.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        self.att_title.setText(f"<b>Cần chú ý ({len(data['attention'])})</b>")
        if not data["attention"]:
            self.att_layout.addWidget(theme.muted_label("Không có gì cần chú ý 🎉"))
        for att in data["attention"]:
            box = QFrame()
            box.setObjectName("AttItem")
            box.setStyleSheet(f"QFrame#AttItem {{ background: {theme.CARD}; border-radius: 8px;"
                              f" border-left: 3px solid {theme.WARNING}; }}")
            lay = QVBoxLayout(box)
            lay.setContentsMargins(10, 6, 10, 6)
            lay.setSpacing(2)
            title = QLabel(f"<b>{att['title']}</b>")
            title.setWordWrap(True)
            lay.addWidget(title)
            lay.addWidget(theme.muted_label(att["detail"]))
            text = {"scan": "Quét lại kênh →", "assign": "Giao Muse làm video mới →",
                    "open": "Mở trình duyệt hồ sơ →"}.get(att["action"], "Xem →")
            button = QPushButton(text)
            button.setProperty("variant", "ghost")
            pid = int(att["profile_id"])
            signal = {"scan": self.scan_profile_requested, "assign": self.assign_requested,
                      "open": self.browser_requested}.get(att["action"], self.browser_requested)
            button.clicked.connect(lambda _c=False, s=signal, p=pid: s.emit(p))
            lay.addWidget(button, 0, Qt.AlignmentFlag.AlignLeft)
            self.att_layout.addWidget(box)
