"""V6.8 — GIAO DIỆN CĂN PHÒNG cho Văn phòng 3D: mẫu văn phòng, màu sàn / tường /
bàn / màu nhấn, kiểu sàn, đồ trang trí (cây xanh, thảm, sofa, bảng trắng KPI,
kệ sách, máy nước). Lưu ở settings["office_theme"]."""

from __future__ import annotations

from PySide6.QtGui import QColor

PRESETS = {
    "modern_dark": {
        "label": "🌑 Hiện đại tối (mặc định)",
        "floor": "#1E2025", "floor2": "#23262C", "grid": "#2A2D33", "wall": "#16171B", "wall_side": "#121317",
        "window": "#1D3B5A", "desk": "#30343C", "accent": "#CEFC19", "pattern": "checker", "rug": "#1A2A12",
    },
    "warm_wood": {
        "label": "🪵 Gỗ ấm",
        "floor": "#5A3F2B", "floor2": "#65482F", "grid": "#4A3323", "wall": "#2B2420", "wall_side": "#241E1A",
        "window": "#3B5C74", "desk": "#8A6142", "accent": "#F2C94C", "pattern": "planks", "rug": "#6E3B2E",
    },
    "corporate_blue": {
        "label": "🏙 Doanh nghiệp kính xanh",
        "floor": "#1B2533", "floor2": "#1F2A3A", "grid": "#2A3850", "wall": "#152030", "wall_side": "#111A27",
        "window": "#2D6A9F", "desk": "#334256", "accent": "#6CC7FF", "pattern": "tiles", "rug": "#173250",
    },
    "light_minimal": {
        "label": "☁ Sáng tối giản",
        "floor": "#C9CDD3", "floor2": "#D2D6DB", "grid": "#B8BDC4", "wall": "#E4E6E9", "wall_side": "#D6D9DD",
        "window": "#9CCBEA", "desk": "#F3F4F6", "accent": "#2F80ED", "pattern": "tiles", "rug": "#AEB6C2",
    },
    "neon_night": {
        "label": "🌃 Đêm neon",
        "floor": "#140F24", "floor2": "#18122B", "grid": "#2A1F4A", "wall": "#0F0B1C", "wall_side": "#0C0917",
        "window": "#3A1F6B", "desk": "#241C3D", "accent": "#FF4FD8", "pattern": "checker", "rug": "#2A0F3A",
    },
}
PATTERNS = {"checker": "Ô bàn cờ", "planks": "Ván gỗ", "tiles": "Gạch lớn", "carpet": "Thảm trơn"}
PROPS = {
    "plants": "🪴 Cây xanh ở các góc",
    "rug": "🟫 Thảm dưới khu làm việc",
    "lounge": "🛋 Góc nghỉ (sofa + bàn trà)",
    "whiteboard": "📋 Bảng trắng KPI trên tường",
    "shelves": "📚 Kệ sách tường bên",
    "cooler": "🚰 Máy nước",
}
DEFAULT_THEME = {"preset": "modern_dark", "props": {k: True for k in PROPS}}


def _dark(hex_color: str, factor: int) -> str:
    return QColor(hex_color).darker(factor).name()


def resolve_theme(settings: dict | None, night: bool = False) -> dict:
    cfg = dict(DEFAULT_THEME)
    cfg.update((settings or {}).get("office_theme") or {})
    preset = PRESETS.get(cfg.get("preset"), PRESETS["modern_dark"])
    theme = {k: v for k, v in preset.items() if k != "label"}
    for key in ("floor", "wall", "desk", "accent", "pattern"):
        if cfg.get(key):
            theme[key] = cfg[key]
            if key == "floor":
                theme["floor2"] = QColor(cfg[key]).lighter(108).name()
                theme["grid"] = QColor(cfg[key]).darker(115).name()
            if key == "wall":
                theme["wall_side"] = QColor(cfg[key]).darker(112).name()
    props = dict(DEFAULT_THEME["props"])
    props.update(cfg.get("props") or {})
    theme["props"] = props
    if night:
        for key in ("floor", "floor2", "grid", "wall", "wall_side", "desk", "rug"):
            theme[key] = _dark(theme[key], 165)
        theme["window"] = "#0A1020"
    theme["desk_left"] = QColor(theme["desk"]).darker(130).name()
    theme["desk_right"] = QColor(theme["desk"]).darker(115).name()
    theme["desk_edge"] = QColor(theme["desk"]).lighter(125).name()
    theme["light"] = QColor(theme["floor"]).lightness() > 150
    return theme
