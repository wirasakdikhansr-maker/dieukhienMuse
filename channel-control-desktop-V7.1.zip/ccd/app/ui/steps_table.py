"""V6.3 — BẢNG VIỆC CHI TIẾT TỪNG BƯỚC (thay khối "Danh sách lệnh").

Mỗi việc là một dòng: Việc · Muse · Hồ sơ/kênh · Trạng thái · Tiến độ ·
Bước đang làm · MÔ TẢ CÁC BƯỚC (kế hoạch theo loại việc, đánh dấu bước
đã xong / đang làm / chưa tới). Mở dòng ra là thấy TOÀN BỘ lịch sử bước
Muse đã báo (giờ, %, nội dung nguyên văn — không tóm tắt chung chung).
Lệnh mới tạo tự hiện ngay ở đây (làm mới realtime theo DB).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QDialog, QMenu, QMessageBox, QToolTip,
    QTreeWidget, QTreeWidgetItem,
)

from ..store import COMMAND_TYPE_LABELS, Store, _parse_iso
from . import theme

STATUS_TEXT = {
    "queued": "⏳ Xếp hàng",
    "waiting_muse": "⏳ Chờ Muse nhận",
    "running": "▶ Đang làm",
    "needs_user": "✋ Chờ người",
    "done": "✓ Xong",
    "failed": "✕ Thất bại",
    "interrupted": "⏸ Bị ngắt",
    "cancelled": "⦸ Đã huỷ",
}
STATUS_COLOR = {
    "running": "#6CC7FF", "needs_user": "#C4A7FF", "failed": "#FF7A7A",
    "done": "#7DDC7A", "queued": "#F2C94C", "waiting_muse": "#F2C94C",
}

# Kế hoạch bước chuẩn theo loại việc — mốc % để đánh dấu tiến trình.
TYPE_PLAN: dict[str, list[tuple[int, str]]] = {
    "create_video": [
        (5, "Nhận việc, đọc yêu cầu + skill"),
        (20, "Nghiên cứu chủ đề, chọn góc kể"),
        (40, "Viết kịch bản + tiêu đề/mô tả"),
        (60, "Tạo hình ảnh/giọng đọc/nhạc"),
        (80, "Dựng & render video"),
        (95, "Đăng lên kênh / giao file vào app"),
        (100, "Báo kết quả + bằng chứng (link/file)"),
    ],
    "upload": [
        (10, "Nhận file video + thông tin đăng"),
        (40, "Mở YouTube Studio của kênh đích"),
        (70, "Tải lên + điền tiêu đề/mô tả/thẻ"),
        (90, "Chọn thumbnail, lịch đăng"),
        (100, "Báo link video đã đăng"),
    ],
    "optimize": [
        (10, "Đọc số liệu kênh / video"),
        (40, "Đề xuất tiêu đề, mô tả, thẻ mới"),
        (80, "Cập nhật trên YouTube Studio"),
        (100, "Báo thay đổi + trước/sau"),
    ],
    "create_channel": [
        (20, "Mở tài khoản Google của hồ sơ"),
        (60, "Tạo kênh thương hiệu + tên/handle"),
        (90, "Ảnh đại diện, banner, mô tả"),
        (100, "Báo link kênh"),
    ],
    "review": [
        (10, "Đọc lệnh gốc + bằng chứng"),
        (60, "Kiểm từng mục checklist"),
        (100, "Chốt kết luận Đạt / Làm lại / Leo thang"),
    ],
    "free": [
        (10, "Nhận việc, làm rõ yêu cầu"),
        (90, "Thực hiện theo yêu cầu"),
        (100, "Báo kết quả + bằng chứng"),
    ],
    "scan": [(50, "Mở Chrome hồ sơ, đọc danh sách kênh"), (100, "Lưu kênh vào app")],
    "open_browser": [(100, "Mở Chrome của hồ sơ")],
    "studio_script": [(10, "Mở Studio"), (90, "Chạy từng bước kịch bản"), (100, "Chụp ảnh kết quả")],
}


def plan_text(command: dict) -> str:
    plan = TYPE_PLAN.get(command.get("type") or "") or [
        (50, "Thực hiện yêu cầu"), (100, "Báo kết quả")]
    progress = int(command.get("progress") or 0)
    status = command.get("status")
    parts = []
    current_marked = False
    for index, (mark, label) in enumerate(plan, start=1):
        if status == "done" or progress >= mark:
            icon = "✓"
        elif not current_marked and status in ("running", "needs_user"):
            icon = "▶" if status == "running" else "✋"
            current_marked = True
        else:
            icon = "○"
        parts.append(f"{icon} {index}. {label}")
    return "   ".join(parts)


def _fmt_time(value) -> str:
    at = _parse_iso(value) if value else None
    return at.strftime("%d/%m %H:%M:%S") if at else "—"


class StepsTable(QTreeWidget):
    """V6.9: chọn NHIỀU dòng (Ctrl/Shift/kéo), menu chuột phải đầy đủ với
    thao tác hàng loạt; rê chuột lên cột Trạng thái → popup vì sao kẹt."""

    command_chosen = Signal(str)
    open_browser_requested = Signal(int)
    selection_info = Signal(str)

    HEADERS = ["Việc", "Muse", "Hồ sơ / kênh", "Trạng thái", "Tiến độ",
               "Bước đang làm (Muse báo)", "Mô tả các bước"]

    def __init__(self, store: Store, settings: dict, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._fingerprint = None
        self._filter_agent: int | None = None
        self.setColumnCount(len(self.HEADERS))
        self.setHeaderLabels(self.HEADERS)
        self.setUniformRowHeights(False)
        self.setWordWrap(True)
        self.setAlternatingRowColors(False)
        self.setStyleSheet(
            f"QTreeWidget {{ background: {theme.BG}; color: {theme.TEXT};"
            f" border: 1px solid {theme.BORDER}; }}"
            f"QTreeWidget::item {{ padding: 4px 2px; border-bottom: 1px solid {theme.BORDER}; }}"
            f"QTreeWidget::item:selected {{ background: {theme.CARD}; }}"
            f"QHeaderView::section {{ background: {theme.PANEL}; color: {theme.MUTED};"
            f" border: none; padding: 5px 8px; }}"
        )
        from . import table_persist

        table_persist.attach_column_persistence(
            self, settings, "work_steps_table",
            default_widths=(260, 110, 170, 120, 80, 320, 640),
        )
        self.itemClicked.connect(self._on_clicked)
        self._actions = None  # CommandsPanel — nguồn các thao tác chuẩn
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(self._on_menu)
        self.itemSelectionChanged.connect(self._emit_selection_info)
        self.setStyleSheet(self.styleSheet() + (
            f"QTreeWidget::item:selected {{ background: #22301A; color: {theme.TEXT};"
            f" border-top: 1px solid {theme.ACCENT}; border-bottom: 1px solid {theme.ACCENT}; }}"
        ))

    def set_actions(self, commands_panel) -> None:
        self._actions = commands_panel

    # ---- chọn nhiều ---- #
    def selected_command_ids(self) -> list[str]:
        out: list[str] = []
        for item in self.selectedItems():
            cid = item.data(0, Qt.UserRole)
            if cid and str(cid) not in out:
                out.append(str(cid))
        if not out and self.currentItem() is not None and self.currentItem().data(0, Qt.UserRole):
            out.append(str(self.currentItem().data(0, Qt.UserRole)))
        return out

    def select_command_ids(self, ids) -> None:
        wanted = {str(i) for i in ids or []}
        self.clearSelection()
        for i in range(self.topLevelItemCount()):
            item = self.topLevelItem(i)
            if str(item.data(0, Qt.UserRole)) in wanted:
                item.setSelected(True)

    def _emit_selection_info(self):
        ids = self.selected_command_ids()
        self.selection_info.emit(f"Đã chọn {len(ids)} việc" if len(ids) > 1 else "")

    # ---- popup giải thích ---- #
    def viewportEvent(self, event):
        if event.type() == QEvent.Type.ToolTip:
            item = self.itemAt(event.pos())
            column = self.columnAt(event.pos().x())
            if item is not None and column in (3, 4, 5):
                cid = item.data(0, Qt.UserRole)
                if cid:
                    from .. import command_actions

                    try:
                        QToolTip.showText(event.globalPos(), command_actions.explain_html(self._store, str(cid)), self)
                    except Exception:
                        pass
                    return True
        return super().viewportEvent(event)

    def set_agent_filter(self, agent_id: int | None):
        self._filter_agent = agent_id
        self._fingerprint = None
        self.refresh()

    def _rows(self) -> list[dict]:
        since = (datetime.now().astimezone() - timedelta(hours=48)).isoformat(timespec="seconds")
        rows = self._store._conn.execute(
            "SELECT * FROM commands WHERE (status IN ('queued','waiting_muse','running','needs_user')"
            " OR updated_at >= ?) ORDER BY CASE status WHEN 'running' THEN 0 WHEN 'needs_user' THEN 1"
            " WHEN 'waiting_muse' THEN 2 WHEN 'queued' THEN 3 ELSE 4 END, updated_at DESC LIMIT 300",
            (since,),
        ).fetchall()
        from ..store import _command_row

        out = [_command_row(r) for r in rows]
        if self._filter_agent is not None:
            out = [c for c in out if c.get("agent_id") == self._filter_agent]
        return out

    def refresh(self):
        try:
            commands = self._rows()
        except Exception:
            return
        steps = self._store.steps_for_commands([c["id"] for c in commands])
        fingerprint = tuple(
            (c["id"], c["status"], c.get("progress"), c.get("step"), c.get("agent_id"),
             len(steps.get(c["id"]) or []))
            for c in commands
        )
        if fingerprint == self._fingerprint:
            return
        self._fingerprint = fingerprint
        expanded = {
            self.topLevelItem(i).data(0, Qt.UserRole)
            for i in range(self.topLevelItemCount())
            if self.topLevelItem(i).isExpanded()
        }
        selected = self.currentItem().data(0, Qt.UserRole) if self.currentItem() else None
        selected_many = {str(i) for i in self.selected_command_ids()}
        agents = {a["id"]: a for a in self._store.list_agents()}
        profiles = {p["id"]: p for p in self._store.list_profiles()}
        self.setUpdatesEnabled(False)
        self.clear()
        for command in commands:
            agent = agents.get(command.get("agent_id"))
            profile = profiles.get(command.get("profile_id"))
            label = COMMAND_TYPE_LABELS.get(command["type"], command["type"])
            title = f"{label} · {(command.get('instruction') or '').strip()[:120]}"
            history = steps.get(command["id"]) or []
            current = command.get("step") or (history[-1]["step"] if history else "")
            if not current:
                current = {
                    "queued": "Đang xếp hàng — chờ tới lượt",
                    "waiting_muse": "Chờ Muse nhận việc (claim)",
                    "done": "Đã xong",
                }.get(command["status"], "Muse chưa báo bước nào")
            item = QTreeWidgetItem([
                title,
                (agent or {}).get("name") or "—",
                ((profile or {}).get("label") or command.get("profile_slug") or "—")
                + (f" · {command['channel_id']}" if command.get("channel_id") else ""),
                STATUS_TEXT.get(command["status"], command["status"]),
                f"{int(command.get('progress') or 0)}%",
                current,
                plan_text(command),
            ])
            item.setData(0, Qt.UserRole, command["id"])
            item.setToolTip(0, f"#{command['id']}\n{command.get('instruction') or ''}")
            item.setToolTip(6, plan_text(command).replace("   ", "\n"))
            color = STATUS_COLOR.get(command["status"])
            if color:
                item.setForeground(3, QBrush(QColor(color)))
            if command.get("error") or command.get("result"):
                item.setToolTip(5, (command.get("error") or command.get("result") or "")[:800])
            for index, step in enumerate(history, start=1):
                child = QTreeWidgetItem([
                    f"   {index}. {step['step']}", "", "", _fmt_time(step["at"]),
                    f"{step['progress']}%", step["step"], step.get("actor") or "",
                ])
                child.setData(0, Qt.UserRole, command["id"])
                child.setForeground(0, QBrush(QColor(theme.MUTED)))
                item.addChild(child)
            if not history:
                child = QTreeWidgetItem(["   (Muse chưa báo bước nào — mỗi lần báo tiến độ sẽ thêm một dòng ở đây)"])
                child.setForeground(0, QBrush(QColor(theme.FAINT)))
                item.addChild(child)
            self.addTopLevelItem(item)
            if command["id"] in expanded or (not expanded and command["status"] == "running"):
                item.setExpanded(True)
            if selected and command["id"] == selected and len(selected_many) <= 1:
                self.setCurrentItem(item)
            if len(selected_many) > 1 and command["id"] in selected_many:
                item.setSelected(True)
        self.setUpdatesEnabled(True)

    def _on_clicked(self, item: QTreeWidgetItem, _column: int):
        command_id = item.data(0, Qt.UserRole)
        if command_id:
            self.command_chosen.emit(str(command_id))

    # ------------------------------------------------------------------ #
    # V6.9 — menu chuột phải (một hoặc NHIỀU dòng)
    # ------------------------------------------------------------------ #
    def _notify(self, message: str):
        panel = self._actions
        if panel is not None and hasattr(panel, "_notify"):
            try:
                panel._notify(message)
                return
            except Exception:
                pass
        self.selection_info.emit(message)

    def _after_change(self):
        self._fingerprint = None
        self.refresh()
        panel = self._actions
        if panel is not None:
            for name in ("_signal_dispatch_now", "_refresh_table"):
                try:
                    getattr(panel, name)()
                except Exception:
                    pass

    def _on_menu(self, pos):
        item = self.itemAt(pos)
        if item is not None and not item.isSelected():
            # chuột phải lên dòng CHƯA chọn → chọn riêng dòng đó
            # (dòng đã nằm trong vùng chọn → giữ nguyên vùng chọn).
            if not (QApplication.keyboardModifiers() & (Qt.ControlModifier | Qt.ShiftModifier)):
                self.clearSelection()
            item.setSelected(True)
        ids = self.selected_command_ids()
        menu = self.build_menu(ids)
        menu.exec(self.viewport().mapToGlobal(pos))

    def build_menu(self, ids: list[str]) -> QMenu:
        from .. import command_actions as ca

        menu = QMenu(self)
        info = ca.summarize_selection(self._store, ids)
        n = info["total"]
        single = self._store.get_command(ids[0]) if n == 1 else None
        if n == 0:
            act = menu.addAction("☑ Chọn tất cả")
            act.triggered.connect(self.selectAll)
            act = menu.addAction("↻ Làm mới")
            act.triggered.connect(self._force_refresh)
            return menu
        head = menu.addAction(f"{'1 việc' if n == 1 else f'{n} việc đã chọn'}"
                              + (f" · {info['running']} đang chạy" if info["running"] else ""))
        head.setEnabled(False)
        menu.addSeparator()
        if single is not None and single["status"] in ("queued", "waiting_muse"):
            act = menu.addAction("▶ Chạy ngay")
            act.triggered.connect(lambda _=False, c=single["id"]: self._run_now(c))
        act = menu.addAction(f"▶ Chạy tiếp / ↻ Thử lại ({info['resumable']})")
        act.setEnabled(info["resumable"] > 0)
        act.setToolTip("Chờ người → chạy tiếp; thất bại/bị ngắt → thử lại")
        act.triggered.connect(lambda: self.do_resume(ids))
        act = menu.addAction(f"🎯 Giao cho Muse… ({n})")
        act.triggered.connect(lambda: self._pick_and_assign(ids))
        act = menu.addAction(f"📨 Gửi lại trọn việc qua chat ({info['open']})")
        act.setEnabled(info["open"] > 0)
        act.triggered.connect(lambda: self.do_resend(ids))
        act = menu.addAction(f"⏱ Gia hạn +1 giờ ({info['open']})")
        act.setEnabled(info["open"] > 0)
        act.triggered.connect(lambda: self.do_extend(ids, 60))
        act = menu.addAction(f"✕ Huỷ ({info['open']})")
        act.setEnabled(info["open"] > 0)
        act.triggered.connect(lambda: self.do_cancel(ids))
        menu.addSeparator()
        if single is not None:
            if self._actions is not None and hasattr(self._actions, "ask_about_command"):
                act = menu.addAction("💬 Hỏi Muse về việc này")
                act.triggered.connect(lambda _=False, c=single["id"]: self._actions.ask_about_command.emit(c))
            if single.get("profile_id"):
                act = menu.addAction("🌐 Mở trình duyệt của hồ sơ")
                act.triggered.connect(lambda _=False, pid=int(single["profile_id"]): self.open_browser_requested.emit(pid))
                if self._actions is not None and hasattr(self._actions, "_open_profile"):
                    act = menu.addAction("👤 Mở trang Hồ sơ")
                    act.triggered.connect(lambda _=False, pid=single["profile_id"]: self._actions._open_profile(pid))
            act = menu.addAction("📋 Xem chi tiết lệnh")
            act.triggered.connect(lambda _=False, c=single["id"]: self.command_chosen.emit(c))
        act = menu.addAction(f"⧉ Sao chép mã việc ({n})")
        act.triggered.connect(lambda: QApplication.clipboard().setText("\n".join(ids)))
        menu.addSeparator()
        act = menu.addAction(f"🗑 Xoá {n} lệnh" + (f" (giữ {info['running']} đang chạy)" if info["running"] else ""))
        act.setEnabled(info["deletable"] > 0)
        act.triggered.connect(lambda: self.do_delete(ids))
        menu.addSeparator()
        act = menu.addAction("☑ Chọn tất cả")
        act.triggered.connect(self.selectAll)
        act = menu.addAction("☐ Bỏ chọn")
        act.triggered.connect(self.clearSelection)
        act = menu.addAction("↻ Làm mới")
        act.triggered.connect(self._force_refresh)
        return menu

    def _force_refresh(self):
        self._fingerprint = None
        self.refresh()

    def _run_now(self, command_id: str):
        panel = self._actions
        if panel is not None and hasattr(panel, "_run_guarded"):
            panel._run_guarded(command_id)
        self._after_change()

    # ---- hiệu lực (gọi được trong kiểm thử, không hộp thoại) ---- #
    def do_resume(self, ids):
        from .. import command_actions as ca

        r = ca.bulk_resume(self._store, ids)
        self._notify(f"▶ Đã cho chạy tiếp {r['resumed']} việc" + (f" · bỏ qua {r['skipped']}" if r["skipped"] else "") + ".")
        self._after_change()
        return r

    def do_resend(self, ids):
        from .. import command_actions as ca

        r = ca.bulk_resend(self._store, ids)
        self._notify(f"📨 Sẽ gửi lại trọn nội dung {r['resent']} việc qua chat muse.ai.")
        self._after_change()
        return r

    def do_extend(self, ids, minutes: int = 60):
        from .. import command_actions as ca

        r = ca.bulk_extend(self._store, ids, minutes)
        self._notify(f"⏱ Đã gia hạn {r['extended']} việc thêm {minutes} phút.")
        self._after_change()
        return r

    def do_assign(self, ids, agent_id: int):
        from .. import command_actions as ca

        r = ca.bulk_assign(self._store, ids, int(agent_id))
        agent = self._store.get_agent(int(agent_id)) or {}
        self._notify(f"🎯 Đã giao {r['assigned']} việc cho '{agent.get('name') or agent_id}'"
                     + (f" · bỏ qua {r['skipped']} việc đã kết thúc" if r["skipped"] else "") + ".")
        self._after_change()
        return r

    def do_cancel(self, ids, confirm: bool = True):
        from .. import command_actions as ca

        if confirm and len(ids) > 1:
            if QMessageBox.question(self, "Huỷ hàng loạt", f"Huỷ {len(ids)} việc đã chọn?") != QMessageBox.StandardButton.Yes:
                return None
        panel = self._actions
        cancel_one = getattr(panel, "_cancel_one", None) if panel is not None else None
        if cancel_one is None:
            def cancel_one(row):
                if row["status"] == "running":
                    return False
                self._store.finish_command(row["id"], "failed", result="Đã huỷ bởi người dùng.",
                                           error="Đã huỷ bởi người dùng.")
                return True
        r = ca.bulk_cancel(self._store, ids, cancel_one)
        self._notify(f"✕ Đã huỷ {r['cancelled']} việc" + (f" · bỏ qua {r['skipped']}" if r["skipped"] else "") + ".")
        self._after_change()
        return r

    def do_delete(self, ids, confirm: bool = True):
        from .. import command_actions as ca

        if confirm:
            text = f"Xoá {len(ids)} lệnh đã chọn? Không hoàn tác được."
            if QMessageBox.question(self, "Xoá hàng loạt", text) != QMessageBox.StandardButton.Yes:
                return None
        r = ca.bulk_delete(self._store, ids)
        self._notify(f"🗑 Đã xoá {r['deleted']} lệnh" + (f" · giữ {r['kept_running']} đang chạy" if r["kept_running"] else "") + ".")
        self._after_change()
        return r

    def _pick_and_assign(self, ids):
        from .dialogs import AgentPickerDialog

        agents = [a for a in self._store.list_agents() if not a.get("revoked")]
        if not agents:
            self._notify("Chưa có tài khoản Muse nào — thêm ở tab Tài khoản Muse trước.")
            return
        first = self._store.get_command(ids[0]) if ids else None
        dialog = AgentPickerDialog(agents, current_agent_id=(first or {}).get("agent_id"), parent=self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        agent_id = dialog.selected_agent_id()
        if agent_id is not None:
            self.do_assign(ids, agent_id)
