"""Panel "Lệnh công việc" (V3) — trung tâm ra lệnh của app.

Người dùng tạo lệnh ngay trong tool: chọn hồ sơ đích, Muse nhận lệnh,
loại lệnh (+ kênh khi loại lệnh cần), nội dung yêu cầu, hẹn giờ tuỳ
chọn. Lệnh được lưu vào bảng commands DÙNG CHUNG với Agent API:

- MỌI lệnh đều vào 'queued' (V4.0 Đ5). Loại app tự làm được (Mở trình
  duyệt / Quét kênh / Kiểm tra kênh): CommandRunner của app chạy tại
  máy và cập nhật trạng thái.
- Loại cần Muse làm (Tối ưu / Tải video / Tạo video / Tạo kênh / Tự
  do): dispatcher xét điều kiện DỮ LIỆU (phân công, hẹn giờ, phụ
  thuộc, file…) rồi đẩy lên 'waiting_muse' — Muse nhận (claim) qua
  Agent API và báo cáo lại; danh sách ở đây tự cập nhật. Không còn
  cổng trình duyệt/đăng nhập nào giữ lệnh (V4.1.2/V4.2).
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from datetime import datetime, timedelta

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QInputDialog,
    QLabel,
    QLineEdit,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import auto_retry, command_schema, skills_lib, studio_script
from ..store import (
    CLAUDE_COMMAND_TYPES,
    COMMAND_TYPE_LABELS,
    LOCAL_COMMAND_TYPES,
    Store,
)
from . import theme
from .dialogs import AgentPickerDialog

STATUS_LABELS = {
    "queued": "Đang chờ",
    "running": "Đang chạy",
    "waiting_muse": "Chờ Muse",
    "needs_user": "⏸ Chờ người xử lý",
    "done": "Xong",
    "failed": "Thất bại",
    "interrupted": "Bị gián đoạn",
}
#: V5.3.2 (M-BULK): tập trạng thái CHƯA KẾT THÚC mà nút "✕ Huỷ lệnh"
#: của từng dòng xử lý được. "Huỷ tất cả lệnh" ở menu chuột phải
#: dùng ĐÚNG tập này và đúng đường huỷ của nút đơn (_cancel_one) —
#: không chế đường riêng. Trạng thái kết thúc (done / failed /
#: interrupted) không bao giờ bị đụng tới.
CANCELLABLE_STATUSES = ("queued", "waiting_muse", "running", "needs_user")
# (màu chữ, màu nền RGBA) cho ô trạng thái — vẽ bằng item thuần, KHÔNG dùng
# cell-widget: bảng tự làm mới mỗi 4 giây, widget trong ô dễ thành "mồ côi"
# khi bảng chưa kịp layout (đã gặp vệt pill lạc vị trí ở lần dựng đầu).
# V4.3.1: bảng màu Concept D (chạy #6CC7FF, xong #43D675, lỗi #FF7A7A,
# chờ #F2C94C) — ô nhuộm nền mờ + chữ đậm + ký hiệu đứng đầu, trông như
# pill mà vẫn là item thuần.
STATUS_ITEM_COLORS = {
    "queued": ("#9BA196", (155, 161, 150, 30)),
    "running": ("#6CC7FF", (62, 207, 106, 30)),
    "waiting_muse": ("#F2C94C", (217, 164, 65, 30)),
    "needs_user": ("#C4A7FF", (199, 127, 161, 30)),
    "done": ("#43D675", (67, 214, 117, 30)),
    "failed": ("#FF7A7A", (214, 92, 92, 30)),
    "interrupted": ("#D98E4A", (217, 142, 74, 30)),
}
# Ký hiệu đứng đầu ô trạng thái (dạng chữ, đúng mẫu Concept D:
# ✓ xong / ⟳ đang chạy / ✕ lỗi).
STATUS_GLYPHS = {
    "queued": "◷ ",
    "running": "⟳ ",
    "waiting_muse": "⏳ ",
    "needs_user": "",
    "done": "✓ ",
    "failed": "✕ ",
    "interrupted": "✕ ",
}
# Chip màu theo LOẠI lệnh cho cột Loại (item thuần: chữ + nền mờ).
TYPE_ITEM_COLORS = {
    "open_browser": ("#6CC7FF", (62, 207, 106, 36)),
    "scan": ("#B5C48D", (181, 196, 141, 36)),
    "check": ("#43D675", (67, 214, 117, 36)),
    "optimize": ("#F2C94C", (217, 164, 65, 36)),
    "upload": ("#7CE38B", (124, 227, 139, 36)),
    "create_video": ("#C4A7FF", (199, 127, 161, 36)),
    "create_channel": ("#43D675", (67, 214, 117, 36)),
    "free": ("#9BA196", (155, 161, 150, 36)),
    "studio_script": ("#D98E4A", (217, 142, 74, 36)),
}
# V4.4: studio_script là loại CDP duy nhất có mặt trong dropdown tạo
# lệnh (app tự chạy trong Chrome nhúng — người dùng tự tạo/chạy thử
# được; các cdp_* một-hành-động vẫn chỉ đi qua Agent API).
UI_COMMAND_TYPES = LOCAL_COMMAND_TYPES + CLAUDE_COMMAND_TYPES + ("studio_script",)

# V5.3 (A3/A5): chiều cao nút trong hàng lọc + nút thao tác trong
# dòng bảng lệnh — 24px theo lệnh chủ kênh (hàng bảng tính chiều
# cao từ đúng số này, không còn đo từ nút mẫu ~56px như V3.8).
# V5.3.1 (M2): đây chỉ còn là MẶC ĐỊNH — giá trị hiệu lực đọc từ
# setting row_action_button_height qua theme.row_action_height
# (người dùng chỉnh 20–36px trong Cài đặt → Giao diện).
ACTION_BUTTON_HEIGHT = 24

_RESULT_SUMMARY_MAX = 110


def _summarize_dict_result(data: dict, status: str) -> str:
    """Tóm tắt NGẮN một kết quả dạng dict (V5.3 — A5): bản cũ in
    nguyên repr dict vào cột Kết quả (dài, khó đọc). Ưu tiên:
    kịch bản Studio → 'studio_script · x/y bước · <trạng thái>';
    có message/summary ngắn → dùng nó; còn lại → đếm mục dữ liệu."""
    kind = str(data.get("kind") or "")
    if kind == "studio_script" or "total_steps" in data:
        total = data.get("total_steps")
        done_steps = data.get("completed_steps")
        state = {
            "done": "xong",
            "failed": "lỗi giữa chừng",
            "needs_user": "chờ người xử lý",
        }.get(status, status or "")
        text = f"studio_script · {done_steps}/{total} bước"
        if state:
            text += f" · {state}"
        reads = data.get("reads") or {}
        if reads:
            text += f" · đọc {len(reads)} mục"
        return text
    for key in ("summary", "message"):
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return " ".join(value.split())[:_RESULT_SUMMARY_MAX]
    label = kind or "dữ liệu"
    return f"{label} · {len(data)} mục"


def summarize_result(command: dict) -> str:
    """Chuỗi NGẮN cho cột KẾT QUẢ (V5.3 — A5). Kết quả đầy đủ vẫn
    xem được ở tooltip của ô (xem _fill_table)."""
    import ast

    data = command.get("result_data")
    if isinstance(data, dict) and data:
        return _summarize_dict_result(data, command.get("status") or "")
    raw = (command.get("result") or "").strip()
    if raw.startswith("{"):
        # Kết quả text nhưng bản chất là repr của dict (đường API
        # cũ / Muse báo cáo dạng dict) — parse an toàn để tóm tắt.
        try:
            parsed = ast.literal_eval(raw)
        except (ValueError, SyntaxError):
            parsed = None
        if isinstance(parsed, dict) and parsed:
            return _summarize_dict_result(
                parsed, command.get("status") or ""
            )
    if raw:
        first = " ".join(raw.split())
        if len(first) > _RESULT_SUMMARY_MAX:
            return first[: _RESULT_SUMMARY_MAX - 1] + "…"
        return first
    error = (command.get("error") or "").strip()
    if error:
        first = " ".join(error.split())
        if len(first) > _RESULT_SUMMARY_MAX:
            return first[: _RESULT_SUMMARY_MAX - 1] + "…"
        return first
    return "—"


class _QueueRow(QFrame):
    """Dòng GỌN trong "Hàng đợi lệnh" (V4.5 — cột Giao việc): chấm
    trạng thái + tiêu đề + dòng phụ + cụm phải (% / tiến độ lô / huy
    hiệu tự-chạy-lại). Bấm dòng → phát id lệnh đại diện để panel chọn
    đúng lệnh đó ở bảng bên phải và bảng việc làm nổi bật theo."""

    clicked = Signal(str)
    # V4.6: chuột phải → "💬 Hỏi về lệnh này" (mở chat với Muse
    # phụ trách, gắn ngữ cảnh chính lệnh này).
    ask_requested = Signal(str)

    def __init__(self, command_id, title, sub, right_text, status, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.command_id = command_id
        self.setCursor(Qt.PointingHandCursor)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 6)
        layout.setSpacing(8)
        fg, _bg = STATUS_ITEM_COLORS.get(status, STATUS_ITEM_COLORS["queued"])
        dot = QLabel("●")
        dot.setStyleSheet(f"color:{fg}; font-size:14px;")
        layout.addWidget(dot)
        texts = QVBoxLayout()
        texts.setSpacing(0)
        title_label = QLabel(title)
        title_label.setObjectName("CardTitle")
        title_label.setWordWrap(True)
        texts.addWidget(title_label)
        if sub:
            sub_label = QLabel(sub)
            sub_label.setObjectName("Faint12")
            sub_label.setWordWrap(True)
            texts.addWidget(sub_label)
        layout.addLayout(texts, 1)
        if right_text:
            right = QLabel(right_text)
            right.setObjectName("Muted")
            right.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            layout.addWidget(right)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.command_id:
            self.clicked.emit(str(self.command_id))
        super().mousePressEvent(event)

    def contextMenuEvent(self, event):
        if not self.command_id:
            return
        menu = QMenu(self)
        act = menu.addAction("💬 Hỏi về lệnh này")
        act.triggered.connect(
            lambda _=False: self.ask_requested.emit(str(self.command_id))
        )
        menu.exec(event.globalPos())


class _ElidedLabel(QLabel):
    """Nhãn MỘT DÒNG tự cắt cụt bằng dấu … theo bề rộng THẬT của
    widget (V5.3 — A3): text() vẫn giữ NGUYÊN VĂN đầy đủ (tooltip
    cũng vậy) nhưng phần VẼ tự elide — dùng cho nhãn trạng thái cầu
    nối khi nó phải nằm gọn trong hàng lọc cùng nút + ô tìm kiếm,
    không wrap xuống 2–3 dòng như banner cũ."""

    def paintEvent(self, event):
        # QStyle/QStyleOption ở QtWidgets (không phải QtGui) —
        # bản đầu V5.3 import nhầm module khiến paintEvent văng
        # ImportError mỗi lần sơn; đã sửa + có test hồi quy riêng.
        from PySide6.QtGui import QPainter
        from PySide6.QtWidgets import QStyleOption

        painter = QPainter(self)
        option = QStyleOption()
        option.initFrom(self)
        metrics = self.fontMetrics()
        elided = metrics.elidedText(
            self.text(), Qt.TextElideMode.ElideRight, max(10, self.width() - 4)
        )
        self.style().drawItemText(
            painter, self.rect(),
            int(self.alignment()) | int(Qt.TextFlag.TextSingleLine),
            option.palette, self.isEnabled(), elided, self.foregroundRole(),
        )
        painter.end()


class CommandsPanel(QWidget):
    # V4.5: một dòng trong Hàng đợi lệnh được bấm — WorkPanel nối
    # tín hiệu này để làm nổi bật đúng lệnh trên bảng việc bên phải.
    command_chosen = Signal(str)
    # V4.6: người dùng muốn HỎI Muse về một lệnh — MainWindow mở
    # chat với Muse phụ trách, gắn ngữ cảnh chính lệnh đó.
    ask_about_command = Signal(str)

    """Nhận: store (thread UI), manager (chưa dùng trực tiếp), notify —
    callback ghi vào nhật ký chung; run_now — callback của CommandRunner;
    cancel_command — callback huỷ lệnh (V3.1; không có thì huỷ ở tầng DB
    cho các lệnh chưa chạy)."""

    def __init__(self, store: Store, notify=None, run_now=None,
                 cancel_command=None, open_profile=None, bridge_help=None,
                 dispatch_now=None, settings=None, parent=None):
        super().__init__(parent)
        self._store = store
        # V4.3.2 (F7): settings dùng chung để lưu bề rộng cột bảng lệnh.
        self._settings = settings
        self._notify = notify or (lambda _line: None)
        self.bulk_profiles_handler = None  # V6.7: MainWindow gắn
        self._run_now = run_now or (lambda _cid: None)
        self._cancel = cancel_command
        self._open_profile = open_profile or (lambda _pid: None)
        self._bridge_help = bridge_help or (lambda: None)
        # V4.1.1: callback ép dispatcher xét ngay (MainWindow nối tới
        # AgentServer.request_dispatch_now) — dùng sau khi đổi Muse
        # nhận lệnh cho lệnh đang chờ. Không có thì bỏ qua, vô hại.
        self._dispatch_now = dispatch_now
        # V3.9: trạng thái lớp vận chuyển Tailscale do MainWindow bơm vào
        # (nó là nơi chạy vòng kiểm tra định kỳ). None = chưa kiểm tra →
        # banner giữ hành vi V3.8 (chỉ dựa vào bằng chứng cầu nối).
        self._ts_state: dict | None = None
        self._cache: list[dict] = []
        self._sort_column = 0
        self._sort_ascending = False  # mặc định: mới nhất trước
        # V4.2 (O-10): chữ ký dữ liệu đã vẽ — refresh bỏ qua dựng lại
        # combo/bảng khi dữ liệu không đổi (giữ lựa chọn + vị trí
        # cuộn của người dùng). None = chưa vẽ lần nào.
        self._profiles_signature = None
        self._agents_signature = None
        self._channels_signature = None
        self._table_signature = None
        self._table_light_sig = None  # V5.2: vân nhẹ cổng nạp bảng lệnh
        # V5.3.1 (M2): độ cao nút hàng lệnh hiệu lực từ settings
        # (mặc định 24 = ACTION_BUTTON_HEIGHT; người dùng chỉnh
        # trong Cài đặt → Giao diện, MainWindow gọi
        # apply_action_button_height sau khi Lưu).
        self._action_button_height = theme.row_action_height(settings)
        self._build_ui()
        self.refresh()
        # V4.2 (O-10): nhịp tự làm mới CHỈ chạy khi mục Lệnh đang
        # hiện (showEvent/hideEvent bật/tắt) — bản cũ chạy 4 giây/lần
        # suốt vòng đời cửa sổ dù đang ở tab khác.
        self._timer = QTimer(self)
        self._timer.setInterval(4000)
        self._timer.timeout.connect(self.refresh)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def _signal_dispatch_now(self):
        """Ép dispatcher xét lệnh NGAY qua callback MainWindow nối tới
        AgentServer.request_dispatch_now (V4.2 — O-27: mọi đường tạo/
        resume/retry đều đánh thức như nút Chạy ngay). Lỗi ở đây
        KHÔNG nuốt lặng (O-06): ghi vào nhật ký chung để anh thấy."""
        callback = self._dispatch_now
        if callback is None:
            return
        try:
            callback()
        except Exception as exc:
            self._notify(f"⚠ Không gọi được điều phối ngay: {exc}")

    # ------------------------------------------------------------------ #
    # V4.3 (G3) — Thư viện Skill cho form tạo lệnh
    # ------------------------------------------------------------------ #
    def _skills_base(self):
        """Thư mục dữ liệu của app (skills nằm ở <data>/skills)."""
        return self._store.db_file.parent

    def _build_skill_row(self) -> QVBoxLayout:
        # V4.5: hai dòng — dòng 1 nhãn + combo, dòng 2 bốn nút thao
        # tác skill. Xếp một hàng ngang như trước cần ~554px, ép cả
        # thẻ form tràn khỏi cột Giao việc ~430px (đã đo + soi ảnh).
        column = QVBoxLayout()
        column.setSpacing(6)
        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(theme.muted_label("✨ Skill"))
        self.skill_combo = QComboBox()
        self.skill_combo.setToolTip(
            "Skill = mẫu hướng dẫn lưu sẵn trong data/skills. Chọn một "
            "skill để điền mẫu vào ô Nội dung (biến {profile}, "
            "{channel}, {topic} được thay bằng giá trị của form)."
        )
        self.skill_combo.currentIndexChanged.connect(self._on_skill_selected)
        row.addWidget(self.skill_combo, 1)
        column.addLayout(row)
        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        self.skill_save_button = QPushButton("💾 Lưu skill")
        self.skill_save_button.setToolTip(
            "Lưu nội dung đang gõ trong ô Nội dung thành một skill mới"
        )
        self.skill_save_button.clicked.connect(self._on_skill_save)
        buttons.addWidget(self.skill_save_button)
        self.skill_edit_button = QPushButton("✏ Sửa")
        self.skill_edit_button.clicked.connect(self._on_skill_edit)
        buttons.addWidget(self.skill_edit_button)
        self.skill_delete_button = QPushButton("🗑 Xoá")
        self.skill_delete_button.clicked.connect(self._on_skill_delete)
        buttons.addWidget(self.skill_delete_button)
        self.skill_reload_button = QPushButton("🔄 Nạp lại")
        self.skill_reload_button.setToolTip(
            "Đọc lại thư viện skill; nếu đã từng nạp từ một thư mục thì nạp lại cả thư mục đó"
        )
        self.skill_reload_button.clicked.connect(self._on_skill_reload)
        buttons.addWidget(self.skill_reload_button)
        buttons.addStretch(1)
        column.addLayout(buttons)
        # V6.5: lấy skill từ THƯ MỤC (thư mục skill kiểu SKILL.md hoặc
        # các file .md) + mở thư mục thư viện skill.
        folder_row = QHBoxLayout()
        folder_row.setSpacing(8)
        self.skill_import_button = QPushButton("📂 Nạp skill từ thư mục…")
        self.skill_import_button.setToolTip(
            "Chọn một thư mục: mỗi thư mục con có SKILL.md thành một skill "
            "(gộp cả tài liệu .md kèm theo); file .md lẻ cũng thành skill."
        )
        self.skill_import_button.clicked.connect(self._on_skill_import)
        folder_row.addWidget(self.skill_import_button)
        self.skill_open_dir_button = QPushButton("📁 Mở thư mục skill")
        self.skill_open_dir_button.clicked.connect(self._on_skill_open_dir)
        folder_row.addWidget(self.skill_open_dir_button)
        folder_row.addStretch(1)
        column.addLayout(folder_row)
        self._refresh_skill_combo()
        return column

    def _on_skill_import(self, folder: str | None = None):
        from PySide6.QtWidgets import QFileDialog

        if not folder:
            start = str((self._settings or {}).get("skills_import_folder") or "")
            folder = QFileDialog.getExistingDirectory(self, "Chọn thư mục chứa skill", start)
        if not folder:
            return 0
        try:
            saved = skills_lib.import_folder(Path(folder), self._skills_base())
        except Exception as exc:  # noqa: BLE001
            self._notify(f"Không nạp được skill từ thư mục: {exc}")
            return 0
        if self._settings is not None:
            self._settings["skills_import_folder"] = str(folder)
            try:
                from .. import config as _config

                _config.save_settings(self._settings)
            except Exception:
                pass
        self._refresh_skill_combo(saved[0].slug if saved else None)
        names = ", ".join(s.name for s in saved[:6]) + ("…" if len(saved) > 6 else "")
        self._notify(f"📂 Đã nạp {len(saved)} skill từ {folder}" + (f": {names}" if saved else " (không thấy SKILL.md / .md nào)."))
        return len(saved)

    def _on_skill_reload(self):
        folder = (self._settings or {}).get("skills_import_folder")
        if folder and Path(folder).is_dir():
            self._on_skill_import(folder)
        else:
            self._refresh_skill_combo()

    def _on_skill_open_dir(self):
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices

        directory = skills_lib.skills_dir(self._skills_base())
        directory.mkdir(parents=True, exist_ok=True)
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(directory)))

    def _refresh_skill_combo(self, select_slug: str | None = None):
        if not hasattr(self, "skill_combo"):
            return
        current = select_slug or self.skill_combo.currentData()
        self.skill_combo.blockSignals(True)
        try:
            self.skill_combo.clear()
            self.skill_combo.addItem("— Không dùng skill —", None)
            try:
                skills = skills_lib.list_skills(self._skills_base())
            except Exception:
                skills = []
            for skill in skills:
                self.skill_combo.addItem(f"✨ {skill.name}", skill.slug)
            if current:
                index = self.skill_combo.findData(current)
                if index >= 0:
                    self.skill_combo.setCurrentIndex(index)
        finally:
            self.skill_combo.blockSignals(False)

    def _selected_skill(self):
        slug = self.skill_combo.currentData() if hasattr(self, "skill_combo") else None
        if not slug:
            return None
        try:
            return skills_lib.load_skill(slug, self._skills_base())
        except Exception:
            return None

    def _on_skill_selected(self, _index: int):
        skill = self._selected_skill()
        if skill is None:
            return
        profile_label = self.profile_combo.currentText() or ""
        # V4.5: {channel} = kênh ĐẦU TIÊN đang tick; chưa tick thì
        # lấy kênh đầu của hồ sơ đích (chỉ để điền mẫu, sửa được).
        checked = self._checked_channels()
        if checked:
            channel_name = checked[0]["name"]
        else:
            profile_id = self.profile_combo.currentData()
            channels = (
                self._store.list_channels(profile_id)
                if profile_id is not None
                else []
            )
            channel_name = channels[0]["name"] if channels else ""
        self.instruction_edit.setPlainText(
            skills_lib.render_body(
                skill.body,
                profile=profile_label,
                channel=channel_name,
                topic="",
            )
        )
        self._set_form_status(
            f"✨ Đã nạp skill “{skill.name}” vào ô Nội dung — sửa thêm "
            "nếu cần rồi bấm Tạo lệnh.",
            ok=True,
        )

    def _on_skill_save(self):
        body = self.instruction_edit.toPlainText().strip()
        if not body:
            self._set_form_status(
                "❌ Ô Nội dung đang trống — gõ mẫu hướng dẫn trước rồi "
                "mới Lưu skill được.",
                ok=False,
            )
            return
        name, accepted = QInputDialog.getText(
            self, "Lưu skill mới", "Tên skill (hiển thị trong danh sách):"
        )
        if not accepted or not name.strip():
            return
        try:
            skill = skills_lib.save_skill(name.strip(), body, self._skills_base())
        except Exception as exc:
            self._set_form_status(f"❌ Không lưu được skill: {exc}", ok=False)
            return
        self._refresh_skill_combo(select_slug=skill.slug)
        self._set_form_status(
            f"💾 Đã lưu skill “{skill.name}” vào data/skills/{skill.path.name}.",
            ok=True,
        )

    def _on_skill_edit(self):
        skill = self._selected_skill()
        if skill is None:
            self._set_form_status(
                "❌ Chọn một skill trong danh sách trước khi Sửa.", ok=False
            )
            return
        dialog = QDialog(self)
        dialog.setWindowTitle(f"Sửa skill — {skill.name}")
        layout = QVBoxLayout(dialog)
        layout.addWidget(theme.muted_label("Tên skill"))
        name_edit = QLineEdit(skill.name)
        layout.addWidget(name_edit)
        layout.addWidget(theme.muted_label("Nội dung mẫu (biến: {profile} {channel} {topic})"))
        body_edit = QPlainTextEdit(skill.body)
        body_edit.setMinimumSize(520, 260)
        layout.addWidget(body_edit)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        new_name = name_edit.text().strip()
        if not new_name:
            return
        try:
            saved = skills_lib.save_skill(
                new_name, body_edit.toPlainText(), self._skills_base()
            )
            if saved.slug != skill.slug:
                skills_lib.delete_skill(skill.slug, self._skills_base())
        except Exception as exc:
            self._set_form_status(f"❌ Không sửa được skill: {exc}", ok=False)
            return
        self._refresh_skill_combo(select_slug=saved.slug)
        self._set_form_status(f"✏ Đã cập nhật skill “{saved.name}”.", ok=True)

    def _on_skill_delete(self):
        skill = self._selected_skill()
        if skill is None:
            self._set_form_status(
                "❌ Chọn một skill trong danh sách trước khi Xoá.", ok=False
            )
            return
        answer = QMessageBox.question(
            self,
            "Xoá skill",
            f"Xoá hẳn skill “{skill.name}” khỏi data/skills?",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if skills_lib.delete_skill(skill.slug, self._skills_base()):
            self._refresh_skill_combo()
            self._set_form_status(f"🗑 Đã xoá skill “{skill.name}”.", ok=True)

    def select_command(self, command_id: str):
        """V4.3 (G1): chọn đúng một lệnh trong bảng từ bên ngoài
        (bảng việc ở mục Công việc / panel chi tiết Văn phòng bấm vào
        một việc) — làm mới dữ liệu trước để lệnh mới nhất cũng có mặt."""
        self.refresh()
        self._select_command_row(command_id)

    # ------------------------------------------------------------------ #
    # Dựng giao diện
    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    # Dựng giao diện (V4.5 — ba khối độc lập cho bố cục Công việc mới)
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        # Ba khối: form_card (tạo lệnh), queue_panel (hàng đợi gọn),
        # list_block (banner + bảng lệnh đầy đủ). Mục Công việc tách
        # chúng sang hai cột (Giao việc | Ai đang làm gì); panel đứng
        # một mình thì ba khối xếp dọc tại đây như cũ.
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        self.form_card = self._build_form_card()
        self.queue_panel = self._build_queue_panel()
        self.list_block = self._build_list_block()
        root.addWidget(self.form_card)
        root.addWidget(self.queue_panel)
        root.addWidget(self.list_block, 1)

    def _build_form_card(self) -> QFrame:
        """Form tạo lệnh MỘT CỘT DỌC (V4.5): Skill → Muse nhận lệnh
        → Loại lệnh → Hồ sơ đích → Kênh liên quan (checkbox, tick
        nhiều kênh = tạo một LÔ) → Nội dung → Tạo lệnh. Bỏ hẳn cơ
        chế chảy lưới 2×2 của V4.3.1 — cột Giao việc hẹp cố định
        (~420px) nên một cột dọc là đọc được nhất."""
        form = theme.card_frame()
        form_layout = QVBoxLayout(form)
        form_layout.setContentsMargins(16, 14, 16, 14)
        form_layout.setSpacing(10)
        form_layout.addWidget(theme.section_header("📝 Tạo lệnh"))

        # Hàng SKILL (V4.3 — G3): mẫu hướng dẫn dùng lại trong
        # data/skills; chọn skill → mẫu điền vào ô Nội dung.
        form_layout.addLayout(self._build_skill_row())

        agent_box = QVBoxLayout()
        agent_box.addWidget(theme.muted_label("Tài khoản Muse nhận lệnh"))
        self.agent_combo = QComboBox()
        self.agent_combo.setToolTip(
            "Để 'Tự động' nếu muốn Muse phụ trách hồ sơ đích nhận lệnh "
            "như trước. Chọn một tài khoản Muse cụ thể: lệnh sẽ giao "
            "cho đúng Muse đó và hồ sơ đích được phân công cho Muse "
            "đó phụ trách ngay khi tạo lệnh."
        )
        self.agent_combo.currentIndexChanged.connect(
            lambda _i: self._on_agent_changed()
        )
        agent_box.addWidget(self.agent_combo)
        form_layout.addLayout(agent_box)

        type_box = QVBoxLayout()
        type_box.addWidget(theme.muted_label("Loại lệnh"))
        self.type_combo = QComboBox()
        for key in UI_COMMAND_TYPES:
            self.type_combo.addItem(COMMAND_TYPE_LABELS[key], key)
        self.type_combo.currentIndexChanged.connect(
            lambda _i: self._update_form_state()
        )
        type_box.addWidget(self.type_combo)
        form_layout.addLayout(type_box)

        profile_box = QVBoxLayout()
        profile_box.addWidget(theme.muted_label("Hồ sơ đích"))
        self.profile_combo = QComboBox()
        self.profile_combo.currentIndexChanged.connect(self._on_profile_changed)
        profile_box.addWidget(self.profile_combo)
        form_layout.addLayout(profile_box)

        form_layout.addWidget(self._build_channel_block())

        # Dòng tóm tắt "sẽ tạo gì" cập nhật trực tiếp (V4.2 — O-26).
        self.form_summary = QLabel("")
        self.form_summary.setObjectName("Muted")
        self.form_summary.setWordWrap(True)
        form_layout.addWidget(self.form_summary)

        # Ô payload JSON cho lệnh 'Kịch bản Studio (nhúng)' (V4.4) —
        # CHỈ hiện khi chọn đúng loại đó.
        self.studio_payload_label = theme.muted_label(
            "Kịch bản Studio (JSON) — payload dạng {\"steps\": [...]}: goto / "
            "wait_for / click / fill / press / upload{file: tên file đã giao "
            "kèm lệnh} / read / screenshot / sleep / require_no_login_wall"
        )
        self.studio_payload_label.setWordWrap(True)
        self.studio_payload_edit = QPlainTextEdit()
        self.studio_payload_edit.setPlainText(
            json.dumps(
                {"steps": studio_script.EXAMPLE_STEPS},
                ensure_ascii=False,
                indent=2,
            )
        )
        self.studio_payload_edit.setMaximumHeight(150)
        form_layout.addWidget(self.studio_payload_label)
        form_layout.addWidget(self.studio_payload_edit)
        self.studio_payload_label.setVisible(False)
        self.studio_payload_edit.setVisible(False)

        form_layout.addWidget(theme.muted_label("Nội dung lệnh"))
        self.instruction_edit = QPlainTextEdit()
        self.instruction_edit.setPlaceholderText(
            "Nội dung yêu cầu — vd: Tối ưu tiêu đề + mô tả + tags cho EP08 theo đúng "
            "trình tự tiêu đề → mô tả → tags → thumbnail → lên lịch."
        )
        # V7.0.1: ô nội dung lệnh KÉO CAO tuỳ ý (tay kéo bên dưới), nhớ chiều cao.
        saved_ih = int(((self._settings or {}).get("work_instruction_h") or 72))
        self.instruction_edit.setFixedHeight(max(HeightGrip.MIN_H - 10, min(HeightGrip.MAX_H, saved_ih)))
        form_layout.addWidget(self.instruction_edit)
        self.instruction_grip = HeightGrip(self.instruction_edit, lambda h: self._save_height("work_instruction_h", h))
        self.instruction_grip.setToolTip("Kéo để đổi chiều cao ô nội dung lệnh · bấm đúp để thu gọn/mở rộng")
        form_layout.addWidget(self.instruction_grip)

        row2 = QHBoxLayout()
        row2.setSpacing(10)
        self.schedule_check = QCheckBox("Hẹn giờ chạy")
        row2.addWidget(self.schedule_check)
        self.schedule_edit = QDateTimeEdit()
        self.schedule_edit.setCalendarPopup(True)
        self.schedule_edit.setDisplayFormat("dd/MM/yyyy HH:mm")
        self.schedule_edit.setDateTime(
            (datetime.now() + timedelta(hours=1)).replace(second=0, microsecond=0)
        )
        self.schedule_edit.setEnabled(False)
        self.schedule_check.toggled.connect(self.schedule_edit.setEnabled)
        row2.addWidget(self.schedule_edit)
        row2.addStretch(1)
        self.create_button = QPushButton("＋ Tạo lệnh")
        self.create_button.setProperty("variant", "primary")
        self.create_button.clicked.connect(self._on_create)
        row2.addWidget(self.create_button)
        form_layout.addLayout(row2)

        # Kết quả tạo lệnh hiện NGAY TẠI FORM (V4.2 — G2).
        self.form_status = QLabel("")
        self.form_status.setWordWrap(True)
        self.form_status.setVisible(False)
        form_layout.addWidget(self.form_status)

        # V5.3 (A2/A6): bỏ dòng CHÚ THÍCH dưới nút (nội dung đã có
        # đủ trong tooltip) và bỏ hẳn đoạn chữ HƯỚNG DẪN DÀI "Cách
        # chạy…" cuối form theo lệnh chủ kênh — form chỉ còn nhãn
        # trường + điều khiển.
        self.create_channel_button = QPushButton("🆕 Tạo kênh đầu tiên")
        self.create_channel_button.setToolTip(
            "Tạo lệnh 'Tạo kênh mới' cho HỒ SƠ (mail) đang chọn ở form — "
            "không gắn với kênh nào cả, KHÔNG dùng Loại lệnh/Kênh; ô "
            "Nội dung chỉ làm ghi chú thêm. Muse phụ trách mail đó sẽ "
            "tạo kênh thương hiệu đầu tiên theo chuẩn tạo kênh đã lưu."
        )
        self.create_channel_button.clicked.connect(self._on_create_channel)
        form_layout.addWidget(self.create_channel_button)
        # V6.7: tạo hồ sơ hàng loạt từ "mail|pass" rồi giao luôn cho agent.
        self.bulk_profiles_button = QPushButton("👥 Tạo hồ sơ hàng loạt && giao Muse")
        self.bulk_profiles_button.setToolTip("Dán danh sách email|mật khẩu — app tự tạo hồ sơ, lưu mật khẩu, "
                                             "chia cho các Muse và (tuỳ chọn) giao việc + đăng nhập ngay.")
        self.bulk_profiles_button.clicked.connect(lambda: self.bulk_profiles_handler and self.bulk_profiles_handler())
        form_layout.addWidget(self.bulk_profiles_button)
        return form

    def _build_channel_block(self) -> QWidget:
        """Kênh liên quan dạng DANH SÁCH CHECKBOX (V4.5): kênh của
        các hồ sơ thuộc phạm vi Muse nhận lệnh (chọn Muse cụ thể →
        mọi hồ sơ Muse đó phụ trách; Tự động → hồ sơ đích đang
        chọn). Tick N kênh rồi Tạo lệnh = một LÔ N lệnh, mỗi lệnh
        đúng hồ sơ/kênh của nó, gắn chung batch_id trong payload."""
        block = QWidget()
        layout = QVBoxLayout(block)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        header = QHBoxLayout()
        header.setSpacing(8)
        header.addWidget(theme.muted_label("Kênh liên quan"))
        header.addStretch(1)
        self.channel_all_button = QPushButton("Chọn tất cả")
        self.channel_all_button.clicked.connect(
            lambda: self._set_all_channels(True)
        )
        header.addWidget(self.channel_all_button)
        self.channel_none_button = QPushButton("Bỏ chọn")
        self.channel_none_button.clicked.connect(
            lambda: self._set_all_channels(False)
        )
        header.addWidget(self.channel_none_button)
        layout.addLayout(header)
        self.channel_search = QLineEdit()
        self.channel_search.setPlaceholderText("🔍 Lọc kênh theo tên / hồ sơ…")
        self.channel_search.textChanged.connect(self._apply_channel_filter)
        layout.addWidget(self.channel_search)
        self.channel_scroll = QScrollArea()
        self.channel_scroll.setWidgetResizable(True)
        # V7.0: chiều cao danh sách kênh KÉO ĐƯỢC (tay kéo bên dưới), nhớ lại.
        saved_h = int(((self._settings or {}).get("work_channel_list_h") or 150))
        self.channel_scroll.setFixedHeight(max(70, min(1200, saved_h)))
        self.channel_host = QWidget()
        self.channel_layout = QVBoxLayout(self.channel_host)
        self.channel_layout.setContentsMargins(6, 6, 6, 6)
        self.channel_layout.setSpacing(2)
        self.channel_scroll.setWidget(self.channel_host)
        layout.addWidget(self.channel_scroll)
        self.channel_grip = HeightGrip(self.channel_scroll, self._save_channel_list_height)
        layout.addWidget(self.channel_grip)
        self.channel_empty_label = theme.muted_label(
            "Chưa có kênh nào trong phạm vi — quét kênh cho hồ sơ trước."
        )
        layout.addWidget(self.channel_empty_label)
        self._channel_checks: list = []
        return block

    def _save_height(self, key: str, height: int):
        if self._settings is None:
            return
        self._settings[key] = int(height)
        try:
            from .. import config as _config

            _config.save_settings(self._settings)
        except Exception:
            pass

    def _save_channel_list_height(self, height: int):
        if self._settings is None:
            return
        self._settings["work_channel_list_h"] = int(height)
        try:
            from .. import config as _config

            _config.save_settings(self._settings)
        except Exception:
            pass

    def _build_queue_panel(self) -> QWidget:
        """Hàng đợi lệnh RÚT GỌN (V4.5): dòng compact (chấm trạng
        thái + tiêu đề + % / tiến độ lô / huy hiệu tự-chạy-lại) nằm
        dưới form ở cột Giao việc; bảng đầy đủ ở cột phải."""
        panel = QWidget()
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        header = QHBoxLayout()
        header.addWidget(theme.section_header("Hàng đợi lệnh"))
        header.addStretch(1)
        self.queue_count_label = QLabel("")
        self.queue_count_label.setObjectName("Muted")
        header.addWidget(self.queue_count_label)
        layout.addLayout(header)
        self.queue_host = QWidget()
        self.queue_layout = QVBoxLayout(self.queue_host)
        self.queue_layout.setContentsMargins(0, 0, 0, 0)
        self.queue_layout.setSpacing(6)
        layout.addWidget(self.queue_host)
        self.queue_empty_label = theme.muted_label("Chưa có lệnh nào.")
        layout.addWidget(self.queue_empty_label)
        self._queue_signature = None
        return panel

    def _build_list_block(self) -> QWidget:
        block = QWidget()
        root = QVBoxLayout(block)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(12)

        # V5.3 (A2): hai BANNER thông báo lớn (lệnh CHỜ NGƯỜI + lệnh
        # CHƯA CÓ CHỦ) đã BỎ hẳn theo lệnh chủ kênh — thông tin đã
        # có trong Nhật ký, cột Trạng thái của bảng và bong bóng câu
        # hỏi ở Văn phòng; không còn nhãn banner nào dựng ở đây.
        # V5.3 (A3): nhãn trạng thái CẦU NỐI + nút "Kết nối Muse…"
        # chuyển lên CÙNG HÀNG với bộ lọc của danh sách lệnh; nút
        # trong hàng cao 24px; nhãn cầu nối là nhãn elide một dòng
        # (nội dung đầy đủ ở tooltip).
        list_header = QHBoxLayout()
        list_header.setSpacing(8)
        list_header.addWidget(theme.section_header("Danh sách lệnh"))
        self.bridge_label = _ElidedLabel("")
        self.bridge_label.setMinimumWidth(60)
        from PySide6.QtWidgets import QSizePolicy

        self.bridge_label.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        list_header.addWidget(self.bridge_label, 1)
        self.bridge_help_button = QPushButton("🔌 Kết nối Muse…")
        # V5.3: kiểu nút gọn 24px (theme RowAction) — padding dọc
        # mặc định sẽ cắt chữ trong khung cao 24px.
        self.bridge_help_button.setObjectName("RowAction")
        self.bridge_help_button.setFixedHeight(self._action_button_height)
        self.bridge_help_button.setToolTip(
            "Xem trạng thái cầu nối và 3 bước để Muse nghe được lệnh"
        )
        self.bridge_help_button.clicked.connect(lambda: self._bridge_help())
        list_header.addWidget(self.bridge_help_button)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("🔍 Lọc lệnh…")
        self.search_edit.setToolTip(
            "Lọc theo loại / hồ sơ / nội dung / trạng thái…"
        )
        self.search_edit.setMaximumWidth(300)
        self.search_edit.textChanged.connect(self._render_table)
        list_header.addWidget(self.search_edit)
        root.addLayout(list_header)
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            # V4.3.1: header IN HOA chữ phụ (mẫu Concept D/MetaMint).
            ["TẠO LÚC", "LOẠI", "HỒ SƠ", "TRẠNG THÁI", "YÊU CẦU", "TIẾN ĐỘ", "KẾT QUẢ", "NGUỒN", "THAO TÁC"]
        )
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.Stretch)
        header.setSectionsClickable(True)
        header.sectionClicked.connect(self._on_header_clicked)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng GỌN — chỉ đủ chữ + nút thao tác 24px,
        # đo từ font thật của bảng qua helper chung của theme
        # (DPI-safe như bài học V3.8, không hardcode số chết).
        self._row_height = theme.compact_row_height(
            self.table.font(), min_content=self._action_button_height
        )
        self.table.verticalHeader().setDefaultSectionSize(self._row_height)
        header.setSectionResizeMode(8, QHeaderView.ResizeMode.Fixed)
        self.table.setColumnWidth(8, 380)
        # V4.3.2 (F7): cột nội dung kéo chỉnh tự do + tự lưu bề rộng.
        from . import table_persist

        table_persist.attach_column_persistence(
            self.table, self._settings, "commands_table",
            fixed_columns=(8,),
            default_widths=(120, 110, 130, 120, 420, 130, 300, 90, 380),
        )
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._on_table_menu)
        root.addWidget(self.table, 1)

        # V5.3 (A4): hàng nút Chạy ngay / Xoá lệnh / Làm mới dưới
        # bảng đã XOÁ theo lệnh chủ kênh — cả ba thao tác đều có
        # trong menu chuột phải của bảng (Chạy ngay + Xoá lệnh theo
        # dòng; Làm mới ở cuối menu — xem _on_table_menu), chưa kể
        # bảng tự làm mới mỗi 4 giây.
        return block


    # ------------------------------------------------------------------ #
    # Dữ liệu
    # ------------------------------------------------------------------ #
    def refresh(self):
        self._refresh_profiles()
        self._refresh_agents()
        self._refresh_table()
        self._refresh_bridge_banner()

    def set_tailscale_state(self, state: dict | None):
        """MainWindow bơm trạng thái Tailscale mới nhất (V3.9) — banner
        phân lớp lại ngay: lớp vận chuyển hỏng thì nói lớp vận chuyển,
        không đổ hết thành "Muse chưa kết nối" như trước."""
        self._ts_state = state
        self._refresh_bridge_banner()

    def _refresh_bridge_banner(self):
        try:
            state = self._store.bridge_state()
        except Exception:
            return
        # V3.9: gộp hai lớp (Tailscale trên máy này + Muse gọi vào)
        # thành một thông điệp sự thật; chưa có trạng thái Tailscale
        # thì layer_state tự rơi về đúng hành vi V3.8.
        from .. import tailscale_helper

        level, message = tailscale_helper.layer_state(self._ts_state, state)
        colors = {"ok": "#43D675", "warn": "#F2C94C", "bad": "#FF7A7A"}
        self.bridge_label.setText(message)
        # V5.3 (A3): nhãn nằm trong hàng lọc nên chỉ VẼ một dòng
        # elide — nội dung đầy đủ luôn có ở tooltip.
        self.bridge_label.setToolTip(message)
        self.bridge_label.setStyleSheet(
            f"color:{colors.get(level, '#FF7A7A')}; font-weight:600;"
        )

    def _run_guarded(self, command_id: str):
        # V4.1.3: chạy là CHẠY — không còn hộp thoại chặn theo trạng
        # thái cầu nối (bản cũ bật modal "Chưa có Muse nào đang kết
        # nối" và bấm Huỷ bỏ là bỏ luôn thao tác). Lệnh đã bấm chạy là
        # lệnh đã cấp đầy đủ: Muse chưa kết nối thì lệnh nằm chờ ở
        # 'Chờ Muse' và được giao ngay khi Muse gọi lại (vòng
        # heartbeat tự kết nối lại) — trạng thái cầu nối chỉ còn hiện
        # ở banner để biết, không chặn thao tác. Tên hàm giữ nguyên
        # vì nhiều điểm gọi (nút dòng lệnh, menu chuột phải, nút chạy
        # lệnh đang chọn) đang trỏ vào đây.
        self._run_now(command_id)
        # V4.1.1: làm mới bảng NGAY sau khi bấm (không chờ nhịp 4 giây):
        # lệnh Muse vừa được ép dispatcher xét tức thì — trạng thái
        # mới hoặc lý do còn bị giữ (cột Tiến độ/banner) phải hiện gần
        # như ngay. Hai mốc: 700ms cho nhịp điều phối thuần dữ liệu,
        # 3s dự phòng khi preflight phải chạm trình duyệt lâu hơn.
        QTimer.singleShot(700, self._refresh_table)
        QTimer.singleShot(3000, self._refresh_table)

    def _refresh_profiles(self):
        profiles = self._store.list_profiles()
        signature = tuple(
            (p["id"], p["label"], p["gmail"]) for p in profiles
        )
        if signature == self._profiles_signature:
            # V4.2 (O-10): hồ sơ không đổi → không dựng lại combo,
            # nhưng kênh của hồ sơ đang chọn vẫn phải được rà lại.
            self._on_profile_changed()
            return
        self._profiles_signature = signature
        current = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        for profile in profiles:
            self.profile_combo.addItem(
                f"{profile['label']} — {profile['gmail']}", profile["id"]
            )
        if current is not None:
            index = self.profile_combo.findData(current)
            if index >= 0:
                self.profile_combo.setCurrentIndex(index)
        self.profile_combo.blockSignals(False)
        self._on_profile_changed()

    def _refresh_agents(self):
        """Ô "Tài khoản Muse nhận lệnh" (V4.1.1): mục đầu luôn là
        'Tự động' (data None), tiếp theo là mọi tài khoản Muse CHƯA
        bị thu hồi. Giữ nguyên lựa chọn đang có qua các lần làm mới
        nền — đổi hồ sơ đích KHÔNG tự đổi ô này (đơn giản, dễ đoán).
        V4.2 (O-10): bỏ qua dựng lại khi danh sách agent không đổi."""
        agents = [a for a in self._store.list_agents() if not a["revoked"]]
        signature = tuple(
            (a["id"], a["name"], a["email"]) for a in agents
        )
        if signature == self._agents_signature:
            return
        self._agents_signature = signature
        current = self.agent_combo.currentData()
        self.agent_combo.blockSignals(True)
        self.agent_combo.clear()
        self.agent_combo.addItem("Tự động (theo phân công của hồ sơ)", None)
        for agent in agents:
            self.agent_combo.addItem(
                f"{agent['name']} — {agent['email']}", agent["id"]
            )
        if current is not None:
            index = self.agent_combo.findData(current)
            if index >= 0:
                self.agent_combo.setCurrentIndex(index)
        self.agent_combo.blockSignals(False)
        self._refresh_channel_list()
        self._update_form_state()

    def _chosen_agent_id(self):
        """Agent id người dùng chọn tường minh ở form tạo lệnh;
        None = 'Tự động' (giữ hành vi cũ: store tự gắn Muse phụ
        trách hồ sơ khi tạo)."""
        return self.agent_combo.currentData()

    def _apply_agent_choice(self, command: dict, profile: dict) -> tuple[str, bool]:
        """Sau khi tạo lệnh của Muse với một Muse được CHỈ ĐỊNH ở
        form: đảm bảo phân công hồ sơ ↔ Muse đó tồn tại (dispatcher
        chỉ giao lệnh khi hồ sơ có chủ là Muse đó). Trả (đoạn text
        nối vào thông báo, thành công?) — V4.2 (G2): lỗi ở bước này
        phải hiện như LỖI MỘT PHẦN ở form, không chìm trong câu báo
        thành công. ('', True) khi đang để Tự động."""
        agent_id = self._chosen_agent_id()
        if agent_id is None:
            return "", True
        try:
            agent = self._store.get_agent(agent_id)
            agent_name = agent["name"] if agent else f"#{agent_id}"
            added = self._store.ensure_agent_assignment(agent_id, profile["id"])
        except Exception as exc:
            return f" ⚠ Chưa đảm bảo được phân công cho Muse đã chọn: {exc}", False
        text = f" Muse nhận lệnh: {agent_name}."
        if added:
            text += (
                f" Đã phân công hồ sơ {profile['label']} cho {agent_name} "
                "phụ trách."
            )
        return text, True

    def _on_agent_changed(self):
        """Đổi Muse nhận lệnh → PHẠM VI kênh liên quan đổi theo
        (kênh của các hồ sơ Muse đó phụ trách) + tóm tắt form."""
        self._refresh_channel_list()
        self._update_form_state()

    def _on_profile_changed(self):
        self._refresh_channel_list()
        self._update_form_state()

    # ------------------------------------------------------------------ #
    # V4.5 — Kênh liên quan dạng checkbox + tạo LÔ
    # ------------------------------------------------------------------ #
    @staticmethod
    def _fanout_applies(ctype) -> bool:
        """Loại lệnh có fan-out theo kênh không: lệnh của Muse +
        Kịch bản Studio. Lệnh app-side cấp hồ sơ (Mở trình duyệt /
        Quét / Kiểm tra) bỏ qua tick kênh — một lệnh cho hồ sơ đích."""
        return ctype in CLAUDE_COMMAND_TYPES or ctype == "studio_script"

    def _channel_source_profiles(self) -> list[dict]:
        """Hồ sơ làm nguồn kênh cho danh sách checkbox: Muse nhận
        lệnh được CHỈ ĐỊNH → mọi hồ sơ Muse đó phụ trách; 'Tự
        động' → hồ sơ đích đang chọn ở form."""
        agent_id = self._chosen_agent_id()
        profiles: list[dict] = []
        if agent_id is not None:
            for pid in self._store.profiles_for_agent(int(agent_id)):
                profile = self._store.get_profile(pid)
                if profile is not None:
                    profiles.append(profile)
        if not profiles:
            profile_id = self.profile_combo.currentData()
            if profile_id is not None:
                profile = self._store.get_profile(profile_id)
                if profile is not None:
                    profiles.append(profile)
        return profiles

    def _refresh_channel_list(self):
        """Dựng lại danh sách kênh checkbox theo phạm vi hiện tại —
        chỉ khi danh sách kênh THẬT SỰ đổi (chữ ký O-10); các tick
        đang chọn được giữ theo (profile_id, channel_id)."""
        if not hasattr(self, "channel_layout"):
            return
        profiles = self._channel_source_profiles()
        rows = []
        for profile in profiles:
            for channel in self._store.list_channels(profile["id"]):
                rows.append((profile, channel))
        signature = (
            tuple(p["id"] for p in profiles),
            tuple(
                (p["id"], c["channel_id"], c["name"], c.get("handle") or "")
                for p, c in rows
            ),
        )
        if signature == self._channels_signature:
            return
        self._channels_signature = signature
        checked_before = {
            (pid, cid)
            for box, pid, cid, _name in self._channel_checks
            if box.isChecked()
        }
        # Dọn sạch đúng kỷ luật V4.3.2 (ẩn + gỡ parent + deleteLater).
        while self.channel_layout.count():
            item = self.channel_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self._channel_checks = []
        multi = len(profiles) > 1
        for profile, channel in rows:
            label = f"{channel['name']} {(channel.get('handle') or '').strip()}".strip()
            if multi:
                label += f" · {profile['label']}"
            box = QCheckBox(label)
            box.setToolTip(
                f"Kênh {channel['channel_id']} — hồ sơ {profile['label']} "
                f"({profile['gmail']})"
            )
            if (profile["id"], channel["channel_id"]) in checked_before:
                box.setChecked(True)
            box.stateChanged.connect(lambda _s: self._update_form_state())
            self.channel_layout.addWidget(box)
            self._channel_checks.append(
                (box, profile["id"], channel["channel_id"], channel["name"])
            )
        self.channel_layout.addStretch(1)
        self.channel_empty_label.setVisible(not rows)
        self.channel_scroll.setVisible(bool(rows))
        self._apply_channel_filter()

    def _set_all_channels(self, checked: bool):
        for box, _pid, _cid, _name in self._channel_checks:
            box.setChecked(checked)
        self._update_form_state()

    def _apply_channel_filter(self):
        query = (self.channel_search.text() or "").strip().casefold()
        for box, _pid, _cid, _name in self._channel_checks:
            box.setVisible(not query or query in box.text().casefold())

    def _checked_channels(self) -> list[dict]:
        """Kênh đang tick: [{profile_id, channel_id, name}] theo thứ
        tự hiển thị trong danh sách."""
        return [
            {"profile_id": pid, "channel_id": cid, "name": name}
            for box, pid, cid, name in self._channel_checks
            if box.isChecked()
        ]

    def _update_form_state(self):
        """Bật/tắt ô theo loại lệnh + dòng tóm tắt trực tiếp (O-26).
        Ô Muse nhận lệnh chỉ bật cho lệnh của Muse; danh sách
        kênh luôn tick được — loại lệnh bắt buộc kênh mà chưa tick
        kênh nào thì tóm tắt BÁO THIẾU ngay tại form."""
        ctype = self.type_combo.currentData()
        schema = command_schema.COMMAND_SCHEMAS.get(ctype or "", {})
        self.agent_combo.setEnabled(ctype in CLAUDE_COMMAND_TYPES)
        # V4.4: ô payload JSON chỉ thuộc về lệnh Kịch bản Studio.
        is_studio = ctype == "studio_script"
        self.studio_payload_label.setVisible(is_studio)
        self.studio_payload_edit.setVisible(is_studio)
        profile_text = self.profile_combo.currentText() or "—"
        agent_id = self.agent_combo.currentData()
        agent_text = (
            "Tự động (Muse phụ trách hồ sơ)"
            if agent_id is None
            else self.agent_combo.currentText()
        )
        type_text = COMMAND_TYPE_LABELS.get(ctype, ctype or "—")
        checked = self._checked_channels()
        parts = [f"Sẽ tạo: {type_text}", f"Hồ sơ {profile_text}", f"Muse {agent_text}"]
        if self._fanout_applies(ctype) and len(checked) > 1:
            parts.append(f"LÔ {len(checked)} kênh — mỗi kênh 1 lệnh riêng")
        elif self._fanout_applies(ctype) and checked:
            parts.append(f"Kênh {checked[0]['name']}")
        elif schema.get("require_channel"):
            parts.append("Kênh: ⚠ chưa tick kênh nào (loại này bắt buộc)")
        self.form_summary.setText(" · ".join(parts))

    def _set_form_status(self, message: str, ok: bool = True):
        """V4.2 (G2): kết quả thao tác tạo lệnh hiện tại form — màu
        xanh khi thành công, đỏ khi lỗi; không phụ thuộc việc người
        dùng có đang ngó tab Nhật ký hay không."""
        self.form_status.setText(message)
        self.form_status.setStyleSheet(
            "color:#43D675; font-weight:600;" if ok
            else "color:#FF7A7A; font-weight:600;"
        )
        self.form_status.setVisible(bool(message))

    def _refresh_table(self):
        # V5.2 (hiệu năng §15): cổng NHẸ trước khâu nạp — vân (id/
        # status/progress/updated_at) của 100 lệnh đầu không đổi
        # thì BỎ QUA toàn bộ. Trước đây cổng chữ ký chỉ nằm ở khâu
        # VẼ (_render_table) nên mỗi nhịp 4 giây panel vẫn SELECT *
        # + parse JSON payload của 100 lệnh (~0,3s trên fixture cỡ
        # máy thật) dù không có gì thay đổi. Hàng đợi + cảnh báo
        # suy từ đúng tập lệnh này nên bỏ qua cùng nhau là an toàn.
        try:
            light_sig = tuple(
                (c["id"], c["status"], c["progress"], c["updated_at"])
                for c in self._store.list_commands_light(limit=100)
            )
        except Exception:
            light_sig = None
        if light_sig is not None and light_sig == self._table_light_sig:
            return
        self._table_light_sig = light_sig
        self._cache = self._store.list_commands(limit=100)
        self._batch_stats = self._compute_batch_stats(self._cache)
        self._render_table()
        self._refresh_queue()
        # V5.3 (A2): _refresh_alerts đã XOÁ cùng hai banner của nó.

    @staticmethod
    def _compute_batch_stats(commands: list[dict]) -> dict:
        """Thống kê theo lô từ danh sách lệnh đang có: batch_id →
        (số xong, tổng khai báo trong payload, [thành viên]). Tổng
        lấy theo batch_total các thành viên khai (cache cắt 100
        dòng có thể thiếu thành viên — con số 'xong' đếm trên phần
        nhìn thấy được)."""
        stats: dict[str, dict] = {}
        for command in commands:
            payload = command.get("payload") or {}
            batch_id = payload.get("batch_id")
            total = int(payload.get("batch_total") or 0)
            if not batch_id or total <= 1:
                continue
            entry = stats.setdefault(
                batch_id, {"done": 0, "total": total, "members": []}
            )
            entry["total"] = max(entry["total"], total)
            entry["members"].append(command)
            if command.get("status") == "done":
                entry["done"] += 1
        return stats

    # ------------------------------------------------------------------ #
    # V4.5 — Hàng đợi lệnh rút gọn (cột Giao việc)
    # ------------------------------------------------------------------ #
    def _refresh_queue(self):
        """Dựng lại các dòng compact từ cache lệnh: lệnh thuộc một
        LÔ (payload batch_id, batch_total > 1) GỘP thành một dòng
        (x/N xong + % trung bình); lệnh lẻ một dòng. Chỉ dựng lại
        khi chữ ký dữ liệu đổi."""
        if not hasattr(self, "queue_layout"):
            return
        commands = self._cache
        signature = tuple(
            (
                c.get("id"), c.get("status"), c.get("progress"),
                (c.get("payload") or {}).get("batch_id"),
                (c.get("payload") or {}).get("auto_retry_count"),
                (c.get("payload") or {}).get("auto_retry_at"),
            )
            for c in commands
        )
        if signature == self._queue_signature:
            return
        self._queue_signature = signature
        while self.queue_layout.count():
            item = self.queue_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        entries: list[tuple[str | None, list[dict]]] = []
        batch_slots: dict[str, list[dict]] = {}
        for command in commands:
            payload = command.get("payload") or {}
            batch_id = payload.get("batch_id")
            total = int(payload.get("batch_total") or 0)
            if batch_id and total > 1:
                if batch_id in batch_slots:
                    batch_slots[batch_id].append(command)
                else:
                    members: list[dict] = [command]
                    batch_slots[batch_id] = members
                    entries.append((batch_id, members))
            else:
                entries.append((None, [command]))
        for batch_id, members in entries[:14]:
            row = self._make_queue_row(batch_id, members)
            row.clicked.connect(self._on_queue_row_clicked)
            row.ask_requested.connect(self.ask_about_command.emit)
            self.queue_layout.addWidget(row)
        self.queue_empty_label.setVisible(not entries)
        active = sum(
            1 for c in commands
            if c.get("status") in ("queued", "running", "waiting_muse", "needs_user")
        )
        self.queue_count_label.setText(
            f"{active} đang chờ/chạy · {len(commands)} lệnh gần nhất"
        )

    def _make_queue_row(self, batch_id, members) -> _QueueRow:
        first = members[0]
        type_label = COMMAND_TYPE_LABELS.get(first["type"], first["type"])
        if batch_id:
            stats = self._batch_stats.get(batch_id, {})
            total = int(stats.get("total") or len(members))
            done = int(stats.get("done") or 0)
            percent = round(
                sum(
                    100 if m.get("status") == "done" else int(m.get("progress") or 0)
                    for m in members
                ) / max(1, len(members))
            )
            slugs = " · ".join(
                sorted({m.get("profile_slug") or "" for m in members})
            )
            representative = next(
                (m for m in members if m.get("status") != "done"), first
            )
            status = representative.get("status") or "queued"
            return _QueueRow(
                representative["id"],
                f"🧩 {type_label} ×{total} kênh",
                f"Lô #{batch_id} — {slugs}",
                f"{done}/{total} xong · {percent}%",
                status,
            )
        payload = first.get("payload") or {}
        percent = 100 if first.get("status") == "done" else int(first.get("progress") or 0)
        right = f"{percent}%"
        if first.get("status") == "failed":
            countdown = auto_retry.pending_countdown(
                first, datetime.now().astimezone()
            )
            if countdown is not None:
                right += f" · ↻ {countdown}s"
            elif payload.get(auto_retry.KEY_COUNT):
                right += (
                    f" · ↻ {int(payload[auto_retry.KEY_COUNT])}"
                    f"/{auto_retry.MAX_AUTO_RETRIES}"
                )
        sub = (first.get("step") or "").strip() or STATUS_LABELS.get(
            first.get("status"), first.get("status") or ""
        )
        return _QueueRow(
            first["id"],
            f"{type_label} · {first.get('profile_slug') or '—'}",
            sub,
            right,
            first.get("status") or "queued",
        )

    def _on_queue_row_clicked(self, command_id: str):
        """Bấm một dòng hàng đợi: chọn đúng lệnh ở bảng bên phải +
        báo WorkPanel làm nổi bật lệnh trên bảng việc."""
        self.select_command(command_id)
        self.command_chosen.emit(command_id)

    # V5.3 (A2): _refresh_alerts + hai banner (needs_user /
    # unassigned) đã XOÁ — lệnh chờ người vẫn thấy ở cột Trạng thái
    # của bảng, bong bóng câu hỏi ở Văn phòng và tin hệ thống trong
    # chat; lệnh chưa có chủ thấy ở cột Trạng thái/Tiến độ. Sự kiện
    # vẫn ghi Nhật ký như cũ.

    _SORT_KEYS = {
        0: lambda c: c["created_at"] or "",
        1: lambda c: COMMAND_TYPE_LABELS.get(c["type"], c["type"]),
        2: lambda c: c["profile_slug"] or "",
        3: lambda c: STATUS_LABELS.get(c["status"], c["status"]),
        4: lambda c: c["instruction"] or "",
        5: lambda c: c.get("progress") or 0,
        6: lambda c: c["result"] or c["error"] or "",
        7: lambda c: c["source"] or "",
    }

    def _on_header_clicked(self, column: int):
        if column == 8:
            return
        if column == self._sort_column:
            self._sort_ascending = not self._sort_ascending
        else:
            self._sort_column = column
            self._sort_ascending = True
        self._render_table()

    def _visible_commands(self) -> list[dict]:
        query = self.search_edit.text().strip().lower() if hasattr(self, "search_edit") else ""
        commands = list(self._cache)
        if query:
            def _matches(c: dict) -> bool:
                haystack = " ".join(
                    str(x or "")
                    for x in (
                        COMMAND_TYPE_LABELS.get(c["type"], c["type"]),
                        c["profile_slug"],
                        STATUS_LABELS.get(c["status"], c["status"]),
                        c["instruction"],
                        c["result"],
                        c["error"],
                    )
                ).lower()
                return query in haystack

            commands = [c for c in commands if _matches(c)]
        key = self._SORT_KEYS.get(self._sort_column)
        if key is not None:
            commands.sort(key=key, reverse=not self._sort_ascending)
        return commands

    def _table_data_signature(self, commands: list[dict]) -> tuple:
        """Chữ ký những gì bảng THẬT SỰ vẽ (O-10): gồm cả ô tìm kiếm
        + thứ tự sắp xếp (đổi lọc/sắp xếp là phải vẽ lại) và một
        "xô thời gian" 15 giây CHỈ khi đang có lệnh running giữ
        lease — ô tiến độ của lệnh đó hiện đếm ngược lease nên cần
        vẽ lại theo nhịp, các trường hợp khác đứng yên."""
        rows = tuple(
            (
                c.get("id"), c.get("status"), c.get("progress"),
                c.get("step"), c.get("updated_at"), c.get("result"),
                c.get("error"), c.get("agent_id"),
                c.get("lease_agent_id"), c.get("lease_expires_at"),
                c.get("created_at"), c.get("instruction"),
                c.get("profile_slug"), c.get("source"), c.get("type"),
                (c.get("payload") or {}).get("batch_id"),
                (c.get("payload") or {}).get("auto_retry_count"),
                (c.get("payload") or {}).get("auto_retry_at"),
                (c.get("payload") or {}).get("auto_retry_cancelled"),
                (c.get("payload") or {}).get("auto_retry_blocked"),
            )
            for c in commands
        )
        bucket = 0
        if any(
            c.get("status") == "running" and c.get("lease_agent_id")
            for c in commands
        ):
            bucket = int(datetime.now().timestamp()) // 15
        elif any(
            auto_retry.pending_countdown(c, datetime.now().astimezone())
            is not None
            for c in commands
        ):
            # V4.5: đang có lệnh failed chờ TỰ CHẠY LẠI — ô tiến độ
            # hiện đếm ngược nên bảng phải vẽ lại theo xô 5 giây.
            bucket = int(datetime.now().timestamp()) // 5
        return (
            rows,
            self.search_edit.text() if hasattr(self, "search_edit") else "",
            self._sort_column,
            self._sort_ascending,
            bucket,
        )

    def _render_table(self):
        commands = self._visible_commands()
        signature = self._table_data_signature(commands)
        if signature == self._table_signature:
            return  # O-10: dữ liệu vẽ không đổi → giữ nguyên bảng
            # (lựa chọn dòng + vị trí cuộn không bị phá mỗi 4 giây).
        self._table_signature = signature
        # V4.3.2 (F4): nạp hàng loạt tắt repaint/signals của bảng —
        # mỗi dòng có widget thao tác, sơn từng ô là nguồn đơ chính.
        from . import table_persist

        with table_persist.batch_update(self.table):
            self._fill_table(commands)

    def _fill_table(self, commands):
        self.table.setRowCount(len(commands))
        for row, command in enumerate(commands):
            created = _fmt_ts(command["created_at"])
            self.table.setItem(row, 0, _cell(created))
            type_item = _cell(COMMAND_TYPE_LABELS.get(command["type"], command["type"]))
            type_fg, type_bg = TYPE_ITEM_COLORS.get(
                command["type"], ("#9BA196", (155, 161, 150, 36))
            )
            type_item.setForeground(QColor(type_fg))
            type_item.setBackground(QColor(*type_bg))
            type_font = type_item.font()
            type_font.setBold(True)
            type_item.setFont(type_font)
            self.table.setItem(row, 1, type_item)
            self.table.setItem(row, 2, _cell(command["profile_slug"] or "—"))
            status_item = _cell(
                STATUS_GLYPHS.get(command["status"], "")
                + STATUS_LABELS.get(command["status"], command["status"])
            )
            fg, bg = STATUS_ITEM_COLORS.get(
                command["status"], STATUS_ITEM_COLORS["queued"]
            )
            status_item.setForeground(QColor(fg))
            status_item.setBackground(QColor(*bg))
            status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            status_font = status_item.font()
            status_font.setBold(True)
            status_item.setFont(status_font)
            self.table.setItem(row, 3, status_item)
            instruction_text = command["instruction"] or "—"
            cmd_payload = command.get("payload") or {}
            instruction_item = _cell(instruction_text)
            if (
                cmd_payload.get("batch_id")
                and int(cmd_payload.get("batch_total") or 0) > 1
            ):
                # V4.5: lệnh thuộc một LÔ fan-out theo kênh.
                stats = self._batch_stats.get(cmd_payload["batch_id"], {})
                instruction_item.setText("🧩 " + instruction_text)
                instruction_item.setToolTip(
                    f"Lô #{cmd_payload['batch_id']}: "
                    f"{stats.get('done', 0)}/{stats.get('total', '?')} lệnh đã xong "
                    "(mỗi kênh một lệnh riêng, chung mã lô)."
                )
            self.table.setItem(row, 4, instruction_item)
            self.table.setItem(row, 5, self._progress_cell(command))
            # V5.3 (A5): cột Kết quả hiện TÓM TẮT NGẮN (vd
            # "studio_script · 8/8 bước · xong") thay cho repr dict
            # thô; bản đầy đủ nằm ở tooltip của ô.
            result_item = _cell(summarize_result(command))
            full_result = (
                command.get("result") or command.get("error") or ""
            ).strip()
            if full_result:
                result_item.setToolTip(full_result)
            result = command["result"]
            # V4.3.1: kết quả dạng pill (item thuần nhuộm nền): lỗi →
            # nền đỏ mờ, có kết quả & lệnh đã xong → nền xanh mờ.
            if command.get("error"):
                result_item.setForeground(QColor(theme.DANGER))
                result_item.setBackground(QColor(214, 92, 92, 28))
            elif result and command["status"] == "done":
                result_item.setForeground(QColor(theme.SUCCESS))
                result_item.setBackground(QColor(67, 214, 117, 28))
            self.table.setItem(row, 6, result_item)
            self.table.setItem(row, 7, _cell({"ui": "Trong app", "api": "Muse", "auto": "Tự động"}.get(command["source"], command["source"])))
            self.table.item(row, 0).setData(Qt.ItemDataRole.UserRole, command["id"])
            self.table.setCellWidget(row, 8, self._action_widget(command))
            # Ép chiều cao từng dòng theo số đo nút (phòng khi Qt tự co
            # dòng khi bảng làm mới) — nút trong dòng không bị che.
            self.table.setRowHeight(row, self._row_height)

    @staticmethod
    def _progress_cell(command: dict) -> QTableWidgetItem:
        """Ô tiến độ dạng CHỮ (thanh khối unicode + % + bước hiện tại) —
        cố ý không dùng QProgressBar cell-widget vì bảng này tự làm mới
        mỗi 4 giây (xem ghi chú ở STATUS_ITEM_COLORS)."""
        status = command["status"]
        percent = 100 if status == "done" else int(command.get("progress") or 0)
        filled = max(0, min(10, round(percent / 10)))
        text = f"{'█' * filled}{'░' * (10 - filled)} {percent}%"
        step = (command.get("step") or "").strip()
        if step and status in ("queued", "running", "waiting_muse"):
            text += f" · {step}"
        # V4.0 (H7): lease của lệnh đang chạy — CHỮ THUẦN trong cùng ô
        # (không cell-widget, đúng bài học orphan): Muse giữ + còn
        # bao lâu trước khi sweeper thu hồi nếu mất dấu.
        if status == "running" and command.get("lease_agent_id"):
            text += f" · 🤖#{command['lease_agent_id']} giữ"
            expires = command.get("lease_expires_at")
            if expires:
                try:
                    remain = (
                        datetime.fromisoformat(str(expires)) - datetime.now().astimezone()
                    ).total_seconds()
                    if remain > 0:
                        text += f" · lease còn {int(remain // 60)}:{int(remain % 60):02d}"
                    else:
                        text += " · lease đã hết hạn (sắp thu hồi)"
                except ValueError:
                    pass
        # V4.5: lệnh failed — hiện lịch TỰ CHẠY LẠI (đếm ngược +
        # lần n/3) hoặc lý do KHÔNG tự chạy lại, ngay trong ô tiến độ.
        if status == "failed":
            payload = command.get("payload") or {}
            countdown = auto_retry.pending_countdown(
                command, datetime.now().astimezone()
            )
            count = int(payload.get(auto_retry.KEY_COUNT) or 0)
            if countdown is not None:
                text += (
                    f" · ↻ tự chạy lại sau {countdown}s"
                    f" (lần {count}/{auto_retry.MAX_AUTO_RETRIES})"
                )
            elif payload.get(auto_retry.KEY_CANCELLED):
                text += " · đã huỷ tự chạy lại"
            elif payload.get(auto_retry.KEY_BLOCKED):
                reasons = {
                    "needs_user": "không tự chạy lại (đã chờ người xử lý)",
                    "dependency": "không tự chạy lại (phụ thuộc lỗi)",
                    "invalid": "không tự chạy lại (lỗi cấu hình)",
                    "cancelled": "đã huỷ",
                    "max_retries": (
                        f"đã hết {auto_retry.MAX_AUTO_RETRIES} lần tự chạy lại"
                    ),
                }
                note = reasons.get(str(payload[auto_retry.KEY_BLOCKED]))
                if note:
                    text += f" · {note}"
            elif count:
                text += f" · ↻ {count}/{auto_retry.MAX_AUTO_RETRIES}"
        item = _cell(text)
        if step:
            item.setToolTip(step)
        if status == "running":
            item.setForeground(QColor(theme.ACCENT))
        elif status == "done":
            item.setForeground(QColor(theme.SUCCESS))
        elif status == "failed":
            item.setForeground(QColor(theme.DANGER))
        return item

    def apply_action_button_height(self):
        """Áp độ cao nút hàng lệnh MỚI từ settings (V5.3.1 — M2;
        MainWindow gọi sau khi người dùng Lưu cài đặt): tính lại
        chiều cao dòng từ đúng số mới, nút cầu nối theo ngay, và
        xoá vân bảng để hàng hiện có dựng lại với nút đúng chiều
        cao (đổi hiển thị không chờ dữ liệu đổi)."""
        new_height = theme.row_action_height(self._settings)
        if new_height == self._action_button_height:
            return
        self._action_button_height = new_height
        self._row_height = theme.compact_row_height(
            self.table.font(), min_content=new_height
        )
        self.table.verticalHeader().setDefaultSectionSize(self._row_height)
        self.bridge_help_button.setFixedHeight(new_height)
        self._table_signature = None
        self._table_light_sig = None
        self.refresh()

    def _action_widget(self, command: dict) -> QWidget:
        """Nút thao tác theo từng dòng — luôn đủ ICON + TEXT (yêu cầu V3.7):
        ▶ Chạy ngay cho lệnh đang chờ (app chạy ngay, hoặc mở trang Hồ sơ
        của mail để Muse phụ trách thực hiện), 🎯 Đổi Muse cho lệnh
        của Muse đang chờ (V4.1.1), ✕ Huỷ, ↻ Thử lại."""
        host = QWidget()
        layout = QHBoxLayout(host)
        layout.setContentsMargins(4, 2, 4, 2)
        layout.setSpacing(6)
        status = command["status"]
        cid = command["id"]
        if status in ("queued", "waiting_muse"):
            run = QPushButton("▶ Chạy ngay")
            run.setFixedHeight(self._action_button_height)
            run.clicked.connect(lambda _=False, c=cid: self._run_guarded(c))
            layout.addWidget(run)
        if (
            status in ("queued", "waiting_muse")
            and command["type"] in CLAUDE_COMMAND_TYPES
        ):
            # V4.1.1: đổi Muse nhận lệnh NGAY tại dòng lệnh — chỉ khi
            # lệnh còn đang chờ (chưa ai giữ lease). Đang chạy/chờ
            # người/đã xong thì quyền sở hữu đã chốt, không đổi ở đây.
            reassign = QPushButton("🎯 Đổi Muse…")
            reassign.setFixedHeight(self._action_button_height)
            reassign.setToolTip(
                "Chỉ định tài khoản Muse khác nhận lệnh này (kèm phân "
                "công hồ sơ đích cho Muse đó nếu chưa có)"
            )
            reassign.clicked.connect(
                lambda _=False, c=cid: self._on_reassign_agent(c)
            )
            layout.addWidget(reassign)
        if status == "needs_user":
            # V4.0 (H3): người dùng xử lý xong (đăng nhập/2FA...) thì
            # bấm chạy tiếp — lệnh về 'queued' cho dispatcher xét lại.
            resume = QPushButton("▶ Đã xử lý — chạy tiếp")
            resume.setFixedHeight(self._action_button_height)
            resume.clicked.connect(lambda _=False, c=cid: self._on_resume(c))
            layout.addWidget(resume)
        if status in ("queued", "running", "waiting_muse", "needs_user"):
            cancel = QPushButton("✕ Huỷ lệnh")
            cancel.setFixedHeight(self._action_button_height)
            cancel.clicked.connect(lambda _=False, c=cid: self._on_cancel(c))
            layout.addWidget(cancel)
        if status in ("failed", "interrupted"):
            retry = QPushButton("↻ Thử lại")
            retry.setFixedHeight(self._action_button_height)
            retry.clicked.connect(lambda _=False, c=cid: self._on_retry(c))
            layout.addWidget(retry)
        if status == "failed" and auto_retry.pending_countdown(
            command, datetime.now().astimezone()
        ) is not None:
            # V4.5: đang có lịch TỰ CHẠY LẠI — cho huỷ hẹn ngay tại
            # dòng (lệnh giữ nguyên Thất bại, Thử lại tay vẫn được).
            cancel_retry = QPushButton("⏸ Huỷ chạy lại")
            cancel_retry.setFixedHeight(self._action_button_height)
            cancel_retry.setToolTip(
                "Bỏ lịch tự chạy lại sau 30 giây — lệnh giữ nguyên "
                "trạng thái Thất bại."
            )
            cancel_retry.clicked.connect(
                lambda _=False, c=cid: self._on_cancel_auto_retry(c)
            )
            layout.addWidget(cancel_retry)
        # V5.3: mọi nút trong dòng mang kiểu GỌN (theme RowAction)
        # để chữ không bị cắt trong khung cao 24px.
        for index in range(layout.count()):
            widget = layout.itemAt(index).widget()
            if isinstance(widget, QPushButton):
                widget.setObjectName("RowAction")
        layout.addStretch(1)
        return host

    def _on_reassign_agent(self, command_id: str):
        """V4.1.1: '🎯 Đổi Muse nhận lệnh…' — hộp chọn Muse cho một
        lệnh của Muse đang chờ (queued/waiting_muse). Phần hiệu lực
        thật nằm ở _apply_reassign_agent để kiểm thử không cần hộp
        thoại."""
        command = self._store.get_command(command_id)
        if (
            command is None
            or command["type"] not in CLAUDE_COMMAND_TYPES
            or command["status"] not in ("queued", "waiting_muse")
        ):
            self._notify(
                "Chỉ đổi được Muse nhận cho lệnh của Muse đang chờ "
                "(chưa chạy, chưa chờ người xử lý)."
            )
            return
        agents = [a for a in self._store.list_agents() if not a["revoked"]]
        if not agents:
            self._notify(
                "Chưa có tài khoản Muse nào — thêm ở tab Tài khoản Muse trước."
            )
            return
        dialog = AgentPickerDialog(
            agents, current_agent_id=command.get("agent_id"), parent=self
        )
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        agent_id = dialog.selected_agent_id()
        if agent_id is None:
            return
        self._apply_reassign_agent(command_id, agent_id)

    def _apply_reassign_agent(self, command_id: str, agent_id: int):
        """Hiệu lực của đổi Muse nhận lệnh: ghi danh lệnh cho Muse
        mới + đảm bảo phân công hồ sơ đích ↔ Muse đó (dispatcher chỉ
        giao khi hồ sơ có chủ đúng người) + ép dispatcher xét ngay.
        Lệnh 'waiting_muse' cũng được ép xét lại — vô hại: dispatcher
        không tự claim, Muse mới thấy lệnh trong phạm vi của mình
        ngay ở lần gọi/long-poll kế."""
        command = self._store.get_command(command_id)
        if command is None:
            return
        agent = self._store.get_agent(agent_id)
        agent_name = agent["name"] if agent else f"#{agent_id}"
        self._store.set_command_agent(command_id, agent_id)
        added = False
        if command.get("profile_id"):
            added = self._store.ensure_agent_assignment(
                agent_id, command["profile_id"]
            )
        # V4.2 (O-06): ép điều phối lỗi thì BÁO RA (qua helper đã
        # ghi log) — không nuốt lặng như bản cũ.
        self._signal_dispatch_now()
        message = (
            f"Đã đổi Muse nhận lệnh #{command_id} → {agent_name}."
        )
        if added:
            message += (
                f" Đã phân công hồ sơ đích cho {agent_name} phụ trách."
            )
        self._notify(message)
        self._refresh_table()
        QTimer.singleShot(700, self._refresh_table)

    def _on_resume(self, command_id: str):
        """V4.0 (H3): 'Đã xử lý — chạy tiếp' cho lệnh needs_user.
        V4.2 (O-27): resume cũng đánh thức dispatcher NGAY như nút
        Chạy ngay — không đợi nhịp 15 giây."""
        row = self._store.resume_command(command_id)
        if row is None:
            self._notify("Lệnh không còn ở trạng thái Chờ người nữa.")
        else:
            if row["type"] in CLAUDE_COMMAND_TYPES:
                self._signal_dispatch_now()
            self._notify(
                f"Đã xếp hàng lại lệnh #{command_id} — dispatcher sẽ xét "
                "điều kiện và giao lại cho Muse phụ trách."
            )
        self._refresh_table()

    def _cancel_one(self, command: dict) -> bool:
        """Huỷ ĐÚNG MỘT lệnh theo ngữ nghĩa của nút huỷ từng dòng —
        đường huỷ DUY NHẤT, dùng chung cho nút đơn (_on_cancel) và
        "Huỷ tất cả lệnh" (V5.3.2 M-BULK). Trả True khi lệnh đã
        được huỷ (hoặc đã bàn giao cho bộ chạy nền huỷ); False khi
        tầng này không huỷ được (đang chạy mà không có bộ chạy nền
        nối vào). KHÔNG notify, KHÔNG refresh — nơi gọi chịu trách
        nhiệm báo cáo."""
        command_id = command["id"]
        status = command["status"]
        if status == "needs_user":
            # Lệnh chờ người không nằm trong bộ chạy nền — chốt thẳng.
            self._store.finish_command(
                command_id, "failed",
                result="Đã huỷ bởi người dùng.", error="Đã huỷ bởi người dùng.",
            )
            return True
        if self._cancel is not None:
            if status in ("queued", "waiting_muse", "running"):
                self._cancel(command_id)
                return True
            return False
        # Không có bộ chạy nền nối vào: chỉ huỷ được lệnh chưa chạy.
        if status in ("queued", "waiting_muse"):
            self._store.finish_command(
                command_id, "failed",
                result="Đã huỷ bởi người dùng.", error="Đã huỷ bởi người dùng.",
            )
            return True
        return False

    def _on_cancel(self, command_id: str):
        command = self._store.get_command(command_id)
        if command is not None and command["status"] == "needs_user":
            self._cancel_one(command)
            self._notify(f"Đã huỷ lệnh #{command_id}.")
            self._refresh_table()
            return
        if self._cancel is not None:
            if command is not None:
                self._cancel_one(command)
        else:
            # Không có bộ chạy nền nối vào: chỉ huỷ được lệnh chưa chạy.
            if command is not None and command["status"] in ("queued", "waiting_muse"):
                self._cancel_one(command)
                self._notify(f"Đã huỷ lệnh #{command_id}.")
            else:
                self._notify("Lệnh đang chạy — không huỷ ở tầng dữ liệu được.")
        self._refresh_table()

    # ------------------------------------------------------------------ #
    # V5.3.2 (M-BULK) — Huỷ tất cả / Xoá tất cả ở menu chuột phải
    # ------------------------------------------------------------------ #
    def _bulk_counts(self) -> tuple[int, int, int]:
        """(số lệnh huỷ được, số lệnh xoá được, số lệnh đang chạy)
        bằng aggregate SQL — đếm THẬT tại thời điểm gọi, không suy
        từ cache bảng đã cắt limit."""
        counts = self._store.command_status_counts()
        cancellable = sum(
            counts.get(status, 0) for status in CANCELLABLE_STATUSES
        )
        running = counts.get("running", 0)
        total = sum(counts.values())
        return cancellable, total - running, running

    def _command_ids(self, statuses: tuple[str, ...] | None = None) -> list[str]:
        """Toàn bộ id lệnh (lọc theo trạng thái nếu có) — phân
        trang bằng offset TRƯỚC khi thi hành, để việc huỷ/xoá làm
        thay đổi tập kết quả không làm vòng lặp bỏ sót lệnh."""
        ids: list[str] = []
        wanted = statuses or (None,)
        for status in wanted:
            offset = 0
            while True:
                page = self._store.list_commands(
                    status=status, limit=1000, offset=offset
                )
                ids.extend(row["id"] for row in page)
                if len(page) < 1000:
                    break
                offset += len(page)
        return ids

    def _on_cancel_all(self):
        """Huỷ MỌI lệnh chưa kết thúc — đúng ngữ nghĩa nút huỷ từng
        lệnh qua _cancel_one. Hộp xác nhận ghi số đếm tại thời điểm
        mở hộp; thi hành thì NẠP LẠI từng lệnh (lệnh vừa kết thúc
        trong lúc hộp đang mở không bị huỷ nhầm)."""
        cancellable, _deletable, _running = self._bulk_counts()
        if cancellable <= 0:
            return
        answer = QMessageBox.question(
            self,
            "Huỷ tất cả lệnh",
            f"Huỷ {cancellable} lệnh chưa kết thúc (đang chờ / chờ "
            "Muse / đang chạy / chờ người xử lý)?\n"
            "Lệnh đã xong, đã thất bại hoặc bị gián đoạn sẽ không "
            "bị đụng tới.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        cancelled = 0
        skipped = 0
        for command_id in self._command_ids(CANCELLABLE_STATUSES):
            fresh = self._store.get_command(command_id)
            if fresh is None or fresh["status"] not in CANCELLABLE_STATUSES:
                continue
            if self._cancel_one(fresh):
                cancelled += 1
            else:
                skipped += 1
        message = f"✕ Huỷ tất cả lệnh: đã huỷ {cancelled} lệnh."
        if skipped:
            message += (
                f" Bỏ qua {skipped} lệnh đang chạy — không huỷ được "
                "ở tầng này, hãy dừng tiến trình đang chạy trước."
            )
        self._notify(message)
        self._refresh_table()

    def _on_delete_all(self):
        """Xoá khỏi CSDL MỌI lệnh KHÔNG đang chạy — đúng đường xoá
        của nút xoá từng lệnh (Store.delete_command). Lệnh đang
        chạy được GIỮ LẠI và báo rõ số lượng bỏ qua trong cả hộp
        xác nhận lẫn dòng kết quả."""
        _cancellable, deletable, running = self._bulk_counts()
        if deletable <= 0:
            return
        text = (
            f"Xoá {deletable} lệnh khỏi danh sách? "
            "Hành động này không hoàn tác được."
        )
        if running:
            text += (
                f"\n{running} lệnh đang chạy sẽ được GIỮ LẠI — "
                "muốn xoá cả chúng thì huỷ tất cả lệnh trước."
            )
        answer = QMessageBox.question(self, "Xoá tất cả lệnh", text)
        if answer != QMessageBox.StandardButton.Yes:
            return
        deleted = 0
        kept_running = 0
        for command_id in self._command_ids():
            fresh = self._store.get_command(command_id)
            if fresh is None:
                continue
            if fresh["status"] == "running":
                kept_running += 1
                continue
            self._store.delete_command(command_id)
            deleted += 1
        message = f"🗑 Xoá tất cả lệnh: đã xoá {deleted} lệnh."
        if kept_running:
            message += f" Giữ lại {kept_running} lệnh đang chạy."
        self._notify(message)
        self._refresh_table()

    def _on_retry(self, command_id: str):
        row = self._store.requeue_command(command_id)
        if row is None:
            self._notify("Lệnh không ở trạng thái thử lại được.")
        else:
            # V4.2 (O-27): thử lại lệnh Muse cũng đánh thức
            # dispatcher ngay.
            if row["type"] in CLAUDE_COMMAND_TYPES:
                self._signal_dispatch_now()
            self._notify(
                f"Đã xếp hàng lại lệnh #{command_id} ({STATUS_LABELS.get(row['status'], row['status'])})."
            )
        self._refresh_table()

    def _on_cancel_auto_retry(self, command_id: str):
        """V4.5: huỷ lịch TỰ CHẠY LẠI của một lệnh failed."""
        row = self._store.cancel_auto_retry(command_id)
        if row is None:
            self._notify("Lệnh không còn lịch tự chạy lại để huỷ.")
        else:
            self._notify(
                f"Đã huỷ tự chạy lại cho lệnh #{command_id} — lệnh giữ "
                "nguyên trạng thái Thất bại (bấm ↻ Thử lại khi muốn chạy)."
            )
        self._refresh_table()

    # ------------------------------------------------------------------ #
    # Hành động
    # ------------------------------------------------------------------ #
    def _on_create(self):
        # V4.1.3: tạo lệnh là GHI lệnh — không chặn theo trạng thái
        # cầu nối (đã bỏ _bridge_guard ở đây): Muse chưa kết nối thì
        # lệnh vẫn vào danh sách, nằm chờ và được giao khi Muse gọi
        # lại.
        # V4.2 (G2): MỌI kết quả (kể cả lỗi validation và lỗi bất ngờ)
        # hiện NGAY TẠI FORM qua _set_form_status — không chỉ dòng
        # nhật ký thoáng qua; thành công còn chọn đúng dòng lệnh mới.
        try:
            self._create_command_from_form()
        except Exception as exc:
            message = f"❌ Chưa tạo được lệnh: {exc}"
            self._set_form_status(message, ok=False)
            self._notify(message)

    def _create_command_from_form(self):
        command_type = self.type_combo.currentData()
        profile_id = self.profile_combo.currentData()
        if profile_id is None:
            message = "Chưa có hồ sơ nào — thêm hồ sơ ở mục Hồ sơ trước."
            self._set_form_status("❌ " + message, ok=False)
            self._notify(message)
            return
        anchor_profile = self._store.get_profile(profile_id)
        scheduled_at = None
        if self.schedule_check.isChecked():
            scheduled_at = self.schedule_edit.dateTime().toPython().astimezone()
            scheduled_at = scheduled_at.isoformat(timespec="seconds")
        instruction = self.instruction_edit.toPlainText().strip()

        # V4.5: đích tạo lệnh. Tick kênh + loại lệnh có fan-out →
        # MỘT ĐÍCH MỖI KÊNH (đúng hồ sơ của kênh đó); >1 đích = một
        # LÔ chung batch_id. Chưa tick → một đích duy nhất ở hồ sơ
        # đích, không kênh (hành vi cũ). Loại bắt buộc kênh mà chưa
        # tick kênh nào → BÁO LỖI tại form, không tạo lệnh rỗng.
        schema = command_schema.COMMAND_SCHEMAS.get(command_type or "", {})
        checked = self._checked_channels()
        if schema.get("require_channel") and not checked:
            message = (
                "Loại lệnh này bắt buộc có kênh — tick ít nhất 1 kênh "
                "trong danh sách Kênh liên quan trước khi Tạo lệnh."
            )
            self._set_form_status("❌ " + message, ok=False)
            self._notify(message)
            return
        targets: list[tuple[dict, str | None]] = []
        if self._fanout_applies(command_type) and checked:
            for entry in checked:
                target_profile = self._store.get_profile(entry["profile_id"])
                if target_profile is not None:
                    targets.append((target_profile, entry["channel_id"]))
        if not targets:
            targets = [(anchor_profile, None)]

        studio_payload = None
        if command_type == "studio_script":
            # V4.4: payload kịch bản lấy từ ô JSON — parse + kiểm tra
            # TỪNG BƯỚC ngay tại form; lỗi thì báo rõ và KHÔNG tạo lệnh.
            try:
                parsed = json.loads(self.studio_payload_edit.toPlainText())
            except json.JSONDecodeError as exc:
                message = f"Payload kịch bản chưa phải JSON hợp lệ: {exc}"
                self._set_form_status("❌ " + message, ok=False)
                self._notify(message)
                return
            if not isinstance(parsed, dict):
                message = "Payload kịch bản phải là một object JSON {\"steps\": [...]}."
                self._set_form_status("❌ " + message, ok=False)
                self._notify(message)
                return
            errors = command_schema.validate_command(command_type, payload=parsed)
            if errors:
                message = "Chưa tạo được lệnh — " + "; ".join(errors)
                self._set_form_status("❌ " + message, ok=False)
                self._notify(message)
                return
            studio_payload = parsed
        if command_type in CLAUDE_COMMAND_TYPES:
            # Kiểm tra MỌI đích TRƯỚC khi tạo bất kỳ lệnh nào — lô
            # không bao giờ dở dang nửa vời vì một kênh lỗi cấu hình.
            for target_profile, target_channel in targets:
                errors = command_schema.validate_command(
                    command_type,
                    channel_id=target_channel or "",
                    instruction=instruction,
                    payload={},
                    channel_ids=[
                        c["channel_id"]
                        for c in self._store.list_channels(target_profile["id"])
                    ],
                    skip_any_of=True,
                )
                if errors:
                    message = (
                        f"Chưa tạo được lệnh cho hồ sơ {target_profile['label']} — "
                        + "; ".join(errors)
                    )
                    self._set_form_status("❌ " + message, ok=False)
                    self._notify(message)
                    return
        # V4.0 (Đ5): MỌI lệnh vào 'queued'; lệnh Muse do dispatcher
        # xét điều kiện dữ liệu rồi mới đẩy lên 'waiting_muse'.
        status = "queued"
        batch_id = uuid.uuid4().hex[:12] if len(targets) > 1 else None
        created: list[tuple[dict, dict]] = []
        for index, (target_profile, target_channel) in enumerate(targets):
            payload = dict(studio_payload) if studio_payload is not None else None
            if batch_id is not None:
                payload = dict(payload or {})
                payload["batch_id"] = batch_id
                payload["batch_index"] = index + 1
                payload["batch_total"] = len(targets)
            command = self._store.create_command(
                command_type,
                source="ui",
                profile_id=target_profile["id"],
                profile_slug=target_profile["slug"],
                channel_id=target_channel,
                instruction=instruction,
                payload=payload,
                scheduled_at=scheduled_at,
                status=status,
                # Muse chỉ định ở form thì ghi danh ngay (None = Tự
                # động); lệnh app tự chạy luôn None.
                agent_id=(
                    self._chosen_agent_id()
                    if command_type in CLAUDE_COMMAND_TYPES
                    else None
                ),
                # V4.1.3: tạo THỦ CÔNG không truyền khoá chống trùng.
            )
            created.append((command, target_profile))
        if any(cmd.get("deduplicated") for cmd, _prof in created):
            # Phòng hờ như bản cũ: store trả cờ trùng thì nói THẬT.
            first = created[0][0]
            message = (
                f"Lệnh giống hệt đã có trong danh sách (#{first['id']}) "
                "— không tạo trùng."
            )
            self._set_form_status("ℹ " + message, ok=True)
            self._notify(message)
            self._refresh_table()
            self._select_command_row(first["id"])
            return
        choice_text, choice_ok = "", True
        if command_type in CLAUDE_COMMAND_TYPES:
            for command, target_profile in created:
                text, ok = self._apply_agent_choice(command, target_profile)
                if text:
                    choice_text = text
                choice_ok = choice_ok and ok
            # V4.2 (O-27): lệnh Muse vừa tạo → đánh thức dispatcher NGAY.
            self._signal_dispatch_now()
        first_command = created[0][0]
        if batch_id is not None:
            message = (
                f"Đã tạo LÔ {len(created)} lệnh #{batch_id} — "
                f"{COMMAND_TYPE_LABELS[command_type]} ({STATUS_LABELS[status]}), "
                f"mỗi kênh 1 lệnh riêng.{choice_text}"
            )
        else:
            message = (
                f"Đã tạo lệnh #{first_command['id']} — {COMMAND_TYPE_LABELS[command_type]} "
                f"({STATUS_LABELS[status]}) cho hồ sơ {created[0][1]['label']}."
                f"{choice_text}"
            )
        self._set_form_status(
            ("✅ " if choice_ok else "") + message, ok=choice_ok
        )
        self._notify(message)
        self.instruction_edit.clear()
        self._refresh_table()
        # V4.2 (G2): chọn + làm nổi bật đúng dòng lệnh vừa tạo.
        self._select_command_row(first_command["id"])

    def _selected_command_id(self) -> str | None:
        row = self.table.currentRow()
        if row < 0:
            return None
        item = self.table.item(row, 0)
        return item.data(Qt.ItemDataRole.UserRole) if item else None

    def _select_command_row(self, command_id: str):
        """Chọn đúng dòng của một lệnh trong bảng (id nằm ở UserRole
        của ô đầu mỗi dòng) — dùng khi cần chỉ cho người dùng thấy
        lệnh sẵn có, ví dụ trường hợp không tạo trùng ở V4.1.3."""
        for row in range(self.table.rowCount()):
            item = self.table.item(row, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == command_id:
                self.table.selectRow(row)
                self.table.setCurrentCell(row, 0)
                return

    # V5.3 (A4): _on_run_selected đã XOÁ cùng nút "▶ Chạy ngay"
    # dưới bảng — chạy lệnh chọn sẵn đi qua menu chuột phải
    # (_run_guarded) hoặc nút ▶ ngay trên dòng lệnh.

    def _on_create_channel(self):
        """Lệnh TẠO KÊNH MỚI ĐẦU TIÊN cho MAIL đang chọn ở form (không phải
        cho kênh đang chọn): lệnh chờ Muse, ghi danh đúng Muse phụ trách
        mail đó (store tự gắn), nội dung mặc định theo chuẩn tạo kênh.
        V4.2 (G2/O-27): kết quả hiện tại form + đánh thức dispatcher
        ngay + chọn dòng lệnh mới, như _on_create."""
        try:
            self._create_channel_from_form()
        except Exception as exc:
            message = f"❌ Chưa tạo được lệnh tạo kênh: {exc}"
            self._set_form_status(message, ok=False)
            self._notify(message)

    def _create_channel_from_form(self):
        profile_id = self.profile_combo.currentData()
        if profile_id is None:
            message = "Chưa có hồ sơ nào — thêm hồ sơ ở mục Hồ sơ trước."
            self._set_form_status("❌ " + message, ok=False)
            self._notify(message)
            return
        # V4.1.3: không chặn theo trạng thái cầu nối — xem _on_create.
        profile = self._store.get_profile(profile_id)
        note = self.instruction_edit.toPlainText().strip()
        instruction = (
            "Tạo KÊNH THƯƠNG HIỆU ĐẦU TIÊN cho Gmail này (chưa có kênh nào "
            "được chọn — đây là lệnh cấp mail). Làm theo chuẩn tạo kênh đã "
            "lưu: nghiên cứu ngách/chủ đề phù hợp, chốt tên + handle (có "
            "phương án dự phòng), logo/banner, mô tả kênh, xác minh số điện "
            "thoại nếu Studio yêu cầu (dừng và báo lại nếu cần thao tác của "
            "chủ tài khoản). Mọi thao tác trong trình duyệt nhúng của hồ sơ "
            "này; báo tiến độ theo từng bước."
        )
        if note:
            instruction += f" Ghi chú thêm của người dùng: {note}"
        command = self._store.create_command(
            "create_channel",
            source="ui",
            profile_id=profile_id,
            profile_slug=profile["slug"],
            instruction=instruction,
            # V4.0 (Đ5): vào 'queued' — dispatcher xét điều kiện trước
            # khi đẩy lên 'waiting_muse'.
            status="queued",
            # V4.1.1: tôn trọng ô chọn Muse nhận lệnh như _on_create.
            agent_id=self._chosen_agent_id(),
            # V4.1.3: không khoá chống trùng cho thao tác thủ công —
            # xem ghi chú ở _on_create.
        )
        if command.get("deduplicated"):
            message = (
                f"Lệnh giống hệt đã có trong danh sách (#{command['id']}) "
                "— không tạo trùng."
            )
            self._set_form_status("ℹ " + message, ok=True)
            self._notify(message)
            self._refresh_table()
            self._select_command_row(command["id"])
            return
        # V4.1.1: có chỉ định Muse thì đảm bảo phân công trước khi
        # tra "Muse phụ trách" để dòng thông báo phản ánh đúng người.
        choice_text, choice_ok = self._apply_agent_choice(command, profile)
        self._signal_dispatch_now()
        owner = self._store.agent_for_profile(profile_id)
        owner_text = (
            f" — Muse phụ trách: {owner['name']}" if owner else
            " — CHƯA có Muse phụ trách mail này (vào tab Tài khoản Muse để phân công)"
        )
        message = (
            f"Đã tạo lệnh #{command['id']} — Tạo kênh mới (Đang chờ — "
            f"dispatcher sẽ giao cho Muse) cho mail "
            f"{profile['gmail']}{owner_text}.{choice_text}"
        )
        self._set_form_status(
            ("✅ " if choice_ok else "") + message, ok=choice_ok
        )
        self._notify(message)
        self.instruction_edit.clear()
        self._refresh_table()
        self._select_command_row(command["id"])

    def _on_table_menu(self, pos):
        """Menu chuột phải trên bảng lệnh (icon + text, theo trạng thái)."""
        row = self.table.rowAt(pos.y())
        if row < 0:
            return
        self.table.selectRow(row)
        command_id = self._selected_command_id()
        command = self._store.get_command(command_id) if command_id else None
        if command is None:
            return
        status = command["status"]
        menu = QMenu(self)
        if status in ("queued", "waiting_muse"):
            act = menu.addAction("▶ Chạy ngay")
            act.triggered.connect(lambda _=False, c=command_id: self._run_guarded(c))
        if (
            status in ("queued", "waiting_muse")
            and command["type"] in CLAUDE_COMMAND_TYPES
        ):
            act = menu.addAction("🎯 Đổi Muse nhận lệnh…")
            act.triggered.connect(
                lambda _=False, c=command_id: self._on_reassign_agent(c)
            )
        if command.get("profile_id"):
            act = menu.addAction("👤 Mở trang Hồ sơ của mail này")
            act.triggered.connect(
                lambda _=False, pid=command["profile_id"]: self._open_profile(pid)
            )
        if status == "needs_user":
            act = menu.addAction("▶ Đã xử lý — chạy tiếp")
            act.triggered.connect(lambda _=False, c=command_id: self._on_resume(c))
        if status in ("queued", "running", "waiting_muse", "needs_user"):
            act = menu.addAction("✕ Huỷ lệnh")
            act.triggered.connect(lambda _=False, c=command_id: self._on_cancel(c))
        if status in ("failed", "interrupted"):
            act = menu.addAction("↻ Thử lại")
            act.triggered.connect(lambda _=False, c=command_id: self._on_retry(c))
        if status == "failed" and auto_retry.pending_countdown(
            command, datetime.now().astimezone()
        ) is not None:
            act = menu.addAction("⏸ Huỷ tự chạy lại")
            act.triggered.connect(
                lambda _=False, c=command_id: self._on_cancel_auto_retry(c)
            )
        # V4.6: hỏi Muse phụ trách NGAY về lệnh này (mở chat gắn
        # ngữ cảnh lệnh) — trao đổi hai chiều thay vì chỉ nhìn trạng thái.
        act = menu.addAction("💬 Hỏi về lệnh này")
        act.triggered.connect(
            lambda _=False, c=command_id: self.ask_about_command.emit(c)
        )
        # V6.0: lịch sử kiểm tra chéo của lệnh này (kèm override
        # của chủ kênh trong hộp thoại).
        act = menu.addAction("🔍 Lịch sử kiểm tra")
        act.triggered.connect(
            lambda _=False, c=command_id: self._on_review_history(c)
        )
        menu.addSeparator()
        act = menu.addAction("🗑 Xoá lệnh")
        act.setEnabled(status != "running")
        act.triggered.connect(self._on_delete_selected)
        # V5.3 (A4): "Làm mới" chuyển vào menu này sau khi hàng nút
        # dưới bảng bị xoá (bảng vốn tự làm mới mỗi 4 giây).
        act = menu.addAction("↻ Làm mới danh sách")
        act.triggered.connect(self.refresh)
        # V5.3.2 (M-BULK): thao tác HÀNG LOẠT ở CUỐI menu, sau vạch
        # phân cách. Số đếm lấy thật tại lúc mở menu; không có gì
        # để xử lý thì nút MỜ kèm lý do trong tooltip (không giấu
        # nút, không chặn bấm lại — menu dựng mới mỗi lần mở).
        menu.addSeparator()
        cancellable, deletable, running = self._bulk_counts()
        act = menu.addAction("✕ Huỷ tất cả lệnh")
        act.setEnabled(cancellable > 0)
        if cancellable > 0:
            act.setToolTip(f"Huỷ {cancellable} lệnh chưa kết thúc")
        else:
            act.setToolTip("Không có lệnh nào đang chờ/đang chạy để huỷ")
        act.triggered.connect(self._on_cancel_all)
        act = menu.addAction("🗑 Xoá tất cả")
        act.setEnabled(deletable > 0)
        if deletable > 0:
            act.setToolTip(
                f"Xoá {deletable} lệnh — lệnh đang chạy được giữ lại"
            )
        elif running > 0:
            act.setToolTip(
                "Mọi lệnh đều đang chạy — huỷ tất cả trước nếu muốn xoá"
            )
        else:
            act.setToolTip("Không có lệnh nào để xoá")
        act.triggered.connect(self._on_delete_all)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def _on_review_history(self, command_id: str):
        """V6.0: hộp thoại Lịch sử kiểm tra của một lệnh — các vòng
        kiểm tra chéo đã qua + nút override của chủ kênh."""
        from .supervision_panel import ReviewHistoryDialog

        dialog = ReviewHistoryDialog(
            self._store,
            command_id,
            settings=getattr(self, "_settings", None) or {},
            notify=self._notify,
            parent=self,
        )
        dialog.exec()
        self._refresh_table()

    def _on_delete_selected(self):
        command_id = self._selected_command_id()
        if not command_id:
            self._notify("Chọn một lệnh trong danh sách trước đã.")
            return
        command = self._store.get_command(command_id)
        if command and command["status"] == "running":
            self._notify("Lệnh đang chạy — không xoá được.")
            return
        self._store.delete_command(command_id)
        self._notify(f"Đã xoá lệnh #{command_id}.")
        self._refresh_table()


class HeightGrip(QFrame):
    """V7.0: thanh kéo đổi CHIỀU CAO widget phía trên (kéo lên/xuống;
    bấm đúp = thu gọn ↔ mở rộng). on_done(height) khi thả chuột."""

    MIN_H, MAX_H = 60, 1200

    def __init__(self, target: QWidget, on_done=None, parent=None):
        super().__init__(parent)
        self._target = target
        self._on_done = on_done
        self._start = None
        self.setFixedHeight(12)
        self.setCursor(Qt.CursorShape.SizeVerCursor)
        self.setToolTip("Kéo để đổi chiều cao danh sách kênh · bấm đúp để thu gọn/mở rộng")
        self.setStyleSheet(
            "QFrame { background: transparent; }"
            f"QFrame:hover {{ background: rgba(206, 252, 25, 0.10); border-radius: 4px; }}")

    def paintEvent(self, event):
        super().paintEvent(event)
        from PySide6.QtGui import QColor, QPainter

        p = QPainter(self)
        p.setPen(QColor(theme.FAINT))
        cx, cy = self.width() // 2, self.height() // 2
        for dx in (-12, -6, 0, 6, 12):
            p.drawPoint(cx + dx, cy - 1)
            p.drawPoint(cx + dx, cy + 2)
        p.end()

    def set_height(self, height: int):
        height = max(self.MIN_H, min(self.MAX_H, int(height)))
        self._target.setFixedHeight(height)
        return height

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._start = (event.globalPosition().y(), self._target.height())
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._start is not None:
            y0, h0 = self._start
            self.set_height(h0 + int(event.globalPosition().y() - y0))
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        if self._start is not None:
            self._start = None
            if self._on_done:
                self._on_done(self._target.height())
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        height = self.set_height(420 if self._target.height() < 300 else 150)
        if self._on_done:
            self._on_done(height)


def _cell(text: str) -> QTableWidgetItem:
    item = QTableWidgetItem(text)
    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
    return item


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m %H:%M")
    except ValueError:
        return str(value)
