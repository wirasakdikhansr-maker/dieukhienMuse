"""V6.7 — hộp thoại "👥 Tạo hồ sơ hàng loạt & giao Muse"."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QLabel,
    QPlainTextEdit,
    QVBoxLayout,
)

from .. import bulk_profiles
from ..store import COMMAND_TYPE_LABELS
from . import theme


class BulkProfilesDialog(QDialog):
    def __init__(self, store, lead_id=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Tạo hồ sơ hàng loạt & giao Muse")
        self.resize(640, 620)
        self._store = store
        self._lead_id = lead_id
        layout = QVBoxLayout(self)
        layout.addWidget(theme.section_header("👥 Tạo hồ sơ hàng loạt & giao Muse"))
        hint = theme.muted_label(
            "Mỗi dòng một tài khoản: email|mật khẩu (tuỳ chọn |tên hồ sơ). Mật khẩu chỉ lưu trong kho "
            "riêng của hồ sơ trên máy này — không ghi nhật ký, không gửi cho Muse.")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.text = QPlainTextEdit()
        self.text.setPlaceholderText("kenh01@gmail.com|matkhau1\nkenh02@gmail.com|matkhau2|Kênh Mèo")
        self.text.textChanged.connect(self._preview)
        layout.addWidget(self.text, 1)
        self.preview = QLabel("")
        self.preview.setWordWrap(True)
        self.preview.setStyleSheet(f"color: {theme.MUTED};")
        layout.addWidget(self.preview)
        layout.addWidget(QLabel("Giao cho:"))
        self.agent_combo = QComboBox()
        self.agent_combo.addItem("Tự động — chia đều cho Muse ít hồ sơ nhất (trưởng phòng điều phối)", "auto")
        for agent in store.list_agents():
            if not agent.get("revoked"):
                self.agent_combo.addItem(f"🤖 {agent.get('name') or agent.get('email')}", int(agent["id"]))
        layout.addWidget(self.agent_combo)
        self.login_check = QCheckBox("Đăng nhập Google ngay cho các hồ sơ mới (chạy trong trình duyệt nhúng, không bật ra ngoài)")
        self.login_check.setChecked(True)
        layout.addWidget(self.login_check)
        layout.addWidget(QLabel("Việc giao kèm cho mỗi hồ sơ (để trống = chỉ tạo + phân công):"))
        self.type_combo = QComboBox()
        for key in ("free", "create_channel", "optimize", "create_video", "upload"):
            self.type_combo.addItem(COMMAND_TYPE_LABELS.get(key, key), key)
        layout.addWidget(self.type_combo)
        self.task_edit = QPlainTextEdit()
        self.task_edit.setPlaceholderText("vd: Kiểm tra kênh, tạo kênh nếu chưa có, đặt ảnh đại diện + mô tả theo chủ đề …")
        self.task_edit.setFixedHeight(80)
        layout.addWidget(self.task_edit)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Tạo & giao")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._preview()

    def _preview(self):
        entries, errors = bulk_profiles.parse_lines(self.text.toPlainText())
        existing = sum(1 for e in entries if self._store.find_profile_by_gmail(e["email"]))
        text = f"{len(entries)} tài khoản hợp lệ ({len(entries) - existing} hồ sơ mới, {existing} đã có)."
        if errors:
            text += " Lỗi: " + "; ".join(errors[:4]) + ("…" if len(errors) > 4 else "")
        self.preview.setText(text)

    def values(self) -> dict:
        entries, errors = bulk_profiles.parse_lines(self.text.toPlainText())
        task = {"type": self.type_combo.currentData(), "instruction": self.task_edit.toPlainText()}
        return {"entries": entries, "errors": errors, "target": self.agent_combo.currentData(),
                "login": self.login_check.isChecked(), "task": task}
