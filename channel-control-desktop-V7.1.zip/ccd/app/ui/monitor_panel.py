"""Panel "Tiến độ" (V3.6): MỘT màn hình theo dõi toàn bộ công việc
của mọi kênh — không phải dò từng kênh nữa.

Gồm: lệnh đang chạy/hàng đợi (làm gì, kênh nào, AI LÀM — Muse nào
hay app/tự động, tiến độ %, bước hiện tại), mục ĐANG VƯỚNG (lệnh lỗi,
lệnh chờ Muse quá lâu, lệnh chạy treo), kênh đang lên/cần chú ý
(từ snapshots), và chủ đề/từ khóa đang lên SUY TỪ số liệu kênh của
chính người dùng.

Trung thực phạm vi dữ liệu: mọi con số ở đây lấy từ dữ liệu app có
(lệnh công việc + các lần quét kênh). "Video đang lên" ở cấp video và
xu hướng toàn nền tảng cần dữ liệu YouTube Studio — phần đó do Muse
bổ sung khi quét Studio, app không bịa thay.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt

from PySide6.QtWidgets import (
    QHBoxLayout,
    QHeaderView,
    QMenu,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..store import COMMAND_TYPE_LABELS, Store
from . import theme
from .reports_panel import sparkline

ACTIVE_STATUSES = ("running", "waiting_muse", "queued")
STATUS_ORDER = {"running": 0, "waiting_muse": 1, "queued": 2}
STATUS_LABELS = {
    "running": "▶ Đang chạy",
    "waiting_muse": "⏳ Chờ Muse",
    "queued": "• Trong hàng đợi",
}


def _parse_ts(value):
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.astimezone()
    return parsed


def _age_text(start, now) -> str:
    if start is None:
        return "—"
    seconds = max(0, int((now - start).total_seconds()))
    if seconds < 90:
        return f"{seconds} giây"
    if seconds < 5400:
        return f"{seconds // 60} phút"
    if seconds < 172800:
        return f"{seconds // 3600} giờ"
    return f"{seconds // 86400} ngày"


def owner_label(command: dict, agents: dict) -> str:
    """Lệnh này do AI làm: Muse phụ trách (theo agent_id), app tự
    chạy, quy tắc tự động, hay Muse chưa ghi danh."""
    agent_id = command.get("agent_id")
    if agent_id and agent_id in agents:
        return f"🤖 {agents[agent_id]['name']}"
    if command.get("source") == "auto":
        return "⏰ Tự động (quy tắc)"
    if command["type"] in ("open_browser", "scan", "check"):
        return "🖥 App tự chạy"
    if command.get("source") == "api":
        return "🤖 Muse (qua cầu nối)"
    return "🤖 Muse"


def progress_text(command: dict) -> str:
    status = command["status"]
    percent = 100 if status == "done" else int(command.get("progress") or 0)
    filled = max(0, min(10, round(percent / 10)))
    return f"{'█' * filled}{'░' * (10 - filled)} {percent}%"


def build_monitor_data(store: Store, now: datetime | None = None) -> dict:
    """Dựng toàn bộ dữ liệu cho màn Tiến độ từ Store — hàm thuần dữ
    liệu (không Qt) để kiểm thử độc lập."""
    now = now or datetime.now().astimezone()
    agents = {a["id"]: a for a in store.list_agents()}
    profiles = {p["id"]: p for p in store.list_profiles()}
    commands = store.list_commands(limit=200)

    active = [c for c in commands if c["status"] in ACTIVE_STATUSES]
    active.sort(
        key=lambda c: (
            STATUS_ORDER.get(c["status"], 9),
            -(int(c.get("progress") or 0)),
            c.get("created_at") or "",
        )
    )

    blocked: list[dict] = []
    for command in commands:
        status = command["status"]
        if status == "failed":
            result_data = command.get("result_data") or {}
            reason = (
                command.get("error")
                or result_data.get("error")
                or result_data.get("message")
                or command.get("result")
                or "không rõ lỗi — mở mục Lệnh công việc để xem chi tiết"
            )
            blocked.append(
                {"command": command, "kind": "❌ Lệnh lỗi", "reason": str(reason)}
            )
        elif status == "waiting_muse":
            created = _parse_ts(command.get("created_at"))
            if created and (now - created).total_seconds() > 6 * 3600:
                blocked.append(
                    {
                        "command": command,
                        "kind": "⏳ Chờ Muse quá lâu",
                        "reason": f"đã chờ {_age_text(created, now)} chưa có Muse nhận",
                    }
                )
        elif status == "running":
            updated = _parse_ts(command.get("updated_at"))
            if updated and (now - updated).total_seconds() > 30 * 60:
                blocked.append(
                    {
                        "command": command,
                        "kind": "⚠ Chạy lâu không cập nhật",
                        "reason": f"không báo tiến độ mới từ {_age_text(updated, now)} trước",
                    }
                )

    rising, attention = [], []
    topic_scores: dict[str, int] = {}
    for profile_id, profile in profiles.items():
        for channel in store.list_channels(profile_id):
            growth = store.channel_growth(profile_id, channel["channel_id"])
            entry = {
                "profile": profile,
                "channel": channel,
                "growth": growth,
            }
            delta = growth["subs_delta_7d"]
            videos_delta = growth["videos_delta_7d"]
            niche = (channel.get("niche") or "").strip()
            if niche and delta:
                topic_scores[niche] = topic_scores.get(niche, 0) + delta
            if (delta or 0) > 0 or (videos_delta or 0) > 0:
                rising.append(entry)
            elif (delta or 0) < 0:
                attention.append(entry)
    rising.sort(key=lambda e: -(e["growth"]["subs_delta_7d"] or 0))
    attention.sort(key=lambda e: e["growth"]["subs_delta_7d"] or 0)
    topics = sorted(topic_scores.items(), key=lambda kv: -kv[1])

    return {
        "active": active,
        "blocked": blocked,
        "rising": rising,
        "attention": attention,
        "topics": topics,
        "agents": agents,
        "profiles": profiles,
    }


class MonitorPanel(QWidget):
    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self._store = store
        self._build_ui()
        self.refresh()
        from PySide6.QtCore import QTimer

        self._timer = QTimer(self)
        self._timer.setInterval(15_000)
        self._timer.timeout.connect(self._on_timer_tick)
        # V5.2 (§8/§15): trước đây timer chạy ngay từ __init__ và
        # không bao giờ dừng — panel này hiện không được gắn vào cây
        # UI nào nên nó là timer MỒ CÔI đốt refresh 15s mãi mãi. Nay
        # timer chỉ chạy khi panel ĐANG HIỆN (showEvent/hideEvent)
        # và tick tự kiểm tra lại hiển thị trước khi refresh.

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def _on_timer_tick(self):
        if not self.isVisible():
            return
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        header = QHBoxLayout()
        header.addWidget(theme.section_header("Trung tâm tiến độ — tất cả các kênh"))
        header.addStretch(1)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        self.kpi_label = QLabel("")
        self.kpi_label.setObjectName("CardTitle")
        self.kpi_label.setWordWrap(True)
        root.addWidget(self.kpi_label)

        root.addWidget(theme.muted_label("ĐANG XỬ LÝ & HÀNG ĐỢI — làm gì · kênh nào · ai làm · tiến độ · bước hiện tại"))
        self.active_table = QTableWidget(0, 6)
        self.active_table.setHorizontalHeaderLabels(
            ["Công việc", "Kênh / Hồ sơ", "Ai làm", "Tiến độ", "Bước hiện tại", "Đã chạy"]
        )
        header_view = self.active_table.horizontalHeader()
        header_view.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header_view.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header_view.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        # V4.3.2 (F7): panel cũ không còn trong điều hướng nhưng
        # vẫn thuộc diện "tất cả các bảng" — gắn cùng cơ chế lưu cột.
        from . import table_persist

        table_persist.attach_column_persistence(
            self.active_table, None, "monitor_active_table",
            default_widths=(260, 170, 130, 170, 240, 90),
        )
        self.active_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.active_table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng gọn theo chuẩn chung (chỉ chữ).
        self.active_table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.active_table.font())
        )
        self.active_table.setContextMenuPolicy(
            Qt.ContextMenuPolicy.CustomContextMenu
        )
        self.active_table.customContextMenuRequested.connect(self._table_menu)
        root.addWidget(self.active_table, 2)

        root.addWidget(theme.muted_label("⚠ ĐANG VƯỚNG / CẦN CHÚ Ý"))
        self.blocked_label = QLabel("")
        self.blocked_label.setObjectName("Muted")
        self.blocked_label.setWordWrap(True)
        root.addWidget(self.blocked_label)

        root.addWidget(theme.muted_label("KÊNH ĐANG LÊN — kênh vừa có video mới / subs tăng (từ số liệu quét kênh)"))
        self.rising_table = QTableWidget(0, 6)
        self.rising_table.setHorizontalHeaderLabels(
            ["Kênh", "Hồ sơ", "Subs", "Δ subs 7 ngày", "Δ video 7 ngày", "Xu hướng"]
        )
        rising_header = self.rising_table.horizontalHeader()
        rising_header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        rising_header.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        rising_header.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        from . import table_persist

        table_persist.attach_column_persistence(
            self.rising_table, None, "monitor_rising_table",
            default_widths=(230, 140, 100, 130, 130, 170),
        )
        self.rising_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.rising_table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng gọn theo chuẩn chung (chỉ chữ).
        self.rising_table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.rising_table.font())
        )
        root.addWidget(self.rising_table, 1)

        self.topics_label = QLabel("")
        self.topics_label.setObjectName("Muted")
        self.topics_label.setWordWrap(True)
        root.addWidget(self.topics_label)

    def _table_menu(self, pos):
        menu = QMenu(self)
        act = menu.addAction("↻ Làm mới ngay")
        act.triggered.connect(self.refresh)
        menu.exec(self.active_table.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------ #
    def refresh(self):
        try:
            data = build_monitor_data(self._store)
        except Exception as exc:
            self.kpi_label.setText(f"Không đọc được dữ liệu tiến độ: {exc}")
            return
        now = datetime.now().astimezone()
        active, blocked = data["active"], data["blocked"]
        running = sum(1 for c in active if c["status"] == "running")
        waiting = sum(1 for c in active if c["status"] == "waiting_muse")
        queued = sum(1 for c in active if c["status"] == "queued")
        self.kpi_label.setText(
            f"▶ Đang chạy: {running} · ⏳ Chờ Muse: {waiting} · "
            f"Hàng đợi: {queued} · ⚠ Vướng: {len(blocked)} · "
            f"📈 Kênh đang lên: {len(data['rising'])} · "
            f"📉 Kênh cần chú ý: {len(data['attention'])}"
        )

        profiles, agents = data["profiles"], data["agents"]
        self.active_table.setRowCount(len(active))
        for row, command in enumerate(active):
            profile = profiles.get(command.get("profile_id") or 0)
            values = [
                f"{STATUS_LABELS.get(command['status'], command['status'])} "
                f"{COMMAND_TYPE_LABELS.get(command['type'], command['type'])}",
                profile["label"] if profile else (command.get("profile_slug") or "—"),
                owner_label(command, agents),
                progress_text(command),
                (command.get("step") or "—"),
                _age_text(_parse_ts(command.get("created_at")), now),
            ]
            for col, value in enumerate(values):
                self.active_table.setItem(row, col, QTableWidgetItem(value))

        if blocked:
            lines = []
            for item in blocked[:12]:
                command = item["command"]
                profile = profiles.get(command.get("profile_id") or 0)
                scope = profile["label"] if profile else (command.get("profile_slug") or "—")
                lines.append(
                    f"{item['kind']}: {COMMAND_TYPE_LABELS.get(command['type'], command['type'])}"
                    f" · {scope} · {owner_label(command, agents)} — {item['reason']}"
                )
            if len(blocked) > 12:
                lines.append(f"… và {len(blocked) - 12} mục vướng khác (xem mục Lệnh công việc).")
            self.blocked_label.setText("\n".join(lines))
        else:
            self.blocked_label.setText("Không có lệnh nào đang vướng. 🎉")

        rising = data["rising"]
        self.rising_table.setRowCount(len(rising))
        for row, entry in enumerate(rising):
            channel, growth = entry["channel"], entry["growth"]
            values = [
                channel["name"] or channel["channel_id"],
                entry["profile"]["label"],
                f"{channel['subs']:,}" if channel["subs"] is not None else "—",
                f"▲ +{growth['subs_delta_7d']:,}" if growth["subs_delta_7d"] else "—",
                f"+{growth['videos_delta_7d']}" if growth["videos_delta_7d"] else "—",
                sparkline(growth["series"]),
            ]
            for col, value in enumerate(values):
                self.rising_table.setItem(row, col, QTableWidgetItem(value))

        parts = []
        if data["topics"]:
            top = " · ".join(
                f"{niche} ({'+' if score > 0 else ''}{score} subs/7 ngày)"
                for niche, score in data["topics"][:5]
                if score > 0
            )
            if top:
                parts.append(f"🔥 Chủ đề đang lên (theo kênh của bạn): {top}.")
        if data["attention"]:
            names = ", ".join(
                e["channel"]["name"] for e in data["attention"][:3]
            )
            parts.append(f"📉 Kênh đang giảm subs, cần chú ý: {names}.")
        parts.append(
            "Từ khóa/chủ đề ở đây suy từ CHỦ ĐỀ + tăng trưởng của chính "
            "các kênh bạn quản lý; xu hướng toàn YouTube và video nào "
            "đang được đề xuất ở cấp video cần dữ liệu Studio — Muse "
            "bổ sung khi quét Studio định kỳ."
        )
        self.topics_label.setText(" ".join(parts))
