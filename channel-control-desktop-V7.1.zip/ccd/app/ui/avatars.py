"""V6.8 — HÌNH AGENT 3D tuỳ chỉnh được cho Văn phòng 3D.

5 mẫu nhân vật (robot khối · nhân viên văn phòng · phi hành gia · quả cầu
AI · mèo văn phòng), chỉnh màu thân / màu nhấn / màu da / màu tóc, kích
thước 60–160%, ẩn/hiện bảng tên và chip trạng thái. Cấu hình lưu ở
settings["office_avatar"] = {"default": {...}, "agents": {"<id>": {...}}}
— đặt chung cho tất cả, hoặc ghi đè riêng từng agent.
"""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainterPath, QPen, QRadialGradient, QLinearGradient

MODELS = {
    "robot": "🤖 Robot khối",
    "human": "🧑‍💼 Nhân viên văn phòng",
    "astronaut": "🧑‍🚀 Phi hành gia",
    "orb": "🔮 Quả cầu AI",
    "cat": "🐱 Mèo văn phòng",
}
# Chiều cao đỉnh đầu (đơn vị thế giới, trước khi nhân kích thước).
MODEL_TOP = {"robot": 72, "human": 80, "astronaut": 78, "orb": 64, "cat": 58}
DEFAULT_STYLE = {
    "model": "robot", "body": "#D7DBE2", "accent": "", "skin": "#F1C9A5", "hair": "#2B2118",
    "size": 1.25, "show_name": True, "show_chip": True,
}
PRESET_COLORS = ["#D7DBE2", "#CEFC19", "#6CC7FF", "#7DDC7A", "#F2C94C", "#FF9F6B", "#FF7A7A", "#C792EA", "#3A3D44", "#FFFFFF"]


def resolve_style(settings: dict | None, agent_id=None, lead: bool = False) -> dict:
    cfg = (settings or {}).get("office_avatar") or {}
    style = dict(DEFAULT_STYLE)
    style.update({k: v for k, v in (cfg.get("default") or {}).items() if v is not None})
    if lead and cfg.get("lead"):
        style.update({k: v for k, v in cfg["lead"].items() if v is not None})
    if agent_id is not None:
        style.update({k: v for k, v in ((cfg.get("agents") or {}).get(str(agent_id)) or {}).items() if v is not None})
    if style.get("model") not in MODELS:
        style["model"] = "robot"
    try:
        style["size"] = max(0.6, min(1.8, float(style.get("size") or 1.25)))
    except (TypeError, ValueError):
        style["size"] = 1.0
    return style


def top_height(style: dict) -> float:
    return MODEL_TOP.get(style.get("model"), 72) * float(style.get("size") or 1.0)


def _c(hex_color: str, alpha: float = 1.0) -> QColor:
    color = QColor(hex_color or "#D7DBE2")
    color.setAlphaF(max(0.0, min(1.0, alpha)))
    return color


def _shade(hex_color: str, factor: int) -> str:
    """factor > 100 sáng hơn, < 100 tối hơn."""
    color = QColor(hex_color or "#D7DBE2")
    color = color.lighter(factor) if factor >= 100 else color.darker(int(10000 / max(1, factor)))
    return color.name()


def _dim(hex_color: str, active: bool, night: bool) -> str:
    """Rảnh/ngủ → nhạt màu về xám; ban đêm → tối đi."""
    color = QColor(hex_color or "#D7DBE2")
    if not active:
        grey = QColor("#8A8F98")
        color = QColor((color.red() + grey.red() * 2) // 3, (color.green() + grey.green() * 2) // 3,
                       (color.blue() + grey.blue() * 2) // 3)
    if night:
        color = color.darker(150)
    return color.name()


def paint_avatar(stage, p, rx: float, ry: float, z: float, state: str, style: dict, glow: str,
                 night: bool, bob: float, lead: bool = False) -> float:
    """Vẽ nhân vật tại chân (rx, ry, z). Trả chiều cao đỉnh đầu (đơn vị thế giới)."""
    model = style.get("model") or "robot"
    active = state not in ("idle", "sleep")
    accent = style.get("accent") or glow
    painter = {"robot": _robot, "human": _human, "astronaut": _astronaut, "orb": _orb, "cat": _cat}[model]
    top = painter(stage, p, rx, ry, z, state, style, accent, active, night, bob)
    if lead:
        crown = stage.P(rx, ry, z + top + 22 + bob)
        stage._text(p, crown, "👑", "#F2C94C", 16)
    if state == "sleep":
        zz = stage.P(rx, ry, z + top + 8 + (stage._phase * 10) % 20)
        stage._text(p, QPointF(zz.x() + 16 * stage._scale, zz.y()), "z", "#9AA0A8", 12)
        stage._text(p, QPointF(zz.x() + 26 * stage._scale, zz.y() - 12 * stage._scale), "z", "#9AA0A8", 9)
        dock = stage.P(rx + 28 * style["size"], ry, z)
        p.setPen(QPen(_c("#3A3D44"), 1))
        p.setBrush(_c("#26282D"))
        p.drawRoundedRect(QRectF(dock.x() - 6 * stage._scale, dock.y() - 22 * stage._scale, 12 * stage._scale,
                                 22 * stage._scale), 3, 3)
        stage._text(p, QPointF(dock.x(), dock.y() - 9 * stage._scale), "⚡", "#7DDC7A", 8)
    return top


def _shadow(stage, p, rx, ry, z, size, k=1.0):
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_c("#000000", 0.35))
    p.drawEllipse(stage.P(rx, ry, z), 20 * size * k * stage._scale, 9 * size * k * stage._scale)


def _eyes(stage, p, center: QPointF, color: str, closed: bool, u: float, gap: float = 6.0, r: float = 2.4):
    if closed:
        p.setPen(QPen(_c("#20232A"), max(1.0, 1.6 * u)))
        p.drawLine(QPointF(center.x() - (gap + 2) * u, center.y()), QPointF(center.x() - (gap - 3) * u, center.y()))
        p.drawLine(QPointF(center.x() + (gap - 3) * u, center.y()), QPointF(center.x() + (gap + 2) * u, center.y()))
        return
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_c(color))
    p.drawEllipse(QPointF(center.x() - gap * u, center.y()), r * u, r * u)
    p.drawEllipse(QPointF(center.x() + gap * u, center.y()), r * u, r * u)


# ----------------------------------------------------------------- mẫu 1
def _robot(stage, p, rx, ry, z, state, style, accent, active, night, bob):
    s = style["size"]
    body = _dim(style.get("body"), active, night)
    side1, side2 = _shade(body, 82), _shade(body, 92)
    _shadow(stage, p, rx, ry, z, s)
    stage._box(p, rx - 16 * s, ry - 12 * s, z, 32 * s, 24 * s, 34 * s + bob * 0.3, body, side1, side2)
    stage._box(p, rx - 14 * s, ry - 10 * s, z + 36 * s + bob, 28 * s, 22 * s, 24 * s, body, side1, side2)
    head = stage.P(rx - 4 * s, ry + 12 * s, z + 48 * s + bob)
    _eyes(stage, p, QPointF(head.x() + 1 * stage._scale, head.y() + 1.5 * stage._scale),
          accent if active else "#9AA0A8", state == "sleep", stage._scale * s)
    ant = stage.P(rx, ry, z + 60 * s + bob)
    p.setPen(QPen(_c("#9AA0A8"), 2 * stage._scale))
    p.drawLine(ant, QPointF(ant.x(), ant.y() - 12 * stage._scale * s))
    blink = 1.0 if state != "receive" else (0.4 + 0.6 * (int(stage._phase * 3) % 2))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_c(accent if active else "#3A3D44", blink))
    p.drawEllipse(QPointF(ant.x(), ant.y() - 14 * stage._scale * s), 3.5 * stage._scale * s, 3.5 * stage._scale * s)
    return MODEL_TOP["robot"] * s


# ----------------------------------------------------------------- mẫu 2
def _human(stage, p, rx, ry, z, state, style, accent, active, night, bob):
    s = style["size"]
    u = stage._scale * s
    shirt = _dim(style.get("body"), active, night)
    skin = _dim(style.get("skin") or "#F1C9A5", True, night)
    hair = style.get("hair") or "#2B2118"
    _shadow(stage, p, rx, ry, z, s)
    feet = stage.P(rx, ry, z)
    # chân
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_c(_shade("#2A2E36", 100 if not night else 70)))
    for dx in (-5, 5):
        p.drawRoundedRect(QRectF(feet.x() + (dx - 3.5) * u, feet.y() - 26 * u, 7 * u, 26 * u), 3 * u, 3 * u)
    # thân + tay
    torso = QRectF(feet.x() - 13 * u, feet.y() - (52 + bob * 0.4) * u, 26 * u, 30 * u)
    grad = QLinearGradient(torso.topLeft(), torso.topRight())
    grad.setColorAt(0, _c(_shade(shirt, 112)))
    grad.setColorAt(1, _c(_shade(shirt, 80)))
    p.setBrush(grad)
    p.drawRoundedRect(torso, 9 * u, 9 * u)
    swing = 4 * math.sin(stage._phase * 6) if state in ("working", "night", "lead") else 0
    p.setBrush(_c(_shade(shirt, 88)))
    p.drawRoundedRect(QRectF(torso.left() - 5 * u, torso.top() + 3 * u, 6 * u, 22 * u), 3 * u, 3 * u)
    p.drawRoundedRect(QRectF(torso.right() - 1 * u, torso.top() + 3 * u + swing * u, 6 * u, 22 * u), 3 * u, 3 * u)
    # cà vạt màu nhấn (màu trạng thái)
    tie = QPainterPath()
    tie.moveTo(feet.x(), torso.top() + 3 * u)
    tie.lineTo(feet.x() - 3 * u, torso.top() + 15 * u)
    tie.lineTo(feet.x(), torso.top() + 21 * u)
    tie.lineTo(feet.x() + 3 * u, torso.top() + 15 * u)
    tie.closeSubpath()
    p.setBrush(_c(accent if active else "#5A5F68"))
    p.drawPath(tie)
    # đầu
    head_c = QPointF(feet.x(), torso.top() - 11 * u)
    p.setBrush(_c(skin))
    p.drawEllipse(head_c, 10.5 * u, 11.5 * u)
    hair_path = QPainterPath()
    hair_path.moveTo(head_c.x() - 11 * u, head_c.y() - 1 * u)
    hair_path.cubicTo(head_c.x() - 11 * u, head_c.y() - 16 * u, head_c.x() + 11 * u, head_c.y() - 16 * u,
                      head_c.x() + 11 * u, head_c.y() - 1 * u)
    hair_path.cubicTo(head_c.x() + 6 * u, head_c.y() - 7 * u, head_c.x() - 6 * u, head_c.y() - 7 * u,
                      head_c.x() - 11 * u, head_c.y() - 1 * u)
    p.setBrush(_c(hair))
    p.drawPath(hair_path)
    _eyes(stage, p, QPointF(head_c.x(), head_c.y() + 2 * u), "#1B1D22", state == "sleep", u, gap=4.0, r=1.6)
    if active and state != "error":
        p.setPen(QPen(_c("#8A4B3A"), max(1.0, 1.2 * u)))
        p.drawArc(QRectF(head_c.x() - 3 * u, head_c.y() + 3 * u, 6 * u, 4 * u), 200 * 16, 140 * 16)
    return MODEL_TOP["human"] * s


# ----------------------------------------------------------------- mẫu 3
def _astronaut(stage, p, rx, ry, z, state, style, accent, active, night, bob):
    s = style["size"]
    u = stage._scale * s
    suit = _dim(style.get("body") or "#ECEEF1", active, night)
    _shadow(stage, p, rx, ry, z, s, 1.1)
    feet = stage.P(rx, ry, z)
    p.setPen(Qt.PenStyle.NoPen)
    # ba lô
    p.setBrush(_c(_shade(suit, 70)))
    p.drawRoundedRect(QRectF(feet.x() - 15 * u, feet.y() - (50 + bob * 0.4) * u, 30 * u, 26 * u), 6 * u, 6 * u)
    # thân
    body = QRectF(feet.x() - 13 * u, feet.y() - (46 + bob * 0.4) * u, 26 * u, 46 * u)
    grad = QLinearGradient(body.topLeft(), body.topRight())
    grad.setColorAt(0, _c(_shade(suit, 115)))
    grad.setColorAt(1, _c(_shade(suit, 82)))
    p.setBrush(grad)
    p.drawRoundedRect(body, 11 * u, 11 * u)
    p.setBrush(_c(accent if active else "#5A5F68"))
    p.drawRoundedRect(QRectF(feet.x() - 6 * u, body.top() + 14 * u, 12 * u, 7 * u), 2 * u, 2 * u)
    # mũ bảo hộ + kính
    helmet = QPointF(feet.x(), body.top() - 12 * u)
    p.setBrush(_c(_shade(suit, 108)))
    p.drawEllipse(helmet, 15 * u, 15 * u)
    visor = QRadialGradient(QPointF(helmet.x() - 4 * u, helmet.y() - 4 * u), 14 * u)
    visor.setColorAt(0, _c(_shade(accent if active else "#3A3D44", 140), 0.95))
    visor.setColorAt(1, _c("#0C0D0F", 0.95))
    p.setBrush(visor)
    p.drawEllipse(QRectF(helmet.x() - 11 * u, helmet.y() - 8 * u, 22 * u, 15 * u))
    p.setBrush(_c("#FFFFFF", 0.55))
    p.drawEllipse(QPointF(helmet.x() - 5 * u, helmet.y() - 4 * u), 3 * u, 2 * u)
    if state == "sleep":
        p.setBrush(_c("#000000", 0.5))
        p.drawEllipse(QRectF(helmet.x() - 11 * u, helmet.y() - 8 * u, 22 * u, 15 * u))
    return MODEL_TOP["astronaut"] * s


# ----------------------------------------------------------------- mẫu 4
def _orb(stage, p, rx, ry, z, state, style, accent, active, night, bob):
    s = style["size"]
    u = stage._scale * s
    color = _dim(style.get("body") or "#6CC7FF", active, night)
    float_h = 8 + (3 * math.sin(stage._phase * 2.5) if active else 0)
    _shadow(stage, p, rx, ry, z, s, 0.9)
    center = stage.P(rx, ry, z + (30 + float_h) * s)
    grad = QRadialGradient(QPointF(center.x() - 8 * u, center.y() - 9 * u), 30 * u)
    grad.setColorAt(0, _c(_shade(color, 160)))
    grad.setColorAt(0.55, _c(color))
    grad.setColorAt(1, _c(_shade(color, 55)))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(grad)
    p.drawEllipse(center, 22 * u, 22 * u)
    # vòng quỹ đạo màu nhấn
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.setPen(QPen(_c(accent if active else "#5A5F68", 0.85), max(1.0, 2 * u)))
    p.drawEllipse(center, 30 * u, 8 * u)
    # mặt màn hình
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(_c("#0C0D0F", 0.85))
    p.drawRoundedRect(QRectF(center.x() - 12 * u, center.y() - 6 * u, 24 * u, 12 * u), 6 * u, 6 * u)
    _eyes(stage, p, center, accent if active else "#9AA0A8", state == "sleep", u, gap=5.0, r=2.2)
    return MODEL_TOP["orb"] * s


# ----------------------------------------------------------------- mẫu 5
def _cat(stage, p, rx, ry, z, state, style, accent, active, night, bob):
    s = style["size"]
    u = stage._scale * s
    fur = _dim(style.get("body") or "#F2C94C", True, night)
    _shadow(stage, p, rx, ry, z, s)
    base = stage.P(rx, ry, z)
    p.setPen(Qt.PenStyle.NoPen)
    # đuôi
    tail = QPainterPath()
    wag = 5 * math.sin(stage._phase * 5) if active else 0
    tail.moveTo(base.x() + 10 * u, base.y() - 8 * u)
    tail.cubicTo(base.x() + 26 * u, base.y() - 10 * u, base.x() + (24 + wag) * u, base.y() - 32 * u,
                 base.x() + (18 + wag) * u, base.y() - 38 * u)
    p.setPen(QPen(_c(_shade(fur, 85)), 5 * u, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawPath(tail)
    p.setPen(Qt.PenStyle.NoPen)
    body = QRectF(base.x() - 15 * u, base.y() - (30 + bob * 0.3) * u, 30 * u, 30 * u)
    grad = QLinearGradient(body.topLeft(), body.bottomRight())
    grad.setColorAt(0, _c(_shade(fur, 115)))
    grad.setColorAt(1, _c(_shade(fur, 80)))
    p.setBrush(grad)
    p.drawEllipse(body)
    # vòng cổ màu nhấn
    p.setBrush(_c(accent if active else "#5A5F68"))
    p.drawRoundedRect(QRectF(base.x() - 9 * u, body.top() + 1 * u, 18 * u, 4 * u), 2 * u, 2 * u)
    head = QPointF(base.x(), body.top() - 9 * u)
    p.setBrush(_c(fur))
    for side in (-1, 1):
        ear = QPainterPath()
        ear.moveTo(head.x() + side * 4 * u, head.y() - 8 * u)
        ear.lineTo(head.x() + side * 12 * u, head.y() - 18 * u)
        ear.lineTo(head.x() + side * 13 * u, head.y() - 4 * u)
        ear.closeSubpath()
        p.drawPath(ear)
    p.drawEllipse(head, 13 * u, 11 * u)
    _eyes(stage, p, QPointF(head.x(), head.y() + 1 * u), "#1B1D22" if state != "error" else "#FF7A7A",
          state == "sleep", u, gap=5.0, r=2.0)
    p.setPen(QPen(_c("#5A4A3A"), max(1.0, 0.8 * u)))
    for side in (-1, 1):
        p.drawLine(QPointF(head.x() + side * 4 * u, head.y() + 5 * u), QPointF(head.x() + side * 15 * u, head.y() + 3 * u))
        p.drawLine(QPointF(head.x() + side * 4 * u, head.y() + 6 * u), QPointF(head.x() + side * 15 * u, head.y() + 8 * u))
    return MODEL_TOP["cat"] * s
