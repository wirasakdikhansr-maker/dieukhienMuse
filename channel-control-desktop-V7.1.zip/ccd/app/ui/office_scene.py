"""Ánh xạ dữ liệu → mô hình "Văn phòng diorama" (V4.1, Concept C).

Tầng THUẦN DỮ LIỆU (không import Qt): nhận các dict đúng hình dạng mà
``Store`` trả ra (agents của ``list_agents``, commands của
``list_commands``, bridge của ``bridge_state``, profiles của
``list_profiles``) và dựng một mô hình cảnh để ``office_view`` vẽ:

- ``manager``: nút "Điều phối viên" — tóm tắt cầu nối 2 lớp + hàng đợi.
- ``desks``: mỗi tài khoản Muse = một bàn làm việc (tối đa
  ``MAX_DESKS`` bàn; phần thừa đếm vào ``desks_overflow``). Trạng thái
  bàn suy từ lệnh thật: needs_user > working (đang giữ lease chạy) >
  waiting (có lệnh queued/waiting_muse thuộc phạm vi) > offline
  (agent ngoại tuyến/thu hồi) > idle (rảnh).
- ``queue``: bảng ghim hàng đợi — lệnh queued + waiting_muse sắp đúng
  thứ tự dispatcher xét (nguồn ui > auto > api, cũ trước).
- ``stats``: chip tổng cho thanh trên của tab Văn phòng.

Màu của agent: suy tất định từ (id + tên) bằng crc32 — KHÔNG dùng
hash() của Python (bị salt theo tiến trình) — cùng tiền lệ cổng debug
trong ``app.config.port_for_slug``.
"""

from __future__ import annotations

import zlib
from datetime import datetime

from ..store import COMMAND_TYPE_LABELS

MAX_DESKS = 8
QUEUE_BOARD_LIMIT = 5

# Thứ tự dispatcher xét lệnh (khớp app.dispatcher.SOURCE_PRIORITY).
SOURCE_PRIORITY = {"ui": 0, "auto": 1, "api": 2}

# Bảng màu robot theo agent (pastel, hợp tông diorama sáng của Concept C).
AGENT_PALETTE = [
    "#2DD4BF",  # teal
    "#F472B6",  # hồng
    "#A78BFA",  # tím
    "#60A5FA",  # xanh dương
    "#FBBF24",  # vàng
    "#34D399",  # xanh lá
    "#FB923C",  # cam
    "#F87171",  # đỏ nhạt
    "#38BDF8",  # xanh trời
    "#E879F9",  # tím hồng
    "#A3E635",  # chanh
    "#94A3B8",  # xám xanh
]

DESK_STATES = ("working", "waiting", "needs_user", "offline", "idle")

STATE_LABELS = {
    "working": "Đang làm",
    "waiting": "Đang chờ việc",
    "needs_user": "Chờ người xử lý",
    "offline": "Ngoại tuyến",
    "idle": "Đang rảnh",
}

AGENT_STATUS_LABELS = {
    "online": "🟢 Online",
    "idle": "🟡 Vắng",
    "offline": "⚪ Ngoại tuyến",
    "revoked": "⛔ Đã thu hồi",
}


def agent_color(agent_id, name: str = "") -> str:
    """Màu ổn định của một agent từ id + tên (cùng màu ở mọi lần chạy)."""
    key = f"{agent_id}:{name or ''}".encode("utf-8")
    return AGENT_PALETTE[zlib.crc32(key) % len(AGENT_PALETTE)]


def _parse_ts(value) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


def lease_seconds_left(command: dict, now: datetime) -> int | None:
    """Số giây lease còn lại của lệnh running (None nếu không có lease
    hoặc đã hết hạn — âm được kẹp về 0)."""
    expires = _parse_ts(command.get("lease_expires_at"))
    if expires is None:
        return None
    return max(0, int((expires - now).total_seconds()))


def _snippet(text: str | None, limit: int = 60) -> str:
    text = " ".join(str(text or "").split())
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def command_belongs_to_agent(command: dict, agent: dict) -> bool:
    """Lệnh thuộc phạm vi một agent: giữ lease của agent, ghi danh
    agent, là lệnh hiện tại agent báo cáo, hoặc thuộc hồ sơ agent phụ
    trách mà chưa ghi danh ai (cùng tinh thần list_commands_for_agent
    nhưng nhẹ hơn — chỉ dùng cho HIỂN THỊ văn phòng)."""
    agent_id = agent.get("id")
    if command.get("lease_agent_id") == agent_id:
        return True
    if command.get("agent_id") == agent_id:
        return True
    if agent.get("current_command_id") and command.get("id") == agent.get(
        "current_command_id"
    ):
        return True
    if command.get("agent_id") is None and command.get("profile_id") in (
        agent.get("profile_ids") or []
    ):
        return True
    return False


def _command_view(command: dict, now: datetime) -> dict:
    """Hình dạng rút gọn của một lệnh để vẽ bong bóng/thẻ hàng đợi.

    V4.2 (O-09/O-11): kèm ``lease_expires_at`` THÔ (chuỗi ISO) để
    tầng vẽ tính lại đếm ngược lease từ chính mốc này trên mỗi tick
    1 giây mà không phải dựng lại mô hình; kèm ``waiting_seconds``
    (đã chờ bao lâu) cho thẻ hàng đợi."""
    created = _parse_ts(command.get("created_at"))
    waiting_seconds = None
    if created is not None and command.get("status") in ("queued", "waiting_muse"):
        waiting_seconds = max(0, int((now - created).total_seconds()))
    return {
        "id": command.get("id"),
        "type": command.get("type"),
        "type_label": COMMAND_TYPE_LABELS.get(
            command.get("type"), command.get("type") or ""
        ),
        "status": command.get("status"),
        "source": command.get("source"),
        "progress": int(command.get("progress") or 0),
        "step": _snippet(command.get("step"), 80),
        "instruction": _snippet(command.get("instruction"), 60),
        "profile_slug": command.get("profile_slug") or "",
        "profile_id": command.get("profile_id"),
        "agent_id": command.get("agent_id"),
        "created_at": command.get("created_at"),
        "finished_at": command.get("finished_at"),
        "lease_seconds_left": lease_seconds_left(command, now),
        "lease_expires_at": command.get("lease_expires_at"),
        "waiting_seconds": waiting_seconds,
        "due_at": command.get("due_at"),
    }


def _dispatcher_order(command: dict):
    # Bẻ hoà bằng _seq (rowid) như dispatcher — id UUID không có thứ tự.
    return (
        SOURCE_PRIORITY.get(command.get("source"), 3),
        command.get("created_at") or "",
        command.get("_seq") or 0,
    )


def _desk_for_agent(agent: dict, commands: list[dict], now: datetime) -> dict:
    mine = [c for c in commands if command_belongs_to_agent(c, agent)]
    by_status: dict[str, list[dict]] = {}
    for command in mine:
        by_status.setdefault(command.get("status"), []).append(command)

    current: dict | None = None
    state = "idle"
    needs = sorted(by_status.get("needs_user", []), key=_dispatcher_order)
    running = by_status.get("running", [])
    # Lệnh đang chạy "đúng chủ" nhất: lệnh agent đang GIỮ LEASE, sau đó
    # tới lệnh agent tự báo cáo là hiện tại, cuối cùng mới tới ghi danh.
    running.sort(
        key=lambda c: (
            0 if c.get("lease_agent_id") == agent.get("id") else 1,
            0 if c.get("id") == agent.get("current_command_id") else 1,
            c.get("created_at") or "",
        )
    )
    waiting = sorted(
        by_status.get("waiting_muse", []) + by_status.get("queued", []),
        key=_dispatcher_order,
    )
    if needs:
        state, current = "needs_user", needs[0]
    elif running:
        state, current = "working", running[0]
    elif waiting:
        state, current = "waiting", waiting[0]
    elif agent.get("status") in ("offline", "revoked"):
        state = "offline"

    queue_count = len(waiting) - (1 if state == "waiting" and current else 0)
    # V4.2 (O-25): hàng đợi RIÊNG của agent theo đúng thứ tự
    # dispatcher xét — panel chi tiết mục "Tiếp theo" đọc danh sách
    # này (tối đa 5 lệnh sau lệnh hiện tại).
    waiting_next = [
        _command_view(c, now)
        for c in waiting
        if current is None or c.get("id") != current.get("id")
    ][:5]
    return {
        "agent_id": agent.get("id"),
        "name": agent.get("name") or agent.get("email") or f"Muse #{agent.get('id')}",
        "email": agent.get("email") or "",
        "color": agent_color(agent.get("id"), agent.get("name") or ""),
        "state": state,
        "state_label": STATE_LABELS[state],
        "agent_status": agent.get("status") or "offline",
        "agent_status_label": AGENT_STATUS_LABELS.get(
            agent.get("status") or "offline", agent.get("status") or ""
        ),
        "revoked": bool(agent.get("revoked")),
        "profile_ids": list(agent.get("profile_ids") or []),
        "current": _command_view(current, now) if current else None,
        "queue_count": max(0, queue_count),
        "waiting_next": waiting_next,
        # Lệnh gần nhất của agent (mọi trạng thái) cho panel chi tiết.
        "recent": [
            _command_view(c, now)
            for c in sorted(
                mine,
                key=lambda c: (c.get("created_at") or "", str(c.get("id") or "")),
                reverse=True,
            )[:5]
        ],
    }


def build_office_scene(
    agents: list[dict],
    commands: list[dict],
    bridge: dict | None = None,
    profiles: list[dict] | None = None,
    now: datetime | None = None,
    counts: dict | None = None,
    chat_unread: dict | None = None,
    pending_questions: dict | None = None,
) -> dict:
    """Dựng mô hình cảnh văn phòng từ dữ liệu Store. Hàm thuần — cùng
    đầu vào cho cùng đầu ra (trừ mốc ``now`` truyền vào).

    ``counts`` (V4.2 — O-07): số tổng TOÀN CỤC từ aggregate SQL của
    Store (khoá queued/running/needs_user/done_today). Danh sách
    lệnh truyền vào bị cắt ở giới hạn hiển thị (cache 200) nên số
    đếm suy từ danh sách SAI khi hệ thống lớn; có ``counts`` thì
    manager/stats dùng số tổng thật, danh sách vẫn dùng cho bàn/thẻ.
    Không truyền ``counts`` → suy từ danh sách như cũ (kiểm thử)."""
    now = now or datetime.now().astimezone()
    bridge = bridge or {}
    profiles_by_id = {p["id"]: p for p in (profiles or [])}
    agents_by_id = {a.get("id"): a for a in (agents or [])}

    desks_all = [_desk_for_agent(agent, commands, now) for agent in (agents or [])]
    for desk in desks_all:
        desk["profile_labels"] = [
            (profiles_by_id.get(pid) or {}).get("label") or f"Hồ sơ #{pid}"
            for pid in desk["profile_ids"]
        ]
        # V4.6 (10:46): chat trên từng bàn — số tin user chưa đọc
        # (huy hiệu 💬) + câu hỏi needs_user đang chờ (bong bóng
        # thoại). Nguồn do OfficeView.refresh tổng hợp từ Store;
        # không truyền → bàn không có huy hiệu/bong bóng.
        desk["chat_unread"] = int(
            (chat_unread or {}).get(desk["agent_id"], 0)
        )
        desk["pending_question"] = (
            (pending_questions or {}).get(desk["agent_id"]) or ""
        )
    desks = desks_all[:MAX_DESKS]

    queue_commands = sorted(
        [c for c in commands if c.get("status") in ("queued", "waiting_muse")],
        key=_dispatcher_order,
    )
    queue = [_command_view(c, now) for c in queue_commands]
    # V4.2 (O-11): thẻ hàng đợi hiện cả TÊN Muse phụ trách (giải
    # quyết tại đây — tầng vẽ không phải tra cứu).
    for view in queue:
        owner = None
        if view.get("agent_id"):
            owner = agents_by_id.get(view["agent_id"])
        if owner is None and view.get("profile_id") is not None:
            for agent in agents or []:
                if view["profile_id"] in (agent.get("profile_ids") or []):
                    owner = agent
                    break
        view["agent_name"] = (
            (owner.get("name") or owner.get("email"))
            if owner
            else None
        )
    running = [c for c in commands if c.get("status") == "running"]
    needs = [c for c in commands if c.get("status") == "needs_user"]
    done_today = 0
    for c in commands:
        if c.get("status") != "done":
            continue
        stamp = _parse_ts(c.get("finished_at")) or _parse_ts(c.get("created_at"))
        if stamp and stamp.date() == now.date():
            done_today += 1

    if counts:
        queue_total = int(counts.get("queued", 0)) + int(
            counts.get("waiting_muse", 0)
        )
        running_total = int(counts.get("running", 0))
        needs_total = int(counts.get("needs_user", 0))
        done_today = int(counts.get("done_today", done_today))
    else:
        queue_total = len(queue)
        running_total = len(running)
        needs_total = len(needs)

    manager = {
        "label": "Điều phối viên",
        "bridge_connected": bool(bridge.get("connected")),
        "bridge_ever": bool(bridge.get("ever")),
        "any_agent_online": bool(bridge.get("any_agent_online")),
        "seconds_ago": bridge.get("seconds_ago"),
        "queue_total": queue_total,
        "running_total": running_total,
        "needs_user_total": needs_total,
        "lines": [
            "Cầu nối: "
            + ("Đang nối ✅" if bridge.get("connected") else "Chưa nối ⚠"),
            f"Hàng đợi: {queue_total} lệnh",
            f"Đang chạy: {running_total} lệnh",
        ],
    }
    if needs_total:
        manager["lines"].append(f"Chờ người: {needs_total} lệnh ✋")

    stats = {
        "agents_total": len(agents or []),
        "agents_online": sum(
            1 for a in (agents or []) if a.get("status") == "online"
        ),
        "agents_busy": sum(1 for d in desks_all if d["state"] == "working"),
        "running": running_total,
        "queued_total": queue_total,
        "needs_user": needs_total,
        "done_today": done_today,
    }
    return {
        "manager": manager,
        "desks": desks,
        # V4.2 (O-25): TOÀN BỘ bàn (không cắt 8) — panel chi tiết +
        # bộ chọn agent dùng danh sách này để với tới agent thứ 9+.
        "desks_all": desks_all,
        "desks_overflow": max(0, len(desks_all) - MAX_DESKS),
        "desks_total": len(desks_all),
        "queue": queue,
        "queue_board": queue[:QUEUE_BOARD_LIMIT],
        "queue_total": queue_total,
        "stats": stats,
    }
