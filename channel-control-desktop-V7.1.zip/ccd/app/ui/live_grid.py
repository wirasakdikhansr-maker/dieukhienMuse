"""V7.1 — LƯỚI XEM TRỰC TIẾP: mọi trình duyệt hồ sơ hiện cùng lúc, KHÔNG đè nhau.

Trình duyệt thật chạy ngoài màn hình ở kích thước cố định (không nhúng), Muse
điều khiển qua CDP. App chỉ hiển thị HÌNH CHIẾU chụp qua CDP:

- ô đang bị Muse điều khiển → làm mới nhanh (~2 hình/giây) + viền sáng +
  dòng "🤖 Muse: bước 3/6 · bấm «Đăng»";
- ô đang rảnh → làm mới chậm (mỗi ~4 giây) để tiết kiệm máy;
- bấm "🖐 Điều khiển tay" (hoặc nhấp đúp vào hình) → app nhúng THẬT đúng trình
  duyệt đó lên khung lớn cho bạn thao tác; các trình duyệt khác vẫn chạy nền.

Một luồng nền duy nhất chụp lần lượt mọi ô (không mở N luồng cho N trình duyệt).
"""

from __future__ import annotations

import base64
import threading
import time

from PySide6.QtCore import QSize, Qt, QThread, Signal
from PySide6.QtGui import QFontMetrics, QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from . import theme

FAST_INTERVAL = 0.5
IDLE_INTERVAL = 4.0
TILE_W, TILE_H = 440, 290


class LiveGridCapture(QThread):
    frame = Signal(int, bytes)
    status = Signal(int, str)

    def __init__(self, manager, parent=None):
        super().__init__(parent)
        self._manager = manager
        self._lock = threading.Lock()
        self._targets: dict[int, dict] = {}
        self._fast: set[int] = set()
        self._next: dict[int, float] = {}
        self._clients: dict[int, object] = {}
        self._stopped = False

    def set_targets(self, profiles: list[dict]):
        with self._lock:
            self._targets = {int(p["id"]): p for p in profiles}
            for pid in list(self._next):
                if pid not in self._targets:
                    self._next.pop(pid, None)

    def set_fast(self, pid: int, fast: bool):
        with self._lock:
            if fast:
                self._fast.add(int(pid))
                self._next[int(pid)] = 0.0
            else:
                self._fast.discard(int(pid))

    def poke(self, pid: int):
        with self._lock:
            self._next[int(pid)] = 0.0

    def stop(self):
        self._stopped = True

    def _client(self, pid: int, profile: dict):
        client = self._clients.get(pid)
        if client is None:
            client = self._manager.connect_page(profile)
            self._clients[pid] = client
        return client

    def _drop(self, pid: int):
        client = self._clients.pop(pid, None)
        if client is not None:
            try:
                client.close()
            except Exception:
                pass

    def run(self):
        while not self._stopped:
            now = time.monotonic()
            with self._lock:
                due = [(pid, prof) for pid, prof in self._targets.items() if self._next.get(pid, 0.0) <= now]
                fast = set(self._fast)
                gone = [pid for pid in self._clients if pid not in self._targets]
            for pid in gone:
                self._drop(pid)
            for pid, profile in due:
                if self._stopped:
                    break
                try:
                    client = self._client(pid, profile)
                    result = client.call("Page.captureScreenshot",
                                         {"format": "jpeg", "quality": 55 if pid in fast else 40, "fromSurface": True})
                    self.frame.emit(pid, base64.b64decode(result["data"]))
                    interval = FAST_INTERVAL if pid in fast else IDLE_INTERVAL
                except Exception as exc:  # noqa: BLE001
                    self._drop(pid)
                    self.status.emit(pid, f"Chưa xem được trình duyệt: {type(exc).__name__}")
                    interval = IDLE_INTERVAL
                with self._lock:
                    self._next[pid] = time.monotonic() + interval
            time.sleep(0.08)
        for pid in list(self._clients):
            self._drop(pid)


class _LiveTile(QFrame):
    take_control = Signal(int)

    def __init__(self, profile: dict, parent=None):
        super().__init__(parent)
        self.profile_id = int(profile["id"])
        self.setObjectName("LiveTile")
        self.setFixedSize(TILE_W, TILE_H + 70)
        self._paint(False)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(4)
        head = QHBoxLayout()
        title = QLabel()
        title.setObjectName("CardTitle")
        title.setText(QFontMetrics(title.font()).elidedText(profile.get("label") or "", Qt.TextElideMode.ElideRight, 230))
        title.setToolTip(profile.get("gmail") or profile.get("label") or "")
        head.addWidget(title, 1)
        self.control_button = QPushButton("🖐 Điều khiển tay")
        self.control_button.setToolTip("Nhúng THẬT trình duyệt này lên khung lớn để bạn thao tác bằng chuột")
        self.control_button.clicked.connect(lambda: self.take_control.emit(self.profile_id))
        head.addWidget(self.control_button)
        lay.addLayout(head)
        self.image = QLabel("Đang kết nối…")
        self.image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image.setFixedSize(TILE_W - 20, TILE_H - 20)
        self.image.setStyleSheet(f"background:{theme.BG}; color:{theme.MUTED}; border-radius:8px;")
        lay.addWidget(self.image)
        self.caption = QLabel("Đang rảnh")
        self.caption.setStyleSheet(f"color:{theme.MUTED}; font-size:11px;")
        lay.addWidget(self.caption)
        self.last_frame_at = 0.0

    def resize_to(self, width: int):
        width = max(300, int(width))
        img_w = width - 20
        img_h = int(img_w * 900 / 1366)
        self.setFixedSize(width, img_h + 86)
        self.image.setFixedSize(img_w, img_h)
        pix = self.image.pixmap()
        if getattr(self, "_raw", None) is not None:
            self.image.setPixmap(self._raw.scaled(self.image.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                                  Qt.TransformationMode.SmoothTransformation))
        elif pix is not None and not pix.isNull():
            pass

    def _paint(self, active: bool):
        border = "2px solid #CEFC19" if active else f"1px solid {theme.BORDER}"
        self.setStyleSheet(f"QFrame#LiveTile {{ background:{theme.PANEL}; border:{border}; border-radius:12px; }}")

    def set_frame(self, data: bytes):
        pix = QPixmap()
        if pix.loadFromData(data):
            self._raw = pix
            self.image.setPixmap(pix.scaled(self.image.size(), Qt.AspectRatioMode.KeepAspectRatio,
                                            Qt.TransformationMode.SmoothTransformation))
            self.last_frame_at = time.monotonic()

    def set_status(self, text: str):
        if time.monotonic() - self.last_frame_at > 6:
            self.image.setText(text)

    def set_activity(self, text: str | None):
        active = bool(text)
        self._paint(active)
        if active:
            self.caption.setText(QFontMetrics(self.caption.font()).elidedText(text, Qt.TextElideMode.ElideRight, TILE_W - 24))
            self.caption.setStyleSheet("color:#CEFC19; font-size:11px; font-weight:600;")
            self.caption.setToolTip(text)
        else:
            self.caption.setText("Đang rảnh — xem chậm (4 giây/lần)")
            self.caption.setStyleSheet(f"color:{theme.MUTED}; font-size:11px;")

    def mouseDoubleClickEvent(self, event):
        self.take_control.emit(self.profile_id)
        super().mouseDoubleClickEvent(event)


class LiveGrid(QWidget):
    """Lưới hình chiếu trực tiếp các trình duyệt hồ sơ đang chạy."""

    take_control = Signal(int)

    def __init__(self, manager, parent=None):
        super().__init__(parent)
        self._manager = manager
        self.tiles: dict[int, _LiveTile] = {}
        self._ids: tuple = ()
        self._activity: dict[int, str] = {}
        self.capture: LiveGridCapture | None = None
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(6)
        self.info = theme.muted_label(
            "📺 Lưới trực tiếp — trình duyệt chạy nền ở kích thước cố định, Muse điều khiển không bị che; "
            "ô đang làm việc sáng viền + cập nhật nhanh. Bấm 🖐 để tự thao tác một trình duyệt.")
        self.info.setWordWrap(True)
        root.addWidget(self.info)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet(f"QScrollArea, QScrollArea > QWidget > QWidget {{ background:{theme.BG}; }}")
        self.host = QWidget()
        self.grid = QGridLayout(self.host)
        self.grid.setContentsMargins(4, 4, 4, 4)
        self.grid.setSpacing(12)
        self.grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self.scroll.setWidget(self.host)
        root.addWidget(self.scroll, 1)
        self.empty = theme.muted_label("Chưa có trình duyệt hồ sơ nào đang chạy.")
        root.addWidget(self.empty)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

    def sizeHint(self):
        return QSize(900, 600)

    # -- vòng đời luồng chụp
    def start(self):
        if self.capture is None:
            self.capture = LiveGridCapture(self._manager, parent=self)
            self.capture.frame.connect(self._on_frame)
            self.capture.status.connect(self._on_status)
            self.capture.start()
        self.capture.set_targets([t._profile for t in self.tiles.values()])
        for pid, text in self._activity.items():
            self.capture.set_fast(pid, not str(text).startswith(("✓", "⚠")))

    def stop(self):
        if self.capture is not None:
            self.capture.stop()
            self.capture.wait(3000)
            self.capture = None

    def is_running(self) -> bool:
        return self.capture is not None

    # -- dữ liệu
    def column_count(self) -> int:
        return max(1, (self.scroll.viewport().width() - 8) // (380 + 12))

    def set_entries(self, profiles: list[dict]):
        profiles = sorted(profiles, key=lambda p: int(p["id"]))
        ids = tuple(int(p["id"]) for p in profiles)
        if ids != self._ids:
            self._ids = ids
            for pid in [pid for pid in self.tiles if pid not in ids]:
                tile = self.tiles.pop(pid)
                tile.hide()
                tile.setParent(None)
                tile.deleteLater()
            for profile in profiles:
                pid = int(profile["id"])
                if pid not in self.tiles:
                    tile = _LiveTile(profile)
                    tile._profile = profile
                    tile.take_control.connect(self.take_control.emit)
                    tile.set_activity(self._activity.get(pid))
                    self.tiles[pid] = tile
            self._relayout()
        self.empty.setVisible(not profiles)
        if self.capture is not None:
            self.capture.set_targets(profiles)

    def _relayout(self):
        while self.grid.count():
            self.grid.takeAt(0)
        cols = self.column_count()
        width = (self.scroll.viewport().width() - 8 - 12 * (cols - 1)) // cols
        for index, pid in enumerate(self._ids):
            tile = self.tiles.get(pid)
            if tile is not None:
                tile.resize_to(min(760, width))  # ô giãn đều theo bề rộng khung
                self.grid.addWidget(tile, index // cols, index % cols)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._relayout()

    def set_activity(self, pid: int, text: str | None):
        pid = int(pid)
        if text:
            self._activity[pid] = text
        else:
            self._activity.pop(pid, None)
        tile = self.tiles.get(pid)
        if tile is not None:
            tile.set_activity(text)
        if self.capture is not None:
            self.capture.set_fast(pid, bool(text) and not str(text).startswith(("✓", "⚠")))

    def highlight(self, pid: int) -> bool:
        tile = self.tiles.get(int(pid))
        if tile is None:
            return False
        self.scroll.ensureWidgetVisible(tile, 20, 20)
        if self.capture is not None:
            self.capture.poke(int(pid))
        return True

    def _on_frame(self, pid: int, data: bytes):
        tile = self.tiles.get(int(pid))
        if tile is not None:
            tile.set_frame(data)

    def _on_status(self, pid: int, text: str):
        tile = self.tiles.get(int(pid))
        if tile is not None:
            tile.set_status(text)
