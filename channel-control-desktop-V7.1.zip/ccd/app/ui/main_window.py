"""Cửa sổ chính — cockpit điều khiển "Mission Control" (V3.1).

Bố cục browser-first: thanh điều hướng trái (7 mục, thu gọn được còn
hàng icon), vùng nội dung theo mục, thanh trạng thái dưới cùng (số hồ
sơ có CDP sống / cầu nối Muse / luật tự động kế tiếp).

Mục Hồ sơ là nơi làm việc chính với trình duyệt:
- Cột hồ sơ (ẩn/hiện được) + cột phải gồm MỘT thanh công cụ trình
  duyệt gọn duy nhất, khung xem 3 tab (Trình duyệt nhúng | Luồng trực
  tiếp | Ảnh chụp) và DOCK DƯỚI dạng tab (Kênh | Nhật ký | Hàng đợi
  lệnh) thu/mở được — mặc định mở nhưng thấp (~220px) để trình duyệt
  chiếm phần lớn chiều cao.
- Chế độ Toàn màn hình trình duyệt (nút ⛶ / F11, thoát bằng Esc):
  ẩn rail + cột hồ sơ + dock + header, chỉ còn thanh mỏng trên cùng.

Mọi việc nặng (quét, kiểm tra, lệnh, tự mở trình duyệt) chạy qua
JobEngine dùng chung (CommandRunner) — không còn QThread rời cho từng
việc. Luồng trực tiếp vẫn là LiveStreamWorker riêng (việc khung hình).
"""

from __future__ import annotations

import html
import shutil
import threading
import time
from collections import deque
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QEvent, QObject, QSize, Qt, QThread, QTimer, QUrl, Signal
from PySide6.QtGui import (
    QAction,
    QColor,
    QDesktopServices,
    QFont,
    QIcon,
    QPainter,
    QPixmap,
    QTextCharFormat,
    QTextCursor,
)
from PySide6.QtWidgets import (
    QApplication,
    QButtonGroup,
    QCheckBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QStackedWidget,
    QStatusBar,
    QSystemTrayIcon,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import (
    agent_browser,
    automation,
    automation_health,
    browser_zoom,
    cdp,
    config,
    cookies_vault,
    credentials_vault,
    docking,
    firewall_helper,
    login_helper,
    scanner,
    tailscale_helper,
)
from ..chrome_manager import ChromeManager
from ..store import CLAUDE_COMMAND_TYPES, Store, now_iso
from . import theme
from .automation_panel import AutomationPanel
from .browser_wall import BrowserWall
from .checks_panel import ChecksPanel
from .command_runner import CommandRunner, FuncWorker
from .agents_panel import AgentsPanel
from .channel_status_panel import ChannelStatusPanel
from .commands_panel import CommandsPanel
from .monitor_panel import MonitorPanel
from .reports_panel import ReportsPanel
from .dialogs import AddProfileDialog
from .journal_panel import JournalPanel
from .live_view import LiveViewLabel
from .live_worker import LiveStreamWorker
from .office_view import OfficeView
from .overview_panel import OverviewPanel
from .settings_panel import SettingsPanel
from .theme_panel import ThemePanel
from .work_panel import WorkPanel

# Chỉ số tab trong khung xem trình duyệt.
TAB_EMBED, TAB_STREAM, TAB_STILL = 0, 1, 2

#: V5.3 (A8): chữ trạng thái của khung nhúng khi CHẠY ẨN bật —
#: nói rõ đây là chế độ đã chọn (không phải lỗi nhúng) và cách
#: quay lại nhúng.
HIDDEN_MODE_PLACEHOLDER = (
    "Đang bật CHẠY ẨN NGOÀI APP: trình duyệt chạy ở cửa sổ "
    "riêng/thu nhỏ — app vẫn điều khiển qua CDP bình thường. "
    "Muốn nhúng lại vào app: tắt “🏃 Chạy ẩn” trên thanh công "
    "cụ Hồ sơ (hoặc trong Hệ thống → Cài đặt)."
)
# Chỉ số mục điều hướng. V4.3 (G1): GỘP 11 → 7 mục — Tổng quan nhập
# vào Văn phòng (KPI đã có ở header Văn phòng), Lệnh công việc + Tiến
# độ thành mục Công việc (bảng việc trên, khối lệnh dưới), Báo cáo
# kênh + Kiểm tra và Nhật ký + Cài đặt thành hai mục có TAB CON.
# Các hằng CŨ giữ làm BÍ DANH trỏ đúng mục mới để mọi nơi gọi cũ
# (_goto_checks, tín hiệu từ Văn phòng…) không vỡ.
# V4.5: thứ tự điều hướng đổi — Tài khoản Muse chuyển xuống CẠNH
# Hệ thống (Văn phòng · Hồ sơ · Công việc · Báo cáo · Tự động ·
# Tài khoản Muse · Hệ thống) theo yêu cầu người dùng.
SEC_OFFICE, SEC_PROFILES, SEC_WORK, SEC_REPORTS, SEC_AUTO, SEC_AGENTS, SEC_SYSTEM = range(7)
# V6.0: mục GIÁM SÁT CHÉO nối ở CUỐI (chỉ số 7) — không xê dịch chỉ
# số của 7 mục cũ để mọi bí danh/đường nhảy cũ giữ nguyên nghĩa.
SEC_SUPERVISION = 7
SEC_OVERVIEW = SEC_OFFICE
SEC_COMMANDS = SEC_WORK
SEC_MONITOR = SEC_WORK
SEC_CHECKS = SEC_REPORTS
SEC_JOURNAL = SEC_SYSTEM
SEC_SETTINGS = SEC_SYSTEM

NAV_ITEMS = [
    ("🏢", "Văn phòng"),
    ("👤", "Hồ sơ"),
    ("📋", "Công việc"),
    ("📊", "Báo cáo"),
    ("⏰", "Tự động"),
    ("🤖", "Tài khoản Muse"),
    ("🛠", "Hệ thống"),
    ("🔍", "Giám sát"),
]
# V6.5: thứ tự HIỂN THỊ trên thanh điều hướng (chỉ số mục không đổi):
# Văn phòng · Hồ sơ · Công việc · Báo cáo · Giám sát · Tự động · Tài khoản Muse · Hệ thống.
NAV_ORDER = [0, 1, 2, 3, 7, 4, 5, 6]


class _AvatarWorker(QThread):
    """Tải logo kênh (avatar) ở luồng nền về thư mục avatars — lỗi mạng
    thì bỏ qua lặng lẽ (kênh vẫn hiện tên như thường)."""

    fetched = Signal(str, str)

    def __init__(self, jobs, parent=None):
        super().__init__(parent)
        self._jobs = jobs  # [(channel_id, url, dest_path)]

    def run(self):
        import urllib.request

        for channel_id, url, dest in self._jobs:
            try:
                request = urllib.request.Request(
                    url, headers={"User-Agent": "Mozilla/5.0"}
                )
                with urllib.request.urlopen(request, timeout=10) as response:
                    data = response.read(2_000_000)
                path = Path(dest)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
                self.fetched.emit(channel_id, dest)
            except Exception:
                self.fetched.emit(channel_id, "")


# --------------------------------------------------------------------------- #
# Thẻ hồ sơ ở cột trái
# --------------------------------------------------------------------------- #
class _InputWatch(QObject):
    def __init__(self, window):
        super().__init__(window)
        self._window = window

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.MouseButtonPress, QEvent.Type.KeyPress, QEvent.Type.Wheel):
            self._window._last_user_input = time.monotonic()
        return False


class ProfileCard(QFrame):
    clicked = Signal(int)

    def __init__(self, profile_id: int, parent=None):
        super().__init__(parent)
        self._profile_id = profile_id
        self.setObjectName("ProfileCard")
        self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._profile_id)
        super().mousePressEvent(event)

    def set_selected(self, selected: bool):
        self.setProperty("selected", "true" if selected else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def set_activity(self, text: str):
        """V7.0: hồ sơ đang bị Muse điều khiển → dòng xanh dưới thẻ."""
        label = getattr(self, "activity_label", None)
        if text:
            if label is None and self.layout() is not None:
                label = QLabel()
                label.setWordWrap(True)
                label.setStyleSheet("color:#CEFC19; font-size:11px; font-weight:600;")
                self.layout().addWidget(label)
                self.activity_label = label
            if label is not None:
                label.setText(text)
                label.show()
        elif label is not None:
            label.hide()


class TitleBar(QWidget):
    """Thanh tiêu đề RIÊNG của app (V3.7): logo Muse Automation ở góc
    trái-trên, CÙNG HÀNG với các nút − / □ / ✕ tự vẽ. Kéo thả để di chuyển
    cửa sổ; nhấn đúp để phóng to / khôi phục."""

    def __init__(self, window: "MainWindow", parent=None):
        super().__init__(parent)
        self._window = window
        self.setObjectName("TitleBar")
        self.setFixedHeight(38)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 0, 6, 0)
        layout.setSpacing(8)
        icon_path = Path(__file__).resolve().parent.parent / "assets" / "app_icon.png"
        logo = QLabel()
        if icon_path.exists():
            logo.setPixmap(
                QPixmap(str(icon_path)).scaled(
                    24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation
                )
            )
        layout.addWidget(logo)
        title = QLabel("Muse Automation — Channel Control Desktop")
        title.setObjectName("TitleBarText")
        layout.addWidget(title)
        layout.addStretch(1)
        self.btn_min = QPushButton("−")
        self.btn_min.setObjectName("WinBtn")
        self.btn_min.setToolTip("Thu nhỏ")
        self.btn_min.clicked.connect(window.showMinimized)
        layout.addWidget(self.btn_min)
        self.btn_max = QPushButton("□")
        self.btn_max.setObjectName("WinBtn")
        self.btn_max.setToolTip("Phóng to / khôi phục")
        self.btn_max.clicked.connect(window._toggle_maximize)
        layout.addWidget(self.btn_max)
        self.btn_close = QPushButton("✕")
        self.btn_close.setObjectName("WinBtnClose")
        self.btn_close.setToolTip("Đóng (thu xuống khay nếu đã bật trong Cài đặt)")
        self.btn_close.clicked.connect(window.close)
        layout.addWidget(self.btn_close)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._window._drag_pos = (
                event.globalPosition().toPoint() - self._window.frameGeometry().topLeft()
            )
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        window = self._window
        if window._drag_pos is not None and event.buttons() & Qt.LeftButton:
            if not window.isMaximized() and not window.isFullScreen():
                window.move(event.globalPosition().toPoint() - window._drag_pos)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._window._drag_pos = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            self._window._toggle_maximize()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


# --------------------------------------------------------------------------- #
# Khung chứa cửa sổ Chrome nhúng
# --------------------------------------------------------------------------- #
class DockContainer(QWidget):
    """Widget native làm "ổ cắm" cho cửa sổ Chrome thật khi nhúng
    (Win32 SetParent trỏ vào HWND của widget này)."""

    resized = Signal(int, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_NativeWindow, True)
        self.setStyleSheet("background:#060706;")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resized.emit(self.width(), self.height())


# --------------------------------------------------------------------------- #
# Cửa sổ chính
# --------------------------------------------------------------------------- #
class MainWindow(QMainWindow):
    # Tín hiệu bắc cầu: callback của JobEngine chạy trên luồng engine,
    # phát Signal ở đây để Qt xếp hàng về luồng UI an toàn.
    _bg_scan_finished = Signal(dict, int)
    _bg_open_finished = Signal(object)
    _bg_login_finished = Signal(dict, int)
    _bg_agent_login = Signal(int, object)
    _bg_agent_probe = Signal(int, str)
    # V6.2: đăng nhập hàng loạt muse.ai qua tinyhost.shop.
    _bg_bulk_login_msg = Signal(str)
    _bg_bulk_login_result = Signal(int, object)
    _bg_bulk_login_done = Signal(object)
    _bg_push_result = Signal(str)
    # V6.4.3: sự kiện của cầu nối chat muse.ai (luồng nền → giao diện).
    _bg_bridge = Signal(object)
    # V6.5: kết quả một vòng Muse điều khiển trình duyệt (luồng nền → UI).
    _bg_control = Signal(object)
    # V7.0: từng BƯỚC Muse đang thao tác trên trình duyệt (luồng nền → UI).
    _bg_control_step = Signal(object)
    _bg_zoom_done = Signal(object)

    def __init__(self, store: Store, manager: ChromeManager, settings: dict,
                 agent_server=None):
        super().__init__()
        self.setWindowTitle("Channel Control Desktop — Trung tâm điều khiển kênh")
        self.resize(1440, 900)
        self.setMinimumSize(1100, 700)
        # V3.7: icon CHUNG cho mọi cửa sổ của app (logo Muse Automation) +
        # cửa sổ không khung với thanh tiêu đề riêng: logo ở góc TRÁI-TRÊN
        # cùng hàng với các nút − / □ / ✕ tự vẽ.
        icon_path = Path(__file__).resolve().parent.parent / "assets" / "app_icon.png"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        self.setWindowFlags(self.windowFlags() | Qt.FramelessWindowHint)
        # V6.9: mọi nút bấm đều có phản hồi (sáng viền / "⏳ Đang …")
        from . import button_feedback

        button_feedback.install()
        # V7.0: nhớ lúc bạn thao tác gần nhất — "theo dõi tự động" không giật
        # khung xem khỏi tay bạn khi bạn đang làm việc.
        self._last_user_input = 0.0
        self._input_watch = _InputWatch(self)
        QApplication.instance().installEventFilter(self._input_watch)
        self._busy_done: dict = {}
        self._drag_pos = None
        self._resize_edge = None
        self._store = store
        self._manager = manager
        self._settings = settings
        # V5.3 (A8): đồng bộ cờ mở-thu-nhỏ mặc định của manager với
        # chế độ chạy ẩn đã lưu (mọi đường mở trình duyệt — kể cả
        # executor/cầu nối — đều mở thu nhỏ khi chế độ này bật).
        try:
            self._manager.launch_minimized_default = self._browsers_hidden()
        except Exception:
            pass
        # V6.1 (CHỐNG ĐƠ): mọi is_running() gọi từ luồng giao diện chỉ
        # đọc bộ đệm do luồng nền của ChromeManager dò song song —
        # không còn HTTP chặn tới cổng debug của từng hồ sơ mỗi nhịp.
        try:
            self._manager.ui_nonblocking = True
        except Exception:
            pass
        # V6.1: hạn chót theo loại lệnh từ cài đặt + gán hạn cho lệnh
        # đang mở từ trước bản này (không có due_at).
        try:
            from ..store import Store as _Store

            _Store.set_deadline_minutes(self._settings.get("deadline_minutes") or {})
            self._store.backfill_due_dates()
        except Exception:
            pass
        # V5.3 (A9): đẩy ảnh nền Văn phòng tuỳ chọn đã lưu vào
        # theme (rỗng = nền đóng gói).
        try:
            from . import theme as _theme

            _theme.set_office_background_path(
                self._settings.get("office_bg_image") or None
            )
        except Exception:
            pass
        self._agent_server = agent_server
        self._live_worker: LiveStreamWorker | None = None
        # Worker luồng trực tiếp đã nhận lệnh dừng nhưng CHƯA kết thúc
        # (đang kẹt trong một lệnh CDP dài): phải GIỮ tham chiếu mạnh ở
        # đây tới khi tín hiệu finished thật sự về — bỏ tham chiếu cuối
        # trong lúc QThread còn chạy khiến Qt huỷ thread giữa chừng và
        # sập app ("QThread: Destroyed while thread is still running").
        self._retiring_live_workers: list[LiveStreamWorker] = []
        self._avatar_icons: dict[str, QIcon] = {}
        self._avatar_pending: set[str] = set()
        self._avatar_workers: list[_AvatarWorker] = []
        self._current_profile_id: int | None = None
        self._has_frame = False
        self._session_states: dict[int, str] = {}
        # V4.5: tường trình duyệt nhúng (section Hồ sơ) + tự mở
        # trình duyệt khi có việc.
        self._wall_active = False
        self._wall_manual_off_count = -1
        self._data_panel_auto_hidden = False
        # V4.6 (10:47): trạng thái ĐƠN KHUNG ĐẦY KÍCH THƯỚC (panel
        # dữ liệu thu gọn cho khung đơn) + cờ người dùng đã tắt tay
        # (đường tự bật không được bật lại sau khi họ đã tắt).
        self._full_frame = False
        self._full_frame_optout = False
        self._full_frame_saved_dock = True
        self._wall_entry_ids: tuple[int, ...] = ()
        self._browser_autostart_at: dict[int, float] = {}
        self._scan_all_queue: list[dict] | None = None
        self._scan_inflight: set[int] = set()
        self._card_widgets: dict[int, ProfileCard] = {}
        self._frame_times: deque[float] = deque()
        self._last_frame_pixmap: QPixmap | None = None
        self._current_url = ""
        self._db_path = config.db_path()
        self._dock = docking.BrowserDock()
        self._watchdog = docking.DockWatchdog(self._dock, docking.find_chrome_window)
        self._dock_profile_id: int | None = None
        # Hồ sơ mà người dùng vừa bấm "Gỡ nhúng" tay: bộ tự-nhúng không
        # giành lại cho tới khi đổi hồ sơ / bấm Nhúng lại / bật lại cài đặt.
        self._embed_suppressed: set[int] = set()
        self._tab_sync_guard = False
        self._theater = False
        self._theater_saved: dict | None = None
        # V5.3 (A2): hệ TOAST đã BỎ hẳn theo lệnh chủ kênh — mọi sự
        # kiện chỉ ghi vào Nhật ký (journal/_log_ui), không còn
        # thông báo bật lên che giao diện.
        self._runner = CommandRunner(
            self._db_path, self._manager, parent=self,
            dispatch_now=self._request_dispatch_now,
        )
        self._engine = automation.AutomationEngine(self._store, log=self._log_ui)

        # V4.3 (G5): trạng thái áp zoom trình duyệt nhúng theo hồ sơ.
        self._zoom_applied: dict[int, tuple] = {}
        self._zoom_inflight: set[int] = set()
        self._zoom_last_attempt: dict[int, float] = {}

        # V5.2 (hiệu năng §15 — chi phí lớn nhất lúc khởi động):
        # áp QSS TRƯỚC khi dựng UI. Trước đây QApplication.setStyleSheet
        # chạy SAU _build_ui() khiến Qt phải nắn lại style cho TOÀN BỘ
        # cây widget đã dựng xong (~6 giây trên fixture cỡ máy thật).
        self._applied_qss: str | None = None
        # Số đo hiệu năng các nhịp nền gần nhất (ms) — hiện ở mục Hệ
        # thống (dòng "Hiệu năng") để máy thật tự chứng minh.
        self._perf_ms: dict[str, float] = {}
        self._apply_theme(self._initial_theme_tokens(), save=False)
        self._build_ui()
        self._build_tray()
        self._bg_zoom_done.connect(self._on_zoom_apply_done)
        self._bg_scan_finished.connect(self._on_scan_job_finished)
        self._bg_open_finished.connect(self._on_auto_open_result)
        self._bg_login_finished.connect(self._on_login_job_finished)
        self._bg_agent_login.connect(self._on_agent_login_opened)
        self._bg_agent_probe.connect(self._on_agent_probe_result)
        self._bg_bulk_login_msg.connect(self._log_ui)
        self._bg_bulk_login_result.connect(self._on_bulk_login_result)
        self._bg_bulk_login_done.connect(self._on_bulk_login_done)
        self._bulk_login_stop = threading.Event()
        self._bulk_login_active = False
        # V6.3: chat tức thì — đẩy tin của người dùng vào muse.ai.
        self._bg_push_result.connect(self._log_ui)
        self._push_queue = None
        self._chat_bridge = None
        self._bridge_msgs: dict = {}
        self._bg_bridge.connect(self._on_bridge_event)
        self._bg_control.connect(self._on_control_result)
        self._bg_control_step.connect(self._on_control_step)
        self._automation: dict[int, dict] = {}
        self._control_rounds: dict = {}
        self._install_chat_push()
        # Phiên đăng nhập muse.ai của một tài khoản Muse (V3.5): cửa
        # sổ Chrome riêng của Muse đó được ưu tiên nhúng trong lúc
        # người dùng đăng nhập; probe kiểm tra trạng thái mỗi 5 giây.
        self._agent_target: dict | None = None
        self._agent_probe_started = 0.0
        self._agent_probe_busy = False
        self._agent_probe_timer = QTimer(self)
        self._agent_probe_timer.setInterval(5000)
        self._agent_probe_timer.timeout.connect(self._agent_probe_tick)

        self._focus_timer = QTimer(self)
        self._focus_timer.setInterval(600)
        self._focus_timer.timeout.connect(self._sync_live_active)
        self._focus_timer.start()
        self._status_timer = QTimer(self)
        self._status_timer.setInterval(5000)
        self._status_timer.timeout.connect(self._refresh_status_bar)
        # V4.5: cùng nhịp 5 giây — tự mở trình duyệt cho lệnh đang
        # chạy mà Chrome của hồ sơ chưa chạy.
        self._status_timer.timeout.connect(self._browser_autostart_tick)
        self._status_timer.start()

        # V4.1: tab Văn phòng làm mới mỗi 1 giây — CHỈ khi đang là mục
        # hiện hành và đang hiện trên màn hình (không đọc kho vô ích
        # khi người dùng đang ở tab khác / app đang ẩn).
        self._office_timer = QTimer(self)
        self._office_timer.setInterval(1000)
        self._office_timer.timeout.connect(self._office_tick)
        self._office_timer.start()

        # V3.9 — Lớp vận chuyển Tailscale: app TỰ kiểm tra khi mở và
        # mỗi 30 giây (luồng nền, không chặn UI), tự nối lại bằng
        # "tailscale up" khi máy đã đăng nhập sẵn mà đang mất kết nối.
        self._ts_state: dict | None = None
        self._ts_level = ""
        self._ts_busy = False
        self._ts_up_busy = False
        self._ts_auto_up_armed = True
        self._ts_workers: list[FuncWorker] = []
        self._ts_timer = QTimer(self)
        self._ts_timer.setInterval(30_000)
        self._ts_timer.timeout.connect(self._check_tailscale)
        self._ts_timer.start()
        QTimer.singleShot(1200, self._check_tailscale)

        # V7.0: SAO LƯU CSDL nóng mỗi 30 phút (giữ 6 bản) — CSDL có hỏng thì
        # lúc mở app sẽ tự bù dữ liệu từ bản lành gần nhất (app/db_health.py).
        self._backup_timer = QTimer(self)
        self._backup_timer.setInterval(30 * 60_000)
        self._backup_timer.timeout.connect(self._backup_db_tick)
        self._backup_timer.start()
        QTimer.singleShot(90_000, self._backup_db_tick)

        self.refresh_profiles()
        self._log_ui("Đã mở Channel Control Desktop.")
        self._refresh_status_bar()

        # --- Nền: bộ chạy lệnh + lịch tự động + tự mở trình duyệt ---
        self._store.seed_default_rules()
        self._engine.ensure_next_runs()
        self._runner.log_line.connect(self._log_ui)
        self._runner.command_finished.connect(self._on_background_command_finished)
        # V4.5: lệnh vừa bắt đầu chạy → xét tự mở trình duyệt ngay.
        self._runner.command_started.connect(
            self._on_command_started_for_browser
        )
        self._runner.start()
        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(30_000)
        self._auto_timer.timeout.connect(self._on_auto_tick)
        self._auto_timer.start()
        self._apply_first_run_dock()
        # V5.3 (A7): trình duyệt khởi động CÙNG tool — mặc định
        # BẬT khi khoá chưa từng lưu (kèm config.DEFAULT_SETTINGS).
        if not self._settings.get("v67_browsers_on_demand"):
            # V6.7: trình duyệt CHỈ chạy khi agent cần — tắt "mở hết khi khởi động" một lần.
            self._settings["v67_browsers_on_demand"] = True
            self._settings["auto_open_browsers_on_start"] = False
            try:
                config.save_settings(self._settings)
            except Exception:
                pass
        if self._settings.get("auto_open_browsers_on_start", False):
            QTimer.singleShot(900, self._auto_open_browsers_on_start)

    # ------------------------------------------------------------------ #
    # Dựng giao diện
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        central = QWidget()
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        # V3.7: thanh tiêu đề riêng (logo + nút cửa sổ) là hàng TRÊN CÙNG;
        # dưới nó là topbar điều hướng (V3.4).
        # V4.3.2 (F2 — nghiệm thu máy thật): BỎ HẲN panel tiêu đề
        # "CHANNEL CONTROL / MISSION CONTROL · YOUTUBE" — 3 nút của
        # nó (Cột hồ sơ / Panel dữ liệu / Thêm hồ sơ) đã chuyển vào
        # cụm phải của chính hàng điều hướng (xem _build_nav_rail).
        self.title_bar = TitleBar(self)
        outer.addWidget(self.title_bar)
        self.nav_rail = self._build_nav_rail()
        outer.addWidget(self.nav_rail)

        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(12, 12, 12, 12)
        body_layout.setSpacing(14)

        self.sections = QStackedWidget()
        # V4.1: Văn phòng diorama là mục ĐẦU TIÊN + màn hình mặc định.
        self.office_panel = OfficeView(
            self._store, settings=self._settings,
            wake_bridge=self._wake_bridge_messages,
        )
        self.office_panel.open_commands_requested.connect(
            lambda: self._switch_section(SEC_COMMANDS)
        )
        self.office_panel.open_agents_requested.connect(
            lambda: self._switch_section(SEC_AGENTS)
        )
        # V6.1: nút trong khối "Sự cố cần xử lý" của Văn phòng.
        self.office_panel.issue_action_requested.connect(
            self._on_office_issue_action
        )
        self.office_panel.open_command_requested.connect(
            self._open_command_in_work
        )
        # V4.6 (10:46): Văn phòng KHÔNG còn nút nhảy mục để chat —
        # khung chat nằm ngay trong panel chi tiết của nó.
        self.sections.addWidget(self.office_panel)                         # 0
        # V4.3 (G1): Tổng quan KHÔNG còn mục riêng — KPI của nó đã có
        # ở header Văn phòng. Widget vẫn được dựng (không đưa vào
        # stack) để các nơi tham chiếu cũ (kiểm thử, báo cáo) không vỡ.
        self.overview_panel = OverviewPanel(self._store)
        self.sections.addWidget(self._build_profiles_page())               # 1
        self.commands_panel = CommandsPanel(
            self._store,
            notify=self._log_ui,
            run_now=self._run_now_dispatch,
            cancel_command=self._runner.cancel_command,
            open_profile=self._open_profile_page,
            bridge_help=self._show_bridge_help,
            dispatch_now=self._request_dispatch_now,
            settings=self._settings,
        )
        # V4.3 (G1): mục CÔNG VIỆC = bảng việc theo agent (trên) +
        # nguyên khối Lệnh công việc (dưới); panel Tiến độ cũ được
        # thay bằng bảng việc này.
        self.commands_panel.bulk_profiles_handler = self._open_bulk_profiles
        self.work_panel = WorkPanel(
            self._store, self._settings, self.commands_panel
        )
        self.work_panel.command_chosen.connect(self.commands_panel.select_command)
        # V4.5: bấm một dòng trong Hàng đợi lệnh → chọn lệnh ở bảng
        # + làm nổi bật trên bảng việc.
        self.commands_panel.command_chosen.connect(
            self.work_panel.highlight_command
        )
        # V4.6: "💬 Hỏi về lệnh này" (bảng lệnh + hàng đợi rút gọn).
        self.commands_panel.ask_about_command.connect(self._open_command_chat)
        # V5.0: "Mở trình duyệt của kênh" từ bảng Theo Agent.
        self.work_panel.open_browser_requested.connect(
            self._open_channel_browser
        )
        self.sections.addWidget(self.work_panel)                           # 2
        self.agents_panel = AgentsPanel(
            self._store, notify=self._log_ui, login_handler=self._login_agent,
            bulk_login_handler=self._bulk_login_agents,
            bridge_help_handler=lambda: self._show_bridge_help(),
            settings=self._settings,
            wake_bridge=self._wake_bridge_messages,
        )
        # V4.5: KHÔNG addWidget tại đây — mục Tài khoản Muse nằm ở
        # vị trí 5 (cạnh Hệ thống), addWidget sau khối Tự động bên
        # dưới để thứ tự stack khớp thứ tự điều hướng mới.
        # V4.3 (G1): mục BÁO CÁO = Báo cáo kênh + Kiểm tra (tab con).
        self.reports_panel = ReportsPanel(self._store, settings=self._settings)
        self.checks_panel = ChecksPanel(
            self._store,
            self._db_path,
            self._manager,
            notify=self._log_ui,
            submit_custom=self._runner.submit_custom,
        )
        self.reports_tabs = QTabWidget()
        self.reports_tabs.addTab(self.reports_panel, "📊 Báo cáo kênh")
        self.reports_tabs.addTab(self.checks_panel, "🩺 Kiểm tra")
        # V6.3: báo cáo kênh hằng ngày (tự tạo lúc 08:00).
        from .daily_reports_page import DailyReportsPage

        self.daily_reports_page = DailyReportsPage(self._store, self._settings)
        self.reports_tabs.addTab(self.daily_reports_page, "📅 Báo cáo ngày")
        # V6.5: BẢNG ĐIỀU KHIỂN báo cáo (theo thiết kế đã duyệt) đứng đầu.
        from .report_dashboard import ReportDashboard

        self.report_dashboard = ReportDashboard(self._store, self._settings)
        self.reports_tabs.insertTab(0, self.report_dashboard, "📈 Tổng quan")
        self.reports_tabs.setCurrentIndex(0)
        self.report_dashboard.scan_requested.connect(self.on_scan_all)
        self.report_dashboard.export_requested.connect(self._export_daily_report_now)
        self.report_dashboard.browser_requested.connect(self._open_channel_browser)
        self.report_dashboard.assign_requested.connect(self._assign_for_profile)
        self.report_dashboard.scan_profile_requested.connect(self._scan_profile_id)
        self._daily_timer = QTimer(self)
        self._daily_timer.setInterval(60_000)
        self._daily_timer.timeout.connect(self._daily_report_tick)
        self._daily_timer.start()
        # V6.4.2: TỰ NỐI LẠI khi mất kết nối Muse (app/reconnect.py).
        self._reconnect_timer = QTimer(self)
        self._reconnect_timer.setInterval(30_000)
        self._reconnect_timer.timeout.connect(self._reconnect_tick)
        self._reconnect_timer.start()
        # V6.4.3: giao việc cho Muse qua chat muse.ai (không cần phiếu).
        self._dispatch_timer = QTimer(self)
        self._dispatch_timer.setInterval(5_000)
        self._dispatch_timer.timeout.connect(self._bridge_dispatch_tick)
        self._dispatch_timer.start()
        # V6.5: TRƯỞNG PHÒNG chạy ngay trong app (có đường gửi thật qua
        # chat muse.ai) — nhịp 30 giây, tự tiết lưu 60 giây bên trong.
        self._lead_timer = QTimer(self)
        self._lead_timer.setInterval(30_000)
        self._lead_timer.timeout.connect(self._lead_tick)
        self._lead_timer.start()
        self._idle_timer = QTimer(self)
        self._idle_timer.setInterval(60_000)
        self._idle_timer.timeout.connect(self._idle_browser_tick)
        self._idle_timer.start()
        # V6.7: CẤT mọi cửa sổ Chrome chưa nhúng (ngoài màn hình + khỏi taskbar).
        self._sweep_targets: list = []
        self._refresh_sweep_targets()
        self._sweep_timer = QTimer(self)
        self._sweep_timer.setInterval(5000)
        self._sweep_timer.timeout.connect(self._refresh_sweep_targets)
        self._sweep_timer.start()
        try:
            self._manager.start_window_sweeper(lambda: self._sweep_targets)
        except Exception:
            pass
        # Lần kiểm đầu sau 5 giây — timer CON của cửa sổ (singleShot
        # với hàm của cửa sổ đã đóng có thể làm sập tiến trình).
        self._daily_first = QTimer(self)
        self._daily_first.setSingleShot(True)
        self._daily_first.timeout.connect(self._daily_report_tick)
        self._daily_first.start(5000)
        # V4.3.1: section Báo cáo có bảng tình trạng kênh (lớp tổng
        # quan, dữ liệu thật) + khối tab Báo cáo/Kiểm tra.
        # V4.3.2 (F5 — nghiệm thu máy thật): ĐẢO THỨ TỰ — khối Báo
        # cáo kênh + Kiểm tra lên TRÊN, bảng Tình trạng kênh xuống
        # DƯỚI; splitter dọc giữ nguyên cơ chế kéo giãn hai phần.
        self.channel_status_panel = ChannelStatusPanel(
            self._store, settings=self._settings
        )
        self.channel_status_panel.channel_chosen.connect(
            self._open_channel_in_reports
        )
        self.reports_page = QWidget()
        reports_layout = QVBoxLayout(self.reports_page)
        reports_layout.setContentsMargins(0, 0, 0, 0)
        reports_layout.setSpacing(0)
        self.reports_splitter = QSplitter(Qt.Orientation.Vertical)
        self.reports_splitter.addWidget(self.reports_tabs)
        self.reports_splitter.addWidget(self.channel_status_panel)
        self.reports_splitter.setStretchFactor(0, 1)
        self.reports_splitter.setStretchFactor(1, 0)
        self.reports_splitter.setSizes([440, 460])
        reports_layout.addWidget(self.reports_splitter)
        # V6.5: Tổng quan đã có bảng từng kênh → ẩn bảng Tình trạng kênh
        # bên dưới khi đang ở Tổng quan (đủ chỗ cho biểu đồ).
        def _sync_status_panel(_index=None):
            self.channel_status_panel.setVisible(
                self.reports_tabs.currentWidget() is not self.report_dashboard)
        self.reports_tabs.currentChanged.connect(_sync_status_panel)
        _sync_status_panel()
        self.sections.addWidget(self.reports_page)                         # 3
        self.automation_panel = AutomationPanel(
            self._store, self._settings, notify=self._log_ui
        )
        self.sections.addWidget(self.automation_panel)                     # 4
        self.sections.addWidget(self.agents_panel)                         # 5
        # V6.0: panel GIÁM SÁT CHÉO dựng ở đây, đưa vào stack ở CUỐI
        # (chỉ số 7) sau khối Hệ thống bên dưới.
        from .supervision_panel import SupervisionPanel

        self.supervision_panel = SupervisionPanel(
            self._store, settings=self._settings, notify=self._log_ui
        )
        self.supervision_panel.open_command_requested.connect(
            self._open_command_in_work
        )
        self.supervision_panel.open_chat_requested.connect(
            self._open_command_chat
        )
        # V4.3 (G1): mục HỆ THỐNG = Nhật ký + Cài đặt + Giao diện.
        self.journal_panel = JournalPanel(self._store)
        self.settings_panel = SettingsPanel(
            self._store,
            self._settings,
            apply_settings=self._apply_settings,
            agent_status=self._agent_status_text,
        )
        self.theme_panel = ThemePanel(
            self._settings,
            apply_theme=self._apply_theme,
            notify=self._log_ui,
        )
        self.system_tabs = QTabWidget()
        self.system_tabs.addTab(self.journal_panel, "📓 Nhật ký")
        self.system_tabs.addTab(self.settings_panel, "⚙ Cài đặt")
        self.system_tabs.addTab(self.theme_panel, "🎨 Giao diện")
        # V5.1 (plan §2.7): mục Hệ thống = THẺ CẦU NỐI tóm tắt ở
        # trên (agent online/tổng, nhịp heartbeat cuối, mở thư mục
        # phiếu) + các tab Nhật ký/Cài đặt/Giao diện bên dưới.
        self.system_page = QWidget()
        system_layout = QVBoxLayout(self.system_page)
        system_layout.setContentsMargins(0, 0, 0, 0)
        system_layout.setSpacing(12)
        system_layout.addWidget(self._build_bridge_card())
        system_layout.addWidget(self.system_tabs, 1)
        self.sections.addWidget(self.system_page)                         # 6
        self.sections.addWidget(self.supervision_panel)                    # 7 (V6.0)
        body_layout.addWidget(self.sections, 1)
        outer.addWidget(body, 1)
        self.setCentralWidget(central)

        status = QStatusBar()
        self.status_cdp = QLabel("CDP: —")
        self.status_bridge = QLabel("Cầu nối: —")
        self.status_auto = QLabel("Tự động: —")
        # V4.2 (O-06): cảnh báo sức khoẻ vòng tự động — chỉ hiện khi
        # dispatcher/sweeper đang lỗi (automation_health trong kho).
        self.status_health = QLabel("")
        self.status_health.setStyleSheet("color:#FF7A7A; font-weight:600;")
        self.status_health.setVisible(False)
        status.addWidget(self.status_cdp, 1)
        status.addWidget(self.status_bridge, 1)
        status.addWidget(self.status_auto, 1)
        status.addWidget(self.status_health, 2)
        self.setStatusBar(status)

        self._apply_rail_state(bool(self._settings.get("ui_rail_collapsed", False)))
        self.profile_column.setVisible(
            bool(self._settings.get("ui_profile_column_visible", True))
        )
        self._set_dock_expanded(bool(self._settings.get("ui_dock_expanded", True)))
        # V4.1: mở app là vào thẳng Văn phòng diorama (màn mặc định).
        self.sections.setCurrentIndex(SEC_OFFICE)
        self._nav_buttons[SEC_OFFICE].setChecked(True)

    def _build_nav_rail(self) -> QFrame:
        """TOPBAR điều hướng (V3.4): thanh ngang trên cùng, cùng hàng
        với đỉnh cột hồ sơ — logo CCD, các nút mục, thao tác nhanh
        (quét tất cả / toàn màn hình), chấm trạng thái cầu nối Muse
        và phiên bản ở cuối hàng. V4.3.1 (Concept D): các nút mục là
        TAB LỚN bo tròn — icon ở trên, nhãn ở dưới, mục đang chọn nền
        accent + một thanh gạch chân accent ngay dưới tab (khung chứa
        riêng giữ thanh chỉ thị); thu gọn thì về icon-only như cũ và
        thanh co chiều cao theo."""
        rail = QFrame()
        # V6.3.1: header phẳng 56px kiểu AI Studio V31.1 (viền dưới mảnh,
        # tab chữ một dòng, mục đang chọn nền accent nhạt + viền accent).
        rail.setObjectName("HeaderBar")
        rail.setFixedHeight(56)
        layout = QHBoxLayout(rail)
        layout.setContentsMargins(14, 0, 14, 0)
        layout.setSpacing(4)

        logo_icon = QLabel()
        _icon_path = theme.ASSETS_DIR / "app_icon.png"
        if _icon_path.exists():
            from PySide6.QtGui import QPixmap as _QPixmap

            logo_icon.setPixmap(_QPixmap(str(_icon_path)).scaled(
                30, 30, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo_icon.setFixedSize(30, 30)
        layout.addWidget(logo_icon, 0, Qt.AlignVCenter)
        logo_text = QVBoxLayout()
        logo_text.setSpacing(0)
        logo_text.setContentsMargins(6, 0, 12, 0)
        self._nav_title = QLabel(
            f"MUSE <span style='color:{theme.ACCENT}'>AUTOMATION</span>"
        )
        self._nav_title.setTextFormat(Qt.RichText)
        self._nav_title.setStyleSheet("font-weight:800; font-size:14px;")
        logo_text.addWidget(self._nav_title)
        self._nav_subtitle = QLabel("Channel • Muse • Supervisor")
        self._nav_subtitle.setStyleSheet(
            f"color:{theme.FAINT}; font-size:9px; font-weight:600; letter-spacing:1px;"
        )
        logo_text.addWidget(self._nav_subtitle)
        layout.addLayout(logo_text)

        separator = QFrame()
        separator.setFixedWidth(1)
        separator.setStyleSheet(f"background:{theme.BORDER}; border:none;")
        layout.addWidget(separator)

        self._nav_group = QButtonGroup(self)
        self._nav_group.setExclusive(True)
        self._nav_buttons: list[QPushButton] = []
        self._nav_indicators: list[QFrame] = []
        nav_holders: list[QWidget] = []
        for index, (icon, text) in enumerate(NAV_ITEMS):
            button = QPushButton(icon)
            button.setObjectName("NavTab")
            button.setCheckable(True)
            button.setToolTip(text)
            button.clicked.connect(
                lambda _checked=False, i=index: self._switch_section(i)
            )
            button.toggled.connect(
                lambda checked, i=index: self._sync_nav_indicator(i, checked)
            )
            self._nav_group.addButton(button)
            self._nav_buttons.append(button)
            # Khung chứa: nút tab + thanh gạch chân accent ở dưới,
            # chỉ sáng khi tab đang chọn (đúng mẫu Concept D).
            holder = QWidget()
            holder_layout = QVBoxLayout(holder)
            holder_layout.setContentsMargins(0, 0, 0, 0)
            holder_layout.setSpacing(3)
            holder_layout.addWidget(button)
            indicator_row = QHBoxLayout()
            indicator_row.setContentsMargins(0, 0, 0, 0)
            indicator_row.addStretch(1)
            indicator = QFrame()
            indicator.setFixedSize(44, 0)
            indicator.hide()
            indicator.setStyleSheet(
                "background: transparent; border: none; border-radius: 2px;"
            )
            indicator_row.addWidget(indicator)
            indicator_row.addStretch(1)
            holder_layout.addLayout(indicator_row)
            self._nav_indicators.append(indicator)
            nav_holders.append(holder)
        # V6.5: Giám sát đứng NGAY CẠNH Báo cáo (chỉ số mục giữ nguyên).
        for index in NAV_ORDER:
            layout.addWidget(nav_holders[index])

        separator2 = QFrame()
        separator2.setFixedWidth(1)
        separator2.setStyleSheet(f"background:{theme.BORDER}; border:none;")
        layout.addWidget(separator2)

        # V4.3.2 (F2): cụm thao tác nằm hẳn BÊN PHẢI hàng điều hướng
        # — Quét tất cả · Toàn màn hình · 3 nút vốn ở panel tiêu đề
        # (Cột hồ sơ / Panel dữ liệu / Thêm hồ sơ) · chấm trạng thái
        # · nút thu gọn · nhãn phiên bản, tất cả CÙNG MỘT HÀNG.
        layout.addStretch(1)
        self.btn_scan_all = QPushButton("🔄")
        self.btn_scan_all.setObjectName("NavButton")
        self.btn_scan_all.setToolTip("Quét tất cả hồ sơ")
        self.btn_scan_all.clicked.connect(self.on_scan_all)
        layout.addWidget(self.btn_scan_all, 0, Qt.AlignVCenter)
        self.btn_theater = QPushButton("⛶")
        self.btn_theater.setObjectName("NavButton")
        self.btn_theater.setToolTip("Toàn màn hình trình duyệt (F11) — Esc để thoát")
        self.btn_theater.clicked.connect(self._toggle_theater)
        layout.addWidget(self.btn_theater, 0, Qt.AlignVCenter)

        separator3 = QFrame()
        separator3.setFixedWidth(1)
        separator3.setStyleSheet(f"background:{theme.BORDER}; border:none;")
        layout.addWidget(separator3)

        self.btn_toggle_column = QPushButton("☰ Cột hồ sơ")
        self.btn_toggle_column.setToolTip("Ẩn/hiện cột hồ sơ bên trái")
        self.btn_toggle_column.clicked.connect(self._toggle_profile_column)
        layout.addWidget(self.btn_toggle_column, 0, Qt.AlignVCenter)
        self.btn_toggle_panel = QPushButton("🗂 Panel dữ liệu")
        self.btn_toggle_panel.setToolTip(
            "Ẩn/hiện panel dữ liệu hồ sơ (kênh / nhật ký / hàng đợi) ở cột phải"
        )
        self.btn_toggle_panel.clicked.connect(self._toggle_dock)
        layout.addWidget(self.btn_toggle_panel, 0, Qt.AlignVCenter)
        self.btn_add = QPushButton("Thêm hồ sơ")
        self.btn_add.clicked.connect(self.on_add_profile)
        layout.addWidget(self.btn_add, 0, Qt.AlignVCenter)

        self.icon_bridge_dot = QLabel("●")
        self.icon_bridge_dot.setToolTip("Trạng thái cầu nối Muse")
        self.icon_bridge_dot.setStyleSheet(f"color:{theme.MUTED}; font-size:12px;")
        layout.addWidget(self.icon_bridge_dot, 0, Qt.AlignVCenter)
        self.btn_rail_toggle = QPushButton("»")
        self.btn_rail_toggle.setObjectName("NavButton")
        self.btn_rail_toggle.setToolTip("Hiện / ẩn nhãn chữ trên thanh điều hướng")
        self.btn_rail_toggle.clicked.connect(self._toggle_rail)
        layout.addWidget(self.btn_rail_toggle, 0, Qt.AlignVCenter)
        # V4.0: nhãn phiên bản đọc từ NGUỒN DUY NHẤT app.__version__.
        from .. import DISPLAY_VERSION

        self._nav_version = QLabel(DISPLAY_VERSION)
        self._nav_version.setObjectName("Faint12")
        layout.addWidget(self._nav_version)
        return rail

    def _sync_nav_indicator(self, index: int, checked: bool):
        """V4.3.1: thanh gạch chân dưới tab điều hướng — accent khi
        tab đang chọn, trong suốt khi không (mẫu Concept D)."""
        if index >= len(getattr(self, "_nav_indicators", [])):
            return
        self._nav_indicators[index].setStyleSheet(
            f"background: {theme.ACCENT if checked else 'transparent'};"
            " border: none; border-radius: 2px;"
        )

    def _apply_rail_state(self, collapsed: bool):
        # Topbar ngang (V3.4): "thu gọn" = chỉ hiện icon trên các nút.
        # V4.3.1: dạng mở = tab lớn icon-trên/nhãn-dưới nên thanh cao
        # 92px; dạng thu gọn về icon-only thì thanh co còn 56px.
        self._rail_collapsed_effective = collapsed
        self.nav_rail.setFixedHeight(56)
        self._nav_title.setVisible(not collapsed)
        if hasattr(self, "_nav_subtitle"):
            self._nav_subtitle.setVisible(not collapsed)
        self._nav_version.setVisible(not collapsed)
        for (icon, text), button in zip(NAV_ITEMS, self._nav_buttons):
            button.setText(icon if collapsed else f"{icon}  {text}")
            button.setMinimumWidth(40 if collapsed else 0)
            button.setFixedHeight(34)
        # V6.3.1: cụm phải GỌN kiểu AI Studio — nút tiện ích chỉ icon
        # (chữ ở tooltip) để các tab mục luôn đủ chỗ hiện chữ.
        self.btn_scan_all.setText("🔄")
        self.btn_theater.setText("⛶")
        self.btn_toggle_column.setText("☰")
        self.btn_toggle_panel.setText("🗂")
        self.btn_add.setText("➕" if collapsed else "＋ Hồ sơ")
        for button in (self.btn_scan_all, self.btn_theater, self.btn_toggle_column,
                       self.btn_toggle_panel):
            button.setObjectName("NavButton")
            button.setFixedSize(34, 34)
        self.btn_rail_toggle.setText("»" if collapsed else "«")
        if not collapsed:
            # V4.2 (O-23): ghi nhớ bề rộng topbar khi MỞ ĐẦY ĐỦ để
            # resizeEvent biết khi nào cửa sổ quá hẹp cho dạng chữ.
            hint = self.nav_rail.sizeHint().width()
            self._rail_expanded_hint = max(
                getattr(self, "_rail_expanded_hint", 0), hint
            )

    def _toggle_rail(self):
        collapsed = not bool(self._settings.get("ui_rail_collapsed"))
        self._settings["ui_rail_collapsed"] = collapsed
        config.save_settings(self._settings)
        # V4.2 (O-23): thao tác tay trong phiên này LUÔN thắng chế độ
        # tự thu gọn theo bề rộng cửa sổ.
        self._rail_manual = True
        self._apply_rail_state(collapsed)

    def _maybe_auto_collapse_rail(self):
        """V4.2 (O-23): cửa sổ hẹp hơn bề rộng topbar dạng đầy đủ →
        topbar tự chuyển icon-only (chữ bị cắt cụt là tệ nhất); rộng
        lại quá ngưỡng + đệm 48px (tránh nhấp nháy qua lại) thì khôi
        phục. Thiết lập tay (setting ui_rail_collapsed hoặc đã bấm
        nút trong phiên) LUÔN thắng; chế độ tự động KHÔNG ghi
        setting."""
        if getattr(self, "_rail_manual", False):
            return
        if bool(self._settings.get("ui_rail_collapsed", False)):
            return  # người dùng đã chốt thu gọn bằng setting
        hint = getattr(self, "_rail_expanded_hint", 0)
        if not hint:
            return
        width = self.width()
        collapsed = getattr(self, "_rail_collapsed_effective", False)
        if not collapsed and width < hint:
            self._apply_rail_state(True)
        elif collapsed and width > hint + 48:
            self._apply_rail_state(False)

    def _perf_record(self, name: str, started: float):
        """Ghi thời lượng (ms) của một nhịp vào sổ hiệu năng (V5.2)
        — mục Hệ thống hiển thị dòng "Hiệu năng" từ sổ này."""
        self._perf_ms[name] = (time.monotonic() - started) * 1000.0

    @staticmethod
    def _set_text_if_changed(label, text: str):
        """setText CHỈ khi nội dung đổi (V5.2): setText giống hệt vẫn
        khiến Qt tính lại bố cục nhãn mỗi nhịp nền."""
        if label.text() != text:
            label.setText(text)

    def perf_summary_text(self) -> str:
        """Dòng tóm tắt hiệu năng gần nhất cho mục Hệ thống."""
        if not self._perf_ms:
            return "Hiệu năng: chưa có số đo."
        parts = [
            f"{name} {ms:.0f}ms"
            for name, ms in sorted(self._perf_ms.items())
        ]
        return "Hiệu năng (nhịp gần nhất): " + " · ".join(parts)

    def _office_tick(self):
        """Nhịp 1 giây cho tab Văn phòng (V4.1): chỉ đọc kho khi tab
        đang hiện hành + đang hiện — tránh tải vô ích nền sau."""
        if (
            self.sections.currentIndex() == SEC_OFFICE
            and self.office_panel.isVisible()
        ):
            started = time.monotonic()
            self.office_panel.refresh()
            self._perf_record("Văn phòng 1s", started)

    def _repaint_section(self, index: int):
        if not hasattr(self, "sections") or self.sections.currentIndex() != index:
            return
        page = self.sections.currentWidget()
        if page is None:
            return
        from PySide6.QtWidgets import QAbstractScrollArea

        for area in page.findChildren(QAbstractScrollArea):
            if not area.updatesEnabled():
                area.setUpdatesEnabled(True)
            area.viewport().update()
        page.update()

    # ------------------------------------------------------------------ #
    # V6.3: REALTIME — mọi thay đổi DB từ cầu nối/bộ chạy nền (kết nối
    # khác) được bắt bằng PRAGMA data_version mỗi giây → làm mới ngay
    # mục đang xem (thay vì chờ nhịp 15 giây của từng panel).
    # ------------------------------------------------------------------ #
    def _ensure_realtime_watch(self):
        if getattr(self, "_rt_timer", None) is not None:
            return
        self._rt_version = self._store.data_version()
        self._rt_last_refresh = 0.0
        self._rt_timer = QTimer(self)
        self._rt_timer.setInterval(1000)
        self._rt_timer.timeout.connect(self._realtime_tick)
        self._rt_timer.start()

    def _realtime_tick(self):
        if not self.isVisible():
            return
        version = self._store.data_version()
        if version == self._rt_version:
            return
        self._rt_version = version
        now_m = time.monotonic()
        if now_m - self._rt_last_refresh < 0.9:
            return
        self._rt_last_refresh = now_m
        index = self.sections.currentIndex()
        refresh = {
            SEC_OFFICE: getattr(self.office_panel, "refresh", None),
            SEC_WORK: self._refresh_work_section,
            SEC_AGENTS: self.agents_panel.refresh,
            SEC_SUPERVISION: self.supervision_panel.refresh,
        }.get(index)
        if refresh is None:
            return
        try:
            refresh()
        except Exception:
            pass

    def _export_daily_report_now(self):
        try:
            path = self.daily_reports_page.generate_now()
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"Không tạo được báo cáo ngày: {exc}")
            return
        self._log_ui(f"📊 Đã xuất báo cáo ngày: {path.name}")
        self.reports_tabs.setCurrentWidget(self.daily_reports_page)

    def _assign_for_profile(self, profile_id: int):
        """V6.5: từ "Cần chú ý" → sang Công việc, chọn sẵn hồ sơ trong
        form giao việc nhanh."""
        self._switch_section(SEC_WORK)
        combo = getattr(self.commands_panel, "profile_combo", None)
        if combo is not None:
            index = combo.findData(int(profile_id))
            if index >= 0:
                combo.setCurrentIndex(index)

    def _scan_profile_id(self, profile_id: int):
        profile = self._store.get_profile(int(profile_id))
        if profile is None or profile["id"] in self._scan_inflight:
            return
        self._submit_scan(profile)
        self._log_ui(f"🔄 Đang quét lại hồ sơ '{profile.get('label')}'.")

    def _daily_report_tick(self):
        from .. import daily_report

        try:
            if not daily_report.due(self._store, self._settings):
                return
            path = daily_report.generate(self._store, self._settings)
        except Exception as exc:
            self._log_ui(f"Không tạo được báo cáo ngày: {exc}")
            return
        self._log_ui(f"📊 Báo cáo kênh hôm nay đã sẵn sàng: {path.name} (Báo cáo → 📅 Báo cáo ngày).")
        try:
            self.daily_reports_page.refresh()
        except Exception:
            pass
        tray = getattr(self, "_tray", None)
        if tray is not None:
            try:
                tray.showMessage("Báo cáo kênh hằng ngày", f"Đã tạo {path.name}")
            except Exception:
                pass

    def _refresh_reports_section(self):
        """Mở section Báo cáo: làm mới CẢ khối báo cáo ở trên lẫn
        bảng tình trạng kênh bên dưới (khối Kiểm tra có nút riêng)."""
        self.channel_status_panel.refresh()
        self.reports_panel.refresh()

    def _open_channel_in_reports(self, profile_id: int, channel_id: str):
        """Bấm thẻ kênh trên bảng tình trạng → nhảy về đúng dòng kênh
        đó trong bảng Báo cáo kênh ở khối trên (V4.3.2 — F5)."""
        self.reports_tabs.setCurrentWidget(self.reports_panel)
        self.reports_panel.select_channel(profile_id, channel_id)

    def _switch_section(self, index: int):
        _perf_started = time.monotonic()
        if self._theater and index != SEC_PROFILES:
            self._exit_theater()
        self.sections.setCurrentIndex(index)
        self._ensure_realtime_watch()
        # V7.0.1: nút tam giác ẩn/hiện cho mọi thanh chia của trang vừa mở
        try:
            from . import collapse

            collapse.install(self, self._settings)
        except Exception:
            pass
        # V6.3.1: ép VẼ LẠI trang vừa mở. Trang Hồ sơ chứa cửa sổ Chrome
        # NATIVE (nhúng bằng SetParent); trên Windows, chuyển sang trang
        # khác thì các bảng/khung cuộn của trang mới có thể không được
        # vẽ lại và giữ nguyên hình cũ của Chrome (lỗi "tab Tài khoản
        # mất danh sách": bảng vẫn có dữ liệu nhưng hiện vùng đen + bong
        # bóng URL sót lại). Vẽ lại ngay và thêm một nhịp sau 120ms.
        self._repaint_section(index)
        QTimer.singleShot(120, lambda i=index: self._repaint_section(i))
        # V5.2: bỏ cơ chế "focus" của V5.1 (thanh chip đã bị chủ kênh
        # bỏ) — vào mục Hồ sơ giữ nguyên cột hồ sơ/panel dữ liệu
        # theo đúng cài đặt đã lưu, như trước V5.1.
        self._nav_buttons[index].setChecked(True)
        refresh = {
            SEC_OFFICE: self.office_panel.refresh,
            SEC_WORK: self._refresh_work_section,
            SEC_AGENTS: self.agents_panel.refresh,
            SEC_REPORTS: self._refresh_reports_section,
            SEC_AUTO: self.automation_panel.refresh,
            SEC_SYSTEM: self._refresh_system_section,
            SEC_SUPERVISION: self.supervision_panel.refresh,
        }.get(index)
        if refresh is not None:
            refresh()
        self._perf_record("Chuyển mục", _perf_started)

    # V4.3.2 (F2): _build_header ĐÃ XOÁ — panel tiêu đề bỏ hẳn, 3
    # nút của nó dựng ngay trong _build_nav_rail (cụm phải).

    def _toggle_profile_column(self):
        visible = not self.profile_column.isVisible()
        self.profile_column.setVisible(visible)
        self._settings["ui_profile_column_visible"] = visible
        config.save_settings(self._settings)

    # ------------------------------------------------------------------ #
    # Trang Hồ sơ: cột hồ sơ + (toolbar + khung xem + dock dưới)
    # ------------------------------------------------------------------ #
    def _build_profiles_page(self) -> QWidget:
        page = QWidget()
        # V5.2: BỎ thanh chip hồ sơ của V5.1 (chủ kênh: "thừa") —
        # chọn hồ sơ quay về CỘT THẺ hồ sơ bên trái như trước V5.1;
        # trạng thái đăng nhập hiển thị trên thẻ + panel dữ liệu.
        page_layout = QVBoxLayout(page)
        page_layout.setContentsMargins(0, 0, 0, 0)
        page_layout.setSpacing(10)
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(14)
        self.profiles_splitter = splitter
        self.profile_column = self._build_sidebar()
        splitter.addWidget(self.profile_column)

        # Trung tâm: trình duyệt. Phải: panel DỮ LIỆU HỒ SƠ (V3.4 —
        # chuyển từ dock dưới sang cột phải, ẩn/hiện tuỳ chọn).
        center = QWidget()
        center_layout = QVBoxLayout(center)
        center_layout.setContentsMargins(0, 0, 0, 0)
        center_layout.setSpacing(10)
        self.theater_bar = self._build_theater_bar()
        self.theater_bar.hide()
        center_layout.addWidget(self.theater_bar)
        center_layout.addWidget(self._build_live_panel(), 1)
        inner = QSplitter(Qt.Horizontal)
        inner.setHandleWidth(14)
        self.profiles_inner_splitter = inner
        inner.addWidget(center)
        self.data_panel = self._build_bottom_dock()
        inner.addWidget(self.data_panel)
        inner.setSizes([660, 560])
        inner.setStretchFactor(0, 1)
        inner.setStretchFactor(1, 0)
        splitter.addWidget(inner)
        splitter.setSizes([320, 1220])
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        layout.addWidget(splitter)
        page_layout.addLayout(layout, 1)
        return page

    def _build_theater_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("Panel")
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(12, 6, 12, 6)
        layout.setSpacing(10)
        self.theater_label = QLabel("⛶ Toàn màn hình trình duyệt")
        self.theater_label.setObjectName("CardTitle")
        layout.addWidget(self.theater_label)
        layout.addStretch(1)
        exit_button = QPushButton("✕ Thoát (Esc)")
        exit_button.clicked.connect(self._exit_theater)
        layout.addWidget(exit_button)
        return bar

    def _build_sidebar(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("Panel")
        panel.setMinimumWidth(296)
        panel.setMaximumWidth(348)
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)
        layout.addWidget(theme.section_header("Hồ sơ"))

        self.cards_scroll = QScrollArea()
        self.cards_scroll.setWidgetResizable(True)
        self.cards_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.cards_scroll.setToolTip(
            "Chuột phải vào thẻ hồ sơ (hoặc nút ⋯ trên thẻ) để mở "
            "trình duyệt, đăng nhập, quét kênh, nhập cookies…"
        )
        layout.addWidget(self.cards_scroll, 1)

        # V3.7: toàn bộ nút thao tác hồ sơ CHUYỂN thành menu chuột phải
        # trên thẻ hồ sơ (có icon + text) theo yêu cầu — cột hồ sơ chỉ còn
        # thẻ + dòng trạng thái. Các nút thật vẫn được tạo/nối ở đây nhưng
        # nằm trong hộp ẨN: menu chuột phải và nút ⋯ trên thẻ gọi đúng các
        # nút này (một bộ xử lý duy nhất, không nhân đôi logic).
        actions_box = QWidget()
        actions_layout = QVBoxLayout(actions_box)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(8)
        self.btn_open = QPushButton("Mở trình duyệt")
        self.btn_open.setProperty("variant", "primary")
        self.btn_open.clicked.connect(self.on_open_browser)
        actions_layout.addWidget(self.btn_open)

        self.btn_login = QPushButton("🔐 Đăng nhập")
        self.btn_login.setToolTip(
            "Đăng nhập tài khoản của hồ sơ ngay trong trình duyệt nhúng: "
            "có cookies đã lưu thì dùng cookies, có mật khẩu đã lưu thì "
            "tự điền — gặp bước xác minh thì dừng để bạn tự hoàn tất"
        )
        self.btn_login.clicked.connect(self.on_login)
        actions_layout.addWidget(self.btn_login)

        row = QHBoxLayout()
        row.setSpacing(10)
        self.btn_scan = QPushButton("Quét kênh")
        self.btn_scan.clicked.connect(self.on_scan)
        self.btn_pause = QPushButton("Tạm dừng hồ sơ")
        self.btn_pause.clicked.connect(self.on_toggle_pause)
        row.addWidget(self.btn_scan, 1)
        row.addWidget(self.btn_pause, 1)
        actions_layout.addLayout(row)

        self.btn_delete = QPushButton("Xoá hồ sơ")
        self.btn_delete.setProperty("variant", "danger")
        self.btn_delete.clicked.connect(self.on_delete_profile)
        actions_layout.addWidget(self.btn_delete)

        cookie_row = QHBoxLayout()
        cookie_row.setSpacing(10)
        self.btn_import_cookies = QPushButton("🍪 Nhập cookies…")
        self.btn_import_cookies.setToolTip(
            "Nhập file cookies có sẵn (JSON hoặc cookies.txt) — nhập xong "
            "app TỰ đăng nhập bằng cookies đó và báo kết quả ngay tại đây"
        )
        self.btn_import_cookies.clicked.connect(self.on_import_cookies)
        self.btn_apply_cookies = QPushButton("Nạp cookies")
        self.btn_apply_cookies.setToolTip("Nạp cookies đã lưu vào Chrome của hồ sơ này")
        self.btn_apply_cookies.clicked.connect(self.on_apply_cookies)
        cookie_row.addWidget(self.btn_import_cookies, 1)
        cookie_row.addWidget(self.btn_apply_cookies, 1)
        actions_layout.addLayout(cookie_row)
        actions_box.setVisible(False)
        self._profile_actions_box = actions_box
        layout.addWidget(actions_box)

        # V5.3 (A6): nhãn gợi ý "chuột phải vào thẻ…" đã BỎ — gợi ý
        # chuyển vào tooltip của vùng thẻ; nút ⋯ trên từng thẻ vẫn
        # mở đúng menu đó.

        # Cookies đăng nhập của hồ sơ đang chọn (V3.2): trạng thái kho.
        self.cookie_status = QLabel("🍪 Cookies: —")
        self.cookie_status.setObjectName("Muted")
        self.cookie_status.setWordWrap(True)
        layout.addWidget(self.cookie_status)
        # Muse phụ trách hồ sơ này (V3.3) — phân công ở mục Tài khoản Muse.
        self.agent_owner_label = QLabel("🤖 Muse phụ trách: —")
        self.agent_owner_label.setObjectName("Muted")
        self.agent_owner_label.setWordWrap(True)
        layout.addWidget(self.agent_owner_label)
        return panel

    # ------------------------------------------------------------------ #
    # Panel trình duyệt: MỘT thanh công cụ gọn + khung xem 3 tab
    # ------------------------------------------------------------------ #
    def _build_live_panel(self) -> QFrame:
        card = QFrame()
        card.setObjectName("Card")
        layout = QVBoxLayout(card)
        layout.setContentsMargins(14, 12, 14, 14)
        layout.setSpacing(10)
        layout.addLayout(self._build_browser_toolbar())

        self.live_label = LiveViewLabel()
        self.live_label.setWordWrap(True)
        self.live_label.mouse_clicked.connect(self._on_live_click)
        self.live_label.mouse_wheeled.connect(self._on_live_wheel)
        self.live_label.key_event.connect(self._on_live_key)
        self.dock_container = DockContainer()
        self.dock_container.resized.connect(self._on_dock_resized)
        # V5.2 (chỉ-nhúng): khung giữ chỗ LỖI NHÚNG ngay trong khung
        # nhúng — khi gắn cửa sổ Chrome vào app thất bại, người dùng
        # thấy lý do + nút "Nhúng lại" TẠI ĐÂY, và cửa sổ Chrome
        # được đỗ khuất chứ không nổi ra ngoài app (xem _try_dock).
        self.dock_placeholder = QFrame(self.dock_container)
        self.dock_placeholder.setObjectName("Panel")
        dock_ph_layout = QVBoxLayout(self.dock_placeholder)
        dock_ph_layout.setContentsMargins(24, 24, 24, 24)
        dock_ph_layout.setSpacing(10)
        self.dock_placeholder_label = QLabel("")
        self.dock_placeholder_label.setObjectName("Muted")
        self.dock_placeholder_label.setWordWrap(True)
        self.dock_placeholder_label.setAlignment(Qt.AlignCenter)
        dock_ph_layout.addWidget(self.dock_placeholder_label)
        self.btn_dock_retry = QPushButton("Nhúng lại")
        self.btn_dock_retry.setProperty("variant", "primary")
        self.btn_dock_retry.clicked.connect(self._dock_manual)
        dock_ph_layout.addWidget(
            self.btn_dock_retry, 0, Qt.AlignmentFlag.AlignHCenter
        )
        self.dock_placeholder.hide()
        self.still_label = QLabel()
        self.still_label.setAlignment(Qt.AlignCenter)
        self.still_label.setStyleSheet(
            f"background:{theme.BG}; color:{theme.MUTED};"
            f" border:1px solid {theme.BORDER}; border-radius:10px;"
        )
        self.still_label.setMinimumHeight(300)
        self.live_tabs = QTabWidget()
        self.live_tabs.addTab(self.dock_container, "Trình duyệt nhúng")
        self.live_tabs.addTab(self.live_label, "Luồng trực tiếp")
        self.live_tabs.addTab(self.still_label, "Ảnh chụp")
        # Mặc định mở ở tab Nhúng khi bật tự-nhúng (V3.2) — trình duyệt
        # chạy là vào thẳng giao diện, không mở cửa sổ ngoài.
        self.live_tabs.setCurrentIndex(TAB_EMBED if self._embed_always() else TAB_STREAM)
        # Nối tín hiệu SAU khi đã chọn tab mặc định — tránh handler chạy
        # trong lúc dựng (addTab tự phát currentChanged).
        self.live_tabs.currentChanged.connect(self._on_live_tab_changed)
        # V4.5: khung giữa = stack hai lớp: khung xem ĐƠN (live_tabs)
        # và TƯỜNG TRÌNH DUYỆT NHÚNG (lưới nhiều hồ sơ). Nút 🧱 Tường
        # ở thanh công cụ chuyển qua lại; tường cũng TỰ BẬT khi ≥3
        # trình duyệt hồ sơ cùng chạy.
        # V5.3.1 (M2): tường đọc kích thước ô từ settings dùng chung.
        self.browser_wall = BrowserWall(self._store, settings=self._settings)
        if self._browsers_hidden():
            # V5.3 (A8): app mở lên với chạy ẩn đã bật từ phiên
            # trước — tường ở trạng thái ẩn ngay từ đầu.
            self.browser_wall.set_hidden_mode(True)
        self.browser_wall.page_zoom_changed.connect(self._apply_page_zoom)
        self.browser_wall.maximize_requested.connect(
            self._exit_wall_to_profile
        )
        # V7.0: DẢI "ĐANG TỰ ĐỘNG" — mỗi trình duyệt Muse đang điều khiển một
        # dòng (hồ sơ · Muse · bước i/n · thao tác); bấm để xem trình duyệt đó.
        self.automation_strip = QFrame()
        self.automation_strip.setObjectName("AutomationStrip")
        self.automation_strip.setStyleSheet(
            "QFrame#AutomationStrip { background: rgba(206,252,25,0.06); border: 1px solid #4D5F12;"
            " border-radius: 10px; }")
        self.automation_layout = QVBoxLayout(self.automation_strip)
        self.automation_layout.setContentsMargins(10, 6, 10, 6)
        self.automation_layout.setSpacing(4)
        self.automation_strip.hide()
        layout.addWidget(self.automation_strip)
        self.center_stack = QStackedWidget()
        self.center_stack.addWidget(self.live_tabs)
        self.center_stack.addWidget(self.browser_wall)
        from .live_grid import LiveGrid

        self.live_grid = LiveGrid(self._manager)
        self.live_grid.take_control.connect(self._grid_take_control)
        self.center_stack.addWidget(self.live_grid)
        self._grid_active = False
        self._grid_manual_off_count = -1
        layout.addWidget(self.center_stack, 1)
        self._show_live_placeholder(
            "Chưa chọn hồ sơ — chọn một hồ sơ ở cột trái để xem trực tiếp."
        )
        return card

    def _build_browser_toolbar(self) -> QVBoxLayout:
        strip = QHBoxLayout()
        strip.setSpacing(8)
        self.live_dot = theme.PulsingDot()
        strip.addWidget(self.live_dot)
        live_caption = QLabel("LIVE")
        live_caption.setObjectName("LiveCaption")
        strip.addWidget(live_caption)
        self.live_profile_label = QLabel("Chưa chọn hồ sơ")
        self.live_profile_label.setObjectName("CardTitle")
        # V4.5: nhãn chữ trong dải công cụ phải CO ĐƯỢC (Ignored) —
        # mặc định QLabel đòi bề rộng tối thiểu bằng đủ chữ, khiến
        # cả dải nút bị ép cắt chữ khi khung giữa hẹp (soi preview).
        self.live_profile_label.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        self.live_profile_label.setMinimumWidth(60)
        strip.addWidget(self.live_profile_label)
        self.live_gmail_label = QLabel("")
        self.live_gmail_label.setObjectName("Muted")
        self.live_gmail_label.setMaximumWidth(130)  # chừa chỗ cho nút bấm
        self.live_gmail_label.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred
        )
        self.live_gmail_label.setMinimumWidth(0)
        strip.addWidget(self.live_gmail_label)
        self.live_url = QLabel("")
        self.live_url.setObjectName("UrlLabel")
        strip.addWidget(self.live_url, 1)
        self.fps_label = QLabel("— fps")
        self.fps_label.setObjectName("FpsLabel")
        strip.addWidget(self.fps_label)

        # V4.3 (G5): điều khiển zoom trình duyệt nhúng của hồ sơ đang
        # chọn (mặc định 75%, lưu riêng từng hồ sơ; áp qua CDP
        # Emulation.setPageScaleFactor và áp lại sau mỗi điều hướng).
        strip.addWidget(QLabel("Zoom"))
        self.btn_zoom_out = QPushButton("−")
        self.btn_zoom_out.setToolTip("Giảm zoom trình duyệt nhúng (−10%)")
        self.btn_zoom_out.clicked.connect(lambda: self._on_zoom_step(-10))
        strip.addWidget(self.btn_zoom_out)
        self.zoom_label = QLabel("100%")
        self.zoom_label.setObjectName("FpsLabel")
        strip.addWidget(self.zoom_label)
        self.btn_zoom_in = QPushButton("+")
        self.btn_zoom_in.setToolTip("Tăng zoom trình duyệt nhúng (+10%)")
        self.btn_zoom_in.clicked.connect(lambda: self._on_zoom_step(10))
        strip.addWidget(self.btn_zoom_in)
        # V6.5: thanh trượt zoom TRANG cho hồ sơ đang xem (giữ khi tải lại).
        from PySide6.QtWidgets import QSlider

        self.page_zoom_single = QSlider(Qt.Orientation.Horizontal)
        self.page_zoom_single.setRange(30, 150)
        self.page_zoom_single.setValue(100)
        self.page_zoom_single.setFixedWidth(120)
        self.page_zoom_single.setToolTip("Zoom nội dung trang của hồ sơ đang xem (30–150%)")
        self._page_zoom_single_timer = QTimer(self)
        self._page_zoom_single_timer.setSingleShot(True)
        self._page_zoom_single_timer.setInterval(180)
        self._page_zoom_single_timer.timeout.connect(self._apply_strip_zoom)
        self.page_zoom_single.valueChanged.connect(self._on_strip_zoom_slider)
        strip.addWidget(self.page_zoom_single)

        # V4.5: dải công cụ TÁCH HAI HÀNG (xem cuối hàm): hàng 2
        # chứa các điều khiển luồng — tạo layout ngay từ đầu và xếp
        # thẳng widget vào đây (di chuyển widget giữa hai layout lúc
        # dựng không đáng tin, widget dễ nằm cả hai nơi).
        # V6.9: hàng 2 là FLOW (tự xuống dòng) — thêm các nút Mở trình duyệt/
        # Quét/Nhúng lại/Kiểm tra mà không bị ép cắt chữ khi khung hẹp.
        from .work_panel import FlowLayout

        strip2_host = QWidget()
        self.strip2_host = strip2_host
        strip2 = FlowLayout(strip2_host, h_spacing=8, v_spacing=6)
        strip2.setContentsMargins(0, 0, 0, 0)

        # V4.5: nút TƯỜNG TRÌNH DUYỆT — bật/tắt lưới nhúng nhiều hồ
        # sơ; tường tự bật khi ≥3 trình duyệt cùng chạy (tắt tay ở
        # đúng số đó thì không tự bật lại cho tới khi số lượng đổi).
        self.btn_wall = QPushButton("🧱 Tường")
        self.btn_wall.setCheckable(True)
        self.btn_wall.setToolTip(
            "Tường trình duyệt: xếp mọi Chrome hồ sơ đang chạy thành "
            "lưới nhúng ngay trong app (tự bật khi ≥3 trình duyệt chạy)."
        )
        self.btn_wall.clicked.connect(
            lambda checked: self._set_wall_mode(bool(checked))
        )
        strip.addWidget(self.btn_wall)
        # V7.1: LƯỚI XEM TRỰC TIẾP — trình duyệt chạy nền kích thước cố định,
        # app hiện hình chiếu (không nhúng, không che nhau); Muse điều khiển thoải mái.
        self.btn_live_grid = QPushButton("📺 Lưới trực tiếp")
        self.btn_live_grid.setCheckable(True)
        self.btn_live_grid.setToolTip(
            "Xem TẤT CẢ trình duyệt đang chạy cùng lúc bằng hình chiếu trực tiếp — không cửa sổ nào bị che, "
            "Muse thao tác không vướng. Bấm 🖐 trên một ô để tự điều khiển trình duyệt đó.")
        self.btn_live_grid.clicked.connect(lambda checked: self._set_grid_mode(bool(checked)))
        strip.addWidget(self.btn_live_grid)

        # V4.6 (10:47): ĐƠN KHUNG ĐẦY KÍCH THƯỚC — thu gọn panel dữ
        # liệu để khung trình duyệt nhúng ĐƠN chiếm trọn vùng nội
        # dung của section Hồ sơ. Đây là KÍCH THƯỚC KHUNG, khác hẳn
        # MỨC ZOOM TRANG (75% mặc định qua CDP, chỉnh ± ở thanh công
        # cụ — giữ nguyên) và khác ⛶ theater F11 (toàn màn hình cả
        # app). Tự bật khi: bấm ⛶ ở một ô tường, hoặc trình duyệt
        # DUY NHẤT được tự mở khi có việc (trừ khi người dùng đã
        # tắt tay trong phiên này).
        self.btn_full_frame = QPushButton("🗗 Đầy khung")
        self.btn_full_frame.setCheckable(True)
        self.btn_full_frame.setToolTip(
            "Đơn khung đầy kích thước: thu gọn panel dữ liệu để "
            "trình duyệt nhúng chiếm trọn vùng nội dung của mục Hồ "
            "sơ. Chỉ đổi KÍCH THƯỚC KHUNG — mức zoom trang (mặc "
            "định 75%) không đổi."
        )
        self.btn_full_frame.clicked.connect(
            lambda checked: self._on_full_frame_toggled(bool(checked))
        )
        strip.addWidget(self.btn_full_frame)

        # Chế độ xem/điều khiển luồng (chỉ hiện khi xem luồng).
        segmented = QFrame()
        segmented.setObjectName("Segmented")
        seg_layout = QHBoxLayout(segmented)
        seg_layout.setContentsMargins(2, 2, 2, 2)
        seg_layout.setSpacing(2)
        self.btn_mode_view = QPushButton("Xem")
        self.btn_mode_view.setCheckable(True)
        self.btn_mode_view.setChecked(True)
        self.btn_mode_control = QPushButton("Điều khiển")
        self.btn_mode_control.setCheckable(True)
        mode_group = QButtonGroup(self)
        mode_group.addButton(self.btn_mode_view)
        mode_group.addButton(self.btn_mode_control)
        self.btn_mode_view.clicked.connect(lambda: self._set_control_mode(False))
        self.btn_mode_control.clicked.connect(lambda: self._set_control_mode(True))
        seg_layout.addWidget(self.btn_mode_view)
        seg_layout.addWidget(self.btn_mode_control)
        self.mode_segmented = segmented
        strip2.addWidget(segmented)

        self.btn_front = QPushButton("⬆ Lên trước")
        self.btn_front.setToolTip("Đưa cửa sổ Chrome thật ra trước màn hình")
        self.btn_front.clicked.connect(self._on_bring_front)
        strip2.addWidget(self.btn_front)

        self.btn_dock_toggle = QPushButton("Nhúng")
        self.btn_dock_toggle.setToolTip(
            "Nhúng cửa sổ Chrome THẬT vào trong app (Win32, chỉ Windows). "
            "Không nhúng được thì app tự dùng Luồng trực tiếp."
        )
        self.btn_dock_toggle.clicked.connect(self._on_dock_toggle)
        strip.addWidget(self.btn_dock_toggle)

        self.btn_save_shot = QPushButton("Lưu ảnh")
        self.btn_save_shot.setToolTip("Lưu khung hình hiện tại vào data/screenshots/")
        self.btn_save_shot.clicked.connect(self._on_save_screenshot)
        strip2.addWidget(self.btn_save_shot)

        # V3.7: tuỳ chọn ẨN trình duyệt ngoài khung nhúng — cửa sổ Chrome
        # không đang nhúng sẽ được đưa RA NGOÀI phạm vi màn hình (vẫn chạy
        # nền) thay vì hiện trên desktop. Checkbox trực tiếp ngay tại đây.
        self.chk_offscreen = QCheckBox("🙈 Ngoài MH")
        self.chk_offscreen.setToolTip(
            "Khi bật: cửa sổ Chrome của hồ sơ KHÔNG đang xem sẽ chạy ngoài "
            "phạm vi màn hình (không hiện trên desktop). Khi tắt: cửa sổ đó "
            "được thu nhỏ xuống thanh taskbar như bình thường. Trình duyệt "
            "đang nhúng trong app không bị ảnh hưởng."
        )
        self.chk_offscreen.setChecked(
            bool(self._settings.get("ui_browser_offscreen", True))
        )
        self.chk_offscreen.toggled.connect(self._on_offscreen_toggled)
        strip2.addWidget(self.chk_offscreen)

        # V5.3 (A8): CHẠY ẨN NGOÀI APP — ngoại lệ do chủ kênh trực
        # tiếp ra lệnh cho quy tắc chỉ-nhúng. Bật: trình duyệt mở
        # dạng cửa sổ riêng/thu nhỏ, app KHÔNG nhúng (khung nhúng
        # + tường hiện trạng thái đang chạy ẩn), CDP nguyên vẹn.
        # Cùng setting với ô tick trong Hệ thống → Cài đặt.
        self.chk_hidden_mode = QCheckBox("🏃 Chạy ẩn")
        self.chk_hidden_mode.setToolTip(
            "Chạy ẩn ngoài app: trình duyệt mở ở cửa sổ riêng/thu "
            "nhỏ, app không nhúng vào khung xem/tường trình duyệt "
            "(đổi tốc độ + các Muse không tranh khung nhúng). "
            "Điều khiển qua CDP vẫn nguyên vẹn. Tắt: nhúng vào "
            "app như mặc định."
        )
        self.chk_hidden_mode.setChecked(self._browsers_hidden())
        self.chk_hidden_mode.toggled.connect(self._apply_hidden_mode)
        strip2.addWidget(self.chk_hidden_mode)

        # V6.9: các thao tác của menu "⋯" đưa RA NGOÀI thành nút, cùng hàng
        # điều khiển — bấm là thấy ngay, có trạng thái đang xử lý.
        self.btn_open_browser = QPushButton("🌐 Mở trình duyệt")
        self.btn_open_browser.setToolTip("Mở Chrome của hồ sơ đang chọn và nhúng vào app")
        self.btn_open_browser.clicked.connect(self.on_open_browser)
        strip2.addWidget(self.btn_open_browser)
        self.btn_scan_profile = QPushButton("🔄 Quét hồ sơ")
        self.btn_scan_profile.setToolTip("Quét danh sách kênh của hồ sơ đang chọn")
        self.btn_scan_profile.clicked.connect(self.on_scan)
        strip2.addWidget(self.btn_scan_profile)
        self.btn_redock = QPushButton("🔗 Nhúng lại")
        self.btn_redock.setToolTip("Tìm lại cửa sổ Chrome của hồ sơ và nhúng vào khung")
        self.btn_redock.clicked.connect(self._dock_manual)
        strip2.addWidget(self.btn_redock)
        self.btn_check_profile = QPushButton("🩺 Kiểm tra hồ sơ")
        self.btn_check_profile.setToolTip("Mở kiểm tra sức khoẻ hồ sơ/kênh đang chọn")
        self.btn_check_profile.clicked.connect(self._goto_checks)
        strip2.addWidget(self.btn_check_profile)
        # V7.0: đăng nhập Facebook/TikTok (và cả YouTube) bằng cookie dán vào
        self.btn_cookie_login = QPushButton("🍪 Đăng nhập bằng cookie")
        self.btn_cookie_login.setToolTip("Dán cookie Facebook / TikTok / YouTube cho hồ sơ đang chọn → đăng nhập + quét page/kênh")
        self.btn_cookie_login.clicked.connect(lambda: self._open_cookie_login_dialog())
        strip2.addWidget(self.btn_cookie_login)
        # V6.9: trạng thái CHẠY ẨN hiện rõ ngay trên thanh (không phải bấm cho vui)
        self.hidden_status = QLabel("")
        self.hidden_status.setObjectName("HiddenStatus")
        self.hidden_status.setStyleSheet(
            "QLabel#HiddenStatus { color:#F2C94C; border:1px solid #F2C94C; border-radius:10px; padding:2px 10px; }")
        self.hidden_status.setVisible(False)
        strip2.addWidget(self.hidden_status)
        # V4.5: ghép hai hàng — hàng 1 (strip): trạng thái + zoom +
        # Tường + Nhúng + ⋯; hàng 2 (strip2): điều khiển luồng.
        # Một hàng duy nhất cần tối thiểu ~1.150px, khung giữa
        # không đủ ở cửa sổ 1600px nên nút bị ép cắt chữ (đã đo).
        column = QVBoxLayout()
        column.setSpacing(6)
        column.addLayout(strip)
        column.addWidget(strip2_host)
        return column

    # ------------------------------------------------------------------ #
    # Dock dưới: tab Kênh | Nhật ký | Hàng đợi lệnh, thu/mở bằng chevron
    # ------------------------------------------------------------------ #
    def _build_bottom_dock(self) -> QFrame:
        # Từ V3.4 widget này là panel dữ liệu ở cột PHẢI (giữ tên hàm cũ
        # vì nhiều nơi tham chiếu dock_tabs/btn_dock_chevron).
        frame = QFrame()
        frame.setObjectName("Card")
        frame.setMinimumWidth(340)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 8, 12, 10)
        layout.setSpacing(6)

        header = QFrame()
        header.setObjectName("DockHeader")
        header.setFixedHeight(28)
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(8)
        dock_title = QLabel("DỮ LIỆU HỒ SƠ")
        dock_title.setObjectName("SectionHeader")
        header_layout.addWidget(dock_title)
        header_layout.addStretch(1)
        self.btn_dock_chevron = QPushButton("▾ Thu gọn")
        self.btn_dock_chevron.setObjectName("ChevronButton")
        self.btn_dock_chevron.clicked.connect(self._toggle_dock)
        header_layout.addWidget(self.btn_dock_chevron)
        layout.addWidget(header)

        self.dock_tabs = QTabWidget()
        # Tab Kênh: bảng hoặc trạng thái rỗng một dòng.
        self.channel_stack = QStackedWidget()
        self.table = self._build_channel_table()
        self.channel_stack.addWidget(self.table)
        empty = QLabel(
            "Hồ sơ này chưa có kênh nào — bấm “Quét kênh” để đồng bộ danh sách kênh."
        )
        empty.setObjectName("EmptyState")
        self.channel_stack.addWidget(empty)
        self.dock_tabs.addTab(self.channel_stack, "Kênh")

        self.journal_view = QPlainTextEdit()
        self.journal_view.setObjectName("Journal")
        self.journal_view.setReadOnly(True)
        self.journal_view.setMaximumBlockCount(2000)
        self.dock_tabs.addTab(self.journal_view, "Nhật ký")

        self.queue_table = QTableWidget(0, 4)
        self.queue_table.setHorizontalHeaderLabels(
            ["Lệnh", "Hồ sơ", "Trạng thái", "Tạo lúc"]
        )
        self.queue_table.setEditTriggers(QTableWidget.NoEditTriggers)
        # V4.3.2 (F7): mọi cột kéo chỉnh tự do + tự lưu bề rộng.
        from . import table_persist

        table_persist.attach_column_persistence(
            self.queue_table, self._settings, "queue_table",
            default_widths=(300, 160, 130, 150),
        )
        self.queue_table.setShowGrid(False)
        self.queue_table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng gọn theo chuẩn chung (chỉ chữ).
        self.queue_table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.queue_table.font())
        )
        self.dock_tabs.addTab(self.queue_table, "Hàng đợi lệnh")
        self.dock_tabs.setCurrentIndex(
            int(self._settings.get("ui_dock_tab", 0) or 0)
        )
        self.dock_tabs.currentChanged.connect(self._on_dock_tab_changed)
        layout.addWidget(self.dock_tabs)
        return frame

    def _build_channel_table(self) -> QTableWidget:
        table = QTableWidget(0, 7)
        table.setHorizontalHeaderLabels(
            ["", "Tên kênh", "Handle", "Subs", "Video", "Chủ đề", "Lần quét cuối"]
        )
        table.horizontalHeader().setStretchLastSection(True)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setAlternatingRowColors(True)
        table.setShowGrid(False)
        table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng gọn — vẫn đủ cho icon avatar kênh 28px.
        table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(table.font(), min_content=28)
        )
        table.setIconSize(QSize(28, 28))
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Fixed)
        # V4.3.2 (F7): mọi cột nội dung kéo chỉnh tự do + tự lưu bề
        # rộng theo bảng; cột 0 (avatar kênh 38px) giữ Fixed — ngoại
        # lệ cố định duy nhất của bảng này.
        from . import table_persist

        table_persist.attach_column_persistence(
            table, self._settings, "channels_table", fixed_columns=(0,),
            default_widths=(38, 210, 110, 80, 70, 90, 130),
        )
        table.setWordWrap(True)
        # V3.7: chuột phải trên dòng kênh — mở kênh/Studio, quét lại.
        table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        table.customContextMenuRequested.connect(self._on_channel_table_menu)
        return table

    def _on_channel_table_menu(self, pos):
        table = self.table
        row = table.rowAt(pos.y())
        if row < 0:
            return
        table.selectRow(row)
        item = table.item(row, 0)
        channel_id = item.data(Qt.ItemDataRole.UserRole) if item else None
        handle_item = table.item(row, 2)
        handle = handle_item.text().strip() if handle_item else ""
        if handle and not handle.startswith("@"):
            handle = "@" + handle
        menu = QMenu(self)
        if handle and handle != "@—":
            act = menu.addAction("🌐 Mở kênh trên YouTube")
            act.triggered.connect(
                lambda _=False, h=handle: QDesktopServices.openUrl(
                    QUrl(f"https://www.youtube.com/{h}")
                )
            )
        if channel_id:
            act = menu.addAction("🎬 Mở kênh trong YouTube Studio")
            act.triggered.connect(
                lambda _=False, cid=channel_id: QDesktopServices.openUrl(
                    QUrl(f"https://studio.youtube.com/channel/{cid}/videos")
                )
            )
        menu.addSeparator()
        act = menu.addAction("🔍 Quét lại hồ sơ này")
        act.triggered.connect(lambda _=False: self.btn_scan.click())
        menu.exec(table.viewport().mapToGlobal(pos))

    def _on_dock_tab_changed(self, index: int):
        self._settings["ui_dock_tab"] = index
        config.save_settings(self._settings)
        if index == 2:
            self._refresh_queue_tab()

    def _set_dock_expanded(self, expanded: bool):
        # V3.4: "dock" giờ là panel dữ liệu ở CỘT PHẢI — expanded = hiện
        # panel, ngược lại ẩn hẳn (mở lại bằng nút "🗂 Panel dữ liệu"
        # trên thanh tiêu đề hoặc nút trong panel).
        self._dock_expanded = expanded
        if hasattr(self, "dock_tabs"):
            self.dock_tabs.setVisible(expanded)
            self.dock_tabs.parentWidget().setVisible(expanded)
            self.btn_dock_chevron.setText("✕ Ẩn panel" if expanded else "🗂 Hiện panel")

    def _toggle_dock(self):
        expanded = not getattr(self, "_dock_expanded", True)
        self._settings["ui_dock_expanded"] = expanded
        config.save_settings(self._settings)
        self._set_dock_expanded(expanded)

    def _apply_first_run_dock(self):
        """Lần chạy đầu tiên: chưa có kênh nào trong kho thì dock dưới tự
        thu gọn (chẳng có gì để xem) — trình duyệt được trọn chiều cao."""
        if self._settings.get("ui_first_run_done"):
            return
        self._settings["ui_first_run_done"] = True
        try:
            total_channels = self._store.stats()["channels"]
        except Exception:
            total_channels = 1
        if total_channels == 0:
            self._settings["ui_dock_expanded"] = False
            self._set_dock_expanded(False)
        config.save_settings(self._settings)

    def _refresh_queue_tab(self):
        if not hasattr(self, "queue_table"):
            return
        try:
            commands = [
                c
                for c in self._store.list_commands(limit=60)
                if c["status"] in ("queued", "running", "waiting_muse")
            ]
        except Exception:
            commands = []
        from .commands_panel import STATUS_LABELS
        from .table_persist import batch_update

        # V4.3.2 (F4): nạp hàng loạt tắt repaint/signals của bảng.
        with batch_update(self.queue_table):
            self.queue_table.setRowCount(len(commands))
            for row, command in enumerate(commands):
                from ..store import COMMAND_TYPE_LABELS

                values = [
                    COMMAND_TYPE_LABELS.get(command["type"], command["type"]),
                    command["profile_slug"] or "—",
                    STATUS_LABELS.get(command["status"], command["status"]),
                    _fmt_ts(command["created_at"]),
                ]
                for col, value in enumerate(values):
                    self.queue_table.setItem(row, col, QTableWidgetItem(value))

    # ------------------------------------------------------------------ #
    # Chế độ toàn màn hình trình duyệt (theater)
    # ------------------------------------------------------------------ #
    def _toggle_theater(self):
        if self._theater:
            self._exit_theater()
        else:
            self.enter_theater()

    def enter_theater(self):
        if self._theater:
            return
        if self.sections.currentIndex() != SEC_PROFILES:
            self._switch_section(SEC_PROFILES)
        # Lưu trạng thái ẩn HIỂN THỊ tường minh (isHidden) — không dùng
        # isVisible() vì cửa sổ chưa show thì mọi widget đều "không visible".
        self._theater_saved = {
            "rail": not self.nav_rail.isHidden(),
            "column": not self.profile_column.isHidden(),
            "dock": getattr(self, "_dock_expanded", True),
            "title": not self.title_bar.isHidden(),
        }
        self._theater = True
        self.nav_rail.hide()
        self.profile_column.hide()
        self.title_bar.hide()
        self.dock_tabs.parentWidget().hide()
        profile = self._selected_profile()
        name = profile["label"] if profile else "Chưa chọn hồ sơ"
        self.theater_label.setText(f"⛶ Toàn màn hình trình duyệt — {name}")
        self.theater_bar.show()
        self.showFullScreen()

    def _exit_theater(self):
        if not self._theater:
            return
        self._theater = False
        saved = self._theater_saved or {}
        self.nav_rail.setVisible(saved.get("rail", True))
        self.profile_column.setVisible(saved.get("column", True))
        self.title_bar.setVisible(saved.get("title", True))
        self.dock_tabs.parentWidget().show()
        self._set_dock_expanded(saved.get("dock", True))
        self.theater_bar.hide()
        self.showNormal()

    # ------------------------------------------------------------------ #
    # V3.9 — Lớp vận chuyển Tailscale: tự kiểm tra + tự nối lại
    # ------------------------------------------------------------------ #
    def _spawn_ts_worker(self, fn, on_done):
        """Chạy việc Tailscale trên luồng nền theo đúng bài học V3.1:
        worker có chủ (parent=self), chỉ thả tham chiếu sau khi thread
        đã finished thật (reaper), không bao giờ huỷ giữa chừng."""
        worker = FuncWorker(fn, parent=self)
        self._ts_workers.append(worker)
        worker.done.connect(on_done)
        worker.failed.connect(
            lambda err: self._log_ui(f"[Tailscale] Việc nền lỗi: {err}")
        )

        def _reap(w=worker):
            if w in self._ts_workers:
                self._ts_workers.remove(w)
            w.deleteLater()

        worker.finished.connect(_reap)
        worker.start()
        return worker

    def _check_tailscale(self):
        """Đọc trạng thái Tailscale thật trên máy này (nền)."""
        if self._ts_busy:
            return
        self._ts_busy = True

        def _job():
            return tailscale_helper.run_status(tailscale_helper.find_tailscale())

        def _done(state):
            self._ts_busy = False
            self._apply_tailscale_state(state)

        self._spawn_ts_worker(_job, _done)

    def _apply_tailscale_state(self, state: dict):
        self._ts_state = state
        level = tailscale_helper.classify(state)
        if level != self._ts_level:
            previous, self._ts_level = self._ts_level, level
            if previous:  # lần đầu chỉ ghi nhận, tránh ồn khi vừa mở app
                self._log_ui(f"[Tailscale] {self._tailscale_line()}")
        try:
            self.commands_panel.set_tailscale_state(state)
        except Exception:
            pass
        self._refresh_status_bar()
        # Tự nối lại đúng MỘT lần cho mỗi đợt mất nối: chỉ khi máy ĐÃ
        # đăng nhập sẵn (down) — needs_login phải do người dùng bấm,
        # app không tự bật trình duyệt khi chưa được yêu cầu.
        # V6.4.2: KHÔNG chỉ thử một lần — còn "down" thì thử lại theo
        # nhịp giãn dần 1 → 2 → 5 → 10 phút (bản cũ thử 1 lần, hỏng là
        # đứng yên tới khi người dùng tự bấm).
        if level == "ok":
            self._ts_auto_up_armed = True
            self._ts_retry_step = 0
            self._ts_next_retry = 0.0
        elif (
            level == "down"
            and self._settings.get("ts_auto_connect", True)
            and (self._ts_auto_up_armed or time.monotonic() >= getattr(self, "_ts_next_retry", 0.0))
        ):
            self._ts_auto_up_armed = False
            step = getattr(self, "_ts_retry_step", 0)
            self._ts_next_retry = time.monotonic() + (60, 120, 300, 600)[min(step, 3)]
            self._ts_retry_step = step + 1
            self._log_ui(
                "[Tailscale] Đã đăng nhập mà chưa kết nối — app tự chạy "
                "“tailscale up” để nối lại…"
            )
            self._connect_tailscale_now(auto=True)

    def _tailscale_line(self) -> str:
        """Một dòng trạng thái Tailscale ngắn cho nhật ký/thanh trạng thái."""
        state = self._ts_state
        if state is None:
            return "Tailscale: đang kiểm tra…"
        level = tailscale_helper.classify(state)
        if level == "missing":
            return "Tailscale: chưa cài trên máy này"
        if level == "needs_login":
            return "Tailscale: chưa đăng nhập tài khoản"
        if level == "down":
            return "Tailscale: đã đăng nhập, chưa kết nối"
        if level == "error":
            return f"Tailscale: lỗi đọc trạng thái ({state.get('error') or '?'})"
        ip = state.get("self_ip") or "—"
        if level == "no_muse":
            return f"Tailscale: đã nối ({ip}) · chưa thấy muse trực tuyến"
        return f"Tailscale: đã nối ({ip}) · muse trực tuyến"

    def _connect_tailscale_now(self, auto: bool = False):
        """Chạy "tailscale up" (nền). Cần đăng nhập → mở link CLI in ra
        trong trình duyệt mặc định để người dùng đăng nhập/duyệt một lần."""
        if self._ts_up_busy:
            return
        exe = tailscale_helper.find_tailscale()
        if not exe:
            if not auto:
                self._log_ui(
                    "[Tailscale] Chưa cài Tailscale trên máy này — cài "
                    "từ tailscale.com rồi mở lại app."
                )
            return
        self._ts_up_busy = True

        def _done(result):
            self._ts_up_busy = False
            if result.get("auth_url"):
                from PySide6.QtGui import QDesktopServices

                QDesktopServices.openUrl(QUrl(result["auth_url"]))
                self._log_ui(
                    "[Tailscale] Cần đăng nhập/duyệt thiết bị: đã mở "
                    "trang Tailscale trong trình duyệt."
                )
            elif result.get("ok"):
                self._log_ui("[Tailscale] Đã nối lại (tailscale up xong).")
            else:
                self._log_ui(
                    "[Tailscale] tailscale up chưa xong: "
                    f"{(result.get('output') or '')[:160]}"
                )
            QTimer.singleShot(1500, self._check_tailscale)

        self._spawn_ts_worker(lambda: tailscale_helper.run_up(exe), _done)

    def _open_firewall_port(self):
        """Mở cổng Agent API trong Windows Firewall qua UAC (người
        dùng tự bấm Yes) — dùng khi Tailscale đã thông mà Muse vẫn
        không gọi vào được (adapter Tailscale hay bị xếp Public)."""
        port = int(self._settings.get("agent_port", 19500))
        if firewall_helper.run_add_rule(port):
            self._log_ui(
                f"[Tường lửa] Đã yêu cầu mở cổng {port} (chờ UAC) — rule "
                f"“{firewall_helper.RULE_NAME}”."
            )
        else:
            self._log_ui(
                "[Tường lửa] Không mở được hộp thoại UAC trên máy này "
                "— mở cổng thủ công hoặc chạy app bằng quyền quản trị "
                "rồi thử lại."
            )

    def _show_bridge_help(self):
        """Hộp thoại KẾT NỐI CLAUDE (V3.8): một chỗ duy nhất nói rõ trạng
        thái cầu nối thật + 3 bước để Muse nghe được lệnh. Nguyên nhân
        gốc của lỗi 'ra lệnh mà Muse không chạy' là cầu nối chưa từng
        được nối (mạng Tailscale + phiếu kết nối) trong khi app im lặng
        — hộp thoại này + banner/guard ở tab Lệnh bịt lỗ hổng đó."""
        from PySide6.QtWidgets import QDialog, QDialogButtonBox

        state = self._store.bridge_state()
        if state["connected"]:
            state_line = "✅ Hiện tại: Muse ĐANG kết nối — lệnh sẽ được nhận."
        elif state["ever"]:
            state_line = (
                "⚠ Hiện tại: Muse TỪNG kết nối nhưng đang mất kết nối "
                f"(hoạt động cuối: {state['last_poll_at'] or '—'})."
            )
        else:
            state_line = (
                "❌ Hiện tại: CHƯA TỪNG có Muse nào kết nối tới app này — "
                "mọi lệnh của Muse đều đang chờ vô thời hạn."
            )
        port = self._settings.get("agent_port", 19500)
        dialog = QDialog(self)
        dialog.setWindowTitle("🔌 Kết nối Muse vào cầu nối")
        dialog.resize(640, 560)
        layout = QVBoxLayout(dialog)
        body = QLabel(
            f"{state_line}\n\n"
            "App này nghe lệnh tại cổng "
            f"{port} (Agent API). Lệnh app tự chạy (Mở trình duyệt / Quét "
            "kênh / Kiểm tra) chạy ngay trong app; riêng lệnh của Muse "
            "chỉ chạy khi một tài khoản Muse THẬT SỰ kết nối vào cầu nối "
            "và đến nhận lệnh. Muốn vậy cần đủ 3 bước:\n\n"
            "1️⃣ Chung một mạng riêng (Tailscale): app TỰ kiểm tra lớp "
            "này mỗi 30 giây và tự nối lại khi máy đã đăng nhập sẵn — xem "
            "dòng trạng thái + các nút ngay dưới đây. Tài khoản Tailscale "
            "trên máy này phải CÙNG tài khoản với phía Muse và thiết bị "
            "“muse” phải được duyệt trong trang quản trị Tailscale.\n\n"
            "2️⃣ Windows Firewall: nếu Tailscale đã thông mà Muse vẫn "
            "không gọi vào được, bấm nút “Mở cổng trong tường lửa” dưới "
            "đây (Windows sẽ hỏi quyền quản trị — bấm Yes).\n\n"
            "3️⃣ Gửi PHIẾU KẾT NỐI cho Muse: vào tab 🤖 Tài khoản Muse → "
            "chọn đúng Muse phụ trách hồ sơ → bấm 📄 Xuất phiếu kết nối "
            "→ gửi file phiếu đó cho Muse trong cuộc trò chuyện. Muse "
            "dùng phiếu (địa chỉ máy này + token riêng) để nhận lệnh, làm "
            "trong trình duyệt nhúng và báo % tiến độ về đây.\n\n"
            "Xong 3 bước, banner ở đầu tab Lệnh chuyển xanh “ĐANG KẾT "
            "NỐI” và lệnh “Chờ Muse” sẽ tự chuyển “Đang chạy” khi Muse "
            "nhận. Token chung của cầu nối nằm trong data/settings.json "
            "(khoá agent_token) — chỉ gửi cho Muse qua phiếu kết nối, "
            "không đăng công khai."
        )
        body.setWordWrap(True)
        layout.addWidget(body)

        # V3.9: trạng thái lớp vận chuyển + nút hành động NGAY trong hộp
        # thoại — người dùng không phải mò Settings/Tailscale bên ngoài.
        ts_label = QLabel(f"🌐 {self._tailscale_line()}")
        ts_label.setWordWrap(True)
        ts_label.setStyleSheet("font-weight:600;")
        layout.addWidget(ts_label)
        ts_row = QHBoxLayout()
        recheck_btn = QPushButton("🔄 Kiểm tra lại")
        connect_btn = QPushButton("🔌 Kết nối Tailscale ngay")
        firewall_btn = QPushButton(f"🧱 Mở cổng {port} trong tường lửa")

        def _refresh_ts_label():
            ts_label.setText(f"🌐 {self._tailscale_line()}")

        def _recheck():
            self._check_tailscale()
            QTimer.singleShot(1600, _refresh_ts_label)

        def _connect():
            self._connect_tailscale_now()
            QTimer.singleShot(2500, _refresh_ts_label)

        recheck_btn.clicked.connect(_recheck)
        connect_btn.clicked.connect(_connect)
        firewall_btn.clicked.connect(self._open_firewall_port)
        ts_row.addWidget(recheck_btn)
        ts_row.addWidget(connect_btn)
        ts_row.addWidget(firewall_btn)
        layout.addLayout(ts_row)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        layout.addWidget(buttons)
        dialog.exec()

    def _open_profile_page(self, profile_id: int):
        """Mở trang Hồ sơ và chọn đúng hồ sơ (mail) — theo dõi thao tác
        ngay trong trình duyệt nhúng của hồ sơ đó."""
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        if self._current_profile_id != profile_id:
            self._current_profile_id = profile_id
            self._update_card_selection()
            self._refresh_right_pane(profile_id)
            self._restart_live_worker(profile)
        if self.sections.currentIndex() != SEC_PROFILES:
            self._switch_section(SEC_PROFILES)

    def _request_dispatch_now(self):
        """V4.1.1: chuyển yêu cầu "dispatcher xét ngay" của nút Chạy
        ngay tới AgentServer ĐANG chạy (đọc thuộc tính tại lúc gọi —
        cầu nối khởi động lại thì vẫn trúng bản mới). Cầu nối tắt thì
        thôi: lệnh vẫn được dispatcher xét ở nhịp thường khi cầu nối
        mở lại, không báo lỗi giả.
        V4.2 (O-06): lỗi khi gọi thì GHI LOG UI — không nuốt lặng."""
        server = self._agent_server
        if server is not None:
            try:
                server.request_dispatch_now()
            except Exception as exc:
                self._log_ui(f"⚠ Không gọi được điều phối ngay: {exc}")

    def _run_now_dispatch(self, command_id: str):
        """▶ Chạy ngay từ tab Lệnh (V3.7):
        - Lệnh app tự chạy (queued, loại local): runner chạy ngay VÀ
          chuyển sang trang Hồ sơ của mail đích để xem thao tác trong
          trình duyệt nhúng (giữ hành vi cũ).
        - Lệnh của Muse (queued/waiting_muse): V4.2 (O-21) — KHÔNG
          ép chuyển tab nữa. Bản cũ giật người dùng sang tab Hồ sơ
          mỗi lần bấm Chạy ngay cho lệnh Muse trong khi việc họ
          đang làm là quản lý hàng đợi ở tab Lệnh. Nay: runner ép
          dispatcher xét ngay (run_now đã tự lo) + một ghi chú
          KHÔNG-modal (chỉ nhật ký — toast đã bỏ ở V5.3) nói lệnh sẽ do Muse nào làm;
          muốn xem trình duyệt thì tự mở trang Hồ sơ."""
        command = self._store.get_command(command_id)
        if command is None:
            return
        is_claude = command["type"] in CLAUDE_COMMAND_TYPES
        if command["status"] == "queued":
            self._runner.run_now(command_id)
        profile_id = command.get("profile_id")
        if profile_id and not is_claude:
            self._open_profile_page(profile_id)
        if is_claude and command["status"] in ("queued", "waiting_muse"):
            owner = (
                self._store.get_agent(command["agent_id"])
                if command.get("agent_id")
                else None
            )
            # V3.9.1: lệnh tạo trước khi hồ sơ có người phụ trách thì
            # agent_id trống — tra chủ THEO HỒ SƠ (id, rồi tới slug bền)
            # thay vì báo "chưa phân công" oan khi hồ sơ đã có chủ.
            if owner is None and command.get("profile_id"):
                owner = self._store.agent_for_profile(command["profile_id"])
            if owner is None and command.get("profile_slug"):
                for prof in self._store.list_profiles():
                    if prof["slug"] == command["profile_slug"]:
                        owner = self._store.agent_for_profile(prof["id"])
                        break
            owner_text = (
                f"🤖 {owner['name']} ({owner['email']})" if owner
                else "Muse phụ trách hồ sơ (chưa phân công — vào tab Tài khoản Muse)"
            )
            message = (
                f"Lệnh #{command_id} là lệnh của Muse, thực hiện bởi {owner_text} "
                "qua cầu nối, ngay trong trình duyệt nhúng của hồ sơ này. "
                "“Chờ Muse” = đang xếp hàng chờ Muse đó nhận việc; khi nhận, "
                "trạng thái tự chuyển “Đang chạy” kèm % tiến độ — theo dõi ở "
                "tab 🧭 Tiến độ hoặc ngay tại danh sách lệnh này. (V4.2: "
                "bấm Chạy ngay cho lệnh Muse không còn tự chuyển sang "
                "tab Hồ sơ — muốn xem trình duyệt thì mở trang Hồ sơ "
                "của mail đích.)"
            )
            self._store.append_journal(message, profile_id)
            self._log_ui(message)

    def _on_offscreen_toggled(self, checked: bool):
        self._settings["ui_browser_offscreen"] = bool(checked)
        try:
            from .. import config

            config.save_settings(self._settings)
        except Exception:
            pass
        self._log_ui(
            "Tuỳ chọn trình duyệt ngoài khung: "
            + (
                "BẬT — cửa sổ không nhúng sẽ chạy ngoài phạm vi màn hình."
                if checked
                else "TẮT — cửa sổ không nhúng sẽ thu nhỏ xuống taskbar."
            )
        )

    # ------------------------------------------------------------------ #
    # V5.3 (A8) — Chế độ CHẠY ẨN NGOÀI APP (ngoại lệ do chủ kênh
    # trực tiếp ra lệnh cho quy tắc chỉ-nhúng V5.2)
    # ------------------------------------------------------------------ #
    def _browsers_hidden(self) -> bool:
        """Đang bật chế độ chạy ẩn ngoài app hay không (setting
        browsers_hidden_mode, mặc định TẮT)."""
        return bool(self._settings.get("browsers_hidden_mode", False))

    def _apply_hidden_mode(self, enabled: bool, announce: bool = True):
        """Áp chế độ chạy ẩn: lưu setting bền + hệ quả NGAY —
        bật thì gỡ mọi nhúng (khung đơn + ô tường), tường/khung
        chuyển sang trạng thái 'đang chạy ẩn', các đường tự-nhúng
        và watchdog tự chặn ở đầu hàm; tắt thì nhịp tự-nhúng
        600ms tự đưa cửa sổ đang chạy về app như mặc định."""
        enabled = bool(enabled)
        changed = self._browsers_hidden() != enabled
        self._settings["browsers_hidden_mode"] = enabled
        try:
            from .. import config

            config.save_settings(self._settings)
        except Exception:
            pass
        try:
            self._manager.launch_minimized_default = enabled
        except Exception:
            pass
        chk = getattr(self, "chk_hidden_mode", None)
        if chk is not None and chk.isChecked() != enabled:
            chk.blockSignals(True)
            chk.setChecked(enabled)
            chk.blockSignals(False)
        wall = getattr(self, "browser_wall", None)
        if wall is not None:
            wall.set_hidden_mode(enabled)
        if enabled:
            if getattr(self, "_dock", None) is not None and self._dock.is_docked():
                self._undock()
            if changed or announce:
                self._log_ui(
                    "Đã BẬT chạy ẩn ngoài app — trình duyệt chạy ở cửa "
                    "sổ riêng/thu nhỏ, app KHÔNG nhúng (điều khiển "
                    "qua CDP vẫn nguyên vẹn)."
                )
            if (
                hasattr(self, "live_tabs")
                and self.live_tabs.currentIndex() == TAB_EMBED
                and not self._dock.is_docked()
            ):
                self._show_dock_placeholder(HIDDEN_MODE_PLACEHOLDER)
        elif changed or announce:
            self._log_ui(
                "Đã TẮT chạy ẩn — trình duyệt sẽ nhúng lại vào app "
                "như mặc định."
            )
        if not enabled:
            # V6.9: tắt chạy ẩn → NHÚNG LẠI NGAY (không chờ nhịp tự-nhúng)
            try:
                if getattr(self, "_wall_active", False):
                    self.browser_wall.dock_all(self._manager)
                else:
                    self._embed_suppressed.discard(self._current_profile_id)
                    self._try_dock(quiet=True)
            except Exception:
                pass
        self._sync_hidden_status()

    def _sync_hidden_status(self):
        """V6.9: hiện ĐÚNG trạng thái chạy ẩn trên thanh Hồ sơ + số trình duyệt."""
        label = getattr(self, "hidden_status", None)
        if label is None:
            return
        try:
            running = [p for p in self._store.list_profiles()
                       if self._manager.is_running_cached(p)] if hasattr(self._manager, "is_running_cached") else []
        except Exception:
            running = []
        hidden = self._browsers_hidden()
        chk = getattr(self, "chk_hidden_mode", None)
        if chk is not None:
            chk.setText(f"🏃 Chạy ẩn ({len(running)})" if hidden else "🏃 Chạy ẩn")
        if hidden:
            label.setText(f"🙈 Đang chạy ẩn · {len(running)} trình duyệt chạy nền ngoài màn hình, không hiện ở đâu — "
                          "bỏ chọn “Chạy ẩn” để nhúng lại vào app")
            label.setStyleSheet("QLabel#HiddenStatus { color:#F2C94C; border:1px solid #F2C94C;"
                                " border-radius:10px; padding:2px 10px; }")
        else:
            label.setText(f"🧩 Nhúng trong app · {len(running)} trình duyệt đang chạy")
            label.setStyleSheet("QLabel#HiddenStatus { color:#7DDC7A; border:1px solid #2E3036;"
                                " border-radius:10px; padding:2px 10px; }")
        label.setVisible(True)

    def _toggle_maximize(self):
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    # Cửa sổ không khung: đổi kích thước bằng cách kéo các cạnh (6px).
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and not self.isMaximized() \
                and not self.isFullScreen():
            pos = event.position().toPoint()
            rect = self.rect()
            margin = 6
            edges = ""
            if pos.y() <= margin:
                edges += "t"
            elif pos.y() >= rect.height() - margin:
                edges += "b"
            if pos.x() <= margin:
                edges += "l"
            elif pos.x() >= rect.width() - margin:
                edges += "r"
            if edges:
                self._resize_edge = (edges, event.globalPosition().toPoint(), self.geometry())
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._resize_edge and event.buttons() & Qt.LeftButton:
            edges, start_pos, start_geo = self._resize_edge
            delta = event.globalPosition().toPoint() - start_pos
            geo = start_geo
            x, y, w, h = geo.x(), geo.y(), geo.width(), geo.height()
            if "r" in edges:
                w = max(self.minimumWidth(), w + delta.x())
            if "b" in edges:
                h = max(self.minimumHeight(), h + delta.y())
            if "l" in edges:
                new_w = max(self.minimumWidth(), w - delta.x())
                x += w - new_w
                w = new_w
            if "t" in edges:
                new_h = max(self.minimumHeight(), h - delta.y())
                y += h - new_h
                h = new_h
            self.setGeometry(x, y, w, h)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._resize_edge = None
        super().mouseReleaseEvent(event)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape and self._theater:
            self._exit_theater()
            event.accept()
            return
        if event.key() == Qt.Key_F11:
            self._toggle_theater()
            event.accept()
            return
        super().keyPressEvent(event)

    # ------------------------------------------------------------------ #
    # Thanh trạng thái + khay hệ thống (toast đã bỏ ở V5.3 — A2)
    # ------------------------------------------------------------------ #
    def _refresh_status_bar(self):
        _perf_started = time.monotonic()
        # Số hồ sơ có cổng debug đang mở (CDP sống).
        try:
            profiles = self._store.list_profiles()
        except Exception:
            profiles = []
        live = 0
        for profile in profiles:
            try:
                if self._manager.is_running(profile):
                    live += 1
            except Exception:
                pass
        self._set_text_if_changed(
            self.status_cdp, f"CDP sống: {live}/{len(profiles)} hồ sơ"
        )
        self._set_text_if_changed(
            self.status_bridge, self._bridge_status_text()
        )
        dot = getattr(self, "icon_bridge_dot", None)
        if dot is not None:
            server = self._agent_server
            if server is not None and server.running:
                color, tip = "#43D675", "Cầu nối Muse: đang nghe"
            elif server is not None:
                color, tip = "#E0A63F", "Cầu nối Muse: chưa chạy"
            else:
                color, tip = theme.MUTED, "Cầu nối Muse: tắt"
            # V5.2: chỉ nắn style chấm cầu nối khi màu THẬT SỰ đổi.
            if getattr(dot, "_ccd_color", None) != color:
                dot._ccd_color = color
                dot.setStyleSheet(f"color:{color}; font-size:12px;")
            dot.setToolTip(tip)
        # Luật tự động tới hạn gần nhất.
        try:
            rules = [r for r in self._store.list_rules() if r["enabled"]]
        except Exception:
            rules = []
        upcoming = [r["next_run_at"] for r in rules if r.get("next_run_at")]
        if upcoming:
            nxt = min(upcoming)
            self._set_text_if_changed(
                self.status_auto, f"Tự động kế: {_fmt_ts(nxt)}"
            )
        else:
            self._set_text_if_changed(
                self.status_auto, "Tự động: không có quy tắc đang bật"
            )
        # V4.2 (O-06): vòng tự động degraded thì nói rõ trên thanh
        # trạng thái (nguồn lỗi + giờ + lỗi gần nhất) — hết lỗi thì
        # ẩn. Trước V4.2 lỗi pipeline bị nuốt lặng hoàn toàn.
        try:
            from .. import automation_health

            health = automation_health.read_health(self._store)
        except Exception:
            health = None
        if health and health.get("degraded"):
            at = str(health.get("at") or "")[11:16]
            self._set_text_if_changed(
                self.status_health,
                f"⚠ Vòng tự động lỗi ({health.get('source') or '?'})"
                + (f" lúc {at}" if at else "")
                + f" — {health.get('error') or ''}",
            )
            self.status_health.setVisible(True)
        else:
            self.status_health.setVisible(False)
        # V5.1: thẻ Cầu nối ở mục Hệ thống tươi cùng nhịp thanh
        # trạng thái (5 giây) — mở mục đó là thấy số liệu hiện tại.
        self._update_bridge_card()
        # V4.2 (O-11): bảng hàng đợi ở dock chỉ dựng lại khi đang
        # NHÌN THẤY — nhịp status 5 giây không còn nạp 60 lệnh +
        # dựng bảng cho một dock đang ẩn. Các điểm gọi theo sự kiện
        # (sau thao tác) vẫn gọi thẳng _refresh_queue_tab như cũ.
        queue_table = getattr(self, "queue_table", None)
        if queue_table is not None and queue_table.isVisible():
            self._refresh_queue_tab()
        self._perf_record("Thanh trạng thái 5s", _perf_started)

    def _bridge_status_text(self) -> str:
        server = self._agent_server
        if server is None:
            return "Cầu nối Muse: tắt"
        state = "đang nghe" if server.running else "chưa chạy"
        # V3.8: dùng bằng chứng BỀN trong DB (chỉ tính lời gọi ĐÃ XÁC
        # THỰC, còn sau khi khởi động lại app) thay cho bộ nhớ tạm của
        # server — trạng thái "Muse có đang nghe lệnh không" phải đúng
        # sự thật, kể cả khi app vừa mở lại.
        try:
            bridge = self._store.bridge_state()
        except Exception:
            bridge = {"ever": False, "connected": False, "seconds_ago": None}
        if bridge["connected"]:
            ago = "Muse ĐANG kết nối"
        elif not bridge["ever"]:
            ago = "CHƯA có Muse nào kết nối"
        else:
            seconds = int(bridge["seconds_ago"] or 0)
            if seconds < 3600:
                ago = f"Muse gọi {max(1, seconds // 60)} phút trước"
            elif seconds < 86400:
                ago = f"Muse gọi {seconds // 3600} giờ trước"
            else:
                ago = f"Muse gọi {seconds // 86400} ngày trước"
        # V3.9: kèm lớp vận chuyển Tailscale — hai lớp hỏng khác nhau
        # phải nhìn khác nhau ngay trên thanh trạng thái.
        ts_part = ""
        ts_state = getattr(self, "_ts_state", None)
        if ts_state is not None:
            ts_level = tailscale_helper.classify(ts_state)
            ts_short = {
                "ok": "Tailscale ✓",
                "no_muse": "Tailscale ✓ · muse offline",
                "down": "Tailscale ✗ chưa nối",
                "needs_login": "Tailscale ✗ chưa đăng nhập",
                "missing": "Tailscale ✗ chưa cài",
                "error": "Tailscale ? lỗi",
            }.get(ts_level, "")
            if ts_short:
                ts_part = f" · {ts_short}"
        return f"Cầu nối Muse: {state} · {server.bind_host}:{server.port} · {ago}{ts_part}"

    def _agent_status_text(self) -> str:
        return self._bridge_status_text()

    def _build_tray(self):
        self._tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        pixmap = QPixmap(64, 64)
        pixmap.fill(Qt.transparent)
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(QColor(theme.ACCENT))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(6, 6, 52, 52)
        painter.setPen(QColor("#0B0C0A"))
        # Font dựng TƯỜNG MINH (không sao chép font của painter rồi đặt
        # lại cỡ): bản sao lấy từ thiết bị vẽ có thể là font cỡ pixel
        # (pointSize() == -1) và đường đặt-lại-cỡ đó phát cảnh báo
        # "QFont::setPointSize: Point size <= 0 (-1)" trên Windows.
        painter.setFont(QFont("Segoe UI", 26, QFont.Weight.Bold))
        painter.drawText(pixmap.rect(), Qt.AlignCenter, "C")
        painter.end()
        tray = QSystemTrayIcon(QIcon(pixmap), self)
        tray.setToolTip("Channel Control Desktop")
        menu = QMenu(self)
        menu.addAction("Hiện cửa sổ", self._tray_show)
        menu.addAction("Ẩn cửa sổ", self.hide)
        menu.addSeparator()
        menu.addAction("Quét tất cả hồ sơ", self.on_scan_all)
        menu.addSeparator()
        menu.addAction("Thoát", self.close)
        tray.setContextMenu(menu)
        tray.activated.connect(self._on_tray_activated)
        tray.show()
        self._tray = tray

    def _tray_show(self):
        self.show()
        self.raise_()
        self.activateWindow()

    def _on_tray_activated(self, reason):
        if reason in (
            QSystemTrayIcon.ActivationReason.Trigger,
            QSystemTrayIcon.ActivationReason.DoubleClick,
        ):
            self._tray_show()

    # V5.3 (A2): show_toast/_layout_toasts/_dismiss_toast đã XOÁ —
    # không còn cơ chế thông báo bật lên; sự kiện ghi vào Nhật ký.

    def resizeEvent(self, event):
        super().resizeEvent(event)
        # V4.2 (O-23): topbar tự thu gọn icon-only khi cửa sổ hẹp.
        if hasattr(self, "nav_rail"):
            self._maybe_auto_collapse_rail()

    # ------------------------------------------------------------------ #
    # Cài đặt: áp dụng từ panel Cài đặt
    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    # V4.3 (G4) — Áp theme giao diện
    # ------------------------------------------------------------------ #
    def _initial_theme_tokens(self):
        """Tokens hiệu lực khi mở app — qua KỶ NGUYÊN GIAO DIỆN
        (V5.1, plan §1.2): lần chạy đầu của bản V5.1 áp token V5.1
        VÔ ĐIỀU KIỆN (bộ cũ sao lưu sang theme_backup_pre_v51 —
        cơ chế di trú khớp-tuyệt-đối của các đời trước đã thất bại
        trên máy thật vì settings lệch vài trường, xem skill §13);
        từ đó về sau token đã lưu (kể cả bản khôi phục) được tôn
        trọng. Kỷ nguyên vừa áp thì LƯU settings ngay, không thì
        lần mở sau áp lại và ghi đè khôi phục của người dùng."""
        tokens, changed = theme.apply_theme_epoch(self._settings)
        if changed:
            config.save_settings(self._settings)
        return tokens

    def _apply_theme(self, tokens, save: bool = True):
        """Áp một bộ theme tokens cho TOÀN app ngay lập tức (QSS tập
        trung sinh từ tokens — xem app.ui.theme.build_qss) và lưu vào
        settings. Ảnh nền (nếu có) áp ở mức trang trí cho cửa sổ
        chính; lớp phủ tối giữ bằng chính màu nền của token."""
        qss = theme.build_qss(tokens)
        if tokens.bg_image and Path(tokens.bg_image).exists():
            url = tokens.bg_image.replace("\\", "/")
            qss += (
                f'\nQMainWindow {{ background-image: url("{url}");'
                " background-repeat: repeat; }\n"
            )
        app = QApplication.instance()
        if app is not None and qss != getattr(self, "_applied_qss", None):
            # V5.2: bỏ qua setStyleSheet khi QSS không đổi — mỗi lần
            # gọi là một vòng nắn style toàn cây widget.
            app.setStyleSheet(qss)
            self._applied_qss = qss
        if save:
            self._settings["theme_tokens"] = theme.tokens_to_dict(tokens)
            config.save_settings(self._settings)

    # ------------------------------------------------------------------ #
    # V4.3 (G5) — Zoom trình duyệt nhúng theo hồ sơ
    # ------------------------------------------------------------------ #
    def _update_zoom_label(self):
        if not hasattr(self, "zoom_label"):
            return
        profile = self._selected_profile()
        pct = (
            browser_zoom.get_zoom_pct(self._settings, profile["slug"])
            if profile
            else browser_zoom.DEFAULT_ZOOM_PCT
        )
        self.zoom_label.setText(f"{pct}%")
        slider = getattr(self, "page_zoom_single", None)
        if slider is not None:
            from .. import page_zoom

            value = page_zoom.get_pct(self._settings, profile["slug"]) if profile else None
            slider.blockSignals(True)
            slider.setValue(value if value is not None else 100)
            slider.blockSignals(False)
            self.zoom_label.setText(f"{slider.value()}%")  # V6.9: nhãn = mức zoom trang thật

    def _on_strip_zoom_slider(self, value: int):
        if hasattr(self, "zoom_label"):
            self.zoom_label.setText(f"{int(value)}%")
        self._page_zoom_single_timer.start()

    def _apply_strip_zoom(self):
        """V6.9: thanh zoom cạnh nút Tường — đang ở Tường (hoặc chưa chọn hồ sơ)
        thì áp cho MỌI trang đang mở, ngược lại áp cho hồ sơ đang xem.
        Bản cũ chỉ áp 'trang đang chọn' nên ở chế độ Tường kéo không có tác dụng."""
        wall = bool(getattr(self, "_wall_active", False))
        scope = "all" if (wall or self._current_profile_id is None) else "page"
        self._apply_page_zoom(scope, int(self.page_zoom_single.value()))

    def _on_zoom_step(self, delta: int):
        slider = getattr(self, "page_zoom_single", None)
        if slider is not None:
            slider.setValue(max(slider.minimum(), min(slider.maximum(), slider.value() + int(delta))))
        # V6.9: nút −/+ chỉ đẩy THANH TRƯỢT (một nguồn zoom duy nhất, giữ khi
        # tải lại trang) — không cộng dồn thêm zoom cấp trình duyệt nữa.
        if slider is None:
            profile = self._selected_profile()
            if profile is None:
                return
            pct = browser_zoom.get_zoom_pct(self._settings, profile["slug"]) + delta
            browser_zoom.set_zoom_pct(self._settings, profile["slug"], pct)
            config.save_settings(self._settings)
            self._update_zoom_label()
            self._request_zoom_apply(profile, force=True)

    def _request_zoom_apply(self, profile: dict, force: bool = False):
        """Nộp việc áp zoom (CDP) vào hàng đợi nền — KHÔNG làm trên
        luồng UI. Bỏ qua khi (url, %) không đổi so với lần áp gần
        nhất; lần áp hỏng thì giãn cách thử lại ≥ 15 giây để không
        dội hàng đợi khi Chrome chưa chạy."""
        profile_id = profile["id"]
        pct = browser_zoom.get_zoom_pct(self._settings, profile["slug"])
        url = self._current_url if profile_id == self._current_profile_id else ""
        if not force and self._zoom_applied.get(profile_id) == (url, pct):
            return
        if profile_id in self._zoom_inflight:
            return
        now_mono = time.monotonic()
        if now_mono - self._zoom_last_attempt.get(profile_id, 0.0) < 15.0 and not force:
            return
        self._zoom_last_attempt[profile_id] = now_mono
        self._zoom_inflight.add(profile_id)
        manager = self._manager

        def job(_token, profile=profile, pct=pct, url=url):
            ok = browser_zoom.apply_zoom_for_profile(manager, profile, pct)
            return (profile["id"], url, pct, ok)

        self._runner.submit_custom(
            job,
            profile_id=profile_id,
            kind="browser_zoom",
            on_done=lambda done_job: self._bg_zoom_done.emit(done_job.result),
        )

    # ------------------------------------------------------------------ #
    # V6.5 — Zoom TRANG (CSS) theo ô / hàng / mọi trang, giữ khi tải lại
    # ------------------------------------------------------------------ #
    def _running_profiles(self) -> list[dict]:
        out = []
        for profile in self._store.list_profiles():
            try:
                if self._manager.is_running(profile):
                    out.append(profile)
            except Exception:
                continue
        return out

    def _apply_page_zoom(self, scope: str, pct: int):
        from .. import page_zoom

        running = self._running_profiles()
        positions = dict(getattr(self.browser_wall, "_positions", {}) or {})
        ids = page_zoom.scope_ids(scope, self._current_profile_id, [p["id"] for p in running], positions)
        if not ids and scope != "all":
            self._log_ui("Chưa chọn ô/hồ sơ nào — chọn một trình duyệt hoặc dùng phạm vi 'Mọi trang đang mở'.")
            return
        by_id = {p["id"]: p for p in self._store.list_profiles()}
        slugs = [by_id[i]["slug"] for i in ids if i in by_id]
        pct = page_zoom.set_pct(self._settings, slugs, pct)
        config.save_settings(self._settings)
        self._sync_zoom_keeper(running)
        label = {"page": "trang đang chọn", "row": "cả hàng", "all": "mọi trang đang mở"}.get(scope, scope)
        self._log_ui(f"🔍 Zoom {pct}% cho {label} ({len(slugs)} hồ sơ) — giữ nguyên khi trang tải lại.")

    def _sync_zoom_keeper(self, running: list[dict] | None = None):
        from .. import page_zoom

        running = running if running is not None else self._running_profiles()
        targets = {}
        for profile in running:
            pct = page_zoom.get_pct(self._settings, profile["slug"])
            if pct is not None:
                targets[int(profile["id"])] = (int(profile["port"]), pct)
        keeper = getattr(self, "_zoom_keeper", None)
        if keeper is None:
            if not targets:
                return
            keeper = self._zoom_keeper = page_zoom.ZoomKeeper()
        keeper.set_targets(targets)

    def _on_zoom_apply_done(self, result):
        if not result:
            return
        profile_id, url, pct, ok = result
        self._zoom_inflight.discard(profile_id)
        if ok:
            self._zoom_applied[profile_id] = (url, pct)

    def _zoom_tick(self):
        """Nhịp 600ms (từ _sync_live_active): hồ sơ đang xem mà URL
        trang đổi (điều hướng mới) → áp lại zoom cho target mới."""
        if self._current_profile_id is None or not self._current_url:
            return
        profile = self._selected_profile()
        if profile is not None:
            self._request_zoom_apply(profile)

    def _login_watchdog_tick(self):
        """V4.3 (G5): canh phiên đăng nhập muse.ai của các tài khoản
        Muse — agent nào bị văng (web_state = 'out') thì ghi nhận
        qua automation_health để thanh trạng thái + tab Tài khoản
        Muse báo rõ, thay vì lặng lẽ mất kết nối."""
        try:
            logged_out = [
                a for a in self._store.list_agents()
                if (a.get("web_state") or "") == "out" and not a.get("revoked")
            ]
        except Exception:
            return
        if logged_out:
            names = ", ".join(
                a.get("name") or a.get("email") or f"#{a.get('id')}"
                for a in logged_out
            )
            automation_health.record_error(
                self._store,
                "login_watchdog",
                f"Tài khoản Muse bị văng đăng nhập muse.ai: {names} "
                "— mở tab 🤖 Tài khoản Muse, bấm 🌐 Đăng nhập muse.ai "
                "để đăng nhập lại ngay trong app.",
            )
        else:
            automation_health.record_ok(self._store, "login_watchdog")

    def _apply_settings(self, changed: set) -> str:
        config.save_settings(self._settings)
        messages: list[str] = []
        if "chrome_path" in changed:
            self._manager.chrome_path_override = str(
                self._settings.get("chrome_path") or ""
            )
            messages.append("Đã cập nhật đường dẫn Chrome.")
        if changed & {"ui_rail_collapsed"}:
            # V4.2 (O-23): đổi ở Cài đặt cũng là quyết định tay —
            # thắng chế độ tự thu gọn theo bề rộng.
            self._rail_manual = True
            self._apply_rail_state(bool(self._settings.get("ui_rail_collapsed")))
        if "ui_profile_column_visible" in changed:
            self.profile_column.setVisible(
                bool(self._settings.get("ui_profile_column_visible", True))
            )
        if "ui_dock_expanded" in changed:
            self._set_dock_expanded(bool(self._settings.get("ui_dock_expanded", True)))
        if "auto_open_browsers_on_start" in changed:
            try:
                self.automation_panel.auto_open_check.setChecked(
                    bool(self._settings.get("auto_open_browsers_on_start", False))
                )
            except Exception:
                pass
        if "browsers_hidden_mode" in changed:
            # V5.3 (A8): đổi trong Cài đặt áp ngay như ô tick trên
            # thanh công cụ Hồ sơ (cùng một đường áp chế độ).
            self._apply_hidden_mode(self._browsers_hidden(), announce=False)
        if "embed_browser_always" in changed:
            if self._embed_always():
                # Vừa bật lại: bỏ chặn gỡ-tay và nhúng ngay nếu Chrome đang chạy.
                self._embed_suppressed.clear()
                self._auto_dock_tick()
                messages.append("Đã bật tự nhúng trình duyệt vào app.")
            else:
                messages.append(
                    "Đã tắt tự nhúng — trình duyệt dùng Luồng trực tiếp / nút Nhúng thủ công."
                )
        if changed & {"agent_port", "agent_bind_localhost", "agent_token"}:
            messages.append(self._restart_agent_server())
        if "autostart_windows" in changed:
            # V4.0 (H4.2): ghi/xoá khoá Run của Windows ngay khi Lưu.
            messages.append(self._apply_autostart_setting())
        # V5.3.1 (M2): kích thước ô tường + độ cao nút hàng lệnh —
        # áp MỘT LẦN tại đây khi Lưu (không theo tick, không
        # setStyleSheet toàn app), đúng mẫu gom-áp của trang này.
        if changed & {"wall_tile_width", "wall_tile_height"}:
            wall = getattr(self, "browser_wall", None)
            if wall is not None:
                wall.set_tile_size(
                    self._settings.get("wall_tile_width", 600),
                    self._settings.get("wall_tile_height", 800),
                )
            messages.append("Đã áp kích thước ô tường trình duyệt mới.")
        if "row_action_button_height" in changed:
            for panel in (
                getattr(self, "commands_panel", None),
                getattr(self, "agents_panel", None),
            ):
                apply = getattr(panel, "apply_action_button_height", None)
                if apply is not None:
                    apply()
            messages.append("Đã áp độ cao nút hàng lệnh mới.")
        return " ".join(messages) if messages else "Đã lưu cài đặt."

    def _apply_autostart_setting(self) -> str:
        import sys as _sys

        from .. import instance_guard

        enabled = bool(self._settings.get("autostart_windows"))
        frozen = bool(getattr(_sys, "frozen", False))
        if frozen:
            command = instance_guard.build_autostart_command(
                _sys.executable, frozen=True
            )
        else:
            entry = Path(__file__).resolve().parent.parent.parent / "run_exe.py"
            command = instance_guard.build_autostart_command(
                _sys.executable, script_path=str(entry), frozen=False
            )
        result = instance_guard.set_autostart(enabled, command)
        if result == "ok":
            return (
                "Đã bật tự khởi động cùng Windows."
                if enabled
                else "Đã tắt tự khởi động cùng Windows."
            )
        return (
            "Tự khởi động cùng Windows chỉ áp dụng trên Windows "
            f"({result}) — đã lưu lựa chọn."
        )

    def _reconnect_tick(self):
        """Mỗi 30 giây: (1) tự kiểm cầu nối của app — không trả lời 2 lần
        liền thì khởi động lại; (2) Muse từng kết nối mà mất nhịp tim → đẩy
        tin "kết nối lại" vào muse.ai của tài khoản đó (giãn dần 5 → 10 →
        20 → 40 phút), phiên muse.ai văng thì tự đăng nhập lại qua tinyhost."""
        from .. import reconnect

        if self._settings.get("agent_enabled", True):
            server = self._agent_server
            port = int(getattr(server, "port", 0) or self._settings.get("agent_port", 19500))
            alive = server is not None and reconnect.probe_bridge(port)
            if alive:
                self._bridge_fail = 0
            else:
                self._bridge_fail = getattr(self, "_bridge_fail", 0) + 1
                if self._bridge_fail >= 2:
                    self._bridge_fail = 0
                    message = self._restart_agent_server()
                    self._log_ui(f"🔁 Cầu nối không phản hồi — đã tự khởi động lại. {message}")
                    try:
                        self._store.append_journal(f"[Tự nối lại] Cầu nối không phản hồi → {message}")
                    except Exception:
                        pass
        # V6.5: Muse làm việc qua chat muse.ai (không gọi API) → tài khoản
        # đã đăng nhập muse.ai được coi là SẴN SÀNG nhận việc (nhịp sống
        # do app ghi), để trưởng phòng/KPI/Văn phòng thấy đúng người rảnh.
        if self._settings.get("chat_push_to_muse", True):
            for agent in self._store.list_agents():
                if not agent.get("revoked") and agent.get("web_state") == "in":
                    try:
                        self._store.touch_agent_heartbeat_light(int(agent["id"]), min_interval_seconds=25)
                    except Exception:
                        pass
        if not self._settings.get("auto_reconnect_muse", True):
            return
        # V6.5.2: KHÔNG còn tự đăng nhập lại theo nhịp (bản cũ cứ 30 giây
        # lại mở Chrome đăng nhập cho một tài khoản đang 'out' → trình duyệt
        # Muse bật lên liên tục). Đăng nhập lại chỉ chạy KHI CẦN: lúc cầu
        # nối chat thật sự gửi tin mà trang muse.ai báo đã đăng xuất.

    def _ensure_push_queue(self):
        if self._push_queue is None:
            from .. import muse_push

            def on_result(agent, result, emit=self._bg_push_result.emit):
                name = agent.get("name") or agent.get("email")
                if result.get("ok"):
                    emit(f"⚡ Đã đẩy tin vào muse.ai của '{name}'.")
                else:
                    emit(f"'{name}': chưa đẩy được vào muse.ai ({result.get('reason')}).")

            self._push_queue = muse_push.PushQueue(self._manager, on_result=on_result)
        return self._push_queue

    def _restart_agent_server(self) -> str:
        if self._agent_server is not None:
            try:
                self._agent_server.stop()
            except Exception:
                pass
            self._agent_server = None
        if not self._settings.get("agent_enabled", True):
            return "Cầu nối đang tắt trong cấu hình."
        from ..agent_server import AgentServer

        # V4.1.2: khởi động lại cầu nối KHÔNG gắn hooks preflight
        # trình duyệt/đăng nhập (xem ghi chú ở app/main.py) — lệnh
        # phải tới thẳng Muse, không bị giữ vì web chưa mở.
        server = AgentServer(
            settings=self._settings,
            manager=self._manager,
        )
        try:
            server.start()
        except OSError as exc:
            return f"Không mở lại được cầu nối: {exc}"
        self._agent_server = server
        return f"Cầu nối đã khởi động lại tại {server.bind_host}:{server.port}."

    @property
    def agent_server(self):
        return self._agent_server

    # ------------------------------------------------------------------ #
    # Nền: lệnh chạy xong / lịch tự động / tự mở trình duyệt
    # ------------------------------------------------------------------ #
    def _on_background_command_finished(self, row):
        self.refresh_profiles()
        self.commands_panel.refresh()
        self.checks_panel.refresh()
        self.automation_panel.refresh()
        self.overview_panel.refresh()
        self._refresh_queue_tab()
        status = (row or {}).get("status")
        # V5.3 (A2): kết thúc lệnh chỉ ghi Nhật ký (toast đã bỏ).
        if status == "done":
            self._log_ui(f"Lệnh #{row['id']} ({row['type']}) — xong.")
        elif status in ("failed", "interrupted"):
            self._log_ui(
                f"Lệnh #{row['id']} ({row['type']}) — {status}."
            )

    def _on_auto_tick(self):
        self._login_watchdog_tick()
        # V4.5: nhịp TỰ CHẠY LẠI phía UI (bổ trợ nhịp trong
        # AgentServer — lệnh app-side không phụ thuộc cầu nối có
        # đang chạy hay không; UPDATE có điều kiện ở Store chống
        # hai nhịp giẫm nhau). Lệnh Muse vừa xếp lại → đánh thức
        # dispatcher ngay như lệnh mới.
        try:
            retried = self._store.process_auto_retries()
        except Exception:
            retried = []
        if retried:
            for row in retried:
                self._log_ui(
                    f"[Tự động] Lệnh #{row['id']} ({row['type']}) thất bại"
                    " — đã tự xếp hàng chạy lại sau 30 giây."
                )
            if any(
                row["type"] in CLAUDE_COMMAND_TYPES for row in retried
            ):
                self._request_dispatch_now()
            self.commands_panel.refresh()
        try:
            created = self._engine.tick()
        except Exception as exc:
            self._log_ui(f"Lỗi lịch tự động: {exc}")
            return
        if created:
            # V4.2 (O-27): quy tắc tự động vừa sinh lệnh Muse thì
            # đánh thức dispatcher NGAY (engine tạo lệnh create_video
            # ở 'queued') — không đợi nhịp dispatcher 15 giây.
            self._request_dispatch_now()
            self.commands_panel.refresh()
            self.automation_panel.refresh()
            self._refresh_queue_tab()

    def _auto_open_browsers_on_start(self):
        # V5.3 (A7): trình duyệt khởi động CÙNG tool — mọi hồ sơ
        # không tạm dừng; theo chế độ A8: chạy ẩn thì mở thu nhỏ.
        profiles = [p for p in self._store.list_profiles() if not p["paused"]]
        manager = self._manager
        minimized = self._browsers_hidden()
        for profile in profiles:
            def job_fn(_token, profile=profile, minimized=minimized):
                try:
                    return (
                        profile,
                        manager.launch(profile, hidden=True),  # V6.7: cất tới khi nhúng
                        None,
                    )
                except Exception as exc:
                    return (profile, None, str(exc))

            self._runner.submit_custom(
                job_fn,
                profile_id=profile["id"],
                kind="open_browser",
                on_done=lambda job: self._bg_open_finished.emit(job.result),
            )

    def _on_auto_open_result(self, result):
        if not result:
            return
        profile, state, error = result
        if error:
            message = (
                f"[Tự động] Mở Chrome hồ sơ '{profile['label']}' thất bại: {error}"
            )
        else:
            message = (
                f"[Tự động] Chrome hồ sơ '{profile['label']}': "
                f"{'đã chạy sẵn' if state == 'already_running' else 'đã mở'} "
                "(tự mở khi mở app)."
            )
        self._store.append_journal(message, profile["id"])
        self._log_ui(message)
        if not error:
            # V5.2 (chỉ-nhúng): cửa sổ vừa TỰ MỞ (đầu phiên / theo
            # việc) mà chưa được nhúng ngay (người dùng đang ở mục
            # khác) thì đỗ khuất — không để Chrome đứng ngoài app.
            self._park_window_later(profile)


    # ------------------------------------------------------------------ #
    # V4.5 — Tường trình duyệt nhúng + tự mở trình duyệt khi có việc
    # ------------------------------------------------------------------ #
    def _running_profiles(self) -> list[dict]:
        """Các hồ sơ có Chrome đang chạy (cổng debug mở)."""
        running = []
        for profile in self._store.list_profiles():
            try:
                if self._manager.is_running(profile):
                    running.append(profile)
            except Exception:
                continue
        return running

    def _set_wall_mode(self, on: bool, auto: bool = False):
        """Bật/tắt TƯỜNG TRÌNH DUYỆT ở section Hồ sơ.

        Bật: gỡ nhúng khung đơn (Chrome hồ sơ đang chọn sẽ vào Ô
        của chính nó trong lưới), dựng lưới theo các hồ sơ đang
        chạy, nhúng từng cửa sổ vào ô, và TỰ ẨN panel dữ liệu khi
        ≥3 trình duyệt để lưới có chỗ. Tắt: gỡ nhúng mọi ô (Chrome
        về cửa sổ riêng; nhịp tự-nhúng sẽ đưa hồ sơ đang chọn về
        khung đơn như cũ), hiện lại panel dữ liệu nếu app đã ẩn."""
        if on == self._wall_active or not hasattr(self, "browser_wall"):
            return
        self._wall_active = on
        self.btn_wall.setChecked(on)
        if on:
            if self._dock.is_docked():
                self._undock()
            running = self._running_profiles()
            self._wall_entry_ids = tuple(p["id"] for p in running)
            self.browser_wall.set_entries(running, self._session_states)
            self.center_stack.setCurrentWidget(self.browser_wall)
            if docking.IS_WINDOWS:
                self.browser_wall.dock_all(self._manager)
                # V5.2: ô chưa nhúng được → đỗ khuất cửa sổ + chữ
                # lỗi trên ô; ô đã nhúng → áp zoom đã lưu.
                self._after_wall_dock(running)
            if len(running) >= 3 and not self.data_panel.isHidden():
                self.data_panel.hide()
                self._data_panel_auto_hidden = True
            self._log_ui(
                f"[Tường trình duyệt] {'Tự bật' if auto else 'Đã bật'}: "
                f"{len(running)} trình duyệt hồ sơ đang chạy — ô cố "
                "định 600×800, tối đa 3 ô mỗi hàng (V5.3)."
                + (
                    " Đang bật CHẠY ẨN: các ô chỉ hiện trạng thái, "
                    "trình duyệt chạy ngoài app."
                    if self._browsers_hidden() else ""
                )
            )
        else:
            self.browser_wall.undock_all()
            self.center_stack.setCurrentWidget(self.live_tabs)
            # V4.6: đang ở chế độ ĐẦY KHUNG thì panel dữ liệu vẫn
            # thu gọn (đường ⛶ từ tường dựa vào đây) — chỉ hiện lại
            # khi không đầy khung.
            if self._data_panel_auto_hidden and not self._full_frame:
                self.data_panel.show()
                self._data_panel_auto_hidden = False
            self._wall_manual_off_count = len(self._running_profiles())
            self._log_ui(
                "[Tường trình duyệt] Đã tắt — về khung xem đơn; Chrome "
                "các hồ sơ về cửa sổ riêng (hồ sơ đang chọn sẽ tự "
                "nhúng lại vào khung đơn)."
            )

    # ------------------------------------------------------------------ #
    # V7.1 — LƯỚI XEM TRỰC TIẾP (trình duyệt không nhúng, không che nhau)
    # ------------------------------------------------------------------ #
    def _stream_mode(self) -> bool:
        return str(self._settings.get("browser_view_mode") or "stream") == "stream"

    def _set_grid_mode(self, on: bool, auto: bool = False):
        if not hasattr(self, "live_grid") or on == self._grid_active:
            if hasattr(self, "btn_live_grid"):
                self.btn_live_grid.setChecked(self._grid_active)
            return
        self._grid_active = on
        self.btn_live_grid.setChecked(on)
        if on:
            if self._wall_active:
                self._set_wall_mode(False)
            if self._dock.is_docked():
                old_hwnd = self._dock.docked_hwnd
                self._undock()
                if old_hwnd:
                    self._park_window(old_hwnd)
            running = self._running_profiles()
            self.live_grid.set_entries(running)
            self.live_grid.start()
            self.center_stack.setCurrentWidget(self.live_grid)
            for pid, entry in self._automation.items():
                self.live_grid.set_activity(pid, self._automation_caption(entry))
            self._log_ui(f"📺 Lưới trực tiếp {'tự bật' if auto else 'đã bật'}: {len(running)} trình duyệt chạy nền "
                         "kích thước cố định — không cửa sổ nào bị che, Muse điều khiển không vướng.")
        else:
            self.live_grid.stop()
            self.center_stack.setCurrentWidget(self.live_tabs)
            self._grid_manual_off_count = len(self._running_profiles())

    def _grid_take_control(self, profile_id: int):
        """Bấm 🖐 trên một ô → thoát lưới, nhúng THẬT trình duyệt đó để bạn thao tác."""
        self._set_grid_mode(False)
        self._embed_suppressed.discard(int(profile_id))
        self._on_card_clicked(int(profile_id))
        try:
            self._try_dock(quiet=True)
        except Exception:
            pass
        self._log_ui("🖐 Bạn đang điều khiển tay trình duyệt này — bấm 📺 Lưới trực tiếp để xem lại tất cả.")

    def _grid_tick(self, running: list[dict]):
        if self._grid_active:
            self.live_grid.set_entries(running)
            return
        if not self._stream_mode() or self._wall_active:
            return
        if len(running) < 2:
            self._grid_manual_off_count = -1
        elif len(running) != self._grid_manual_off_count:
            self._set_grid_mode(True, auto=True)

    def _wall_tick(self):
        """Nhịp 600ms: giữ lưới khớp với thực tế — hồ sơ mở thêm/
        đóng bớt thì lưới dựng lại; TỰ BẬT tường khi ≥3 trình duyệt
        cùng chạy ở section Hồ sơ (trừ khi người dùng vừa tắt tay
        ở đúng số lượng đó)."""
        if not hasattr(self, "browser_wall"):
            return
        if (
            not hasattr(self, "sections")
            or self.sections.currentIndex() != SEC_PROFILES
        ):
            return
        running = self._running_profiles()
        ids = tuple(p["id"] for p in running)
        self._wall_priority_tick(running)
        # V7.1: chế độ hình chiếu (mặc định) — lưới trực tiếp thay cho tường nhúng
        self._grid_tick(running)
        if self._grid_active:
            return
        if self._wall_active:
            if ids != self._wall_entry_ids:
                self._wall_entry_ids = ids
                self.browser_wall.set_entries(running, self._session_states)
                if docking.IS_WINDOWS:
                    self.browser_wall.dock_all(self._manager)
                    self._after_wall_dock(running)
            else:
                self.browser_wall.refresh_login_states(self._session_states)
            self.browser_wall.prune_dead()
        else:
            if len(running) < 3:
                self._wall_manual_off_count = -1
            elif len(running) != self._wall_manual_off_count and not self._stream_mode():
                self._set_wall_mode(True, auto=True)
            # V4.6 (10:47): đúng MỘT trình duyệt đang chạy (thường
            # là trình duyệt app TỰ MỞ khi có việc) → nó mở ở dạng
            # ĐƠN ĐẦY KÍCH THƯỚC, trừ khi người dùng đã tắt tay.
            if (
                len(running) == 1
                and not self._full_frame
                and not self._full_frame_optout
            ):
                self._set_full_frame(True)

    # ------------------------------------------------------------------ #
    # V6.3: hồ sơ Muse đang dùng lên đầu tường + tự tắt Chrome rảnh
    # ------------------------------------------------------------------ #
    def _busy_profiles(self) -> dict[int, str]:
        """profile_id → nhãn việc Muse/app đang làm trên hồ sơ đó."""
        out: dict[int, str] = {}
        try:
            agents = {a["id"]: a for a in self._store.list_agents()}
            for command in self._store.list_open_commands(limit=500):
                pid = command.get("profile_id")
                if not pid or command.get("status") not in ("running", "needs_user", "waiting_muse"):
                    continue
                if pid in out and command.get("status") != "running":
                    continue
                agent = agents.get(command.get("agent_id")) or {}
                who = agent.get("name") or "App"
                verb = {"running": "đang dùng", "needs_user": "chờ bạn", "waiting_muse": "sắp dùng"}[command["status"]]
                out[pid] = f"🤖 {who} {verb} · {int(command.get('progress') or 0)}%"
        except Exception:
            pass
        return out

    def _wall_priority_tick(self, running: list[dict]):
        now_m = time.monotonic()
        if now_m - getattr(self, "_wall_prio_at", 0.0) < 3.0:
            return
        self._wall_prio_at = now_m
        self._sync_zoom_keeper(running)
        busy = self._busy_profiles()
        last_used = self._profile_last_used()
        for pid in busy:
            last_used[pid] = now_m
        if self._current_profile_id:
            last_used[self._current_profile_id] = now_m
        priority = {
            p["id"]: (0 if "đang dùng" in busy.get(p["id"], "") else 1 if p["id"] in busy else 2,
                      -last_used.get(p["id"], 0.0), p["id"])
            for p in running
        }
        try:
            self.browser_wall.set_priority(priority, busy)
        except Exception:
            pass

    def _profile_last_used(self) -> dict[int, float]:
        if not hasattr(self, "_last_used_map"):
            self._last_used_map = {}
        return self._last_used_map

    def _refresh_sweep_targets(self):
        self._sync_hidden_status()
        targets = []
        try:
            from .. import agent_browser

            for profile in self._store.list_profiles():
                targets.append((dict(profile), False))
            for agent in self._store.list_agents():
                if not agent.get("revoked"):
                    targets.append((agent_browser.agent_profile(agent), False))
        except Exception:
            return
        self._sweep_targets = targets

    def _backup_db_tick(self):
        db_file = getattr(self._store, "db_file", None)
        if db_file is None or str(db_file) == ":memory:":
            return
        import threading

        def job():
            try:
                from .. import db_health

                db_health.backup_now(db_file)
            except Exception:
                pass

        threading.Thread(target=job, name="db-backup", daemon=True).start()

    def _idle_browser_tick(self):
        # V6.7: Chrome muse.ai của Muse rảnh lâu → tắt (mở lại tự động khi có tin/việc).
        bridge = getattr(self, "_chat_bridge", None)
        if bridge is not None and hasattr(bridge, "close_idle"):
            minutes = float(self._settings.get("muse_idle_close_minutes", 10) or 0)
            bridge.max_browsers = int(self._settings.get("muse_max_browsers", 6) or 6)

            def work(bridge=bridge, minutes=minutes, emit=self._bg_push_result.emit):
                closed = bridge.close_idle(minutes)
                if closed:
                    emit(f"💤 Tự tắt {len(closed)} trình duyệt muse.ai rảnh quá {minutes:g} phút.")

            threading.Thread(target=work, daemon=True, name="muse-idle-close").start()
        self._idle_profiles_tick()

    def _idle_profiles_tick(self):
        """Mỗi phút: Chrome hồ sơ KHÔNG có việc Muse nào (đang chạy /
        chờ người / sắp chạy), không phải hồ sơ bạn đang xem, và rảnh
        quá N phút → tự tắt (phiên đăng nhập vẫn giữ trong thư mục hồ sơ)."""
        minutes = int(self._settings.get("browser_idle_close_minutes", 15) or 0)
        if minutes <= 0:
            return
        now_m = time.monotonic()
        busy = self._busy_profiles()
        last_used = self._profile_last_used()
        try:
            running = self._running_profiles()
        except Exception:
            return
        from .. import cdp as _cdp

        for profile in running:
            pid = profile["id"]
            if pid in busy or pid == self._current_profile_id:
                last_used[pid] = now_m
                continue
            first_seen = last_used.setdefault(pid, now_m)
            if now_m - first_seen < minutes * 60:
                continue
            try:
                _cdp.browser_call(int(profile["port"]), "Browser.close", timeout=5)
            except Exception:
                continue
            last_used.pop(pid, None)
            self._log_ui(f"💤 Tự tắt trình duyệt '{profile['label']}' — không Muse nào dùng {minutes} phút.")

    def _exit_wall_to_profile(self, profile_id: int):
        """Nút ⛶ trên một ô: thoát tường, chọn hồ sơ đó ở khung đơn
        (nhịp tự-nhúng đưa Chrome của nó về khung đơn) — và bật ĐƠN
        KHUNG ĐẦY KÍCH THƯỚC để trình duyệt đó chiếm trọn vùng nội
        dung (V4.6 — 10:47)."""
        self._set_wall_mode(False)
        if profile_id != self._current_profile_id:
            self._on_card_clicked(profile_id)
        self._set_full_frame(True)

    # ------------------------------------------------------------------ #
    # V4.6 (10:47) — Đơn khung ĐẦY KÍCH THƯỚC ở section Hồ sơ
    # ------------------------------------------------------------------ #
    def _set_full_frame(self, on: bool):
        """Bật/tắt ĐƠN KHUNG ĐẦY KÍCH THƯỚC: thu gọn panel dữ liệu
        để khung trình duyệt nhúng đơn lấp đầy vùng nội dung của
        section. Kích thước khung bám theo cửa sổ trực tiếp qua
        đường resize sẵn có (DockContainer.resizeEvent →
        _on_dock_resized → BrowserDock.sync_size; ô tường cũng
        vậy) — hàm này chỉ đổi BỐ CỤC, không đụng zoom trang.

        Thu gọn panel đi qua _set_dock_expanded — cơ chế đóng/mở
        panel dữ liệu CHUẨN của app (chevron trong panel + nút mở
        panel ở thanh tiêu đề dùng chung) — để trạng thái không
        lệch nhau; trạng thái panel TRƯỚC khi bật được nhớ và khôi
        phục khi tắt (người dùng vốn đã thu gọn thì tắt đầy khung
        không tự bung panel ra)."""
        if on == self._full_frame:
            if on and getattr(self, "_dock_expanded", False):
                self._set_dock_expanded(False)
            return
        self._full_frame = on
        self.btn_full_frame.setChecked(on)
        if on:
            self._full_frame_saved_dock = bool(
                getattr(self, "_dock_expanded", True)
            )
            self._set_dock_expanded(False)
        elif not self._wall_active:
            self._set_dock_expanded(
                bool(getattr(self, "_full_frame_saved_dock", True))
            )

    def _on_full_frame_toggled(self, on: bool):
        """Người dùng bấm nút 🗗 Đầy khung: tắt tay thì ghi nhận để
        các đường TỰ bật (nhịp tường) không bật lại trong phiên."""
        if not on:
            self._full_frame_optout = True
        self._set_full_frame(on)

    def _browser_autostart_tick(self):
        """V4.5 — TỰ MỞ TRÌNH DUYỆT KHI CÓ VIỆC (nhịp quét 5 giây):
        lệnh đang CHẠY (running) thuộc một hồ sơ mà Chrome của hồ
        sơ đó chưa chạy → app tự mở Chrome cho hồ sơ đó."""
        if self._manager is None:
            return
        try:
            commands = self._store.list_active_commands()
        except Exception:
            return
        seen: set[int] = set()
        for command in commands:
            if command.get("status") != "running":
                continue
            profile_id = command.get("profile_id")
            if not profile_id or int(profile_id) in seen:
                continue
            seen.add(int(profile_id))
            profile = self._store.get_profile(int(profile_id))
            if profile is not None:
                self._autostart_browser_for(profile, command)

    def _on_command_started_for_browser(self, command: dict):
        """Lệnh app-side vừa bắt đầu chạy (tín hiệu từ CommandRunner)
        → xét mở trình duyệt cho hồ sơ của lệnh NGAY, không đợi nhịp
        quét 5 giây."""
        profile_id = command.get("profile_id")
        if not profile_id:
            return
        profile = self._store.get_profile(int(profile_id))
        if profile is not None:
            self._autostart_browser_for(profile, command)

    def _autostart_browser_for(self, profile: dict, command: dict):
        """Mở Chrome cho MỘT hồ sơ vì lệnh của nó đang chạy mà
        trình duyệt chưa chạy. Chặn dội: tối đa 1 lần/45 giây mỗi
        hồ sơ; hồ sơ TẠM DỪNG thì không tự mở. Việc mở chạy qua
        JobEngine như mọi việc nền (không chặn UI); khi tường trình
        duyệt đang bật, nhịp tường sẽ tự nhúng cửa sổ vừa mở vào ô
        của hồ sơ."""
        if self._manager is None:
            return
        profile_id = int(profile["id"])
        if profile.get("paused"):
            return
        try:
            if self._manager.is_running(profile):
                return
        except Exception:
            return
        now = time.monotonic()
        if now - self._browser_autostart_at.get(profile_id, 0.0) < 45:
            return
        self._browser_autostart_at[profile_id] = now
        manager = self._manager
        self._store.append_journal(
            f"[Tự mở trình duyệt] Lệnh #{command['id']} "
            f"({command.get('type')}) đang chạy — app tự mở Chrome "
            f"cho hồ sơ '{profile['label']}'.",
            profile_id,
        )
        self._log_ui(
            f"[Tự mở trình duyệt] Lệnh #{command['id']} cần trình "
            f"duyệt của hồ sơ '{profile['label']}' — đang tự mở…"
        )

        def job_fn(_token, profile=profile):
            try:
                return (profile, manager.launch(profile), None)
            except Exception as exc:
                return (profile, None, str(exc))

        self._runner.submit_custom(
            job_fn,
            profile_id=profile_id,
            kind="open_browser",
            on_done=lambda job: self._bg_open_finished.emit(job.result),
        )

    def _refresh_work_section(self):
        """V4.3 (G1): vào mục Công việc thì làm mới CẢ bảng việc lẫn
        khối lệnh bên dưới."""
        _perf_started = time.monotonic()
        self.work_panel.refresh()
        self.commands_panel.refresh()
        self._perf_record("Công việc", _perf_started)

    def _refresh_system_section(self):
        self.journal_panel.refresh()
        self.settings_panel.refresh()
        self.theme_panel.refresh()
        self._update_bridge_card()

    def _build_bridge_card(self) -> QFrame:
        """Thẻ CẦU NỐI ở mục Hệ thống (V5.1, plan §2.7): số agent
        đang hoạt động / tổng, nhịp heartbeat gần nhất, nút mở thư
        mục phiếu kết nối. Số liệu THẬT từ Store (trạng thái suy từ
        heartbeat như mọi nơi khác trong app)."""
        card = QFrame()
        card.setObjectName("Panel")
        layout = QHBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(12)
        texts = QVBoxLayout()
        texts.setSpacing(3)
        title = QLabel("🌉 Cầu nối")
        title.setObjectName("CardTitle")
        texts.addWidget(title)
        self.bridge_card_summary = QLabel("—")
        self.bridge_card_summary.setObjectName("Muted")
        self.bridge_card_summary.setWordWrap(True)
        texts.addWidget(self.bridge_card_summary)
        self.bridge_card_heartbeat = QLabel("")
        self.bridge_card_heartbeat.setObjectName("Faint12")
        texts.addWidget(self.bridge_card_heartbeat)
        # V5.2: dòng HIỆU NĂNG (số đo nhịp nền THẬT của chính phiên
        # này) — chủ kênh tự đối chiếu trên máy thật thay vì tin lời.
        self.bridge_card_perf = QLabel("Hiệu năng: chưa có số đo.")
        self.bridge_card_perf.setObjectName("Faint12")
        self.bridge_card_perf.setWordWrap(True)
        texts.addWidget(self.bridge_card_perf)
        layout.addLayout(texts, 1)
        open_button = QPushButton("📁 Mở thư mục phiếu")
        open_button.clicked.connect(self._open_ticket_folder)
        layout.addWidget(open_button)
        return card

    def _update_bridge_card(self):
        if not hasattr(self, "bridge_card_summary"):
            return
        from ..store import agent_status as _agent_status

        try:
            agents = [
                a for a in self._store.list_agents() if not a.get("revoked")
            ]
        except Exception:
            agents = []
        online = sum(
            1
            for a in agents
            if _agent_status(a.get("last_seen_at"), False) == "online"
        )
        self._set_text_if_changed(
            self.bridge_card_summary,
            f"{online}/{len(agents)} Muse đang hoạt động qua cầu nối"
            if agents
            else "Chưa có tài khoản Muse nào.",
        )
        last_seen = max(
            (a.get("last_seen_at") or "" for a in agents), default=""
        )
        self._set_text_if_changed(
            self.bridge_card_heartbeat,
            f"Nhịp heartbeat gần nhất: {last_seen[11:16]}"
            if last_seen
            else "Chưa từng có heartbeat nào — phiếu chưa được nạp "
                 "cho Muse nào (mở thẻ 🔌 Kết nối ở mục Tài khoản).",
        )
        perf_label = getattr(self, "bridge_card_perf", None)
        if perf_label is not None:
            self._set_text_if_changed(
                perf_label, self.perf_summary_text()
            )

    def _open_ticket_folder(self):
        from .. import tickets

        folder = tickets.ticket_export_dir(self._settings)
        try:
            folder.mkdir(parents=True, exist_ok=True)
            from PySide6.QtGui import QDesktopServices
            from PySide6.QtCore import QUrl

            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        except Exception as exc:
            self._log_ui(f"Không mở được thư mục phiếu: {exc}")

    def _on_office_issue_action(self, action: str, issue: dict):
        """V6.1 — thực thi thao tác của một sự cố ở tab Văn phòng.
        Mọi nhánh dùng lại đường xử lý SẴN CÓ của app (không có logic
        song song): chạy tiếp/thử lại qua bảng Công việc, mở trình
        duyệt qua mục Hồ sơ, chat ở panel Văn phòng, kết nối qua hộp
        thoại cầu nối/kết nối từng agent."""
        command_id = issue.get("command_id")
        agent_id = issue.get("agent_id")
        profile_id = issue.get("profile_id")
        try:
            if action == "lead_all":
                from . import button_feedback

                panel = self.office_panel.issues_panel
                done = button_feedback.busy(panel.lead_all_button, "⏳ Trưởng phòng đang xử lý…")
                decided = self._lead_tick(force=True) or []
                done(True, f"✓ Đã ra {len(decided)} quyết định")
                self.office_panel.refresh()
                return
            if action == "resume_all":
                count = 0
                seen = set()
                for item in (issue.get("issues") or []):
                    for cid in item.get("command_ids") or ([item["command_id"]] if item.get("command_id") else []):
                        if cid in seen:
                            continue
                        seen.add(cid)
                        row = self._store.get_command(str(cid))
                        if row is None:
                            continue
                        if row["status"] == "needs_user":
                            self._store.resume_command(str(cid))
                        elif row["status"] in ("failed", "interrupted"):
                            self._store.requeue_command(str(cid))
                        else:
                            continue
                        self._store.update_command_payload_flags(str(cid), clear_keys=("chat_sent", "acked", "chat_sent_at"))
                        count += 1
                self._log_ui(f"▶ Đã cho chạy tiếp {count} lệnh — Muse sẽ nhận lại trọn nội dung việc.")
                from . import button_feedback

                button_feedback.busy(self.office_panel.issues_panel.resume_all_button, "⏳")(True, f"✓ {count} lệnh chạy tiếp")
                self.office_panel.refresh()
                return
            if action == "connect_bridge":
                self._show_bridge_help()
            elif action == "open_journal":
                self._switch_section(SEC_SYSTEM)
                self.system_tabs.setCurrentWidget(self.journal_panel)
            elif action == "open_profile" and profile_id:
                self._open_channel_browser(int(profile_id))
            elif action == "resume" and command_id:
                for cid in issue.get("command_ids") or [command_id]:
                    self.commands_panel._on_resume(str(cid))
            elif action == "open_supervision":
                self._switch_section(SEC_SUPERVISION)
            elif action == "retry" and command_id:
                self.commands_panel._on_retry(str(command_id))
            elif action == "open_command" and command_id:
                self._open_command_in_work(str(command_id))
            elif action == "chat":
                if command_id:
                    self._open_command_chat(str(command_id))
                elif agent_id:
                    self.office_panel.select_agent(int(agent_id))
            elif action == "remind" and agent_id:
                body = (
                    f"⏰ Nhắc việc: lệnh #{command_id} — {issue.get('title')}. "
                    f"{issue.get('detail') or ''} Báo tiến độ ngay hoặc nói rõ đang kẹt ở đâu."
                ).strip()
                self._store.add_message(int(agent_id), "user", body[:3900], command_id=command_id)
                self._wake_bridge_messages()
                self._log_ui(f"Đã nhắc Muse #{agent_id} về lệnh #{command_id}.")
            elif action == "extend" and command_id:
                row = self._store.extend_command_due(str(command_id), 60)
                if row is not None:
                    self._store.append_journal(
                        f"[Giám sát] Gia hạn lệnh #{command_id} thêm 60 phút (từ Văn phòng).",
                        row.get("profile_id"),
                    )
                    self._log_ui(f"Đã gia hạn lệnh #{command_id} thêm 1 giờ.")
            elif action == "agent_connect" and agent_id:
                self._switch_section(SEC_AGENTS)
                self.agents_panel._on_connect_clicked(int(agent_id))
            elif action == "assign":
                self._switch_section(SEC_AGENTS)
                self._log_ui("Chọn một Muse rồi bấm 🎯 Phân công kênh… để giao hồ sơ.")
        except Exception as exc:
            self._log_ui(f"Không thực hiện được thao tác '{action}': {exc}")
        self.office_panel.refresh_issues(force=True)

    def _open_command_in_work(self, command_id):
        """V4.3 (G1/G2): từ Văn phòng (bấm một việc trong panel chi
        tiết) → sang mục Công việc và chọn đúng lệnh đó."""
        self._switch_section(SEC_WORK)
        self.commands_panel.select_command(str(command_id))

    # ------------------------------------------------------------------ #
    # V4.6 — Chat trực tiếp với từng Muse
    # ------------------------------------------------------------------ #
    def _install_chat_push(self):
        """V6.4.3: bấm gửi trong app → gõ NGUYÊN VĂN vào chat muse.ai của
        tài khoản và đọc câu trả lời ngay trên trang (cầu nối trình
        duyệt) — không cần phiếu/connector, tốc độ bằng web muse.ai."""
        from .agent_chat import AgentChatWidget

        def hook(agent, text):
            if not self._settings.get("chat_push_to_muse", True):
                return
            fresh = self._store.get_agent(int(agent["id"])) or agent
            self._ensure_chat_bridge().send(fresh, text)
            AgentChatWidget.poke(int(fresh["id"]), "⏳ Đang gửi vào muse.ai…")

        AgentChatWidget.user_message_hook = staticmethod(hook)

    def _ensure_chat_bridge(self):
        from .. import muse_chat_bridge

        muse_chat_bridge.HEADLESS = bool(self._settings.get("muse_headless", True))
        if self._chat_bridge is None:
            self._chat_bridge = muse_chat_bridge.ChatBridge(self._manager, emit=self._bg_bridge.emit)
            # không giấu cửa sổ muse.ai khi bạn đang tự đăng nhập / đăng nhập hàng loạt
            self._chat_bridge.may_hide = lambda agent_id: (
                not self._bulk_login_active
                and int((self._agent_target or {}).get("agent_id") or 0) != int(agent_id))
        return self._chat_bridge

    def _on_bridge_event(self, event: dict):
        from .. import muse_chat_bridge
        from .agent_chat import AgentChatWidget

        kind = event.get("kind")
        agent_id = int(event.get("agent_id") or 0)
        command_id = event.get("command_id")
        agent = self._store.get_agent(agent_id) if agent_id else None
        if agent is None:
            return
        name = agent.get("name") or agent.get("email")
        try:
            if kind == "sent":
                self._store.mark_read(agent_id, "user")
                if agent.get("web_state") != "in":
                    self._store.set_agent_web_state(agent_id, "in")
                if command_id:
                    self._store.update_command_progress(
                        command_id, 5, f"Đã chuyển việc tới {name} — chờ xác nhận ĐÃ NHẬN")
                if not (event.get("text_head") or "").startswith("[CCD"):
                    # V6.6: trạng thái do APP ghi (chữ xám) — không phải lời của Muse.
                    self._store.add_message(agent_id, "system",
                                            f"✓ Đã chuyển tới {name} · {datetime.now():%H:%M:%S} · 👀 đang đọc…",
                                            command_id=command_id)
                AgentChatWidget.poke(agent_id, "✍ Muse đang trả lời…")
            elif kind == "reply":
                key = (agent_id, event.get("job_id"))
                text = event.get("text") or ""
                message_id = self._bridge_msgs.get(key)
                if text:
                    if message_id is None:
                        message = self._store.add_message(agent_id, "agent", text, command_id=command_id)
                        self._bridge_msgs[key] = message["id"]
                    else:
                        self._store.update_message_body(message_id, text)
                done = bool(event.get("done"))
                if done:
                    self._bridge_msgs.pop(key, None)
                    if not text:
                        self._store.add_message(agent_id, "system",
                                                "Muse chưa trả lời trên muse.ai (quá 2 phút không có chữ).",
                                                command_id=command_id)
                    elif command_id:
                        self._apply_bridge_reply(command_id, text, from_agent_id=agent_id)
                    if text:
                        self._maybe_run_muse_control(agent, text, command_id)
                AgentChatWidget.poke(agent_id, "" if done else "✍ Muse đang trả lời…")
            elif kind == "login":
                self._store.set_agent_web_state(agent_id, "out")
                now_m = time.monotonic()
                memory = getattr(self, "_relogin_memory", {})
                last = memory.get(agent_id, -1e9)
                if now_m - last < 15 * 60:
                    self._store.add_message(agent_id, "system",
                                            "Phiên muse.ai đã văng — vừa thử tự đăng nhập lại cách đây chưa tới 15 phút, "
                                            "chưa thử lại (tránh mở trình duyệt liên tục). Kiểm tra tab Tài khoản Muse.")
                else:
                    memory[agent_id] = now_m
                    self._relogin_memory = memory
                    self._store.add_message(agent_id, "system",
                                            "Phiên muse.ai đã văng — app đang tự đăng nhập lại (chạy nền) rồi gửi tiếp tin của bạn.")
                    if not self._bulk_login_active:
                        self._bulk_login_agents([agent], {"close_on_success": False, "hidden": True})
                AgentChatWidget.poke(agent_id, "🔑 Đang tự đăng nhập lại muse.ai…")
            elif kind == "error":
                reason = event.get("reason") or "lỗi không rõ"
                self._store.add_message(agent_id, "system", f"⚠ Chưa gửi được vào muse.ai: {reason}",
                                        command_id=command_id)
                if command_id:
                    # V7.0: lỗi gửi → app TỰ gửi lại (tối đa 3 lần) thay vì đẩy về bạn.
                    cmd_row = self._store.get_command(command_id) or {}
                    fails = int((cmd_row.get("payload") or {}).get("send_fail_count") or 0) + 1
                    self._store.update_command_payload_flags(
                        command_id, {"send_fail_count": fails}, clear_keys=("chat_sent",))
                    if fails >= 3:
                        self._store.update_command(command_id, status="needs_user", error=reason)
                    elif cmd_row.get("status") not in ("waiting_muse", "done", "failed"):
                        self._store.update_command(command_id, status="waiting_muse")
                self._log_ui(f"Chat '{name}': {reason}")
                AgentChatWidget.poke(agent_id, "")
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"Cầu nối chat '{name}': {exc}")

    def _apply_bridge_reply(self, command_id: str, text: str, from_agent_id: int | None = None):
        from .. import lead_answer, muse_chat_bridge

        command = self._store.get_command(command_id)
        pending_q = ((command or {}).get("payload") or {}).get("lead_q") or {}
        if command is not None and pending_q and from_agent_id is not None \
                and int(from_agent_id) == int(pending_q.get("lead_id") or 0) \
                and int(from_agent_id) != int(command.get("agent_id") or 0):
            # V7.0: đây là câu trả lời của TRƯỞNG PHÒNG → chuyển cho agent hỏi.
            self._forward_lead_answer(command, lead_answer.extract_answer(text), by_lead=True)
            return
        if command is not None and text.strip():
            # V7.0: Muse đã trả lời BẤT KỲ điều gì về việc này = đã nhận việc
            # (không hỏi "nhận chưa?" lặp lại → hết vòng "tin gửi lại lần thứ ba").
            if not (command.get("payload") or {}).get("acked"):
                self._store.update_command_payload_flags(command_id, {
                    "acked": True, "acked_at": datetime.now().astimezone().isoformat(timespec="seconds")})
        if command is not None and muse_chat_bridge.says_missing_task(text) \
                and command.get("status") not in ("done", "failed"):
            # V6.7: Muse nói chưa có nội dung việc → GỬI LẠI TRỌN VIỆC (tối đa 2 lần).
            resend = int((command.get("payload") or {}).get("resend_count") or 0)
            if resend < 2:
                self._store.update_command_payload_flags(
                    command_id, {"resend_count": resend + 1}, clear_keys=("chat_sent", "acked", "chat_sent_at"))
                if command.get("status") != "waiting_muse":
                    self._store.update_command(command_id, status="waiting_muse")
                self._store.update_command_progress(command_id, None, "Muse báo chưa có nội dung việc → gửi lại trọn việc")
                return
        verdict = muse_chat_bridge.classify_reply(text)
        excerpt = " ".join(text.split())[:300]
        pct, step = muse_chat_bridge.parse_progress(text)
        agent = self._store.get_agent(int(command.get("agent_id") or command.get("lease_agent_id") or 0)) \
            if command and (command.get("agent_id") or command.get("lease_agent_id")) else None
        who = (agent or {}).get("name") or "Muse"
        if verdict == "ack":
            # V6.6: Muse xác nhận ĐÃ NHẬN → việc chính thức "Đang làm".
            self._store.update_command_payload_flags(command_id, {
                "acked": True, "acked_at": datetime.now().astimezone().isoformat(timespec="seconds")})
            self._store.update_command_progress(command_id, max(10, pct or 0),
                                                f"{who} xác nhận ĐÃ NHẬN việc: {excerpt[:160]}")
            if pct is not None:
                self._store.update_command_progress(command_id, pct, step or f"Muse báo {pct}%")
            return
        if verdict == "running" and pct is not None:
            self._store.update_command_payload_flags(command_id, {"acked": True})
            self._store.update_command_progress(command_id, pct, step or f"Muse báo {pct}%")
            return
        if verdict == "done":
            self._store.update_command_progress(command_id, 100, f"Muse báo kết quả: {excerpt}")
            self._store.finish_command(command_id, "done", result=text[:4000])
            if agent is not None:
                # V6.6: trưởng phòng (app) xác nhận đã nhận báo cáo — hiện trong luồng trao đổi.
                self._store.add_message(int(agent["id"]), "system",
                                        f"[Trưởng phòng] Đã nhận báo cáo việc #{command_id} của {who} ✓",
                                        command_id=command_id)
        elif verdict == "needs_user" or (verdict != "done" and self._looks_like_question(text)):
            if lead_answer.human_only(text) or not self._settings.get("lead_answers_questions", True):
                # chỉ người thật làm được (mã 2FA/OTP, mật khẩu, thanh toán…)
                self._store.update_command_progress(command_id, 50, f"Muse cần bạn: {excerpt}")
                self._store.update_command(command_id, status="needs_user")
                self._store.update_command_payload_flags(command_id, clear_keys=("chat_sent",))
            else:
                self._lead_resolve_question(command, text, agent)
        else:
            self._store.update_command_progress(command_id, 50, f"Muse trả lời: {excerpt}")

    @staticmethod
    def _looks_like_question(text: str) -> bool:
        """Muse hỏi lại chủ kênh (nhiều dấu ?, "bạn cho", "bạn muốn"…)."""
        low = (text or "").lower()
        asks = low.count("?")
        cues = ("bạn cho", "bạn muốn", "bạn trả lời", "cho em hỏi", "bạn chọn", "bạn duyệt", "xác nhận giúp",
                "cần bạn", "bạn quyết", "nên chọn", "hay là", "trước khi bắt đầu")
        return asks >= 2 or (asks >= 1 and any(c in low for c in cues))

    # ------------------------------------------------------------------ #
    # V7.0 — TRƯỞNG PHÒNG trả lời THAY chủ kênh
    # ------------------------------------------------------------------ #
    def _lead_resolve_question(self, command: dict, question: str, asker: dict | None):
        from .. import lead_answer, supervision

        command_id = command["id"]
        asker_id = int((asker or {}).get("id") or command.get("agent_id") or 0)
        asker_name = (asker or {}).get("name") or "Muse"
        lead_id = supervision.lead_agent_id(self._store, self._settings)
        lead = self._store.get_agent(int(lead_id)) if lead_id else None
        now = datetime.now().astimezone().isoformat(timespec="seconds")
        if command.get("status") == "needs_user":
            self._store.resume_command(command_id)
        if self._store.get_command(command_id)["status"] not in ("running", "waiting_muse"):
            self._store.update_command(command_id, status="running")
        usable = (lead is not None and not lead.get("revoked") and int(lead["id"]) != asker_id
                  and self._settings.get("chat_push_to_muse", True))
        if usable:
            self._store.update_command_payload_flags(command_id, {"lead_q": {
                "question": question[:3000], "asked_at": now, "lead_id": int(lead["id"]), "asker_id": asker_id}})
            prompt = lead_answer.lead_prompt(command, asker_name, question, self._settings)
            self._store.add_message(int(lead["id"]), "user", prompt, command_id=command_id)
            try:
                self._ensure_chat_bridge().send(lead, prompt, command_id=command_id)
            except Exception:
                pass
            self._store.update_command_progress(
                command_id, None, f"{asker_name} hỏi → trưởng phòng {lead.get('name')} đang quyết định thay bạn")
            self._store.add_lead_decision(int(lead["id"]), f"question:{command_id}", "ask_lead",
                                          command_id=command_id, agent_id=asker_id,
                                          detail=f"Nhận câu hỏi của {asker_name} về việc #{command_id} — đang quyết định.",
                                          outcome="done")
            return
        self._forward_lead_answer(command, lead_answer.policy_answer(command, question, self._settings), by_lead=False)

    def _forward_lead_answer(self, command: dict, answer: str, by_lead: bool = True):
        from .. import lead_answer, supervision

        command_id = command["id"]
        payload = command.get("payload") or {}
        asker_id = int((payload.get("lead_q") or {}).get("asker_id") or command.get("agent_id") or 0)
        asker = self._store.get_agent(asker_id) if asker_id else None
        self._store.update_command_payload_flags(command_id, {"acked": True}, clear_keys=("lead_q",))
        fresh = self._store.get_command(command_id) or command
        if fresh.get("status") in ("needs_user", "waiting_muse", "queued"):
            if fresh["status"] == "needs_user":
                self._store.resume_command(command_id)
            self._store.update_command(command_id, status="running")
        body = lead_answer.forward_text(command, answer, by_lead=by_lead)
        if asker is not None:
            self._store.add_message(asker_id, "user", body, command_id=command_id)
            if self._settings.get("chat_push_to_muse", True):
                try:
                    self._ensure_chat_bridge().send(asker, body, command_id=command_id)
                except Exception:
                    pass
        self._store.update_command_progress(
            command_id, None, "Trưởng phòng đã trả lời thay bạn → Muse làm tiếp" if by_lead
            else "Trưởng phòng trả lời theo chính sách tự quyết → Muse làm tiếp")
        lead_id = supervision.lead_agent_id(self._store, self._settings)
        self._store.add_lead_decision(lead_id, f"question:{command_id}", "answer", command_id=command_id,
                                      agent_id=asker_id, outcome="done",
                                      detail=f"Trả lời câu hỏi của {(asker or {}).get('name') or 'Muse'} về việc #{command_id}"
                                             + ("" if by_lead else " (theo chính sách tự quyết)") + ".")
        self._log_ui(f"🧑‍💼 Trưởng phòng đã trả lời câu hỏi việc #{command_id[:8]} — không cần bạn.")

    def _lead_question_watch(self):
        """Trưởng phòng im quá LEAD_ANSWER_WAIT_MIN phút → trả lời theo chính sách."""
        from .. import lead_answer

        now = datetime.now().astimezone()
        try:
            rows = self._store.list_open_commands(limit=500)
        except Exception:
            return
        for row in rows:
            pending = (row.get("payload") or {}).get("lead_q")
            if not pending:
                continue
            asked = _parse_iso_safe(pending.get("asked_at"))
            if asked is None or (now - asked).total_seconds() >= lead_answer.LEAD_ANSWER_WAIT_MIN * 60:
                self._forward_lead_answer(
                    row, lead_answer.policy_answer(row, pending.get("question") or "", self._settings), by_lead=False)

    # ------------------------------------------------------------------ #
    # V6.7 — Tạo hồ sơ hàng loạt (mail|pass) + giao agent
    # ------------------------------------------------------------------ #
    def _open_bulk_profiles(self):
        from PySide6.QtWidgets import QDialog

        from .. import supervision
        from .bulk_profiles_dialog import BulkProfilesDialog

        dialog = BulkProfilesDialog(self._store, supervision.lead_agent_id(self._store, self._settings), self)
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.values()
        if not values["entries"]:
            self._log_ui("Không có tài khoản hợp lệ nào để tạo hồ sơ.")
            return
        self._bulk_create_profiles(values["entries"], values["target"], values["task"], values["login"])

    def _bulk_create_profiles(self, entries, target="auto", task=None, login=True) -> list[dict]:
        from .. import bulk_profiles, supervision

        results = bulk_profiles.create_and_assign(
            self._store, entries, target, supervision.lead_agent_id(self._store, self._settings), task)
        names = {a["id"]: a.get("name") for a in self._store.list_agents()}
        created = [r for r in results if r["status"] == "created"]
        errors = [r for r in results if r["status"] == "error"]
        per_agent: dict = {}
        for r in results:
            if r["agent_id"]:
                per_agent[names.get(r["agent_id"], r["agent_id"])] = per_agent.get(names.get(r["agent_id"], r["agent_id"]), 0) + 1
        split = ", ".join(f"{k}: {v}" for k, v in per_agent.items())
        self._log_ui(f"👥 Đã tạo {len(created)} hồ sơ mới, {len(results) - len(created) - len(errors)} hồ sơ có sẵn"
                     + (f", {len(errors)} lỗi" if errors else "") + (f" — chia: {split}" if split else "") + ".")
        try:
            self.refresh_profiles()
        except Exception:
            pass
        if login:
            for r in results:
                if r["status"] == "created" and r.get("password_saved"):
                    profile = self._store.get_profile(int(r["profile_id"]))
                    if profile is not None:
                        self._submit_login(profile)
        return results

    def _lead_tick(self, force: bool = False):
        from .. import config as _config, lead_autopilot

        if self._settings.get("chat_push_to_muse", True):
            bridge = self._ensure_chat_bridge()
            lead_autopilot.SENDER = lambda agent, body, cid: bridge.send(agent, body, command_id=cid)
        lead_autopilot.QUESTION_HANDLER = lambda cmd, q: self._lead_resolve_question(
            cmd, q, self._store.get_agent(int(cmd["agent_id"])) if cmd.get("agent_id") else None)
        try:
            self._store.set_meta(lead_autopilot.UI_OWNER_KEY, datetime.now().astimezone().isoformat(timespec="seconds"))
            decided = lead_autopilot.run(self._store, self._settings, save_settings=_config.save_settings,
                                         force=force, ignore_cooldown=force)
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"[Trưởng phòng] lỗi: {exc}")
            return
        for record in decided or []:
            self._log_ui(f"🧑‍💼 Trưởng phòng: {record.get('detail')}")
        try:
            self._lead_question_watch()
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"[Trưởng phòng] trả lời câu hỏi lỗi: {exc}")
        # V7.0.1: trưởng phòng TỰ LÊN KẾ HOẠCH + GIAO VIỆC đều cho mọi agent
        try:
            from .. import lead_planner

            planned = lead_planner.run(self._store, self._settings, force=force)
            if planned:
                names = {a["id"]: a.get("name") for a in self._store.list_agents()}
                split: dict = {}
                for row in planned:
                    split[names.get(row.get("agent_id"), "?")] = split.get(names.get(row.get("agent_id"), "?"), 0) + 1
                self._log_ui(f"🧑‍💼 Trưởng phòng giao {len(planned)} việc mới: "
                             + ", ".join(f"{k}: {v}" for k, v in split.items()))
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"[Trưởng phòng] lên kế hoạch lỗi: {exc}")
        return decided

    # ------------------------------------------------------------------ #
    # V6.5 — Muse điều khiển trình duyệt nhúng qua khối ```ccd```
    # ------------------------------------------------------------------ #
    CONTROL_ROUND_LIMIT = 40   # vòng / tài khoản / giờ — chống vòng lặp vô hạn

    def _maybe_run_muse_control(self, agent: dict, text: str, command_id):
        from .. import muse_control

        actions = muse_control.parse_actions(text)
        app_actions = [a for a in actions if a["action"] in muse_control.APP_ACTIONS]
        actions = [a for a in actions if a["action"] not in muse_control.APP_ACTIONS]
        if app_actions:
            self._run_lead_app_actions(agent, app_actions, command_id)
        if not actions:
            return bool(app_actions)
        now_m = time.monotonic()
        rounds = [t for t in self._control_rounds.get(agent["id"], []) if now_m - t < 3600]
        if len(rounds) >= self.CONTROL_ROUND_LIMIT:
            self._send_to_muse(agent, "[CCD] Đã quá giới hạn vòng điều khiển trong 1 giờ — tạm dừng, báo TIẾN ĐỘ hiện tại.",
                               command_id)
            return False
        rounds.append(now_m)
        self._control_rounds[agent["id"]] = rounds
        command = self._store.get_command(command_id) if command_id else None
        profile = muse_control.resolve_profile(self._store, muse_control.wanted_profile(actions), command, agent)
        if profile is None:
            self._send_to_muse(agent, "[CCD] Không xác định được hồ sơ cần mở — thêm {\"action\":\"open\",\"profile\":\"<tên hồ sơ>\"}. "
                               "Hồ sơ có: " + ", ".join(p["label"] for p in self._store.list_profiles()[:30]), command_id)
            return False
        if profile.get("paused"):
            self._send_to_muse(agent, f"[CCD] Hồ sơ '{profile['label']}' đang tạm dừng — không mở được.", command_id)
            return False
        self._open_for_muse(profile)
        if command_id:
            kinds = ", ".join(a["action"] for a in actions[:8])
            try:
                self._store.update_command_progress(command_id, None, f"Muse điều khiển '{profile['label']}': {kinds}")
            except Exception:
                pass
        from .. import muse_control as mc

        self._start_control_round(agent, profile, actions, command_id)
        return True

    def _start_control_round(self, agent: dict, profile: dict, actions: list[dict], command_id, intro: str = ""):
        """Chạy một vòng thao tác trên trình duyệt hồ sơ ở luồng nền (hiển thị
        từng bước) rồi gửi kết quả + ảnh trang hiện tại cho Muse."""
        from .. import muse_control as mc

        step_emit = self._bg_control_step.emit
        visual = bool(self._settings.get("automation_overlay", True))
        self._on_control_step({"profile_id": profile["id"], "label": profile["label"], "agent": agent.get("name"),
                               "index": 0, "total": len(actions), "text": "chuẩn bị trình duyệt…", "state": "run"})

        def work(profile=profile, actions=actions, agent=agent, command_id=command_id, emit=self._bg_control.emit):
            def on_step(index, total, text, state, pid=profile["id"], label=profile["label"], who=agent.get("name")):
                step_emit({"profile_id": pid, "label": label, "agent": who, "index": index, "total": total,
                           "text": text, "state": state, "command_id": command_id})

            try:
                client = mc.connect(int(profile["port"]))
                try:
                    lines, snap = mc.run_actions(client, actions, on_step=on_step,
                                                 who=agent.get("name") or "Muse", visual=visual)
                finally:
                    client.close()
                result = mc.format_result(profile["label"], lines, snap)
            except Exception as exc:  # noqa: BLE001
                result = f"[CCD · {profile['label']}] Không điều khiển được trình duyệt: {type(exc).__name__}: {exc}"
            if intro:
                result = intro.strip() + "\n" + result
            emit({"agent": agent, "command_id": command_id, "text": result, "profile_id": profile["id"]})

        threading.Thread(target=work, daemon=True, name=f"muse-control-{agent['id']}").start()
        self._log_ui(f"🖱 Muse '{agent['name']}' điều khiển trình duyệt '{profile['label']}' ({len(actions)} thao tác).")

    # V7.0.1: loại việc làm TRÊN TRÌNH DUYỆT của kênh → app tự mở sẵn trình duyệt
    KICKOFF_TYPES = ("upload", "optimize", "create_channel", "free", "create_video")

    @staticmethod
    def _work_url(profile: dict, channel: dict | None) -> str:
        from .. import platforms

        platform = platforms.of(channel or profile)
        if platform == "youtube":
            cid = (channel or {}).get("channel_id") or ""
            return f"https://studio.youtube.com/channel/{cid}" if cid.startswith("UC") else "https://studio.youtube.com/"
        if platform == "facebook":
            return (channel or {}).get("url") or "https://business.facebook.com/latest/home"
        return platforms.info(platform)["studio"]

    def _kickoff_browser(self, command: dict, agent: dict) -> bool:
        """Giao việc xong → MỞ SẴN trình duyệt của đúng hồ sơ/kênh ở trang làm việc
        (Studio / page / TikTok Studio), hiển thị trong app, rồi gửi Muse ảnh trang
        + danh sách phần tử để Muse thao tác NGAY bằng khối ```ccd``` — Muse làm
        việc thật trên trình duyệt local, bạn nhìn thấy từng bước."""
        if not self._settings.get("automation_kickoff", True):
            return False
        if command.get("type") not in self.KICKOFF_TYPES or not command.get("profile_id"):
            return False
        if (command.get("payload") or {}).get("browser_kickoff"):
            return False
        profile = self._store.get_profile(int(command["profile_id"]))
        if profile is None or profile.get("paused"):
            return False
        channel = next((c for c in self._store.list_channels(int(profile["id"]))
                        if c.get("channel_id") == command.get("channel_id")), None)
        url = self._work_url(profile, channel)
        self._store.update_command_payload_flags(command["id"], {"browser_kickoff": True})
        self._open_for_muse(profile)
        intro = (f"[CCD · {profile['label']}] Trình duyệt của hồ sơ đã MỞ SẴN cho việc #{command['id']} "
                 f"(đã đăng nhập, đang ở {url}). Làm việc này TRỰC TIẾP trên trình duyệt này: gửi khối ```ccd``` "
                 "vài thao tác mỗi lần (goto / click / type / key / scroll / wait), app chạy ngay rồi gửi lại trang mới. "
                 "Chủ kênh đang nhìn từng bước trên màn hình.")
        self._start_control_round(agent, profile, [{"action": "open"}, {"action": "goto", "url": url}],
                                  command["id"], intro=intro)
        return True

    def _run_lead_app_actions(self, agent: dict, actions: list[dict], command_id):
        """V6.7: TRƯỞNG PHÒNG tạo hồ sơ hàng loạt qua chat:
        {"action":"create_profiles","accounts":["mail|pass", ...],"agent":"auto|<tên Muse>","task":"…"}.
        Chỉ tài khoản đang là trưởng phòng mới được dùng. Kết quả gửi lại KHÔNG kèm mật khẩu."""
        from .. import bulk_profiles, supervision

        lead = supervision.lead_agent_id(self._store, self._settings)
        if lead is None or int(agent["id"]) != int(lead):
            self._send_to_muse(agent, "[CCD] create_profiles chỉ dành cho trưởng phòng — bỏ qua.", command_id)
            return
        for action in actions:
            accounts = action.get("accounts") or []
            text = "\n".join(str(a) for a in accounts) if isinstance(accounts, list) else str(accounts)
            entries, errors = bulk_profiles.parse_lines(text)
            target = action.get("agent") or "auto"
            if target != "auto":
                match = next((a for a in self._store.list_agents()
                              if str(target).lower() in ((a.get("name") or "") + " " + (a.get("email") or "")).lower()), None)
                target = match["id"] if match else "auto"
            task = {"type": action.get("type") or "free", "instruction": action.get("task") or ""}
            results = self._bulk_create_profiles(entries, target, task, login=True) if entries else []
            names = {a["id"]: a.get("name") for a in self._store.list_agents()}
            lines = [f"- {r['email']}: {r['status']} → {names.get(r['agent_id'], '—')}" for r in results]
            self._send_to_muse(agent, "[CCD] Tạo hồ sơ: " + (f"{len(results)} tài khoản" if results else "không có dòng hợp lệ")
                               + ("\n" + "\n".join(lines[:40]) if lines else "")
                               + (("\nLỗi: " + "; ".join(errors[:5])) if errors else ""), command_id)

    def _open_for_muse(self, profile: dict):
        """Mở Chrome của hồ sơ cho Muse: NHÚNG trong app (không bật cửa
        sổ ra ngoài) trừ khi bạn bật chế độ chạy ẩn ngoài app."""
        try:
            if not self._manager.is_running(profile):
                # V6.5.2: mở NGOÀI màn hình (chờ nhúng vào ô), không bật lên giao diện.
                try:
                    self._manager.launch(profile, hidden=True)
                except TypeError:
                    self._manager.launch(profile, start_minimized=True)
                self._store.append_journal(f"🤖 Muse mở Chrome hồ sơ '{profile['label']}' (nhúng trong app).", profile["id"])
        except Exception as exc:  # noqa: BLE001
            self._log_ui(f"Không mở được Chrome hồ sơ '{profile['label']}': {exc}")
            return
        try:
            self._profile_last_used()[int(profile["id"])] = time.monotonic()
        except Exception:
            pass
        if not self._browsers_hidden() and self._embed_always() and not getattr(self, "_wall_active", False) \
                and self._current_profile_id is None:
            self._current_profile_id = profile["id"]
            self._embed_suppressed.discard(profile["id"])

    # ------------------------------------------------------------------ #
    # V7.0 — HIỂN THỊ RÕ thao tác tự động trên từng trình duyệt
    # ------------------------------------------------------------------ #
    def _on_control_step(self, event: dict):
        pid = int(event.get("profile_id") or 0)
        if not pid:
            return
        state = event.get("state")
        entry = self._automation.get(pid) or {"started": time.monotonic(), "log": []}
        entry.update({k: event.get(k) for k in ("label", "agent", "index", "total", "text", "state", "command_id")})
        entry["at"] = time.monotonic()
        if state in ("ok", "error", "done"):
            entry["log"] = (entry.get("log") or [])[-30:] + [
                f"{datetime.now():%H:%M:%S} {'✓' if state != 'error' else '✕'} {event.get('text')}"]
        self._automation[pid] = entry
        if state == "run" and int(event.get("index") or 0) == 1 or (state == "run" and event.get("index") == 0):
            self._follow_automation(pid)
        if state in ("done", "error"):
            try:
                self._store.append_journal(
                    f"🤖 {event.get('agent') or 'Muse'} {'xong' if state == 'done' else 'LỖI'}: {event.get('text')}", pid)
            except Exception:
                pass
            QTimer.singleShot(6000, lambda p=pid, at=entry["at"]: self._expire_automation(p, at))
        self._render_automation_strip()
        try:
            self.browser_wall.set_activity(pid, self._automation_caption(entry))
        except Exception:
            pass
        try:
            self.live_grid.set_activity(pid, self._automation_caption(entry))
        except Exception:
            pass
        self._refresh_card_activity(pid)

    @staticmethod
    def _automation_caption(entry: dict) -> str:
        if not entry:
            return ""
        state = entry.get("state")
        icon = {"run": "🤖", "ok": "🤖", "done": "✓", "error": "⚠"}.get(state, "🤖")
        total = int(entry.get("total") or 0)
        index = int(entry.get("index") or 0)
        step = f"bước {index}/{total} · " if total and state in ("run", "ok") else ""
        return f"{icon} {entry.get('agent') or 'Muse'}: {step}{entry.get('text') or ''}"

    def _expire_automation(self, pid: int, at: float):
        entry = self._automation.get(pid)
        if entry is not None and entry.get("at") == at and entry.get("state") in ("done", "error"):
            self._automation.pop(pid, None)
            self._render_automation_strip()
            try:
                self.browser_wall.set_activity(pid, "")
                self.live_grid.set_activity(pid, "")
            except Exception:
                pass
            self._refresh_card_activity(pid)

    def _render_automation_strip(self):
        strip = getattr(self, "automation_strip", None)
        if strip is None:
            return
        while self.automation_layout.count():
            item = self.automation_layout.takeAt(0)
            old = item.widget()
            if old is not None:
                old.hide()
                old.setParent(None)
                old.deleteLater()
        for pid, entry in sorted(self._automation.items(), key=lambda kv: -kv[1].get("at", 0))[:6]:
            row = QPushButton(f"{entry.get('label') or pid}  ·  {self._automation_caption(entry)}")
            row.setProperty("variant", "ghost")
            row.setStyleSheet(
                "QPushButton { text-align: left; padding: 3px 8px; border: none; color: %s; font-weight: 600; }"
                "QPushButton:hover { color: #FFFFFF; }"
                % {"error": "#FF7A7A", "done": "#7DDC7A"}.get(entry.get("state"), "#CEFC19"))
            row.setToolTip("Bấm để xem trình duyệt này.\n" + "\n".join((entry.get("log") or [])[-10:]))
            row.clicked.connect(lambda _c=False, p=pid: self._focus_profile_browser(p))
            self.automation_layout.addWidget(row)
        strip.setVisible(bool(self._automation))

    def _focus_profile_browser(self, pid: int):
        try:
            if getattr(self, "_grid_active", False):
                self.live_grid.highlight(pid)
                return
            if getattr(self, "_wall_active", False):
                self.browser_wall.highlight(pid)
                return
        except Exception:
            pass
        self._on_card_clicked(int(pid))

    def _follow_automation(self, pid: int):
        """Tự đưa trình duyệt đang bị Muse điều khiển lên khung xem (nếu bạn
        đang ở tab Hồ sơ và không tự thao tác trong ~20 giây gần nhất)."""
        if not self._settings.get("automation_follow", True):
            return
        if pid == self._current_profile_id:
            return
        idle = time.monotonic() - float(getattr(self, "_last_user_input", 0.0))
        if idle < 20:
            return
        try:
            if getattr(self, "_grid_active", False):
                self.live_grid.highlight(pid)
            elif getattr(self, "_wall_active", False):
                self.browser_wall.highlight(pid)
            else:
                self._on_card_clicked(int(pid))
        except Exception:
            pass

    def _refresh_card_activity(self, pid: int):
        card = (getattr(self, "_card_widgets", None) or {}).get(int(pid))
        if card is not None and hasattr(card, "set_activity"):
            try:
                card.set_activity(self._automation_caption(self._automation.get(int(pid)) or {}))
            except Exception:
                pass

    def _on_control_result(self, payload: dict):
        agent = self._store.get_agent(int(payload["agent"]["id"])) or payload["agent"]
        self._send_to_muse(agent, payload["text"], payload.get("command_id"))

    def _send_to_muse(self, agent: dict, text: str, command_id=None):
        try:
            self._store.add_message(int(agent["id"]), "user", text, command_id=command_id)
        except Exception:
            pass
        if self._settings.get("chat_push_to_muse", True):
            self._ensure_chat_bridge().send(agent, text, command_id=command_id)
        from .agent_chat import AgentChatWidget

        AgentChatWidget.poke(int(agent["id"]))

    def _bridge_dispatch_tick(self):
        """Lệnh đang chờ Muse ('waiting_muse') chưa gửi → gõ nội dung việc
        vào chat muse.ai của Muse phụ trách (mỗi lệnh một lần)."""
        if not self._settings.get("chat_push_to_muse", True):
            return
        from .. import muse_chat_bridge
        from .steps_table import plan_text

        try:
            commands = self._store.list_commands(status="waiting_muse", limit=50)
        except Exception:
            return
        from .. import office_feed

        off_hours = office_feed.work_mode(self._settings) == "off"
        sent = 0
        for command in reversed(commands):
            if sent >= 3:
                break
            payload = command.get("payload") or {}
            if payload.get("chat_sent"):
                continue
            if off_hours and not office_feed.is_urgent(command):
                continue  # V6.6: ngoài giờ — việc tự động chờ tới giờ làm việc
            agent = None
            if command.get("agent_id"):
                agent = self._store.get_agent(int(command["agent_id"]))
            if agent is None and command.get("profile_id"):
                agent = self._store.agent_for_profile(int(command["profile_id"]))
            if agent is None or agent.get("revoked"):
                continue
            bridge = self._ensure_chat_bridge()
            if bridge.pending(int(agent["id"])) >= 2:
                continue
            channel = ""
            if command.get("profile_id"):
                profile = self._store.get_profile(int(command["profile_id"]))
                channel = (profile or {}).get("label") or ""
            if payload.get("acked") and not payload.get("force_full"):
                # V7.0: việc ĐÃ được nhận trước đó → chỉ nhắn "làm tiếp" ngắn gọn,
                # không gửi lại trọn nội dung (Muse phàn nàn "tin gửi lại lần thứ ba").
                from .. import lead_answer

                text = lead_answer.continue_text(command, payload.get("resume_note") or "")
                self._store.update_command_payload_flags(command["id"], clear_keys=("resume_note",))
            else:
                from .. import platforms as _platforms

                context = ""
                try:
                    prof_row = self._store.get_profile(int(command["profile_id"])) if command.get("profile_id") else None
                    ch_row = next((c for c in (self._store.list_channels(int(command["profile_id"]))
                                               if command.get("profile_id") else [])
                                   if c.get("channel_id") == command.get("channel_id")), None)
                    context = _platforms.task_context(prof_row, ch_row)
                except Exception:
                    context = ""
                text = muse_chat_bridge.task_text(command, channel, plan_text(command), agent.get("name") or "",
                                                  context=context)
            self._store.update_command_payload_flags(command["id"], {
                "chat_sent": True, "chat_sent_at": datetime.now().astimezone().isoformat(timespec="seconds")})
            self._store.add_message(int(agent["id"]), "user", text, command_id=command["id"])
            bridge.send(agent, text, command_id=command["id"])
            sent += 1
            try:
                self._kickoff_browser(self._store.get_command(command["id"]) or command, agent)
            except Exception as exc:  # noqa: BLE001
                self._log_ui(f"Không mở sẵn được trình duyệt cho việc #{command['id'][:8]}: {exc}")
            self._log_ui(f"📨 Đã giao việc #{command['id']} cho '{agent['name']}' qua chat muse.ai.")

    def _wake_bridge_messages(self):
        """Người dùng vừa gửi tin chat → đánh thức long-poll của cầu
        nối NGAY (AgentServer.notify_messages_changed) để Muse
        nhận tin gần như tức thì thay vì chờ nhịp quét."""
        server = self._agent_server
        if server is not None:
            try:
                server.notify_messages_changed()
            except Exception:
                pass

    def _open_channel_browser(self, profile_id: int):
        """V5.0: mở trình duyệt của kênh từ menu chuột phải ở bảng
        Theo Agent — chuyển sang mục Hồ sơ, chọn đúng hồ sơ của kênh
        rồi mở trình duyệt (đường mở sẵn có của mục Hồ sơ)."""
        self._switch_section(SEC_PROFILES)
        self._on_card_clicked(int(profile_id))
        self.on_open_browser()

    def _open_command_chat(self, command_id):
        """Từ một lệnh → sang VĂN PHÒNG, chọn Muse PHỤ TRÁCH lệnh
        đó và gắn chip ngữ cảnh lệnh vào khung chat tại Văn phòng
        (V4.6 sửa phạm vi 10:46: chat sống ở Văn phòng — không đá
        người dùng sang mục Tài khoản nữa; mục Tài khoản vẫn giữ
        khung chat của nó như cửa vào thứ hai). Muse phụ trách =
        agent ghi danh trên lệnh, đang giữ lease, hoặc chủ của hồ
        sơ đích."""
        command = self._store.get_command(str(command_id))
        if command is None:
            self._log_ui(f"Không thấy lệnh #{command_id} để mở chat.")
            return
        agent_id = command.get("agent_id") or command.get("lease_agent_id")
        if not agent_id and command.get("profile_id"):
            owner = self._store.agent_for_profile(int(command["profile_id"]))
            agent_id = owner["id"] if owner else None
        if not agent_id:
            self._log_ui(
                f"Lệnh #{command_id} chưa có Muse phụ trách — chưa "
                "mở chat được. Hãy phân công Muse cho hồ sơ của "
                "lệnh trước."
            )
            return
        self._switch_section(SEC_OFFICE)
        self.office_panel.open_chat_for_command(
            int(agent_id), str(command_id)
        )

    def _goto_checks(self):
        self._switch_section(SEC_CHECKS)
        # V4.3 (G1): Kiểm tra là TAB CON của mục Báo cáo — chọn đúng
        # tab con, không chỉ dừng ở mục cha.
        self.reports_tabs.setCurrentWidget(self.checks_panel)
        profile = self._selected_profile()
        if profile is not None:
            self.checks_panel._run_one(profile["id"])

    # ------------------------------------------------------------------ #
    # Live view: chế độ xem / điều khiển + chuyển tiếp thao tác
    # ------------------------------------------------------------------ #
    def _set_control_mode(self, control: bool):
        self.live_label.set_control_enabled(control)
        if control:
            self.live_label.setFocus()
            self._log_ui("Đã bật chế độ ĐIỀU KHIỂN — chuột/phím trong khung live sẽ thao tác thật vào Chrome.")
        else:
            self._log_ui("Đã về chế độ XEM trực tiếp (không chuyển tiếp thao tác).")

    def _on_live_click(self, x_ratio: float, y_ratio: float):
        if self._live_worker is not None:
            self._live_worker.send_mouse_click(x_ratio, y_ratio)

    def _on_live_wheel(self, x_ratio: float, y_ratio: float, delta_y: int):
        if self._live_worker is not None:
            self._live_worker.send_mouse_wheel(x_ratio, y_ratio, delta_y)

    def _on_live_key(self, params: dict):
        if self._live_worker is not None:
            self._live_worker.send_key(params)

    def _on_bring_front(self):
        if self._live_worker is not None:
            self._live_worker.request_front()
        else:
            QMessageBox.information(
                self, "Chưa có phiên trực tiếp", "Hãy chọn một hồ sơ có Chrome đang mở."
            )

    def _sync_live_active(self):
        if self._live_worker is not None:
            self._live_worker.set_active(self.isActiveWindow())
        # Watchdog nhúng (V3.1): Chrome chết/tạo cửa sổ mới -> tự xử lý.
        # V5.3 (A8): chạy ẩn thì watchdog KHÔNG cố nhúng lại.
        if self._dock.docked_hwnd is not None and not self._browsers_hidden():
            outcome = self._watchdog.tick()
            if outcome == "redocked":
                # V5.2: nhúng LẠI cũng là một lần nhúng — áp lại
                # zoom đã lưu cho cửa sổ mới.
                self._zoom_for_dock_profile()
                self._log_ui("Chrome vừa tạo cửa sổ mới — đã tự nhúng lại vào app.")
            elif outcome == "lost":
                self._dock.detach()
                self._watchdog.forget()
                self._dock_profile_id = None
                self._set_live_tab(TAB_STREAM)
                self._log_ui("Cửa sổ Chrome đã đóng — đã gỡ nhúng, về Luồng trực tiếp.")
            self._sync_toolbar_context()
        self._auto_dock_tick()
        self._wall_tick()
        self._zoom_tick()

    # ------------------------------------------------------------------ #
    # Nhúng trình duyệt thật (Windows; nơi khác tự rơi về luồng ảnh)
    # ------------------------------------------------------------------ #
    def _set_live_tab(self, index: int):
        self._tab_sync_guard = True
        try:
            self.live_tabs.setCurrentIndex(index)
        finally:
            self._tab_sync_guard = False
        self._sync_toolbar_context()

    def _on_live_tab_changed(self, index: int):
        if self._tab_sync_guard:
            return
        # V4.6: quay lại tab Nhúng khi đang nhúng → đồng bộ lại kích
        # thước cửa sổ Chrome theo khung chứa HIỆN TẠI ngay (bổ trợ
        # cho đường resizeEvent vốn đã chạy ở mọi thay đổi kích
        # thước — phòng khi kích thước đổi lúc tab không hiện).
        if index == TAB_EMBED and self._dock.is_docked():
            self._dock.sync_size(
                self.dock_container.width(), self.dock_container.height()
            )
        if index == TAB_EMBED and not self._dock.is_docked():
            self._dock_manual()
        elif index == TAB_STREAM and self._dock.is_docked() and not self._embed_always():
            # Chỉ khi TẮT tự-nhúng thì sang Luồng trực tiếp mới gỡ nhúng;
            # đang bật tự-nhúng thì Chrome ở yên trong app (V3.2).
            self._undock()
            self._log_ui("Đã gỡ nhúng — Chrome trở lại cửa sổ riêng; đang xem Luồng trực tiếp.")
        elif index == TAB_STILL:
            self._refresh_still()
        self._sync_toolbar_context()

    def _sync_toolbar_context(self):
        docked = self._dock.is_docked()
        embed_showing = (
            hasattr(self, "live_tabs")
            and self.live_tabs.currentIndex() == TAB_EMBED
        )
        dock_mode = docked and embed_showing
        # Đang nhúng: thao tác là native trong chính Chrome — ẩn các nút
        # chỉ dành cho luồng (Xem/Điều khiển, fps, Đưa lên trước).
        self.mode_segmented.setVisible(not dock_mode)
        self.fps_label.setVisible(not dock_mode)
        self.btn_front.setVisible(not dock_mode)
        self.btn_dock_toggle.setText("Gỡ nhúng" if docked else "Nhúng")

    def _on_dock_toggle(self):
        if self._dock.is_docked():
            profile = self._selected_profile()
            if profile is not None:
                # Gỡ tay: bộ tự-nhúng không giành lại cửa sổ này nữa.
                self._embed_suppressed.add(profile["id"])
            self._undock()
            self._set_live_tab(TAB_STREAM)
            self._log_ui("Đã gỡ nhúng — Chrome trở lại cửa sổ riêng.")
        else:
            self._dock_manual()

    def _dock_manual(self):
        """Nhúng theo thao tác tay của người dùng: bỏ chặn tự-nhúng của
        hồ sơ đang chọn rồi nhúng ngay. Chế độ chạy ẩn (V5.3 A8):
        KHÔNG nhúng — hiện trạng thái ẩn trong khung + nhắc cách
        tắt, tôn trọng lựa chọn chế độ của người dùng."""
        if self._browsers_hidden():
            self._log_ui(
                "Đang bật Chạy ẩn ngoài app — tắt “🏃 Chạy ẩn” "
                "để nhúng trình duyệt vào app."
            )
            self._set_live_tab(TAB_EMBED)
            self._show_dock_placeholder(HIDDEN_MODE_PLACEHOLDER)
            return
        from . import button_feedback

        done = button_feedback.busy(getattr(self, "btn_redock", None), "⏳ Đang nhúng…")
        profile = self._selected_profile()
        if profile is not None:
            self._embed_suppressed.discard(profile["id"])
        self._try_dock()
        ok = bool(getattr(self, "_dock", None) is not None and self._dock.is_docked())
        done(ok, "✓ Đã nhúng" if ok else "✕ Chưa nhúng được")

    def _embed_always(self) -> bool:
        return bool(self._settings.get("embed_browser_always", True))

    def _auto_dock_tick(self):
        """Tự nhúng (V3.2) — gọi mỗi 600ms từ _sync_live_active: khi cài
        đặt 'luôn nhúng' đang bật và đang ở mục Hồ sơ, hễ Chrome của hồ
        sơ đang chọn đang chạy mà chưa nhúng thì nhúng ngay; đang nhúng
        cho hồ sơ KHÁC (vừa đổi hồ sơ) thì gỡ ra, thu nhỏ cửa sổ cũ về
        taskbar rồi nhúng cửa sổ mới — không bao giờ để Chrome bật ra
        ngoài giao diện."""
        if self._browsers_hidden():
            return  # V5.3 (A8): chạy ẩn — nhịp tự-nhúng đứng yên.
        if not self._embed_always() or not docking.IS_WINDOWS:
            return
        if getattr(self, "_wall_active", False) or getattr(self, "_grid_active", False):
            # V4.5: tường trình duyệt đang bật — các ô của tường giữ
            # Chrome của chúng; khung đơn không giành lại.
            # V7.1: lưới trực tiếp — không nhúng gì, trình duyệt chạy nền.
            return
        if not hasattr(self, "sections") or self.sections.currentIndex() != SEC_PROFILES:
            return
        # Phiên đăng nhập muse.ai (V3.5): cửa sổ Chrome riêng của tài
        # khoản Muse được ưu tiên nhúng cho tới khi đăng nhập xong
        # hoặc người dùng chọn lại hồ sơ kênh.
        target = self._agent_target
        if target is not None:
            if self._dock.is_docked():
                if self._dock_profile_id != target["id"]:
                    old_hwnd = self._dock.docked_hwnd
                    self._undock()
                    if old_hwnd:
                        self._park_window(old_hwnd)
                    self._try_dock(quiet=True, profile_override=target)
                return
            try:
                running = self._manager.is_running(target)
            except Exception:
                running = False
            if running:
                self._try_dock(quiet=True, profile_override=target)
            return
        profile = self._selected_profile()
        if profile is None or profile["id"] in self._embed_suppressed:
            return
        if self._dock.is_docked():
            if self._dock_profile_id != profile["id"]:
                old_hwnd = self._dock.docked_hwnd
                self._undock()
                if old_hwnd:
                    self._park_window(old_hwnd)
                self._try_dock(quiet=True)
            return
        try:
            running = self._manager.is_running(profile)
        except Exception:
            running = False
        if running:
            self._try_dock(quiet=True)

    def _park_window(self, hwnd: int):
        """Đỗ cửa sổ Chrome vừa gỡ nhúng: theo tuỳ chọn “🙈 Ngoài màn
        hình” (mặc định BẬT) → đưa ra ngoài phạm vi màn hình để không
        bao giờ hiện trình duyệt ngoài app; tắt tuỳ chọn → thu nhỏ
        xuống taskbar như trước."""
        if bool(self._settings.get("ui_browser_offscreen", True)):
            docking.park_window(hwnd)  # V6.7: ngoài màn hình + khỏi taskbar
        else:
            docking.minimize_window(hwnd)

    # ------------------------------------------------------------------ #
    # V5.2 — Chỉ nhúng + zoom đúng cài đặt ở mọi lần nhúng
    # ------------------------------------------------------------------ #
    def _show_dock_placeholder(self, text: str):
        """Hiện khung giữ chỗ lỗi nhúng TRONG khung nhúng (kèm nút
        Nhúng lại) — trạng thái LỖI của vùng trình duyệt: nói rõ
        hỏng gì, vì sao, và làm gì tiếp theo (skill trạng thái/lỗi)."""
        placeholder = getattr(self, "dock_placeholder", None)
        if placeholder is None:
            return
        if self.dock_placeholder_label.text() != text:
            self.dock_placeholder_label.setText(text)
        placeholder.setGeometry(0, 0,
                                self.dock_container.width(),
                                self.dock_container.height())
        placeholder.show()
        placeholder.raise_()

    def _hide_dock_placeholder(self):
        placeholder = getattr(self, "dock_placeholder", None)
        if placeholder is not None:
            placeholder.hide()

    def _apply_embed_zoom(self, profile: dict):
        """Áp zoom ĐÃ LƯU của hồ sơ ngay sau một sự kiện nhúng thành
        công (V5.2): ép buộc (force) vì target CDP vừa gắn là mới —
        mức scale của trang không còn như lần áp trước."""
        self._request_zoom_apply(profile, force=True)

    def _zoom_for_dock_profile(self):
        """Zoom cho hồ sơ đang nhúng ở khung đơn (sau watchdog nhúng
        lại): phiên đăng nhập Muse (profile_override) không có
        slug hồ sơ nên bỏ qua."""
        if self._dock_profile_id is None or self._agent_target is not None:
            return
        try:
            profile = self._store.get_profile(int(self._dock_profile_id))
        except Exception:
            profile = None
        if profile is not None:
            self._apply_embed_zoom(profile)

    def _park_window_later(self, profile: dict, delay_ms: int = 1500):
        """Đỗ khuất cửa sổ của một hồ sơ VỪA ĐƯỢC MỞ nếu sau
        `delay_ms` nó vẫn chưa được nhúng (mở lúc người dùng không
        ở mục Hồ sơ — đường tự mở đầu phiên/tự mở theo việc). Nhúng
        được thì thôi; chưa nhúng được thì cửa sổ không được phép
        đứng ngoài app (luật chỉ-nhúng V5.2)."""
        if self._browsers_hidden():
            return  # V5.3 (A8): chạy ẩn — cửa sổ ĐƯỢC ở ngoài app.
        if not docking.IS_WINDOWS:
            return
        profile_id = int(profile["id"])

        def _check(profile_id=profile_id, profile=profile):
            if getattr(self, "_wall_active", False):
                return  # ô tường phụ trách cửa sổ này
            if self._dock_profile_id == profile_id and self._dock.is_docked():
                return
            try:
                hwnd = docking.find_chrome_window(profile, self._manager)
            except Exception:
                hwnd = None
            if hwnd:
                self._park_window(hwnd)

        QTimer.singleShot(delay_ms, _check)

    def _after_wall_dock(self, running: list[dict]):
        """Sau mỗi lần tường nhúng: (1) ô nào CHƯA nhúng được thì
        đỗ khuất cửa sổ của nó + ghi rõ trạng thái lỗi trên ô;
        (2) ô nào đã nhúng thì áp zoom đã lưu của hồ sơ đó (V5.2)."""
        if self._browsers_hidden():
            return  # V5.3 (A8): chạy ẩn — không đỗ khuất, không zoom nhúng.
        if not docking.IS_WINDOWS:
            return
        undocked = {
            p["id"]: p for p in self.browser_wall.undocked_profiles()
        }
        for profile in running:
            if profile["id"] in undocked:
                try:
                    hwnd = docking.find_chrome_window(
                        profile, self._manager
                    )
                except Exception:
                    hwnd = None
                if hwnd:
                    self._park_window(hwnd)
                tile = self.browser_wall.tiles.get(profile["id"])
                if tile is not None:
                    tile.set_placeholder_text(
                        "Chưa nhúng được cửa sổ này — Chrome của hồ "
                        "sơ đã được giấu sau app (không mở ngoài). "
                        "Thử lại: tắt/bật lại tường trình duyệt "
                        "hoặc bấm ⛶ trên ô khác rồi quay lại."
                    )
            else:
                self._apply_embed_zoom(profile)

    def _try_dock(self, quiet: bool = False, profile_override: dict | None = None):
        if self._browsers_hidden():
            # V5.3 (A8): cổng chặn TRUNG TÂM của chế độ chạy ẩn —
            # mọi đường nhúng (tay, tự động, theo việc) đều qua đây.
            if not quiet:
                self._log_ui(
                    "Đang bật Chạy ẩn ngoài app — tắt “🏃 Chạy ẩn” "
                    "để nhúng trình duyệt vào app."
                )
                self._show_dock_placeholder(HIDDEN_MODE_PLACEHOLDER)
            return
        profile = profile_override or self._selected_profile()
        if profile is None:
            if not quiet:
                self._log_ui("Chọn một hồ sơ trước khi nhúng trình duyệt.")
                self._set_live_tab(TAB_STREAM)
            return
        if not docking.IS_WINDOWS:
            if not quiet:
                self._log_ui(
                    "Nhúng trình duyệt chỉ chạy trên Windows — đang dùng Luồng trực tiếp thay thế."
                )
                self._set_live_tab(TAB_STREAM)
            return
        hwnd = docking.find_chrome_window(profile, self._manager)
        if not hwnd:
            if not quiet:
                self._log_ui(
                    f"Không tìm thấy cửa sổ Chrome của hồ sơ '{profile['label']}' để nhúng — "
                    "hãy bấm Mở trình duyệt trước, hoặc dùng Luồng trực tiếp."
                )
                self._set_live_tab(TAB_STREAM)
            return
        self.dock_container.winId()  # ép tạo native window trước khi lấy HWND
        ok = self._dock.attach(
            hwnd,
            int(self.dock_container.winId()),
            max(50, self.dock_container.width()),
            max(50, self.dock_container.height()),
        )
        if ok:
            self._dock_profile_id = profile["id"]
            self._watchdog.watch(profile, self._manager)
            self._hide_dock_placeholder()
            self._set_live_tab(TAB_EMBED)
            if profile_override is None:
                # V5.2: MỌI lần nhúng thành công đều áp lại zoom đã
                # lưu của hồ sơ (target CDP mới = scale trang reset).
                self._apply_embed_zoom(profile)
            self._log_ui(
                f"Đã nhúng cửa sổ Chrome thật của hồ sơ '{profile['label']}' vào app."
            )
        else:
            # V5.2 (luật CHỈ NHÚNG): gắn cửa sổ thất bại thì cửa sổ
            # Chrome KHÔNG được đứng ngoài app — đỗ khuất nó ngay và
            # hiện trạng thái lỗi + nút "Nhúng lại" TRONG khung
            # nhúng. Bản cũ rơi về Luồng trực tiếp và để cửa sổ
            # Chrome nổi tự do ngoài app.
            self._park_window(hwnd)
            self._show_dock_placeholder(
                f"Chưa nhúng được cửa sổ Chrome của hồ sơ "
                f"'{profile['label']}' vào app. Cửa sổ đã được giấu "
                "sau app (không mở ngoài). Nguyên nhân thường gặp: "
                "Chrome vừa mở chưa ổn định hoặc cửa sổ đang bận. "
                "Đợi vài giây rồi bấm \"Nhúng lại\"."
            )
            if not quiet:
                self._set_live_tab(TAB_EMBED)
                self._log_ui(
                    "Nhúng trình duyệt không thành công — cửa sổ "
                    "Chrome đã được giấu sau app; bấm “Nhúng lại” "
                    "trong khung trình duyệt để thử lại."
                )
        self._sync_toolbar_context()

    def _undock(self):
        self._dock.detach()
        self._watchdog.forget()
        self._dock_profile_id = None

    def _on_dock_resized(self, width: int, height: int):
        if self._dock.is_docked():
            self._dock.sync_size(width, height)
        placeholder = getattr(self, "dock_placeholder", None)
        if placeholder is not None and placeholder.isVisible():
            placeholder.setGeometry(0, 0, width, height)

    def _refresh_still(self):
        if self._last_frame_pixmap is not None and not self._last_frame_pixmap.isNull():
            self.still_label.setPixmap(
                self._last_frame_pixmap.scaled(
                    self.still_label.size(),
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
            )
        else:
            self.still_label.setText("Chưa có khung hình nào để chụp.")

    def _on_save_screenshot(self):
        if self._last_frame_pixmap is None or self._last_frame_pixmap.isNull():
            self._log_ui("Chưa có khung hình trực tiếp nào để lưu ảnh.")
            return
        folder = config.screenshots_dir()
        folder.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        profile = self._selected_profile()
        slug = profile["slug"] if profile else "frame"
        path = folder / f"{stamp}_{slug}.png"
        if self._last_frame_pixmap.save(str(path), "PNG"):
            self._refresh_still()
            self._log_ui(f"Đã lưu ảnh chụp khung trực tiếp: {path}")
        else:
            self._log_ui(f"Lưu ảnh chụp thất bại: {path}")

    def _show_live_placeholder(self, text: str):
        self.live_label.setText(
            "<div style='text-align:center;'>"
            "<span style='font-size:46px; color:#23261F;'>◎</span><br/><br/>"
            f"<span style='font-size:13px; color:#9BA196;'>{html.escape(text)}</span>"
            "</div>"
        )

    def _on_page_url(self, url: str):
        self._current_url = url
        self.live_url.setToolTip(url)
        metrics = self.live_url.fontMetrics()
        width = self.live_url.width()
        available = width - 8 if width >= 80 else 460
        self.live_url.setText(metrics.elidedText(url, Qt.ElideMiddle, max(120, available)))

    def _restart_live_worker(self, profile: dict):
        self._stop_live_worker()
        self._has_frame = False
        self._frame_times.clear()
        self._last_frame_pixmap = None
        self.fps_label.setText("— fps")
        self.live_dot.set_active(False)
        self.live_label.clear_frame()
        self.live_profile_label.setText(profile["label"])
        self.live_gmail_label.setText(profile["gmail"])
        self._current_url = ""
        self.live_url.setText("")
        self.live_url.setToolTip("")
        self._show_live_placeholder("Chưa mở trình duyệt cho hồ sơ này")
        self._live_worker = LiveStreamWorker(
            profile,
            self._manager,
            fps_active=float(self._settings.get("live_fps_active", 5.0)),
            fps_idle=float(self._settings.get("live_fps_idle", 1.0)),
            parent=self,
        )
        self._live_worker.frame.connect(self._on_frame)
        self._live_worker.status.connect(self._on_live_status)
        self._live_worker.page_url.connect(self._on_page_url)
        self._live_worker.set_active(self.isActiveWindow())
        self._live_worker.start()

    def _stop_live_worker(self):
        """Dừng worker luồng trực tiếp HIỆN TẠI một cách an toàn.

        Vòng lặp của worker có thể đang kẹt trong một lệnh CDP (timeout
        tới 15s, chưa kể tự nối lại) nên ``wait()`` ngắn hạn rất dễ quá
        giờ. Bản cũ bỏ qua kết quả wait() rồi gán None luôn — QThread
        mất tham chiếu Python cuối cùng trong lúc còn chạy, Qt huỷ
        C++ QThread giữa chừng → sập app ngay khi quét xong. Nay:
        chờ được thì deleteLater; quá giờ thì chuyển worker vào danh
        sách "đang nghỉ hưu" (giữ tham chiếu mạnh) và chỉ dọn khi tín
        hiệu ``finished`` về thật."""
        worker = self._live_worker
        if worker is None:
            return
        self._live_worker = None
        worker.stop()
        for signal, slot in (
            (worker.frame, self._on_frame),
            (worker.status, self._on_live_status),
            (worker.page_url, self._on_page_url),
        ):
            try:
                signal.disconnect(slot)
            except Exception:
                pass
        if worker.wait(3000):
            worker.deleteLater()
            return
        self._retiring_live_workers.append(worker)
        worker.finished.connect(
            lambda w=worker: self._reap_live_worker(w)
        )

    def _reap_live_worker(self, worker: LiveStreamWorker):
        """Một worker "đang nghỉ hưu" đã kết thúc thật — giờ mới an
        toàn để thả tham chiếu và deleteLater."""
        if worker in self._retiring_live_workers:
            self._retiring_live_workers.remove(worker)
        worker.deleteLater()

    def _on_frame(self, jpeg_bytes: bytes):
        now = time.monotonic()
        self._frame_times.append(now)
        while self._frame_times and now - self._frame_times[0] > 2.0:
            self._frame_times.popleft()
        pixmap = QPixmap()
        if pixmap.loadFromData(jpeg_bytes):
            self._has_frame = True
            self._last_frame_pixmap = pixmap
            self.live_dot.set_active(True)
            self.live_label.set_source_pixmap(pixmap)
            fps_text = "— fps"
            if len(self._frame_times) >= 2:
                span = self._frame_times[-1] - self._frame_times[0]
                if span > 0:
                    fps_text = f"{(len(self._frame_times) - 1) / span:.1f} fps"
            self.fps_label.setText(
                f"{fps_text} · {pixmap.width()}×{pixmap.height()}"
            )

    def _on_live_status(self, message: str):
        if not self._has_frame:
            self._show_live_placeholder(message)

    # ------------------------------------------------------------------ #
    # Dữ liệu hiển thị
    # ------------------------------------------------------------------ #
    def _session_state(self, profile: dict, has_channels: bool) -> str:
        state = self._session_states.get(profile["id"])
        if state:
            return state
        return "in" if has_channels else "unknown"

    def _make_profile_card(self, profile: dict, channels: list[dict]) -> ProfileCard:
        card = ProfileCard(profile["id"])
        # V5.3.2 (M-PROFILE-EDIT): thẻ có thêm HÀNG THAO TÁC riêng
        # ở đáy (nút Sửa hồ sơ + nút ⋯) — xếp cùng hàng ngang với
        # avatar/cột chữ như bản đầu thì cột hồ sơ ~320px không đủ
        # bề ngang: nút Sửa bị cắt chữ và nút ⋯ bị đẩy khỏi thẻ
        # (bắt được ở render nghiệm thu, đúng luật không cắt chữ).
        layout = QVBoxLayout(card)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(8)
        top_row = QHBoxLayout()
        top_row.setSpacing(10)
        top_row.addWidget(theme.avatar(profile["label"], profile["slug"]))
        layout.addLayout(top_row)

        col = QVBoxLayout()
        col.setSpacing(3)
        name = QLabel(profile["label"])
        name.setObjectName("CardTitle")
        col.addWidget(name)
        from .. import platforms as _platforms

        meta = _platforms.info(_platforms.of(profile))
        gmail = QLabel(f"{meta['icon']} {meta['label']} · {profile['gmail'] or '—'}"
                       if _platforms.of(profile) != "youtube" else (profile["gmail"] or "—"))
        gmail.setObjectName("Muted12")
        col.addWidget(gmail)

        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        state = self._session_state(profile, bool(channels))
        pill_text = {
            "in": "Đã đăng nhập",
            "out": "Chưa đăng nhập",
            "unknown": "Chưa rõ phiên",
        }[state]
        bottom.addWidget(theme.pill(pill_text, state))
        if profile["paused"]:
            bottom.addWidget(theme.pill("Tạm dừng", "paused"))
        bottom.addStretch(1)
        count = QLabel(f"{len(channels)} kênh")
        count.setObjectName("Faint12")
        bottom.addWidget(count)
        col.addLayout(bottom)

        top_row.addLayout(col, 1)
        # V5.3.2 (M-PROFILE-EDIT): nút SỬA HỒ SƠ nhìn thấy được
        # ngay trên thẻ — kiểu RowAction gọn, chiều cao đọc từ
        # Cài đặt (theme.row_action_height, cùng đường V5.3.1 với
        # nút trong dòng bảng lệnh) nên chữ không bị cắt và đổi
        # cài đặt là thẻ dựng lại theo. Bấm = on_edit_profile,
        # cùng luồng với mục "✎ Sửa hồ sơ…" trong menu chuột phải.
        edit_btn = QPushButton("✎ Sửa hồ sơ")
        edit_btn.setObjectName("RowAction")
        edit_btn.setFixedHeight(theme.row_action_height(self._settings))
        edit_btn.setToolTip(
            "Sửa nhãn, Gmail và ghi chú của hồ sơ này"
        )
        edit_btn.clicked.connect(
            lambda _=False, p=profile["id"]: self.on_edit_profile(p)
        )
        # V3.7: nút ⋯ trên thẻ + menu chuột phải — mọi thao tác của hồ sơ.
        menu_btn = QPushButton("⋯")
        menu_btn.setObjectName("CardMenuBtn")
        menu_btn.setFixedSize(30, 30)
        menu_btn.setToolTip("Thao tác với hồ sơ này (hoặc chuột phải vào thẻ)")
        pid = profile["id"]
        menu_btn.clicked.connect(
            lambda _=False, p=pid, b=menu_btn: self._show_profile_menu(
                p, b.mapToGlobal(b.rect().bottomLeft())
            )
        )
        actions_row = QHBoxLayout()
        actions_row.setSpacing(8)
        actions_row.addStretch(1)
        actions_row.addWidget(edit_btn)
        actions_row.addWidget(menu_btn)
        layout.addLayout(actions_row)
        card.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        card.customContextMenuRequested.connect(
            lambda pos, p=pid, c=card: self._show_profile_menu(
                p, c.mapToGlobal(pos)
            )
        )
        card.clicked.connect(self._on_card_clicked)
        return card

    def _show_profile_menu(self, profile_id: int, global_pos):
        """Menu thao tác của MỘT hồ sơ (icon + text): chọn hồ sơ đó trước
        rồi gọi đúng các nút xử lý dùng chung."""
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        if self._current_profile_id != profile_id:
            self._on_card_clicked(profile_id)
        menu = QMenu(self)
        actions = [
            ("🌐 Mở trình duyệt", self.btn_open),
            ("🔐 Đăng nhập", self.btn_login),
            ("🔍 Quét kênh", self.btn_scan),
            (
                "▶ Bật hồ sơ" if profile["paused"] else "⏸ Tạm dừng hồ sơ",
                self.btn_pause,
            ),
            ("🍪 Nhập cookies… (tự đăng nhập)", self.btn_import_cookies),
            ("🍪 Nạp cookies đã lưu", self.btn_apply_cookies),
        ]
        for text, button in actions:
            act = menu.addAction(text)
            act.setEnabled(button.isEnabled())
            act.triggered.connect(lambda _=False, b=button: b.click())
        # V5.3.2 (M-PROFILE-EDIT): mục sửa trong menu — cùng luồng
        # on_edit_profile với nút "✎ Sửa hồ sơ" nhìn thấy trên thẻ.
        act = menu.addAction("✎ Sửa hồ sơ…")
        act.triggered.connect(
            lambda _=False, p=profile_id: self.on_edit_profile(p)
        )
        menu.addSeparator()
        act = menu.addAction("🗑 Xoá hồ sơ")
        act.setEnabled(self.btn_delete.isEnabled())
        act.triggered.connect(lambda _=False: self.btn_delete.click())
        menu.exec(global_pos)

    def refresh_profiles(self, keep_selection: bool = True):
        selected_id = self._current_profile_id if keep_selection else None
        profiles = self._store.list_profiles()
        valid_ids = {p["id"] for p in profiles}
        if selected_id is not None and selected_id not in valid_ids:
            selected_id = None
            self._current_profile_id = None

        box = QWidget()
        box.setStyleSheet("background: transparent;")
        box_layout = QVBoxLayout(box)
        box_layout.setContentsMargins(0, 0, 0, 0)
        box_layout.setSpacing(10)
        self._card_widgets = {}
        for profile in profiles:
            channels = self._store.list_channels(profile["id"])
            card = self._make_profile_card(profile, channels)
            self._card_widgets[profile["id"]] = card
            box_layout.addWidget(card)
        if not profiles:
            empty = QLabel("Chưa có hồ sơ nào.\nBấm “Thêm hồ sơ” để bắt đầu.")
            empty.setObjectName("Muted")
            empty.setAlignment(Qt.AlignCenter)
            box_layout.addWidget(empty)
        box_layout.addStretch(1)
        self.cards_scroll.setWidget(box)

        self._update_card_selection()
        self._update_action_buttons()
        if self._current_profile_id is not None:
            self._refresh_right_pane(self._current_profile_id)

    def _update_card_selection(self):
        for pid, card in self._card_widgets.items():
            card.set_selected(pid == self._current_profile_id)

    def _update_action_buttons(self):
        profile = self._selected_profile()
        if profile is not None and profile["paused"]:
            self.btn_pause.setText("Bật hồ sơ")
        else:
            self.btn_pause.setText("Tạm dừng hồ sơ")

    def _refresh_right_pane(self, profile_id: int):
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        channels = self._store.list_channels(profile_id)
        # V4.3.2 (F4): nạp hàng loạt — tắt repaint/signals của bảng kênh.
        from .table_persist import batch_update

        with batch_update(self.table):
            self.table.setRowCount(len(channels))
            avatar_jobs = []
            for row, ch in enumerate(channels):
                # Subs kèm mũi tên tăng/giảm so với hôm qua (từ snapshots).
                subs_text = _fmt_num(ch["subs"])
                try:
                    delta = self._store.channel_growth(profile_id, ch["channel_id"])[
                        "subs_delta_1d"
                    ]
                except Exception:
                    delta = None
                if delta:
                    subs_text += f" ▲{delta}" if delta > 0 else f" ▼{abs(delta)}"
                values = [
                    ch["name"],
                    ch["handle"],
                    subs_text,
                    _fmt_num(ch["video_count"]),
                    ch["niche"] or "—",
                    _fmt_ts(ch["last_scan_at"]),
                ]
                logo_item = QTableWidgetItem()
                icon = self._avatar_icon(ch)
                if icon is not None:
                    logo_item.setIcon(icon)
                elif ch.get("avatar_url"):
                    avatar_jobs.append(ch)
                logo_item.setToolTip(ch["name"])
                logo_item.setData(Qt.ItemDataRole.UserRole, ch["channel_id"])
                self.table.setItem(row, 0, logo_item)
                for col, value in enumerate(values, start=1):
                    self.table.setItem(row, col, QTableWidgetItem(value))
        if avatar_jobs:
            self._fetch_avatars(avatar_jobs)
        self._refresh_cookie_status(profile)
        self._refresh_agent_owner(profile)
        # Trạng thái rỗng: 0 kênh -> một dòng hướng dẫn thay vì bảng trắng.
        self.channel_stack.setCurrentIndex(0 if channels else 1)
        self.journal_view.clear()
        for entry in self._store.list_journal(profile_id):
            self._append_journal_line(_fmt_ts(entry["ts"]), entry["message"])

    # ------------------------------------------------------------------ #
    # Logo kênh (avatar) — tải nền về data/avatars/, hiện ở cột đầu bảng
    # ------------------------------------------------------------------ #
    def _avatar_path(self, channel_id: str) -> Path:
        safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in channel_id)
        return config.data_dir() / "avatars" / f"{safe}.img"

    def _avatar_icon(self, channel: dict):
        channel_id = channel.get("channel_id") or ""
        if not channel_id:
            return None
        if channel_id in self._avatar_icons:
            return self._avatar_icons[channel_id]
        path = self._avatar_path(channel_id)
        if path.exists():
            icon = QIcon(str(path))
            self._avatar_icons[channel_id] = icon
            return icon
        return None

    def _fetch_avatars(self, channels: list[dict]):
        jobs = []
        for ch in channels:
            channel_id = ch.get("channel_id") or ""
            url = ch.get("avatar_url") or ""
            if not channel_id or not url.startswith("http"):
                continue
            if channel_id in self._avatar_pending:
                continue
            self._avatar_pending.add(channel_id)
            jobs.append((channel_id, url, str(self._avatar_path(channel_id))))
        if not jobs:
            return
        worker = _AvatarWorker(jobs, parent=self)
        worker.fetched.connect(self._on_avatar_fetched)
        worker.finished.connect(lambda w=worker: self._avatar_workers.remove(w) if w in self._avatar_workers else None)
        self._avatar_workers.append(worker)
        worker.start()

    def _on_avatar_fetched(self, channel_id: str, path: str):
        self._avatar_pending.discard(channel_id)
        if path:
            self._avatar_icons[channel_id] = QIcon(path)
            if self._current_profile_id is not None:
                self._refresh_right_pane(self._current_profile_id)

    def _append_journal_line(self, ts_text: str, message: str):
        cursor = self.journal_view.textCursor()
        cursor.movePosition(QTextCursor.End)
        ts_format = QTextCharFormat()
        ts_format.setForeground(QColor(theme.MUTED))
        msg_format = QTextCharFormat()
        msg_format.setForeground(QColor(theme.TEXT))
        if not self.journal_view.document().isEmpty():
            cursor.insertText("\n")
        cursor.insertText(f"[{ts_text}] ", ts_format)
        cursor.insertText(message, msg_format)
        self.journal_view.setTextCursor(cursor)

    # ------------------------------------------------------------------ #
    # Chọn hồ sơ
    # ------------------------------------------------------------------ #
    def _selected_profile(self) -> dict | None:
        if self._current_profile_id is None:
            return None
        return self._store.get_profile(self._current_profile_id)

    def _on_card_clicked(self, profile_id: int):
        if profile_id == self._current_profile_id:
            return
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        # Người dùng quay lại làm việc với hồ sơ kênh: nhường khung
        # nhúng khỏi cửa sổ đăng nhập Muse (probe vẫn chạy nền).
        self._agent_target = None
        if self._dock.is_docked() and not self._embed_always():
            self._undock()
            self._set_live_tab(TAB_STREAM)
        # Đang bật tự-nhúng: KHÔNG gỡ ở đây — _auto_dock_tick sẽ tự đổi
        # nhúng sang hồ sơ mới và thu nhỏ cửa sổ cũ về taskbar (V3.2).
        self._embed_suppressed.discard(profile_id)
        self._current_profile_id = profile_id
        self._update_zoom_label()
        self._update_card_selection()
        self._update_action_buttons()
        self._refresh_right_pane(profile_id)
        self._restart_live_worker(profile)
        if self._theater:
            self.theater_label.setText(
                f"⛶ Toàn màn hình trình duyệt — {profile['label']}"
            )

    # ------------------------------------------------------------------ #
    # Thao tác hồ sơ
    # ------------------------------------------------------------------ #
    def on_add_profile(self):
        dialog = AddProfileDialog(self)
        if dialog.exec() != AddProfileDialog.Accepted:
            return
        details = dialog.details()
        label, gmail, note = details["label"], details["gmail"], details["note"]
        platform = details.get("platform") or "youtube"
        try:
            profile = self._store.add_profile(label, gmail, note, platform=platform)
        except ValueError as exc:
            # Mỗi Gmail chỉ một hồ sơ riêng (V3.2) — báo rõ, không tạo trùng.
            QMessageBox.warning(self, "Gmail đã có hồ sơ", str(exc))
            self._log_ui(str(exc))
            return
        message = (
            f"Đã thêm hồ sơ '{profile['label']}' ({profile['gmail']}) — "
            f"slug {profile['slug']}, cổng debug {profile['port']}, "
            f"thư mục Chrome: {config.profile_dir(profile['slug'])}"
        )
        self._store.append_journal(message, profile["id"])
        self._log_ui(message)
        # V4.1.1: hồ sơ mới có gmail trùng email một tài khoản Muse
        # sẵn có → tự phân công ngay, khỏi chờ nhịp dispatcher.
        try:
            auto_pairs = self._store.auto_assign_email_matches()
        except Exception:
            auto_pairs = []
        if auto_pairs:
            self._log_ui(
                f"Tự phân công theo email: {len(auto_pairs)} hồ sơ đã "
                "có Muse phụ trách (trùng email đăng nhập)."
            )

        # Phần đăng nhập kèm theo form (V3.4) — dùng chung với
        # luồng SỬA hồ sơ qua _save_profile_login_material.
        has_login_material = self._save_profile_login_material(
            profile, details, source="import:add-profile",
            blank_cookies_note=(
                "hồ sơ vẫn được tạo, đăng nhập bằng cách khác."
            ),
        )

        self._current_profile_id = profile["id"]
        self.refresh_profiles()
        self._restart_live_worker(profile)
        if platform != "youtube":
            # V7.0: Facebook/TikTok — đăng nhập bằng cookie dán vào (hoặc file) rồi quét page/kênh.
            if details.get("cookie_text") or has_login_material:
                self._cookie_login(profile, details.get("cookie_text") or None, then_scan=True)
            return
        if has_login_material:
            # Có sẵn cookies/mật khẩu -> thử đăng nhập ngay trong trình
            # duyệt nhúng của hồ sơ (yêu cầu V3.4).
            self._submit_login(profile)

    def _cookie_login(self, profile: dict, text: str | None = None, then_scan: bool = True):
        """V7.0: đăng nhập Facebook/TikTok bằng cookie (nền), xong thì quét page/kênh."""
        from .. import platforms

        manager, store = self._manager, self._store
        logs = []

        def job_fn(_token, profile=profile, text=text):
            result = platforms.login_with_cookies(store, profile, manager, text, say=logs.append)
            if result.get("status") == "ok" and then_scan:
                result["scan"] = platforms.scan_profile(store, profile, manager, log=logs.append)
            return result

        def on_done(job, pid=profile["id"], name=profile["label"]):
            result = job.result or {}
            self._bg_push_result.emit(
                f"🍪 {name}: {result.get('message') or job.error or 'xong'}"
                + (f" — {result['scan'].get('message')}" if isinstance(result.get("scan"), dict) else ""))

        self._log_ui(f"🍪 Đang đăng nhập {platforms.label(platforms.of(profile))} bằng cookie cho '{profile['label']}'…")
        self._runner.submit_custom(job_fn, profile_id=profile["id"], kind="cookie_login", on_done=on_done)

    def _open_cookie_login_dialog(self, profile: dict | None = None):
        from PySide6.QtWidgets import QDialog, QDialogButtonBox, QPlainTextEdit, QVBoxLayout as _V

        from .. import platforms

        profile = profile or self._selected_profile()
        if profile is None:
            self._log_ui("Chọn một hồ sơ trước.")
            return
        platform = platforms.of(profile)
        dialog = QDialog(self)
        dialog.setWindowTitle(f"🍪 Đăng nhập {platforms.label(platform)} bằng cookie — {profile['label']}")
        dialog.setMinimumWidth(560)
        lay = _V(dialog)
        lay.addWidget(QLabel(
            "Dán cookie (chuỗi 'c_user=…; xs=…', JSON EditThisCookie/J2TEAM, hoặc cookies.txt). "
            "App lọc đúng domain, nạp vào trình duyệt của hồ sơ, kiểm tra phiên rồi quét page/kênh.\n"
            "Cookie chỉ lưu trên máy này, không gửi cho Muse."))
        edit = QPlainTextEdit()
        edit.setMinimumHeight(160)
        lay.addWidget(edit)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Đăng nhập + quét")
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        lay.addWidget(buttons)
        if dialog.exec() == QDialog.Accepted:
            text = edit.toPlainText().strip()
            self._cookie_login(profile, text or None, then_scan=True)

    def _save_profile_login_material(
        self, profile: dict, details: dict, source: str,
        blank_cookies_note: str,
    ) -> bool:
        """Lưu vật liệu đăng nhập kèm form hồ sơ (V3.4): cookies có
        sẵn -> kho cookies của hồ sơ; mật khẩu -> kho mật khẩu
        riêng. Dùng chung cho THÊM và SỬA hồ sơ (V5.3.2) — một
        đường duy nhất. Giá trị bí mật không bao giờ vào nhật ký —
        chỉ ghi trạng thái có/không. Trả True khi có ít nhất một
        vật liệu đã lưu."""
        label = profile["label"]
        has_login_material = False
        cookies_path = details.get("cookies_path") or ""
        if cookies_path:
            try:
                cookies = cookies_vault.parse_cookies_bytes(
                    Path(cookies_path).read_bytes()
                )
                if cookies:
                    summary = cookies_vault.save_cookies(
                        profile["slug"], cookies, source=source
                    )
                    self._log_ui(
                        f"Hồ sơ '{label}': đã lưu {summary['count']} cookies "
                        "từ file kèm theo — sẽ đăng nhập bằng cookies."
                    )
                    has_login_material = True
                else:
                    QMessageBox.warning(
                        self,
                        "File cookies trống",
                        "Không đọc được cookie nào trong file đã chọn — "
                        + blank_cookies_note,
                    )
            except OSError as exc:
                QMessageBox.warning(self, "Không đọc được file cookies", str(exc))
        if details.get("password"):
            credentials_vault.save_password(
                profile["slug"], profile["gmail"], details["password"]
            )
            self._log_ui(
                f"Hồ sơ '{label}': đã lưu mật khẩu vào kho riêng của hồ sơ "
                "(không hiển thị) — app sẽ tự điền khi đăng nhập."
            )
            has_login_material = True
        return has_login_material

    def on_edit_profile(self, profile_id: int):
        """Sửa hồ sơ (V5.3.2 — M-PROFILE-EDIT): mở ĐÚNG hộp thoại
        hồ sơ dùng chung (AddProfileDialog ở chế độ sửa, điền sẵn
        dữ liệu của hồ sơ này) — nút "✎ Sửa hồ sơ" trên thẻ và mục
        cùng tên trong menu chuột phải đều gọi vào đây. Lưu xong
        bảng/thẻ phản ánh giá trị mới ngay (refresh_profiles)."""
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        dialog = AddProfileDialog(self, profile=profile)
        if dialog.exec() != AddProfileDialog.Accepted:
            return
        details = dialog.details()
        try:
            updated = self._store.update_profile(
                profile_id,
                label=details["label"],
                gmail=details["gmail"],
                note=details["note"],
            )
        except ValueError as exc:
            QMessageBox.warning(self, "Không sửa được hồ sơ", str(exc))
            self._log_ui(str(exc))
            return
        # Vật liệu đăng nhập nhập MỚI trong form sửa (mật khẩu gõ
        # lại / file cookies chọn lại) đi đúng đường của luồng
        # thêm; để trống = giữ nguyên kho cũ, không đụng.
        self._save_profile_login_material(
            updated, details, source="import:edit-profile",
            blank_cookies_note=(
                "hồ sơ giữ nguyên, đăng nhập bằng cách khác."
            ),
        )
        message = (
            f"Đã sửa hồ sơ '{updated['label']}' ({updated['gmail']})."
        )
        self._store.append_journal(message, updated["id"])
        self._log_ui(message)
        self.refresh_profiles()

    # ------------------------------------------------------------------ #
    # Đăng nhập tài khoản trong trình duyệt nhúng (V3.4)
    # ------------------------------------------------------------------ #
    def _submit_login(self, profile: dict):
        from .. import platforms as _platforms

        if _platforms.of(profile) != "youtube":
            # V7.0: Facebook/TikTok đăng nhập bằng COOKIE (không dùng luồng Google).
            self._cookie_login(profile, None, then_scan=False)
            return
        profile_id = profile["id"]
        manager = self._manager

        def job_fn(_token, profile=profile):
            try:
                manager.launch(profile)
                client = manager.connect_page(profile)
            except Exception as exc:
                return {
                    "status": "error",
                    "message": f"Hồ sơ '{profile['label']}': không mở được Chrome — {exc}",
                }
            try:
                return login_helper.attempt_login(
                    client, profile, say=self._runner.log_line.emit
                )
            finally:
                client.close()

        def on_done(job, profile_id=profile_id):
            result = job.result if isinstance(job.result, dict) else {
                "status": "error",
                "message": job.error or "Đăng nhập thất bại.",
            }
            self._bg_login_finished.emit(result, profile_id)

        self._runner.submit_custom(
            job_fn, profile_id=profile_id, kind="login", on_done=on_done
        )
        self._log_ui(
            f"Đang đăng nhập hồ sơ '{profile['label']}' trong trình duyệt nhúng…"
        )

    def _on_login_job_finished(self, result: dict, profile_id: int):
        profile = self._store.get_profile(profile_id)
        label = profile["label"] if profile else str(profile_id)
        message = result.get("message") or f"Đăng nhập hồ sơ '{label}' xong."
        self._store.append_journal(message, profile_id)
        self._log_ui(message)
        if result.get("status") in ("already", "cookies", "password"):
            self._session_states[profile_id] = "in"
            if profile is not None:
                self._refresh_cookie_status(profile)
        elif result.get("status") in ("needs_user", "needs_manual"):
            self._log_ui(
                f"Hồ sơ '{label}': cần hoàn tất đăng nhập trong "
                "trình duyệt nhúng."
            )
        elif result.get("status") == "wrong_password":
            self._session_states[profile_id] = "out"
        # V3.7: kết quả đăng nhập phải HIỆN LÊN tab Hồ sơ — vẽ lại thẻ để
        # chip phiên (Đã đăng nhập / Chưa đăng nhập) và panel phải cập nhật
        # ngay, không bắt người dùng tự đoán.
        self.refresh_profiles()

    def on_login(self):
        profile = self._require_profile()
        if profile is None:
            return
        if profile["paused"]:
            self._log_ui(f"Hồ sơ '{profile['label']}' đang tạm dừng — không đăng nhập.")
            return
        self._submit_login(profile)

    # ------------------------------------------------------------------ #
    # Đăng nhập muse.ai cho từng TÀI KHOẢN CLAUDE (V3.5, lớp B)
    # ------------------------------------------------------------------ #
    def _login_agent(self, agent: dict):
        """Mở Chrome RIÊNG của tài khoản Muse này (data/agents/<slug>)
        tại muse.ai, nhúng vào khung xem để người dùng tự đăng nhập.
        App dò trạng thái: đăng nhập xong thì ghi nhận ✅ và trả khung
        nhúng về cho hồ sơ kênh."""
        pseudo = agent_browser.agent_profile(agent)
        try:
            self._store.set_agent_web_state(agent["id"], "waiting")
        except Exception:
            pass
        self.agents_panel.refresh()
        manager = self._manager

        def job_fn(_token, pseudo=pseudo):
            # Cửa sổ ĐĂNG NHẬP phải hiện cho người dùng thao tác —
            # không mở thu nhỏ kể cả khi chạy ẩn đang bật (V5.3 A8).
            state = manager.launch(pseudo, hidden=True)  # V6.7: nhúng vào khung đăng nhập, không bật ra ngoài
            try:
                client = manager.connect_page(pseudo)
                try:
                    client.navigate(agent_browser.MUSE_URL)
                finally:
                    client.close()
            except Exception:
                pass
            return state

        def on_done(job, agent_id=agent["id"]):
            self._bg_agent_login.emit(agent_id, job.error or (job.result or "ok"))

        self._runner.submit_custom(
            job_fn, profile_id=pseudo["id"], kind="agent_login", on_done=on_done
        )
        self._log_ui(
            f"Đang mở Chrome riêng của Muse '{agent['name']}' tại muse.ai…"
        )

    def _on_agent_login_opened(self, agent_id: int, result):
        agent = self._store.get_agent(agent_id)
        name = agent["name"] if agent else str(agent_id)
        if isinstance(result, str) and result not in ("launched", "already_running", "ok"):
            self._log_ui(f"Mở Chrome cho Muse '{name}' thất bại: {result}")
            try:
                self._store.set_agent_web_state(agent_id, "unknown")
            except Exception:
                pass
            self.agents_panel.refresh()
            return
        if agent is None:
            return
        self._agent_target = agent_browser.agent_profile(agent)
        self._agent_probe_started = time.monotonic()
        self._agent_probe_busy = False
        self._agent_probe_timer.start()
        self._switch_section(SEC_PROFILES)
        self._try_dock(profile_override=self._agent_target, quiet=True)
        message = (
            f"Chrome riêng của Muse '{name}' đang mở tại muse.ai trong "
            "khung nhúng — hãy đăng nhập bằng chính tài khoản Muse đó; "
            "app sẽ tự nhận biết khi đăng nhập xong."
        )
        self._store.append_journal(message)
        self._log_ui(message)

    def _agent_probe_tick(self):
        target = self._agent_target
        if target is None:
            self._agent_probe_timer.stop()
            return
        agent_id = int(target["agent_id"])
        if time.monotonic() - self._agent_probe_started > 600:
            self._agent_probe_timer.stop()
            self._log_ui(
                "Đã 10 phút chờ đăng nhập muse.ai — ngừng tự kiểm tra; "
                "đăng nhập xong thì mở lại mục Tài khoản Muse để app ghi nhận."
            )
            return
        try:
            running = self._manager.is_running(target)
        except Exception:
            running = False
        if not running:
            self._agent_probe_timer.stop()
            self._agent_target = None
            try:
                self._store.set_agent_web_state(agent_id, "out")
            except Exception:
                pass
            self.agents_panel.refresh()
            self._log_ui("Cửa sổ đăng nhập muse.ai đã đóng — chưa ghi nhận đăng nhập.")
            return
        if self._agent_probe_busy:
            return
        self._agent_probe_busy = True
        manager = self._manager

        def job_fn(_token, target=target):
            client = manager.connect_page(target)
            try:
                state = client.evaluate(agent_browser.MUSE_STATE_JS, timeout=15)
            finally:
                client.close()
            return agent_browser.classify_muse_state(state)

        def on_done(job, agent_id=agent_id):
            self._agent_probe_busy = False
            self._bg_agent_probe.emit(agent_id, job.result or "unknown")

        self._runner.submit_custom(
            job_fn, profile_id=target["id"], kind="agent_probe", on_done=on_done
        )

    def _on_agent_probe_result(self, agent_id: int, classification: str):
        if classification != "in":
            return
        agent = self._store.get_agent(agent_id)
        name = agent["name"] if agent else str(agent_id)
        try:
            self._store.set_agent_web_state(agent_id, "in")
        except Exception:
            pass
        self._agent_probe_timer.stop()
        self._agent_target = None
        self.agents_panel.refresh()
        message = (
            f"Muse '{name}': ĐÃ ĐĂNG NHẬP muse.ai trong Chrome riêng — "
            "phiên được giữ lại cho lần sau."
        )
        self._store.append_journal(message)
        self._log_ui(message)

    # ------------------------------------------------------------------ #
    # V6.2: ĐĂNG NHẬP HÀNG LOẠT muse.ai qua hộp thư tinyhost.shop
    # ------------------------------------------------------------------ #
    def _bulk_login_agents(self, agents, options: dict):
        """Handler của nút 🔐 Đăng nhập hàng loạt. ``agents=None`` +
        options['stop'] → yêu cầu dừng lượt đang chạy."""
        if options.get("stop"):
            self._bulk_login_stop.set()
            self._log_ui("Đã yêu cầu dừng đăng nhập hàng loạt — dừng sau bước hiện tại.")
            return True
        if self._bulk_login_active:
            self._log_ui("Đang có một lượt đăng nhập hàng loạt chạy — đợi xong hoặc bấm Dừng.")
            return False
        self._bulk_login_active = True
        self._bulk_login_stop.clear()
        for agent in agents:
            try:
                self._store.set_agent_web_state(agent["id"], "waiting")
            except Exception:
                pass
        self.agents_panel.refresh()
        manager = self._manager
        stop = self._bulk_login_stop
        close_on_success = bool(options.get("close_on_success", True))
        hidden = bool(options.get("hidden", False))
        snapshot = [dict(a) for a in agents]

        # Chạy trên LUỒNG RIÊNG (không chiếm một luồng của JobEngine
        # suốt nhiều phút — quét/kiểm tra kênh vẫn chạy song song).
        def worker():
            from .. import muse_autologin

            try:
                results = muse_autologin.run_batch(
                    manager,
                    snapshot,
                    say=self._bg_bulk_login_msg.emit,
                    should_stop=stop.is_set,
                    on_result=lambda agent, result: self._bg_bulk_login_result.emit(
                        int(agent["id"]), result
                    ),
                    close_on_success=close_on_success,
                    hidden=hidden,
                )
            except Exception as exc:  # noqa: BLE001
                results = {"error": f"{type(exc).__name__}: {exc}"}
            self._bg_bulk_login_done.emit(results)

        threading.Thread(target=worker, daemon=True, name="muse-bulk-login").start()
        return True

    def _on_bulk_login_result(self, agent_id: int, result):
        status = (result or {}).get("status")
        state = {"ok": "in", "already": "in", "needs_user": "waiting"}.get(status, "out")
        try:
            self._store.set_agent_web_state(agent_id, state)
        except Exception:
            pass
        agent = self._store.get_agent(agent_id)
        name = agent["name"] if agent else str(agent_id)
        icon = {"ok": "✅", "already": "✅", "needs_user": "✋", "stopped": "⏹"}.get(status, "❌")
        message = f"{icon} Đăng nhập muse.ai — Muse '{name}': {(result or {}).get('message', '')}"
        try:
            self._store.append_journal(message)
        except Exception:
            pass
        self._log_ui(message)
        self.agents_panel.refresh()

    def _on_bulk_login_done(self, results):
        self._bulk_login_active = False
        self._bulk_login_stop.clear()
        self.agents_panel.set_bulk_login_running(False)
        # Tài khoản còn 'waiting' mà chưa chạy tới (dừng giữa chừng) → trả về 'out'.
        done_ids = set()
        if isinstance(results, list):
            done_ids = {r.get("agent_id") for r in results}
        try:
            for agent in self._store.list_agents():
                if agent.get("web_state") == "waiting" and agent["id"] not in done_ids:
                    if self._agent_target is None or int(self._agent_target.get("agent_id", 0)) != agent["id"]:
                        self._store.set_agent_web_state(agent["id"], "out")
        except Exception:
            pass
        self.agents_panel.refresh()
        if isinstance(results, dict) and results.get("error"):
            text = f"Đăng nhập hàng loạt dừng vì lỗi: {results['error']}"
            self._log_ui(text)
            QMessageBox.warning(self, "Đăng nhập hàng loạt", text)
            return
        results = results or []
        ok = sum(1 for r in results if r.get("status") in ("ok", "already"))
        manual = [r for r in results if r.get("status") == "needs_user"]
        failed = [r for r in results if r.get("status") in ("error", "no_code")]
        lines = [f"Thành công: {ok}/{len(results)}"]
        if manual:
            lines.append(f"Cần bạn tự hoàn tất ({len(manual)}): cửa sổ Chrome của các tài khoản này vẫn mở")
            lines += [f"  • {r.get('email')}: {r.get('message')}" for r in manual]
        if failed:
            lines.append(f"Lỗi / không nhận được mã ({len(failed)}):")
            lines += [f"  • {r.get('email')}: {r.get('message')}" for r in failed]
        if any(r.get("status") == "stopped" for r in results):
            lines.append("Đã dừng theo yêu cầu.")
        summary = "\n".join(lines)
        self._store.append_journal("Đăng nhập hàng loạt muse.ai xong — " + lines[0])
        self._log_ui("Đăng nhập hàng loạt muse.ai xong — " + lines[0])
        QMessageBox.information(self, "Kết quả đăng nhập hàng loạt", summary)

    # ------------------------------------------------------------------ #
    # Cookies đăng nhập theo hồ sơ (V3.2)
    # ------------------------------------------------------------------ #
    def _refresh_cookie_status(self, profile: dict):
        summary = cookies_vault.summarize(profile["slug"])
        if not summary["exists"]:
            text = "🍪 Cookies: chưa có — quét thành công một lần để app tự lưu, hoặc nhập file cookies có sẵn."
        else:
            auth = ", ".join(summary["auth_cookies"]) or "chưa có cookie đăng nhập Google"
            when = _fmt_ts(summary["saved_at"]) if summary["saved_at"] else "—"
            text = (
                f"🍪 Cookies: {summary['count']} cookie (lưu {when}) · {auth}"
                + (f" · {summary['expired']} đã hết hạn" if summary["expired"] else "")
            )
        self.cookie_status.setText(text)

    def _refresh_agent_owner(self, profile: dict):
        """Dòng 'Muse phụ trách' ở cột hồ sơ (V3.3): hồ sơ này đang
        được phân công cho tài khoản Muse nào (phân công đổi ở mục
        Tài khoản Muse)."""
        try:
            owner = self._store.agent_for_profile(profile["id"])
        except Exception:
            owner = None
        if owner:
            self.agent_owner_label.setText(
                f"🤖 Muse phụ trách: {owner['name']} ({owner['email']})"
            )
        else:
            self.agent_owner_label.setText(
                "🤖 Muse phụ trách: — (chưa phân công)"
            )

    def on_import_cookies(self):
        profile = self._require_profile()
        if profile is None:
            return
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn file cookies",
            "",
            "Cookies (*.json *.txt);;Tất cả các file (*)",
        )
        if not path:
            return
        try:
            cookies = cookies_vault.parse_cookies_bytes(Path(path).read_bytes())
        except OSError as exc:
            QMessageBox.warning(self, "Không đọc được file", str(exc))
            return
        if not cookies:
            QMessageBox.warning(
                self,
                "File cookies không hợp lệ",
                "Không đọc được cookie nào. File cần là JSON (mảng cookie / "
                "EditThisCookie) hoặc Netscape cookies.txt xuất từ trình duyệt.",
            )
            return
        summary = cookies_vault.save_cookies(
            profile["slug"], cookies, source=f"import:{Path(path).name}"
        )
        message = (
            f"Đã nhập {summary['count']} cookies cho hồ sơ '{profile['label']}' "
            f"(cookie đăng nhập Google: {', '.join(summary['auth_cookies']) or 'chưa thấy'})."
        )
        self._store.append_journal(message, profile["id"])
        self._log_ui(message)
        self._refresh_cookie_status(profile)
        self._refresh_agent_owner(profile)
        # V3.7 (yêu cầu người dùng): nhập cookies XONG LÀ TỰ ĐĂNG NHẬP
        # LUÔN cho hồ sơ đang chọn và HIỆN KẾT QUẢ tại tab Hồ sơ — phiên
        # đăng nhập tự mở Chrome (nếu cần), nạp cookies, kiểm tra phiên;
        # kết quả về qua _on_login_job_finished (chip phiên trên thẻ +
        # dòng cookies + toast).
        self._submit_login(profile)

    def on_apply_cookies(self):
        profile = self._require_profile()
        if profile is None:
            return
        payload = cookies_vault.load_cookies(profile["slug"])
        if not payload or not payload["cookies"]:
            self._log_ui(f"Hồ sơ '{profile['label']}' chưa có cookies nào trong kho.")
            return
        if not self._manager.is_running(profile):
            self._log_ui(
                "Chrome của hồ sơ chưa chạy — cookies sẽ tự nạp ở lần quét kế tiếp, "
                "hoặc mở trình duyệt hồ sơ rồi bấm Nạp cookies lại."
            )
            return
        params = [cookies_vault.to_cdp_cookie(c) for c in payload["cookies"]]
        port = profile["port"]

        def _apply(_token):
            cdp.set_cookies(port, params)
            return len(params)

        def _done(job):
            if job.status == "done":
                message = (
                    f"Đã nạp {job.result} cookies vào Chrome hồ sơ "
                    f"'{profile['label']}' — tải lại trang YouTube để phiên đăng nhập áp dụng."
                )
            else:
                message = f"Nạp cookies cho hồ sơ '{profile['label']}' thất bại: {job.error}"
            self._store.append_journal(message, profile["id"])
            self._log_ui(message)

        self._runner.submit_custom(_apply, profile_id=profile["id"], kind="cookies", on_done=_done)
        self._log_ui(f"Đang nạp {len(params)} cookies vào Chrome hồ sơ '{profile['label']}'…")

    def on_open_browser(self):
        from . import button_feedback

        profile = self._require_profile()
        if profile is None:
            return
        done = button_feedback.busy(getattr(self, "btn_open_browser", None), "⏳ Đang mở…")
        try:
            self._on_open_browser_inner(profile)
            done(True, "✓ Đã mở")
        except Exception:
            done(False, "✕ Lỗi")
            raise

    def _on_open_browser_inner(self, profile: dict):
        if profile["paused"]:
            self._log_ui(f"Hồ sơ '{profile['label']}' đang tạm dừng — không mở trình duyệt.")
            return
        try:
            # V6.7: mở CẤT (ngoài màn hình, khỏi taskbar) rồi nhúng vào app;
            # chế độ chạy ẩn → giữ cất luôn, không bao giờ hiện ra màn hình.
            state = self._manager.launch(profile, hidden=True)
        except Exception as exc:
            QMessageBox.warning(self, "Không mở được Chrome", str(exc))
            self._store.append_journal(f"Mở Chrome thất bại: {exc}", profile["id"])
            return
        message = f"Chrome hồ sơ '{profile['label']}': {'đã chạy sẵn' if state == 'already_running' else 'đã mở'}."
        if self._browsers_hidden():
            message += " (Đang chạy ẩn ngoài app — không nhúng.)"
        self._store.append_journal(message, profile["id"])
        self._log_ui(message)
        self._current_profile_id = profile["id"]
        self._update_card_selection()
        self._restart_live_worker(profile)
        if self._embed_always():
            # Nhúng ngay vào giao diện; cửa sổ vừa mở có thể chưa kịp
            # hiện — _auto_dock_tick (600ms) sẽ bắt ngay khi nó xuất hiện.
            self._embed_suppressed.discard(profile["id"])
            self._try_dock(quiet=True)

    # ------------------------------------------------------------------ #
    # Quét kênh qua JobEngine (một việc/hồ sơ tại một thời điểm)
    # ------------------------------------------------------------------ #
    def _scan_busy(self) -> bool:
        return bool(self._scan_inflight) or self._scan_all_queue is not None

    def _set_scan_buttons_enabled(self, enabled: bool):
        from . import button_feedback

        if not enabled:
            for key, attr, text in (("scan", "btn_scan_profile", "⏳ Đang quét…"), ("scan_all", "btn_scan_all", "⏳")):
                button = getattr(self, attr, None)
                if button is not None and key not in self._busy_done:
                    self._busy_done[key] = button_feedback.busy(button, text, timeout_ms=15 * 60_000)
        else:
            for key in ("scan", "scan_all"):
                done = self._busy_done.pop(key, None)
                if done:
                    done(True, "✓ Quét xong" if key == "scan" else "✓")
        self.btn_scan.setEnabled(enabled)
        self.btn_scan_all.setEnabled(enabled)

    def _record_session_state(self, profile_id: int | None, result: dict):
        if profile_id is None:
            return
        status = result.get("status")
        if status == "ok":
            self._session_states[profile_id] = "in"
        elif status == "needs_login":
            self._session_states[profile_id] = "out"

    def _submit_scan(self, profile: dict):
        profile_id = profile["id"]
        self._scan_inflight.add(profile_id)
        self._set_scan_buttons_enabled(False)
        manager, db_path = self._manager, self._db_path

        def job_fn(_token, profile=profile):
            store = Store(db_path)
            try:
                return scanner.scan_profile(
                    store, profile, manager, log=self._runner.log_line.emit
                )
            finally:
                store.close()

        def on_done(job, profile_id=profile_id):
            result = job.result if isinstance(job.result, dict) else {
                "status": "error",
                "channels": [],
                "message": job.error or "Quét thất bại.",
            }
            self._bg_scan_finished.emit(result, profile_id)

        self._runner.submit_custom(
            job_fn, profile_id=profile_id, kind="scan", on_done=on_done
        )
        self._log_ui(f"Bắt đầu quét kênh cho hồ sơ '{profile['label']}'…")

    def _on_scan_job_finished(self, result: dict, profile_id: int):
        self._scan_inflight.discard(profile_id)
        self._record_session_state(profile_id, result)
        self.refresh_profiles()
        profile = self._store.get_profile(profile_id)
        label = profile["label"] if profile else str(profile_id)
        if result.get("status") == "ok":
            self._log_ui(f"Quét xong hồ sơ '{label}'.")
        else:
            self._log_ui(
                f"Quét hồ sơ '{label}': {result.get('status', 'error')}."
            )
        if self._scan_all_queue is not None:
            self._start_next_scan_all()
            return
        self._set_scan_buttons_enabled(True)
        selected = self._selected_profile()
        if selected is not None:
            self._restart_live_worker(selected)

    def on_scan(self):
        profile = self._require_profile()
        if profile is None:
            return
        if profile["id"] in self._scan_inflight:
            QMessageBox.information(self, "Đang quét", "Hồ sơ này đang được quét — chờ xong đã.")
            return
        self._submit_scan(profile)

    def on_scan_all(self):
        if self._scan_all_queue is not None:
            QMessageBox.information(self, "Đang quét", "Đang quét tất cả hồ sơ — chờ xong đã.")
            return
        profiles = [
            p
            for p in self._store.list_profiles()
            if not p["paused"] and p["id"] not in self._scan_inflight
        ]
        if not profiles:
            QMessageBox.information(
                self, "Quét tất cả hồ sơ", "Không có hồ sơ đang hoạt động nào để quét."
            )
            return
        self._scan_all_queue = list(profiles)
        self._log_ui(f"Bắt đầu quét tất cả hồ sơ ({len(profiles)} hồ sơ)…")
        self._start_next_scan_all()

    def _start_next_scan_all(self):
        if not self._scan_all_queue:
            self._scan_all_queue = None
            self._set_scan_buttons_enabled(True)
            self.refresh_profiles()
            profile = self._selected_profile()
            if profile is not None:
                self._restart_live_worker(profile)
            return
        profile = self._scan_all_queue.pop(0)
        self._submit_scan(profile)

    def on_toggle_pause(self):
        profile = self._require_profile()
        if profile is None:
            return
        new_state = not profile["paused"]
        self._store.set_profile_paused(profile["id"], new_state)
        message = f"Hồ sơ '{profile['label']}': {'đã TẠM DỪNG' if new_state else 'đã BẬT lại'}."
        self._store.append_journal(message, profile["id"])
        self._log_ui(message)
        self.refresh_profiles()

    def on_delete_profile(self):
        profile = self._require_profile()
        if profile is None:
            return
        if self._scan_busy():
            QMessageBox.information(self, "Đang quét", "Đang có lượt quét chạy — chờ xong rồi xoá.")
            return
        answer = QMessageBox.question(
            self,
            "Xoá hồ sơ",
            f"Xoá hồ sơ '{profile['label']}' ({profile['gmail']}) khỏi hệ thống?\n"
            "Danh sách kênh và nhật ký của hồ sơ sẽ bị xoá. Thư mục Chrome của "
            "hồ sơ được chuyển vào thư mục lưu trữ (_trash), không xoá hẳn.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        profile_id, label, slug = profile["id"], profile["label"], profile["slug"]
        if self._current_profile_id == profile_id:
            if self._dock.is_docked():
                self._undock()
                self._set_live_tab(TAB_STREAM)
            self._stop_live_worker()
            self._current_profile_id = None
            self.live_profile_label.setText("Chưa chọn hồ sơ")
            self.live_gmail_label.setText("")
            self.live_url.setText("")
            self.fps_label.setText("— fps")
            self.live_dot.set_active(False)
            self.live_label.clear_frame()
            self._show_live_placeholder("Chưa chọn hồ sơ — chọn một hồ sơ ở cột trái để xem trực tiếp.")
            self.table.setRowCount(0)
            self.channel_stack.setCurrentIndex(1)
        src = config.profile_dir(slug)
        if src.exists():
            trash_root = config.profiles_root() / "_trash"
            trash_root.mkdir(parents=True, exist_ok=True)
            stamp = now_iso().replace(":", "-").replace("+", "_")
            shutil.move(str(src), str(trash_root / f"{slug}-{stamp}"))
        self._session_states.pop(profile_id, None)
        self._store.delete_profile(profile_id)
        message = f"Đã xoá hồ sơ '{label}' (thư mục Chrome đã chuyển vào _trash)."
        self._store.append_journal(message, None)
        self._log_ui(message)
        self.refresh_profiles()

    # ------------------------------------------------------------------ #
    def _require_profile(self) -> dict | None:
        profile = self._selected_profile()
        if profile is None:
            QMessageBox.information(self, "Chưa chọn hồ sơ", "Hãy chọn một hồ sơ ở cột trái.")
        return profile

    def _log_ui(self, message: str):
        # _log_ui được AutomationEngine dùng làm callback log — engine
        # chạy trên luồng UI (tick bằng QTimer) nên chạm widget an toàn;
        # các callback khác đi qua Signal của CommandRunner.
        if hasattr(self, "journal_view"):
            self._append_journal_line(_fmt_ts(now_iso()), message)

    def closeEvent(self, event):
        try:
            if hasattr(self, "live_grid"):
                self.live_grid.stop()
        except Exception:
            pass
        self._close_event_inner(event)

    def _close_event_inner(self, event):
        # Gỡ nhúng TRƯỚC khi đóng app — cửa sổ Chrome phải trở lại làm cửa
        # sổ thường, không bao giờ bị kẹt trong cửa sổ app đã đóng.
        self._undock()
        self._runner.stop()
        if hasattr(self, "_auto_timer"):
            self._auto_timer.stop()
        if hasattr(self, "_status_timer"):
            self._status_timer.stop()
        if self._tray is not None:
            self._tray.hide()
        self._stop_live_worker()
        # Worker nào VẪN còn chạy sau khi đã chờ (đang kẹt trong lệnh
        # CDP dài): gỡ parent Qt để việc huỷ cửa sổ không kéo theo huỷ
        # QThread đang chạy, và gửi tham chiếu cho QApplication giữ tới
        # hết tiến trình — thread tự thoát theo cờ stop ngay khi lệnh
        # CDP hiện tại trả về, không ai được chạm vào nó nữa.
        leftover = list(self._retiring_live_workers)
        self._retiring_live_workers.clear()
        if leftover:
            app = QApplication.instance()
            if app is not None:
                stash = getattr(app, "_ccd_detached_threads", None)
                if stash is None:
                    stash = []
                    app._ccd_detached_threads = stash  # type: ignore[attr-defined]
                for worker in leftover:
                    worker.setParent(None)
                    stash.append(worker)
        # Mặc định: KHÔNG tắt Chrome khi đóng app (keep_chrome_open_on_exit).
        if not self._settings.get("keep_chrome_open_on_exit", True):
            self._manager.terminate_launched()
        super().closeEvent(event)


def _fmt_num(value) -> str:
    return "?" if value is None else f"{value:,}"


def _fmt_ts(iso_value) -> str:
    if not iso_value:
        return ""
    try:
        date_part, time_part = str(iso_value).split("T", 1)
        year, month, day = date_part.split("-")
        return f"{day}/{month} {time_part[:5]}"
    except Exception:
        return str(iso_value)


def _parse_iso_safe(value):
    from ..store import _parse_iso

    try:
        return _parse_iso(value) if value else None
    except Exception:
        return None
