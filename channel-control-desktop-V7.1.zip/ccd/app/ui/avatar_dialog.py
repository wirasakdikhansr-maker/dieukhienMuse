"""V6.8 — hộp thoại "🎨 Hình agent 3D": chọn mẫu nhân vật, màu, kích thước —
chung cho tất cả hoặc riêng từng agent / trưởng phòng — có XEM TRƯỚC trực tiếp
ở tất cả trạng thái (đang làm, chờ nhận, xong, lỗi, rảnh, ngủ)."""

from __future__ import annotations

import copy

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QSlider,
    QVBoxLayout,
    QWidget,
)

from . import avatars, theme

PREVIEW_STATES = [("working", "▶", "45%", "working"), ("receive", "✉", "chờ nhận", "receive"),
                  ("report", "✓", "xong", "report"), ("error", "⚠", "lỗi", "error"),
                  ("idle", "💤", "rảnh", "idle"), ("sleep", "☾", "nghỉ", "idle")]


class _ColorButton(QPushButton):
    def __init__(self, title: str, allow_auto: bool = False, parent=None):
        super().__init__(parent)
        self._title = title
        self._allow_auto = allow_auto
        self.value = ""
        self.clicked.connect(self._pick)
        self.setMinimumWidth(150)

    def set_value(self, value: str):
        self.value = value or ""
        if self.value:
            ink = "#141A05" if QColor(self.value).lightness() > 140 else "#ECEEF1"
            self.setStyleSheet(f"background:{self.value}; color:{ink}; border-radius:8px; padding:6px 10px;")
            self.setText(self.value.upper())
        else:
            self.setStyleSheet("")
            self.setText("Tự động (theo trạng thái)" if self._allow_auto else "—")

    def _pick(self):
        color = QColorDialog.getColor(QColor(self.value or "#CEFC19"), self, self._title)
        if color.isValid():
            self.set_value(color.name())
            if getattr(self, "_title_auto", False):
                self.window().on_room_changed()
            else:
                self.window().on_changed()


class AvatarDialog(QDialog):
    def __init__(self, settings: dict, store=None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Hình agent 3D")
        self.resize(1100, 640)
        self._settings = settings
        self._store = store
        self._cfg = copy.deepcopy(settings.get("office_avatar") or {"default": {}, "agents": {}})
        self._cfg.setdefault("default", {})
        self._cfg.setdefault("agents", {})
        self._loading = False
        self._theme_cfg = copy.deepcopy(settings.get("office_theme") or {})
        self.setWindowTitle("Giao diện Văn phòng 3D")
        root = QHBoxLayout(self)
        left = QVBoxLayout()
        root.addLayout(left, 0)
        left.addWidget(theme.section_header("🎨 Giao diện Văn phòng 3D"))
        from PySide6.QtWidgets import QTabWidget

        self.tabs = QTabWidget()
        self.tabs.setMinimumWidth(430)
        agent_page = QWidget()
        agent_layout = QVBoxLayout(agent_page)
        form = QFormLayout()
        self.target = QComboBox()
        self.target.addItem("Mặc định — áp cho TẤT CẢ agent", "default")
        self.target.addItem("👑 Riêng trưởng phòng", "lead")
        for agent in (store.list_agents() if store is not None else []):
            if not agent.get("revoked"):
                self.target.addItem(f"🤖 Riêng {agent.get('name') or agent.get('email')}", str(agent["id"]))
        self.target.currentIndexChanged.connect(self._load_target)
        form.addRow("Áp cho:", self.target)
        self.model = QComboBox()
        for key, label in avatars.MODELS.items():
            self.model.addItem(label, key)
        self.model.currentIndexChanged.connect(lambda _i: self.on_changed())
        form.addRow("Mẫu nhân vật:", self.model)
        self.body = _ColorButton("Màu thân / áo")
        form.addRow("Màu thân / áo:", self.body)
        presets = QHBoxLayout()
        presets.setSpacing(4)
        for color in avatars.PRESET_COLORS:
            swatch = QPushButton()
            swatch.setFixedSize(20, 20)
            swatch.setStyleSheet(f"background:{color}; border:1px solid #2E3036; border-radius:10px;")
            swatch.clicked.connect(lambda _c=False, col=color: (self.body.set_value(col), self.on_changed()))
            presets.addWidget(swatch)
        presets.addStretch(1)
        holder = QWidget()
        holder.setLayout(presets)
        form.addRow("", holder)
        self.accent = _ColorButton("Màu nhấn (mắt, cà vạt, vòng cổ…)", allow_auto=True)
        form.addRow("Màu nhấn:", self.accent)
        auto = QPushButton("↺ Màu nhấn theo trạng thái")
        auto.clicked.connect(lambda: (self.accent.set_value(""), self.on_changed()))
        form.addRow("", auto)
        self.skin = _ColorButton("Màu da")
        form.addRow("Màu da (nhân viên):", self.skin)
        self.hair = _ColorButton("Màu tóc")
        form.addRow("Màu tóc (nhân viên):", self.hair)
        size_row = QHBoxLayout()
        self.size = QSlider(Qt.Orientation.Horizontal)
        self.size.setRange(60, 180)
        self.size.valueChanged.connect(lambda v: (self.size_label.setText(f"{v}%"), self.on_changed()))
        self.size_label = QLabel("100%")
        size_row.addWidget(self.size, 1)
        size_row.addWidget(self.size_label)
        size_holder = QWidget()
        size_holder.setLayout(size_row)
        form.addRow("Kích thước:", size_holder)
        self.show_name = QCheckBox("Hiện bảng tên dưới bàn")
        self.show_name.toggled.connect(lambda _c: self.on_changed())
        form.addRow("", self.show_name)
        self.show_chip = QCheckBox("Hiện chip trạng thái trên đầu")
        self.show_chip.toggled.connect(lambda _c: self.on_changed())
        form.addRow("", self.show_chip)
        agent_layout.addLayout(form)
        reset_row = QHBoxLayout()
        self.reset_one = QPushButton("Bỏ tuỳ chỉnh riêng")
        self.reset_one.setToolTip("Agent/trưởng phòng này quay về dùng hình Mặc định")
        self.reset_one.clicked.connect(self._reset_target)
        reset_row.addWidget(self.reset_one)
        reset_all = QPushButton("Đặt lại tất cả")
        reset_all.clicked.connect(self._reset_all)
        reset_row.addWidget(reset_all)
        agent_layout.addLayout(reset_row)
        agent_layout.addStretch(1)
        self.tabs.addTab(agent_page, "🤖 Hình agent")
        self.tabs.addTab(self._build_room_page(), "🏢 Căn phòng")
        left.addWidget(self.tabs, 1)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Lưu")
        buttons.button(QDialogButtonBox.Cancel).setText("Huỷ")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        left.addWidget(buttons)
        # xem trước
        right = QVBoxLayout()
        root.addLayout(right, 1)
        right.addWidget(theme.muted_label("Xem trước ở mọi trạng thái — trưởng phòng ở giữa phía sau"))
        from .office_iso import _IsoStage

        self.preview = _IsoStage()
        self.preview.setMinimumSize(560, 520)
        right.addWidget(self.preview, 1)
        self._load_target()

    # ------------------------------------------------------------------ #
    def _build_room_page(self) -> QWidget:
        from . import office_themes

        page = QWidget()
        layout = QVBoxLayout(page)
        form = QFormLayout()
        self.preset = QComboBox()
        for key, preset in office_themes.PRESETS.items():
            self.preset.addItem(preset["label"], key)
        self.preset.setCurrentIndex(max(0, self.preset.findData(self._theme_cfg.get("preset") or "modern_dark")))
        self.preset.currentIndexChanged.connect(self._on_preset)
        form.addRow("Mẫu văn phòng:", self.preset)
        self.floor_color = _ColorButton("Màu sàn", allow_auto=True)
        self.wall_color = _ColorButton("Màu tường", allow_auto=True)
        self.desk_color = _ColorButton("Màu bàn", allow_auto=True)
        self.accent_color = _ColorButton("Màu nhấn của phòng", allow_auto=True)
        for button in (self.floor_color, self.wall_color, self.desk_color, self.accent_color):
            button._title_auto = True
        form.addRow("Màu sàn:", self.floor_color)
        form.addRow("Màu tường:", self.wall_color)
        form.addRow("Màu bàn:", self.desk_color)
        form.addRow("Màu nhấn (viền, biển, phòng TP):", self.accent_color)
        self.pattern = QComboBox()
        self.pattern.addItem("Theo mẫu", "")
        for key, label in office_themes.PATTERNS.items():
            self.pattern.addItem(label, key)
        self.pattern.setCurrentIndex(max(0, self.pattern.findData(self._theme_cfg.get("pattern") or "")))
        self.pattern.currentIndexChanged.connect(lambda _i: self.on_room_changed())
        form.addRow("Kiểu sàn:", self.pattern)
        layout.addLayout(form)
        layout.addWidget(theme.muted_label("Đồ trang trí:"))
        props = dict(office_themes.DEFAULT_THEME["props"])
        props.update(self._theme_cfg.get("props") or {})
        self.prop_checks = {}
        for key, label in office_themes.PROPS.items():
            check = QCheckBox(label)
            check.setChecked(bool(props.get(key, True)))
            check.toggled.connect(lambda _c: self.on_room_changed())
            self.prop_checks[key] = check
            layout.addWidget(check)
        reset = QPushButton("↺ Màu theo mẫu (bỏ tuỳ chỉnh màu phòng)")
        reset.clicked.connect(self._reset_room_colors)
        layout.addWidget(reset)
        layout.addStretch(1)
        for button, key in ((self.floor_color, "floor"), (self.wall_color, "wall"), (self.desk_color, "desk"),
                            (self.accent_color, "accent")):
            button.set_value(self._theme_cfg.get(key) or "")
            button.setText(button.text().replace("Tự động (theo trạng thái)", "Theo mẫu")) if not button.value else None
        return page

    def _on_preset(self, _index=None):
        self._reset_room_colors()

    def _reset_room_colors(self):
        for button in (self.floor_color, self.wall_color, self.desk_color, self.accent_color):
            button.set_value("")
            button.setText("Theo mẫu")
        self.pattern.setCurrentIndex(0)
        self.on_room_changed()

    def on_room_changed(self):
        if getattr(self, "_loading", False) or not hasattr(self, "prop_checks"):
            return
        self._theme_cfg = {
            "preset": self.preset.currentData(),
            "floor": self.floor_color.value, "wall": self.wall_color.value, "desk": self.desk_color.value,
            "accent": self.accent_color.value, "pattern": self.pattern.currentData() or "",
            "props": {k: c.isChecked() for k, c in self.prop_checks.items()},
        }
        self._refresh_preview()

    def _target_key(self) -> str:
        return self.target.currentData() or "default"

    def _current(self) -> dict:
        key = self._target_key()
        if key == "default":
            return self._cfg["default"]
        if key == "lead":
            return self._cfg.setdefault("lead", {})
        return self._cfg["agents"].setdefault(key, {})

    def _effective(self) -> dict:
        key = self._target_key()
        tmp = {"office_avatar": self._cfg}
        if key == "default":
            return avatars.resolve_style(tmp)
        if key == "lead":
            return avatars.resolve_style(tmp, None, True)
        return avatars.resolve_style(tmp, key)

    def _load_target(self):
        self._loading = True
        style = self._effective()
        self.model.setCurrentIndex(max(0, self.model.findData(style["model"])))
        self.body.set_value(style.get("body") or "")
        self.accent.set_value(style.get("accent") or "")
        self.skin.set_value(style.get("skin") or "")
        self.hair.set_value(style.get("hair") or "")
        self.size.setValue(int(round(float(style["size"]) * 100)))
        self.size_label.setText(f"{self.size.value()}%")
        self.show_name.setChecked(bool(style.get("show_name", True)))
        self.show_chip.setChecked(bool(style.get("show_chip", True)))
        self.reset_one.setEnabled(self._target_key() != "default")
        self._loading = False
        self._refresh_preview()

    def on_changed(self):
        if self._loading:
            return
        current = self._current()
        current.update({
            "model": self.model.currentData(), "body": self.body.value, "accent": self.accent.value,
            "skin": self.skin.value, "hair": self.hair.value, "size": self.size.value() / 100.0,
            "show_name": self.show_name.isChecked(), "show_chip": self.show_chip.isChecked(),
        })
        self._refresh_preview()

    def _reset_target(self):
        key = self._target_key()
        if key == "lead":
            self._cfg.pop("lead", None)
        elif key != "default":
            self._cfg["agents"].pop(key, None)
        self._load_target()

    def _reset_all(self):
        self._cfg = {"default": {}, "agents": {}}
        self._load_target()

    def _refresh_preview(self):
        key = self._target_key()
        preview_id = int(key) if key.isdigit() else None
        desks = []
        for index, (state, icon, text, tone) in enumerate(PREVIEW_STATES):
            agent_id = preview_id if preview_id is not None else -(index + 1)
            desks.append({"agent_id": agent_id, "name": ["Đang làm", "Chờ nhận", "Xong", "Lỗi", "Rảnh", "Ngủ"][index],
                          "state": state, "lead": False, "pct": 45, "bubble": None,
                          "chip": {"icon": icon, "text": text, "tone": tone}})
        lead = {"agent_id": -99, "name": "Trưởng phòng", "state": "lead", "lead": True, "bubble": None,
                "chip": {"icon": "👑", "text": "điều phối", "tone": "lead"}}
        cfg = copy.deepcopy(self._cfg)
        if key == "lead":
            cfg["agents"]["-99"] = dict(cfg.get("lead") or {})
        self.preview.avatar_settings = {"office_avatar": cfg, "office_theme": getattr(self, "_theme_cfg", {})}
        self.preview.set_data({"mode": "work", "lead": lead, "desks": desks, "events": [], "now": ""})

    def result_config(self) -> dict:
        return self._cfg

    def accept(self):
        self._settings["office_avatar"] = self._cfg
        self._settings["office_theme"] = self._theme_cfg
        try:
            from .. import config

            config.save_settings(self._settings)
        except Exception:
            pass
        super().accept()
