"""V6.6 — VĂN PHÒNG 3D (isometric) theo bản phác thảo đã duyệt.

- Phòng TRƯỞNG PHÒNG ở giữa phía sau (sàn viền lime, vách kính, vương miện).
- Bàn nhân viên 3 bàn/hàng; vòng sàn + màn hình + robot thể hiện trạng thái:
  đang làm (lime liền) · vừa nhận/chờ xác nhận (xanh dương nét đứt) ·
  xong/báo cáo (xanh lục) · lỗi (đỏ) · rảnh (xám, màn hình tắt) ·
  xếp hàng chờ giờ (vàng) · ngủ ngoài giờ (robot về sạc, "z z").
- Hiệu ứng: ✉ phong bì bay TP → agent khi giao việc; ✅ nảy trên đầu agent
  khi Muse xác nhận ĐÃ NHẬN; 📄 báo cáo bay agent → TP khi xong; ⚠ bay về
  TP khi lỗi. Bong bóng lời thoại trên đầu = tin thật gần nhất.
- Cột phải "Luồng trao đổi": hội thoại hai chiều giữa trưởng phòng và các
  agent ngay trong app (không cần mở muse.ai). Bấm bàn / bấm tin → mở chat.
- Thanh trên: Tự động theo giờ · Làm việc · Ngoài giờ.
"""

from __future__ import annotations

import math
import time

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPainterPath, QPen, QPolygonF
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QSplitter,
    QWidget,
)

from .. import office_feed
from . import avatars, office_themes, theme

C30 = math.cos(math.radians(30))
STATE_COLOR = {
    "working": "#CEFC19", "night": "#CEFC19", "lead": "#CEFC19", "receive": "#6CC7FF",
    "report": "#7DDC7A", "error": "#FF7A7A", "idle": "#3A3D44", "sleep": "#26282D", "queued": "#F2C94C",
}
TONE_COLOR = {
    "lead": "#CEFC19", "working": "#CEFC19", "receive": "#6CC7FF", "report": "#7DDC7A",
    "error": "#FF7A7A", "idle": "#3A3D44", "queued": "#F2C94C", "talk": "#6CC7FF",
}
FLIGHT_S = 1.8
COLS = 3


def _qc(hex_color: str, alpha: float = 1.0) -> QColor:
    color = QColor(hex_color)
    color.setAlphaF(max(0.0, min(1.0, alpha)))
    return color


class _IsoStage(QWidget):
    agent_clicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(320, 300)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.data: dict = {"mode": "work", "lead": None, "desks": [], "events": []}
        self.selected: int | None = None
        self.flights: list[dict] = []
        self.pops: list[dict] = []
        self._hits: list[tuple[QRectF, object]] = []
        self._scale = 1.0
        self._ox = 0.0
        self._oy = 0.0
        self._phase = 0.0
        self._hover = None
        self.avatar_settings: dict = {}  # V6.8: settings app (khoá office_avatar)

    # ---------------------------------------------------------- hình học
    def _layout(self):
        n = len(self.data.get("desks") or [])
        rows = max(1, math.ceil(n / COLS))
        self.floor_w = 100 + COLS * 240
        self.floor_d = 280 + rows * 200
        return rows

    def _fit(self):
        w, d = self.floor_w, self.floor_d
        corners = [(0, 0, 0), (w, 0, 0), (w, d, 0), (0, d, 0), (0, 0, 175), (w, 0, 175)]
        xs = [(x - y) * C30 for x, y, _z in corners]
        ys = [(x + y) * 0.5 - z for x, y, z in corners]
        bw, bh = max(xs) - min(xs), max(ys) - min(ys) + 10
        scale = min(self.width() / max(1, bw), self.height() / max(1, bh)) * 0.96
        self._scale = max(0.35, min(1.6, scale))
        self._ox = (self.width() - bw * self._scale) / 2 - min(xs) * self._scale
        self._oy = (self.height() - bh * self._scale) / 2 - min(ys) * self._scale + 20 * self._scale

    def P(self, x, y, z=0.0) -> QPointF:
        return QPointF(self._ox + (x - y) * C30 * self._scale, self._oy + ((x + y) * 0.5 - z) * self._scale)

    def _poly(self, painter, pts, fill, stroke=None, width=1.0):
        painter.setBrush(fill if isinstance(fill, QColor) else _qc(fill))
        if stroke:
            painter.setPen(QPen(stroke if isinstance(stroke, QColor) else _qc(stroke), width))
        else:
            painter.setPen(Qt.PenStyle.NoPen)
        painter.drawPolygon(QPolygonF(pts))

    def _box(self, p, x, y, z, w, d, h, top, left, right, stroke=None):
        P = self.P
        self._poly(p, [P(x, y + d, z + h), P(x + w, y + d, z + h), P(x + w, y + d, z), P(x, y + d, z)], left)
        self._poly(p, [P(x + w, y + d, z + h), P(x + w, y, z + h), P(x + w, y, z), P(x + w, y + d, z)], right)
        self._poly(p, [P(x, y, z + h), P(x + w, y, z + h), P(x + w, y + d, z + h), P(x, y + d, z + h)], top, stroke, 1.5)

    def desk_pos(self, index: int) -> tuple[float, float]:
        row, col = divmod(index, COLS)
        return 100 + col * 240, 300 + row * 200

    LEAD_POS = (355.0, 70.0)

    def anchor(self, agent_id) -> QPointF | None:
        lead = self.data.get("lead") or {}
        if agent_id is not None and lead.get("agent_id") == agent_id or (agent_id is None and lead):
            x, y = self.LEAD_POS
            top = avatars.top_height(avatars.resolve_style(self.avatar_settings, lead.get("agent_id"), True))
            return self.P(x + 55, y + 78, 12 + top + 28)
        for i, desk in enumerate(self.data.get("desks") or []):
            if desk["agent_id"] == agent_id:
                x, y = self.desk_pos(i)
                top = avatars.top_height(avatars.resolve_style(self.avatar_settings, agent_id))
                return self.P(x + 55, y + 78, top + 28)
        return None

    # ---------------------------------------------------------- dữ liệu
    def set_data(self, data: dict, new_events: list | None = None):
        """new_events: sự kiện MỚI cần chạy hiệu ứng (mỗi sự kiện một lần)."""
        self.data = data
        self._built_at = time.monotonic()
        if new_events:
            now = time.monotonic()
            lead = (data.get("lead") or {}).get("agent_id")
            for ev in new_events:
                cid = office_feed.short_id(ev.get("command_id"))
                suffix = f" #{cid}" if cid else ""
                label = {"assign": f"✉ Việc{suffix}", "report": f"📄 Báo cáo{suffix}",
                         "error": f"⚠ Lỗi{suffix}"}.get(ev["kind"])
                if ev["kind"] == "ack":
                    self.pops.append({"agent": ev["agent_id"], "t0": now, "text": "✅ Đã nhận"})
                    continue
                src, dst = (lead, ev["agent_id"]) if ev["kind"] == "assign" else (ev["agent_id"], lead)
                self.flights.append({"src": src, "dst": dst, "label": label, "t0": now,
                                     "color": {"assign": "#6CC7FF", "report": "#7DDC7A", "error": "#FF7A7A"}[ev["kind"]]})
        self.update()

    def animating(self) -> bool:
        desks = list(self.data.get("desks") or []) + ([self.data["lead"]] if self.data.get("lead") else [])
        if any(0.0 < self._bubble_alpha(d) < 1.0 or (d.get("bubble") or {}).get("fresh") for d in desks):
            return True
        return bool(self.flights or self.pops) or any(
            d["state"] in ("working", "night", "receive", "sleep") for d in self.data.get("desks") or [])

    def tick(self, dt: float):
        self._phase += dt
        now = time.monotonic()
        self.flights = [f for f in self.flights if now - f["t0"] < FLIGHT_S + 0.4]
        self.pops = [p for p in self.pops if now - p["t0"] < 2.5]
        self.update()

    # ---------------------------------------------------------- vẽ
    def paintEvent(self, _event):
        self._layout()
        self._fit()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        night = self.data.get("mode") == "off"
        p.fillRect(self.rect(), _qc("#0A0B0D" if night else ("#0C0D0F" if not office_themes.resolve_theme(
            self.avatar_settings).get("light") else "#1A1C20")))
        self._paint_room(p, night)
        self._hits = []
        lead = self.data.get("lead")
        items = []
        if lead:
            items.append((self.LEAD_POS, lead, 12))
        for i, desk in enumerate(self.data.get("desks") or []):
            items.append((self.desk_pos(i), desk, 0))
        items.sort(key=lambda it: (it[0][0] + it[0][1]))
        for (x, y), desk, z in items:
            self._paint_desk(p, x, y, z, desk, night)
        self._placed: list[QRectF] = []
        for (x, y), desk, z in sorted(items, key=lambda it: -(it[0][0] + it[0][1])):
            self._paint_bubble(p, x, y, z, desk)
        self._paint_flights(p)
        self._paint_pops(p)
        p.end()

    def _paint_room(self, p, night):
        """V6.8: căn phòng theo CHỦ ĐỀ chọn trong Cài đặt (màu sàn/tường/bàn,
        kiểu sàn, màu nhấn) + đồ trang trí bật/tắt được."""
        P = self.P
        w, d = self.floor_w, self.floor_d
        th = self.theme = office_themes.resolve_theme(self.avatar_settings, night)
        accent = th["accent"]
        pattern = th.get("pattern") or "checker"
        # sàn
        self._poly(p, [P(0, 0), P(w, 0), P(w, d), P(0, d)], th["floor"])
        if pattern == "checker":
            step = 60
            for i in range(int(w // step)):
                for j in range(int(d // step)):
                    if (i + j) % 2:
                        self._poly(p, [P(i * step, j * step), P(i * step + step, j * step),
                                       P(i * step + step, j * step + step), P(i * step, j * step + step)], th["floor2"])
        elif pattern in ("planks", "tiles"):
            step = 30 if pattern == "planks" else 90
            p.setPen(QPen(_qc(th["grid"]), 0.8))
            for j in range(0, int(d) + 1, step):
                p.drawLine(P(0, j), P(w, j))
            if pattern == "tiles":
                for i in range(0, int(w) + 1, step):
                    p.drawLine(P(i, 0), P(i, d))
            else:  # ván gỗ so le
                for j in range(0, int(d), step):
                    offset = 0 if (j // step) % 2 else 60
                    for i in range(offset, int(w), 120):
                        p.drawLine(P(i, j), P(i, j + step))
        # viền chân tường
        self._poly(p, [P(0, 0, 0), P(w, 0, 0), P(w, 0, 170), P(0, 0, 170)], th["wall"])
        self._poly(p, [P(0, 0, 0), P(0, d, 0), P(0, d, 170), P(0, 0, 170)], th["wall_side"])
        self._poly(p, [P(0, 0, 0), P(w, 0, 0), P(w, 0, 6), P(0, 0, 6)], _qc(accent, 0.25 if not night else 0.12))
        self._poly(p, [P(0, 0, 0), P(0, d, 0), P(0, d, 6), P(0, 0, 6)], _qc(accent, 0.18 if not night else 0.08))
        props = th["props"]
        if props.get("rug"):
            self._poly(p, [P(70, 270), P(w - 50, 270), P(w - 50, d - 20), P(70, d - 20)], _qc(th["rug"], 0.55),
                       _qc(accent, 0.25), 1.2)
        for k in range(4):
            x0 = 60 + k * (w - 120) / 4
            if props.get("whiteboard") and k == 0:
                continue
            self._poly(p, [P(x0, 0, 60), P(x0 + 110, 0, 60), P(x0 + 110, 0, 140), P(x0, 0, 140)],
                       th["window"], _qc("#FFFFFF", 0.12), 2)
            self._poly(p, [P(x0 + 55, 0, 60), P(x0 + 57, 0, 60), P(x0 + 57, 0, 140), P(x0 + 55, 0, 140)], _qc("#FFFFFF", 0.1))
            if night:
                for sx, sz in ((30, 120), (80, 100), (55, 80)):
                    pt = P(x0 + sx, 0, sz)
                    p.setPen(Qt.PenStyle.NoPen)
                    p.setBrush(_qc("#FFFFFF", 0.7))
                    p.drawEllipse(pt, 1.4 * self._scale, 1.4 * self._scale)
        if night:
            moon = P(60 + 3 * (w - 120) / 4 + 55, 0, 112)
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_qc("#F2E9B8", 0.9))
            p.drawEllipse(moon, 10 * self._scale, 10 * self._scale)
        if props.get("whiteboard"):
            self._whiteboard(p, night, accent)
        if props.get("shelves"):
            self._shelves(p, night)
        sign = P(120 if not props.get("whiteboard") else 300, 0, 160)
        self._text(p, sign, ("NGOÀI GIỜ · " if night else "ĐANG LÀM VIỆC · ") + str(self.data.get("now") or ""),
                   "#6F7680" if night else accent, 12, bold=True)
        # phòng trưởng phòng
        self._box(p, 260, 20, 0, 300, 190, 12, _qc(accent, 0.14 if not night else 0.07),
                  th["desk_left"], th["desk_right"], stroke=accent if not night else _qc(accent, 0.4).name())
        self._poly(p, [P(260, 20, 12), P(560, 20, 12), P(560, 20, 130), P(260, 20, 130)], _qc("#6CC7FF", 0.03 if night else 0.07))
        self._poly(p, [P(260, 20, 12), P(260, 210, 12), P(260, 210, 130), P(260, 20, 130)], _qc("#6CC7FF", 0.02 if night else 0.05))
        p.setPen(QPen(_qc("#BFE6FF", 0.35 if not night else 0.15), 1.2))
        p.drawLine(P(260, 210, 130), P(260, 20, 130))
        p.drawLine(P(260, 20, 130), P(560, 20, 130))
        tag = P(500, 20, 140)
        ink = "#FFFFFF" if QColor(accent).lightness() < 140 else "#141A05"
        self._pill(p, tag, "PHÒNG TRƯỞNG PHÒNG", accent, ink, alpha=0.55 if night else 1.0)
        if props.get("cooler"):
            self._cooler(p, 600, 40, night)
        if props.get("lounge"):
            self._lounge(p, 30, 60, night, accent)
        if props.get("plants"):
            for px, py in ((22, 22), (w - 30, 22), (22, d - 30), (w - 30, d - 30)):
                self._plant(p, px, py, night)

    # ---- đồ trang trí
    def _plant(self, p, x, y, night):
        P = self.P
        self._box(p, x - 9, y - 9, 0, 18, 18, 16, "#6B4A35", "#4E3626", "#5C402E")
        center = P(x, y, 34)
        leaf = _qc("#3E8E4B" if not night else "#24502B")
        p.setPen(Qt.PenStyle.NoPen)
        for dx, dy, r in ((0, -8, 13), (-9, 0, 10), (9, 0, 10), (0, 6, 9)):
            p.setBrush(leaf)
            p.drawEllipse(QPointF(center.x() + dx * self._scale, center.y() + dy * self._scale), r * self._scale, r * self._scale * 0.8)
        p.setBrush(_qc("#6FCF7A" if not night else "#2F6B3A", 0.6))
        p.drawEllipse(QPointF(center.x() - 3 * self._scale, center.y() - 12 * self._scale), 5 * self._scale, 4 * self._scale)

    def _whiteboard(self, p, night, accent):
        P = self.P
        x0, x1, z0, z1 = 50, 200, 62, 140
        self._poly(p, [P(x0, 0, z0), P(x1, 0, z0), P(x1, 0, z1), P(x0, 0, z1)], "#E9ECEF" if not night else "#4A4E56",
                   "#9AA0A8", 2)
        p.setPen(QPen(_qc(accent, 0.9), 2 * self._scale))
        pts = [P(x0 + 15 + i * 25, 0, z0 + 18 + h) for i, h in enumerate((10, 30, 22, 45, 38, 58))]
        for a, b in zip(pts, pts[1:]):
            p.drawLine(a, b)
        self._text(p, P(x0 + 32, 0, z1 - 12), "KPI", "#2A2E36" if not night else "#9AA0A8", 9, bold=True)

    def _shelves(self, p, night):
        y0, y1 = 240, 360
        P = self.P
        self._poly(p, [P(0, y0, 20), P(0, y1, 20), P(0, y1, 130), P(0, y0, 130)], "#4E3626" if not night else "#2A1E15")
        colors = ["#CEFC19", "#6CC7FF", "#FF7A7A", "#F2C94C", "#C792EA", "#7DDC7A"]
        for row, z in enumerate((28, 64, 100)):
            self._poly(p, [P(0, y0, z - 2), P(0, y1, z - 2), P(0, y1, z), P(0, y0, z)], "#6B4A35")
            for k in range(7):
                yy = y0 + 8 + k * 15
                col = colors[(k + row) % len(colors)]
                self._poly(p, [P(0, yy, z), P(0, yy + 10, z), P(0, yy + 10, z + 26 - (k % 3) * 4), P(0, yy, z + 26 - (k % 3) * 4)],
                           _qc(col, 0.55 if not night else 0.25))

    def _cooler(self, p, x, y, night):
        self._box(p, x, y, 0, 22, 22, 40, "#D7DBE2" if not night else "#5A5F68", "#A9AFB8", "#BFC4CC")
        P = self.P
        c = P(x + 11, y + 11, 58)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_qc("#6CC7FF", 0.7 if not night else 0.3))
        p.drawEllipse(c, 10 * self._scale, 14 * self._scale)

    def _lounge(self, p, x, y, night, accent):
        sofa = QColor(accent).darker(220).name() if not night else "#2A2D33"
        self._box(p, x, y, 0, 40, 130, 18, QColor(sofa).lighter(120).name(), QColor(sofa).darker(130).name(), sofa)
        self._box(p, x, y, 18, 12, 130, 22, QColor(sofa).lighter(110).name(), QColor(sofa).darker(140).name(), sofa)
        self._box(p, x + 60, y + 35, 0, 50, 60, 14, "#6B4A35", "#4E3626", "#5C402E")
        P = self.P
        cup = P(x + 85, y + 60, 16)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_qc("#ECEEF1"))
        p.drawEllipse(cup, 3.5 * self._scale, 2.5 * self._scale)

    def _paint_desk(self, p, x, y, z, desk, night):
        P = self.P
        state = desk.get("state") or "idle"
        glow = STATE_COLOR.get(state, "#3A3D44")
        ring_c = P(x + 55, y + 40, z)
        if state not in ("idle", "sleep"):
            pulse = 0.75 + 0.2 * math.sin(self._phase * 3) if state in ("working", "receive", "night") else 0.75
            pen = QPen(_qc(glow, pulse), 2.5 * self._scale)
            if state in ("receive", "queued"):
                pen.setStyle(Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.setBrush(_qc(glow, 0.06))
            p.drawEllipse(ring_c, 80 * self._scale, 41 * self._scale)
        if self.selected is not None and desk.get("agent_id") == self.selected:
            p.setPen(QPen(_qc("#FFFFFF", 0.6), 1.5 * self._scale, Qt.PenStyle.DotLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawEllipse(ring_c, 92 * self._scale, 48 * self._scale)
        # bóng đổ mềm dưới bàn + robot
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(_qc("#000000", 0.35))
        p.drawEllipse(P(x + 60, y + 52, z), 70 * self._scale, 30 * self._scale)
        th = getattr(self, "theme", None) or office_themes.resolve_theme(self.avatar_settings, night)
        self._box(p, x, y, z, 110, 60, 34, th["desk"], th["desk_left"], th["desk_right"],
                  stroke=th["desk_edge"] if not night else None)
        screen = {"working": "#0E1A06", "night": "#0E1A06", "lead": "#0E1A06", "receive": "#0B1A26",
                  "report": "#0C1A0F", "error": "#261010", "queued": "#1F1A08"}.get(state, "#121316")
        if state == "error" and int(self._phase * 2) % 2:
            screen = "#3A1212"
        self._box(p, x + 30, y + 8, z + 34, 50, 6, 36, "#33363D", screen, "#2A2D33")
        s = P(x + 55, y + 11, z + 60)
        if state in ("working", "night", "lead"):
            p.setPen(QPen(_qc(glow, 0.85), 2 * self._scale))
            shift = (self._phase * 6) % 6
            for k in range(3):
                p.drawLine(QPointF(s.x() - 14 * self._scale, s.y() + (-6 + k * 6 - shift * 0.2) * self._scale),
                           QPointF(s.x() + (10 - k * 5) * self._scale, s.y() + (-6 + k * 6 - 10 - shift * 0.2) * self._scale))
        elif state == "error":
            self._text(p, s, "!", "#FF7A7A", 14, bold=True)
        elif state == "report":
            self._text(p, s, "✓", "#7DDC7A", 14, bold=True)
        # V6.8: nhân vật theo MẪU HÌNH chọn trong Cài đặt (robot / người / phi hành gia / cầu AI / mèo)
        rx, ry = x + 55, y + 78
        bob = 2.5 * math.sin(self._phase * 4 + x) if state in ("working", "night", "lead") else 0
        style = avatars.resolve_style(self.avatar_settings, desk.get("agent_id"), bool(desk.get("lead")))
        top = avatars.paint_avatar(self, p, rx, ry, z, state, style, glow, night, bob, lead=bool(desk.get("lead")))
        # bảng tên
        plate = P(x + 55, y + 60, z)
        name = desk.get("name") or ""
        if desk.get("lead"):
            name = f"TP · {name}"
        border = glow if state not in ("idle", "sleep") else "#2E3036"
        if style.get("show_name", True):
            rect = self._pill(p, QPointF(plate.x(), plate.y() + 16 * self._scale), name, "#16171B", "#ECEEF1",
                              border=border, size=9.5)
        else:
            rect = QRectF(plate.x() - 1, plate.y() - 1, 2, 2)
        # V6.7: CHIP trạng thái gọn trên đầu robot (luôn hiện, thay chữ dài)
        chip = desk.get("chip") if style.get("show_chip", True) else None
        if chip:
            tone = TONE_COLOR.get(chip.get("tone"), "#3A3D44")
            head_top = P(rx, ry, z + top + 12 + bob)
            label = f"{chip['icon']} {chip['text']}".strip()
            dark = chip.get("tone") in ("working", "lead", "report", "receive", "queued", "error")
            self._pill(p, QPointF(head_top.x(), head_top.y() - 4 * self._scale), label,
                       tone if dark else "#1B1D22", "#141A05" if chip.get("tone") in ("working", "lead", "queued", "report")
                       else ("#0B1A26" if chip.get("tone") == "receive" else "#ECEEF1"),
                       border=None if dark else "#3A3D44", size=8.5)
        # vùng bấm: cả bàn + robot
        corners = [P(x, y, z), P(x + 110, y, z), P(x + 110, y + 90, z), P(x, y + 90, z), P(rx, ry, z + top + 30)]
        xs = [c.x() for c in corners]
        ys = [c.y() for c in corners]
        hit = QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)).united(rect)
        self._hits.append((hit, desk.get("agent_id") if desk.get("agent_id") is not None else "lead"))

    def _bubble_alpha(self, desk) -> float:
        """V6.7 — ẩn/hiện linh hoạt: bong bóng tự hiện khi có tin MỚI (25 giây,
        mờ dần 6 giây cuối); rê chuột / chọn bàn thì hiện lại tin gần nhất."""
        bubble = desk.get("bubble")
        if not bubble:
            return 0.0
        key = desk.get("agent_id") if desk.get("agent_id") is not None else "lead"
        if key == self._hover or (self.selected is not None and desk.get("agent_id") == self.selected):
            return 1.0
        age = float(bubble.get("age", 9999)) + (time.monotonic() - getattr(self, "_built_at", time.monotonic()))
        fresh = office_feed.BUBBLE_FRESH_S
        if age >= fresh:
            return 0.0
        return 1.0 if age < fresh - 6 else max(0.0, (fresh - age) / 6)

    def _paint_bubble(self, p, x, y, z, desk):
        bubble = desk.get("bubble")
        alpha = self._bubble_alpha(desk)
        if not bubble or alpha <= 0.01:
            return
        p.setOpacity(alpha)
        try:
            self._paint_bubble_inner(p, x, y, z, desk, bubble)
        finally:
            p.setOpacity(1.0)

    def _paint_bubble_inner(self, p, x, y, z, desk, bubble):
        top = avatars.top_height(avatars.resolve_style(self.avatar_settings, desk.get("agent_id"), bool(desk.get("lead"))))
        anchor = self.P(x + 55, y + 78, z + top + 40)
        color = TONE_COLOR.get(bubble.get("tone"), "#6CC7FF")
        font = QFont(self.font())
        font.setPointSizeF(max(7.5, 9.5 * min(1.15, self._scale)))
        p.setFont(font)
        fm = QFontMetrics(font)
        width = max(120.0, min(230.0, 230 * self._scale))
        head = bubble.get("who") or ""
        text = bubble.get("text") or ""
        # tối đa 3 dòng — phần dài xem ở luồng trao đổi / khung chat
        approx = int((width - 18) / max(5.0, fm.averageCharWidth())) * 3
        if len(text) > approx:
            text = text[: max(10, approx - 1)].rstrip() + "…"
        body = fm.boundingRect(QRectF(0, 0, width - 18, 400).toRect(), Qt.TextFlag.TextWordWrap, text)
        head_h = fm.height() + 2 if head else 0
        height = body.height() + head_h + 14
        dx = -60 * self._scale if desk.get("lead") else 0
        rect = QRectF(anchor.x() - width / 2 + dx, anchor.y() - height - 10 * self._scale, width, height)
        if rect.left() < 4:
            rect.moveLeft(4)
        if rect.right() > self.width() - 4:
            rect.moveRight(self.width() - 4)
        if rect.top() < 4:
            rect.moveTop(4)
        # V6.6: tránh bong bóng chồng nhau — đẩy lên (hoặc sang ngang) tới chỗ trống
        for _attempt in range(6):
            clash = next((r for r in self._placed if r.adjusted(-4, -4, 4, 4).intersects(rect)), None)
            if clash is None:
                break
            if clash.top() - rect.height() - 6 > 4:
                rect.moveBottom(clash.top() - 6)
            else:
                rect.moveLeft(clash.right() + 8 if rect.center().x() >= clash.center().x() else clash.left() - rect.width() - 8)
        self._placed.append(QRectF(rect))
        p.setPen(QPen(_qc(color, 0.95), 1.5))
        p.setBrush(_qc("#16171B", 0.96))
        p.drawRoundedRect(rect, 10, 10)
        tip_x = max(rect.left() + 12, min(rect.right() - 12, anchor.x()))
        if rect.bottom() < anchor.y() - 30:
            p.setPen(QPen(_qc(color, 0.5), 1, Qt.PenStyle.DotLine))
            p.drawLine(QPointF(tip_x, rect.bottom()), anchor)
            p.setPen(QPen(_qc(color, 0.95), 1.5))
        tail = QPolygonF([QPointF(tip_x - 6, rect.bottom() - 1), QPointF(tip_x + 6, rect.bottom() - 1),
                          QPointF(tip_x, rect.bottom() + 8)])
        p.drawPolygon(tail)
        if head:
            bold = QFont(font)
            bold.setBold(True)
            p.setFont(bold)
            p.setPen(_qc(color))
            p.drawText(QRectF(rect.left() + 9, rect.top() + 6, width - 18, head_h), Qt.AlignmentFlag.AlignLeft, head)
            p.setFont(font)
        p.setPen(_qc("#ECEEF1" if bubble.get("real") else "#9AA0A8"))
        p.drawText(QRectF(rect.left() + 9, rect.top() + 6 + head_h, width - 18, body.height() + 4),
                   int(Qt.TextFlag.TextWordWrap), text)

    def _paint_flights(self, p):
        now = time.monotonic()
        for f in self.flights:
            a, b = self.anchor(f["src"]), self.anchor(f["dst"])
            if a is None or b is None:
                continue
            t = min(1.0, (now - f["t0"]) / FLIGHT_S)
            mid = QPointF((a.x() + b.x()) / 2, min(a.y(), b.y()) - 80 * self._scale)
            path = QPainterPath(a)
            path.quadTo(mid, b)
            pen = QPen(_qc(f["color"], 0.8), 2.2 * self._scale, Qt.PenStyle.DashLine)
            p.setPen(pen)
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawPath(path)
            point = path.pointAtPercent(t)
            self._pill(p, point, f["label"], "#16171B", "#ECEEF1", border=f["color"], size=10, glow=True)

    def _paint_pops(self, p):
        now = time.monotonic()
        for pop in self.pops:
            anchor = self.anchor(pop["agent"])
            if anchor is None:
                continue
            t = (now - pop["t0"]) / 2.5
            lift = 30 * self._scale * min(1.0, t * 3)
            self._pill(p, QPointF(anchor.x() + 70 * self._scale, anchor.y() - lift), pop["text"], "#0B1A26",
                       "#6CC7FF", border="#6CC7FF", size=11, alpha=max(0.0, 1.0 - max(0.0, t - 0.6) / 0.4))

    def _text(self, p, at: QPointF, text, color, size, bold=False):
        font = QFont(self.font())
        font.setPointSizeF(max(6.0, size * min(1.2, self._scale)))
        font.setBold(bold)
        p.setFont(font)
        p.setPen(_qc(color))
        rect = QRectF(at.x() - 200, at.y() - 12, 400, 24)
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)

    def _pill(self, p, center: QPointF, text, fill, ink, border=None, size=10, alpha=1.0, glow=False) -> QRectF:
        font = QFont(self.font())
        font.setPointSizeF(max(6.5, size * min(1.15, self._scale)))
        font.setBold(True)
        p.setFont(font)
        fm = QFontMetrics(font)
        w = fm.horizontalAdvance(text) + 18
        h = fm.height() + 6
        rect = QRectF(center.x() - w / 2, center.y() - h / 2, w, h)
        if glow:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(_qc(border or fill, 0.18 * alpha))
            p.drawRoundedRect(rect.adjusted(-5, -5, 5, 5), h / 2 + 5, h / 2 + 5)
        p.setPen(QPen(_qc(border, alpha), 1.4) if border else Qt.PenStyle.NoPen)
        p.setBrush(_qc(fill, alpha))
        p.drawRoundedRect(rect, h / 2, h / 2)
        p.setPen(_qc(ink, alpha))
        p.drawText(rect, Qt.AlignmentFlag.AlignCenter, text)
        return rect

    # ---------------------------------------------------------- chuột
    def _hit(self, pos) -> object:
        for rect, key in reversed(self._hits):
            if rect.contains(pos):
                return key
        return None

    def mousePressEvent(self, event):
        key = self._hit(event.position())
        if key == "lead":
            key = None
        self.agent_clicked.emit(key)

    def mouseMoveEvent(self, event):
        key = self._hit(event.position())
        self.setCursor(Qt.CursorShape.PointingHandCursor if key is not None else Qt.CursorShape.ArrowCursor)
        if key != self._hover:
            self._hover = key
            self.update()

    def leaveEvent(self, event):
        if self._hover is not None:
            self._hover = None
            self.update()
        super().leaveEvent(event)


class _FeedPanel(QFrame):
    agent_clicked = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("OfficeFeed")
        # V7.0: không còn trần 380px — kéo rộng bằng thanh chia, hoặc bấm "⤢ Mở rộng".
        self.setMinimumWidth(260)
        self.expanded = False
        self.full_text = True
        self.setStyleSheet(
            f"QFrame#OfficeFeed {{ background: {theme.PANEL}; border-left: 1px solid {theme.BORDER}; }}"
            "QFrame#OfficeFeed QLabel { background: transparent; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 12, 10, 10)
        layout.setSpacing(8)
        head = QHBoxLayout()
        head.setSpacing(6)
        self.title = theme.section_header("Luồng trao đổi · trực tiếp")
        head.addWidget(self.title, 1)
        self.full_button = QPushButton("≡ Đầy đủ")
        self.full_button.setCheckable(True)
        self.full_button.setChecked(True)
        self.full_button.setToolTip("Hiện TOÀN BỘ nội dung từng tin (bỏ chọn để xem tóm tắt 1–2 dòng)")
        self.full_button.toggled.connect(self._set_full)
        head.addWidget(self.full_button)
        self.expand_button = QPushButton("⤢ Mở rộng")
        self.expand_button.setToolTip("Mở rộng luồng trao đổi chiếm phần lớn tab (bấm lại để thu gọn)")
        head.addWidget(self.expand_button)
        layout.addLayout(head)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }")
        host = QWidget()
        self.list = QVBoxLayout(host)
        self.list.setContentsMargins(0, 0, 6, 0)
        self.list.setSpacing(7)
        self.list.addStretch(1)
        self.scroll.setWidget(host)
        layout.addWidget(self.scroll, 1)
        legend = QLabel(
            "<span style='color:#CEFC19'>■</span> Trưởng phòng &nbsp; <span style='color:#6CC7FF'>■</span> Muse trả lời thật"
            " &nbsp; <span style='color:#9AA0A8'>■</span> trạng thái do app ghi")
        legend.setStyleSheet(f"color: {theme.FAINT}; font-size: 11px;")
        legend.setWordWrap(True)
        layout.addWidget(legend)
        self._ids: tuple = ()
        self._stick = True
        bar = self.scroll.verticalScrollBar()
        bar.rangeChanged.connect(lambda _a, b: bar.setValue(b) if self._stick else None)
        bar.valueChanged.connect(lambda v: setattr(self, "_stick", v >= bar.maximum() - 20))

    def _set_full(self, on: bool):
        self.full_text = bool(on)
        self._ids = ()
        self.set_feed(getattr(self, "_last_feed", []), getattr(self, "_last_mode", "work"))

    def set_feed(self, feed: list[dict], mode: str):
        self._last_feed, self._last_mode = feed, mode
        self.title.setText("LUỒNG TRAO ĐỔI · " + ("TRỰC TIẾP" if mode == "work" else "TRỰC ĐÊM"))
        ids = tuple((e["id"], e.get("full") or e["text"]) for e in feed)
        if ids == self._ids:
            return
        self._ids = ids
        while self.list.count() > 1:
            item = self.list.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        if not feed:
            empty = theme.muted_label("Chưa có trao đổi nào. Giao một việc ở tab Công việc — trưởng phòng sẽ chuyển "
                                      "cho Muse và cuộc trò chuyện hiện ở đây.")
            empty.setWordWrap(True)
            self.list.insertWidget(0, empty)
            return
        for entry in feed:
            self.list.insertWidget(self.list.count() - 1, self._bubble(entry))

    def _bubble(self, e: dict) -> QWidget:
        kind = e["kind"]
        label = QLabel()
        label.setWordWrap(True)
        label.setTextFormat(Qt.TextFormat.RichText)
        label.setCursor(Qt.CursorShape.PointingHandCursor)
        raw = (e.get("full") or e["text"] or "") if self.full_text and kind != "sys" else (e["text"] or "")
        text = raw.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
        t = f"<span style='color:{theme.FAINT}; font-size:10px'>&nbsp;{e['time']}</span>"
        if kind == "lead":
            html = f"<b style='color:#CEFC19'>Trưởng phòng → {e['agent']}</b>{t}<br>{text}"
            style = "background:#1F2A0A; border:1px solid #4D5F12;"
        elif kind == "agent":
            color = {"done": "#7DDC7A", "needs_user": "#FF7A7A", "ack": "#6CC7FF"}.get(e.get("verdict"), "#6CC7FF")
            html = f"<b style='color:{color}'>{e['agent']}</b>{t}<br>{text}"
            style = f"background:#1B1D22; border:1px solid {color};"
        elif kind == "user":
            html = f"<b style='color:#ECEEF1'>Bạn → {e['agent']}</b>{t}<br>{text}"
            style = "background:#1B1D22; border:1px solid #2E3036;"
        else:
            html = f"<span style='color:#9AA0A8'>{text} · {e['agent']}</span>{t}"
            style = "background:transparent; border:none;"
        label.setText(html)
        label.setStyleSheet(f"QLabel {{ {style} border-radius:10px; padding:7px 10px; color:#ECEEF1; font-size:12px; }}")
        holder = QWidget()
        row = QHBoxLayout(holder)
        row.setContentsMargins(0, 0, 0, 0)
        # V7.0: bong bóng giãn theo bề rộng panel (≈88%), chữ chọn/copy được.
        label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        if kind in ("agent", "user"):
            row.addStretch(1)
            row.addWidget(label, 8)
        elif kind == "sys":
            row.addWidget(label, 1)
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        else:
            row.addWidget(label, 8)
            row.addStretch(1)
        aid = int(e["agent_id"])
        label.mousePressEvent = lambda _ev, a=aid: self.agent_clicked.emit(a)
        return holder


class OfficeIsoView(QWidget):
    """Văn phòng 3D V6.6 = thanh chế độ + sân khấu isometric + luồng trao đổi."""

    agent_clicked = Signal(object)

    def __init__(self, store=None, settings: dict | None = None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings if settings is not None else {}
        self._version = None
        self._last_build = 0.0
        self._first = True
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        bar = QHBoxLayout()
        bar.setContentsMargins(12, 6, 12, 6)
        bar.setSpacing(8)
        self._mode_group = QButtonGroup(self)
        self.mode_buttons = {}
        for key, text in (("auto", "🕘 Tự động theo giờ"), ("work", "☀ Làm việc"), ("off", "🌙 Ngoài giờ")):
            button = QPushButton(text)
            button.setObjectName("FilterPill")
            button.setCheckable(True)
            button.clicked.connect(lambda _c=False, k=key: self.set_office_mode(k))
            self._mode_group.addButton(button)
            self.mode_buttons[key] = button
            bar.addWidget(button)
        self.hours_label = theme.muted_label("")
        self.hours_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)  # co lại khi panel chi tiết mở rộng
        bar.addWidget(self.hours_label, 1)
        bar.addStretch(1)
        self.counts_label = QLabel("")
        self.counts_label.setStyleSheet(f"color: {theme.MUTED};")
        self.counts_label.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.counts_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        bar.addWidget(self.counts_label, 2)
        self.avatar_button = QPushButton("🎨 Giao diện && hình agent")
        self.avatar_button.setToolTip("Mẫu văn phòng, màu sàn/tường/bàn, đồ trang trí + mẫu nhân vật 3D, màu, kích thước (chung hoặc riêng từng agent)")
        self.avatar_button.clicked.connect(self.open_avatar_dialog)
        bar.addWidget(self.avatar_button)
        self.progress_toggle = QPushButton("📊 Tiến độ")
        self.progress_toggle.setCheckable(True)
        self.progress_toggle.setChecked(bool(self._settings.get("office_progress_visible", True)))
        self.progress_toggle.setToolTip("Hiện/ẩn cột tiến độ: từng agent đang làm việc gì, kênh nào, bao nhiêu %")
        self.progress_toggle.toggled.connect(self._toggle_progress)
        bar.addWidget(self.progress_toggle)
        self.feed_toggle = QPushButton("💬 Luồng trao đổi")
        self.feed_toggle.setCheckable(True)
        self.feed_toggle.setChecked(bool(self._settings.get("office_feed_visible", True)))
        self.feed_toggle.toggled.connect(self._toggle_feed)
        bar.addWidget(self.feed_toggle)
        root.addLayout(bar)
        # V7.0: sân khấu | luồng trao đổi chia bằng THANH KÉO (nhớ tỉ lệ).
        self.body_split = QSplitter(Qt.Orientation.Horizontal)
        self.body_split.setChildrenCollapsible(False)
        self.body_split.setHandleWidth(5)
        # V7.1: CỘT TIẾN ĐỘ bên trái — ai đang làm gì, % cụ thể
        from .office_progress import ProgressPanel

        self.progress = ProgressPanel()
        self.progress.agent_clicked.connect(self.agent_clicked.emit)
        self.progress.setVisible(self.progress_toggle.isChecked())
        self.body_split.addWidget(self.progress)
        self.stage = _IsoStage()
        self.stage.avatar_settings = self._settings
        self.stage.agent_clicked.connect(self.agent_clicked.emit)
        self.stage.setMinimumWidth(320)
        self.body_split.addWidget(self.stage)
        self.feed = _FeedPanel()
        self.feed.agent_clicked.connect(self.agent_clicked.emit)
        self.feed.setVisible(self.feed_toggle.isChecked())
        self.feed.expand_button.clicked.connect(self.toggle_feed_expanded)
        self.body_split.addWidget(self.feed)
        self.body_split.setStretchFactor(0, 0)
        self.body_split.setStretchFactor(1, 1)
        self.body_split.setStretchFactor(2, 0)
        saved = self._settings.get("office_feed_split3")
        if isinstance(saved, list) and len(saved) == 3 and all(isinstance(v, int) and v >= 0 for v in saved) and saved[1] > 0:
            self.body_split.setSizes(saved)
        else:
            self.body_split.setSizes([330, 820, 440])
        self.body_split.splitterMoved.connect(self._remember_split)
        root.addWidget(self.body_split, 1)
        self.mode_buttons.get(str(self._settings.get("office_mode") or "auto"), self.mode_buttons["auto"]).setChecked(True)
        self._data_timer = QTimer(self)
        self._data_timer.setInterval(1000)
        self._data_timer.timeout.connect(self.refresh)
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(40)
        self._anim_timer.timeout.connect(self._animate)
        self._anim_last = time.monotonic()

    # -------------------------------------------------------------- API
    def set_selected(self, agent_id):
        self.stage.selected = agent_id
        self.stage.update()

    def set_office_mode(self, mode: str):
        self._settings["office_mode"] = mode
        try:
            from .. import config as _config

            _config.save_settings(self._settings)
        except Exception:
            pass
        self.refresh(force=True)

    def open_avatar_dialog(self):
        from .avatar_dialog import AvatarDialog

        dialog = AvatarDialog(self._settings, self._store, self)
        if dialog.exec():
            self.stage.update()

    def _remember_split(self, *_args):
        sizes = self.body_split.sizes()
        if len(sizes) == 3 and sizes[1] > 0:
            self._settings["office_feed_split3"] = [int(v) for v in sizes]

    def toggle_feed_expanded(self):
        sizes = self.body_split.sizes()
        total = max(1, sum(sizes))
        left = sizes[0]
        self.feed.expanded = not self.feed.expanded
        if self.feed.expanded:
            self._split_before = sizes
            rest = total - left
            self.body_split.setSizes([left, int(rest * 0.32), int(rest * 0.68)])
            self.feed.expand_button.setText("⤡ Thu gọn")
        else:
            before = getattr(self, "_split_before", None) or [left, int((total - left) * 0.7), int((total - left) * 0.3)]
            self.body_split.setSizes(before)
            self.feed.expand_button.setText("⤢ Mở rộng")
        self._remember_split()

    def _toggle_progress(self, on: bool):
        self.progress.setVisible(on)
        self._settings["office_progress_visible"] = bool(on)
        if on:
            self.refresh(force=True)

    def _toggle_feed(self, on: bool):
        self.feed.setVisible(on)
        self._settings["office_feed_visible"] = bool(on)

    def showEvent(self, event):
        super().showEvent(event)
        self._data_timer.start()
        self._anim_timer.start()
        self.refresh(force=True)

    def hideEvent(self, event):
        self._data_timer.stop()
        self._anim_timer.stop()
        super().hideEvent(event)

    def _animate(self):
        now = time.monotonic()
        dt = now - self._anim_last
        self._anim_last = now
        if self.stage.animating():
            self.stage.tick(dt)
            self._anim_timer.setInterval(40 if (self.stage.flights or self.stage.pops) else 120)
        else:
            self._anim_timer.setInterval(500)

    def refresh(self, force: bool = False):
        if self._store is None:
            return
        try:
            version = self._store.data_version()
        except Exception:
            version = None
        now = time.monotonic()
        if not force and version == self._version and now - self._last_build < 15:
            return
        self._version = version
        self._last_build = now
        try:
            data = office_feed.build(self._store, self._settings)
        except Exception:
            return
        events = data.get("events") or []
        seen = getattr(self, "_seen", set())
        fresh = [] if self._first else [e for e in events if e["id"] not in seen]
        self._seen = (seen | {e["id"] for e in events}) if len(seen) < 5000 else {e["id"] for e in events}
        self.stage.set_data(data, fresh)
        self._first = False
        self.feed.set_feed(data.get("feed") or [], data.get("mode"))
        if self.progress.isVisible():
            try:
                from .. import progress_board

                self.progress.set_data(progress_board.build(self._store, self._settings))
            except Exception:
                pass
        c = data.get("counts") or {}
        self.hours_label.setText(f"Giờ làm việc {data.get('hours')} · đang: "
                                 + ("☀ làm việc" if data.get("mode") == "work" else "🌙 ngoài giờ"))
        self.counts_label.setText(f"Đang làm <b style='color:#ECEEF1'>{c.get('working', 0)}</b> · "
                                  f"Chờ nhận <b style='color:#ECEEF1'>{c.get('receive', 0)}</b> · "
                                  f"Lỗi <b style='color:#ECEEF1'>{c.get('error', 0)}</b> · "
                                  f"Chờ giờ <b style='color:#ECEEF1'>{c.get('queued', 0)}</b> · "
                                  f"Rảnh <b style='color:#ECEEF1'>{c.get('idle', 0)}</b>")
