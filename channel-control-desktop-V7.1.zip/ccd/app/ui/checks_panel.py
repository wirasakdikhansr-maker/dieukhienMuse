"""Panel "Kiểm tra" (V3) — khám sức khoẻ từng hồ sơ/kênh.

Mỗi hồ sơ một thẻ: Chrome có đang chạy + CDP nối được không; đã đăng
nhập Google/YouTube chưa (thăm dò phiên qua scanner); kênh truy cập
được không; số liệu cập nhật lần cuối khi nào; có video nào đang
Scheduled không (từ dữ liệu kho). Dòng kết quả hiển thị ✓ / ✗ / – kèm
thời điểm kiểm tra; kết quả lưu vào bảng profile_checks (Muse đọc lại
qua GET /api/profiles trường last_check).

Việc kiểm tra chạy trong thread riêng với Store mở-tại-thread đó.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .. import checks, diagnostics
from ..chrome_manager import ChromeManager
from ..store import Store
from . import theme
from .command_runner import FuncWorker

GLYPHS = {"ok": ("✓", "CheckGlyphOk"), "fail": ("✗", "CheckGlyphFail"), "na": ("–", "CheckGlyphNa")}


class _EngineBridge(QObject):
    """Cầu nối kết quả việc nền (luồng engine) về luồng UI qua Signal."""

    done = Signal(object)
    failed = Signal(str)


class ChecksPanel(QWidget):
    def __init__(self, store: Store, db_path, manager: ChromeManager, notify=None,
                 submit_custom=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._db_path = db_path
        self._manager = manager
        self._notify = notify or (lambda _line: None)
        self._worker: FuncWorker | None = None
        # V3.1: nộp việc qua hàng đợi chung của app (JobEngine) nếu cửa sổ
        # chính cấp; đứng độc lập thì rơi về FuncWorker như cũ.
        self._submit_custom = submit_custom
        self._bridge: _EngineBridge | None = None
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        header = QHBoxLayout()
        header.addWidget(theme.section_header("Kiểm tra hệ thống"))
        header.addStretch(1)
        self.run_all_button = QPushButton("▶ Kiểm tra tất cả")
        self.run_all_button.setProperty("variant", "primary")
        self.run_all_button.clicked.connect(self._run_all)
        header.addWidget(self.run_all_button)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.cards_host = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setContentsMargins(0, 0, 0, 0)
        self.cards_layout.setSpacing(12)
        self.cards_layout.addStretch(1)
        self.scroll.setWidget(self.cards_host)
        root.addWidget(self.scroll, 1)

    # ------------------------------------------------------------------ #
    def refresh(self):
        while self.cards_layout.count() > 1:
            item = self.cards_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                # V4.3.2: ẩn + gỡ parent ngay, tránh thẻ cũ vẽ chồng
                # trong lúc chờ deleteLater (cùng bài học bảng kênh).
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        index = 0
        diag_card = self._build_diagnostics_card()
        if diag_card is not None:
            self.cards_layout.insertWidget(index, diag_card)
            index += 1
        profiles = self._store.list_profiles()
        if not profiles:
            empty = theme.muted_label("Chưa có hồ sơ nào — thêm hồ sơ ở mục Hồ sơ.")
            self.cards_layout.insertWidget(index, empty)
            return
        for profile in profiles:
            self.cards_layout.insertWidget(index, self._build_card(profile))
            index += 1

    def _build_diagnostics_card(self) -> QFrame | None:
        """Thẻ chẩn đoán khởi động (V3.1) — kết quả tự kiểm tra môi trường
        lúc mở app, lưu trong app_meta bởi app.diagnostics."""
        try:
            saved = diagnostics.load_saved_diagnostics(self._store)
        except Exception:
            saved = None
        if not saved or not saved.get("items"):
            return None
        card = theme.card_frame()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(8)
        title = QLabel("Chẩn đoán khởi động")
        title.setObjectName("CardTitle")
        layout.addWidget(title)
        meta = theme.muted_label(
            f"{saved.get('summary', '')} · lúc {_fmt_ts(saved.get('ts'))}"
        )
        meta.setWordWrap(True)
        layout.addWidget(meta)
        self._add_item_rows(layout, saved["items"])
        return card

    @staticmethod
    def _add_item_rows(layout: QVBoxLayout, items: list[dict]):
        for item in items:
            glyph_text, glyph_name = GLYPHS.get(item["status"], GLYPHS["na"])
            row = QHBoxLayout()
            row.setSpacing(10)
            glyph = QLabel(glyph_text)
            glyph.setObjectName(glyph_name)
            glyph.setFixedWidth(22)
            glyph.setAlignment(Qt.AlignmentFlag.AlignCenter)
            row.addWidget(glyph)
            label = QLabel(item["label"])
            label.setMinimumWidth(240)
            row.addWidget(label)
            detail = theme.muted_label(item["detail"])
            detail.setWordWrap(True)
            row.addWidget(detail, 1)
            layout.addLayout(row)

    def _build_card(self, profile: dict) -> QFrame:
        card = theme.card_frame()
        layout = QVBoxLayout(card)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(8)

        header = QHBoxLayout()
        header.setSpacing(10)
        header.addWidget(theme.avatar(profile["label"], profile["slug"]))
        title_box = QVBoxLayout()
        title_box.setSpacing(0)
        title = QLabel(profile["label"])
        title.setObjectName("CardTitle")
        title_box.addWidget(title)
        title_box.addWidget(theme.muted_label(profile["gmail"]))
        header.addLayout(title_box)
        header.addStretch(1)
        run_button = QPushButton("Kiểm tra")
        run_button.clicked.connect(lambda _=False, pid=profile["id"]: self._run_one(pid))
        header.addWidget(run_button)
        layout.addLayout(header)

        last_check = self._store.get_last_check(profile["id"])
        if last_check is None:
            layout.addWidget(theme.muted_label("Chưa kiểm tra lần nào."))
            return card

        meta = theme.muted_label(
            f"Lần kiểm tra gần nhất: {_fmt_ts(last_check['ts'])} — {last_check['summary']}"
        )
        meta.setWordWrap(True)
        layout.addWidget(meta)
        self._add_item_rows(layout, last_check["items"])
        return card

    # ------------------------------------------------------------------ #
    def _run_one(self, profile_id: int):
        profile = self._store.get_profile(profile_id)
        if profile is None:
            return
        self._start_checks([profile])

    def _run_all(self):
        profiles = [p for p in self._store.list_profiles() if not p["paused"]]
        if not profiles:
            self._notify("Không có hồ sơ nào để kiểm tra.")
            return
        self._start_checks(profiles)

    def _start_checks(self, profiles: list[dict]):
        if self._worker is not None and self._worker.isRunning():
            self._notify("Đang có lượt kiểm tra chạy — chờ xong đã.")
            return
        if self._bridge is not None:
            self._notify("Đang có lượt kiểm tra chạy — chờ xong đã.")
            return
        self.run_all_button.setEnabled(False)
        db_path, manager = self._db_path, self._manager

        def job():
            store = Store(db_path)
            try:
                return [
                    checks.run_profile_checks(store, profile, manager)
                    for profile in profiles
                ]
            finally:
                store.close()

        if self._submit_custom is not None:
            bridge = _EngineBridge(self)
            bridge.done.connect(self._on_checks_done)
            bridge.failed.connect(self._on_checks_failed)
            self._bridge = bridge

            def _on_done(engine_job):
                self._bridge = None
                if engine_job.status == "done":
                    bridge.done.emit(engine_job.result)
                else:
                    bridge.failed.emit(engine_job.error or "Việc kiểm tra thất bại.")

            self._submit_custom(
                lambda _token: job(),
                profile_id=profiles[0]["id"] if len(profiles) == 1 else None,
                kind="check",
                on_done=_on_done,
            )
        else:
            self._worker = FuncWorker(job, parent=self)
            self._worker.done.connect(self._on_checks_done)
            self._worker.failed.connect(self._on_checks_failed)
            # Chỉ thả tham chiếu khi thread đã finished THẬT (reaper) —
            # không bao giờ để QThread mất chủ trong lúc còn chạy.
            self._worker.finished.connect(self._reap_worker)
            self._worker.start()
        self._notify(f"Đang kiểm tra {len(profiles)} hồ sơ…")

    def _reap_worker(self):
        worker, self._worker = self._worker, None
        if worker is not None:
            worker.deleteLater()

    def _on_checks_done(self, results):
        self.run_all_button.setEnabled(True)
        for saved in results or []:
            self._notify(f"Kiểm tra xong: {saved['summary']}")
        self.refresh()

    def _on_checks_failed(self, error: str):
        self.run_all_button.setEnabled(True)
        self._notify(f"Kiểm tra thất bại: {error}")
        self.refresh()


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m/%Y %H:%M:%S")
    except ValueError:
        return str(value)
