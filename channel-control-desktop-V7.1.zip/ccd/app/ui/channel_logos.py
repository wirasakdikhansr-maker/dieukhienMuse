"""V7.0 — LOGO KÊNH dùng chung (YouTube / Facebook page / TikTok).

Ảnh lấy từ ``channels.avatar_url`` (quét kênh ghi vào), tải NỀN một lần về
``data/avatars/<channel_id>.img`` (cùng chỗ bảng kênh ở tab Hồ sơ dùng) rồi cắt
tròn theo kích thước cần. Chưa có ảnh → avatar chữ cái + huy hiệu nền tảng.
"""

from __future__ import annotations

import threading
from pathlib import Path

from PySide6.QtCore import QObject, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPixmap

from .. import config

PLATFORM_BADGE = {
    "youtube": ("▶", "#FF3B30"),
    "facebook": ("f", "#1877F2"),
    "tiktok": ("♪", "#111111"),
}


class _Notifier(QObject):
    fetched = Signal(str)


NOTIFIER = None
_PENDING: set[str] = set()
_FAILED: set[str] = set()
_CACHE: dict[tuple[str, int], QPixmap] = {}
_LOCK = threading.Lock()


def notifier() -> _Notifier:
    global NOTIFIER
    if NOTIFIER is None:
        NOTIFIER = _Notifier()
    return NOTIFIER


def logo_path(channel_id: str) -> Path:
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(channel_id or ""))
    return config.data_dir() / "avatars" / f"{safe}.img"


def _circle(source: QPixmap, size: int) -> QPixmap:
    out = QPixmap(size, size)
    out.fill(Qt.GlobalColor.transparent)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
    path = QPainterPath()
    path.addEllipse(QRectF(0, 0, size, size))
    p.setClipPath(path)
    scaled = source.scaled(size, size, Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                           Qt.TransformationMode.SmoothTransformation)
    p.drawPixmap((size - scaled.width()) // 2, (size - scaled.height()) // 2, scaled)
    p.end()
    return out


def _badge(pixmap: QPixmap, platform: str) -> QPixmap:
    glyph, color = PLATFORM_BADGE.get(platform or "youtube", PLATFORM_BADGE["youtube"])
    if platform in (None, "", "youtube"):
        return pixmap  # kênh YouTube: không cần huy hiệu
    size = pixmap.width()
    b = max(12, size // 3)
    out = QPixmap(pixmap)
    p = QPainter(out)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    rect = QRectF(size - b, size - b, b, b)
    p.setBrush(QColor(color))
    p.setPen(QColor("#0C0D0F"))
    p.drawEllipse(rect)
    font = QFont()
    font.setBold(True)
    font.setPixelSize(int(b * 0.7))
    p.setFont(font)
    p.setPen(QColor("#FFFFFF"))
    p.drawText(rect, Qt.AlignmentFlag.AlignCenter, glyph)
    p.end()
    return out


def pixmap(channel: dict, size: int = 36) -> QPixmap | None:
    """Logo tròn của kênh từ bộ nhớ đệm; None nếu chưa tải."""
    channel_id = str(channel.get("channel_id") or "")
    if not channel_id:
        return None
    key = (channel_id + "|" + str(channel.get("platform") or ""), int(size))
    if key in _CACHE:
        return _CACHE[key]
    path = logo_path(channel_id)
    if not path.exists() or path.stat().st_size < 64:
        return None
    source = QPixmap(str(path))
    if source.isNull():
        return None
    result = _badge(_circle(source, int(size)), str(channel.get("platform") or ""))
    _CACHE[key] = result
    return result


def request(channels: list[dict]) -> int:
    """Tải nền logo các kênh chưa có ảnh. Trả số kênh đưa vào hàng đợi."""
    jobs = []
    with _LOCK:
        for ch in channels or []:
            channel_id = str(ch.get("channel_id") or "")
            url = str(ch.get("avatar_url") or "")
            if not channel_id or not url.startswith("http") or channel_id in _PENDING or channel_id in _FAILED:
                continue
            if logo_path(channel_id).exists():
                continue
            _PENDING.add(channel_id)
            jobs.append((channel_id, url))
    if not jobs:
        return 0
    note = notifier()

    def work():
        import urllib.request

        for channel_id, url in jobs:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=10) as response:
                    data = response.read(2_000_000)
                path = logo_path(channel_id)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(data)
                ok = True
            except Exception:
                ok = False
            with _LOCK:
                _PENDING.discard(channel_id)
                if not ok:
                    _FAILED.add(channel_id)
            if ok:
                try:
                    note.fetched.emit(channel_id)
                except RuntimeError:
                    pass

    threading.Thread(target=work, name="channel-logos", daemon=True).start()
    return len(jobs)
