"""V7.1 — CỘT TIẾN ĐỘ CÔNG VIỆC (bên trái Văn phòng 3D).

Mỗi agent: việc đang làm cụ thể + kênh, ai giao + lúc nào, hạn, thanh % tổng,
bước Muse báo, thanh TIẾN ĐỘ CON đếm được ("cảnh 20/30"), các việc đang chờ.
Đầu cột: trưởng phòng vừa giao gì. Ẩn/hiện bằng nút "📊 Tiến độ" hoặc tam giác
trên thanh chia.
"""

from __future__ import annotations

import html

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from . import theme

STATUS_COLOR = {"running": "#CEFC19", "needs_user": "#C4A7FF", "waiting_muse": "#6CC7FF", "queued": "#F2C94C"}


def _bar(value: int, color: str, height: int = 10, text: str = "") -> QProgressBar:
    bar = QProgressBar()
    bar.setRange(0, 100)
    bar.setValue(max(0, min(100, int(value))))
    bar.setTextVisible(bool(text))
    if text:
        bar.setFormat(text)
        bar.setAlignment(Qt.AlignmentFlag.AlignCenter)
    bar.setFixedHeight(height)
    bar.setStyleSheet(
        f"QProgressBar {{ background:#24272D; border:none; border-radius:{height // 2}px; color:#0C0D0F;"
        f" font-size:10px; font-weight:700; }}"
        f"QProgressBar::chunk {{ background:{color}; border-radius:{height // 2}px; }}")
    return bar


class _AgentBlock(QFrame):
    clicked = Signal(int)

    def __init__(self, entry: dict, parent=None):
        super().__init__(parent)
        self.agent_id = int(entry["agent_id"])
        cur = entry.get("current")
        border = "#F5B841" if entry.get("lead") else (STATUS_COLOR.get((cur or {}).get("status"), theme.BORDER)
                                                       if cur else theme.BORDER)
        self.setObjectName("ProgressBlock")
        self.setStyleSheet(f"QFrame#ProgressBlock {{ background:{theme.CARD}; border:1px solid {border};"
                           f" border-left:3px solid {border}; border-radius:10px; }}"
                           "QFrame#ProgressBlock QLabel { background:transparent; border:none; }")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(4)
        head = QHBoxLayout()
        dot = "🟢" if entry.get("online") else "⚪"
        name = QLabel(f"{dot} {'★ ' if entry.get('lead') else ''}<b>{html.escape(entry['name'])}</b>")
        name.setTextFormat(Qt.TextFormat.RichText)
        name.setStyleSheet(f"color:{theme.TEXT};")
        head.addWidget(name, 1)
        if cur:
            pill = QLabel(cur["status_text"])
            color = STATUS_COLOR.get(cur["status"], theme.MUTED)
            pill.setStyleSheet(f"color:{color}; border:1px solid {color}; border-radius:8px; padding:0 6px; font-size:11px;")
            head.addWidget(pill)
        lay.addLayout(head)
        if not cur:
            idle = QLabel("Rảnh — chưa có việc" + (" (trưởng phòng điều phối)" if entry.get("lead") else ""))
            idle.setStyleSheet(f"color:{theme.FAINT}; font-size:12px;")
            lay.addWidget(idle)
            return
        title = QLabel(html.escape(cur["title"]) + (f" — <span style='color:{theme.MUTED}'>{html.escape(cur['channel'])}</span>"
                                                     if cur.get("channel") else ""))
        title.setTextFormat(Qt.TextFormat.RichText)
        title.setWordWrap(True)
        title.setStyleSheet(f"color:{theme.TEXT}; font-weight:600;")
        lay.addWidget(title)
        meta = f"Giao bởi {cur['by']}" + (f" lúc {cur['assigned_at']}" if cur.get("assigned_at") else "")
        if cur.get("due"):
            meta += f" · hạn {cur['due']}" + (" — TRỄ" if cur.get("overdue") else "")
        meta_label = QLabel(meta)
        meta_label.setStyleSheet(f"color:{'#FF7A7A' if cur.get('overdue') else theme.FAINT}; font-size:11px;")
        lay.addWidget(meta_label)
        row = QHBoxLayout()
        row.setSpacing(6)
        row.addWidget(_bar(cur["pct"], STATUS_COLOR.get(cur["status"], theme.ACCENT), 10), 1)
        pct = QLabel(f"{cur['pct']}%")
        pct.setStyleSheet(f"color:{theme.ACCENT}; font-weight:700;")
        row.addWidget(pct)
        lay.addLayout(row)
        if cur.get("step"):
            step = QLabel("▸ " + html.escape(cur["step"][:220]))
            step.setTextFormat(Qt.TextFormat.RichText)
            step.setWordWrap(True)
            step.setStyleSheet(f"color:{theme.MUTED}; font-size:11px;")
            lay.addWidget(step)
        sub = cur.get("sub")
        if sub:
            sub_row = QHBoxLayout()
            sub_row.setSpacing(6)
            sub_label = QLabel(f"{sub['label'] or 'phần'} {sub['done']}/{sub['total']}")
            sub_label.setStyleSheet("color:#6CC7FF; font-size:11px; font-weight:600;")
            sub_row.addWidget(sub_label)
            sub_row.addWidget(_bar(sub["pct"], "#6CC7FF", 7), 1)
            lay.addLayout(sub_row)
        queue = entry.get("queue") or []
        if queue:
            names = " · ".join(q["title"][:40] for q in queue[:3])
            more = QLabel(f"+{len(queue)} việc chờ: {names}" + (" …" if len(queue) > 3 else ""))
            more.setWordWrap(True)
            more.setStyleSheet(f"color:{theme.FAINT}; font-size:11px;")
            lay.addWidget(more)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.agent_id)
        super().mousePressEvent(event)


class ProgressPanel(QFrame):
    agent_clicked = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("OfficeProgress")
        self.setMinimumWidth(270)
        self.setStyleSheet(f"QFrame#OfficeProgress {{ background:{theme.PANEL}; border-right:1px solid {theme.BORDER}; }}")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 8, 10)
        lay.setSpacing(8)
        self.title = theme.section_header("Tiến độ công việc")
        lay.addWidget(self.title)
        self.lead_box = QLabel("")
        self.lead_box.setTextFormat(Qt.TextFormat.RichText)
        self.lead_box.setWordWrap(True)
        self.lead_box.setStyleSheet("QLabel { background:#1F2A0A; border:1px solid #4D5F12; border-radius:8px;"
                                    " padding:6px 8px; color:#ECEEF1; font-size:11px; }")
        lay.addWidget(self.lead_box)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }")
        host = QWidget()
        self.list = QVBoxLayout(host)
        self.list.setContentsMargins(0, 0, 4, 0)
        self.list.setSpacing(8)
        self.list.addStretch(1)
        self.scroll.setWidget(host)
        lay.addWidget(self.scroll, 1)
        self._fingerprint = None
        self.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)

    def set_data(self, data: dict):
        agents = data.get("agents") or []
        def cur_key(a):
            c = a.get("current") or {}
            return (c.get("id"), c.get("pct"), c.get("step"), c.get("status"), c.get("due"), c.get("overdue"))

        fp = (tuple((a["agent_id"], a["online"], a["lead"], cur_key(a), len(a.get("queue") or [])) for a in agents),
              tuple((x["at"], x["text"]) for x in data.get("lead_log") or []))
        self.title.setText(f"TIẾN ĐỘ CÔNG VIỆC · {data.get('busy', 0)}/{data.get('total', 0)} ĐANG LÀM")
        if fp == self._fingerprint:
            return
        self._fingerprint = fp
        log = data.get("lead_log") or []
        if log:
            rows = "<br>".join(f"<span style='color:#9AA0A8'>{html.escape(x['at'])}</span> {html.escape(x['text'][:120])}"
                               for x in log[:3])
            self.lead_box.setText(f"<b style='color:#CEFC19'>🧑‍💼 Trưởng phòng vừa quyết định</b><br>{rows}")
            self.lead_box.show()
        else:
            self.lead_box.hide()
        while self.list.count() > 1:
            item = self.list.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        if not agents:
            empty = theme.muted_label("Chưa có tài khoản Muse nào.")
            self.list.insertWidget(0, empty)
            return
        for index, entry in enumerate(agents):
            block = _AgentBlock(entry)
            block.clicked.connect(self.agent_clicked.emit)
            self.list.insertWidget(index, block)
