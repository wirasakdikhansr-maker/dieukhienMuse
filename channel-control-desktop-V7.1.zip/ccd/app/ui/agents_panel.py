"""Panel "Tài khoản Muse" (V3.3): quản lý các tài khoản Muse như
thực thể riêng của app — thêm lẻ / nhập HÀNG LOẠT, token cầu nối riêng
từng tài khoản, phân công kênh (một Muse phụ trách NHIỀU hồ sơ; mỗi
hồ sơ một Muse chính), theo dõi trạng thái sống (heartbeat) và lệnh
đang giữ của từng Muse.

Mọi thao tác ghi qua Store; panel chỉ hiển thị + gọi Store, giống các
panel khác. Token chỉ hiện khi người dùng chủ động xuất phiếu kết nối
hoặc cấp lại — bảng chính không bao giờ in token.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import config, tickets
from ..store import Store
from . import theme
from .agent_chat import AgentChatWidget
from .agent_connect import AgentConnectDialog

STATUS_LABELS = {
    "online": "🟢 Đang hoạt động",
    "idle": "🟡 Vừa rời đi",
    "offline": "⚪ Ngoại tuyến",
    "revoked": "🚫 Đã thu hồi",
}

# V4.6: tooltip cột Trạng thái — giải thích HAI LỚP để người dùng
# không còn nhầm "đã đăng nhập muse.ai" với "đã kết nối cầu nối".
STATUS_TOOLTIP = (
    "Hai lớp khác nhau: cột Trạng thái này là CẦU NỐI — agent chỉ "
    "“Đang hoạt động” khi một Muse cầm PHIẾU KẾT NỐI của nó gọi "
    "vào app (heartbeat). Cột “Muse.ai” là phiên đăng nhập web "
    "trong Chrome của tài khoản; đăng nhập web KHÔNG làm agent "
    "online. Bấm nút ở cột Kết nối để xem chi tiết hai lớp."
)


def _fmt_seen(value) -> str:
    if not value:
        return "chưa từng"
    try:
        seen = datetime.fromisoformat(str(value))
    except ValueError:
        return str(value)
    age = (datetime.now().astimezone() - seen).total_seconds()
    if age < 60:
        return "vừa xong"
    if age < 3600:
        return f"{int(age // 60)} phút trước"
    if age < 86400:
        return f"{int(age // 3600)} giờ trước"
    return seen.strftime("%d/%m %H:%M")


def parse_agent_lines(text: str) -> list[dict]:
    """Phân tích danh sách dán vào ô nhập hàng loạt: mỗi dòng dạng
    'Tên | email', 'tên,email' hoặc chỉ 'email'. Bỏ dòng trống/#."""
    entries: list[dict] = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "|" in line:
            name, email = line.split("|", 1)
        elif "," in line:
            name, email = line.split(",", 1)
        else:
            name, email = "", line
        entries.append({"name": name.strip(), "email": email.strip()})
    return entries


class AddAgentDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Thêm tài khoản Muse")
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("vd: Muse Kênh Nhạc")
        self.email_edit = QLineEdit()
        self.email_edit.setPlaceholderText("email đăng ký tài khoản Muse")
        self.note_edit = QLineEdit()
        self.note_edit.setPlaceholderText("Không bắt buộc")
        form.addRow("Tên hiển thị:", self.name_edit)
        form.addRow("Email Muse:", self.email_edit)
        form.addRow("Ghi chú:", self.note_edit)
        layout.addLayout(form)
        hint = QLabel(
            "Token cầu nối riêng sẽ được tự sinh — phiếu kết nối RIÊNG "
            "của tài khoản này (mỗi tài khoản một file "
            "phieu-ket-noi-<tên>.txt) tự động được ghi ra thư mục phiếu "
            "ngay sau khi thêm."
        )
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def values(self) -> dict:
        return {
            "name": self.name_edit.text().strip(),
            "email": self.email_edit.text().strip(),
            "note": self.note_edit.text().strip(),
        }


class BulkImportDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Nhập hàng loạt tài khoản Muse")
        self.resize(560, 420)
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Dán danh sách tài khoản — mỗi dòng một tài khoản, một trong "
            "các dạng:\n"
            "• Tên hiển thị | email@cuamang.ai\n"
            "• tên,email@cuamang.ai\n"
            "• chỉ email@cuamang.ai\n"
            "Email trùng (đã có trong app) sẽ được báo 'trùng' và bỏ qua, "
            "không chặn các dòng khác."
        )
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.text_edit = QPlainTextEdit()
        self.text_edit.setPlaceholderText(
            "Muse Kênh Nhạc | nhac@example.ai\nMuse Review Phim | phim@example.ai"
        )
        layout.addWidget(self.text_edit, 1)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def entries(self) -> list[dict]:
        return parse_agent_lines(self.text_edit.toPlainText())


class BulkMuseLoginDialog(QDialog):
    """V6.2: ĐĂNG NHẬP HÀNG LOẠT muse.ai bằng hộp thư tinyhost.shop.
    Mỗi dòng một tài khoản ('Tên | email', 'tên,email' hoặc chỉ email);
    email chưa có trong app sẽ được thêm thành tài khoản Muse mới."""

    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Đăng nhập hàng loạt muse.ai (tinyhost.shop)")
        self.resize(600, 480)
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Với từng email, app tự làm: mở tinyhost.shop → dán email → "
            "mở muse.ai → dán email, bấm Continue → chờ ô nhập mã → quay "
            "lại tinyhost bấm Check Inbox lấy mã → dán mã vào muse.ai → "
            "kiểm tra đăng nhập thành công rồi tự thoát, sang email kế "
            "tiếp.\n\nMỗi dòng một tài khoản: 'Tên | email', 'tên,email' "
            "hoặc chỉ email. Danh sách dưới đã điền sẵn các tài khoản "
            "CHƯA đăng nhập muse.ai."
        )
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.text_edit = QPlainTextEdit()
        self.text_edit.setPlaceholderText("Muse 01 | abc123@tinyhost-domain.com\nxyz789@tinyhost-domain.com")
        lines = []
        try:
            for agent in store.list_agents():
                if agent.get("revoked") or agent.get("web_state") == "in":
                    continue
                lines.append(f"{agent['name']} | {agent['email']}")
        except Exception:
            pass
        self.text_edit.setPlainText("\n".join(lines))
        layout.addWidget(self.text_edit, 1)
        self.add_missing = QCheckBox("Email chưa có trong app → tự thêm thành tài khoản Muse mới")
        self.add_missing.setChecked(True)
        layout.addWidget(self.add_missing)
        self.close_after = QCheckBox("Đăng nhập xong thì tự thoát Chrome của tài khoản đó")
        self.close_after.setChecked(True)
        layout.addWidget(self.close_after)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("🔐 Bắt đầu đăng nhập")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def entries(self) -> list[dict]:
        return parse_agent_lines(self.text_edit.toPlainText())

    def options(self) -> dict:
        return {
            "add_missing": self.add_missing.isChecked(),
            "close_on_success": self.close_after.isChecked(),
        }


class AssignProfilesDialog(QDialog):
    """Chọn các hồ sơ một Muse phụ trách (checkbox). Hồ sơ đang thuộc
    Muse khác sẽ được chuyển sang Muse này khi lưu."""

    def __init__(self, store: Store, agent: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Phân công kênh — {agent['name']}")
        self.resize(460, 420)
        layout = QVBoxLayout(self)
        hint = QLabel(
            "Một Muse phụ trách được NHIỀU hồ sơ (mọi kênh trong hồ sơ "
            "đi theo). Mỗi hồ sơ chỉ có một Muse chính: tick vào hồ sơ "
            "đang thuộc Muse khác sẽ chuyển hồ sơ đó sang Muse này."
        )
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        owners = {}
        for other in store.list_agents():
            for profile_id in other.get("profile_ids") or []:
                owners[profile_id] = other["name"]
        self.list_widget = QListWidget()
        current = set(agent.get("profile_ids") or [])
        for profile in store.list_profiles():
            label = f"{profile['label']} ({profile['gmail']})"
            if profile["id"] in owners and profile["id"] not in current:
                label += f" — đang của {owners[profile['id']]}"
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, profile["id"])
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(
                Qt.CheckState.Checked
                if profile["id"] in current
                else Qt.CheckState.Unchecked
            )
            self.list_widget.addItem(item)
        layout.addWidget(self.list_widget, 1)
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def selected_profile_ids(self) -> list[int]:
        ids = []
        for index in range(self.list_widget.count()):
            item = self.list_widget.item(index)
            if item.checkState() == Qt.CheckState.Checked:
                ids.append(int(item.data(Qt.ItemDataRole.UserRole)))
        return ids


WEB_STATE_LABELS = {
    "in": "✅ Đã đăng nhập",
    "out": "❌ Chưa đăng nhập",
    "waiting": "⏳ Đang chờ đăng nhập…",
    "unknown": "❔ Chưa kiểm tra",
}


class AgentsPanel(QWidget):
    def __init__(self, store: Store, notify=None, login_handler=None,
                 settings=None, wake_bridge=None, parent=None,
                 bulk_login_handler=None, bridge_help_handler=None):
        super().__init__(parent)
        self._store = store
        self._notify = notify or (lambda message: None)
        self._login_handler = login_handler
        # V6.2: đăng nhập hàng loạt muse.ai qua tinyhost — MainWindow
        # truyền handler(agents, options) chạy nền; trả False nếu
        # đang có một lượt chạy (khi đó nút thành nút Dừng).
        self._bulk_login_handler = bulk_login_handler
        self._bulk_login_running = False
        self._bridge_help_handler = bridge_help_handler
        # V4.6: đánh thức cầu nối khi người dùng gửi tin chat
        # (MainWindow nối tới AgentServer.notify_messages_changed).
        self._wake_bridge = wake_bridge
        # V4.1.1: settings dùng chung (MainWindow truyền dict của nó)
        # để nhớ thư mục phiếu kết nối 'ticket_export_dir'; không có
        # thì tự nạp từ settings.json theo thư mục dữ liệu của store.
        self._data_dir = store.db_file.parent
        self._settings = (
            settings
            if settings is not None
            else config.load_settings(self._data_dir)
        )
        self._ticket_error: str | None = None
        self._agents: list[dict] = []
        self._build_ui()
        self.refresh()
        # V4.3.2 (F4): nhịp 15 giây CHỈ chạy khi panel đang hiện —
        # bản cũ chạy suốt vòng đời cửa sổ kể cả khi đang ở section
        # khác (cùng bài học O-10 của panel Lệnh/Bảng việc).
        self._timer = QTimer(self)
        self._timer.setInterval(15_000)
        self._timer.timeout.connect(self.refresh)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()
        # V6.3.1: bảng luôn được vẽ lại khi tab hiện (xem
        # MainWindow._repaint_section) — kể cả khi dữ liệu không đổi.
        self.table.setUpdatesEnabled(True)
        self.table.viewport().update()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        # V5.3.3 (V3): lề DƯỚI = 1px như panel Văn phòng — splitter
        # (bảng + thẻ chat) là khối cuối của tab nên mép dưới ô
        # chat cách mép dưới vùng chứa đúng 1px thay vì 16px; các
        # phía còn lại giữ nguyên.
        root.setContentsMargins(20, 16, 20, 1)
        root.setSpacing(12)

        header = QHBoxLayout()
        header.addWidget(theme.section_header("Tài khoản Muse"))
        header.addStretch(1)
        self.add_button = QPushButton("➕ Thêm tài khoản")
        self.add_button.clicked.connect(self._on_add)
        header.addWidget(self.add_button)
        self.bulk_button = QPushButton("📥 Nhập hàng loạt")
        self.bulk_button.clicked.connect(self._on_bulk)
        header.addWidget(self.bulk_button)
        self.bulk_login_button = QPushButton("🔐 Đăng nhập hàng loạt")
        self.bulk_login_button.setToolTip(
            "Tự đăng nhập muse.ai cho nhiều tài khoản: lấy mã đăng nhập "
            "từ hộp thư tinyhost.shop của từng email rồi dán vào muse.ai"
        )
        self.bulk_login_button.clicked.connect(self._on_bulk_login)
        header.addWidget(self.bulk_login_button)
        # V6.3: nút "Kết nối Muse" chuyển từ tab Công việc về đây.
        self.bridge_button = QPushButton("🔌 Kết nối Muse")
        self.bridge_button.setToolTip(
            "Trạng thái cầu nối + các bước để Muse nghe được lệnh của app"
        )
        self.bridge_button.clicked.connect(self._on_bridge_help)
        header.addWidget(self.bridge_button)
        self.export_button = QPushButton("🎫 Xuất phiếu kết nối")
        self.export_button.setToolTip(
            "Ghi phiếu kết nối vào thư mục phiếu: mỗi tài khoản một "
            "file RIÊNG phieu-ket-noi-<tên>.txt (chỉ token của tài "
            "khoản đó) + một file gộp. Phiếu cũng TỰ cập nhật mỗi khi "
            "thêm tài khoản, cấp lại token, thu hồi hay xoá tài khoản "
            "— nút này chỉ để ghi lại ngay theo yêu cầu."
        )
        self.export_button.clicked.connect(self._on_export)
        header.addWidget(self.export_button)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        # V5.3 (A6): đoạn chữ GIẢI THÍCH dài dưới tiêu đề đã BỎ —
        # nguyên tắc token-riêng/phân-công đã nằm ở tooltip của nút
        # Xuất phiếu + hộp thoại Kết nối của từng dòng.

        # V4.3 (G5): cảnh báo VĂNG ĐĂNG NHẬP — agent nào mất phiên
        # muse.ai thì hiện rõ tại đây (kèm đường xử lý trong app),
        # thay vì mất kết nối lặng lẽ như trước.
        self.login_alert_label = QLabel("")
        self.login_alert_label.setWordWrap(True)
        self.login_alert_label.setStyleSheet("color:#FF7A7A; font-weight:600;")
        self.login_alert_label.setVisible(False)
        root.addWidget(self.login_alert_label)

        # V4.1.1: dòng trạng thái thư mục phiếu — luôn nhìn thấy phiếu
        # đang nằm ở đâu; nút đổi thư mục ghi nhớ vào settings.
        ticket_row = QHBoxLayout()
        self.ticket_dir_label = QLabel("")
        self.ticket_dir_label.setObjectName("Muted")
        self.ticket_dir_label.setWordWrap(True)
        ticket_row.addWidget(self.ticket_dir_label, 1)
        self.ticket_dir_button = QPushButton("📁 Đổi thư mục phiếu…")
        self.ticket_dir_button.setToolTip(
            "Chọn thư mục khác để lưu phiếu kết nối (được nhớ trong "
            "cài đặt); toàn bộ phiếu sẽ được ghi lại vào thư mục mới."
        )
        self.ticket_dir_button.clicked.connect(self._on_choose_ticket_dir)
        ticket_row.addWidget(self.ticket_dir_button)
        root.addLayout(ticket_row)

        # V4.3 (G6): thêm cột Phiếu — thời điểm xuất phiếu gần nhất
        # của từng tài khoản, để lệch phiếu nhìn thấy ngay tại bảng.
        # V4.6: thêm cột Kết nối — nút 🔌 trên TỪNG dòng mở hộp
        # thoại kết nối 2 lớp của đúng agent đó (agent_connect.py).
        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(
            ["Tài khoản Muse", "Email", "Trạng thái", "Muse.ai", "Đang làm", "Hồ sơ phụ trách", "Hoạt động cuối", "🎫 Phiếu", "Kết nối"]
        )
        header_view = self.table.horizontalHeader()
        header_view.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header_view.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        header_view.setSectionResizeMode(5, QHeaderView.ResizeMode.Stretch)
        # V4.3.2 (F7): mọi cột kéo chỉnh tự do + tự lưu bề rộng theo
        # bảng (mặc định chỉ áp khi chưa có số đã lưu).
        from . import table_persist

        table_persist.attach_column_persistence(
            self.table, self._settings, "agents_table",
            # V4.6: bảng nay ở CỘT TRÁI cạnh khung chat — bề rộng mặc
            # định gọn hơn bộ cũ (chỉ áp khi chưa có số đã lưu của
            # người dùng; số đã lưu luôn thắng theo chuẩn F7). Cột 9
            # (Kết nối) thêm cùng đợt V4.6; cột Trạng thái đủ rộng
            # cho nhãn "⚪ Chưa kết nối" không bị cắt cụt.
            default_widths=(170, 180, 118, 122, 188, 170, 120, 112, 124),
        )
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        # V5.3 (A5): dòng GỌN theo chuẩn chung — vừa chữ + nút Kết
        # nối trong ô (trước: 38px cố định từ V3.7). V5.3.1 (M2):
        # min_content = độ cao nút hiệu lực từ settings như chính
        # nút Kết nối trong ô.
        self.table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(
                self.table.font(),
                min_content=theme.row_action_height(self._settings),
            )
        )
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._on_table_menu)
        self.table.currentCellChanged.connect(self._on_agent_row_changed)

        # V4.6: bố cục HAI CỘT — trái: danh sách/quản lý tài khoản
        # (bảng + hàng nút như cũ); phải: khung CHAT với agent đang
        # chọn. Chọn dòng ở bảng là mở đúng luồng chat của agent đó.
        left_host = QWidget()
        left_layout = QVBoxLayout(left_host)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(10)
        left_layout.addWidget(self.table, 1)

        self.empty_label = QLabel(
            "Chưa có tài khoản Muse nào. Bấm ➕ Thêm tài khoản hoặc "
            "📥 Nhập hàng loạt để bắt đầu."
        )
        self.empty_label.setObjectName("EmptyState")
        left_layout.addWidget(self.empty_label)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.login_button = QPushButton("🌐 Đăng nhập muse.ai")
        self.login_button.setProperty("variant", "primary")
        self.login_button.setToolTip(
            "Mở Chrome riêng của tài khoản Muse đang chọn, nhúng vào "
            "app tại trang muse.ai để bạn tự đăng nhập cho tài khoản đó"
        )
        self.login_button.clicked.connect(self._on_login)
        actions.addWidget(self.login_button)
        self.assign_button = QPushButton("🎯 Phân công kênh…")
        self.assign_button.clicked.connect(self._on_assign)
        actions.addWidget(self.assign_button)
        self.token_button = QPushButton("🔑 Cấp lại token")
        self.token_button.clicked.connect(self._on_regenerate_token)
        actions.addWidget(self.token_button)
        self.revoke_button = QPushButton("🚫 Thu hồi / mở lại")
        self.revoke_button.clicked.connect(self._on_toggle_revoke)
        actions.addWidget(self.revoke_button)
        self.delete_button = QPushButton("🗑 Xoá")
        self.delete_button.setProperty("variant", "danger")
        self.delete_button.clicked.connect(self._on_delete)
        actions.addWidget(self.delete_button)
        # V4.3 (G6): tự kiểm tra kết nối NGAY TRONG APP (không cần mở
        # web muse): heartbeat còn tươi? phiếu đã xuất có khớp token
        # trong DB? server còn nghe ở cổng cầu nối?
        self.check_button = QPushButton("🔎 Kiểm tra kết nối")
        self.check_button.setToolTip(
            "Tự kiểm tra nội bộ cho tài khoản đang chọn: độ tươi "
            "heartbeat, phiếu đã xuất có khớp dữ liệu hiện tại, và "
            "server cầu nối có đang nghe không — báo kết quả tại đây."
        )
        self.check_button.clicked.connect(self._on_check_connection)
        actions.addWidget(self.check_button)
        actions.addStretch(1)
        left_layout.addLayout(actions)

        self.chat_widget = AgentChatWidget(
            self._store,
            wake_bridge=self._wake_bridge,
            on_store_changed=self.refresh,
        )
        self.chat_widget.setMinimumWidth(360)
        self.agents_splitter = QSplitter(Qt.Orientation.Horizontal)
        self.agents_splitter.addWidget(left_host)
        self.agents_splitter.addWidget(self.chat_widget)
        # V4.6: bề rộng DƯ khi cửa sổ lớn dồn cho BẢNG (nhiều cột);
        # khung chat giữ bề rộng vừa đọc, người dùng kéo splitter
        # để đổi tỉ lệ theo ý.
        self.agents_splitter.setStretchFactor(0, 1)
        self.agents_splitter.setStretchFactor(1, 0)
        self.agents_splitter.setSizes([1080, 450])
        root.addWidget(self.agents_splitter, 1)

    # ------------------------------------------------------------------ #
    # Dữ liệu
    # ------------------------------------------------------------------ #
    def apply_action_button_height(self):
        """Áp độ cao nút hàng lệnh MỚI từ settings (V5.3.1 — M2;
        MainWindow gọi sau khi Lưu cài đặt): chiều cao dòng tính
        lại theo nút Kết nối mới, bảng dựng lại ở refresh ngay
        sau đó trong cùng lời gọi này."""
        self.table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(
                self.table.font(),
                min_content=theme.row_action_height(self._settings),
            )
        )
        self.refresh()

    def refresh(self):
        try:
            self._agents = self._store.list_agents()
            profiles = {p["id"]: p for p in self._store.list_profiles()}
            active = {
                c["id"]: c for c in self._store.list_active_commands(limit=100)
            }
            # V4.6: số tin chat CHƯA ĐỌC theo agent (tin Muse gửi +
            # tin hệ thống) — vào huy hiệu ở ô tên và vào vân dòng.
            unread_counts = self._store.unread_counts()
        except Exception:
            return
        # V4.6: đồng bộ lựa chọn sang khung chat — lần đầu có agent
        # thì tự chọn dòng đầu để luồng chat không trống vô định.
        if self._agents and self.table.currentRow() < 0:
            self.table.selectRow(0)
        # V4.3.2 (F4): tính TRỌN giá trị từng dòng trước (kèm cờ
        # heartbeat stale — nó đổi theo thời gian nên phải nằm
        # trong vân) — vân không đổi thì GIỮ NGUYÊN bảng, không nạp
        # lại vô ích mỗi nhịp 15 giây.
        rows = []
        for agent in self._agents:
            current_id = agent.get("current_command_id") or ""
            command = active.get(current_id)
            if agent["status"] == "revoked":
                working = "—"
            elif command is not None:
                working = (
                    f"{command['type']} · {command.get('profile_slug') or '—'} "
                    f"— {int(command.get('progress') or 0)}%"
                    + (f" · {command['step']}" if command.get("step") else "")
                )
            elif agent["status"] == "online":
                working = "Đang rảnh"
            else:
                working = "—"
            owned = [
                profiles[pid]["label"]
                for pid in agent.get("profile_ids") or []
                if pid in profiles
            ]
            # V4.6: huy hiệu tin chat chưa đọc ngay ở ô tên (tin
            # Muse gửi + tin hệ thống đang chờ người dùng xem).
            unread = unread_counts.get(agent["id"], {})
            unread_total = int(unread.get("agent", 0)) + int(
                unread.get("system", 0)
            )
            name_value = f"#{agent['id']} {agent['name']}"
            if unread_total:
                name_value += f"  💬 {unread_total} chưa đọc"
            # V4.6: agent offline mà CHƯA TỪNG có heartbeat thì nói
            # thẳng "Chưa kết nối" thay vì "Ngoại tuyến" trơ trụi —
            # người dùng từng nhầm lớp này với đăng nhập muse.ai.
            if agent["status"] == "offline" and not agent.get("last_seen_at"):
                status_value = "⚪ Chưa kết nối"
            else:
                status_value = STATUS_LABELS.get(
                    agent["status"], agent["status"]
                )
            # V4.6: nhãn nút Kết nối theo trạng thái cầu nối hiện tại.
            connect_value = (
                "Đã kết nối ✓" if agent["status"] == "online"
                else "🔌 Kết nối"
            )
            values = [
                name_value,
                agent["email"],
                status_value,
                WEB_STATE_LABELS.get(
                    agent.get("web_state") or "unknown", "❔ Chưa kiểm tra"
                ),
                working,
                ", ".join(owned) if owned else "— chưa phân công —",
                _fmt_seen(agent.get("last_seen_at")),
                self._ticket_export_text(agent),
                connect_value,
            ]
            rows.append(
                (tuple(values), self._heartbeat_stale(agent), agent["id"])
            )
        if rows == getattr(self, "_last_rows", None):
            return
        self._last_rows = rows
        from . import table_persist

        with table_persist.batch_update(self.table):
            self.table.setRowCount(len(rows))
            for row, (values, stale, agent_id) in enumerate(rows):
                for col, value in enumerate(values):
                    if col == 8:
                        continue  # cột Kết nối là NÚT, không phải chữ
                    item = QTableWidgetItem(value)
                    if col == 0:
                        # V5.2: icon avatar robot THẬT ở ô tên (icon
                        # của item — KHÔNG phải widget con trong ô),
                        # vòng màu phân biệt theo agent, bản xám khi
                        # không online.
                        agent_row = next(
                            (a for a in self._agents if a["id"] == agent_id),
                            {},
                        )
                        pixmap = theme.robot_avatar_pixmap(
                            26,
                            ring=theme.agent_ring_color(agent_id),
                            grey=agent_row.get("status")
                            not in ("online", "idle"),
                        )
                        if pixmap is not None:
                            from PySide6.QtGui import QIcon

                            item.setIcon(QIcon(pixmap))
                    if col == 2:
                        item.setToolTip(STATUS_TOOLTIP)
                    # V4.3 (G6): heartbeat quá 5 phút không thấy (và
                    # tài khoản chưa bị thu hồi) → tô đỏ ô Hoạt động
                    # cuối để mất kết nối nhìn thấy ngay.
                    if col == 6 and stale:
                        item.setForeground(QColor(theme.DANGER))
                        item.setText(f"{value} ⚠ quá 5 phút")
                    self.table.setItem(row, col, item)
                connect_button = QPushButton(values[8])
                # Nút TRONG Ô bảng: padding dọc của QSS nút toàn
                # cục bóp mất chữ — dùng padding gọn riêng cho nút
                # này (màu/viền vẫn theo MetaMint) + cao theo độ
                # cao nút hàng lệnh hiệu lực (mặc định 24px khớp
                # chiều cao dòng gọn V5.3 A5; V5.3.1 M2: người
                # dùng chỉnh được trong Cài đặt → Giao diện).
                connect_button.setStyleSheet(
                    "QPushButton { padding: 2px 6px; font-size: 12px; }"
                )
                connect_button.setFixedHeight(
                    theme.row_action_height(self._settings)
                )
                connect_button.setToolTip(
                    "Mở hộp thoại kết nối của agent này: hai lớp tách "
                    "bạch — cầu nối Muse (phiếu kết nối) và đăng "
                    "nhập muse.ai — kèm lý do ngoại tuyến và nút xuất "
                    "phiếu của đúng agent."
                )
                connect_button.clicked.connect(
                    lambda _c=False, aid=agent_id:
                        self._on_connect_clicked(aid)
                )
                self.table.setCellWidget(row, 8, connect_button)
        self.empty_label.setVisible(not self._agents)
        self._refresh_ticket_label()
        self._refresh_login_alert()

    # ------------------------------------------------------------------ #
    # V4.3 (G5/G6) — Độ tươi heartbeat, phiếu, cảnh báo đăng nhập
    # ------------------------------------------------------------------ #
    @staticmethod
    def _heartbeat_age_seconds(agent: dict) -> float | None:
        raw = agent.get("last_seen_at")
        if not raw:
            return None
        try:
            seen = datetime.fromisoformat(str(raw))
        except ValueError:
            return None
        if seen.tzinfo is None:
            seen = seen.astimezone()
        return max(0.0, (datetime.now().astimezone() - seen).total_seconds())

    def _heartbeat_stale(self, agent: dict) -> bool:
        if agent.get("status") == "revoked" or agent.get("revoked"):
            return False
        age = self._heartbeat_age_seconds(agent)
        return age is not None and age > 300

    def _ticket_export_text(self, agent: dict) -> str:
        """Thời điểm xuất phiếu riêng gần nhất của agent (mtime của
        file phiếu) — '— chưa xuất —' khi chưa có file."""
        try:
            path = self._ticket_folder() / tickets.agent_ticket_filename(agent)
            if not path.exists():
                return "— chưa xuất —"
            stamp = datetime.fromtimestamp(path.stat().st_mtime).astimezone()
            return stamp.strftime("%H:%M %d/%m")
        except Exception:
            return "—"

    def _refresh_login_alert(self):
        logged_out = [
            a for a in self._agents
            if (a.get("web_state") or "") == "out" and not a.get("revoked")
        ]
        if not logged_out:
            self.login_alert_label.setVisible(False)
            return
        names = ", ".join(
            a.get("name") or a.get("email") or f"#{a['id']}" for a in logged_out
        )
        self.login_alert_label.setText(
            f"⚠ ĐÃ VĂNG ĐĂNG NHẬP muse.ai: {names}. Chọn tài khoản đó "
            "rồi bấm “🌐 Đăng nhập muse.ai” ở dưới để đăng nhập lại "
            "NGAY TRONG APP (Chrome riêng của tài khoản, nhúng sẵn)."
        )
        self.login_alert_label.setVisible(True)

    def _connection_report(self, agent: dict) -> str:
        """Báo cáo tự kiểm tra kết nối cho MỘT tài khoản (G6) — mọi
        kiểm tra đều nội bộ: heartbeat trong DB, nội dung phiếu đã
        xuất so với dữ liệu hiện tại, cổng server trên máy này, và
        bằng chứng cầu nối (lần gọi đã xác thực gần nhất)."""
        lines = [f"🔎 Kiểm tra kết nối — {agent.get('name')} ({agent.get('email')})"]
        age = self._heartbeat_age_seconds(agent)
        if age is None:
            lines.append("• Heartbeat: ❌ chưa từng gọi vào.")
        elif age <= 300:
            lines.append(f"• Heartbeat: ✅ {_fmt_seen(agent.get('last_seen_at'))}.")
        else:
            lines.append(
                f"• Heartbeat: ⚠ lần cuối {_fmt_seen(agent.get('last_seen_at'))} "
                "— quá 5 phút, Muse đó có thể đã mất kết nối."
            )
        # Phiếu: nội dung file đã xuất phải khớp phiếu sinh từ dữ
        # liệu HIỆN TẠI (token/phân công đổi mà chưa xuất lại = lệch).
        try:
            profiles = {p["id"]: p for p in self._store.list_profiles()}
            expected = tickets.agent_ticket_text(agent, profiles)
            path = self._ticket_folder() / tickets.agent_ticket_filename(agent)
            if not path.exists():
                lines.append("• Phiếu kết nối: ❌ chưa xuất file riêng cho tài khoản này.")
            elif path.read_text(encoding="utf-8") == expected:
                lines.append(
                    f"• Phiếu kết nối: ✅ khớp dữ liệu hiện tại "
                    f"(xuất lúc {self._ticket_export_text(agent)})."
                )
            else:
                lines.append(
                    "• Phiếu kết nối: ⚠ LỆCH — token/phân công đã đổi "
                    "sau lần xuất gần nhất. Bấm “🎫 Xuất phiếu kết nối” "
                    "để ghi lại rồi gửi file mới cho Muse đó."
                )
        except Exception as exc:
            lines.append(f"• Phiếu kết nối: ⚠ không kiểm tra được ({exc}).")
        # Server cầu nối trên máy này có đang nghe không.
        import socket

        port = int(self._settings.get("agent_port", 19500) or 19500)
        sock = socket.socket()
        sock.settimeout(1.5)
        try:
            listening = sock.connect_ex(("127.0.0.1", port)) == 0
        except OSError:
            listening = False
        finally:
            sock.close()
        lines.append(
            f"• Server cầu nối (cổng {port}): "
            + ("✅ đang nghe trên máy này." if listening else "❌ không nghe được — kiểm tra app/server.")
        )
        try:
            bridge = self._store.bridge_state()
            if bridge.get("connected"):
                lines.append("• Cầu nối: ✅ đang có Muse kết nối.")
            elif bridge.get("ever"):
                lines.append(
                    f"• Cầu nối: ⚠ từng kết nối, lần gọi xác thực cuối "
                    f"{bridge.get('seconds_ago')} giây trước."
                )
            else:
                lines.append("• Cầu nối: ❌ chưa từng có lời gọi xác thực nào.")
        except Exception:
            pass
        return "\n".join(lines)

    def _on_check_connection(self):
        agent = self._selected_agent()
        if agent is None:
            self._notify("Chọn một tài khoản Muse trong bảng trước đã.")
            return
        QMessageBox.information(
            self, "Kiểm tra kết nối", self._connection_report(agent)
        )

    # ------------------------------------------------------------------ #
    # Phiếu kết nối theo tài khoản (V4.1.1)
    # ------------------------------------------------------------------ #
    def _ticket_folder(self) -> Path:
        return tickets.ticket_export_dir(self._settings, self._data_dir)

    def _refresh_ticket_label(self):
        text = f"📁 Thư mục phiếu kết nối: {self._ticket_folder()}"
        if self._ticket_error:
            text += f" — ⚠ lần ghi gần nhất thất bại: {self._ticket_error}"
        self.ticket_dir_label.setText(text)

    def _sync_tickets(self, agent_id=None, deleted_agent=None) -> Path | None:
        """Tự ghi phiếu sau một sự kiện vòng đời tài khoản: agent_id
        → ghi lại file riêng của agent đó + file gộp; deleted_agent
        (dict chụp trước khi xoá) → xoá file riêng của nó + ghi lại
        file gộp; cả hai None → ghi lại tất cả.

        Trả thư mục phiếu khi ghi xong, None khi lỗi. KHÔNG BAO GIỜ
        ném lỗi ra ngoài: ghi phiếu hỏng không được làm hỏng thao tác
        thêm/cấp lại token/thu hồi/xoá — chỉ báo một dòng trạng thái
        không chặn."""
        folder = self._ticket_folder()
        try:
            if deleted_agent is not None:
                tickets.remove_agent_ticket(deleted_agent, folder)
                tickets.write_all_tickets(self._store, folder)
            elif agent_id is not None:
                tickets.write_agent_ticket(self._store, agent_id, folder)
            else:
                tickets.write_all_tickets(self._store, folder)
        except Exception as exc:
            self._ticket_error = str(exc)
            self._notify(
                f"⚠ Không ghi được phiếu kết nối vào thư mục {folder}: {exc}"
            )
            self._refresh_ticket_label()
            return None
        self._ticket_error = None
        self._refresh_ticket_label()
        return folder

    def _on_choose_ticket_dir(self):
        chosen = QFileDialog.getExistingDirectory(
            self, "Chọn thư mục lưu phiếu kết nối", str(self._ticket_folder())
        )
        if not chosen:
            return
        self._settings[tickets.SETTINGS_KEY] = chosen
        try:
            config.save_settings(self._settings, self._data_dir)
        except Exception:
            pass  # lưu cài đặt lỗi thì vẫn ghi phiếu vào thư mục vừa chọn lần này
        folder = self._sync_tickets()
        if folder is not None:
            self._notify(
                f"Đã đổi thư mục phiếu kết nối thành {folder} và ghi "
                "lại toàn bộ phiếu vào đó."
            )

    def _selected_agent(self) -> dict | None:
        row = self.table.currentRow()
        if row < 0 or row >= len(self._agents):
            return None
        return self._agents[row]

    # ------------------------------------------------------------------ #
    # V4.6 — Chat: đồng bộ lựa chọn + điểm vào từ mục khác
    # ------------------------------------------------------------------ #
    def _on_agent_row_changed(self, row, _col, _prev_row, _prev_col):
        if 0 <= row < len(self._agents):
            agent = self._agents[row]
            if self.chat_widget.agent_id != agent["id"]:
                self.chat_widget.set_agent(agent)

    def open_chat(self, agent_id: int, command_id: str | None = None) -> bool:
        """Mở luồng chat của một agent — điểm vào cho nút "💬 Hỏi về
        lệnh này" (mục Công việc) và "💬 Nhắn tin" (Văn phòng):
        chọn đúng dòng agent và, nếu có, gắn chip ngữ cảnh lệnh.
        Trả False khi không thấy agent."""
        self.refresh()
        for index, agent in enumerate(self._agents):
            if agent["id"] == int(agent_id):
                self.table.selectRow(index)
                self.chat_widget.set_agent(
                    agent, context_command_id=command_id
                )
                return True
        return False

    # ------------------------------------------------------------------ #
    # V4.6 — Hộp thoại Kết nối từng agent (nút ở cột Kết nối)
    # ------------------------------------------------------------------ #
    def build_connect_dialog(self, agent_id: int):
        """Dựng hộp thoại kết nối 2 lớp cho một agent (chưa mở) —
        None khi không thấy agent đó trong dữ liệu hiện tại."""
        for agent in self._agents:
            if agent["id"] == int(agent_id):
                return AgentConnectDialog(
                    self._store, int(agent_id),
                    settings=self._settings, data_dir=self._data_dir,
                    on_recheck=self.refresh, parent=self,
                )
        return None

    def _on_connect_clicked(self, agent_id: int):
        dialog = self.build_connect_dialog(agent_id)
        if dialog is not None:
            dialog.exec()

    def _on_table_menu(self, pos):
        """Menu chuột phải trên dòng tài khoản Muse (icon + text) — cùng
        bộ chức năng với hàng nút dưới bảng."""
        row = self.table.rowAt(pos.y())
        if row < 0 or row >= len(self._agents):
            return
        self.table.selectRow(row)
        agent = self._agents[row]
        menu = QMenu(self)
        entries = [
            (
                "🔌 Kết nối…",
                lambda aid=agent["id"]: self._on_connect_clicked(aid),
            ),
            ("🌐 Đăng nhập muse.ai", self._on_login),
            ("👥 Phân công hồ sơ", self._on_assign),
            ("📄 Xuất phiếu kết nối", self._on_export),
            ("🔑 Cấp lại token", self._on_regenerate_token),
            (
                "↩️ Huỷ thu hồi" if agent.get("revoked") else "⛔ Thu hồi token",
                self._on_toggle_revoke,
            ),
        ]
        for text, slot in entries:
            act = menu.addAction(text)
            act.triggered.connect(lambda _=False, s=slot: s())
        menu.addSeparator()
        act = menu.addAction("🗑 Xoá tài khoản Muse")
        act.triggered.connect(self._on_delete)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------ #
    # Thao tác
    # ------------------------------------------------------------------ #
    def _on_add(self):
        dialog = AddAgentDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        values = dialog.values()
        try:
            agent = self._store.create_agent(
                values["name"], values["email"], values["note"]
            )
        except ValueError as exc:
            QMessageBox.warning(self, "Không thêm được", str(exc))
            return
        note = (
            f"Đã thêm tài khoản Muse '{agent['name']}' ({agent['email']}) "
            f"— id #{agent['id']}, đã sinh token riêng."
        )
        # V4.1.1: email vừa thêm trùng gmail hồ sơ nào chưa có chủ →
        # tự phân công ngay (khỏi chờ nhịp dispatcher/khởi động lại).
        try:
            auto_pairs = self._store.auto_assign_email_matches()
        except Exception:
            auto_pairs = []
        if auto_pairs:
            note += (
                f" Đã tự phân công {len(auto_pairs)} hồ sơ trùng email "
                "cho Muse phụ trách."
            )
        # V4.1.1: phiếu riêng của tài khoản mới tự được ghi ra ngay.
        folder = self._sync_tickets(agent["id"])
        if folder is not None:
            note += (
                f" Phiếu riêng đã ghi: {tickets.agent_ticket_filename(agent)} "
                f"(thư mục {folder})."
            )
        self._notify(note)
        self.refresh()

    def _on_bulk(self):
        dialog = BulkImportDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        entries = dialog.entries()
        if not entries:
            QMessageBox.warning(self, "Danh sách trống", "Chưa có dòng hợp lệ nào.")
            return
        results = self._store.bulk_create_agents(entries)
        created = sum(1 for r in results if r["status"] == "created")
        duplicates = sum(1 for r in results if r["status"] == "duplicate")
        errors = [r for r in results if r["status"] == "error"]
        message = (
            f"Nhập hàng loạt: thêm mới {created}, trùng {duplicates}, "
            f"lỗi {len(errors)} / tổng {len(results)}."
        )
        if errors:
            message += "\n" + "\n".join(
                f"• {r['email'] or '(trống)'}: {r.get('message', '')}" for r in errors
            )
        # V4.1.1: tự phân công theo email cho các Muse vừa nhập.
        try:
            auto_pairs = self._store.auto_assign_email_matches()
        except Exception:
            auto_pairs = []
        if auto_pairs:
            message += (
                f"\nĐã tự phân công {len(auto_pairs)} hồ sơ trùng email "
                "cho các Muse vừa nhập."
            )
        # V4.1.1: phiếu riêng cho các tài khoản vừa nhập + file gộp.
        if created:
            folder = self._sync_tickets()
            if folder is not None:
                message += (
                    f"\nPhiếu kết nối đã được ghi vào thư mục {folder} "
                    "(mỗi tài khoản một file riêng + file gộp)."
                )
        self._notify(
            f"Nhập hàng loạt tài khoản Muse: thêm mới {created}/"
            f"{len(results)} (trùng {duplicates}, lỗi {len(errors)})."
        )
        QMessageBox.information(self, "Kết quả nhập hàng loạt", message)
        self.refresh()

    def _on_bulk_login(self):
        """V6.2: đăng nhập hàng loạt muse.ai (tinyhost.shop)."""
        if self._bulk_login_handler is None:
            QMessageBox.information(self, "Chưa sẵn sàng", "Chức năng chưa được nối vào cửa sổ chính.")
            return
        if self._bulk_login_running:
            self._bulk_login_handler(None, {"stop": True})
            self.bulk_login_button.setText("⏳ Đang dừng…")
            return
        dialog = BulkMuseLoginDialog(self._store, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        entries = dialog.entries()
        options = dialog.options()
        if not entries:
            QMessageBox.warning(self, "Danh sách trống", "Chưa có email hợp lệ nào.")
            return
        agents: list[dict] = []
        problems: list[str] = []
        added = 0
        seen: set[str] = set()
        for entry in entries:
            email = (entry.get("email") or "").strip().lower()
            if not email or email in seen:
                continue
            seen.add(email)
            agent = self._store.get_agent_by_email(email)
            if agent is None:
                if not options["add_missing"]:
                    problems.append(f"• {email}: chưa có trong app (bỏ qua)")
                    continue
                try:
                    agent = self._store.create_agent(entry.get("name") or "", email, "")
                    added += 1
                except ValueError as exc:
                    problems.append(f"• {email}: {exc}")
                    continue
            if agent.get("revoked"):
                problems.append(f"• {email}: đã thu hồi quyền — bỏ qua")
                continue
            agents.append(agent)
        if added:
            try:
                self._store.auto_assign_email_matches()
            except Exception:
                pass
            self._sync_tickets()
        self.refresh()
        if problems:
            QMessageBox.information(self, "Một số dòng bị bỏ qua", "\n".join(problems))
        if not agents:
            return
        if self._bulk_login_handler(agents, options) is not False:
            self.set_bulk_login_running(True)
            self._notify(
                f"Bắt đầu đăng nhập hàng loạt muse.ai cho {len(agents)} tài khoản"
                + (f" (vừa thêm mới {added})" if added else "") + "."
            )

    def _on_bridge_help(self):
        if self._bridge_help_handler is not None:
            self._bridge_help_handler()

    def set_bulk_login_running(self, running: bool):
        self._bulk_login_running = bool(running)
        self.bulk_login_button.setText(
            "⏹ Dừng đăng nhập hàng loạt" if running else "🔐 Đăng nhập hàng loạt"
        )

    def _on_assign(self):
        agent = self._selected_agent()
        if agent is None:
            QMessageBox.information(self, "Chưa chọn", "Chọn một tài khoản Muse trong bảng trước.")
            return
        dialog = AssignProfilesDialog(self._store, agent, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        updated = self._store.assign_profiles(
            agent["id"], dialog.selected_profile_ids()
        )
        self._notify(
            f"Phân công Muse '{updated['name']}': phụ trách "
            f"{len(updated['profile_ids'])} hồ sơ."
        )
        self.refresh()

    def _on_regenerate_token(self):
        agent = self._selected_agent()
        if agent is None:
            QMessageBox.information(self, "Chưa chọn", "Chọn một tài khoản Muse trong bảng trước.")
            return
        answer = QMessageBox.question(
            self,
            "Cấp lại token",
            f"Cấp token MỚI cho '{agent['name']}'? Token cũ sẽ hết hiệu "
            "lực ngay. Phiếu kết nối của tài khoản này sẽ được app TỰ "
            "ĐỘNG cấp lại (ghi đè file phiếu riêng) — bạn chỉ cần gửi "
            "lại file phiếu mới cho Muse đó.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        updated = self._store.regenerate_agent_token(agent["id"])
        # V4.1.1: cấp lại token = cấp lại phiếu TỰ ĐỘNG, tại chỗ. Đây
        # là bài học "cấp lại token làm mù cầu nối âm thầm": từ nay
        # không còn bước xuất-lại-thủ-công để mà quên.
        folder = self._sync_tickets(updated["id"])
        filename = tickets.agent_ticket_filename(updated)
        self._notify(
            f"Đã cấp lại token cho tài khoản Muse '{updated['name']}' "
            "— token cũ hết hiệu lực, phiếu riêng đã tự cấp lại "
            f"({filename})."
        )
        if folder is not None:
            body = (
                f"Token mới đã sinh và phiếu kết nối của "
                f"'{updated['name']}' đã được TỰ ĐỘNG cấp lại:\n"
                f"• File: {filename}\n"
                f"• Thư mục: {folder}\n\n"
                "Token cũ đã CHẾT. Gửi file phiếu mới này cho Muse đó "
                "nạp lại — không cần xuất phiếu thủ công nữa."
            )
        else:
            body = (
                "Token mới đã sinh NHƯNG app không ghi được phiếu tự "
                "động (xem dòng trạng thái thư mục phiếu). Kiểm tra thư "
                "mục phiếu, bấm 🎫 Xuất phiếu kết nối rồi gửi file "
                f"{filename} cho Muse đó — token cũ đã chết."
            )
        QMessageBox.information(self, "Đã cấp lại token + phiếu", body)
        self.refresh()

    def _on_toggle_revoke(self):
        agent = self._selected_agent()
        if agent is None:
            QMessageBox.information(self, "Chưa chọn", "Chọn một tài khoản Muse trong bảng trước.")
            return
        updated = self._store.set_agent_revoked(agent["id"], not agent["revoked"])
        self._notify(
            f"Tài khoản Muse '{updated['name']}': "
            + ("đã THU HỒI quyền cầu nối." if updated["revoked"] else "đã mở lại quyền cầu nối.")
        )
        # V4.1.1: phiếu của tài khoản vừa thu hồi/mở lại cũng tự cập
        # nhật (file riêng ghi rõ trạng thái thu hồi, file gộp làm tươi).
        self._sync_tickets(updated["id"])
        self.refresh()

    def _on_login(self):
        agent = self._selected_agent()
        if agent is None:
            QMessageBox.information(self, "Chưa chọn", "Chọn một tài khoản Muse trong bảng trước.")
            return
        if agent["revoked"]:
            QMessageBox.warning(
                self,
                "Đã thu hồi",
                "Tài khoản này đã bị thu hồi quyền — mở lại trước khi đăng nhập.",
            )
            return
        if self._login_handler is None:
            QMessageBox.information(
                self, "Chưa nối", "Chức năng đăng nhập chưa được nối vào cửa sổ chính."
            )
            return
        self._login_handler(agent)

    def _on_delete(self):
        agent = self._selected_agent()
        if agent is None:
            QMessageBox.information(self, "Chưa chọn", "Chọn một tài khoản Muse trong bảng trước.")
            return
        answer = QMessageBox.question(
            self,
            "Xoá tài khoản Muse",
            f"Xoá hẳn '{agent['name']}' ({agent['email']}) khỏi app? "
            "Phân công kênh của Muse này sẽ bị gỡ và thư mục Chrome "
            "riêng (kèm phiên đăng nhập muse.ai) cũng bị xoá.",
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._store.delete_agent(agent["id"])
        # V4.1.1: xoá luôn file phiếu riêng của tài khoản đã xoá (khỏi
        # để lại token mồ côi trên đĩa) + làm tươi file gộp.
        self._sync_tickets(deleted_agent=agent)
        # Xoá luôn thư mục Chrome riêng của tài khoản (phiên muse.ai).
        try:
            from .. import agent_browser, config as app_config

            folder = (
                app_config.data_dir() / "agents" / agent_browser.agent_slug(agent)
            )
            if folder.exists():
                import shutil

                shutil.rmtree(folder, ignore_errors=True)
        except Exception:
            pass
        self._notify(f"Đã xoá tài khoản Muse '{agent['name']}' ({agent['email']}).")
        self.refresh()

    def _on_export(self):
        """V4.1.1: xuất phiếu = ghi TOÀN BỘ phiếu vào THƯ MỤC phiếu:
        mỗi tài khoản một file riêng phieu-ket-noi-<tên>.txt + file
        gộp phieu-ket-noi-claude.txt (định dạng cũ giữ nguyên cho
        parser phía Muse). Chưa từng đặt thư mục thì hỏi MỘT lần
        rồi nhớ vào settings; huỷ hộp chọn thì dùng thư mục mặc định
        trong thư mục dữ liệu của app. Không còn cảnh mọi tài khoản
        dồn vào một file một tên chung gây nhầm lẫn."""
        if not self._agents:
            QMessageBox.information(self, "Chưa có tài khoản", "Chưa có tài khoản Muse nào để xuất phiếu.")
            return
        if not (self._settings.get(tickets.SETTINGS_KEY) or "").strip():
            chosen = QFileDialog.getExistingDirectory(
                self,
                "Chọn thư mục lưu phiếu kết nối (chỉ hỏi lần này)",
                str(self._ticket_folder()),
            )
            if chosen:
                self._settings[tickets.SETTINGS_KEY] = chosen
                try:
                    config.save_settings(self._settings, self._data_dir)
                except Exception:
                    pass
        folder = self._sync_tickets()
        if folder is not None:
            self._notify(
                f"Đã ghi phiếu kết nối cho {len(self._agents)} tài khoản "
                f"Muse vào thư mục {folder} — mỗi tài khoản một file "
                f"riêng phieu-ket-noi-<tên>.txt + file gộp "
                f"{tickets.COMBINED_FILENAME}."
            )
