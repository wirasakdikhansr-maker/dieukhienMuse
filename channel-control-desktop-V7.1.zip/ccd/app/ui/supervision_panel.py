"""Panel "Giám sát" — V6.1: TRƯỞNG PHÒNG + HẠN CHÓT trực quan.

Bố cục (từ trên xuống):
1. Thanh điều khiển: bật/tắt giám sát, chế độ (Trưởng phòng / Vòng
   chéo), chọn TÀI KHOẢN TRƯỞNG PHÒNG — đổi là áp ngay + lưu cài đặt.
2. Dải chỉ số: việc đang mở · đúng tiến độ · sắp trễ · trễ hạn · đang
   kẹt · chờ chấm · % xong đúng hạn tuần này (bấm ô = lọc bảng).
3. Thân chia đôi:
   - trái: BẢNG TIẾN ĐỘ THEO HẠN CHÓT — mỗi tài khoản một làn (trưởng
     phòng ở đầu), mỗi việc một hàng: thanh tiến độ % + VẠCH THỜI GIAN
     đã dùng của hạn (vạch vượt thanh = đang chậm), giờ hạn + còn/trễ
     bao lâu, nhãn sức khoẻ. Chuột phải / thanh thao tác: gia hạn,
     đặt hạn, nhắc Muse, thu hồi, mở lệnh.
   - phải: SƠ ĐỒ ĐỘI (trưởng phòng → thành viên, chấm màu theo tình
     trạng) + THẺ ĐIỂM tuần (bảng gọn).
4. Dưới: tab Hàng đợi kiểm tra | Cảnh báo treo (watchdog).

Làm mới: nhịp 5s CHỈ khi panel đang hiện, có cổng vân dữ liệu.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QEvent, QPointF, QRectF, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QFontMetrics, QPainter, QPen
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDialog,
    QDialogButtonBox,
    QFrame,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QTableWidget,
    QToolTip,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .. import config, supervision
from ..store import COMMAND_TYPE_LABELS, Store
from . import table_persist, theme

TRIGGER_LABELS = {
    "failed": "Lệnh thất bại",
    "done": "Lệnh xong (mẫu)",
    "stuck": "Nghi treo (watchdog)",
}

REVIEW_STATUS_LABELS = {
    "open": "⏳ Đang chờ chấm",
    "passed": "✅ Đạt",
    "rework": "↩ Chưa đạt — làm lại",
    "escalated": "⬆ Leo thang chủ kênh",
    "skipped": "⏭ Đã bỏ qua",
}

REVIEW_COLUMNS = [
    "Lệnh gốc", "Loại", "Người làm", "Giám sát",
    "Kích hoạt", "Vòng", "Trạng thái", "Tạo lúc",
]

# Màu sức khoẻ việc theo hạn (dùng chung bảng + sơ đồ + ô chỉ số).
HEALTH_COLORS = {
    supervision.HEALTH_ON_TRACK: "#CEFC19",
    supervision.HEALTH_AT_RISK: "#F5B841",
    supervision.HEALTH_OVERDUE: "#FF7A7A",
    supervision.HEALTH_BLOCKED: "#C084FC",
    supervision.HEALTH_NO_DUE: "#7C8791",
    supervision.HEALTH_DONE: "#CEFC19",
}
HEALTH_ORDER = {
    supervision.HEALTH_OVERDUE: 0,
    supervision.HEALTH_BLOCKED: 1,
    supervision.HEALTH_AT_RISK: 2,
    supervision.HEALTH_ON_TRACK: 3,
    supervision.HEALTH_NO_DUE: 4,
}
STATUS_SHORT = {
    "queued": "Hàng đợi", "waiting_muse": "Chờ Muse nhận", "running": "Đang làm",
    "needs_user": "Chờ bạn", "interrupted": "Gián đoạn",
}
APP_LANE_ID = -1  # làn "App tự chạy" (lệnh local không gắn Muse)


def _agent_label(store: Store, agent_id) -> str:
    if agent_id is None:
        return "—"
    agent = store.get_agent(int(agent_id))
    if agent is None:
        return f"Muse #{agent_id}"
    return agent.get("name") or agent.get("email") or f"Muse #{agent_id}"


def _fmt_ts(raw) -> str:
    text = str(raw or "")
    return text[11:16] + " " + text[8:10] + "/" + text[5:7] if len(text) >= 16 else text


def _fmt_due(raw) -> str:
    """'17:30' nếu hôm nay, '17:30 02/11' nếu ngày khác."""
    text = str(raw or "")
    if len(text) < 16:
        return "—"
    today = datetime.now().astimezone().date().isoformat()
    return text[11:16] if text[:10] == today else _fmt_ts(text)


# --------------------------------------------------------------------------- #
# Mô hình thuần cho bảng tiến độ (test được không cần vẽ)
# --------------------------------------------------------------------------- #
def build_board_model(
    agents: list[dict], commands: list[dict], lead_id: int | None,
    now: datetime | None = None, warn_percent: int = 75,
    owner_by_profile: dict | None = None,
) -> dict:
    """Gom việc đang mở theo làn tài khoản. Trả {lanes, counts}.
    lanes: [{agent_id, name, is_lead, status, tasks:[...], counts}],
    trưởng phòng đứng đầu, các làn khác xếp theo mức nguy (trễ nhiều
    trước), làn 'App tự chạy' cuối cùng."""
    now = now or datetime.now().astimezone()
    owner_by_profile = owner_by_profile or {}
    by_id = {int(a["id"]): a for a in agents if not a.get("revoked")}
    lanes: dict[int, dict] = {}

    def lane(agent_id: int) -> dict:
        if agent_id not in lanes:
            agent = by_id.get(agent_id)
            lanes[agent_id] = {
                "agent_id": agent_id,
                "name": (
                    "App tự chạy" if agent_id == APP_LANE_ID
                    else (agent or {}).get("name") or (agent or {}).get("email")
                    or f"Muse #{agent_id}"
                ),
                "is_lead": agent_id == lead_id,
                "status": (agent or {}).get("status") or ("online" if agent_id == APP_LANE_ID else "offline"),
                "tasks": [],
            }
        return lanes[agent_id]

    for agent_id in by_id:
        lane(agent_id)
    counts = {key: 0 for key in HEALTH_ORDER}
    counts["total"] = 0
    for command in commands:
        if command.get("type") == "review":
            continue
        agent_id = command.get("lease_agent_id") or command.get("agent_id")
        if agent_id is None and command.get("profile_id") is not None:
            agent_id = owner_by_profile.get(int(command["profile_id"]))
        agent_id = int(agent_id) if agent_id is not None else APP_LANE_ID
        if agent_id != APP_LANE_ID and agent_id not in by_id:
            agent_id = APP_LANE_ID
        health = supervision.deadline_health(command, now, warn_percent)
        task = {
            "id": command["id"],
            "type": command.get("type"),
            "type_label": COMMAND_TYPE_LABELS.get(command.get("type"), command.get("type") or ""),
            "profile": command.get("profile_slug") or "—",
            "status": command.get("status"),
            "status_label": STATUS_SHORT.get(command.get("status"), command.get("status") or ""),
            "step": (command.get("step") or "").strip(),
            "instruction": " ".join(str(command.get("instruction") or "").split())[:120],
            "agent_id": None if agent_id == APP_LANE_ID else agent_id,
            "profile_id": command.get("profile_id"),
            **health,
        }
        lane(agent_id)["tasks"].append(task)
        counts[health["health"]] = counts.get(health["health"], 0) + 1
        counts["total"] += 1
    result = []
    for item in lanes.values():
        item["tasks"].sort(key=lambda t: (HEALTH_ORDER.get(t["health"], 9),
                                          t.get("due_at") or "9999"))
        c = {key: 0 for key in HEALTH_ORDER}
        for task in item["tasks"]:
            c[task["health"]] = c.get(task["health"], 0) + 1
        item["counts"] = c
        result.append(item)
    result.sort(key=lambda l: (
        0 if l["is_lead"] else (2 if l["agent_id"] == APP_LANE_ID else 1),
        -l["counts"].get(supervision.HEALTH_OVERDUE, 0),
        -l["counts"].get(supervision.HEALTH_BLOCKED, 0),
        -len(l["tasks"]),
        l["name"],
    ))
    return {"lanes": result, "counts": counts}


# --------------------------------------------------------------------------- #
# Widget vẽ bảng tiến độ theo hạn
# --------------------------------------------------------------------------- #
class DeadlineBoard(QWidget):
    """Vẽ các làn tài khoản + hàng việc. Phát task_selected(id) khi
    bấm, context_requested(id, global_pos) khi chuột phải."""

    task_selected = Signal(str)
    context_requested = Signal(str, object)

    LANE_H = 40
    ROW_H = 36
    MAX_ROWS = 8
    LABEL_W = 270
    DUE_W = 150
    PILL_W = 104

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lanes: list[dict] = []
        self._filter: str | None = None
        self._selected: str | None = None
        self._hit: list[tuple[QRectF, str]] = []
        self.explain = None  # V6.9: callable(task_id) -> HTML popup "kẹt gì"
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def event(self, event):
        if event.type() == QEvent.Type.ToolTip and self.explain is not None:
            task_id = self._task_at(event.pos())
            if task_id:
                try:
                    QToolTip.showText(event.globalPos(), self.explain(task_id), self)
                    return True
                except Exception:
                    pass
            QToolTip.hideText()
            event.ignore()
            return True
        return super().event(event)

    def set_model(self, lanes: list[dict]) -> None:
        self._lanes = lanes
        self._relayout()

    def set_filter(self, health: str | None) -> None:
        self._filter = health
        self._relayout()

    def selected_task(self) -> str | None:
        return self._selected

    def select(self, task_id: str | None) -> None:
        self._selected = task_id
        self.update()

    def _visible_tasks(self, lane: dict) -> list[dict]:
        tasks = lane["tasks"]
        if self._filter:
            tasks = [t for t in tasks if t["health"] == self._filter]
        return tasks

    def _relayout(self):
        height = 8
        for lane in self._lanes:
            tasks = self._visible_tasks(lane)
            if self._filter and not tasks:
                continue
            height += self.LANE_H + max(1, min(len(tasks), self.MAX_ROWS)) * self.ROW_H
            if len(tasks) > self.MAX_ROWS:
                height += 22
            height += 10
        self.setMinimumHeight(max(height, 120))
        self.updateGeometry()
        self.update()

    def sizeHint(self):
        return QSize(800, self.minimumHeight())

    # -- vẽ -- #
    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(theme.BG))
        self._hit = []
        width = self.width()
        y = 8
        base = QFont(self.font())
        bold = QFont(base)
        bold.setBold(True)
        small = QFont(base)
        small.setPointSizeF(max(7.0, base.pointSizeF() - 1))
        drawn_any = False
        for lane in self._lanes:
            tasks = self._visible_tasks(lane)
            if self._filter and not tasks:
                continue
            drawn_any = True
            rows = max(1, min(len(tasks), self.MAX_ROWS))
            extra = 22 if len(tasks) > self.MAX_ROWS else 0
            box = QRectF(8, y, width - 16, self.LANE_H + rows * self.ROW_H + extra)
            p.setPen(QPen(QColor("#F5B841" if lane["is_lead"] else theme.BORDER),
                          1.4 if lane["is_lead"] else 1.0))
            p.setBrush(QBrush(QColor(theme.PANEL)))
            p.drawRoundedRect(box, 12, 12)
            # tiêu đề làn
            color = QColor(theme.agent_ring_color(lane["agent_id"])) if lane["agent_id"] != APP_LANE_ID else QColor("#7C8791")
            p.setPen(Qt.NoPen)
            p.setBrush(color)
            p.drawEllipse(QRectF(20, y + 9, 22, 22))
            p.setPen(QColor("#0C0D0F"))
            p.setFont(bold)
            p.drawText(QRectF(20, y + 9, 22, 22), Qt.AlignCenter, (lane["name"] or "?")[:1].upper())
            p.setPen(QColor(theme.TEXT))
            name = lane["name"]
            p.drawText(QRectF(50, y, 260, self.LANE_H), Qt.AlignVCenter | Qt.AlignLeft, name)
            x_after = 50 + QFontMetrics(bold).horizontalAdvance(name) + 10
            dot = {"online": "#CEFC19", "idle": "#F5B841"}.get(lane["status"], "#6F7680")
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(dot))
            p.drawEllipse(QRectF(x_after, y + self.LANE_H / 2 - 4, 8, 8))
            x_after += 16
            if lane["is_lead"]:
                badge = QRectF(x_after, y + 10, 104, 20)
                p.setBrush(QColor("#3A2E10"))
                p.setPen(QPen(QColor("#F5B841"), 1))
                p.drawRoundedRect(badge, 10, 10)
                p.setPen(QColor("#F5B841"))
                p.setFont(small)
                p.drawText(badge, Qt.AlignCenter, "★ TRƯỞNG PHÒNG")
            c = lane["counts"]
            summary = (
                f"{len(lane['tasks'])} việc"
                + (f" · {c.get('overdue', 0)} trễ" if c.get("overdue") else "")
                + (f" · {c.get('at_risk', 0)} sắp trễ" if c.get("at_risk") else "")
                + (f" · {c.get('blocked', 0)} kẹt" if c.get("blocked") else "")
            )
            p.setFont(small)
            p.setPen(QColor(theme.MUTED))
            p.drawText(QRectF(width - 320, y, 296, self.LANE_H), Qt.AlignVCenter | Qt.AlignRight, summary)
            ry = y + self.LANE_H
            if not tasks:
                p.setPen(QColor(theme.FAINT))
                p.drawText(QRectF(24, ry, width - 48, self.ROW_H), Qt.AlignVCenter | Qt.AlignLeft,
                           "Không có việc đang mở — đang rảnh.")
            for task in tasks[: self.MAX_ROWS]:
                self._paint_row(p, task, ry, width, base, bold, small)
                ry += self.ROW_H
            if extra:
                p.setFont(small)
                p.setPen(QColor(theme.MUTED))
                p.drawText(QRectF(24, ry, width - 48, 20), Qt.AlignVCenter | Qt.AlignLeft,
                           f"+{len(tasks) - self.MAX_ROWS} việc nữa (xem ở mục Công việc)")
            y = box.bottom() + 10
        if not drawn_any:
            p.setPen(QColor(theme.MUTED))
            p.drawText(self.rect(), Qt.AlignCenter,
                       "Không có việc nào khớp bộ lọc." if self._filter else
                       "Chưa có tài khoản Muse / việc đang mở.")
        p.end()

    def _paint_row(self, p, task, ry, width, base, bold, small):
        row = QRectF(16, ry + 2, width - 32, self.ROW_H - 4)
        self._hit.append((row, task["id"]))
        if task["id"] == self._selected:
            p.setPen(QPen(QColor(theme.ACCENT), 1.2))
            p.setBrush(QColor("#1B2A20"))
            p.drawRoundedRect(row, 8, 8)
        color = QColor(HEALTH_COLORS.get(task["health"], "#7C8791"))
        # nhãn việc
        label_rect = QRectF(28, ry, self.LABEL_W - 12, self.ROW_H)
        p.setFont(base)
        p.setPen(QColor(theme.TEXT))
        fm = QFontMetrics(base)
        title = fm.elidedText(f"{task['type_label']} · {task['profile']}", Qt.ElideRight, int(label_rect.width()))
        p.drawText(QRectF(label_rect.x(), ry + 2, label_rect.width(), 18), Qt.AlignLeft | Qt.AlignVCenter, title)
        p.setFont(small)
        p.setPen(QColor(theme.MUTED))
        sub = task["step"] or task["status_label"]
        sub = QFontMetrics(small).elidedText(f"#{task['id'][:8]} · {sub}", Qt.ElideRight, int(label_rect.width()))
        p.drawText(QRectF(label_rect.x(), ry + 18, label_rect.width(), 16), Qt.AlignLeft | Qt.AlignVCenter, sub)
        # thanh tiến độ + vạch thời gian
        bar_x = 28 + self.LABEL_W
        bar_w = max(80, width - bar_x - self.DUE_W - self.PILL_W - 40)
        bar = QRectF(bar_x, ry + self.ROW_H / 2 - 6, bar_w, 12)
        p.setPen(Qt.NoPen)
        pct = task.get("progress") or 0
        # V6.3.1: MỘT kiểu thanh tiến độ toàn app (mảnh 4px, accent).
        theme.paint_progress(p, bar, pct)
        p.setFont(small)
        p.setPen(QColor(theme.TEXT))
        used = task.get("time_used_pct")
        if used is not None:
            marker_x = bar.x() + bar_w * min(used, 100.0) / 100.0
            p.setPen(QPen(QColor("#FFFFFF"), 2))
            p.drawLine(QPointF(marker_x, bar.y() - 5), QPointF(marker_x, bar.bottom() + 5))
            if used > 100:
                p.setPen(QColor("#FF7A7A"))
                p.drawText(QRectF(bar.right() + 4, bar.y() - 4, 30, 20), Qt.AlignLeft | Qt.AlignVCenter, "▶")
        p.setPen(QColor(theme.TEXT))
        p.drawText(QRectF(bar.x(), bar.y() - 1, bar_w - 6, 14), Qt.AlignRight | Qt.AlignVCenter,
                   f"{pct}%")
        # hạn
        due_x = bar.right() + 26
        p.setFont(base)
        p.setPen(QColor(theme.TEXT))
        p.drawText(QRectF(due_x, ry + 2, self.DUE_W, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   "⏰ " + _fmt_due(task.get("due_at")))
        p.setFont(small)
        left = supervision.format_left(task.get("seconds_left"))
        p.setPen(QColor("#FF7A7A") if left.startswith("trễ") else QColor(theme.MUTED))
        p.drawText(QRectF(due_x, ry + 18, self.DUE_W, 16), Qt.AlignLeft | Qt.AlignVCenter, left or "chưa đặt hạn")
        # nhãn sức khoẻ
        pill = QRectF(width - self.PILL_W - 24, ry + self.ROW_H / 2 - 11, self.PILL_W, 22)
        tint = QColor(color)
        tint.setAlpha(40)
        p.setBrush(tint)
        p.setPen(QPen(color, 1))
        p.drawRoundedRect(pill, 11, 11)
        p.setPen(color)
        p.drawText(pill, Qt.AlignCenter, task["label"])

    # -- chuột -- #
    def _task_at(self, pos) -> str | None:
        for rect, task_id in self._hit:
            if rect.contains(QPointF(pos)):
                return task_id
        return None

    def mousePressEvent(self, event):
        task_id = self._task_at(event.position() if hasattr(event, "position") else event.pos())
        if task_id:
            self._selected = task_id
            self.update()
            self.task_selected.emit(task_id)
            if event.button() == Qt.RightButton:
                self.context_requested.emit(task_id, event.globalPosition().toPoint()
                                            if hasattr(event, "globalPosition") else event.globalPos())
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        pos = event.position() if hasattr(event, "position") else event.pos()
        self.setCursor(Qt.PointingHandCursor if self._task_at(pos) else Qt.ArrowCursor)
        super().mouseMoveEvent(event)


# --------------------------------------------------------------------------- #
# Sơ đồ đội: trưởng phòng → thành viên
# --------------------------------------------------------------------------- #
class TeamChart(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._lead: dict | None = None
        self._members: list[dict] = []
        self.setMinimumHeight(170)

    def set_team(self, lead: dict | None, members: list[dict]) -> None:
        self._lead = lead
        self._members = members
        rows = (len(members) + 2) // 3
        self.setMinimumHeight(96 + max(1, rows) * 58)
        self.update()

    def _node(self, p, rect: QRectF, item: dict, lead: bool):
        border = QColor("#F5B841") if lead else QColor(theme.BORDER)
        p.setPen(QPen(border, 1.4 if lead else 1))
        p.setBrush(QColor("#2A2412") if lead else QColor(theme.CARD))
        p.drawRoundedRect(rect, 10, 10)
        health = item.get("worst")
        dot = QColor(HEALTH_COLORS.get(health, "#CEFC19" if item.get("status") == "online" else "#6F7680"))
        p.setPen(Qt.NoPen)
        p.setBrush(dot)
        p.drawEllipse(QRectF(rect.x() + 8, rect.y() + 10, 8, 8))
        font = QFont(self.font())
        font.setBold(True)
        p.setFont(font)
        p.setPen(QColor(theme.TEXT))
        fm = QFontMetrics(font)
        p.drawText(QRectF(rect.x() + 20, rect.y() + 3, rect.width() - 24, 20),
                   Qt.AlignLeft | Qt.AlignVCenter,
                   fm.elidedText(("★ " if lead else "") + item["name"], Qt.ElideRight, int(rect.width() - 26)))
        small = QFont(self.font())
        small.setPointSizeF(max(7.0, small.pointSizeF() - 1))
        p.setFont(small)
        p.setPen(QColor("#FF7A7A") if item.get("overdue") else QColor(theme.MUTED))
        p.drawText(QRectF(rect.x() + 8, rect.y() + 22, rect.width() - 12, 18),
                   Qt.AlignLeft | Qt.AlignVCenter, item.get("summary") or "")

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(theme.PANEL))
        width = self.width()
        if self._lead is None:
            p.setPen(QColor(theme.MUTED))
            p.drawText(QRectF(10, 6, width - 20, 40), Qt.AlignLeft | Qt.TextWordWrap,
                       "Chưa chọn trưởng phòng — đang dùng VÒNG CHÉO (mỗi Muse do Muse kế tiếp chấm).")
            top = 50
        else:
            lead_rect = QRectF(width / 2 - 95, 8, 190, 44)
            self._node(p, lead_rect, self._lead, True)
            top = 80
        if not self._members:
            p.end()
            return
        cols = 3 if width >= 330 else 2
        node_w = (width - 16 - (cols - 1) * 8) / cols
        if self._lead is not None:
            p.setPen(QPen(QColor("#F5B841"), 1))
            p.drawLine(QPointF(width / 2, 52), QPointF(width / 2, 66))
            p.drawLine(QPointF(8 + node_w / 2, 66), QPointF(width - 8 - node_w / 2, 66))
        for index, member in enumerate(self._members):
            r, c = divmod(index, cols)
            x = 8 + c * (node_w + 8)
            y = top + r * 58
            if self._lead is not None and r == 0:
                p.setPen(QPen(QColor("#F5B841"), 1))
                p.drawLine(QPointF(x + node_w / 2, 66), QPointF(x + node_w / 2, y))
            self._node(p, QRectF(x, y, node_w, 46), member, False)
        p.end()


class _DueDialog(QDialog):
    def __init__(self, current_iso: str | None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Đặt hạn chót")
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Hạn hoàn thành mới:"))
        self.edit = QDateTimeEdit()
        self.edit.setCalendarPopup(True)
        self.edit.setDisplayFormat("dd/MM/yyyy HH:mm")
        from PySide6.QtCore import QDateTime

        base = None
        if current_iso:
            try:
                base = datetime.fromisoformat(current_iso)
            except ValueError:
                base = None
        base = base or datetime.now().astimezone()
        self.edit.setDateTime(QDateTime(base.year, base.month, base.day, base.hour, base.minute))
        layout.addWidget(self.edit)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def value_iso(self) -> str:
        value = self.edit.dateTime().toPython()
        return value.astimezone().isoformat(timespec="seconds")


class _KpiTile(QPushButton):
    def __init__(self, title: str, color: str, health: str | None):
        super().__init__()
        self.health = health
        self._color = color
        self.setCheckable(health is not None)
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(58)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._title = title
        self.set_value("0")

    def set_value(self, value: str):
        self.setText(f"{value}\n{self._title}")
        self.setStyleSheet(
            "QPushButton{background:%s;border:1px solid %s;border-radius:12px;"
            "color:%s;font-weight:700;padding:6px 10px;text-align:left;}"
            "QPushButton:checked{background:%s;border:2px solid %s;}"
            % (theme.CARD, theme.BORDER, self._color, "#1E2A22", self._color)
        )


KPI_COLUMNS = [
    "Muse", "Vai trò", "Điểm", "Đạt?", "Xong", "Đúng hạn", "Đạt lần đầu",
    "Treo", "Chờ người", "Trả lời chat", "Chưa đạt chỉ tiêu",
]


class SupervisionPanel(QWidget):
    open_command_requested = Signal(str)
    open_chat_requested = Signal(str)

    def __init__(self, store: Store, settings: dict | None = None,
                 notify=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings if settings is not None else {}
        self._notify = notify or (lambda _msg: None)
        self._signature: tuple | None = None
        self._stuck_reviews: list[dict] = []
        self._tasks: dict[str, dict] = {}
        self._syncing = False
        self._build_ui()
        self._timer = QTimer(self)
        self._timer.setInterval(5_000)
        self._timer.timeout.connect(self._on_timer_tick)
        self.refresh(force=True)

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(10)

        # ---- 1. Thanh điều khiển ---- #
        bar = QHBoxLayout()
        bar.setSpacing(8)
        bar.addWidget(theme.section_header("🔍 Giám sát · Trưởng phòng"))
        self.status_label = theme.muted_label("")
        bar.addWidget(self.status_label)
        bar.addSpacing(12)
        self.enabled_check = QCheckBox("Bật giám sát")
        self.enabled_check.toggled.connect(self._on_controls_changed)
        bar.addWidget(self.enabled_check)
        bar.addWidget(theme.muted_label("Chế độ:"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("👔 Trưởng phòng giám sát", "lead")
        self.mode_combo.addItem("🔁 Vòng chéo", "ring")
        self.mode_combo.currentIndexChanged.connect(self._on_controls_changed)
        bar.addWidget(self.mode_combo)
        bar.addWidget(theme.muted_label("Trưởng phòng:"))
        self.lead_combo = QComboBox()
        self.lead_combo.setMinimumWidth(180)
        self.lead_combo.currentIndexChanged.connect(self._on_controls_changed)
        bar.addWidget(self.lead_combo)
        bar.addStretch(1)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(lambda: self.refresh(force=True))
        bar.addWidget(refresh_button)
        root.addLayout(bar)

        # ---- 2. Dải chỉ số ---- #
        kpis = QHBoxLayout()
        kpis.setSpacing(8)
        self.kpi_open = _KpiTile("Việc đang mở", theme.TEXT, None)
        self.kpi_on_track = _KpiTile("Đúng tiến độ", HEALTH_COLORS["on_track"], "on_track")
        self.kpi_at_risk = _KpiTile("Sắp trễ", HEALTH_COLORS["at_risk"], "at_risk")
        self.kpi_overdue = _KpiTile("Trễ hạn", HEALTH_COLORS["overdue"], "overdue")
        self.kpi_blocked = _KpiTile("Đang kẹt / chờ bạn", HEALTH_COLORS["blocked"], "blocked")
        self.kpi_reviews = _KpiTile("Chờ chấm", "#60A5FA", None)
        self.kpi_week = _KpiTile("Xong đúng hạn (tuần)", theme.ACCENT, None)
        self._kpi_filters = [self.kpi_on_track, self.kpi_at_risk, self.kpi_overdue, self.kpi_blocked]
        for tile in (self.kpi_open, self.kpi_on_track, self.kpi_at_risk, self.kpi_overdue,
                     self.kpi_blocked, self.kpi_reviews, self.kpi_week):
            kpis.addWidget(tile)
        for tile in self._kpi_filters:
            tile.clicked.connect(lambda _c=False, t=tile: self._on_kpi_clicked(t))
        self.kpi_open.clicked.connect(lambda: self._on_kpi_clicked(None))
        root.addLayout(kpis)

        # ---- 3. Thân: bảng tiến độ | đội + thẻ điểm ---- #
        vsplit = QSplitter(Qt.Vertical)
        vsplit.setChildrenCollapsible(False)
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.setChildrenCollapsible(False)

        board_box = QFrame()
        board_box.setObjectName("Card")
        board_layout = QVBoxLayout(board_box)
        board_layout.setContentsMargins(10, 8, 10, 8)
        board_head = QHBoxLayout()
        board_head.addWidget(theme.section_header("Bảng tiến độ theo hạn chót"))
        self.filter_label = theme.muted_label("")
        board_head.addWidget(self.filter_label)
        board_head.addStretch(1)
        legend = theme.muted_label("▮ tiến độ   ┃ thời gian đã dùng của hạn — vạch vượt thanh = đang chậm")
        board_head.addWidget(legend)
        board_layout.addLayout(board_head)
        self.board = DeadlineBoard()
        from .. import command_actions as _ca

        self.board.explain = lambda task_id: _ca.explain_html(self._store, task_id)
        self.board.task_selected.connect(self._on_task_selected)
        self.board.context_requested.connect(self._on_task_context)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(self.board)
        board_layout.addWidget(scroll, 1)
        actions = QHBoxLayout()
        actions.setSpacing(6)
        self.task_hint = theme.muted_label("Chọn một việc để thao tác (hoặc chuột phải).")
        actions.addWidget(self.task_hint, 1)
        self.btn_remind = QPushButton("💬 Nhắc Muse")
        self.btn_remind.clicked.connect(lambda: self._remind_task(self.board.selected_task()))
        self.btn_extend = QPushButton("⏱ +1 giờ")
        self.btn_extend.clicked.connect(lambda: self._extend_task(self.board.selected_task(), 60))
        self.btn_due = QPushButton("📅 Đặt hạn…")
        self.btn_due.clicked.connect(lambda: self._set_due_task(self.board.selected_task()))
        self.btn_revoke = QPushButton("↩ Thu hồi")
        self.btn_revoke.clicked.connect(lambda: self._revoke_task(self.board.selected_task()))
        self.btn_open = QPushButton("📋 Mở lệnh")
        self.btn_open.clicked.connect(lambda: self._open_task(self.board.selected_task()))
        self._task_buttons = [self.btn_remind, self.btn_extend, self.btn_due, self.btn_revoke, self.btn_open]
        for button in self._task_buttons:
            actions.addWidget(button)
        board_layout.addLayout(actions)
        hsplit.addWidget(board_box)

        side = QFrame()
        side.setObjectName("Card")
        side.setMinimumWidth(300)
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(10, 8, 10, 8)
        side_layout.addWidget(theme.section_header("Sơ đồ đội"))
        self.team_chart = TeamChart()
        side_layout.addWidget(self.team_chart)
        side_layout.addWidget(theme.section_header("Thẻ điểm tuần này"))
        self.score_table = QTableWidget(0, 5)
        self.score_table.setHorizontalHeaderLabels(["Muse", "Xong", "Đúng hạn", "Đạt lần đầu", "Treo"])
        self.score_table.verticalHeader().setVisible(False)
        self.score_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.score_table.setSelectionMode(QAbstractItemView.NoSelection)
        header = self.score_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        for col in range(1, 5):
            header.setSectionResizeMode(col, QHeaderView.ResizeToContents)
        self.score_table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.score_table.font())
        )
        side_layout.addWidget(self.score_table, 1)
        # Nhãn văn bản (giữ cho tương thích + đọc nhanh/sao chép).
        self.scorecards_label = QLabel("")
        self.scorecards_label.setObjectName("Muted")
        self.scorecards_label.setWordWrap(True)
        self.scorecards_label.setVisible(False)
        side_layout.addWidget(self.scorecards_label)
        self.matrix_label = QLabel("")
        self.matrix_label.setObjectName("Muted")
        self.matrix_label.setWordWrap(True)
        side_layout.addWidget(self.matrix_label)
        hsplit.addWidget(side)
        hsplit.setStretchFactor(0, 1)
        hsplit.setStretchFactor(1, 0)
        hsplit.setSizes([1100, 380])
        vsplit.addWidget(hsplit)

        # ---- 4. Hàng đợi kiểm tra | cảnh báo ---- #
        tabs = QTabWidget()
        self.bottom_tabs = tabs
        review_page = QWidget()
        review_layout = QVBoxLayout(review_page)
        review_layout.setContentsMargins(0, 6, 0, 0)
        self.reviews_table = QTableWidget(0, len(REVIEW_COLUMNS))
        self.reviews_table.setHorizontalHeaderLabels(REVIEW_COLUMNS)
        self.reviews_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.reviews_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.reviews_table.verticalHeader().setVisible(False)
        self.reviews_table.verticalHeader().setDefaultSectionSize(
            theme.compact_row_height(self.reviews_table.font())
        )
        table_persist.attach_column_persistence(
            self.reviews_table, self._settings, "supervision_reviews",
            default_widths=[150, 130, 130, 130, 140, 50, 170, 110],
        )
        review_layout.addWidget(self.reviews_table)
        self.reviews_empty_label = theme.muted_label(
            "Chưa có vòng kiểm tra nào — tự sinh khi một lệnh của Muse xong/thất bại hoặc bị bắt treo."
        )
        review_layout.addWidget(self.reviews_empty_label)
        tabs.addTab(review_page, "🧾 Hàng đợi kiểm tra")
        alert_page = QWidget()
        alert_layout = QVBoxLayout(alert_page)
        alert_layout.setContentsMargins(0, 6, 0, 0)
        self.alerts_list = QListWidget()
        self.alerts_list.currentRowChanged.connect(self._on_alert_selected)
        alert_layout.addWidget(self.alerts_list)
        alert_actions = QHBoxLayout()
        self.remind_button = QPushButton("💬 Nhắc agent")
        self.remind_button.clicked.connect(self._on_remind_agent)
        alert_actions.addWidget(self.remind_button)
        self.revoke_button = QPushButton("↩ Thu hồi lệnh")
        self.revoke_button.clicked.connect(self._on_revoke_command)
        alert_actions.addWidget(self.revoke_button)
        self.alert_hint = theme.muted_label("")
        alert_actions.addWidget(self.alert_hint, 1)
        alert_layout.addLayout(alert_actions)
        tabs.addTab(alert_page, "⚠ Cảnh báo treo")
        # V6.3: KPI tuần (nhân viên + trưởng phòng) theo chỉ tiêu trong Cài đặt.
        kpi_page = QWidget()
        kpi_layout = QVBoxLayout(kpi_page)
        kpi_layout.setContentsMargins(0, 6, 0, 0)
        self.kpi_table = QTableWidget(0, len(KPI_COLUMNS))
        self.kpi_table.setHorizontalHeaderLabels(KPI_COLUMNS)
        self.kpi_table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.kpi_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.kpi_table.verticalHeader().setVisible(False)
        table_persist.attach_column_persistence(
            self.kpi_table, self._settings, "supervision_kpi",
            default_widths=[150, 110, 60, 90, 60, 80, 90, 60, 80, 90, 460],
        )
        kpi_layout.addWidget(self.kpi_table)
        kpi_layout.addWidget(theme.muted_label(
            "Điểm 0–100 chấm từ dữ liệu thật tuần này. Chỉ tiêu + quy tắc sửa ở Cài đặt → 📏 Quy tắc & KPI."
        ))
        tabs.addTab(kpi_page, "📊 KPI")
        # V6.3: nhật ký quyết định tự động của trưởng phòng.
        lead_page = QWidget()
        lead_layout = QVBoxLayout(lead_page)
        lead_layout.setContentsMargins(0, 6, 0, 0)
        self.lead_list = QListWidget()
        lead_layout.addWidget(self.lead_list)
        lead_actions = QHBoxLayout()
        self.lead_run_button = QPushButton("🤖 Trưởng phòng xử lý ngay")
        self.lead_run_button.setToolTip("Chạy một lượt tự xử lý mọi sự cố hiện có (trong phạm vi cho phép)")
        self.lead_run_button.clicked.connect(self._on_lead_run_now)
        lead_actions.addWidget(self.lead_run_button)
        self.lead_hint = theme.muted_label("")
        lead_actions.addWidget(self.lead_hint, 1)
        lead_layout.addLayout(lead_actions)
        tabs.addTab(lead_page, "🤖 Trưởng phòng tự xử lý")
        vsplit.addWidget(tabs)
        vsplit.setStretchFactor(0, 3)
        vsplit.setStretchFactor(1, 1)
        vsplit.setSizes([620, 220])
        root.addWidget(vsplit, 1)
        self._on_alert_selected(-1)
        self._on_task_selected(None)

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()
        self.refresh()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def _on_timer_tick(self):
        if self.isVisible():
            self.refresh()

    # ------------------------------------------------------------------ #
    # Điều khiển: bật/tắt, chế độ, trưởng phòng
    # ------------------------------------------------------------------ #
    def _sync_controls(self, agents: list[dict]):
        cfg = supervision.supervision_settings(self._settings)
        self._syncing = True
        try:
            self.enabled_check.setChecked(cfg["enabled"])
            index = self.mode_combo.findData(cfg["mode"])
            self.mode_combo.setCurrentIndex(index if index >= 0 else 0)
            wanted = [(0, "— Chưa chọn —")] + [
                (int(a["id"]), a.get("name") or a.get("email") or f"Muse #{a['id']}")
                for a in agents if not a.get("revoked")
            ]
            current = [
                (self.lead_combo.itemData(i), self.lead_combo.itemText(i))
                for i in range(self.lead_combo.count())
            ]
            if current != wanted:
                self.lead_combo.clear()
                for agent_id, label in wanted:
                    self.lead_combo.addItem(label, agent_id)
            index = self.lead_combo.findData(cfg["lead_agent_id"])
            self.lead_combo.setCurrentIndex(index if index >= 0 else 0)
            self.lead_combo.setEnabled(cfg["mode"] == "lead")
        finally:
            self._syncing = False

    def _on_controls_changed(self, *_args):
        if self._syncing:
            return
        self._settings["supervision_enabled"] = self.enabled_check.isChecked()
        self._settings["supervision_mode"] = self.mode_combo.currentData() or "lead"
        lead = self.lead_combo.currentData()
        self._settings["supervision_lead_agent_id"] = int(lead or 0)
        self.lead_combo.setEnabled(self._settings["supervision_mode"] == "lead")
        try:
            config.save_settings(self._settings)
        except OSError as exc:
            self._notify(f"Không lưu được cài đặt giám sát: {exc}")
        if self._settings["supervision_mode"] == "lead" and lead:
            self._notify(
                f"Trưởng phòng: {self.lead_combo.currentText()} — giám sát mọi tài khoản khác "
                "(áp cho việc kiểm tra sinh ra từ bây giờ)."
            )
        self.refresh(force=True)

    def _on_kpi_clicked(self, tile):
        for other in self._kpi_filters:
            if other is not tile:
                other.setChecked(False)
        health = tile.health if (tile is not None and tile.isChecked()) else None
        self.board.set_filter(health)
        self.filter_label.setText(
            f"· lọc: {supervision.HEALTH_LABELS.get(health, '')}" if health else ""
        )

    # ------------------------------------------------------------------ #
    def _refresh_kpi_and_lead(self):
        try:
            _kpi_refresh_impl(self)
        except Exception:
            pass

    def _on_lead_run_now(self):
        from .. import lead_autopilot

        decided = lead_autopilot.run(
            self._store, self._settings, force=True,
            save_settings=lambda data: config.save_settings(data),
        )
        self._kpi_key = None
        self.lead_hint.setText(f"Vừa ra {len(decided)} quyết định.")
        self.refresh(force=True)

    def refresh(self, force: bool = False):
        agents = self._store.list_agents()
        commands = self._store.list_open_commands(limit=400)
        review_sig = self._store.reviews_signature()
        minute = datetime.now().strftime("%H%M")
        signature = (
            review_sig,
            minute,
            tuple((a.get("id"), a.get("status"), a.get("name"), bool(a.get("revoked"))) for a in agents),
            tuple((c["id"], c.get("status"), c.get("progress"), c.get("due_at"),
                   c.get("agent_id"), c.get("lease_agent_id"), c.get("step")) for c in commands),
            (self._settings.get("supervision_mode"), self._settings.get("supervision_lead_agent_id"),
             self._settings.get("supervision_enabled")),
        )
        self._refresh_kpi_and_lead()
        if not force and signature == self._signature:
            return
        self._signature = signature
        cfg = supervision.supervision_settings(self._settings)
        self._sync_controls(agents)
        lead_id = supervision.lead_agent_id(self._store, self._settings)
        if not cfg["enabled"]:
            self.status_label.setText("· đang TẮT")
        elif lead_id is not None:
            self.status_label.setText(f"· trưởng phòng {_agent_label(self._store, lead_id)} chấm mọi tài khoản khác")
        else:
            self.status_label.setText("· vòng chéo (chưa chọn trưởng phòng)")

        owner_by_profile = {}
        for agent in agents:
            for pid in agent.get("profile_ids") or []:
                owner_by_profile[int(pid)] = int(agent["id"])
        model = build_board_model(
            agents, commands, lead_id, warn_percent=cfg["warn_percent"],
            owner_by_profile=owner_by_profile,
        )
        self._tasks = {t["id"]: t for lane in model["lanes"] for t in lane["tasks"]}
        self.board.set_model(model["lanes"])
        if self.board.selected_task() not in self._tasks:
            self.board.select(None)
            self._on_task_selected(None)
        counts = model["counts"]
        self.kpi_open.set_value(str(counts.get("total", 0)))
        self.kpi_on_track.set_value(str(counts.get("on_track", 0)))
        self.kpi_at_risk.set_value(str(counts.get("at_risk", 0)))
        self.kpi_overdue.set_value(str(counts.get("overdue", 0)))
        self.kpi_blocked.set_value(str(counts.get("blocked", 0)))
        # V6.9: rê chuột lên ô đếm → popup liệt kê TỪNG việc + lý do kẹt/trễ.
        try:
            from .. import command_actions as _ca

            by_health: dict[str, list[str]] = {}
            for task in self._tasks.values():
                by_health.setdefault(task.get("health") or "", []).append(task["id"])
            for tile, title in ((self.kpi_on_track, "Đúng tiến độ"), (self.kpi_at_risk, "Sắp trễ"),
                                (self.kpi_overdue, "Trễ hạn"), (self.kpi_blocked, "Đang kẹt / chờ bạn")):
                _ca.attach_lazy_tooltip(tile, lambda t=title, i=tuple(by_health.get(tile.health) or []):
                                        _ca.group_html(self._store, t, i))
            _ca.attach_lazy_tooltip(self.kpi_open, lambda i=tuple(self._tasks.keys()):
                                    _ca.group_html(self._store, "Việc đang mở", i))
        except Exception:
            pass
        self.kpi_reviews.set_value(str(review_sig[2] if len(review_sig) > 2 else 0))
        week = self._store.deadline_stats(None, supervision.week_start_iso())
        total = week["on_time"] + week["late"]
        self.kpi_week.set_value(f"{round(100 * week['on_time'] / total)}%" if total else "—")

        # Sơ đồ đội
        lanes = {l["agent_id"]: l for l in model["lanes"]}

        def node(agent: dict) -> dict:
            lane = lanes.get(int(agent["id"])) or {"tasks": [], "counts": {}}
            c = lane["counts"]
            worst = None
            for key in ("overdue", "blocked", "at_risk", "on_track"):
                if c.get(key):
                    worst = key
                    break
            parts = [f"{len(lane['tasks'])} việc"]
            if c.get("overdue"):
                parts.append(f"{c['overdue']} trễ")
            if c.get("at_risk"):
                parts.append(f"{c['at_risk']} sắp trễ")
            return {
                "name": agent.get("name") or agent.get("email") or f"Muse #{agent['id']}",
                "status": agent.get("status"),
                "worst": worst,
                "overdue": bool(c.get("overdue")),
                "summary": " · ".join(parts),
            }

        active = [a for a in agents if not a.get("revoked")]
        lead_agent = next((a for a in active if int(a["id"]) == lead_id), None)
        self.team_chart.set_team(
            node(lead_agent) if lead_agent else None,
            [node(a) for a in active if lead_agent is None or int(a["id"]) != lead_id],
        )

        self._refresh_reviews()
        self._refresh_scorecards(cfg, active)

    def _refresh_reviews(self):
        reviews = self._store.list_reviews(limit=100)
        reviews.sort(key=lambda r: (r["status"] != "open", -int(r["id"])))
        with table_persist.batch_update(self.reviews_table):
            self.reviews_table.setRowCount(len(reviews))
            for row, review in enumerate(reviews):
                target = self._store.get_command(review["command_id"])
                values = [
                    f"#{review['command_id']}",
                    COMMAND_TYPE_LABELS.get(
                        (target or {}).get("type"), (target or {}).get("type") or "—"
                    ),
                    _agent_label(self._store, review.get("worker_agent_id")),
                    _agent_label(self._store, review.get("supervisor_agent_id")),
                    TRIGGER_LABELS.get(review["trigger_kind"], review["trigger_kind"]),
                    str(review.get("round") or 0),
                    REVIEW_STATUS_LABELS.get(review["status"], review["status"]),
                    _fmt_ts(review.get("created_at")),
                ]
                for col, value in enumerate(values):
                    self.reviews_table.setItem(row, col, QTableWidgetItem(value))
        self.reviews_empty_label.setVisible(not reviews)
        self.reviews_table.setVisible(bool(reviews))
        open_count = sum(1 for r in reviews if r["status"] == "open")
        self.bottom_tabs.setTabText(0, f"🧾 Hàng đợi kiểm tra ({open_count} chờ chấm)")

        self._stuck_reviews = [
            r for r in self._store.list_reviews(status="open", limit=100)
            if r["trigger_kind"] == "stuck"
        ]
        self.alerts_list.clear()
        for review in self._stuck_reviews:
            target = self._store.get_command(review["command_id"])
            status = (target or {}).get("status") or "?"
            self.alerts_list.addItem(QListWidgetItem(
                f"⚠ Lệnh #{review['command_id']} "
                f"({COMMAND_TYPE_LABELS.get((target or {}).get('type'), '')}) "
                f"— trạng thái {status}, người làm "
                f"{_agent_label(self._store, review.get('worker_agent_id'))}, "
                f"mở lúc {_fmt_ts(review.get('created_at'))}"
            ))
        if not self._stuck_reviews:
            self.alerts_list.addItem(QListWidgetItem("Không có cảnh báo treo nào đang mở."))
            self.alerts_list.setEnabled(False)
        else:
            self.alerts_list.setEnabled(True)
        self.bottom_tabs.setTabText(1, f"⚠ Cảnh báo treo ({len(self._stuck_reviews)})")
        self._on_alert_selected(self.alerts_list.currentRow())

    def _refresh_scorecards(self, cfg: dict, agents: list[dict]):
        if not agents:
            self.scorecards_label.setText("Chưa có tài khoản Muse nào.")
            self.matrix_label.setText("")
            self.score_table.setRowCount(0)
            return
        lines = []
        with table_persist.batch_update(self.score_table):
            self.score_table.setRowCount(len(agents))
            for row, agent in enumerate(agents):
                card = supervision.scorecard(self._store, int(agent["id"]))
                rate = (
                    f"{card['first_pass_rate']:.0f}%"
                    if card["first_pass_rate"] is not None else "—"
                )
                avg = (
                    f"{card['avg_completion_seconds'] / 60:.1f} phút"
                    if card["avg_completion_seconds"] is not None else "—"
                )
                dl = card.get("deadline") or {"on_time": 0, "late": 0}
                dl_total = dl["on_time"] + dl["late"]
                on_time = f"{round(100 * dl['on_time'] / dl_total)}%" if dl_total else "—"
                name = agent.get("name") or agent.get("email") or f"Muse #{agent['id']}"
                lines.append(
                    f"• {name}: đạt ngay lần đầu {rate} "
                    f"({card['first_pass_decided']} lệnh đã chấm) · "
                    f"làm lại {card['rework_rounds']} vòng · "
                    f"bị bắt treo {card['stuck_count']} lần · "
                    f"leo thang {card['escalations']} · "
                    f"xong {card['commands_done']} lệnh, trung bình {avg}/lệnh · "
                    f"đúng hạn {on_time}"
                )
                values = [name, str(card["commands_done"]), on_time, rate, str(card["stuck_count"])]
                for col, value in enumerate(values):
                    item = QTableWidgetItem(value)
                    if col == 2 and dl_total and dl["late"]:
                        item.setForeground(QColor("#F5B841"))
                    self.score_table.setItem(row, col, item)
        self.scorecards_label.setText("\n".join(lines))
        matrix = supervision.effective_matrix(self._store, self._settings)
        pairs = [
            f"{_agent_label(self._store, w)} → {_agent_label(self._store, s)} chấm"
            for w, s in sorted(matrix.items())
        ]
        self.matrix_label.setText(
            "Ma trận giám sát: " + (" · ".join(pairs) if pairs else "—")
        )
        self.matrix_label.setToolTip(self.matrix_label.text())

    # ------------------------------------------------------------------ #
    # Thao tác trên một việc của bảng tiến độ
    # ------------------------------------------------------------------ #
    def _on_task_selected(self, task_id):
        task = self._tasks.get(task_id) if task_id else None
        for button in self._task_buttons:
            button.setEnabled(task is not None)
        if task is None:
            self.task_hint.setText("Chọn một việc để thao tác (hoặc chuột phải).")
            return
        self.btn_remind.setEnabled(task.get("agent_id") is not None)
        self.btn_revoke.setEnabled(task.get("status") == "running" and task.get("agent_id") is not None)
        left = supervision.format_left(task.get("seconds_left"))
        self.task_hint.setText(
            f"#{task['id'][:8]} · {task['type_label']} · {task['profile']} · "
            f"{task['progress']}% · hạn {_fmt_due(task.get('due_at'))} ({left or 'chưa đặt'}) · {task['label']}"
        )

    def _on_task_context(self, task_id: str, global_pos):
        task = self._tasks.get(task_id)
        if task is None:
            return
        menu = QMenu(self)
        if task.get("agent_id") is not None:
            menu.addAction("💬 Nhắc Muse làm việc này", lambda: self._remind_task(task_id))
            menu.addAction("🗨 Mở chat với Muse", lambda: self.open_chat_requested.emit(task_id))
        menu.addSeparator()
        menu.addAction("⏱ Gia hạn +30 phút", lambda: self._extend_task(task_id, 30))
        menu.addAction("⏱ Gia hạn +1 giờ", lambda: self._extend_task(task_id, 60))
        menu.addAction("⏱ Gia hạn +4 giờ", lambda: self._extend_task(task_id, 240))
        menu.addAction("📅 Đặt hạn chót…", lambda: self._set_due_task(task_id))
        menu.addSeparator()
        if task.get("status") == "running" and task.get("agent_id") is not None:
            menu.addAction("↩ Thu hồi lệnh về hàng chờ", lambda: self._revoke_task(task_id))
        menu.addAction("📋 Mở lệnh trong Công việc", lambda: self._open_task(task_id))
        menu.addAction("🧾 Lịch sử kiểm tra…", lambda: ReviewHistoryDialog(
            self._store, task_id, self._settings, self._notify, self).exec())
        menu.exec(global_pos)

    def _remind_task(self, task_id):
        task = self._tasks.get(task_id) if task_id else None
        if task is None or task.get("agent_id") is None:
            return
        left = supervision.format_left(task.get("seconds_left"))
        body = (
            f"⏰ Trưởng phòng nhắc việc: lệnh #{task_id} ({task['type_label']}, hồ sơ "
            f"{task['profile']}) đang {task['progress']}% — hạn {_fmt_due(task.get('due_at'))}"
            f" ({left or 'chưa đặt hạn'}). Báo tiến độ ngay; nếu kẹt hãy nói rõ kẹt ở đâu."
        )
        self._store.add_message(int(task["agent_id"]), "user", body, command_id=task_id)
        self._store.append_journal(
            f"[Giám sát] Đã nhắc Muse #{task['agent_id']} về lệnh #{task_id} ({task['label']}).",
            task.get("profile_id"),
        )
        self._notify(f"Đã nhắc {_agent_label(self._store, task['agent_id'])} về lệnh #{task_id[:8]}.")

    def _extend_task(self, task_id, minutes: int):
        if not task_id:
            return
        row = self._store.extend_command_due(task_id, minutes)
        if row is None:
            return
        self._store.append_journal(
            f"[Giám sát] Gia hạn lệnh #{task_id} thêm {minutes} phút → hạn mới {_fmt_due(row.get('due_at'))}.",
            row.get("profile_id"),
        )
        self._notify(f"Đã gia hạn lệnh #{task_id[:8]} tới {_fmt_due(row.get('due_at'))}.")
        self.refresh(force=True)

    def _set_due_task(self, task_id):
        task = self._tasks.get(task_id) if task_id else None
        if task is None:
            return
        dialog = _DueDialog(task.get("due_at"), self)
        if dialog.exec() != QDialog.Accepted:
            return
        row = self._store.set_command_due(task_id, dialog.value_iso())
        self._store.append_journal(
            f"[Giám sát] Đặt hạn lệnh #{task_id} → {_fmt_due((row or {}).get('due_at'))}.",
            (row or {}).get("profile_id"),
        )
        self.refresh(force=True)

    def _revoke_task(self, task_id):
        if not task_id:
            return
        released = self._store.release_claude_command(task_id, None)
        if released is None:
            self._notify(f"Không thu hồi được lệnh #{task_id[:8]} — lệnh không còn đang chạy.")
            return
        self._store.append_journal(
            f"[Giám sát] Đã THU HỒI lệnh #{task_id} khỏi Muse đang giữ (về hàng chờ).",
            released.get("profile_id"),
        )
        self._notify(f"Đã thu hồi lệnh #{task_id[:8]} về hàng chờ.")
        self.refresh(force=True)

    def _open_task(self, task_id):
        if task_id:
            self.open_command_requested.emit(task_id)

    # ------------------------------------------------------------------ #
    def _selected_alert(self) -> dict | None:
        row = self.alerts_list.currentRow()
        if 0 <= row < len(self._stuck_reviews):
            return self._stuck_reviews[row]
        return None

    def _on_alert_selected(self, _row: int):
        alert = self._selected_alert()
        if alert is None:
            self.remind_button.setEnabled(False)
            self.revoke_button.setEnabled(False)
            self.alert_hint.setText(
                "Chọn một cảnh báo treo ở danh sách trên để nhắc agent "
                "hoặc thu hồi lệnh."
            )
            return
        target = self._store.get_command(alert["command_id"])
        self.remind_button.setEnabled(
            alert.get("worker_agent_id") is not None
        )
        running = (target or {}).get("status") == "running"
        self.revoke_button.setEnabled(running)
        self.alert_hint.setText(
            f"Lệnh #{alert['command_id']} đang '{(target or {}).get('status')}'"
            + ("" if running else " — chỉ thu hồi được lệnh đang chạy (đang giữ lease).")
        )

    def _on_remind_agent(self):
        alert = self._selected_alert()
        if alert is None or alert.get("worker_agent_id") is None:
            return
        body = (
            f"⏰ Nhắc việc: lệnh #{alert['command_id']} đang bị watchdog "
            "đánh dấu NGHI TREO (không tiến triển). Kiểm tra lại lệnh "
            "này ngay: tiếp tục và báo tiến độ, hoặc trả lệnh/báo lý "
            "do kẹt trong luồng chat này."
        )
        self._store.add_message(
            int(alert["worker_agent_id"]), "user", body,
            command_id=alert["command_id"],
        )
        self._store.append_journal(
            f"[Giám sát] Chủ kênh đã NHẮC Muse "
            f"#{alert['worker_agent_id']} về lệnh treo #{alert['command_id']}.",
            (self._store.get_command(alert["command_id"]) or {}).get("profile_id"),
        )
        self._notify(f"Đã gửi tin nhắc tới Muse #{alert['worker_agent_id']}.")

    def _on_revoke_command(self):
        alert = self._selected_alert()
        if alert is None:
            return
        released = self._store.release_claude_command(alert["command_id"], None)
        if released is None:
            self._notify(
                f"Không thu hồi được lệnh #{alert['command_id']} — lệnh "
                "không còn ở trạng thái đang chạy."
            )
            return
        self._store.append_journal(
            f"[Giám sát] Chủ kênh đã THU HỒI lệnh #{alert['command_id']} "
            "khỏi agent giữ lease (về hàng chờ Muse).",
            released.get("profile_id"),
        )
        self._notify(f"Đã thu hồi lệnh #{alert['command_id']} về hàng chờ.")
        self.refresh(force=True)


# --------------------------------------------------------------------------- #
# Hộp thoại lịch sử kiểm tra của MỘT lệnh (chi tiết lệnh — plan §7)
# --------------------------------------------------------------------------- #
def _kpi_refresh_impl(panel):
    from datetime import datetime as _dt

    from .. import kpi as _kpi
    from PySide6.QtGui import QColor as _QColor
    from PySide6.QtWidgets import QTableWidgetItem as _Item

    stamp = _dt.now().strftime("%H%M")
    version = panel._store.data_version()
    key = (stamp, version, panel._settings.get("supervision_lead_agent_id"))
    if getattr(panel, "_kpi_key", None) == key:
        return
    panel._kpi_key = key
    try:
        rows = _kpi.team_kpi(panel._store, panel._settings)
    except Exception as exc:
        panel.lead_hint.setText(f"Không tính được KPI: {exc}")
        return
    table = panel.kpi_table
    lines = []
    for row in rows:
        lines.append(row)
        if row.get("lead"):
            lines.append(dict(row["lead"], name=row["name"] + " (giám sát)", is_lead_line=True))
    table.setRowCount(len(lines))
    for r, row in enumerate(lines):
        is_lead_line = row.get("is_lead_line")
        values = [
            row.get("name") or "—",
            "Trưởng phòng" if is_lead_line else ("Nhân viên ★" if row.get("is_lead") else "Nhân viên"),
            _kpi.fmt(row.get("score")),
            "—" if row.get("passed") is None else ("✓ Đạt" if row["passed"] else "✕ Chưa"),
            _kpi.fmt(row.get("auto_fixed") if is_lead_line else row.get("done")),
            _kpi.fmt(row.get("team_on_time_pct") if is_lead_line else row.get("on_time_pct"), "%"),
            _kpi.fmt(row.get("auto_fix_pct") if is_lead_line else row.get("first_pass_pct"), "%"),
            "—" if is_lead_line else str(row.get("stuck", 0)),
            "—" if is_lead_line else str(row.get("needs_user", 0)),
            _kpi.fmt(row.get("review_min") if is_lead_line else row.get("chat_reply_min"), " ph"),
            "; ".join(row.get("misses") or []) or "Đạt mọi chỉ tiêu có dữ liệu",
        ]
        for c, value in enumerate(values):
            item = _Item(str(value))
            if c == 3 and row.get("passed") is not None:
                item.setForeground(_QColor("#6CC7FF" if row["passed"] else "#FF7A7A"))
            table.setItem(r, c, item)
    decisions = panel._store.list_lead_decisions(limit=80)
    panel.lead_list.clear()
    for d in decisions:
        icon = "🤖" if d.get("outcome") == "done" else "⬆"
        panel.lead_list.addItem(f"{(d.get('at') or '')[5:16].replace('T', ' ')}  {icon} {d.get('detail')}")
    auto = sum(1 for d in decisions if d.get("outcome") == "done")
    panel.lead_hint.setText(
        f"{auto} quyết định tự xử lý · {len(decisions) - auto} leo thang (80 gần nhất)"
        + ("" if panel._settings.get("lead_auto_fix", True) else " · ĐANG TẮT tự xử lý (Cài đặt → ⚙ Tự vận hành)")
    )


class ReviewHistoryDialog(QDialog):
    """Lịch sử kiểm tra của một lệnh gốc + override của chủ kênh
    (GĐ2): "Bỏ qua kiểm tra" đóng vòng đang mở mà không đổi trạng
    thái lệnh gốc; "Chốt đạt" đóng vòng với kết luận Đạt."""

    def __init__(self, store: Store, command_id: str,
                 settings: dict | None = None, notify=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._command_id = command_id
        self._settings = settings if settings is not None else {}
        self._notify = notify or (lambda _msg: None)
        self.setWindowTitle(f"Lịch sử kiểm tra — lệnh #{command_id}")
        self.resize(640, 420)
        root = QVBoxLayout(self)
        self.summary_label = QLabel("")
        self.summary_label.setWordWrap(True)
        root.addWidget(self.summary_label)
        self.history_view = QListWidget()
        # Dòng lịch sử dài (kích hoạt + ghi chú + checklist): cho
        # XUỐNG DÒNG thay vì cắt ngang/cuộn ngang khó đọc.
        self.history_view.setWordWrap(True)
        root.addWidget(self.history_view, 1)
        actions = QHBoxLayout()
        self.skip_button = QPushButton("⏭ Bỏ qua kiểm tra")
        self.skip_button.clicked.connect(lambda: self._override("skip"))
        actions.addWidget(self.skip_button)
        self.pass_button = QPushButton("✅ Chốt đạt")
        self.pass_button.clicked.connect(lambda: self._override("pass"))
        actions.addWidget(self.pass_button)
        actions.addStretch(1)
        close_button = QPushButton("Đóng")
        close_button.clicked.connect(self.accept)
        actions.addWidget(close_button)
        root.addLayout(actions)
        self.refresh()

    def refresh(self):
        target = self._store.get_command(self._command_id)
        reviews = self._store.list_reviews_for_command(self._command_id)
        if target is None:
            self.summary_label.setText("Không thấy lệnh này trong kho.")
            self.skip_button.setEnabled(False)
            self.pass_button.setEnabled(False)
            return
        self.summary_label.setText(
            f"Lệnh #{self._command_id} ({COMMAND_TYPE_LABELS.get(target.get('type'), target.get('type'))})"
            f" — trạng thái {target.get('status')}, đã làm lại "
            f"{target.get('review_round') or 0} vòng, kết luận gần nhất: "
            f"{target.get('last_verdict') or 'chưa có'}."
        )
        self.history_view.clear()
        if not reviews:
            self.history_view.addItem(QListWidgetItem(
                "Lệnh này chưa từng được kiểm tra chéo."
            ))
        for review in reviews:
            checklist_lines = []
            for item in review.get("checklist") or []:
                if isinstance(item, dict):
                    mark = {"pass": "✔", "fail": "✘", "na": "—"}.get(
                        item.get("status"), "•"
                    )
                    checklist_lines.append(f"      {mark} {item.get('item', '')}")
            text = (
                f"Vòng {review.get('round') or 0} — "
                f"{REVIEW_STATUS_LABELS.get(review['status'], review['status'])}"
                f" · kích hoạt: {TRIGGER_LABELS.get(review['trigger_kind'], review['trigger_kind'])}"
                f" · người làm {_agent_label(self._store, review.get('worker_agent_id'))}"
                f" · giám sát {_agent_label(self._store, review.get('supervisor_agent_id'))}"
                f" · mở {_fmt_ts(review.get('created_at'))}"
                + (f" · chốt {_fmt_ts(review.get('decided_at'))}" if review.get("decided_at") else "")
                + (f"\n      Ghi chú: {review['notes']}" if review.get("notes") else "")
                + ("\n" + "\n".join(checklist_lines) if checklist_lines else "")
            )
            self.history_view.addItem(QListWidgetItem(text))
        open_review = self._store.open_review_for_command(self._command_id)
        can_override = open_review is not None
        self.skip_button.setEnabled(can_override)
        self.pass_button.setEnabled(can_override)
        self.skip_button.setToolTip(
            "Đóng vòng kiểm tra đang mở, lệnh gốc giữ nguyên trạng thái."
            if can_override else "Không có vòng kiểm tra nào đang mở."
        )
        self.pass_button.setToolTip(
            "Đóng vòng kiểm tra đang mở với kết luận Đạt."
            if can_override else "Không có vòng kiểm tra nào đang mở."
        )

    def _override(self, verdict: str):
        open_review = self._store.open_review_for_command(self._command_id)
        if open_review is None or not open_review.get("review_command_id"):
            return
        try:
            outcome = supervision.apply_verdict(
                self._store,
                open_review["review_command_id"],
                verdict,
                notes="Quyết định trực tiếp của chủ kênh trong app.",
                actor="owner",
                settings=self._settings,
            )
        except ValueError as exc:
            self._notify(f"Không áp được quyết định: {exc}")
            return
        self._notify(
            f"Đã {'bỏ qua kiểm tra' if verdict == 'skip' else 'chốt ĐẠT'} "
            f"cho lệnh #{self._command_id} ({outcome['outcome']})."
        )
        self.refresh()
