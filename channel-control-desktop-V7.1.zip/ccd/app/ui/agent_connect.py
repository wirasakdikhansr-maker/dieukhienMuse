"""Hộp thoại KẾT NỐI của một tài khoản Muse (V4.6 — nút 🔌 trên
từng dòng bảng Tài khoản Muse).

Người dùng từng hỏi "đã đăng nhập sao vẫn ngoại tuyến" vì hai lớp
trạng thái trông giống nhau mà khác hẳn nhau:

(a) CẦU NỐI Muse — agent chỉ "Đang hoạt động" khi có một Muse
    cầm PHIẾU KẾT NỐI của nó gọi vào app (heartbeat). Đây là lớp
    quyết định trạng thái online/offline của agent.
(b) ĐĂNG NHẬP muse.ai — phiên web trong Chrome riêng của tài
    khoản; đăng nhập xong KHÔNG làm agent online.

Hộp thoại này tách bạch hai lớp, nêu LÝ DO ngoại tuyến suy từ dữ
liệu thật (chưa từng có heartbeat / mất nhịp từ lúc nào), và cho
hành động ngay tại chỗ: xuất lại phiếu của đúng agent đó + kiểm
tra lại ngay.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
)

from .. import tickets
from ..store import Store
from . import theme

# Khớp WEB_STATE_LABELS ở agents_panel (sao chép nhỏ để tránh import
# vòng: agents_panel nhập hộp thoại này).
WEB_STATE_LABELS = {
    "in": "✅ Đã đăng nhập",
    "out": "❌ Chưa đăng nhập",
    "waiting": "⏳ Đang chờ đăng nhập…",
    "unknown": "❔ Chưa kiểm tra",
}

LAYER_NOTE = (
    "Hai lớp KHÁC nhau: đăng nhập muse.ai chỉ là phiên web trong "
    "Chrome của tài khoản — KHÔNG làm agent online. Agent chỉ hiện "
    "“Đang hoạt động” khi có một Muse cầm PHIẾU KẾT NỐI của nó "
    "gọi vào app (heartbeat qua cầu nối)."
)


def _age_seconds(agent: dict) -> float | None:
    raw = agent.get("last_seen_at")
    if not raw:
        return None
    try:
        seen = datetime.fromisoformat(str(raw))
    except ValueError:
        return None
    if seen.tzinfo is None:
        seen = seen.astimezone()
    return max(0.0, (datetime.now().astimezone() - seen).total_seconds())


def _fmt_seen(value) -> str:
    if not value:
        return "chưa từng"
    try:
        moment = datetime.fromisoformat(str(value))
    except ValueError:
        return str(value)
    if moment.tzinfo is None:
        moment = moment.astimezone()
    return moment.strftime("%H:%M %d/%m")


def _fmt_age(age: float | None) -> str:
    if age is None:
        return ""
    if age < 90:
        return f"{int(age)} giây trước"
    minutes = int(age // 60)
    if minutes < 90:
        return f"{minutes} phút trước"
    hours, rest = divmod(minutes, 60)
    return f"{hours} giờ {rest} phút trước" if rest else f"{hours} giờ trước"


def bridge_state(agent: dict) -> tuple[str, str]:
    """(nhãn lớp cầu nối, lý do) — suy từ heartbeat THẬT của agent.

    - online: đang kết nối.
    - chưa từng có heartbeat: "Chưa từng kết nối — phiếu chưa được
      nạp cho Muse nào".
    - từng có heartbeat rồi mất: "Mất nhịp từ HH:MM (X phút trước)".
    """
    if agent.get("revoked") or agent.get("status") == "revoked":
        return (
            "🚫 Đã thu hồi",
            "Token của tài khoản đã bị thu hồi — mở lại token để "
            "Muse kết nối lại được.",
        )
    age = _age_seconds(agent)
    if agent.get("status") == "online":
        return (
            "🟢 Đang kết nối",
            f"Heartbeat gần nhất {_fmt_age(age)} — Muse đang cầm "
            "phiếu của tài khoản này và gọi vào app đều đặn.",
        )
    if age is None:
        return (
            "⚪ Ngoại tuyến",
            "Chưa từng kết nối — phiếu chưa được nạp cho Muse nào. "
            "Bấm “🎫 Xuất phiếu kết nối” rồi đưa file phiếu của tài "
            "khoản này cho Muse của nó.",
        )
    seen_hhmm = _fmt_seen(agent.get("last_seen_at")).split(" ")[0]
    return (
        "⚪ Ngoại tuyến",
        f"Mất nhịp từ {seen_hhmm} ({_fmt_age(age)}) — Muse của "
        "tài khoản này đã ngừng gọi vào app; kiểm tra phía Muse "
        "(cầu nối còn chạy không, phiếu còn đúng không).",
    )


class AgentConnectDialog(QDialog):
    """Chi tiết kết nối 2 lớp của MỘT agent + hành động tại chỗ."""

    def __init__(self, store: Store, agent_id: int, settings=None,
                 data_dir=None, on_recheck=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._agent_id = int(agent_id)
        self._settings = settings if settings is not None else {}
        self._data_dir = data_dir
        # on_recheck: nơi chứa (AgentsPanel) làm mới toàn bảng sau
        # khi kiểm tra lại tại đây.
        self._on_recheck = on_recheck or (lambda: None)
        self._agent: dict | None = None
        self.setWindowTitle("🔌 Kết nối tài khoản Muse")
        self.setMinimumWidth(520)
        self._build_ui()
        self.refresh_view()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        self.title_label = QLabel("")
        self.title_label.setObjectName("DialogTitle")
        self.title_label.setWordWrap(True)
        root.addWidget(self.title_label)

        bridge_box = QFrame()
        bridge_box.setObjectName("Panel")
        bridge_layout = QVBoxLayout(bridge_box)
        bridge_layout.setContentsMargins(14, 12, 14, 12)
        bridge_layout.setSpacing(6)
        bridge_layout.addWidget(
            theme.section_header("🌉 Lớp 1 — Cầu nối Muse (phiếu kết nối)")
        )
        self.bridge_status_label = QLabel("")
        self.bridge_status_label.setWordWrap(True)
        bridge_layout.addWidget(self.bridge_status_label)
        self.bridge_seen_label = QLabel("")
        self.bridge_seen_label.setObjectName("Muted")
        self.bridge_seen_label.setWordWrap(True)
        bridge_layout.addWidget(self.bridge_seen_label)
        self.bridge_reason_label = QLabel("")
        self.bridge_reason_label.setWordWrap(True)
        bridge_layout.addWidget(self.bridge_reason_label)
        self.ticket_state_label = QLabel("")
        self.ticket_state_label.setObjectName("Muted")
        self.ticket_state_label.setWordWrap(True)
        bridge_layout.addWidget(self.ticket_state_label)
        root.addWidget(bridge_box)

        web_box = QFrame()
        web_box.setObjectName("Panel")
        web_layout = QVBoxLayout(web_box)
        web_layout.setContentsMargins(14, 12, 14, 12)
        web_layout.setSpacing(6)
        web_layout.addWidget(
            theme.section_header("🌐 Lớp 2 — Đăng nhập muse.ai (Chrome của tài khoản)")
        )
        self.web_status_label = QLabel("")
        self.web_status_label.setWordWrap(True)
        web_layout.addWidget(self.web_status_label)
        note = QLabel(LAYER_NOTE)
        note.setObjectName("Muted")
        note.setWordWrap(True)
        web_layout.addWidget(note)
        root.addWidget(web_box)

        self.ticket_path_label = QLabel("")
        self.ticket_path_label.setObjectName("Faint12")
        self.ticket_path_label.setWordWrap(True)
        root.addWidget(self.ticket_path_label)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        self.export_button = QPushButton("🎫 Xuất phiếu kết nối")
        self.export_button.setProperty("variant", "primary")
        self.export_button.setToolTip(
            "Ghi lại file phiếu RIÊNG của tài khoản này vào thư mục "
            "phiếu rồi mở thư mục đó — đưa file cho Muse của tài "
            "khoản để nó kết nối vào app."
        )
        self.export_button.clicked.connect(self._on_export)
        buttons.addWidget(self.export_button)
        self.recheck_button = QPushButton("↻ Kiểm tra lại ngay")
        self.recheck_button.setToolTip(
            "Đọc lại trạng thái mới nhất của tài khoản này và làm "
            "mới toàn bộ bảng Tài khoản Muse."
        )
        self.recheck_button.clicked.connect(self._on_recheck_clicked)
        buttons.addWidget(self.recheck_button)
        buttons.addStretch(1)
        close_button = QPushButton("Đóng")
        close_button.clicked.connect(self.accept)
        buttons.addWidget(close_button)
        root.addLayout(buttons)

    # ------------------------------------------------------------------ #
    # Dữ liệu + hiển thị
    # ------------------------------------------------------------------ #
    def _ticket_folder(self) -> Path:
        return tickets.ticket_export_dir(self._settings, self._data_dir)

    def _ticket_state(self, agent: dict) -> tuple[str, Path]:
        """Trạng thái file phiếu của agent so với dữ liệu hiện tại."""
        folder = self._ticket_folder()
        path = folder / tickets.agent_ticket_filename(agent)
        try:
            if not path.exists():
                return ("❌ chưa xuất file riêng", path)
            profiles = {p["id"]: p for p in self._store.list_profiles()}
            expected = tickets.agent_ticket_text(agent, profiles)
            if path.read_text(encoding="utf-8") == expected:
                return ("✅ đã xuất, khớp dữ liệu hiện tại", path)
            return ("⚠ LỆCH dữ liệu — nên xuất lại", path)
        except Exception as exc:
            return (f"⚠ không kiểm tra được ({exc})", path)

    def refresh_view(self):
        """Đọc lại agent từ Store và vẽ lại cả hai lớp."""
        agent = self._store.get_agent(self._agent_id)
        self._agent = agent
        if agent is None:
            self.title_label.setText(
                f"Không còn thấy tài khoản Muse #{self._agent_id}."
            )
            self.bridge_status_label.setText("Trạng thái: —")
            self.bridge_seen_label.setText("")
            self.bridge_reason_label.setText("")
            self.ticket_state_label.setText("")
            self.web_status_label.setText("Đăng nhập muse.ai: —")
            self.export_button.setEnabled(False)
            return
        self.export_button.setEnabled(True)
        self.title_label.setText(
            f"{agent.get('name') or 'Muse'} · {agent.get('email') or ''}"
        )
        label, reason = bridge_state(agent)
        self.bridge_status_label.setText(f"Trạng thái cầu nối: {label}")
        age = _age_seconds(agent)
        if age is None:
            self.bridge_seen_label.setText("Nhịp heartbeat cuối: chưa từng")
        else:
            self.bridge_seen_label.setText(
                f"Nhịp heartbeat cuối: {_fmt_seen(agent.get('last_seen_at'))}"
                f" ({_fmt_age(age)})"
            )
        self.bridge_reason_label.setText(reason)
        state_text, path = self._ticket_state(agent)
        self.ticket_state_label.setText(f"Phiếu kết nối: {state_text}")
        self.ticket_path_label.setText(f"📁 {path}")
        web_label = WEB_STATE_LABELS.get(
            agent.get("web_state") or "unknown", "❔ Chưa kiểm tra"
        )
        self.web_status_label.setText(f"Đăng nhập muse.ai: {web_label}")

    # ------------------------------------------------------------------ #
    # Hành động
    # ------------------------------------------------------------------ #
    def export_ticket(self) -> Path | None:
        """Ghi lại file phiếu RIÊNG của agent này + mở thư mục phiếu.

        Trả đường dẫn file phiếu (None khi agent không còn / ghi
        lỗi). Mở thư mục bằng QDesktopServices — trên Windows là
        Explorer tại đúng thư mục phiếu của app."""
        if self._agent is None:
            return None
        folder = self._ticket_folder()
        try:
            path = tickets.write_agent_ticket(
                self._store, self._agent_id, folder
            )
        except Exception:
            return None
        if path is None:
            return None
        self.refresh_view()
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(folder)))
        except Exception:
            pass
        return Path(path)

    def _on_export(self):
        self.export_ticket()

    def _on_recheck_clicked(self):
        self.refresh_view()
        try:
            self._on_recheck()
        except Exception:
            pass
