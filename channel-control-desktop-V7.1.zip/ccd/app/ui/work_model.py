"""Mô hình cây công việc (V4.3) — logic THUẦN cho panel Công việc.

Đầu vào là các dict thô đúng như ``store.list_commands`` /
``store.list_agents`` / ``store.list_profiles`` /
``store.list_channels`` trả về; đầu ra là cây
agent → hồ sơ → kênh → lệnh, mỗi nút kèm ``counts`` (số lệnh theo
nhóm trạng thái) và ``percent`` (% cuốn chiếu từ mọi lệnh con cháu)
để panel chỉ việc vẽ, không tự tính lại.

Mọi quyết định nằm ở đây để test được bằng dict giả — module này
KHÔNG I/O, KHÔNG Qt, KHÔNG chạm store:

- Lọc cửa sổ hiển thị: lệnh đang sống (queued / running /
  waiting_muse / needs_user / interrupted) luôn hiện; lệnh đã kết
  thúc (done / failed) chỉ hiện khi ``updated_at`` (dự phòng
  ``created_at``) rơi vào NGÀY HÔM NAY theo ``now`` truyền vào.
  Chuỗi ngày rỗng/None/sai định dạng coi như "không phải hôm nay"
  nhưng không bao giờ làm rớt lệnh đang sống.
- Phân công lệnh cho agent: ``agent_id`` ghi danh trên lệnh THẮNG
  phân công hồ sơ; agent_id trống/không còn tồn tại thì tra hồ sơ
  trong bản đồ profile→agent dựng từ ``agents[].profile_ids``
  (agent đứng trước trong danh sách thắng khi một hồ sơ lỡ thuộc
  hai agent); không có đường nào → bucket "chưa phân công"
  (``agent`` là None, luôn nằm CUỐI cây, chỉ tạo khi có lệnh mồ côi).
- Thứ tự lệnh trong mỗi nhóm con = đúng thứ tự dispatcher xét:
  nguồn ui > auto > api, cùng nguồn thì cũ trước, bẻ hoà bằng
  ``_seq`` (rowid) — xem ``app/dispatcher.py``.
- ``percent`` của một nút = làm tròn trung bình ``command_percent``
  trên MỌI lệnh con cháu (không phải trung bình của các % con);
  nút không có lệnh nào → None để panel hiện "—" thay vì 0% giả.
"""

from __future__ import annotations

import hashlib
from datetime import datetime

try:
    # dispatcher không phụ thuộc Qt nên import thẳng được; hằng số
    # này là NGUỒN SỰ THẬT DUY NHẤT cho thứ tự ưu tiên nguồn lệnh.
    from ..dispatcher import SOURCE_PRIORITY
except ImportError:  # pragma: no cover — phòng khi module bị nạp
    # ngoài ngữ cảnh package (import vòng/lạ): khai báo cục bộ GIỐNG
    # HỆT app/dispatcher.py để hành vi không lệch.
    SOURCE_PRIORITY = {"ui": 0, "auto": 1, "api": 2}

# Ánh xạ trạng thái lệnh → nhóm (bucket) hiển thị/đếm. 'interrupted'
# gộp vào "failed" (lệnh chết giữa chừng cần xử lý như thất bại),
# 'queued' + 'waiting_muse' gộp vào "waiting" (cùng là đang chờ).
STATUS_BUCKETS = {
    "running": "running",
    "queued": "waiting",
    "waiting_muse": "waiting",
    "needs_user": "needs_user",
    "failed": "failed",
    "interrupted": "failed",
    "done": "done",
}

# Lệnh đang sống: luôn hiện bất kể ngày tháng.
_ACTIVE_STATUSES = frozenset(
    {"queued", "running", "waiting_muse", "needs_user", "interrupted"}
)
# Lệnh đã kết thúc: chỉ hiện khi kết thúc trong ngày hôm nay.
_TERMINAL_STATUSES = frozenset({"done", "failed"})

_COUNT_KEYS = ("running", "waiting", "needs_user", "failed", "done")


# ---------------------------------------------------------------------- #
# % và counts
# ---------------------------------------------------------------------- #
def command_percent(command: dict) -> int:
    """% hoàn thành của MỘT lệnh: done luôn 100; còn lại lấy
    ``progress`` (None → 0) kẹp trong 0..100."""
    if (command or {}).get("status") == "done":
        return 100
    try:
        value = int((command or {}).get("progress") or 0)
    except (TypeError, ValueError):
        value = 0
    return max(0, min(100, value))


def empty_counts() -> dict:
    """Bộ đếm rỗng: mọi bucket 0 kèm ``total`` (tổng lệnh đã đếm)."""
    return {
        "running": 0,
        "waiting": 0,
        "needs_user": 0,
        "failed": 0,
        "done": 0,
        "total": 0,
    }


def add_counts(target: dict, source: dict) -> dict:
    """Cộng ``source`` vào ``target`` (tại chỗ) và trả ``target`` —
    dùng khi cuốn chiếu counts từ nút con lên nút cha."""
    for key in (*_COUNT_KEYS, "total"):
        target[key] = int(target.get(key) or 0) + int(source.get(key) or 0)
    return target


def _counts_for(commands) -> dict:
    counts = empty_counts()
    for command in commands:
        bucket = STATUS_BUCKETS.get(command.get("status"))
        if bucket is None:
            continue
        counts[bucket] += 1
        counts["total"] += 1
    return counts


def _percent_for(commands) -> int | None:
    """% cuốn chiếu: trung bình ``command_percent`` trên TOÀN BỘ
    lệnh truyền vào; rỗng → None."""
    if not commands:
        return None
    total = sum(command_percent(command) for command in commands)
    return int(round(total / len(commands)))


# ---------------------------------------------------------------------- #
# Ngày tháng + thứ tự dispatcher
# ---------------------------------------------------------------------- #
def _parse_datetime(value) -> datetime | None:
    """Parse ISO chịu lỗi: rỗng/None/sai định dạng → None. Chuỗi
    không kèm múi giờ hiểu theo giờ địa phương (giống dispatcher)."""
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


def _finished_today(command: dict, now: datetime) -> bool:
    """Lệnh kết thúc có rơi vào NGÀY HÔM NAY (theo ``now``) không —
    xét ``updated_at`` trước, ``created_at`` dự phòng khi trường
    chính trống/không parse được."""
    parsed = _parse_datetime(command.get("updated_at"))
    if parsed is None:
        parsed = _parse_datetime(command.get("created_at"))
    if parsed is None:
        return False
    return parsed.astimezone(now.tzinfo).date() == now.date()


def _is_included(command: dict, now: datetime) -> bool:
    status = command.get("status")
    if status in _ACTIVE_STATUSES:
        return True
    if status in _TERMINAL_STATUSES:
        return _finished_today(command, now)
    return False


def _dispatch_key(command: dict):
    """Đúng khoá sắp xếp của dispatcher (app/dispatcher.py): ưu tiên
    nguồn, rồi cũ trước, bẻ hoà bằng _seq (rowid, có thể thiếu)."""
    return (
        SOURCE_PRIORITY.get(command.get("source"), 3),
        str(command.get("created_at") or ""),
        command.get("_seq") or 0,
    )


def _sorted(commands) -> list:
    return sorted(commands, key=_dispatch_key)


# ---------------------------------------------------------------------- #
# Dựng cây
# ---------------------------------------------------------------------- #
def _build_channel_and_profile(profile, channel_dicts, profile_commands):
    """Dựng một profile_node từ các lệnh thuộc đúng hồ sơ đó.

    Trả ``(profile_node, descendant_commands)`` — descendant là mọi
    lệnh con cháu đã sắp theo thứ tự dispatcher, dùng để cuốn chiếu
    counts/percent lên các nút cha."""
    channel_nodes = []
    node_by_channel_id = {}
    for channel in channel_dicts:
        node = {
            "channel": channel,
            "commands": [],
            "counts": empty_counts(),
            "percent": None,
        }
        channel_nodes.append(node)
        channel_id = channel.get("channel_id")
        if channel_id not in (None, ""):
            node_by_channel_id.setdefault(str(channel_id), node)

    own_commands = []
    for command in profile_commands:
        channel_id = command.get("channel_id")
        node = (
            node_by_channel_id.get(str(channel_id))
            if channel_id not in (None, "")
            else None
        )
        if node is not None:
            node["commands"].append(command)
        else:
            own_commands.append(command)

    descendants: list = []
    for node in channel_nodes:
        node["commands"] = _sorted(node["commands"])
        node["counts"] = _counts_for(node["commands"])
        node["percent"] = _percent_for(node["commands"])
        descendants.extend(node["commands"])
    own_commands = _sorted(own_commands)
    descendants.extend(own_commands)

    profile_node = {
        "profile": profile,
        "channels": channel_nodes,
        "commands": own_commands,
        "counts": _counts_for(descendants),
        "percent": _percent_for(descendants),
    }
    return profile_node, descendants


def build_work_model(
    commands,
    agents,
    profiles,
    channels_by_profile,
    now: datetime | None = None,
) -> dict:
    """Dựng cây công việc từ các dict thô của store.

    ``channels_by_profile``: dict profile_id → list channel dict
    (đúng như gọi ``store.list_channels(profile_id)`` cho từng hồ
    sơ). ``now``: mốc "hôm nay" — datetime có tz; mặc định là thời
    điểm hiện tại theo giờ địa phương.

    Cây trả về::

        {"agents": [agent_node, ...],   # agent thật theo tên (không
                                         # phân biệt hoa thường),
                                         # bucket None (nếu có) cuối
         "summary": {"agent_count": int, "counts": {...},
                     "percent": int | None, "command_count": int},
         "generated_at": now.isoformat()}

    agent_node::

        {"agent": dict | None, "profiles": [profile_node, ...],
         "loose_commands": [lệnh không có profile_id],
         "counts": {...}, "percent": int | None}

    profile_node::

        {"profile": dict | None,   # None = lệnh mang profile_id
                                   # không còn trong danh sách hồ sơ
         "channels": [channel_node, ...],
         "commands": [lệnh có hồ sơ nhưng không khớp kênh nào],
         "counts": {...}, "percent": int | None}

    channel_node: {"channel": dict, "commands": [...],
                   "counts": {...}, "percent": int | None}

    MỌI agent thật đều có mặt dù không có lệnh nào (panel cần hiện
    đủ). Hồ sơ hiện trong nút agent khi: được phân công cho agent
    đó, hoặc có lệnh của agent đó trỏ tới; kênh hiện theo
    ``channels_by_profile`` của hồ sơ.
    """
    now = now or datetime.now().astimezone()
    commands = list(commands or [])
    agents = list(agents or [])
    profiles = list(profiles or [])
    channels_by_profile = channels_by_profile or {}

    included = [c for c in commands if _is_included(c, now)]

    agents_by_id: dict = {}
    for agent in agents:
        if agent.get("id") is not None:
            agents_by_id.setdefault(agent["id"], agent)
    # Bản đồ profile→agent từ phân công hồ sơ; agent đứng trước
    # thắng khi dữ liệu lỡ phân một hồ sơ cho hai agent.
    profile_owner: dict = {}
    for agent in agents:
        for profile_id in agent.get("profile_ids") or []:
            profile_owner.setdefault(profile_id, agent)
    profiles_by_id: dict = {}
    for profile in profiles:
        if profile.get("id") is not None:
            profiles_by_id.setdefault(profile["id"], profile)

    def resolve_agent(command):
        agent_id = command.get("agent_id")
        if agent_id is not None and agent_id in agents_by_id:
            return agents_by_id[agent_id]
        profile_id = command.get("profile_id")
        if profile_id:
            return profile_owner.get(profile_id)
        return None

    # Gom lệnh theo agent (khoá: id của agent, None = mồ côi).
    commands_by_agent: dict = {}
    for command in included:
        owner = resolve_agent(command)
        key = owner["id"] if owner is not None else None
        commands_by_agent.setdefault(key, []).append(command)

    def build_agent_node(agent, owned_commands):
        if agent is not None:
            assigned_ids = {
                pid for pid in (agent.get("profile_ids") or []) if pid
            }
        else:
            assigned_ids = set()
        referenced_ids = {
            command["profile_id"]
            for command in owned_commands
            if command.get("profile_id")
        }
        wanted_ids = assigned_ids | referenced_ids
        # Hồ sơ đã biết: theo thứ tự trong danh sách hồ sơ đầu vào.
        ordered_profile_ids = [
            profile["id"]
            for profile in profiles
            if profile.get("id") in wanted_ids
        ]
        # profile_id lạ (không còn trong danh sách): nút profile
        # None riêng cho từng id, xếp cuối theo id cho ổn định.
        known_ids = set(ordered_profile_ids)
        unknown_ids = sorted(
            (pid for pid in wanted_ids if pid not in known_ids),
            key=lambda pid: str(pid),
        )

        profile_nodes = []
        descendants: list = []
        for profile_id in [*ordered_profile_ids, *unknown_ids]:
            profile = profiles_by_id.get(profile_id)
            channel_dicts = (
                channels_by_profile.get(profile_id) or []
                if profile is not None
                else []
            )
            profile_commands = [
                command
                for command in owned_commands
                if command.get("profile_id") == profile_id
            ]
            node, sub = _build_channel_and_profile(
                profile, channel_dicts, profile_commands
            )
            profile_nodes.append(node)
            descendants.extend(sub)

        loose = _sorted(
            [c for c in owned_commands if not c.get("profile_id")]
        )
        descendants.extend(loose)
        agent_node = {
            "agent": agent,
            "profiles": profile_nodes,
            "loose_commands": loose,
            "counts": _counts_for(descendants),
            "percent": _percent_for(descendants),
        }
        return agent_node

    ordered_agents = sorted(
        agents, key=lambda a: str(a.get("name") or "").casefold()
    )
    agent_nodes = [
        build_agent_node(agent, commands_by_agent.get(agent.get("id"), []))
        for agent in ordered_agents
    ]
    # Bucket "chưa phân công" CHỈ tồn tại khi có lệnh mồ côi, và
    # luôn nằm cuối cây.
    if None in commands_by_agent:
        agent_nodes.append(build_agent_node(None, commands_by_agent[None]))

    summary = {
        "agent_count": len(agents),
        "counts": _counts_for(included),
        "percent": _percent_for(included),
        "command_count": len(included),
    }
    return {
        "agents": agent_nodes,
        "summary": summary,
        "generated_at": now.isoformat(),
    }


# ---------------------------------------------------------------------- #
# Dấu vân thay đổi (panel dùng để biết có cần vẽ lại không)
# ---------------------------------------------------------------------- #
def work_fingerprint(commands, agents) -> str:
    """SHA-256 rút gọn (16 ký tự hex) của trạng thái công việc.

    Nguyên liệu: mỗi lệnh lấy (id, status, progress, updated_at)
    sắp theo id; mỗi agent lấy (id, last_seen_at, status) sắp theo
    id. Cùng input → cùng dấu vân (bất kể thứ tự danh sách đầu vào);
    bất kỳ trường nào trong số đó đổi → dấu vân đổi.
    """

    def field(value) -> str:
        return "" if value is None else str(value)

    lines: list[str] = []
    for command in sorted(
        commands or [], key=lambda c: str(c.get("id"))
    ):
        lines.append(
            "cmd|{}|{}|{}|{}".format(
                field(command.get("id")),
                field(command.get("status")),
                field(command.get("progress")),
                field(command.get("updated_at")),
            )
        )
    for agent in sorted(agents or [], key=lambda a: str(a.get("id"))):
        lines.append(
            "agent|{}|{}|{}".format(
                field(agent.get("id")),
                field(agent.get("last_seen_at")),
                field(agent.get("status")),
            )
        )
    digest = hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()
    return digest[:16]
