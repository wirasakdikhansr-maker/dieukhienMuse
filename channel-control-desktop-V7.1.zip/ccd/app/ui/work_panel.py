"""Mục "📋 Công việc" (V4.5 — thiết kế lại chống rối):

- Cột TRÁI "Giao việc" (~430px): form tạo lệnh MỘT CỘT DỌC (Skill →
  Muse nhận lệnh → Loại lệnh → Hồ sơ đích → Kênh checkbox → Nội
  dung) + "Hàng đợi lệnh" rút gọn bên dưới (dòng compact, lô gộp
  một dòng, huy hiệu tự-chạy-lại). Form + hàng đợi là hai khối
  form_card / queue_panel của CommandsPanel được xếp sang đây.
- Cột PHẢI "Ai đang làm gì": dải tổng quan (pill đếm đang chạy /
  chờ / cần xử lý / thất bại) + bảng việc theo agent 3 dạng xem
  (Danh sách / Ô / Nhánh trên work_model) + bảng lệnh đầy đủ
  (list_block của CommandsPanel) ở dưới trong splitter dọc.
- Một chỗ hiển thị tiến độ cho mỗi việc (thẻ việc ở bảng; hàng đợi
  chỉ hiện % gọn), bộ lọc GỘP MỘT HÀNG, một kiểu panel duy nhất.
- Splitter ngang nhớ tỉ lệ qua settings MỚI work_split_h2 /
  work_split_v2 (đảo cột so với V4.3.1 nên không dùng lại khoá cũ —
  tỉ lệ cũ sẽ áp ngược ý đồ); cửa sổ <1200px xếp dọc: Giao việc
  trên, Ai đang làm gì dưới.
- Bấm một việc (bảng việc / hàng đợi) → chọn đúng lệnh đó ở bảng
  lệnh bên phải + làm nổi bật trên bảng việc.
"""


from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QPoint, QRect, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QFrame,
    QGraphicsScene,
    QGraphicsTextItem,
    QGraphicsView,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSlider,
    QSplitter,
    QStackedWidget,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import config
from .. import auto_retry
from ..store import COMMAND_TYPE_LABELS, Store
from . import theme, work_model
from .agent_board import AgentBoardWidget
from .commands_panel import STATUS_LABELS

VIEW_LIST, VIEW_CARDS, VIEW_TREE = "list", "cards", "tree"
VIEW_AGENTS = "agents"
VIEW_KANBAN = "kanban"  # V6.5: bảng Kanban (mặc định)
VIEW_LEDGER = "ledger"  # V6.7: sổ giao việc của trưởng phòng
CARDS_FULL_LIMIT = 12          # ≤ 12 agent: cột thẻ đầy đủ cho mọi agent
CARD_COMMAND_LIMIT = 8         # số lệnh tối đa hiện trong một cột thẻ
FILTERS = (
    ("all", "Tất cả"),
    ("running", "Đang chạy"),
    ("waiting", "Đang chờ"),
    ("needs_user", "Chờ người"),
    ("failed", "Lỗi"),
    ("done", "Đã xong"),
)
SORTS = (
    ("recent", "Hoạt động gần nhất"),
    ("percent", "% cao nhất"),
    ("name", "Theo tên"),
)
_BUCKET_COLORS = {
    "running": "#6CC7FF",
    "waiting": "#F2C94C",
    "needs_user": "#C4A7FF",
    "failed": "#FF7A7A",
    "done": "#43D675",
}
# Bucket trạng thái → state của theme.pill (thẻ việc / đầu cột agent).
_PILL_STATE_BY_BUCKET = {
    "running": "run",
    "waiting": "paused",
    "needs_user": "user",
    "failed": "out",
    "done": "in",
}
_STATUS_BUCKET = {
    "running": "running",
    "queued": "waiting",
    "waiting_muse": "waiting",
    "needs_user": "needs_user",
    "failed": "failed",
    "interrupted": "failed",
    "done": "done",
}


def bar_text(percent, width: int = 10) -> str:
    """Thanh % dạng khối unicode (không dùng widget con trong bảng —
    kỷ luật chống widget mồ côi của CCD)."""
    pct = max(0, min(100, int(percent or 0)))
    filled = max(0, min(width, round(pct * width / 100)))
    return f"{'█' * filled}{'░' * (width - filled)} {pct}%"


def _agent_title(agent: dict | None) -> str:
    if agent is None:
        return "❔ Chưa phân công"
    name = agent.get("name") or agent.get("email") or f"Muse #{agent.get('id')}"
    return f"🤖 {name}"


def _counts_text(counts: dict) -> str:
    parts = []
    if counts.get("running"):
        parts.append(f"▶ {counts['running']}")
    if counts.get("waiting"):
        parts.append(f"⏳ {counts['waiting']}")
    if counts.get("needs_user"):
        parts.append(f"✋ {counts['needs_user']}")
    if counts.get("failed"):
        parts.append(f"❌ {counts['failed']}")
    if counts.get("done"):
        parts.append(f"✅ {counts['done']}")
    return " · ".join(parts) if parts else "— không có việc —"


def _agent_name(agent: dict | None) -> str:
    if agent is None:
        return "Chưa phân công"
    return agent.get("name") or agent.get("email") or f"Muse #{agent.get('id')}"


def _agent_pill(node: dict) -> QLabel:
    """Pill trạng thái của agent (Concept D: pill có chấm) — suy từ
    bộ đếm việc THẬT của agent: đang chạy > chờ người > đang chờ >
    rảnh."""
    counts = node.get("counts") or {}
    if counts.get("running"):
        return theme.pill("● Đang chạy", "in")
    if counts.get("needs_user"):
        return theme.pill("✋ Chờ người", "user")
    if counts.get("waiting"):
        return theme.pill("● Đang chờ", "run")
    return theme.pill("● Rảnh", "unknown")


class FlowLayout(QLayout):
    """Bố cục chảy (mẫu chuẩn của Qt): xếp widget liên tiếp trái
    → phải, hết bề rộng thì XUỐNG DÒNG thay vì cắt/nén chữ.
    V5.3.1 (M1) dùng cho khối đầu bảng việc: ở cửa sổ rộng mọi
    điều khiển nằm gọn 1–2 dòng; ở cửa sổ hẹp chúng xuống thêm
    dòng chứ KHÔNG BAO GIỜ cắt chữ nút/nhãn (luật giao diện)."""

    def __init__(self, parent=None, h_spacing: int = 8, v_spacing: int = 6):
        super().__init__(parent)
        self._items: list = []
        self._h_spacing = h_spacing
        self._v_spacing = v_spacing
        self.setContentsMargins(0, 0, 0, 0)

    def addItem(self, item):
        self._items.append(item)

    def count(self):
        return len(self._items)

    def itemAt(self, index):
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index):
        if 0 <= index < len(self._items):
            return self._items.pop(index)
        return None

    def expandingDirections(self):
        return Qt.Orientation(0)

    def hasHeightForWidth(self):
        return True

    def heightForWidth(self, width):
        return self._do_layout(QRect(0, 0, width, 0), test_only=True)

    def setGeometry(self, rect):
        super().setGeometry(rect)
        self._do_layout(rect, test_only=False)

    def sizeHint(self):
        return self.minimumSize()

    def minimumSize(self):
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        size += QSize(margins.left() + margins.right(),
                      margins.top() + margins.bottom())
        return size

    def _do_layout(self, rect, test_only):
        margins = self.contentsMargins()
        effective = rect.adjusted(
            margins.left(), margins.top(), -margins.right(), -margins.bottom()
        )
        x = effective.x()
        y = effective.y()
        line_height = 0
        for item in self._items:
            widget = item.widget()
            if widget is not None and widget.isHidden():
                continue  # V6.9: widget ẩn không để lại khoảng trống
            hint = item.sizeHint()
            next_x = x + hint.width() + self._h_spacing
            if next_x - self._h_spacing > effective.right() + 1 and line_height > 0:
                x = effective.x()
                y += line_height + self._v_spacing
                next_x = x + hint.width() + self._h_spacing
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y() + margins.bottom()


class _CommandCard(QFrame):
    """Thẻ một việc trong cột agent (dạng Ô) — phong cách Concept D:
    tiêu đề đậm, dòng phụ (hồ sơ · kênh), thanh tiến độ kèm pill % ở
    cuối thanh, hàng meta dưới: bước hiện tại + chip nguồn. Bấm thẻ →
    phát ``clicked`` để panel chọn đúng lệnh đó ở bảng lệnh cột phải.
    (Thẻ nằm trong lưới cuộn, KHÔNG phải ô bảng — widget con ở đây an
    toàn, không vướng kỷ luật orphan của bảng tự làm mới.)"""

    clicked = Signal(str)

    def __init__(self, command: dict, context: str, parent=None,
                 highlighted: bool = False):
        super().__init__(parent)
        self.setObjectName("Card")
        self.command_id = command.get("id")
        self.setCursor(Qt.PointingHandCursor)
        if highlighted:
            # V4.5: lệnh vừa được chọn từ Hàng đợi lệnh — viền nhấn
            # để mắt tìm thấy ngay trên bảng việc.
            self.setStyleSheet(f"border: 1px solid {theme.ACCENT};")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(4)
        label = COMMAND_TYPE_LABELS.get(
            command.get("type"), command.get("type") or ""
        )
        title = QLabel(label)
        title.setObjectName("CardTitle")
        title.setWordWrap(True)
        layout.addWidget(title)
        if context:
            sub = QLabel(context)
            sub.setObjectName("Muted12")
            sub.setWordWrap(True)
            layout.addWidget(sub)
        pct = work_model.command_percent(command)
        bucket = _STATUS_BUCKET.get(command.get("status"), "waiting")
        color = _BUCKET_COLORS.get(bucket, theme.MUTED)
        bar_row = QHBoxLayout()
        bar_row.setSpacing(8)
        bar = QProgressBar()
        bar.setRange(0, 100)
        bar.setValue(pct)
        bar.setTextVisible(False)
        bar.setFixedHeight(theme.PROGRESS_HEIGHT)
        # V6.3.1: một kiểu thanh tiến độ (accent) — màu trạng thái ở pill.
        bar_row.addWidget(bar, 1)
        bar_row.addWidget(
            theme.pill(f"{pct}%", _PILL_STATE_BY_BUCKET.get(bucket, "unknown"))
        )
        layout.addLayout(bar_row)
        meta = QHBoxLayout()
        meta.setSpacing(8)
        step = (command.get("step") or "").strip()
        status = STATUS_LABELS.get(command.get("status"), command.get("status") or "")
        step_label = QLabel(step or status)
        step_label.setObjectName("Faint12")
        step_label.setWordWrap(True)
        meta.addWidget(step_label, 1)
        source_text = {"ui": "Trong app", "api": "Muse", "auto": "Tự động"}.get(
            command.get("source"), command.get("source") or ""
        )
        if source_text:
            meta.addWidget(theme.pill(source_text, "unknown"))
        # V4.5: huy hiệu LÔ (lệnh thuộc fan-out nhiều kênh) + huy
        # hiệu TỰ CHẠY LẠI cho lệnh failed đang có lịch/chờ retry.
        payload = command.get("payload") or {}
        if payload.get("batch_id") and int(payload.get("batch_total") or 0) > 1:
            meta.addWidget(
                theme.pill(f"🧩 Lô ×{int(payload['batch_total'])}", "unknown")
            )
        if bucket == "failed" and payload.get("auto_retry_count"):
            meta.addWidget(
                theme.pill(
                    f"↻ {int(payload['auto_retry_count'])}/{auto_retry.MAX_AUTO_RETRIES}",
                    "out",
                )
            )
        layout.addLayout(meta)
        self.setToolTip(
            (command.get("instruction") or "")[:300]
            + (f"\nBước: {step}" if step else "")
        )

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton and self.command_id:
            self.clicked.emit(str(self.command_id))
        super().mousePressEvent(event)


class _AgentTile(QFrame):
    """Ô gọn của một agent (>12 agent) — bấm để nở/thu cột thẻ."""

    clicked = Signal(int)

    def __init__(self, node: dict, expanded: bool, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self._agent_key = _node_key(node)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(4)
        agent = node.get("agent")
        head = QHBoxLayout()
        head.setSpacing(8)
        seed = str((agent or {}).get("email") or (agent or {}).get("name") or "?")
        head.addWidget(theme.avatar("🤖", seed, 30))
        title = QLabel(_agent_name(agent))
        title.setObjectName("CardTitle")
        title.setWordWrap(True)
        head.addWidget(title, 1)
        head.addWidget(_agent_pill(node))
        layout.addLayout(head)
        counts = node.get("counts") or {}
        current = _first_current(node)
        if current is not None:
            label = COMMAND_TYPE_LABELS.get(
                current.get("type"), current.get("type") or ""
            )
            layout.addWidget(
                theme.muted_label(
                    f"{label} · {bar_text(work_model.command_percent(current), 8)}"
                )
            )
        else:
            layout.addWidget(theme.muted_label("— đang rảnh —"))
        chips = QLabel(_counts_text(counts))
        chips.setObjectName("Faint12")
        chips.setWordWrap(True)
        layout.addWidget(chips)
        pct = node.get("percent")
        layout.addWidget(
            theme.muted_label(
                f"Tổng: {bar_text(pct, 8)}" if pct is not None else "Tổng: —"
            )
        )
        self.setCursor(Qt.PointingHandCursor)
        if expanded:
            self.setStyleSheet(f"border: 1px solid {theme.ACCENT};")

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.clicked.emit(self._agent_key)
        super().mousePressEvent(event)


def _node_key(node: dict) -> int:
    agent = node.get("agent")
    return int(agent["id"]) if agent else -1


def _iter_node_commands(node: dict):
    """Mọi lệnh trong một agent-node (hồ sơ → kênh + lệnh rời + loose)."""
    for command in node.get("loose_commands") or []:
        yield command, ""
    for profile_node in node.get("profiles") or []:
        profile = profile_node.get("profile") or {}
        scope = profile.get("label") or profile.get("slug") or ""
        for command in profile_node.get("commands") or []:
            yield command, scope
        for channel_node in profile_node.get("channels") or []:
            channel = channel_node.get("channel") or {}
            name = channel.get("name") or channel.get("channel_id") or ""
            context = f"{scope} · {name}" if scope else name
            for command in channel_node.get("commands") or []:
                yield command, context


def _first_current(node: dict) -> dict | None:
    best = None
    order = {"running": 0, "needs_user": 1, "waiting_muse": 2, "queued": 3}
    for command, _ctx in _iter_node_commands(node):
        rank = order.get(command.get("status"), 9)
        if rank < 9 and (best is None or rank < order.get(best.get("status"), 9)):
            best = command
    return best


class WorkPanel(QWidget):
    """Bảng việc (trên) + panel Lệnh công việc được truyền vào (dưới)."""

    command_chosen = Signal(str)
    # V5.0: "Mở trình duyệt của kênh" từ menu chuột phải của bảng
    # Theo Agent — MainWindow lo chuyển mục + mở trình duyệt.
    open_browser_requested = Signal(int)

    def __init__(self, store: Store, settings: dict, commands_panel: QWidget,
                 parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._commands_panel = commands_panel
        self._model: dict | None = None
        self._fingerprint: str | None = None
        self._filter_bucket = "all"
        self._expanded_agent_key: int | None = None
        self._tree_expanded: set = set()
        self._tree_expanded_ready = False
        self._last_refresh_str = ""
        self._cards_width_bucket: int | None = None
        self._highlight_command_id: str | None = None
        self._build_ui()
        self.refresh()
        self._timer = QTimer(self)
        self._timer.setInterval(4000)
        self._timer.timeout.connect(self.refresh)

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    # ------------------------------------------------------------------ #
    # Dựng giao diện
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        # QSS nền tối cho viewport của các QScrollArea trong panel.
        self._scroll_qss = (
            f"QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.BG}; }}"
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(10)

        # ----- Cột TRÁI "Giao việc": form + hàng đợi (cuộn riêng) --
        self.assign_scroll = QScrollArea()
        self.assign_scroll.setWidgetResizable(True)
        self.assign_scroll.setFrameShape(QFrame.NoFrame)
        self.assign_scroll.setStyleSheet(self._scroll_qss)
        assign_host = QWidget()
        assign_layout = QVBoxLayout(assign_host)
        assign_layout.setContentsMargins(0, 0, 6, 0)
        assign_layout.setSpacing(12)
        assign_layout.addWidget(self._commands_panel.form_card)
        # V6.3: BỎ "Hàng đợi lệnh" + "Danh sách lệnh" khỏi mặt hiển
        # thị — lệnh mới tự vào BẢNG VIỆC (Theo Agent) và bảng chi tiết
        # từng bước bên phải. Khối cũ vẫn sống (ẩn) vì panel Lệnh dùng
        # chung logic tạo/chọn lệnh.
        assign_layout.addWidget(self._commands_panel.queue_panel)
        self._commands_panel.queue_panel.hide()
        assign_layout.addStretch(1)
        self.assign_scroll.setWidget(assign_host)
        # V7.0.1: cột Giao việc KÉO RỘNG/HẸP được bằng thanh chia (bỏ trần
        # 470px làm cột bị che chữ); hẹp hơn nội dung thì hiện thanh cuộn
        # ngang thay vì cắt mất nút.
        self.assign_scroll.setMinimumWidth(300)
        self.assign_scroll.setMaximumWidth(16777215)
        self.assign_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        assign_host.setMinimumWidth(360)

        # ----- Cột PHẢI "Ai đang làm gì": dải tổng quan + điều
        # khiển GỘP MỘT HÀNG + 3 dạng xem. --------------------------
        self.board_widget = QWidget()
        board_layout = QVBoxLayout(self.board_widget)
        board_layout.setContentsMargins(0, 0, 0, 0)
        board_layout.setSpacing(10)

        # V5.3.1 (M1 — góp ý máy thật: khối đầu "quá nhiều dòng"):
        # TOÀN BỘ khối đầu (tiêu đề + đếm rút gọn + tìm kiếm + sắp
        # xếp + dạng xem + pill lọc) nằm trong MỘT FlowLayout —
        # hết bề rộng thì xuống dòng thay vì cắt chữ. Đo thật trên
        # fixture: ở 1920 và 1460 khối xếp đúng 2 dòng (dòng 1:
        # tiêu đề/đếm/tìm/sắp xếp/dạng xem; dòng 2: 6 pill lọc
        # kèm số); ở 1100 hẹp nó xuống thêm dòng, vẫn không cắt
        # chữ nút nào (luật giao diện thắng số dòng ở khổ hẹp).
        # Gộp LỌC vào PILL TRẠNG THÁI: pill mang sẵn số đếm, bấm
        # pill = lọc đúng trạng thái đó (trạng thái đang chọn nổi
        # bằng style :checked) — đủ 6 lựa chọn lọc như cũ (Tất cả
        # + 5 trạng thái), bỏ hàng "Lọc:" và dải pill nhãn riêng.
        header_flow = FlowLayout(h_spacing=8, v_spacing=6)
        self.header_flow = header_flow
        header_flow.addWidget(theme.section_header("🧑‍🤝‍🧑 Ai đang làm gì"))
        self.summary_label = QLabel("")
        self.summary_label.setObjectName("CardTitle")
        header_flow.addWidget(self.summary_label)

        self.search_edit = QLineEdit()
        # V5.3.1: placeholder RÚT NGẮN để không bị cắt đuôi khi ô
        # tìm kiếm nằm trong FlowLayout ở khổ cửa sổ vừa (luật
        # không cắt chữ áp cả cho chữ mờ trong ô nhập).
        self.search_edit.setPlaceholderText("🔍 Tìm agent / kênh / việc…")
        self.search_edit.setMinimumWidth(170)
        self.search_edit.textChanged.connect(lambda _t: self._render())
        header_flow.addWidget(self.search_edit)

        # Nhãn "Sắp xếp:" bỏ khỏi mặt hiển thị (chiếm 60px) —
        # nghĩa của ô chọn nằm trong tooltip + các mục chọn.
        self.sort_combo = QComboBox()
        self.sort_combo.setToolTip("Sắp xếp danh sách agent")
        for key, label in SORTS:
            self.sort_combo.addItem(label, key)
        current_sort = self._settings.get("work_sort") or "recent"
        index = self.sort_combo.findData(current_sort)
        if index >= 0:
            self.sort_combo.setCurrentIndex(index)
        self.sort_combo.currentIndexChanged.connect(self._on_sort_changed)
        header_flow.addWidget(self.sort_combo)

        self._view_group = QButtonGroup(self)
        self._view_group.setExclusive(True)
        self._view_buttons: dict[str, QPushButton] = {}
        for key, label in (
            (VIEW_KANBAN, "▥ Kanban"),
            (VIEW_LEDGER, "📒 Sổ giao việc"),
            (VIEW_AGENTS, "🧑‍🤝‍🧑 Theo Agent"),
            (VIEW_LIST, "☰ Danh sách"),
            (VIEW_CARDS, "▦ Ô"),
            (VIEW_TREE, "🌿 Nhánh"),
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.clicked.connect(lambda _c=False, k=key: self._set_view(k))
            self._view_group.addButton(button)
            self._view_buttons[key] = button
            header_flow.addWidget(button)

        # Pill lọc: "Tất cả" (state unknown/xám) + 5 pill trạng
        # thái — chính là summary_pills cũ nhưng BẤM ĐƯỢC: cùng
        # một nút vừa báo số đếm vừa là nút lọc (nhóm độc quyền
        # như nhóm Lọc cũ, qua _set_filter nguyên trạng).
        self._filter_group = QButtonGroup(self)
        self._filter_group.setExclusive(True)
        self._filter_buttons: dict[str, QPushButton] = {}
        self.summary_pills: dict[str, QPushButton] = {}
        pill_specs = (
            ("all", "Tất cả", "unknown"),
            ("running", "▶ Đang chạy", "run"),
            ("waiting", "⏳ Đang chờ", "paused"),
            ("needs_user", "✋ Cần xử lý", "user"),
            ("failed", "✕ Thất bại", "out"),
            ("done", "✓ Đã xong", "in"),
        )
        for key, label, state in pill_specs:
            button = QPushButton(f"{label} · 0")
            button.setObjectName("FilterPill")
            button.setProperty("state", state)
            button.setCheckable(True)
            button.clicked.connect(
                lambda _c=False, k=key: self._set_filter(k)
            )
            self._filter_group.addButton(button)
            self._filter_buttons[key] = button
            if key != "all":
                self.summary_pills[key] = button
            header_flow.addWidget(button)
        self._filter_buttons["all"].setChecked(True)
        board_layout.addLayout(header_flow)

        self.views = QStackedWidget()
        self.views.addWidget(self._build_list_view())    # 0
        self.views.addWidget(self._build_cards_view())   # 1
        self.views.addWidget(self._build_tree_view())    # 2
        # V5.0: bảng Theo Agent — view chính của mục Công việc.
        self.agent_board = AgentBoardWidget(
            self._store, self._store.db_file.parent
        )
        self.agent_board.commands_created.connect(
            lambda _n: self._force_refresh()
        )
        self.agent_board.data_changed.connect(self._force_refresh)
        self.agent_board.command_chosen.connect(self.command_chosen.emit)
        self.agent_board.open_browser_requested.connect(
            self.open_browser_requested.emit
        )
        self.views.addWidget(self.agent_board)           # 3
        # V6.5: KANBAN — dải KPI + 4 cột + panel chi tiết từng bước.
        from .kanban_view import KanbanView

        self.kanban = KanbanView(self._store, self._settings, self._commands_panel)
        self.kanban.command_chosen.connect(self.command_chosen.emit)
        self.kanban.browser_requested.connect(self.open_browser_requested.emit)
        self.views.addWidget(self.kanban)                # 4
        from .ledger_view import LedgerView

        self.ledger = LedgerView(self._store)
        self.ledger.command_chosen.connect(self._open_from_ledger)
        self.views.addWidget(self.ledger)                # 5
        board_layout.addWidget(self.views, 1)

        # Cột phải tự chia DỌC: bảng việc trên, bảng lệnh đầy đủ
        # (list_block) dưới — kéo thả được, không nhớ tỉ lệ riêng
        # (chiều cao theo cửa sổ là đủ).
        from .steps_table import StepsTable

        steps_host = QWidget()
        self.steps_host = steps_host
        steps_layout = QVBoxLayout(steps_host)
        steps_layout.setContentsMargins(0, 6, 0, 0)
        steps_layout.setSpacing(6)
        steps_head = QHBoxLayout()
        steps_head.addWidget(theme.section_header("📋 Bảng việc chi tiết từng bước"))
        hint = QLabel("Ctrl/Shift để chọn nhiều dòng · chuột phải: giao việc / xoá / chạy tiếp hàng loạt · rê chuột lên Trạng thái để biết kẹt gì")
        hint.setObjectName("Muted")
        steps_head.addWidget(hint, 1)
        steps_layout.addLayout(steps_head)
        self.steps_table = StepsTable(self._store, self._settings)
        self.steps_table.command_chosen.connect(self.command_chosen.emit)
        # V6.9: menu chuột phải + thao tác hàng loạt dùng đường chuẩn của
        # CommandsPanel (huỷ, chạy ngay, hỏi Muse, mở hồ sơ).
        self.steps_table.set_actions(self._commands_panel)
        self.steps_table.open_browser_requested.connect(self.open_browser_requested.emit)
        self.steps_selection_label = QLabel("")
        self.steps_selection_label.setStyleSheet(f"color: {theme.ACCENT}; font-weight: 600;")
        steps_head.addWidget(self.steps_selection_label)
        self.steps_table.selection_info.connect(self.steps_selection_label.setText)
        steps_layout.addWidget(self.steps_table, 1)

        self.right_splitter = QSplitter(Qt.Vertical)
        self.right_splitter.addWidget(self.board_widget)
        self.right_splitter.addWidget(steps_host)
        self.right_splitter.addWidget(self._commands_panel.list_block)
        self._commands_panel.list_block.hide()
        self.right_splitter.setStretchFactor(0, 1)
        self.right_splitter.setStretchFactor(1, 1)
        self.right_splitter.setSizes([520, 420, 0])

        # Splitter chính NGANG: trái Giao việc (~430px) — phải bảng
        # việc; hẹp <1200px lật DỌC (Giao việc trên). Khoá settings
        # MỚI (h2/v2): đảo cột so với V4.3.1, dùng lại tỉ lệ cũ sẽ
        # áp ngược bề rộng hai cột.
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.addWidget(self.assign_scroll)
        self.splitter.addWidget(self.right_splitter)
        # V7.0.1: thanh chia rõ ràng, dễ nắm để kéo (sáng lên khi rê chuột)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(8)
        self.splitter.setStyleSheet(
            "QSplitter::handle:horizontal { background: transparent; margin: 40px 2px;"
            f" border-left: 1px dashed {theme.BORDER}; }}"
            "QSplitter::handle:horizontal:hover { background: rgba(206, 252, 25, 0.25); border-radius: 3px; }"
            "QSplitter::handle:vertical { background: transparent; }"
            "QSplitter::handle:vertical:hover { background: rgba(206, 252, 25, 0.25); }")
        self.splitter.handle(1).setToolTip("Kéo để đổi bề rộng cột Tạo lệnh ↔ Ai đang làm gì")
        self.right_splitter.setMinimumWidth(520)
        saved_h = self._settings.get("work_split_h2")
        if (
            isinstance(saved_h, list) and len(saved_h) == 2
            and all(isinstance(v, int) and v > 0 for v in saved_h)
        ):
            self.splitter.setSizes(saved_h)
        else:
            self.splitter.setSizes([430, 1000])
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.splitterMoved.connect(self._on_splitter_moved)
        root.addWidget(self.splitter, 1)

        # V5.0: lần đầu chạy bản này → view chính là Theo Agent (đánh
        # dấu một lần; sau đó tôn trọng lựa chọn đã lưu của người dùng).
        if not self._settings.get("work_view_v65_seen"):
            # V6.5: lần đầu chạy bản này → mở thẳng bảng Kanban mới.
            self._settings["work_view_v50_seen"] = True
            self._settings["work_view_v65_seen"] = True
            config.save_settings(self._settings)
            mode = VIEW_KANBAN
        else:
            mode = self._settings.get("work_view_mode") or VIEW_LIST
        self._set_view(
            mode
            if mode in (VIEW_LIST, VIEW_CARDS, VIEW_TREE, VIEW_AGENTS, VIEW_KANBAN, VIEW_LEDGER)
            else VIEW_KANBAN
        )


    # ---- Dạng Danh sách ------------------------------------------------ #
    def _build_list_view(self) -> QWidget:
        self.list_tree = QTreeWidget()
        # APP_QSS chưa có luật cho QTreeWidget — không đặt nền/chữ ở
        # đây thì cây rơi về palette trắng mặc định, chữ sáng trên nền
        # trắng không đọc được (đã thấy ở ảnh xem trước offscreen).
        self.list_tree.setStyleSheet(
            f"QTreeWidget {{ background: {theme.BG}; color: {theme.TEXT};"
            f" border: 1px solid {theme.BORDER}; }}"
            f"QTreeWidget::item {{ padding: 3px 2px;"
            f" border-bottom: 1px solid {theme.BORDER}; }}"
            f"QTreeWidget::item:selected {{ background: {theme.CARD}; }}"
            f"QHeaderView::section {{ background: {theme.PANEL};"
            f" color: {theme.MUTED}; border: none; padding: 5px 8px; }}"
        )
        self.list_tree.setColumnCount(4)
        self.list_tree.setHeaderLabels(["Việc / Agent", "Tiến độ", "Trạng thái", "Bước hiện tại"])
        # V4.3.2 (F7): cột cây việc cũng kéo chỉnh tự do + tự lưu.
        from . import table_persist

        table_persist.attach_column_persistence(
            self.list_tree, self._settings, "work_list_tree",
            default_widths=(380, 170, 130, 320),
        )
        self.list_tree.itemClicked.connect(self._on_item_clicked)
        return self.list_tree

    # ---- Dạng Ô -------------------------------------------------------- #
    def _build_cards_view(self) -> QWidget:
        self.cards_scroll = QScrollArea()
        self.cards_scroll.setWidgetResizable(True)
        self.cards_scroll.setStyleSheet(self._scroll_qss)
        self.cards_host = QWidget()
        self.cards_layout = QGridLayout(self.cards_host)
        self.cards_layout.setSpacing(10)
        self.cards_scroll.setWidget(self.cards_host)
        return self.cards_scroll

    # ---- Dạng Nhánh ---------------------------------------------------- #
    def _build_tree_view(self) -> QWidget:
        host = QWidget()
        layout = QVBoxLayout(host)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        bar = QHBoxLayout()
        self.tree_expand_button = QPushButton("🌿 Mở nhánh đang hoạt động")
        self.tree_expand_button.clicked.connect(self._expand_active_branches)
        bar.addWidget(self.tree_expand_button)
        bar.addWidget(theme.muted_label("Thu/phóng:"))
        self.tree_zoom = QSlider(Qt.Horizontal)
        self.tree_zoom.setRange(40, 160)
        self.tree_zoom.setValue(100)
        self.tree_zoom.setMaximumWidth(180)
        self.tree_zoom.valueChanged.connect(self._on_tree_zoom)
        bar.addWidget(self.tree_zoom)
        self.tree_fit_button = QPushButton("⤢ Vừa khung")
        self.tree_fit_button.clicked.connect(self._fit_tree)
        bar.addWidget(self.tree_fit_button)
        bar.addStretch(1)
        # V5.3 (A6): nhãn hướng dẫn thao tác cuối thanh đã BỎ.
        layout.addLayout(bar)
        self.tree_scene = QGraphicsScene(self)
        self.tree_view = QGraphicsView(self.tree_scene)
        # V4.3.1: cây Nhánh nằm trong cột trái hẹp — cuộn ngang
        # trong chính cột của nó khi sơ đồ rộng hơn khung.
        self.tree_view.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tree_view.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.tree_view.setRenderHint(QPainter.Antialiasing)
        self.tree_view.setBackgroundBrush(QBrush(QColor(theme.BG)))
        self.tree_view.mousePressEvent = self._on_tree_click
        layout.addWidget(self.tree_view, 1)
        return host

    # ------------------------------------------------------------------ #
    # Điều khiển xem/lọc
    # ------------------------------------------------------------------ #
    def _set_view(self, mode: str):
        self._view_mode = mode
        self._settings["work_view_mode"] = mode
        config.save_settings(self._settings)
        for key, button in self._view_buttons.items():
            button.setChecked(key == mode)
        self.views.setCurrentIndex(
            {VIEW_LIST: 0, VIEW_CARDS: 1, VIEW_TREE: 2, VIEW_AGENTS: 3, VIEW_KANBAN: 4, VIEW_LEDGER: 5}[mode]
        )
        # V6.5: Kanban có dải KPI, ô tìm và panel chi tiết riêng → ẩn
        # pill lọc/ô tìm/sắp xếp và bảng bước bên dưới cho gọn.
        kanban = mode in (VIEW_KANBAN, VIEW_LEDGER)
        for widget in [self.search_edit, self.sort_combo, self.summary_label, *self._filter_buttons.values()]:
            widget.setVisible(not kanban)
        if hasattr(self, "steps_host"):
            self.steps_host.setVisible(not kanban)
        self._render()

    def _set_filter(self, bucket: str):
        self._filter_bucket = bucket
        self._render()

    def _on_sort_changed(self):
        self._settings["work_sort"] = self.sort_combo.currentData()
        config.save_settings(self._settings)
        self._render()

    def _on_item_clicked(self, item: QTreeWidgetItem, _column: int):
        command_id = item.data(0, Qt.ItemDataRole.UserRole)
        if command_id:
            self.command_chosen.emit(str(command_id))

    def _open_from_ledger(self, command_id: str):
        """Sổ giao việc → mở việc đó ở Kanban (chi tiết + dòng thời gian)."""
        self._set_view(VIEW_KANBAN)
        self.kanban.select(str(command_id))
        self.command_chosen.emit(str(command_id))

    def highlight_command(self, command_id: str):
        """V4.5: làm nổi bật một lệnh trên bảng việc (chọn từ Hàng
        đợi lệnh ở cột Giao việc): dạng Ô viền nhấn thẻ, dạng Danh
        sách chọn đúng dòng con."""
        self._highlight_command_id = str(command_id)
        if hasattr(self, "kanban") and self.kanban._selected != str(command_id):
            self.kanban.select(str(command_id))
        self._render()

    # ------------------------------------------------------------------ #
    # Splitter hai cột: ngang khi đủ rộng, dọc khi hẹp
    # ------------------------------------------------------------------ #
    SPLIT_STACK_WIDTH = 1200  # panel hẹp hơn ngưỡng này → xếp dọc

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._apply_split_orientation(self.width())
        if getattr(self, "_view_mode", None) == VIEW_CARDS:
            bucket = self.width() // 100
            if bucket != self._cards_width_bucket:
                self._cards_width_bucket = bucket
                self._render_cards()

    def _apply_split_orientation(self, width: int):
        """Đủ rộng (≥1200px) → splitter NGANG hai cột; hẹp hơn →
        lật DỌC (Giao việc trên, Ai đang làm gì dưới). Cỡ từng
        hướng được lưu riêng trong settings (khoá h2/v2) và khôi
        phục khi lật qua lại."""
        if not hasattr(self, "splitter"):
            return
        horizontal = width >= self.SPLIT_STACK_WIDTH
        orientation = Qt.Horizontal if horizontal else Qt.Vertical
        if self.splitter.orientation() == orientation:
            return
        self._save_split_sizes()
        self.splitter.setOrientation(orientation)
        saved = self._settings.get(
            "work_split_h2" if horizontal else "work_split_v2"
        )
        if (
            isinstance(saved, list) and len(saved) == 2
            and all(isinstance(v, int) and v > 0 for v in saved)
        ):
            self.splitter.setSizes(saved)
        else:
            self.splitter.setSizes([430, 1000] if horizontal else [620, 480])

    def _on_splitter_moved(self, *_args):
        self._save_split_sizes()

    def _save_split_sizes(self):
        if not hasattr(self, "splitter"):
            return
        key = (
            "work_split_h2"
            if self.splitter.orientation() == Qt.Horizontal
            else "work_split_v2"
        )
        self._settings[key] = self.splitter.sizes()
        config.save_settings(self._settings)

    # ------------------------------------------------------------------ #
    # Dữ liệu
    # ------------------------------------------------------------------ #
    def refresh(self):
        self._last_refresh_str = datetime.now().strftime("%H:%M:%S")
        # V4.5: form/hàng đợi/bảng lệnh sống trong các khối con của
        # CommandsPanel (đã tách sang hai cột) — làm mới cùng nhịp
        # tại đây (bên trong panel có chữ ký dữ liệu chống dựng lại).
        try:
            self._commands_panel.refresh()
        except Exception:
            pass
        # V6.3: bảng chi tiết từng bước (có vân riêng, không dựng lại thừa).
        try:
            self.steps_table.refresh()
        except Exception:
            pass
        # V5.2 (hiệu năng §15): tính VÂN bằng truy vấn NHẸ trước (chỉ
        # các cột vân cần) — vân không đổi thì dừng tại đây, KHÔNG
        # nạp SELECT * 500 lệnh + parse JSON như trước. Vân đổi mới
        # nạp bản đầy đủ để dựng mô hình.
        try:
            light_fp = work_model.work_fingerprint(
                self._store.list_commands_light(limit=500),
                self._store.list_agents_light(),
            )
        except Exception:
            light_fp = None
        if (
            light_fp is not None
            and light_fp == self._fingerprint
            and self._model is not None
        ):
            return
        try:
            agents = self._store.list_agents()
            profiles = self._store.list_profiles()
            channels_by_profile = {
                p["id"]: self._store.list_channels(p["id"]) for p in profiles
            }
            commands = self._store.list_commands(limit=500)
        except Exception:
            return
        fingerprint = work_model.work_fingerprint(commands, agents)
        if fingerprint == self._fingerprint and self._model is not None:
            return
        self._fingerprint = fingerprint
        self._model = work_model.build_work_model(
            commands, agents, profiles, channels_by_profile
        )
        if not self._tree_expanded_ready:
            self._expand_active_branches()
            self._tree_expanded_ready = True
        self._render()

    def _force_refresh(self):
        """Làm mới bỏ qua chữ ký dữ liệu (dùng khi đổi trạng thái
        ngoài work model — vd cờ tạm dừng hồ sơ từ bảng Theo Agent)."""
        self._fingerprint = None
        self.refresh()

    def _visible_nodes(self) -> list[dict]:
        """Agent-node sau khi áp tìm kiếm + lọc trạng thái + sắp xếp."""
        if not self._model:
            return []
        query = (self.search_edit.text() or "").strip().casefold()
        bucket = self._filter_bucket
        nodes = []
        for node in self._model.get("agents") or []:
            commands = list(_iter_node_commands(node))
            if bucket != "all":
                commands = [
                    (c, ctx) for c, ctx in commands
                    if _STATUS_BUCKET.get(c.get("status")) == bucket
                ]
                if not commands:
                    continue
            if query:
                agent = node.get("agent") or {}
                haystacks = [
                    str(agent.get("name") or ""), str(agent.get("email") or ""),
                ]
                matched = any(query in h.casefold() for h in haystacks)
                if not matched:
                    matched = any(
                        query in str(c.get("instruction") or "").casefold()
                        or query in COMMAND_TYPE_LABELS.get(c.get("type"), "").casefold()
                        or query in str(ctx).casefold()
                        for c, ctx in commands
                    )
                if not matched:
                    continue
            nodes.append(node)
        sort_key = self.sort_combo.currentData() or "recent"
        if sort_key == "name":
            nodes.sort(key=lambda n: _agent_title(n.get("agent")).casefold())
        elif sort_key == "percent":
            nodes.sort(key=lambda n: -(n.get("percent") or -1))
        else:  # recent: agent có lệnh cập nhật gần nhất lên trước
            def _latest(node):
                stamps = [
                    str(c.get("updated_at") or c.get("created_at") or "")
                    for c, _ctx in _iter_node_commands(node)
                ]
                return max(stamps) if stamps else ""

            nodes.sort(key=_latest, reverse=True)
        return nodes

    def _render(self):
        if self._model is None:
            return
        summary = self._model.get("summary") or {}
        counts = summary.get("counts") or {}
        percent = summary.get("percent")
        # V5.3.1 (M1): dòng đếm RÚT GỌN — số theo trạng thái đã
        # nằm trên chính các pill lọc bên dưới; ở đây chỉ còn số
        # agent + tiến độ chung để khối đầu gọn 1–2 dòng.
        self.summary_label.setText(
            f"🤖 {summary.get('agent_count', 0)} Muse · "
            + (f"📊 chung {percent}%" if percent is not None else "📊 —")
        )
        pill_texts = {
            "running": f"▶ Đang chạy · {counts.get('running', 0)}",
            "waiting": f"⏳ Đang chờ · {counts.get('waiting', 0)}",
            "needs_user": f"✋ Cần xử lý · {counts.get('needs_user', 0)}",
            "failed": f"✕ Thất bại · {counts.get('failed', 0)}",
            "done": f"✓ Đã xong · {counts.get('done', 0)}",
        }
        for key, pill in self.summary_pills.items():
            pill.setText(pill_texts[key])
        self._update_pill_tooltips()
        total = sum(int(counts.get(key, 0)) for key in pill_texts)
        self._filter_buttons["all"].setText(f"Tất cả · {total}")
        if self._view_mode == VIEW_LIST:
            self._render_list()
        elif self._view_mode == VIEW_CARDS:
            self._render_cards()
        elif self._view_mode == VIEW_AGENTS:
            self.agent_board.set_model(self._model)
        else:
            self._render_tree()

    def _update_pill_tooltips(self):
        """V6.9: rê chuột lên pill trạng thái → popup từng việc + lý do."""
        from .. import command_actions
        from .work_model import STATUS_BUCKETS

        groups: dict[str, list[str]] = {}
        seen = set()
        for node in (self._model or {}).get("agents") or []:
            for command, _ctx in _iter_node_commands(node):
                cid = command.get("id")
                if not cid or cid in seen:
                    continue
                seen.add(cid)
                bucket = STATUS_BUCKETS.get(command.get("status"))
                if bucket:
                    groups.setdefault(bucket, []).append(str(cid))
        titles = {"running": "Đang chạy", "waiting": "Đang chờ", "needs_user": "Cần xử lý",
                  "failed": "Thất bại", "done": "Đã xong"}
        for key, pill in self.summary_pills.items():
            ids = groups.get(key) or []
            # Tạo popup LÚC RÊ CHUỘT (lazy) — không tốn truy vấn mỗi nhịp làm mới.
            command_actions.attach_lazy_tooltip(
                pill, lambda k=key, i=tuple(ids): command_actions.group_html(self._store, titles.get(k, k), i))

    # ------------------------------------------------------------------ #
    # Vẽ — Danh sách
    # ------------------------------------------------------------------ #
    def _render_list(self):
        tree = self.list_tree
        tree.setUpdatesEnabled(False)
        try:
            tree.clear()
            for node in self._visible_nodes():
                counts = node.get("counts") or {}
                pct = node.get("percent")
                top = QTreeWidgetItem(
                    [
                        f"{_agent_title(node.get('agent'))} — {_counts_text(counts)}",
                        bar_text(pct) if pct is not None else "—",
                        "",
                        "",
                    ]
                )
                top.setFont(0, QFont("", -1, QFont.Bold))
                tree.addTopLevelItem(top)
                for command, context in _iter_node_commands(node):
                    label = COMMAND_TYPE_LABELS.get(
                        command.get("type"), command.get("type") or ""
                    )
                    if context:
                        label += f" · {context}"
                    child = QTreeWidgetItem(
                        [
                            label,
                            bar_text(work_model.command_percent(command)),
                            STATUS_LABELS.get(
                                command.get("status"), command.get("status") or ""
                            ),
                            command.get("step") or "",
                        ]
                    )
                    # V4.3.1: cột Trạng thái nhuộm màu theo nhóm
                    # trạng thái (cùng ngôn ngữ màu với thẻ Ô và
                    # bảng lệnh) — item chữ thuần, không widget con.
                    bucket = _STATUS_BUCKET.get(command.get("status"), "waiting")
                    child.setForeground(
                        2, QBrush(QColor(_BUCKET_COLORS.get(bucket, theme.MUTED)))
                    )
                    child.setData(0, Qt.ItemDataRole.UserRole, command.get("id"))
                    child.setToolTip(0, (command.get("instruction") or "")[:300])
                    top.addChild(child)
                    if str(command.get("id")) == self._highlight_command_id:
                        tree.setCurrentItem(child)
                top.setExpanded(True)
        finally:
            tree.setUpdatesEnabled(True)

    # ------------------------------------------------------------------ #
    # Vẽ — Ô
    # ------------------------------------------------------------------ #
    def _clear_cards(self):
        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                # V4.3.2: ẩn + gỡ parent NGAY rồi mới deleteLater —
                # chỉ deleteLater thì thẻ cũ còn vẽ chồng lên thẻ
                # mới khi đổi dạng/dữ liệu liên tiếp (deleteLater chỉ
                # xử lý khi vòng lặp sự kiện rảnh tay).
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()

    def _cards_columns(self, full_all: bool) -> int:
        """Số cột thẻ theo bề rộng THẬT của vùng cuộn (V4.3.1): cột
        trái hẹp (bố cục 2 cột) thì thẻ agent xếp dọc TỪNG cột một,
        không ép hai cột thẻ cạnh nhau khi không đủ rộng; cửa sổ đủ
        rộng mới trải 2–3 cột. Ô gọn (nhiều agent) dùng ngưỡng nhỏ
        hơn vì ô vốn hẹp."""
        try:
            width = self.cards_scroll.viewport().width()
        except Exception:
            width = 0
        if full_all:
            if width <= 0:
                return 3
            return max(1, min(3, width // 400))
        if width <= 0:
            return 4
        return max(1, min(6, width // 250))

    def _render_cards(self):
        self._clear_cards()
        nodes = self._visible_nodes()
        full_all = len(nodes) <= CARDS_FULL_LIMIT
        columns = self._cards_columns(full_all)
        row = col = 0
        for node in nodes:
            key = _node_key(node)
            expanded = full_all or self._expanded_agent_key == key
            if expanded:
                widget = self._agent_column(node)
            else:
                widget = _AgentTile(node, expanded=False)
                widget.clicked.connect(self._toggle_tile)
            self.cards_layout.addWidget(widget, row, col)
            col += 1
            if col >= columns:
                col = 0
                row += 1
        # Chiều cao tối thiểu của host = chiều cao tự nhiên của
        # lưới: thiếu chỗ thì vùng cuộn CUỘN thay vì ép các thẻ
        # (và pill trong thẻ) dẹt xuống dưới sizeHint — ảnh xem
        # trước V4.3.1 bắt được pill bị nén còn ~14px khi hai cột
        # agent chồng nhau trong cột trái hẹp.
        self.cards_host.setMinimumHeight(
            self.cards_layout.sizeHint().height()
        )

    def _toggle_tile(self, key: int):
        self._expanded_agent_key = None if self._expanded_agent_key == key else key
        self._render_cards()

    def _agent_column(self, node: dict) -> QFrame:
        frame = QFrame()
        frame.setObjectName("Card")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)
        # V4.3.1 (Concept D): dòng "Updated • giờ • Auto-refresh ON"
        # ở góc trên-phải của thẻ agent — giờ là lần làm mới dữ
        # liệu gần nhất của bảng việc, tự làm mới đang bật theo
        # nhịp của panel khi mục đang hiện.
        if self._last_refresh_str:
            updated = QLabel(
                f"Updated • {self._last_refresh_str} • Auto-refresh ON"
            )
            updated.setObjectName("Faint12")
            updated.setAlignment(Qt.AlignRight)
            layout.addWidget(updated)
        agent = node.get("agent")
        head = QHBoxLayout()
        head.setSpacing(8)
        seed = str((agent or {}).get("email") or (agent or {}).get("name") or "?")
        head.addWidget(theme.avatar("🤖", seed, 34))
        title = QLabel(_agent_name(agent))
        title.setObjectName("CardTitle")
        title.setWordWrap(True)
        head.addWidget(title, 1)
        head.addWidget(_agent_pill(node))
        layout.addLayout(head)
        counts = node.get("counts") or {}
        chips = QLabel(_counts_text(counts))
        chips.setObjectName("Faint12")
        chips.setWordWrap(True)
        layout.addWidget(chips)
        commands = list(_iter_node_commands(node))
        if not commands:
            layout.addWidget(theme.muted_label("— đang rảnh —"))
        for command, context in commands[:CARD_COMMAND_LIMIT]:
            card = _CommandCard(
                command, context,
                highlighted=str(command.get("id")) == self._highlight_command_id,
            )
            card.clicked.connect(self.command_chosen.emit)
            layout.addWidget(card)
        if len(commands) > CARD_COMMAND_LIMIT:
            layout.addWidget(
                theme.muted_label(f"… và {len(commands) - CARD_COMMAND_LIMIT} việc nữa (xem dạng Danh sách)")
            )
        layout.addStretch(1)
        return frame

    # ------------------------------------------------------------------ #
    # Vẽ — Nhánh (cây đồ hoạ)
    # ------------------------------------------------------------------ #
    def _expand_active_branches(self):
        """Mở sẵn toàn bộ đường nhánh tới lệnh running / needs_user
        (agent → hồ sơ → kênh), để mở tab là thấy ngay việc đang chạy."""
        if not self._model:
            return

        def _active(counts) -> bool:
            counts = counts or {}
            return bool(counts.get("running") or counts.get("needs_user"))

        for node in self._model.get("agents") or []:
            if not _active(node.get("counts")):
                continue
            key = _node_key(node)
            self._tree_expanded.add(("agent", key))
            for profile_node in node.get("profiles") or []:
                if not _active(profile_node.get("counts")):
                    continue
                profile = profile_node.get("profile") or {}
                pkey = (key, profile.get("id"))
                self._tree_expanded.add(("profile", pkey))
                for channel_node in profile_node.get("channels") or []:
                    if _active(channel_node.get("counts")):
                        channel = channel_node.get("channel") or {}
                        self._tree_expanded.add(
                            ("channel", (pkey, channel.get("channel_id")))
                        )

    def _on_tree_zoom(self, value: int):
        self.tree_view.resetTransform()
        self.tree_view.scale(value / 100.0, value / 100.0)

    def _fit_tree(self):
        rect = self.tree_scene.itemsBoundingRect()
        if not rect.isNull():
            self.tree_view.fitInView(rect, Qt.KeepAspectRatio)

    def _on_tree_click(self, event):
        if event.button() == Qt.LeftButton:
            item = self.tree_scene.itemAt(
                self.tree_view.mapToScene(event.pos()), self.tree_view.transform()
            )
            while item is not None:
                kind = item.data(0)
                key = item.data(1)
                if kind == "command" and key:
                    self.command_chosen.emit(str(key))
                    break
                if kind in ("agent", "profile", "channel"):
                    marker = (kind, key)
                    if marker in self._tree_expanded:
                        self._tree_expanded.discard(marker)
                    else:
                        self._tree_expanded.add(marker)
                    self._render_tree()
                    break
                item = item.parentItem()
        QGraphicsView.mousePressEvent(self.tree_view, event)

    def _tree_node(self, x, y, w, h, title, sub, pct, kind, key, color):
        from PySide6.QtWidgets import QGraphicsRectItem

        rect = QGraphicsRectItem(x, y, w, h)
        rect.setBrush(QBrush(QColor(theme.CARD)))
        rect.setPen(QPen(QColor(color), 1.6))
        rect.setData(0, kind)
        rect.setData(1, key)
        self.tree_scene.addItem(rect)
        text = QGraphicsTextItem()
        text.setDefaultTextColor(QColor(theme.TEXT))
        text.setFont(QFont("Segoe UI", 8.5))
        pct_line = bar_text(pct, 8) if pct is not None else "—"
        limit = max(10, int((w - 16) / 5.4))
        title = title if len(title) <= limit else title[: limit - 1] + "…"
        sub = sub if len(sub) <= limit else sub[: limit - 1] + "…"
        text.setPlainText(f"{title}\n{sub}\n{pct_line}")
        text.setPos(x + 8, y + 5)
        text.setData(0, kind)
        text.setData(1, key)
        self.tree_scene.addItem(text)
        return y + h

    def _render_tree(self):
        self.tree_scene.clear()
        nodes = self._visible_nodes()
        y = 10.0
        agent_w, profile_w, channel_w, cmd_w = 210, 200, 190, 260
        node_h, gap = 74, 14
        for node in nodes:
            key = _node_key(node)
            counts = node.get("counts") or {}
            color = theme.ACCENT
            if counts.get("needs_user"):
                color = _BUCKET_COLORS["needs_user"]
            elif counts.get("running"):
                color = _BUCKET_COLORS["running"]
            agent_bottom = self._tree_node(
                10, y, agent_w, node_h,
                _agent_title(node.get("agent")), _counts_text(counts),
                node.get("percent"), "agent", key, color,
            )
            subtree_bottom = agent_bottom
            if ("agent", key) in self._tree_expanded:
                py = y
                for profile_node in node.get("profiles") or []:
                    profile = profile_node.get("profile") or {}
                    pkey = (key, profile.get("id"))
                    ptitle = profile.get("label") or profile.get("slug") or "Hồ sơ"
                    p_bottom = self._tree_node(
                        260, py, profile_w, node_h,
                        f"👤 {ptitle}", _counts_text(profile_node.get("counts") or {}),
                        profile_node.get("percent"), "profile", pkey, theme.MUTED,
                    )
                    self._tree_line(10 + agent_w, y + node_h / 2, 260, py + node_h / 2)
                    cy = py
                    if ("profile", pkey) in self._tree_expanded:
                        for channel_node in profile_node.get("channels") or []:
                            channel = channel_node.get("channel") or {}
                            ckey = (pkey, channel.get("channel_id"))
                            c_bottom = self._tree_node(
                                500, cy, channel_w, node_h,
                                f"📺 {channel.get('name') or channel.get('channel_id')}",
                                _counts_text(channel_node.get("counts") or {}),
                                channel_node.get("percent"), "channel", ckey,
                                theme.MUTED,
                            )
                            self._tree_line(
                                260 + profile_w, py + node_h / 2, 500, cy + node_h / 2
                            )
                            ly = cy
                            if ("channel", ckey) in self._tree_expanded:
                                for command in channel_node.get("commands") or []:
                                    ly = self._tree_command(730, ly, cmd_w, command)
                                cy = max(c_bottom, ly)
                            else:
                                cy = c_bottom
                            cy += gap
                        for command in profile_node.get("commands") or []:
                            cy = self._tree_command(500, cy, channel_w + 60, command)
                            cy += gap
                    subtree_bottom = max(subtree_bottom, cy)
                    py = max(p_bottom, cy) + gap
                for command in node.get("loose_commands") or []:
                    ly = self._tree_command(260, py, profile_w + 60, command)
                    py = ly + gap
                    subtree_bottom = max(subtree_bottom, py)
                y = max(agent_bottom, subtree_bottom) + gap * 1.5
            else:
                y = agent_bottom + gap * 1.5
        self.tree_scene.setSceneRect(self.tree_scene.itemsBoundingRect())

    def _tree_line(self, x1, y1, x2, y2):
        from PySide6.QtWidgets import QGraphicsLineItem

        line = QGraphicsLineItem(x1, y1, x2, y2)
        line.setPen(QPen(QColor(theme.BORDER), 1.2))
        self.tree_scene.addItem(line)

    def _tree_command(self, x, y, w, command: dict) -> float:
        bucket = _STATUS_BUCKET.get(command.get("status"), "waiting")
        color = _BUCKET_COLORS.get(bucket, theme.MUTED)
        label = COMMAND_TYPE_LABELS.get(command.get("type"), command.get("type") or "")
        status = STATUS_LABELS.get(command.get("status"), command.get("status") or "")
        bottom = self._tree_node(
            x, y, w, 60,
            f"• {label}", status, work_model.command_percent(command),
            "command", command.get("id"), color,
        )
        return bottom
