"""Tường trình duyệt nhúng.

Khi NHIỀU trình duyệt hồ sơ đang chạy, các khung Chrome nhúng TỰ
SẮP XẾP ngay trong app thay vì chỉ xem được một khung:

- V5.3 (lệnh MỚI NHẤT của chủ kênh 2026-10-30 18:10 — THAY quy
  cách một cột dọc V5.2): mỗi ô CỐ ĐỊNH 600×800px (kích thước
  hiển thị), tối đa 3 ô mỗi hàng, thừa thì xuống hàng mới, vùng
  tường cuộn dọc; thứ tự ô cố định theo id hồ sơ tăng dần. Ô
  600×800 giữ tỉ lệ dọc kiểu cửa sổ trình duyệt độc lập — đọc
  trang web thoải mái hơn hẳn ô ngang thấp của các bản trước.
- Mỗi ô: thanh tiêu đề gọn (tên hồ sơ + kênh chính + pill trạng
  thái đăng nhập + nút ⛶ phóng to về khung đơn) và MỘT
  docking.BrowserDock riêng nhúng cửa sổ Chrome của hồ sơ đó
  (Win32 SetParent vào ô chứa native của ô) — cùng cơ chế với
  khung đơn ở MainWindow, nhân lên nhiều ô.
- Chế độ CHẠY ẨN (V5.3, mục A8 — ngoại lệ do chủ kênh trực tiếp
  ra lệnh cho quy tắc chỉ-nhúng): khi bật, tường KHÔNG nhúng —
  các ô hiện trạng thái "đang chạy ẩn ngoài app" và trình duyệt
  sống ở cửa sổ riêng/thu nhỏ, điều khiển qua CDP như thường.
- Ngoài Windows (môi trường kiểm thử/offscreen): ô hiện khung giữ
  chỗ; việc nhúng thật chỉ chạy trên Windows như khung đơn.
"""

from __future__ import annotations

from PySide6.QtCore import QPoint, Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QButtonGroup,
    QComboBox,
    QFrame,
    QSlider,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from PySide6.QtGui import QFontMetrics

from .. import docking
from . import theme

#: Quy cách ô tường V5.3 (lệnh chủ kênh 2026-10-30 18:10): ô CỐ
#: ĐỊNH 600×800px, tối đa 3 ô/hàng. TILE_HOST_HEIGHT = 800 trừ
#: lề dọc của ô (8+10) trừ thanh tiêu đề (32) trừ khoảng cách (6).
#: V5.3.1 (M2): 600×800 chỉ còn là MẶC ĐỊNH — kích thước hiệu lực
#: đọc từ settings (wall_tile_width/wall_tile_height, người dùng
#: chỉnh trong Cài đặt → Giao diện) qua tile_size() dưới đây.
TILE_WIDTH = 600
TILE_HEIGHT = 800
MAX_COLUMNS = 6
TILE_SPACING = 12
_TILE_HEADER_HEIGHT = 32
TILE_HOST_HEIGHT = TILE_HEIGHT - 8 - 10 - 6 - _TILE_HEADER_HEIGHT

#: Dải chặn kích thước ô người dùng chỉnh được (M2): đủ nhỏ để
#: tường vẫn là tường xem nhanh, đủ lớn để trang web đọc được.
TILE_WIDTH_MIN, TILE_WIDTH_MAX = 320, 1200
TILE_HEIGHT_MIN, TILE_HEIGHT_MAX = 240, 1200


def tile_host_height(tile_height: int) -> int:
    """Chiều cao khung nhúng trong ô theo chiều cao ô: trừ lề
    dọc của ô (8+10) trừ thanh tiêu đề (32) trừ khoảng cách (6)."""
    return max(40, int(tile_height) - 8 - 10 - 6 - _TILE_HEADER_HEIGHT)


def tile_size(settings) -> tuple[int, int]:
    """Kích thước ô tường HIỆU LỰC (rộng, cao) từ settings —
    None/thiếu khoá → mặc định V5.3 600×800; ngoài dải → kẹp."""
    def _clamp(raw, default, low, high):
        try:
            value = int(raw)
        except (TypeError, ValueError):
            value = default
        return max(low, min(high, value))

    settings = settings or {}
    return (
        _clamp(settings.get("wall_tile_width"), TILE_WIDTH,
               TILE_WIDTH_MIN, TILE_WIDTH_MAX),
        _clamp(settings.get("wall_tile_height"), TILE_HEIGHT,
               TILE_HEIGHT_MIN, TILE_HEIGHT_MAX),
    )


def wall_columns(viewport_width: int, tile_width: int = TILE_WIDTH) -> int:
    """Số cột của tường theo bề rộng vùng cuộn: bao nhiêu ô
    `tile_width`px vừa một hàng, chặn trần 3 ô/hàng (V5.3), ít
    nhất 1. (V5.3.1: bề rộng ô là tham số — mặc định 600 như cũ.)"""
    if viewport_width <= 0:
        return 1
    fit = (int(viewport_width) + TILE_SPACING) // (int(tile_width) + TILE_SPACING)
    return max(1, min(3, int(fit)))


class _TileHost(QWidget):
    """Ổ cắm native cho cửa sổ Chrome của MỘT ô (như DockContainer)."""

    resized = Signal(int, int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WA_NativeWindow, True)
        self.setStyleSheet("background:#060706;")

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.resized.emit(self.width(), self.height())


class _ResizeGrip(QLabel):
    """V6.3: tay kéo góc dưới-phải của ô — kéo một ô là ĐỔI ĐỒNG THỜI
    kích thước mọi ô trong tường (tường phát resize_requested)."""

    dragged = Signal(int, int)
    released = Signal()

    def __init__(self, tile):
        super().__init__("◢", tile)
        self._tile = tile
        self._origin: QPoint | None = None
        self._start = (0, 0)
        self.setCursor(Qt.SizeFDiagCursor)
        self.setFixedSize(16, 16)
        self.setStyleSheet(f"color:{theme.MUTED}; font-size:12px;")
        self.setToolTip("Kéo để đổi kích thước TẤT CẢ ô cùng lúc")

    def mousePressEvent(self, event):
        self._origin = event.globalPosition().toPoint()
        self._start = (self._tile.width(), self._tile.height())

    def mouseMoveEvent(self, event):
        if self._origin is None:
            return
        delta = event.globalPosition().toPoint() - self._origin
        self.dragged.emit(self._start[0] + delta.x(), self._start[1] + delta.y())

    def mouseReleaseEvent(self, event):
        self._origin = None
        self.released.emit()


_LOGIN_PILLS = {
    "in": ("● Đã đăng nhập", "in"),
    "out": ("● Chưa đăng nhập", "out"),
    "unknown": ("● Chưa rõ", "unknown"),
}


class BrowserTile(QFrame):
    """Một ô trình duyệt trong tường: tiêu đề gọn + khung nhúng.
    Kích thước CỐ ĐỊNH theo tile_size hiệu lực (mặc định 600×800
    của V5.3; V5.3.1 người dùng chỉnh được qua settings) — không
    co giãn theo vùng chứa, để mọi ô bằng nhau tuyệt đối ở mọi
    số lượng."""

    maximize_requested = Signal(int)
    resize_requested = Signal(int, int)
    resize_finished = Signal()

    def __init__(self, profile: dict, channel_text: str,
                 login_state: str, parent=None,
                 tile_width: int = TILE_WIDTH,
                 tile_height: int = TILE_HEIGHT):
        super().__init__(parent)
        self.setObjectName("Card")
        self.profile_id = profile["id"]
        self.profile = profile
        self.dock = docking.BrowserDock()
        self._hidden_mode = False
        self._tile_width = int(tile_width)
        self._tile_height = int(tile_height)
        self.setFixedSize(self._tile_width, self._tile_height)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 8, 10, 10)
        layout.setSpacing(6)

        header_host = QWidget()
        header_host.setFixedHeight(_TILE_HEADER_HEIGHT)
        header = QHBoxLayout(header_host)
        header.setContentsMargins(0, 0, 0, 0)
        header.setSpacing(8)
        # Nhãn ô GỌN MỘT HÀNG — cắt cụt bằng dấu … theo ngân sách
        # pixel cố định (tên đầy đủ xem ở tooltip), không để nhãn
        # dài tràn/xô pill trạng thái.
        title = QLabel()
        title.setObjectName("CardTitle")
        title.setToolTip(profile.get("email") or profile["label"])
        title.setText(QFontMetrics(title.font()).elidedText(
            profile["label"], Qt.ElideRight, 210
        ))
        header.addWidget(title)
        if channel_text:
            channel = QLabel()
            channel.setObjectName("Muted")
            channel.setToolTip(channel_text)
            channel.setText(QFontMetrics(channel.font()).elidedText(
                channel_text, Qt.ElideRight, 170
            ))
            header.addWidget(channel)
        header.addStretch(1)
        text, state = _LOGIN_PILLS.get(login_state, _LOGIN_PILLS["unknown"])
        self.login_pill = theme.pill(text, state)
        header.addWidget(self.login_pill)
        maximize = QPushButton("⛶")
        maximize.setToolTip("Phóng to hồ sơ này về khung xem đơn")
        maximize.setFixedWidth(34)
        maximize.clicked.connect(
            lambda _c=False, pid=self.profile_id: self.maximize_requested.emit(pid)
        )
        header.addWidget(maximize)
        layout.addWidget(header_host)

        self.host = _TileHost()
        self.host.setFixedHeight(tile_host_height(self._tile_height))
        self.host.resized.connect(self._on_host_resized)
        layout.addWidget(self.host)
        self.placeholder = QLabel(self.DEFAULT_PLACEHOLDER, self.host)
        self.placeholder.setObjectName("Muted")
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setWordWrap(True)
        self.grip = _ResizeGrip(self)
        self.grip.dragged.connect(self.resize_requested)
        self.grip.released.connect(self.resize_finished)
        self.busy_badge = None

    def set_activity(self, text: str | None):
        """V7.0: dòng "🤖 Muse: bước i/n · thao tác" trên đầu ô + viền sáng
        khi Muse đang điều khiển trình duyệt này."""
        badge = getattr(self, "activity_badge", None)
        if text:
            if badge is None:
                badge = QLabel()
                badge.setStyleSheet("color:#CEFC19; font-weight:600;")
                self.layout().insertWidget(1, badge)
                self.activity_badge = badge
            badge.setText(QFontMetrics(badge.font()).elidedText(text, Qt.ElideRight, max(120, self._tile_width - 30)))
            badge.setToolTip(text)
            self.setStyleSheet("QFrame#Card { border: 2px solid #CEFC19; border-radius: 14px; }")
        else:
            if badge is not None:
                badge.setParent(None)
                badge.deleteLater()
                self.activity_badge = None
            self.setStyleSheet("")

    def set_busy(self, text: str | None):
        """V6.3: nhãn 'Muse đang dùng' trên ô (agent đang làm việc trên hồ sơ)."""
        if text and self.busy_badge is None:
            self.busy_badge = theme.pill(text, "run")
            self.layout().itemAt(0).widget().layout().insertWidget(1, self.busy_badge)
        elif self.busy_badge is not None:
            if text:
                self.busy_badge.setText(text)
            else:
                self.busy_badge.setParent(None)
                self.busy_badge.deleteLater()
                self.busy_badge = None

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.grip.move(self.width() - self.grip.width() - 2, self.height() - self.grip.height() - 2)
        self.grip.raise_()

    #: Chữ giữ chỗ mặc định của ô (trạng thái ĐANG TẢI/chờ nhúng).
    DEFAULT_PLACEHOLDER = "Đang chờ nhúng cửa sổ Chrome của hồ sơ này…"
    #: Chữ giữ chỗ khi CHẠY ẨN (V5.3 A8): ô nói rõ trình duyệt
    #: đang sống ngoài app — không phải lỗi nhúng.
    HIDDEN_PLACEHOLDER = (
        "Đang chạy ẩn ngoài app — trình duyệt của hồ sơ này mở ở "
        "cửa sổ riêng/thu nhỏ, app vẫn điều khiển qua CDP. Tắt "
        "“Chạy ẩn” ở tab Hồ sơ để nhúng lại vào tường."
    )

    def _default_placeholder(self) -> str:
        return (
            self.HIDDEN_PLACEHOLDER if self._hidden_mode
            else self.DEFAULT_PLACEHOLDER
        )

    def set_hidden_mode(self, on: bool):
        """Bật/tắt hiển thị CHẠY ẨN cho ô: đang nhúng thì gỡ
        nhúng (cửa sổ về cửa sổ riêng của nó), khung giữ chỗ nói
        trạng thái ẩn; tắt thì về chữ chờ nhúng mặc định."""
        self._hidden_mode = bool(on)
        if self._hidden_mode and self.dock.docked_hwnd is not None:
            self.dock.detach()
        if not self.dock.is_docked():
            self.set_placeholder_text(self._default_placeholder())
            self.placeholder.show()

    def apply_tile_size(self, tile_width: int, tile_height: int):
        """Áp kích thước ô MỚI (V5.3.1 — M2, từ Cài đặt): ô cố
        định lại đúng (rộng, cao) và khung nhúng theo đúng chiều
        cao suy ra; cửa sổ Chrome đang nhúng được đồng bộ lại
        kích thước qua tín hiệu resized của host."""
        self._tile_width = int(tile_width)
        self._tile_height = int(tile_height)
        self.setFixedSize(self._tile_width, self._tile_height)
        self.host.setFixedHeight(tile_host_height(self._tile_height))

    def set_placeholder_text(self, text: str):
        """Đổi chữ khung giữ chỗ của ô (trạng thái LỖI nhúng phải
        nói rõ trên chính ô — xem MainWindow._after_wall_dock)."""
        if self.placeholder.text() != text:
            self.placeholder.setText(text)

    def set_login_state(self, login_state: str):
        text, state = _LOGIN_PILLS.get(login_state, _LOGIN_PILLS["unknown"])
        if self.login_pill.text() != text:
            self.login_pill.setText(text)
        if self.login_pill.property("state") != state:
            self.login_pill.setProperty("state", state)
            style = self.login_pill.style()
            style.unpolish(self.login_pill)
            style.polish(self.login_pill)

    def dock_chrome(self, manager) -> bool:
        """Nhúng cửa sổ Chrome của hồ sơ vào ô này (Windows).
        Chế độ chạy ẩn: KHÔNG nhúng — cửa sổ ở ngoài app."""
        if self._hidden_mode:
            return False
        if not docking.IS_WINDOWS:
            return False
        if self.dock.is_docked():
            # V6.5.1: ô đã nhúng nhưng Chrome bị thu nhỏ → khôi phục, giãn đầy ô.
            if docking.ensure_restored(self.dock.docked_hwnd):
                self.dock.sync_size(max(50, self.host.width()), max(50, self.host.height()))
            return True
        hwnd = docking.find_chrome_window(self.profile, manager)
        if not hwnd:
            return False
        self.host.winId()  # ép tạo native window trước khi lấy HWND
        ok = self.dock.attach(
            hwnd,
            int(self.host.winId()),
            max(50, self.host.width()),
            max(50, self.host.height()),
        )
        if ok:
            self.placeholder.hide()
        return ok

    def undock(self):
        if self.dock.docked_hwnd is not None:
            self.dock.detach()
        self.set_placeholder_text(self._default_placeholder())
        self.placeholder.show()

    def prune_if_dead(self):
        """Chrome của ô đã đóng → gỡ nhúng, hiện lại khung giữ chỗ."""
        if self.dock.docked_hwnd is not None and not self.dock.is_docked():
            self.dock.detach()
            self.set_placeholder_text(self._default_placeholder())
            self.placeholder.show()

    def _on_host_resized(self, width: int, height: int):
        self.placeholder.setGeometry(6, 6, max(10, width - 12), max(10, height - 12))
        if self.dock.is_docked():
            self.dock.sync_size(width, height)


class BrowserWall(QWidget):
    """Lưới ô trình duyệt (V5.3): ô cố định 600×800, tối đa 3 ô
    mỗi hàng, thừa xuống hàng mới, cuộn dọc; thứ tự ô cố định
    theo id hồ sơ tăng dần."""

    maximize_requested = Signal(int)
    # V6.5: zoom TRANG (scope: 'page' | 'row' | 'all', phần trăm)
    page_zoom_changed = Signal(str, int)

    def __init__(self, store, parent=None, settings=None):
        super().__init__(parent)
        self._store = store
        # V5.3.1 (M2): kích thước ô hiệu lực từ settings của
        # MainWindow (None → mặc định 600×800); đổi trong Cài đặt
        # thì MainWindow gọi set_tile_size để áp ngay.
        self._tile_width, self._tile_height = tile_size(settings)
        self.tiles: dict[int, BrowserTile] = {}
        self._entry_ids: tuple[int, ...] = ()
        self._hidden_mode = False
        self._positions: dict[int, tuple[int, int]] = {}
        self._rows_used = 0

        self._settings = settings if settings is not None else {}
        self._layout_mode = str(self._settings.get("browser_wall_layout") or "auto")
        self._priority: dict[int, tuple] = {}
        self._busy_text: dict[int, str] = {}

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(6)
        # V6.3: thanh điều khiển tường — bố cục theo cột / lấp đầy,
        # cỡ ô đồng loạt, Muse đang dùng luôn lên đầu.
        bar = QHBoxLayout()
        bar.setSpacing(6)
        bar.addWidget(QLabel("Bố cục:"))
        self._layout_group = QButtonGroup(self)
        self._layout_buttons = {}
        for key, label, tip in (
            ("auto", "Tự động", "Số cột theo bề rộng, ô giữ kích thước đã chỉnh"),
            ("1", "1 cột", "Một cột, ô rộng hết khung"),
            ("2", "2 cột", "Hai cột chia đều"),
            ("3", "3 cột", "Ba cột chia đều"),
            ("4", "4 cột", "Bốn cột chia đều"),
            ("fit", "⊞ Lấp đầy", "Chia ô vừa khít khung, không cần cuộn"),
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setToolTip(tip)
            button.clicked.connect(lambda _c=False, k=key: self.set_layout_mode(k))
            self._layout_group.addButton(button)
            self._layout_buttons[key] = button
            bar.addWidget(button)
        self._layout_buttons.get(self._layout_mode, self._layout_buttons["auto"]).setChecked(True)
        bar.addSpacing(12)
        bar.addWidget(QLabel("Cỡ ô:"))
        self.size_slider = QSlider(Qt.Horizontal)
        self.size_slider.setRange(40, 200)
        self.size_slider.setValue(100)
        self.size_slider.setFixedWidth(140)
        self.size_slider.setToolTip("Phóng/thu MỌI ô cùng lúc (100% = kích thước trong Cài đặt)")
        self.size_slider.valueChanged.connect(self._on_zoom)
        bar.addWidget(self.size_slider)
        self.zoom_label = QLabel("100%")
        self.zoom_label.setObjectName("Muted")
        bar.addWidget(self.zoom_label)
        # V6.5: ZOOM TRANG dạng thanh trượt — áp cho ô đang chọn, cả
        # hàng của ô đó, hoặc mọi trang đang mở; giữ khi trang tải lại.
        bar.addSpacing(12)
        bar.addWidget(QLabel("Zoom trang:"))
        self.page_zoom_slider = QSlider(Qt.Horizontal)
        self.page_zoom_slider.setRange(30, 150)
        self.page_zoom_slider.setSingleStep(5)
        self.page_zoom_slider.setPageStep(10)
        self.page_zoom_slider.setValue(int(self._settings.get("page_zoom_last", 100) or 100))
        self.page_zoom_slider.setFixedWidth(150)
        self.page_zoom_slider.setToolTip("Kéo để zoom NỘI DUNG trang (giữ nguyên khi trang tải lại)")
        self.page_zoom_label = QLabel(f"{self.page_zoom_slider.value()}%")
        self.page_zoom_label.setObjectName("Muted")
        self.page_zoom_scope = QComboBox()
        for key, text in (("page", "Ô đang chọn"), ("row", "Cả hàng"), ("all", "Mọi trang đang mở")):
            self.page_zoom_scope.addItem(text, key)
        scope_index = self.page_zoom_scope.findData(self._settings.get("page_zoom_scope", "all"))
        self.page_zoom_scope.setCurrentIndex(max(0, scope_index))
        self._page_zoom_timer = QTimer(self)
        self._page_zoom_timer.setSingleShot(True)
        self._page_zoom_timer.setInterval(180)
        self._page_zoom_timer.timeout.connect(self._emit_page_zoom)
        self.page_zoom_slider.valueChanged.connect(self._on_page_zoom)
        self.page_zoom_scope.currentIndexChanged.connect(lambda _i: self._emit_page_zoom())
        bar.addWidget(self.page_zoom_slider)
        bar.addWidget(self.page_zoom_label)
        bar.addWidget(self.page_zoom_scope)
        bar.addStretch(1)
        self.summary_label = QLabel("")
        self.summary_label.setObjectName("Muted")
        bar.addWidget(self.summary_label)
        layout.addLayout(bar)
        self._base_size = (self._tile_width, self._tile_height)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet(
            f"QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.BG}; }}"
        )
        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        self.grid.setContentsMargins(2, 2, 2, 2)
        self.grid.setSpacing(TILE_SPACING)
        self.scroll.setWidget(self.grid_host)
        layout.addWidget(self.scroll)

        self.empty_label = QLabel(
            "Chưa có trình duyệt hồ sơ nào đang chạy — mở một hồ sơ "
            "hoặc chờ lệnh tự mở trình duyệt khi có việc."
        )
        self.empty_label.setObjectName("Muted")
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setWordWrap(True)

    # ------------------------------------------------------------------ #
    def _channel_text(self, profile_id: int) -> str:
        try:
            channels = self._store.list_channels(profile_id)
        except Exception:
            channels = []
        if not channels:
            return ""
        first = channels[0].get("name") or channels[0].get("handle") or ""
        if len(channels) > 1:
            return f"{first} +{len(channels) - 1} kênh"
        return first

    def set_hidden_mode(self, on: bool):
        """Chế độ CHẠY ẨN cho cả tường (V5.3 A8): mọi ô ngừng
        nhúng và hiện trạng thái ẩn; tắt thì ô về chờ nhúng."""
        self._hidden_mode = bool(on)
        for tile in self.tiles.values():
            tile.set_hidden_mode(on)

    def set_activity(self, profile_id: int, text: str | None):
        if not hasattr(self, "_activity"):
            self._activity = {}
        if text:
            self._activity[int(profile_id)] = text
        else:
            self._activity.pop(int(profile_id), None)
        tile = self.tiles.get(int(profile_id))
        if tile is not None:
            tile.set_activity(text)

    def highlight(self, profile_id: int) -> bool:
        tile = self.tiles.get(int(profile_id))
        if tile is None:
            return False
        try:
            self.scroll.ensureWidgetVisible(tile, 20, 20)
        except Exception:
            pass
        return True

    def set_entries(self, profiles: list[dict], login_states: dict[int, str]):
        """Dựng/cập nhật LƯỚI Ô theo danh sách hồ sơ ĐANG CHẠY. Ô
        của hồ sơ không còn chạy được GỠ NHÚNG trước khi huỷ
        (Chrome về cửa sổ riêng của nó).

        V5.3: thứ tự ô CỐ ĐỊNH theo id hồ sơ tăng dần — sắp xếp
        tại đây bất kể thứ tự caller đưa vào, để lưới không bao
        giờ xáo trộn giữa các lần refresh."""
        profiles = sorted(profiles, key=lambda p: self._priority.get(p["id"], (9, p["id"])))
        ids = tuple(p["id"] for p in profiles)
        if ids == self._entry_ids:
            self.refresh_login_states(login_states)
            return
        self._entry_ids = ids
        wanted = set(ids)
        for pid in [pid for pid in self.tiles if pid not in wanted]:
            tile = self.tiles.pop(pid)
            tile.undock()
            tile.hide()
            tile.setParent(None)
            tile.deleteLater()
        profiles_by_id = {p["id"]: p for p in profiles}
        for pid in ids:
            tile = self.tiles.get(pid)
            if tile is None:
                tile = BrowserTile(
                    profiles_by_id[pid],
                    self._channel_text(pid),
                    login_states.get(pid, "unknown"),
                    tile_width=self._tile_width,
                    tile_height=self._tile_height,
                )
                tile.maximize_requested.connect(self.maximize_requested)
                tile.resize_requested.connect(self._on_tile_drag)
                tile.resize_finished.connect(self._save_tile_size)
                if self._hidden_mode:
                    tile.set_hidden_mode(True)
                self.tiles[pid] = tile
            else:
                tile.set_login_state(login_states.get(pid, "unknown"))
            tile.set_busy(self._busy_text.get(pid))
            tile.set_activity(getattr(self, "_activity", {}).get(pid))
        self._relayout()

    # ------------------------------------------------------------------ #
    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._relayout()

    def showEvent(self, event):
        super().showEvent(event)
        self._relayout()

    def column_count(self) -> int:
        """Số cột: chế độ 'auto' theo bề rộng vùng cuộn (≤3 như V5.3);
        chế độ N cột cố định; 'fit' = căn bậc hai số ô (V6.3)."""
        mode = self._layout_mode
        if mode.isdigit():
            return max(1, min(MAX_COLUMNS, int(mode)))
        if mode == "fit":
            import math

            return max(1, min(MAX_COLUMNS, math.ceil(math.sqrt(max(1, len(self.tiles))))))
        return min(3, wall_columns(self.scroll.viewport().width(), self._tile_width))

    # ------------------------------------------------------------------ #
    # V6.3: ưu tiên, bố cục, cỡ ô đồng loạt
    # ------------------------------------------------------------------ #
    def set_priority(self, priority: dict[int, tuple], busy_text: dict[int, str] | None = None):
        """priority: profile_id → khoá sắp xếp (nhỏ lên trước). Hồ sơ
        Muse đang dùng lên đầu. Đổi thứ tự thì xếp lại lưới ngay."""
        self._busy_text = dict(busy_text or {})
        changed = priority != self._priority
        self._priority = dict(priority)
        for pid, tile in self.tiles.items():
            tile.set_busy(self._busy_text.get(pid))
        if changed and self.tiles:
            ids = tuple(sorted(self.tiles, key=lambda pid: self._priority.get(pid, (9, pid))))
            if ids != self._entry_ids:
                self._entry_ids = ids
                self._relayout()
        busy = sum(1 for pid in self.tiles if pid in self._busy_text)
        self.summary_label.setText(f"{len(self.tiles)} trình duyệt · {busy} Muse đang dùng")

    def set_layout_mode(self, mode: str):
        self._layout_mode = mode
        if mode in self._layout_buttons:
            self._layout_buttons[mode].setChecked(True)
        self._settings["browser_wall_layout"] = mode
        self._persist()
        self._relayout()

    def _on_page_zoom(self, value: int):
        self.page_zoom_label.setText(f"{value}%")
        self._page_zoom_timer.start()

    def _emit_page_zoom(self):
        scope = self.page_zoom_scope.currentData() or "all"
        self._settings["page_zoom_last"] = self.page_zoom_slider.value()
        self._settings["page_zoom_scope"] = scope
        self.page_zoom_changed.emit(scope, int(self.page_zoom_slider.value()))

    def _on_zoom(self, value: int):
        self.zoom_label.setText(f"{value}%")
        bw, bh = self._base_size
        self._apply_size(int(bw * value / 100), int(bh * value / 100))

    def _on_tile_drag(self, width: int, height: int):
        if self._layout_mode not in ("auto",):
            self._layout_mode = "auto"
            self._layout_buttons["auto"].setChecked(True)
        self._apply_size(width, height)

    def _apply_size(self, width: int, height: int):
        width = max(TILE_WIDTH_MIN, min(TILE_WIDTH_MAX * 2, int(width)))
        height = max(TILE_HEIGHT_MIN, min(TILE_HEIGHT_MAX * 2, int(height)))
        self._tile_width, self._tile_height = width, height
        for tile in self.tiles.values():
            tile.apply_tile_size(width, height)
        self._relayout()

    def _save_tile_size(self):
        self._settings["wall_tile_width"] = min(TILE_WIDTH_MAX, self._tile_width)
        self._settings["wall_tile_height"] = min(TILE_HEIGHT_MAX, self._tile_height)
        self._base_size = (self._tile_width, self._tile_height)
        self.size_slider.blockSignals(True)
        self.size_slider.setValue(100)
        self.size_slider.blockSignals(False)
        self.zoom_label.setText("100%")
        self._persist()

    def _persist(self):
        try:
            from .. import config

            if self._settings:
                config.save_settings(self._settings)
        except Exception:
            pass

    def _fit_sizes(self, cols: int, count: int) -> tuple[int, int]:
        rows = max(1, -(-count // cols))
        vw = max(200, self.scroll.viewport().width() - 6)
        vh = max(200, self.scroll.viewport().height() - 6)
        width = (vw - TILE_SPACING * (cols - 1)) // cols
        height = (vh - TILE_SPACING * (rows - 1)) // rows if self._layout_mode == "fit" else self._tile_height
        return max(TILE_WIDTH_MIN // 2, width), max(TILE_HEIGHT_MIN // 2, height)

    def tile_size(self) -> tuple[int, int]:
        """Kích thước ô hiệu lực hiện tại của tường (rộng, cao)."""
        return (self._tile_width, self._tile_height)

    def set_tile_size(self, tile_width: int, tile_height: int):
        """Áp kích thước ô MỚI cho cả tường (V5.3.1 — M2, gọi từ
        MainWindow khi người dùng Lưu cài đặt): ô hiện có đổi
        kích thước tại chỗ, ô tạo sau dùng kích thước mới, lưới
        xếp lại theo số cột mới."""
        tile_width, tile_height = tile_size({
            "wall_tile_width": tile_width,
            "wall_tile_height": tile_height,
        })
        if (tile_width, tile_height) == (self._tile_width, self._tile_height):
            return
        self._tile_width, self._tile_height = tile_width, tile_height
        self._base_size = (tile_width, tile_height)
        for tile in self.tiles.values():
            tile.apply_tile_size(tile_width, tile_height)
        self._relayout()

    def tile_position(self, profile_id: int) -> tuple[int, int] | None:
        """(hàng, cột) hiện tại của ô trong lưới — None nếu ô
        không có trong tường."""
        return self._positions.get(profile_id)

    def _relayout(self):
        """Xếp lại các ô vào lưới: hàng-quấn theo số cột suy từ bề
        rộng vùng cuộn. Cột/hàng thừa mang stretch để ô dồn về
        góc trên-trái; reset stretch của MỌI cột/hàng mỗi lần
        (bài học §8: số cột đổi mà quên reset thì stretch cũ ở
        lại làm lưới lệch)."""
        while self.grid.count():
            self.grid.takeAt(0)
        self._positions = {}
        cols = self.column_count()
        for c in range(MAX_COLUMNS + 1):
            self.grid.setColumnStretch(c, 1 if c == cols else 0)
        ordered = [self.tiles[pid] for pid in self._entry_ids
                   if pid in self.tiles]
        if ordered and self._layout_mode != "auto":
            width, height = self._fit_sizes(cols, len(ordered))
            for tile in ordered:
                if (tile.width(), tile.height()) != (width, height):
                    tile.apply_tile_size(width, height)
        rows = 0
        if not ordered:
            self.grid.addWidget(self.empty_label, 0, 0, 1, MAX_COLUMNS)
            self.empty_label.show()
            rows = 1
        else:
            self.empty_label.hide()
            for index, tile in enumerate(ordered):
                row, col = divmod(index, cols)
                self.grid.addWidget(tile, row, col)
                self._positions[tile.profile_id] = (row, col)
                rows = max(rows, row + 1)
        for r in range(max(self._rows_used, rows) + 1):
            self.grid.setRowStretch(r, 1 if r == rows else 0)
        self._rows_used = rows

    def refresh_login_states(self, login_states: dict[int, str]):
        for pid, tile in self.tiles.items():
            tile.set_login_state(login_states.get(pid, "unknown"))

    def dock_all(self, manager):
        if self._hidden_mode:
            return  # A8: chạy ẩn — tường không nhúng.
        for tile in self.tiles.values():
            tile.dock_chrome(manager)

    def undocked_profiles(self) -> list[dict]:
        """Hồ sơ có ô nhưng CHƯA nhúng được (đường 'chỉ nhúng':
        cửa sổ của các hồ sơ này phải được đỗ khuất, không để
        nổi ngoài app trong lúc ô còn là khung giữ chỗ). Chế độ
        chạy ẩn thì danh sách RỖNG — cửa sổ ĐƯỢC PHÉP ở ngoài."""
        if self._hidden_mode:
            return []
        return [
            tile.profile for tile in self.tiles.values()
            if not tile.dock.is_docked()
        ]

    def undock_all(self):
        for tile in self.tiles.values():
            tile.undock()

    def prune_dead(self):
        for tile in self.tiles.values():
            tile.prune_if_dead()
