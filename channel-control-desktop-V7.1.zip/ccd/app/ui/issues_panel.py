"""V6.1 — Khối "⚠ Sự cố cần xử lý" (tab Văn phòng).

Mỗi sự cố một hàng: vạch màu mức độ · tiêu đề · chi tiết lỗi thật ·
"→ Cách xử lý" cụ thể · các nút thao tác ngay tại chỗ. Thu gọn được
(lưu settings ``office_issues_collapsed``). Chỉ dựng lại hàng khi danh
sách sự cố THẬT SỰ đổi (vân theo key + chi tiết) — không nháy, không tốn.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from . import theme

SEVERITY_STYLE = {
    "critical": ("#FF7A7A", "#211416", "Nghiêm trọng"),
    "warning": ("#F5B841", "#211D12", "Cần chú ý"),
    "info": ("#60A5FA", "#131B25", "Nên xử lý"),
}


def _esc(text) -> str:
    return (str(text or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


class _IssueRow(QFrame):
    def __init__(self, issue: dict, on_action, parent=None):
        super().__init__(parent)
        color, tint, _label = SEVERITY_STYLE.get(issue["severity"], SEVERITY_STYLE["info"])
        self.setObjectName("IssueRow")
        self.setStyleSheet(
            "QFrame#IssueRow{background:%s;border:none;border-left:3px solid %s;"
            "border-radius:6px;}"
            "QLabel{background:transparent;border:none;}"
            "QPushButton{padding:2px 10px;min-height:22px;}" % (tint, color)
        )
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 4, 6, 4)
        layout.setSpacing(10)
        text_box = QVBoxLayout()
        text_box.setSpacing(0)
        # Dòng 1: tiêu đề đậm + lỗi thật (màu mức độ) trên CÙNG hàng.
        detail = issue.get("detail") or ""
        title = QLabel(
            f"<b style='color:{theme.TEXT}'>{_esc(issue['title'])}</b>"
            + (f" &nbsp;<span style='color:{color}'>{_esc(detail)}</span>" if detail else "")
        )
        title.setTextFormat(Qt.RichText)
        title.setWordWrap(True)
        title.setTextInteractionFlags(Qt.TextSelectableByMouse)
        text_box.addWidget(title)
        if issue.get("lead_note"):
            # V6.7: trưởng phòng đang/đã xử lý gì — bạn không phải làm gì
            note = QLabel(f"🧑‍💼 Trưởng phòng: {_esc(issue['lead_note'])}")
            note.setStyleSheet("color:#CEFC19;")
            note.setWordWrap(True)
            text_box.addWidget(note)
        elif issue.get("fix"):
            fix = QLabel("→ " + issue["fix"])
            fix.setStyleSheet(f"color:{theme.MUTED};")
            fix.setWordWrap(True)
            text_box.addWidget(fix)
        layout.addLayout(text_box, 1)
        buttons = QHBoxLayout()
        buttons.setSpacing(6)
        for action, label in issue.get("actions") or []:
            button = QPushButton(label)
            button.setCursor(Qt.PointingHandCursor)
            button.clicked.connect(lambda _c=False, a=action, i=issue: on_action(a, i))
            buttons.addWidget(button)
        layout.addLayout(buttons)


class IssuesPanel(QFrame):
    """Danh sách sự cố có nút xử lý. Phát action_requested(action, issue)."""

    action_requested = Signal(str, dict)

    def __init__(self, settings: dict | None = None, parent=None):
        super().__init__(parent)
        self._settings = settings if settings is not None else {}
        self._issues: list[dict] = []
        self._fingerprint = None
        self.setObjectName("Card")
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 8, 12, 8)
        root.setSpacing(6)
        head = QHBoxLayout()
        head.setSpacing(8)
        self.title_label = theme.section_header("⚠ Sự cố cần xử lý")
        head.addWidget(self.title_label)
        self.count_critical = self._count_pill("#FF7A7A")
        self.count_warning = self._count_pill("#F5B841")
        self.count_info = self._count_pill("#60A5FA")
        for pill in (self.count_critical, self.count_warning, self.count_info):
            head.addWidget(pill)
        self.ok_label = theme.muted_label("✅ Không có sự cố — mọi việc đang chạy bình thường.")
        head.addWidget(self.ok_label)
        head.addStretch(1)
        # V6.7: DUYỆT HÀNG LOẠT — giao trưởng phòng xử lý hết, hoặc tự cho chạy tiếp hết.
        self.lead_all_button = QPushButton("🧑‍💼 Trưởng phòng xử lý tất cả")
        self.lead_all_button.setProperty("variant", "primary")
        self.lead_all_button.setToolTip("Trưởng phòng ra quyết định ngay cho MỌI sự cố (bỏ qua thời gian chờ giữa các lần xử lý)")
        self.lead_all_button.clicked.connect(lambda: self.action_requested.emit("lead_all", {}))
        head.addWidget(self.lead_all_button)
        self.resume_all_button = QPushButton("▶ Chạy tiếp tất cả")
        self.resume_all_button.setToolTip("Bạn duyệt: cho mọi lệnh đang chờ/lỗi chạy lại, gửi lại trọn việc cho Muse")
        self.resume_all_button.clicked.connect(lambda: self.action_requested.emit("resume_all", {"issues": self.issues()}))
        head.addWidget(self.resume_all_button)
        self.toggle_button = QPushButton()
        self.toggle_button.setStyleSheet("padding:2px 12px;")
        self.toggle_button.clicked.connect(self._toggle)
        head.addWidget(self.toggle_button)
        root.addLayout(head)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.body = QWidget()
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(6)
        self.body_layout.addStretch(1)
        self.scroll.setWidget(self.body)
        root.addWidget(self.scroll)
        self.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        self._collapsed = bool(self._settings.get("office_issues_collapsed", False))
        self._apply_collapsed()

    @staticmethod
    def _count_pill(color: str) -> QLabel:
        label = QLabel("")
        label.setStyleSheet(
            f"color:{color};border:1px solid {color};border-radius:9px;"
            "padding:1px 8px;font-weight:700;"
        )
        label.setVisible(False)
        return label

    def issues(self) -> list[dict]:
        return list(self._issues)

    @staticmethod
    def _group_tooltip(word: str, items: list[dict]) -> str:
        import html as _html

        if not items:
            return ""
        rows = []
        for issue in items[:8]:
            line = f"<li><b>{_html.escape(issue.get('title') or '')}</b>"
            if issue.get("detail"):
                line += f"<br><span style='color:#F2C94C'>{_html.escape(str(issue['detail'])[:180])}</span>"
            if issue.get("lead_note"):
                line += f"<br><span style='color:#CEFC19'>🧑‍💼 {_html.escape(str(issue['lead_note'])[:160])}</span>"
            elif issue.get("fix"):
                line += f"<br><span style='color:#9AA3AD'>→ {_html.escape(str(issue['fix'])[:160])}</span>"
            rows.append(line + "</li>")
        more = f"<div style='color:#9AA3AD'>+{len(items) - 8} sự cố nữa…</div>" if len(items) > 8 else ""
        return (f"<qt><b>{len(items)} sự cố {_html.escape(word)}</b>"
                f"<ul style='margin-left:-20px'>{''.join(rows)}</ul>{more}</qt>")

    def set_issues(self, issues: list[dict]) -> None:
        fingerprint = tuple(
            (i["key"], i["severity"], i["title"], i.get("detail"), i.get("lead_note"),
             tuple(a for a, _ in i.get("actions") or []))
            for i in issues
        )
        if fingerprint == self._fingerprint:
            return
        self._fingerprint = fingerprint
        self._issues = list(issues)
        counts = {"critical": 0, "warning": 0, "info": 0}
        for issue in issues:
            counts[issue["severity"]] = counts.get(issue["severity"], 0) + 1
        for key, pill, word in (
            ("critical", self.count_critical, "nghiêm trọng"),
            ("warning", self.count_warning, "cần chú ý"),
            ("info", self.count_info, "nên xử lý"),
        ):
            pill.setText(f"{counts[key]} {word}")
            pill.setVisible(counts[key] > 0)
            # V6.9: rê chuột lên ô đếm → popup từng sự cố + trưởng phòng đang làm gì
            pill.setToolTip(self._group_tooltip(word, [i for i in issues if i["severity"] == key]))
        self.ok_label.setVisible(not issues)
        self.toggle_button.setVisible(bool(issues))
        self.lead_all_button.setVisible(bool(issues))
        self.resume_all_button.setVisible(any(i.get("command_id") for i in issues))
        # Dựng lại hàng.
        while self.body_layout.count() > 1:
            item = self.body_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        for index, issue in enumerate(issues):
            self.body_layout.insertWidget(index, _IssueRow(issue, self._emit))
        self._apply_collapsed()

    def _emit(self, action: str, issue: dict) -> None:
        self.action_requested.emit(action, issue)

    def _toggle(self):
        self._collapsed = not self._collapsed
        self._settings["office_issues_collapsed"] = self._collapsed
        try:
            from .. import config

            config.save_settings(self._settings)
        except Exception:
            pass
        self._apply_collapsed()

    def _apply_collapsed(self):
        has = bool(self._issues)
        self.scroll.setVisible(has and not self._collapsed)
        self.toggle_button.setText("▾ Mở danh sách" if self._collapsed else "▴ Thu gọn")
        # Cao tối đa ~2.5 hàng (cuộn khi nhiều hơn) — sàn văn phòng
        # vẫn là phần chính của tab.
        rows = min(len(self._issues), 2.5)
        self.scroll.setFixedHeight(int(max(0, rows * 58)))
