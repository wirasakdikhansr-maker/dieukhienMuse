"""Bảng việc theo dòng Agent (V5.0 → V5.1 dạng THẺ) — view chính
của mục Công việc.

V5.1 (plan §2.3): bỏ cây trần (QTreeWidget) — mỗi agent là một THẺ
lớn (avatar robot, tên/mail, pill trạng thái, tiến độ tổng), trong
thẻ là các THẺ CON kênh (avatar chữ, mô tả việc 2 dòng, thanh % +
số %, pill trạng thái kênh, dòng "Thường trực: N mục"). Bên phải
vẫn là hàng đợi việc của kênh/agent đang chọn. Dữ liệu lấy TỪ work
model dùng chung (``work_model.build_work_model``) — không có
nguồn dữ liệu song song.

Luồng chính là CHUỘT PHẢI trên thẻ kênh: Giao việc… / Việc Muse
phải làm cho kênh… / Xem tiến độ kênh / Mở trình duyệt của kênh /
Tạm dừng kênh này. "Tạm dừng" dùng cơ chế pause sẵn có ở CẤP HỒ SƠ
(dispatcher tôn trọng cờ này; app chưa có cờ pause riêng cho từng
kênh) — hộp thoại xác nhận nói rõ phạm vi đó trước khi áp.
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSplitter,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

from .. import assignments
from ..store import COMMAND_TYPE_LABELS, agent_status
from . import theme, work_model
from .agents_panel import STATUS_LABELS
from .assign_dialog import AssignDialog, StandingChecklistDialog

_COMMAND_STATUS = {
    "queued": "Chờ",
    "waiting_muse": "Chờ Muse",
    "assigned": "Đã giao",
    "running": "Đang chạy",
    "needs_user": "Chờ bạn xử lý",
    "done": "Hoàn tất",
    "failed": "Lỗi",
    "cancelled": "Đã huỷ",
}
_STATUS_ICON = {
    "running": "●",
    "done": "✓",
    "needs_user": "⏸",
    "failed": "✕",
    "queued": "≡",
    "waiting_muse": "≡",
    "assigned": "≡",
    "cancelled": "—",
}
_ACTIVE_ORDER = {
    "running": 0,
    "needs_user": 1,
    "waiting_muse": 2,
    "assigned": 3,
    "queued": 4,
    "failed": 5,
    "done": 6,
    "cancelled": 7,
}
# Trạng thái agent (store.agent_status) → state của pill theme.
_AGENT_PILL_STATES = {
    "online": "in",
    "idle": "unknown",
    "offline": "out",
    "revoked": "out",
}
# Trạng thái lệnh hiện tại của kênh → (nhãn pill, state pill).
_CHANNEL_PILL = {
    "running": ("Đang chạy", "run"),
    "needs_user": ("Chờ bạn xử lý", "user"),
    "queued": ("Đang chờ", "paused"),
    "waiting_muse": ("Đang chờ", "paused"),
    "assigned": ("Đang chờ", "paused"),
    "failed": ("Lỗi", "out"),
    "done": ("Hoàn tất", "in"),
    "cancelled": ("Đã huỷ", "unknown"),
}


def _command_title(command: dict) -> str:
    payload = command.get("payload") or {}
    assignment = payload.get("assignment") or {}
    if assignment.get("template_title"):
        return str(assignment["template_title"])
    return COMMAND_TYPE_LABELS.get(
        command.get("type"), command.get("type") or "Lệnh"
    )


def _current_command(commands: list[dict]) -> dict | None:
    """Việc "hiện tại" của một kênh: đang chạy trước, rồi đang chờ,
    cuối cùng là lệnh gần nhất."""
    if not commands:
        return None
    ordered = sorted(
        commands,
        key=lambda c: _ACTIVE_ORDER.get(c.get("status"), 9),
    )
    return ordered[0]


class _ChannelCard(QFrame):
    """Thẻ kênh: bấm trái = chọn, chuột phải = menu giao việc."""

    clicked = Signal(str)
    menu_requested = Signal(str, object)

    def __init__(self, channel_key: str, parent=None):
        super().__init__(parent)
        self.channel_key = channel_key
        self.setObjectName("ChannelCard")
        self.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.customContextMenuRequested.connect(
            lambda pos: self.menu_requested.emit(
                self.channel_key, self.mapToGlobal(pos)
            )
        )

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._mods = event.modifiers()
            self.clicked.emit(self.channel_key)
        super().mousePressEvent(event)

    def event(self, event):
        # V6.9: rê chuột lên thẻ kênh → popup việc hiện tại kẹt gì / vì sao.
        if event.type() == QEvent.Type.ToolTip:
            command_id = getattr(self, "current_command_id", None)
            store = getattr(self, "store", None)
            if command_id and store is not None:
                from .. import command_actions

                try:
                    QToolTip.showText(event.globalPos(), command_actions.explain_html(store, command_id), self)
                    return True
                except Exception:
                    pass
        return super().event(event)


class AgentBoardWidget(QWidget):
    """Thẻ Agent → thẻ kênh + hàng đợi việc của lựa chọn hiện tại."""

    commands_created = Signal(int)
    open_browser_requested = Signal(int)
    command_chosen = Signal(str)
    data_changed = Signal()

    def __init__(self, store, base, parent=None):
        super().__init__(parent)
        self._store = store
        self._base = base
        self._model: dict | None = None
        self._checklists: dict = {}
        self._selected_channel_key: str | None = None
        self._card_data: dict[str, dict] = {}
        self._channel_cards: dict[str, _ChannelCard] = {}
        # V6.9: một kênh có thể hiện ở NHIỀU thẻ agent (vd. việc kiểm tra
        # chéo giao cho Muse khác) → tô viền MỌI thẻ của kênh đang chọn.
        self._all_cards: dict[str, list[_ChannelCard]] = {}
        self._collapsed_agents: set = set()
        self._logo_waiting: dict[str, list] = {}
        from . import channel_logos as _logos

        _logos.notifier().fetched.connect(self._on_logo_fetched)
        # V6.9: chọn NHIỀU kênh (Ctrl = bật/tắt từng kênh, Shift = cả dải).
        self._selected_keys: list[str] = []
        self._anchor_key: str | None = None

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        splitter = QSplitter(Qt.Orientation.Horizontal)
        layout.addWidget(splitter)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 0, 0)
        head_row = QHBoxLayout()
        head_row.setSpacing(8)
        self.header_label = theme.muted_label("Agents")
        head_row.addWidget(self.header_label)
        head_row.addStretch(1)
        self.selection_label = QLabel("")
        self.selection_label.setStyleSheet(f"color:{theme.ACCENT}; font-weight:700;")
        head_row.addWidget(self.selection_label)
        self.bulk_assign_button = QPushButton("📋 Giao việc cho kênh đã chọn")
        self.bulk_assign_button.setToolTip("Giao cùng checklist/skill cho MỌI kênh đang chọn (Ctrl/Shift + bấm để chọn nhiều)")
        self.bulk_assign_button.clicked.connect(self._bulk_assign_selected)
        head_row.addWidget(self.bulk_assign_button)
        self.clear_selection_button = QPushButton("✕ Bỏ chọn")
        self.clear_selection_button.setProperty("variant", "ghost")
        self.clear_selection_button.clicked.connect(self.clear_selection)
        head_row.addWidget(self.clear_selection_button)
        left_layout.addLayout(head_row)
        self._sync_selection_ui()
        self.cards_scroll = QScrollArea()
        self.cards_scroll.setWidgetResizable(True)
        self.cards_scroll.setFrameShape(QFrame.NoFrame)
        self.cards_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        # Nền viewport khớp nền app (bài học §10 — viewport của
        # QScrollArea không tự tối theo QSS toàn cục).
        self.cards_scroll.setStyleSheet(
            "QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.BG}; }}"
        )
        self.cards_host = QWidget()
        self.cards_layout = QVBoxLayout(self.cards_host)
        self.cards_layout.setContentsMargins(2, 2, 6, 2)
        self.cards_layout.setSpacing(12)
        self.cards_layout.addStretch(1)
        self.cards_scroll.setWidget(self.cards_host)
        left_layout.addWidget(self.cards_scroll)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.queue_title = theme.muted_label("Hàng đợi công việc")
        right_layout.addWidget(self.queue_title)
        self.queue_list = QListWidget()
        self.queue_list.itemClicked.connect(self._on_queue_clicked)
        right_layout.addWidget(self.queue_list)
        splitter.addWidget(right)
        splitter.setSizes([560, 480])

    # ------------------------------------------------------------------ #
    # Dựng thẻ từ work model
    # ------------------------------------------------------------------ #
    def set_model(self, model: dict | None):
        self._model = model
        self._checklists = assignments.load_checklists(self._base)
        selected_key = self._selected_channel_key
        # Dọn thẻ cũ ĐÚNG chuẩn (hide + setParent(None) + deleteLater)
        # — bài học "bóng ma" khi dựng lại layout (skill §8).
        while self.cards_layout.count() > 1:
            item = self.cards_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self._card_data = {}
        self._channel_cards = {}
        self._all_cards = {}
        self._logo_waiting = {}
        agents = [
            node
            for node in (model or {}).get("agents") or []
            if node.get("agent")
        ]
        self.header_label.setText(f"Agents ({len(agents)})")
        if not agents:
            empty = QLabel(
                "Chưa có tài khoản Muse nào — thêm ở mục Tài khoản Muse."
            )
            empty.setObjectName("EmptyState")
            empty.setWordWrap(True)
            self.cards_layout.insertWidget(0, empty)
        for node in agents:
            self.cards_layout.insertWidget(
                self.cards_layout.count() - 1, self._agent_card(node)
            )
        keep = [k for k in self._selected_keys if k in self._channel_cards]
        if len(keep) > 1:
            self._selected_keys = keep
            self._selected_channel_key = selected_key if selected_key in keep else keep[-1]
            self._repaint_selection()
        elif selected_key and selected_key in self._channel_cards:
            self._apply_selection(selected_key)
        else:
            self._selected_keys = keep
            self._repaint_selection()
        self._refresh_queue()

    def _agent_card(self, node: dict) -> QFrame:
        agent = node["agent"]
        status = agent_status(
            agent.get("last_seen_at"), bool(agent.get("revoked"))
        )
        has_active = any(
            (c.get("status") in ("running", "needs_user"))
            for profile_node in node.get("profiles") or []
            for channel_node in profile_node.get("channels") or []
            for c in channel_node.get("commands") or []
        ) or any(
            c.get("status") in ("running", "needs_user")
            for c in node.get("loose_commands") or []
        )
        card = QFrame()
        card.setObjectName("Card")
        if has_active:
            # Thẻ agent ĐANG có việc: viền xanh + tint nhẹ (quầng
            # sáng bằng viền/tint theo plan §1.1, không bóng đổ).
            # Selector PHẢI scope QFrame#Card: stylesheet không
            # selector bị Qt áp cho MỌI widget con (bài học từ
            # render V5.1: từng nhãn/thanh trong thẻ đều bị viền).
            card.setStyleSheet(
                "QFrame#Card {"
                " background:rgba(206, 252, 25,0.05);"
                f" border:1px solid {theme.ACCENT}; border-radius:16px;"
                " }"
            )
        layout = QVBoxLayout(card)
        # V5.2: đệm thẻ theo ảnh mẫu (20px) ở thẻ agent Công việc.
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)

        header = QHBoxLayout()
        header.setSpacing(10)
        avatar = QLabel()
        # V5.2: avatar robot ẢNH THẬT + vòng màu theo agent thay
        # vòng tròn chữ cái; thiếu ảnh thì rơi về avatar chữ.
        robot = theme.robot_avatar_pixmap(
            40,
            ring=theme.agent_ring_color(agent.get("id")),
            grey=status not in ("online", "idle"),
        )
        avatar.setPixmap(
            robot
            if robot is not None
            else theme.avatar_pixmap(
                agent.get("name") or "?",
                agent.get("email") or "",
                size=40,
                color=theme.ACCENT,
            )
        )
        avatar.setFixedSize(40, 40)
        header.addWidget(avatar)
        names = QVBoxLayout()
        names.setSpacing(1)
        name_label = QLabel(agent.get("name") or "")
        name_label.setObjectName("CardTitle")
        names.addWidget(name_label)
        email_label = QLabel(agent.get("email") or "")
        email_label.setObjectName("Faint12")
        names.addWidget(email_label)
        header.addLayout(names, 1)
        pill = theme.pill(
            STATUS_LABELS.get(status, status),
            _AGENT_PILL_STATES.get(status, "unknown"),
        )
        header.addWidget(pill, 0, Qt.AlignmentFlag.AlignTop)
        percent = node.get("percent")
        if percent is not None:
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(int(percent))
            bar.setTextVisible(False)
            bar.setFixedWidth(110)
            header.addWidget(bar, 0, Qt.AlignmentFlag.AlignVCenter)
            pct_label = QLabel(f"{int(percent)}%")
            pct_label.setStyleSheet(
                f"color:{theme.ACCENT}; font-weight:700;"
            )
            header.addWidget(pct_label, 0, Qt.AlignmentFlag.AlignVCenter)
        toggle = QPushButton("▾")
        toggle.setProperty("variant", "ghost")
        toggle.setFixedWidth(30)
        toggle.setToolTip("Thu/mở các kênh của agent này")
        header.addWidget(toggle, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(header)

        channels_host = QWidget()
        channels_layout = QVBoxLayout(channels_host)
        channels_layout.setContentsMargins(0, 0, 0, 0)
        channels_layout.setSpacing(8)
        for profile_node in node.get("profiles") or []:
            profile = profile_node.get("profile") or {}
            # V6.3: lệnh của HỒ SƠ (không ghi kênh cụ thể) cũng hiện
            # trên thẻ kênh của hồ sơ đó — trước đây thẻ ghi "Chưa có
            # việc" trong khi agent đang làm, gây hiểu nhầm.
            profile_level = list(profile_node.get("commands") or [])
            for channel_node in profile_node.get("channels") or []:
                if profile_level:
                    merged = list(channel_node.get("commands") or []) + profile_level
                    channel_node = dict(channel_node, commands=merged)
                    if channel_node.get("percent") is None:
                        active = [c for c in merged if c.get("status") in ("running", "needs_user")]
                        if active:
                            channel_node["percent"] = int(active[0].get("progress") or 0)
                channels_layout.addWidget(
                    self._channel_card(channel_node, profile, agent)
                )
        layout.addWidget(channels_host)
        collapsed = agent.get("id") in self._collapsed_agents
        channels_host.setVisible(not collapsed)
        toggle.setText("▸" if collapsed else "▾")

        def _toggle(_checked=False, host=channels_host,
                    agent_id=agent.get("id"), button=toggle):
            visible = not host.isVisible()
            host.setVisible(visible)
            button.setText("▾" if visible else "▸")
            if visible:
                self._collapsed_agents.discard(agent_id)
            else:
                self._collapsed_agents.add(agent_id)

        toggle.clicked.connect(_toggle)
        return card

    def _channel_card(self, channel_node: dict, profile: dict,
                      agent: dict) -> _ChannelCard:
        channel = channel_node.get("channel") or {}
        key = str(channel.get("id"))
        data = {
            "kind": "channel",
            "agent_id": agent.get("id"),
            "agent": agent,
            "profile": profile,
            "profile_id": profile.get("id"),
            "channel": channel,
            "channel_id": channel.get("id"),
            "node": channel_node,
        }
        self._card_data.setdefault(key, data)
        card = _ChannelCard(key)
        card.data = data
        card.clicked.connect(lambda k, c=card: self._on_card_pressed(c))
        card.menu_requested.connect(lambda k, pos, c=card: self._on_card_menu_from(c, pos))
        self._channel_cards.setdefault(key, card)
        self._all_cards.setdefault(key, []).append(card)
        self._paint_channel_card(card, selected=False)

        layout = QHBoxLayout(card)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(10)
        avatar = QLabel()
        # V7.0: LOGO THẬT của kênh (YouTube/Facebook/TikTok) — chưa tải thì
        # avatar chữ, tải nền xong tự thay.
        from . import channel_logos

        logo = channel_logos.pixmap(channel, 40)
        avatar.setPixmap(
            logo if logo is not None else theme.avatar_pixmap(
                channel.get("name") or "?",
                channel.get("channel_id") or "",
                size=40,
            )
        )
        avatar.setFixedSize(40, 40)
        card.logo_label = avatar
        card.logo_is_real = logo is not None
        if logo is None and channel.get("avatar_url"):
            self._logo_waiting.setdefault(str(channel.get("channel_id")), []).append((avatar, dict(channel)))
            channel_logos.request([channel])
        layout.addWidget(avatar, 0, Qt.AlignmentFlag.AlignTop)

        texts = QVBoxLayout()
        texts.setSpacing(2)
        name_label = QLabel(channel.get("name") or channel.get("handle") or "Kênh")
        name_label.setObjectName("CardTitle")
        name_label.setWordWrap(True)
        texts.addWidget(name_label)
        desc_label = QLabel(self._channel_desc(channel_node))
        desc_label.setObjectName("Muted12")
        desc_label.setWordWrap(True)
        texts.addWidget(desc_label)
        standing = self._standing_text(channel, profile)
        # Luôn giữ thuộc tính standing_label trên thẻ (None khi
        # kênh không có checklist thường trực) — test + chẩn đoán
        # bám vào đây thay vì mò cây widget.
        card.standing_label = None
        if standing:
            standing_label = QLabel(standing)
            standing_label.setObjectName("Faint12")
            standing_label.setWordWrap(True)
            texts.addWidget(standing_label)
            card.standing_label = standing_label
        layout.addLayout(texts, 1)

        side = QVBoxLayout()
        side.setSpacing(4)
        current = _current_command(channel_node.get("commands") or [])
        pill_text, pill_state = (
            _CHANNEL_PILL.get(current.get("status"), ("Chưa có việc", "unknown"))
            if current is not None
            else ("Chưa có việc", "unknown")
        )
        pill_widget = theme.pill(pill_text, pill_state)
        card.current_command_id = str(current["id"]) if current is not None and current.get("id") else None
        card.store = self._store
        side.addWidget(pill_widget, 0, Qt.AlignmentFlag.AlignRight)
        percent = channel_node.get("percent")
        if percent is not None:
            bar_row = QHBoxLayout()
            bar_row.setSpacing(6)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(int(percent))
            bar.setTextVisible(False)
            bar.setFixedWidth(90)
            bar_row.addWidget(bar)
            pct_label = QLabel(f"{int(percent)}%")
            pct_label.setStyleSheet(
                f"color:{theme.ACCENT}; font-weight:700;"
            )
            bar_row.addWidget(pct_label)
            side.addLayout(bar_row)
        layout.addLayout(side)
        return card

    def _on_logo_fetched(self, channel_id: str):
        from . import channel_logos

        for label, channel in self._logo_waiting.pop(str(channel_id), []):
            try:
                logo = channel_logos.pixmap(channel, 40)
                if logo is not None:
                    label.setPixmap(logo)
            except RuntimeError:  # thẻ đã bị dựng lại
                pass

    def _paint_channel_card(self, card: _ChannelCard, selected: bool):
        # Selector scope QFrame#ChannelCard — xem ghi chú ở thẻ
        # agent: không selector = viền rò xuống mọi widget con.
        # V6.9: thẻ đang chọn NỔI VIỀN rõ (2px màu nhấn + nền nhuộm);
        # rê chuột cũng sáng viền để biết bấm được.
        card.setProperty("selected", bool(selected))
        if selected:
            card.setStyleSheet(
                "QFrame#ChannelCard {"
                " background:rgba(206, 252, 25,0.13);"
                f" border:2px solid {theme.ACCENT}; border-radius:14px;"
                " }"
            )
        else:
            card.setStyleSheet(
                "QFrame#ChannelCard {"
                f" background:{theme.CARD_HOVER};"
                f" border:1px solid {theme.BORDER}; border-radius:14px;"
                " }"
                "QFrame#ChannelCard:hover {"
                " border:1px solid rgba(206, 252, 25, 0.55);"
                " }"
            )

    def _channel_desc(self, channel_node: dict) -> str:
        current = _current_command(channel_node.get("commands") or [])
        if current is None:
            return "Chưa có việc"
        title = _command_title(current)
        detail = current.get("step") or (current.get("instruction") or "")[:64]
        status = _COMMAND_STATUS.get(
            current.get("status"), current.get("status") or ""
        )
        first = f"{title} — {status}"
        return f"{first}\n{detail}" if detail else first

    def _standing_text(self, channel: dict, profile: dict) -> str:
        parts = []
        checklist = self._checklists.get(str(channel.get("id")))
        if checklist:
            count = len(checklist.get("template_ids") or [])
            parts.append(f"Thường trực: {count} mục")
        if profile.get("paused"):
            parts.append("⏸ Hồ sơ đang tạm dừng")
        return " · ".join(parts)

    # ------------------------------------------------------------------ #
    # Chọn kênh / hàng đợi bên phải
    # ------------------------------------------------------------------ #
    def _on_card_clicked(self, key: str, modifiers=None):
        mods = modifiers if modifiers is not None else QApplication.keyboardModifiers()
        if mods & Qt.KeyboardModifier.ControlModifier:
            self.toggle_selected(key)
        elif mods & Qt.KeyboardModifier.ShiftModifier and self._anchor_key in self._channel_cards:
            self.select_range(self._anchor_key, key)
        else:
            self._apply_selection(key)
        self._refresh_queue()

    def _apply_selection(self, key: str):
        self._selected_channel_key = key
        self._selected_keys = [key]
        self._anchor_key = key
        self._repaint_selection()

    def _repaint_selection(self):
        chosen = set(self._selected_keys)
        for card_key, cards in (self._all_cards or {k: [c] for k, c in self._channel_cards.items()}).items():
            for card in cards:
                self._paint_channel_card(card, selected=(card_key in chosen))
        self._sync_selection_ui()

    def _on_card_pressed(self, card: _ChannelCard):
        # dữ liệu của ĐÚNG thẻ được bấm (đúng agent của thẻ đó)
        if getattr(card, "data", None):
            self._card_data[card.channel_key] = card.data
        self._on_card_clicked(card.channel_key, getattr(card, "_mods", None))

    def _on_card_menu_from(self, card: _ChannelCard, global_pos):
        if getattr(card, "data", None):
            self._card_data[card.channel_key] = card.data
        self._on_card_menu(card.channel_key, global_pos)

    def _sync_selection_ui(self):
        n = len(self._selected_keys)
        if hasattr(self, "selection_label"):
            self.selection_label.setText(f"Đã chọn {n} kênh" if n > 1 else "")
            self.bulk_assign_button.setVisible(n > 1)
            self.clear_selection_button.setVisible(n > 0)

    def toggle_selected(self, key: str):
        key = str(key)
        if key not in self._channel_cards:
            return
        if key in self._selected_keys:
            self._selected_keys.remove(key)
            if self._selected_channel_key == key:
                self._selected_channel_key = self._selected_keys[-1] if self._selected_keys else None
        else:
            self._selected_keys.append(key)
            self._selected_channel_key = key
        self._anchor_key = key
        self._repaint_selection()

    def select_range(self, from_key: str, to_key: str):
        keys = self.channel_keys()
        if from_key not in keys or to_key not in keys:
            self._apply_selection(to_key)
            return
        a, b = sorted((keys.index(from_key), keys.index(to_key)))
        self._selected_keys = keys[a:b + 1]
        self._selected_channel_key = to_key
        self._repaint_selection()

    def select_all_channels(self):
        self._selected_keys = self.channel_keys()
        if self._selected_keys and self._selected_channel_key not in self._selected_keys:
            self._selected_channel_key = self._selected_keys[0]
        self._repaint_selection()
        self._refresh_queue()

    def clear_selection(self):
        self._selected_keys = []
        self._selected_channel_key = None
        self._anchor_key = None
        self._repaint_selection()
        self._refresh_queue()

    def selected_keys(self) -> list[str]:
        return list(self._selected_keys)

    def selected_channels_data(self) -> list[dict]:
        return [self._card_data[k] for k in self._selected_keys if k in self._card_data]

    def selected_channel_data(self) -> dict | None:
        if self._selected_channel_key is None:
            return None
        return self._card_data.get(self._selected_channel_key)

    def channel_card(self, channel_key: str) -> _ChannelCard | None:
        return self._channel_cards.get(str(channel_key))

    def _commands_for(self, data: dict) -> list[dict]:
        return list((data.get("node") or {}).get("commands") or [])

    def _refresh_queue(self):
        data = self.selected_channel_data()
        self.queue_list.clear()
        if data is None:
            self.queue_title.setText("Hàng đợi công việc")
            return
        channel = data.get("channel") or {}
        self.queue_title.setText(
            f"Hàng đợi — {channel.get('name') or 'kênh'}"
        )
        commands = sorted(
            self._commands_for(data),
            key=lambda c: _ACTIVE_ORDER.get(c.get("status"), 9),
        )
        for command in commands:
            percent = work_model.command_percent(command)
            status = _COMMAND_STATUS.get(
                command.get("status"), command.get("status") or ""
            )
            icon = _STATUS_ICON.get(command.get("status"), "·")
            step = command.get("step") or ""
            item = QListWidgetItem(
                f"{icon} {_command_title(command)} — {status} · {percent}%"
                + (f"\n    {step}" if step else "")
            )
            item.setData(Qt.ItemDataRole.UserRole, command.get("id"))
            self.queue_list.addItem(item)

    def _on_queue_clicked(self, item: QListWidgetItem):
        command_id = item.data(Qt.ItemDataRole.UserRole)
        if command_id:
            self.command_chosen.emit(str(command_id))

    def queue_command_ids(self) -> list[str]:
        return [
            str(self.queue_list.item(i).data(Qt.ItemDataRole.UserRole))
            for i in range(self.queue_list.count())
        ]

    # ------------------------------------------------------------------ #
    # Chuột phải trên thẻ kênh
    # ------------------------------------------------------------------ #
    def channel_keys(self) -> list[str]:
        return list(self._channel_cards.keys())

    def select_channel(self, channel_key: str) -> bool:
        key = str(channel_key)
        card = self._channel_cards.get(key)
        if card is None:
            return False
        data = self._card_data.get(key) or {}
        agent_id = data.get("agent_id")
        if agent_id in self._collapsed_agents:
            self._collapsed_agents.discard(agent_id)
            self.set_model(self._model)
            card = self._channel_cards.get(key)
            if card is None:
                return False
        self._apply_selection(key)
        self.cards_scroll.ensureWidgetVisible(card)
        self._refresh_queue()
        return True

    def _on_card_menu(self, key: str, global_pos):
        data = self._card_data.get(key)
        if not data:
            return
        if key in self._selected_keys and len(self._selected_keys) > 1:
            # chuột phải lên một thẻ TRONG vùng chọn → menu hàng loạt
            self.build_bulk_menu(self.selected_channels_data()).exec(global_pos)
            return
        self._apply_selection(key)
        self._refresh_queue()
        self.build_channel_menu(data).exec(global_pos)

    def build_bulk_menu(self, items: list[dict]) -> QMenu:
        menu = QMenu(self)
        n = len(items)
        head = menu.addAction(f"{n} kênh đã chọn")
        head.setEnabled(False)
        menu.addSeparator()
        act = menu.addAction(f"📋 Giao việc cho {n} kênh…")
        act.triggered.connect(lambda: self._open_assign_many(items))
        open_ids = self._open_command_ids(items)
        act = menu.addAction(f"▶ Chạy tiếp việc kẹt/lỗi ({len(open_ids['resumable'])})")
        act.setEnabled(bool(open_ids["resumable"]))
        act.triggered.connect(lambda: self._bulk_resume(open_ids["resumable"]))
        act = menu.addAction(f"✕ Huỷ việc đang mở ({len(open_ids['open'])})")
        act.setEnabled(bool(open_ids["open"]))
        act.triggered.connect(lambda: self._bulk_cancel(open_ids["open"]))
        profile_ids = sorted({int(d["profile_id"]) for d in items if d.get("profile_id") is not None})
        act = menu.addAction(f"🌐 Mở trình duyệt ({len(profile_ids)} hồ sơ)")
        act.setEnabled(bool(profile_ids))
        act.triggered.connect(lambda: [self.open_browser_requested.emit(pid) for pid in profile_ids])
        menu.addSeparator()
        act = menu.addAction(f"⏸ Tạm dừng {len(profile_ids)} hồ sơ")
        act.triggered.connect(lambda: self._set_paused_many(profile_ids, True))
        act = menu.addAction(f"▶ Bỏ tạm dừng {len(profile_ids)} hồ sơ")
        act.triggered.connect(lambda: self._set_paused_many(profile_ids, False))
        menu.addSeparator()
        act = menu.addAction("☑ Chọn tất cả kênh")
        act.triggered.connect(self.select_all_channels)
        act = menu.addAction("☐ Bỏ chọn")
        act.triggered.connect(self.clear_selection)
        return menu

    def _open_command_ids(self, items: list[dict]) -> dict:
        resumable, opened = [], []
        for data in items:
            for command in self._commands_for(data):
                cid = str(command.get("id"))
                status = command.get("status")
                if status in ("needs_user", "failed", "interrupted") and cid not in resumable:
                    resumable.append(cid)
                if status in ("queued", "waiting_muse", "running", "needs_user") and cid not in opened:
                    opened.append(cid)
        return {"resumable": resumable, "open": opened}

    def _bulk_resume(self, ids):
        from .. import command_actions

        command_actions.bulk_resume(self._store, ids)
        self.data_changed.emit()

    def _bulk_cancel(self, ids):
        from .. import command_actions

        if QMessageBox.question(self, "Huỷ hàng loạt", f"Huỷ {len(ids)} việc đang mở của các kênh đã chọn?") \
                != QMessageBox.StandardButton.Yes:
            return

        def cancel_one(row):
            if row["status"] == "running":
                return False
            self._store.finish_command(row["id"], "failed", result="Đã huỷ bởi người dùng.",
                                       error="Đã huỷ bởi người dùng.")
            return True

        command_actions.bulk_cancel(self._store, ids, cancel_one)
        self.data_changed.emit()

    def _set_paused_many(self, profile_ids, paused: bool):
        for pid in profile_ids:
            try:
                self._store.set_profile_paused(int(pid), paused)
            except Exception:
                pass
        self.data_changed.emit()

    def _bulk_assign_selected(self):
        items = self.selected_channels_data()
        if items:
            self._open_assign_many(items)

    def _open_assign_many(self, items: list[dict]):
        if not items:
            return
        first, rest = items[0], items[1:]
        dialog = AssignDialog(
            self._store,
            agent=first.get("agent"),
            profile=first.get("profile"),
            channel=first.get("channel") or {},
            base=self._base,
            parent=self,
            extra_targets=[{"agent": d.get("agent"), "profile": d.get("profile"),
                            "channel": d.get("channel") or {}} for d in rest],
        )
        if dialog.exec() and dialog.created:
            self.commands_created.emit(len(dialog.created))

    def build_channel_menu(self, data: dict) -> QMenu:
        """Menu chuột phải của một thẻ kênh (tách riêng để kiểm thử
        được mà không cần mở menu thật)."""
        menu = QMenu(self)
        paused = bool((data.get("profile") or {}).get("paused"))
        assign_action = menu.addAction("📋 Giao việc cho kênh này…")
        assign_action.triggered.connect(lambda: self._open_assign(data))
        standing_action = menu.addAction("🤖 Việc Muse phải làm cho kênh…")
        standing_action.triggered.connect(
            lambda: self._open_standing(data)
        )
        progress_action = menu.addAction("📊 Xem tiến độ kênh")
        progress_action.triggered.connect(
            lambda: self.select_channel(str(data.get("channel_id")))
        )
        browser_action = menu.addAction("🌐 Mở trình duyệt của kênh")
        browser_action.triggered.connect(
            lambda: self.open_browser_requested.emit(
                int(data.get("profile_id"))
            )
        )
        menu.addSeparator()
        pause_action = menu.addAction(
            "▶ Bỏ tạm dừng kênh này" if paused else "⏸ Tạm dừng kênh này"
        )
        pause_action.triggered.connect(lambda: self._toggle_pause(data))
        return menu

    # ------------------------------------------------------------------ #
    # Hành động của menu
    # ------------------------------------------------------------------ #
    def _open_assign(self, data: dict):
        dialog = AssignDialog(
            self._store,
            agent=data.get("agent"),
            profile=data.get("profile"),
            channel=data.get("channel") or {},
            base=self._base,
            parent=self,
        )
        if dialog.exec() and dialog.created:
            self.commands_created.emit(len(dialog.created))

    def _open_standing(self, data: dict):
        dialog = StandingChecklistDialog(
            self._store,
            agent=data.get("agent"),
            profile=data.get("profile"),
            channel=data.get("channel") or {},
            base=self._base,
            parent=self,
        )
        if dialog.exec() and dialog.created:
            self.commands_created.emit(len(dialog.created))
        self.data_changed.emit()

    def _toggle_pause(self, data: dict):
        profile = data.get("profile") or {}
        profile_id = profile.get("id")
        if profile_id is None:
            return
        paused = bool(profile.get("paused"))
        channel_name = (data.get("channel") or {}).get("name") or "kênh"
        if paused:
            question = (
                f"Bỏ tạm dừng cho kênh {channel_name}?\n\n"
                "Cờ tạm dừng nằm ở cấp HỒ SƠ: bỏ dừng sẽ cho phép hồ sơ "
                f"{profile.get('label') or ''} nhận việc mới trở lại "
                "(mọi kênh thuộc hồ sơ này)."
            )
        else:
            question = (
                f"Tạm dừng kênh {channel_name}?\n\n"
                "App chưa có cờ tạm dừng riêng cho từng kênh — cờ này "
                "nằm ở cấp HỒ SƠ: tạm dừng sẽ chặn MỌI kênh thuộc hồ sơ "
                f"{profile.get('label') or ''} nhận việc mới (các lệnh "
                "đang chạy không bị cắt giữa chừng)."
            )
        answer = QMessageBox.question(self, "Tạm dừng kênh", question)
        if answer != QMessageBox.StandardButton.Yes:
            return
        self._store.set_profile_paused(int(profile_id), not paused)
        self.data_changed.emit()
