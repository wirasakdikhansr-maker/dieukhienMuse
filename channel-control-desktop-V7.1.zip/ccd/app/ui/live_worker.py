"""Luồng trực tiếp (live stream) từ Chrome của một hồ sơ qua CDP.

LiveStreamWorker chạy trong QThread riêng:
- Chụp khung hình bằng Page.captureScreenshot (JPEG) theo nhịp mục tiêu
  ~5 fps khi cửa sổ app đang được focus, ~1 fps khi không (adaptive).
- Nhận lệnh điều khiển từ UI qua hàng đợi thread-safe: click chuột, lăn
  chuột, phím bấm (quy đổi tỉ lệ -> toạ độ CSS bằng layout viewport thật),
  và yêu cầu đưa cửa sổ Chrome lên trước (Page.bringToFront).
- Báo URL trang hiện tại về UI mỗi giây để hiển thị trên khung live view.

Đây là luồng hình của CHÍNH cửa sổ Chrome thật của hồ sơ — cùng cửa sổ mà
nút "Đưa cửa sổ Chrome lên trước" mang ra ngoài màn hình.
"""

from __future__ import annotations

import queue
import time

from PySide6.QtCore import QThread, Signal

from ..cdp import AdaptiveQuality
from ..chrome_manager import ChromeManager


class LiveStreamWorker(QThread):
    frame = Signal(bytes)        # dữ liệu JPEG của khung hình
    status = Signal(str)         # thông báo trạng thái (lỗi/chưa kết nối...)
    page_url = Signal(str)       # URL trang hiện tại trong Chrome

    def __init__(
        self,
        profile: dict,
        manager: ChromeManager,
        fps_active: float = 5.0,
        fps_idle: float = 1.0,
        parent=None,
    ):
        # parent (cửa sổ chính) giữ quyền sở hữu Qt của QThread: wrapper
        # Python bị thu hồi KHÔNG được kéo theo việc huỷ C++ QThread khi
        # thread còn chạy (lỗi "QThread: Destroyed while thread is still
        # running" làm sập app). Vòng đời vẫn do MainWindow quản tường minh.
        super().__init__(parent)
        self._profile = profile
        self._manager = manager
        self._fps_active = max(0.5, fps_active)
        self._fps_idle = max(0.2, fps_idle)
        self._active = True
        self._stopped = False
        self._commands: queue.Queue = queue.Queue()
        self._css_size: tuple[float, float] | None = None
        # Chất lượng JPEG thích ứng (V3.1): chụp chậm -> hạ chất lượng
        # để giữ nhịp; máy khoẻ -> tự nâng lại. Xem app.cdp.AdaptiveQuality.
        self._adaptive = AdaptiveQuality(target_interval=1.0 / self._fps_active)

    # ---------------- API cho UI thread (thread-safe) ------------------ #
    def stop(self):
        self._stopped = True

    def set_active(self, active: bool):
        """True khi cửa sổ app đang được focus -> nhịp fps cao."""
        self._active = active

    def request_front(self):
        self._commands.put(("front", None))

    def send_mouse_click(self, x_ratio: float, y_ratio: float):
        self._commands.put(("click", (x_ratio, y_ratio)))

    def send_mouse_wheel(self, x_ratio: float, y_ratio: float, delta_y: int):
        self._commands.put(("wheel", (x_ratio, y_ratio, delta_y)))

    def send_key(self, cdp_params: dict):
        self._commands.put(("key", cdp_params))

    # ---------------- Vòng lặp trong thread ---------------------------- #
    def run(self):
        client = None
        last_url_check = 0.0
        last_metrics_check = 0.0
        last_url = None
        while not self._stopped:
            frame_started = time.time()
            try:
                if client is None:
                    client = self._manager.connect_page(self._profile)
                    client.call("Page.enable")
                    self._css_size = None
                    last_metrics_check = 0.0
                self._drain_commands(client)
                if frame_started - last_metrics_check > 2.0:
                    last_metrics_check = frame_started
                    self._refresh_css_size(client)
                capture_started = time.time()
                result = client.call(
                    "Page.captureScreenshot",
                    {
                        "format": "jpeg",
                        "quality": self._adaptive.quality(),
                        "fromSurface": True,
                    },
                )
                self._adaptive.note_frame(time.time() - capture_started)
                import base64

                self.frame.emit(base64.b64decode(result["data"]))
                if frame_started - last_url_check > 1.0:
                    last_url_check = frame_started
                    url = client.evaluate("location.href")
                    if url and url != last_url:
                        last_url = url
                        self.page_url.emit(url)
            except Exception as exc:
                if client is not None:
                    client.close()
                    client = None
                self.status.emit(f"Chưa xem được Chrome của hồ sơ: {exc}")
                time.sleep(1.0)
            # Nhịp khung hình thích ứng (adaptive)
            interval = 1.0 / (self._fps_active if self._active else self._fps_idle)
            elapsed = time.time() - frame_started
            time.sleep(max(0.0, interval - elapsed))
        if client is not None:
            client.close()

    def _refresh_css_size(self, client):
        try:
            metrics = client.call("Page.getLayoutMetrics")
            viewport = metrics.get("cssVisualViewport") or metrics.get("layoutViewport") or {}
            width = viewport.get("clientWidth")
            height = viewport.get("clientHeight")
            if width and height:
                self._css_size = (float(width), float(height))
        except Exception:
            pass

    def _to_page_coords(self, x_ratio: float, y_ratio: float) -> tuple[float, float] | None:
        if self._css_size is None:
            return None
        width, height = self._css_size
        return x_ratio * width, y_ratio * height

    def _drain_commands(self, client):
        while True:
            try:
                kind, payload = self._commands.get_nowait()
            except queue.Empty:
                return
            try:
                if kind == "front":
                    client.bring_to_front()
                elif kind == "click":
                    coords = self._to_page_coords(*payload)
                    if coords is None:
                        continue
                    x, y = coords
                    base = {"x": x, "y": y, "button": "left", "clickCount": 1}
                    client.call("Input.dispatchMouseEvent", {"type": "mousePressed", **base})
                    client.call("Input.dispatchMouseEvent", {"type": "mouseReleased", **base})
                elif kind == "wheel":
                    x_ratio, y_ratio, delta_y = payload
                    coords = self._to_page_coords(x_ratio, y_ratio)
                    if coords is None:
                        continue
                    x, y = coords
                    client.call(
                        "Input.dispatchMouseEvent",
                        {"type": "mouseWheel", "x": x, "y": y, "deltaX": 0, "deltaY": float(delta_y)},
                    )
                elif kind == "key":
                    client.call("Input.dispatchKeyEvent", payload)
            except Exception:
                # Lệnh điều khiển lỗi không được làm gãy luồng xem.
                pass
