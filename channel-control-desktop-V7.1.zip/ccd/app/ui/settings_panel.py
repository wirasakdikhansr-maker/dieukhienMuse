"""Panel "Cài đặt" (V3.1) — chia TAB theo mảng, như người dùng yêu cầu:

- **Chung**: hành vi khi thoát app...
- **Trình duyệt & Nhúng**: đường dẫn Chrome (ép tay / tự dò), nhịp
  luồng trực tiếp, tự mở trình duyệt khi mở app.
- **Cầu nối Muse**: cổng Agent API, chỉ-nghe-localhost, token (che,
  có nút hiện + sinh lại). Đổi các mục này → app khởi động lại cầu nối
  ngay khi Lưu.
- **Dữ liệu**: thư mục dữ liệu, toàn vẹn kho, xuất kênh/nhật ký
  (JSON/CSV).
- **Giao diện**: trạng thái mặc định của thanh điều hướng / cột hồ sơ /
  dock dưới (áp dụng ngay khi Lưu và nhớ cho lần mở sau).

Panel chỉ sửa dict settings dùng chung + gọi callback
``apply_settings(changed_keys)``; cửa sổ chính lo lưu file và áp dụng
hệ quả (đổi override Chrome, khởi động lại Agent API, bố cục...).
"""

from __future__ import annotations

import secrets

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from .. import config
from ..store import Store
from . import theme


def _valid_hhmm(text: str) -> str:
    import re

    match = re.match(r"^\s*(\d{1,2}):(\d{2})\s*$", text or "")
    if not match or int(match.group(1)) > 23 or int(match.group(2)) > 59:
        return "08:00"
    return f"{int(match.group(1)):02d}:{match.group(2)}"


class SettingsPanel(QWidget):
    def __init__(self, store: Store, settings: dict, apply_settings=None,
                 agent_status=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._apply = apply_settings or (lambda _changed: "")
        self._agent_status = agent_status or (lambda: "Cầu nối chưa chạy.")
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(8)
        root.addWidget(theme.section_header("Cài đặt"))

        self.tabs = QTabWidget()
        self.tabs.addTab(self._scrolled(self._tab_general()), "Chung")
        self.tabs.addTab(self._scrolled(self._tab_browser()), "Trình duyệt và Nhúng")
        self.tabs.addTab(self._scrolled(self._tab_bridge()), "Cầu nối Muse")
        self.tabs.addTab(self._scrolled(self._tab_supervision()), "Giám sát chéo")
        self.tabs.addTab(self._tab_rules(), "📏 Quy tắc · KPI")
        self.tabs.addTab(self._scrolled(self._tab_automation_v63()), "⚙ Tự vận hành")
        self.tabs.addTab(self._scrolled(self._tab_data()), "Dữ liệu")
        self.tabs.addTab(self._scrolled(self._tab_ui()), "Giao diện")
        root.addWidget(self.tabs, 1)

        footer = QHBoxLayout()
        self.status_label = theme.muted_label("")
        footer.addWidget(self.status_label, 1)
        save_button = QPushButton("Lưu cài đặt")
        save_button.setProperty("variant", "primary")
        save_button.clicked.connect(self._on_save)
        footer.addWidget(save_button)
        root.addLayout(footer)

    # ---- Tab Chung ---------------------------------------------------- #
    def _tab_general(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        self.keep_chrome_check = QCheckBox(
            "Giữ Chrome mở khi đóng app (khuyến nghị)"
        )
        self.keep_chrome_check.setToolTip(
            "Bật: đóng app KHÔNG tắt các cửa sổ Chrome của hồ sơ "
            "(phiên đăng nhập được giữ ấm). Tắt: app tắt luôn những "
            "Chrome do chính nó mở."
        )
        layout.addWidget(self.keep_chrome_check)
        # V4.0 (H4.2): tự khởi động cùng Windows — mặc định TẮT, bật
        # là app ghi khoá Run (HKCU) và mở vào thẳng tray lần sau.
        self.autostart_check = QCheckBox(
            "Tự khởi động cùng Windows (mở vào khay hệ thống)"
        )
        layout.addWidget(self.autostart_check)
        # V5.3 (A6): đoạn giải thích dưới hai ô tick đã BỎ (nội dung
        # nằm ở tooltip của ô Giữ Chrome).
        layout.addStretch(1)
        return page

    # ---- Tab Trình duyệt & Nhúng --------------------------------------- #
    def _tab_browser(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        layout.addWidget(theme.muted_label("Đường dẫn Chrome (để trống = tự dò):"))
        row = QHBoxLayout()
        self.chrome_path_edit = QLineEdit()
        self.chrome_path_edit.setPlaceholderText("Tự dò khi để trống")
        row.addWidget(self.chrome_path_edit, 1)
        detect = QPushButton("Tự động dò")
        detect.clicked.connect(self._on_detect_chrome)
        row.addWidget(detect)
        browse = QPushButton("Chọn file…")
        browse.clicked.connect(self._on_browse_chrome)
        row.addWidget(browse)
        layout.addLayout(row)
        # V5.3 (A6): ghi chú kỹ thuật về cờ mở Chrome đã BỎ (chi
        # tiết nội bộ, không phải nhãn trường/trạng thái).

        fps_row = QHBoxLayout()
        fps_row.setSpacing(10)
        fps_row.addWidget(theme.muted_label("Luồng trực tiếp — fps khi đang xem:"))
        self.fps_active_spin = QDoubleSpinBox()
        self.fps_active_spin.setRange(0.5, 15.0)
        self.fps_active_spin.setSingleStep(0.5)
        fps_row.addWidget(self.fps_active_spin)
        fps_row.addWidget(theme.muted_label("fps khi để nền:"))
        self.fps_idle_spin = QDoubleSpinBox()
        self.fps_idle_spin.setRange(0.2, 5.0)
        self.fps_idle_spin.setSingleStep(0.2)
        fps_row.addWidget(self.fps_idle_spin)
        fps_row.addStretch(1)
        layout.addLayout(fps_row)

        self.auto_open_check = QCheckBox("Tự mở trình duyệt các hồ sơ khi mở app")
        layout.addWidget(self.auto_open_check)
        self.embed_always_check = QCheckBox(
            "Luôn nhúng trình duyệt vào app khi chạy (không mở cửa sổ Chrome riêng)"
        )
        self.embed_always_check.setToolTip(
            "Bật: Chrome của hồ sơ đang chọn tự nhúng thẳng vào khung xem "
            "của app ngay khi chạy; đổi hồ sơ thì cửa sổ cũ tự thu nhỏ về "
            "taskbar. Tắt: dùng Luồng trực tiếp / bấm Nhúng thủ công như trước."
        )
        layout.addWidget(self.embed_always_check)
        # V5.3 (A8): chế độ CHẠY ẨN NGOÀI APP — ngoại lệ do chủ
        # kênh trực tiếp ra lệnh cho quy tắc chỉ-nhúng: BẬT thì
        # trình duyệt mở ở cửa sổ riêng/thu nhỏ, app không nhúng
        # (khung nhúng/tường hiện trạng thái đang chạy ẩn), điều
        # khiển qua CDP vẫn nguyên vẹn. Ô tick nhanh cùng tên nằm
        # trên thanh công cụ của tab Hồ sơ.
        self.hidden_mode_check = QCheckBox(
            "Chạy ẩn ngoài app — không nhúng (trình duyệt chạy cửa sổ riêng/thu nhỏ)"
        )
        self.hidden_mode_check.setToolTip(
            "Bật: trình duyệt của các hồ sơ mở dạng cửa sổ riêng "
            "thu nhỏ, app KHÔNG nhúng vào khung xem/tường — đổi "
            "lại là tốc độ và các Muse không tranh nhau một "
            "khung nhúng chung. Tắt: nhúng vào app như mặc định."
        )
        layout.addWidget(self.hidden_mode_check)
        layout.addStretch(1)
        return page

    # ---- Tab Cầu nối Muse -------------------------------------------- #
    def _tab_bridge(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)

        port_row = QHBoxLayout()
        port_row.addWidget(theme.muted_label("Cổng Agent API:"))
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        port_row.addWidget(self.port_spin)
        port_row.addStretch(1)
        layout.addLayout(port_row)

        self.localhost_check = QCheckBox(
            "Chỉ nghe localhost (127.0.0.1) — an toàn hơn, tắt điều khiển qua Tailscale"
        )
        layout.addWidget(self.localhost_check)

        layout.addWidget(theme.muted_label("Token cầu nối (X-Agent-Token):"))
        token_row = QHBoxLayout()
        self.token_edit = QLineEdit()
        self.token_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.token_edit.setReadOnly(True)
        token_row.addWidget(self.token_edit, 1)
        self.show_token_button = QPushButton("Hiện")
        self.show_token_button.setCheckable(True)
        self.show_token_button.toggled.connect(self._on_toggle_token)
        token_row.addWidget(self.show_token_button)
        regen = QPushButton("Sinh token mới")
        regen.clicked.connect(self._on_regen_token)
        token_row.addWidget(regen)
        layout.addLayout(token_row)

        self.bridge_status_label = theme.muted_label("")
        layout.addWidget(self.bridge_status_label)
        # V5.3 (A6): đoạn hướng dẫn "đổi rồi bấm Lưu…" đã BỎ — hệ
        # quả áp dụng hiện ngay ở dòng trạng thái dưới chân panel;
        # cảnh báo token mới đã có trong hộp xác nhận Sinh token.

        # V4.0 — Vòng tự động cho lệnh chờ Muse (dispatcher + sweeper
        # lease chạy TRONG tiến trình cầu nối này): tắt cầu nối ở cấu
        # hình (agent_enabled) là tắt luôn vòng tự động phía Muse.
        layout.addWidget(theme.section_header("Tự động hoá lệnh Muse (V4.0)"))
        self.full_auto_check = QCheckBox(
            "Bật vòng tự động: dispatcher xét điều kiện + sweeper thu hồi lease"
        )
        layout.addWidget(self.full_auto_check)
        lease_row = QHBoxLayout()
        lease_row.addWidget(theme.muted_label("Hạn lease (giây):"))
        self.lease_spin = QSpinBox()
        self.lease_spin.setRange(30, 3600)
        lease_row.addWidget(self.lease_spin)
        lease_row.addWidget(theme.muted_label("Số lần giữ lệnh tối đa:"))
        self.attempts_spin = QSpinBox()
        self.attempts_spin.setRange(1, 10)
        lease_row.addWidget(self.attempts_spin)
        lease_row.addWidget(theme.muted_label("Cảnh báo chờ (phút):"))
        self.wait_alert_spin = QSpinBox()
        self.wait_alert_spin.setRange(1, 240)
        lease_row.addWidget(self.wait_alert_spin)
        lease_row.addStretch(1)
        layout.addLayout(lease_row)
        # V5.3 (A6): ghi chú nội bộ về dispatcher/sweeper đã BỎ.
        layout.addStretch(1)
        return page

    # ---- Tab Dữ liệu ---------------------------------------------------- #
    def _tab_data(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        self.data_dir_label = theme.muted_label("")
        layout.addWidget(self.data_dir_label)
        self.integrity_label = theme.muted_label("")
        layout.addWidget(self.integrity_label)

        layout.addWidget(theme.section_header("Xuất dữ liệu"))
        export_row = QHBoxLayout()
        export_row.setSpacing(8)
        for text, kind, fmt in (
            ("Kênh → JSON", "channels", "json"),
            ("Kênh → CSV", "channels", "csv"),
            ("Nhật ký → JSON", "journal", "json"),
            ("Nhật ký → CSV", "journal", "csv"),
        ):
            button = QPushButton(text)
            button.clicked.connect(
                lambda _=False, k=kind, f=fmt: self._on_export(k, f)
            )
            export_row.addWidget(button)
        export_row.addStretch(1)
        layout.addLayout(export_row)
        layout.addStretch(1)
        return page

    # ---- Tab Giao diện -------------------------------------------------- #
    def _tab_ui(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        self.rail_collapsed_check = QCheckBox(
            "Thanh điều hướng thu gọn (chỉ icon) khi mở app"
        )
        layout.addWidget(self.rail_collapsed_check)
        self.profile_column_check = QCheckBox("Hiện cột hồ sơ khi mở app")
        layout.addWidget(self.profile_column_check)
        self.dock_expanded_check = QCheckBox(
            "Dock dưới (Kênh / Nhật ký / Hàng đợi) mở sẵn khi mở app"
        )
        layout.addWidget(self.dock_expanded_check)
        # V6.8: hình agent trong Văn phòng 3D (mẫu nhân vật / màu / kích thước)
        layout.addWidget(theme.section_header("Hình agent trong Văn phòng 3D"))
        avatar_row = QHBoxLayout()
        self.avatar_button = QPushButton("🎨 Giao diện văn phòng && hình agent 3D…")
        self.avatar_button.clicked.connect(self._open_avatar_dialog)
        avatar_row.addWidget(self.avatar_button)
        self.avatar_summary = theme.muted_label("")
        avatar_row.addWidget(self.avatar_summary, 1)
        layout.addLayout(avatar_row)
        self._sync_avatar_summary()
        # V5.3 (A6): đoạn giải thích dưới ba ô tick đã BỎ.
        # V5.3.1 (M2 — góp ý máy thật): kích thước ô tường trình
        # duyệt + độ cao nút hàng lệnh chỉnh ĐƯỢC tại đây (trước
        # là hằng số cứng trong code). Dải chặn khớp helper đọc
        # (browser_wall.tile_size / theme.row_action_height).
        layout.addWidget(theme.section_header("Kích thước hiển thị"))
        tile_row = QHBoxLayout()
        tile_row.setSpacing(10)
        tile_row.addWidget(theme.muted_label("Ô tường trình duyệt — rộng (px):"))
        self.wall_tile_width_spin = QSpinBox()
        self.wall_tile_width_spin.setRange(320, 1200)
        self.wall_tile_width_spin.setSingleStep(20)
        tile_row.addWidget(self.wall_tile_width_spin)
        tile_row.addWidget(theme.muted_label("cao (px):"))
        self.wall_tile_height_spin = QSpinBox()
        self.wall_tile_height_spin.setRange(240, 1200)
        self.wall_tile_height_spin.setSingleStep(20)
        tile_row.addWidget(self.wall_tile_height_spin)
        tile_row.addStretch(1)
        layout.addLayout(tile_row)
        button_row = QHBoxLayout()
        button_row.setSpacing(10)
        button_row.addWidget(theme.muted_label("Độ cao nút hàng lệnh (px):"))
        self.row_action_height_spin = QSpinBox()
        self.row_action_height_spin.setRange(20, 36)
        button_row.addWidget(self.row_action_height_spin)
        button_row.addStretch(1)
        layout.addLayout(button_row)
        layout.addStretch(1)
        return page

    # ------------------------------------------------------------------ #
    # ---- Tab Giám sát chéo (V6.0) ------------------------------------- #
    # ------------------------------------------------------------------ #
    # V6.3 — Quy tắc & KPI
    # ------------------------------------------------------------------ #
    KPI_FIELDS = (
        ("agent_on_time_pct", "Nhân viên: % việc xong ĐÚNG HẠN tối thiểu", 0, 100, " %"),
        ("agent_first_pass_pct", "Nhân viên: % việc ĐẠT ngay lần chấm đầu", 0, 100, " %"),
        ("agent_min_done_week", "Nhân viên: số việc xong tối thiểu / tuần", 0, 500, " việc"),
        ("agent_max_stuck", "Nhân viên: số lần bị bắt treo tối đa / tuần", 0, 50, " lần"),
        ("agent_max_needs_user", "Nhân viên: số việc đẩy cho người dùng tối đa", 0, 50, " việc"),
        ("agent_chat_reply_minutes", "Nhân viên: thời gian trả lời chat tối đa", 1, 240, " phút"),
        ("lead_review_minutes", "Giám sát: thời gian chấm một việc tối đa", 1, 240, " phút"),
        ("lead_team_on_time_pct", "Giám sát: % đúng hạn của cả đội tối thiểu", 0, 100, " %"),
        ("lead_auto_fix_pct", "Giám sát: % sự cố TỰ xử lý tối thiểu", 0, 100, " %"),
        ("pass_score", "Điểm KPI tối thiểu để 'Đạt'", 0, 100, " điểm"),
        ("lead_replace_after", "Thay trưởng phòng sau N lần chấm (mỗi giờ) dưới ngưỡng", 1, 48, " lần"),
    )

    def _tab_rules(self) -> QWidget:
        from .. import kpi

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setStyleSheet(
            f"QScrollArea, QScrollArea > QWidget > QWidget {{ background: {theme.BG}; }}"
        )
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        intro = theme.muted_label(
            "Bộ quy tắc được gửi kèm MỌI lệnh cho Muse (trường 'rules' + GET /api/rules). "
            "Để trống = dùng bộ mặc định. KPI chấm tự động theo dữ liệu thật trong app "
            "(tab Giám sát → KPI)."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)
        self.kpi_enforce_check = QCheckBox("Quy tắc là BẮT BUỘC (Muse phải hoàn thành trong khả năng được giao)")
        layout.addWidget(self.kpi_enforce_check)
        layout.addWidget(theme.section_header("Quy tắc cho NHÂN VIÊN (tài khoản Muse làm việc)"))
        self.rules_agent_edit = QPlainTextEdit()
        self.rules_agent_edit.setPlaceholderText(kpi.DEFAULT_AGENT_RULES)
        self.rules_agent_edit.setMinimumHeight(170)
        layout.addWidget(self.rules_agent_edit)
        layout.addWidget(theme.section_header("Quy tắc cho GIÁM SÁT (trưởng phòng / người chấm)"))
        self.rules_supervisor_edit = QPlainTextEdit()
        self.rules_supervisor_edit.setPlaceholderText(kpi.DEFAULT_SUPERVISOR_RULES)
        self.rules_supervisor_edit.setMinimumHeight(150)
        layout.addWidget(self.rules_supervisor_edit)
        buttons = QHBoxLayout()
        fill = QPushButton("📄 Điền bộ mặc định để sửa")
        fill.clicked.connect(self._fill_default_rules)
        buttons.addWidget(fill)
        clear = QPushButton("↺ Dùng lại mặc định (xoá bản sửa)")
        clear.clicked.connect(lambda: (self.rules_agent_edit.clear(), self.rules_supervisor_edit.clear()))
        buttons.addWidget(clear)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        layout.addWidget(theme.section_header("Chỉ tiêu KPI"))
        self.kpi_spins: dict[str, QSpinBox] = {}
        for key, label, lo, hi, suffix in self.KPI_FIELDS:
            row = QHBoxLayout()
            text = QLabel(label)
            text.setMinimumWidth(420)
            row.addWidget(text)
            spin = QSpinBox()
            spin.setRange(lo, hi)
            spin.setSuffix(suffix)
            row.addWidget(spin)
            row.addStretch(1)
            layout.addLayout(row)
            self.kpi_spins[key] = spin
        layout.addStretch(1)
        scroll.setWidget(page)
        return scroll

    def _fill_default_rules(self):
        from .. import kpi

        if not self.rules_agent_edit.toPlainText().strip():
            self.rules_agent_edit.setPlainText(kpi.DEFAULT_AGENT_RULES.strip())
        if not self.rules_supervisor_edit.toPlainText().strip():
            self.rules_supervisor_edit.setPlainText(kpi.DEFAULT_SUPERVISOR_RULES.strip())

    def _tab_automation_v63(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        layout.addWidget(theme.section_header("Trưởng phòng tự vận hành"))
        self.lead_auto_fix_check = QCheckBox("Trưởng phòng TỰ xử lý sự cố trong phạm vi cho phép (không chờ người dùng)")
        layout.addWidget(self.lead_auto_fix_check)
        self.lead_auto_replace_check = QCheckBox("Tự THAY trưởng phòng khi KPI dưới ngưỡng liên tiếp")
        layout.addWidget(self.lead_auto_replace_check)

        def spin_row(label, lo, hi, suffix):
            row = QHBoxLayout()
            row.addWidget(QLabel(label))
            spin = QSpinBox()
            spin.setRange(lo, hi)
            spin.setSuffix(suffix)
            row.addWidget(spin)
            row.addStretch(1)
            layout.addLayout(row)
            return spin

        self.lead_extend_spin = spin_row("Gia hạn tối đa một lần cho việc trễ hạn:", 5, 600, " phút")
        self.lead_retries_spin = spin_row("Số lần tự thử lại lệnh lỗi tạm thời:", 0, 10, " lần")
        # V7.0: trưởng phòng TRẢ LỜI THAY chủ kênh mọi câu hỏi của agent
        self.lead_answers_check = QCheckBox("Trưởng phòng tự trả lời MỌI câu hỏi của agent thay bạn "
                                            "(chỉ mã 2FA/OTP, mật khẩu, thanh toán mới hỏi bạn)")
        layout.addWidget(self.lead_answers_check)
        # V7.0.1: trưởng phòng TỰ GIAO VIỆC đều cho mọi agent
        self.lead_autoplan_check = QCheckBox("Trưởng phòng TỰ LÊN KẾ HOẠCH & GIAO VIỆC cho mọi kênh (chia đều agent, "
                                             "chống trùng chủ đề, chuẩn kiếm tiền, không spam — chỉ trong giờ làm việc)")
        layout.addWidget(self.lead_autoplan_check)
        self.plan_yt_spin = spin_row("Số video mới / kênh YouTube / ngày:", 0, 10, " video")
        self.plan_fb_spin = spin_row("Số bài/Reels mới / fanpage / ngày:", 0, 10, " bài")
        self.plan_tt_spin = spin_row("Số video mới / kênh TikTok / ngày:", 0, 10, " video")
        self.plan_gap_spin = spin_row("Giãn cách tối thiểu giữa 2 việc nội dung của một kênh:", 1, 48, " giờ")
        self.plan_max_open_spin = spin_row("Tối đa việc đang mở mỗi agent (đủ thì chuyển người rảnh):", 1, 20, " việc")
        layout.addWidget(QLabel("Chính sách tự quyết (trưởng phòng & agent dựa vào đây khi phải quyết thay bạn):"))
        from PySide6.QtWidgets import QPlainTextEdit as _PTE

        self.lead_policy_edit = _PTE()
        self.lead_policy_edit.setMinimumHeight(150)
        layout.addWidget(self.lead_policy_edit)
        layout.addWidget(theme.section_header("Chat & trình duyệt"))
        self.chat_push_check = QCheckBox("Chat trực tiếp muse.ai: gõ tin + giao việc thẳng vào chat muse.ai của tài khoản, đọc câu trả lời ngay trên trang (không cần phiếu/connector)")
        layout.addWidget(self.chat_push_check)
        self.auto_reconnect_check = QCheckBox("Tự nối lại: phiên muse.ai văng thì tự đăng nhập lại (tinyhost), cầu nối không phản hồi thì tự khởi động lại")
        layout.addWidget(self.auto_reconnect_check)
        self.idle_close_spin = spin_row("Tự tắt Chrome hồ sơ không ai dùng sau (0 = không tắt):", 0, 600, " phút")
        self.muse_idle_spin = spin_row("Tự tắt Chrome muse.ai của Muse rảnh sau (0 = không tắt):", 0, 600, " phút")
        self.muse_max_spin = spin_row("Tối đa số Chrome muse.ai mở cùng lúc (dư thì tắt cái lâu chưa dùng):", 1, 100, " trình duyệt")
        self.muse_headless_check = QCheckBox("Chrome muse.ai của cầu nối chat chạy KHÔNG CỬA SỔ (không hiện gì trên màn hình/taskbar; đăng nhập thì tự mở cửa sổ)")
        layout.addWidget(self.muse_headless_check)
        self.automation_overlay_check = QCheckBox("Hiện chỉ dẫn trên trang khi Muse thao tác (dải 'bước i/n' + vòng tròn tại điểm bấm)")
        layout.addWidget(self.automation_overlay_check)
        self.automation_follow_check = QCheckBox("Tự đưa trình duyệt đang bị Muse điều khiển lên khung xem (không giật khi bạn đang thao tác)")
        layout.addWidget(self.automation_follow_check)
        self.automation_kickoff_check = QCheckBox("Giao việc xong → app MỞ SẴN trình duyệt đúng kênh (Studio / page / TikTok Studio) "
                                                  "và gửi ảnh trang cho Muse để Muse thao tác trực tiếp trên trình duyệt local")
        layout.addWidget(self.automation_kickoff_check)
        self.stream_view_check = QCheckBox("Xem trình duyệt bằng LƯỚI TRỰC TIẾP khi có ≥2 trình duyệt (chạy nền kích thước cố định, "
                                           "không nhúng, không che nhau — Muse điều khiển không vướng)")
        layout.addWidget(self.stream_view_check)
        layout.addWidget(theme.section_header("Báo cáo hằng ngày"))
        self.daily_report_check = QCheckBox("Tự tạo báo cáo phân tích từng kênh theo từng tài khoản Muse mỗi ngày")
        layout.addWidget(self.daily_report_check)
        row = QHBoxLayout()
        row.addWidget(QLabel("Giờ tạo báo cáo (HH:MM):"))
        self.daily_report_time_edit = QLineEdit()
        self.daily_report_time_edit.setMaximumWidth(80)
        row.addWidget(self.daily_report_time_edit)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addWidget(theme.section_header("File lớn từ server Muse"))
        self.large_file_spin = spin_row("Trần dung lượng mỗi file nhận về:", 1, 500, " GB")
        layout.addStretch(1)
        return page

    def _tab_supervision(self) -> QWidget:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(8)
        self.supervision_enabled_check = QCheckBox(
            "Bật giám sát chéo giữa các tài khoản Muse"
        )
        self.supervision_enabled_check.setToolTip(
            "Bật: lệnh Muse chốt xong/thất bại (và lệnh nghi treo) "
            "tự sinh VIỆC KIỂM TRA giao cho một Muse khác chấm. "
            "Tắt: không sinh việc kiểm tra mới; vòng đang mở giữ nguyên."
        )
        layout.addWidget(self.supervision_enabled_check)

        def _spin_row(label_text, spin, hint):
            row = QHBoxLayout()
            row.addWidget(QLabel(label_text))
            row.addWidget(spin)
            row.addStretch(1)
            layout.addLayout(row)
            hint_label = theme.muted_label(hint)
            hint_label.setWordWrap(True)
            layout.addWidget(hint_label)

        self.supervision_stall_spin = QSpinBox()
        self.supervision_stall_spin.setRange(1, 120)
        self.supervision_stall_spin.setSuffix(" phút")
        _spin_row(
            "Lệnh đang chạy quá lâu không báo tiến độ thì coi là nghi treo:",
            self.supervision_stall_spin,
            "Watchdog trong app quét theo nhịp sẵn có; lệnh bị bắt treo "
            "sẽ sinh việc kiểm tra giao cho giám sát viên xử lý.",
        )
        self.supervision_sample_spin = QSpinBox()
        self.supervision_sample_spin.setRange(0, 100)
        self.supervision_sample_spin.setSuffix(" %")
        _spin_row(
            "Tỷ lệ lệnh XONG bị lấy mẫu kiểm tra:",
            self.supervision_sample_spin,
            "Lệnh THẤT BẠI luôn kiểm tra 100%; lệnh đã qua vòng làm "
            "lại luôn được kiểm tra lại bất kể tỷ lệ này.",
        )
        self.supervision_rounds_spin = QSpinBox()
        self.supervision_rounds_spin.setRange(0, 5)
        self.supervision_rounds_spin.setSuffix(" vòng")
        _spin_row(
            "Số vòng làm lại tối đa trước khi leo thang chủ kênh:",
            self.supervision_rounds_spin,
            "Quá số vòng này mà vẫn chưa đạt, kết luận tự chuyển "
            "thành 'Cần chủ kênh quyết định'.",
        )

        layout.addWidget(theme.section_header("Ma trận giám sát (ai chấm ai)"))
        matrix_hint = theme.muted_label(
            "Mặc định chấm vòng chéo theo thứ tự tài khoản (không ai "
            "tự chấm mình). Chọn một giám sát viên cụ thể để ghi đè "
            "cho từng người làm."
        )
        matrix_hint.setWordWrap(True)
        layout.addWidget(matrix_hint)
        self.matrix_container = QWidget()
        self.matrix_layout = QVBoxLayout(self.matrix_container)
        self.matrix_layout.setContentsMargins(0, 0, 0, 0)
        self.matrix_layout.setSpacing(6)
        layout.addWidget(self.matrix_container)
        self._matrix_combos: dict[int, QComboBox] = {}
        layout.addStretch(1)
        return page

    def _sync_avatar_summary(self):
        from . import avatars

        cfg = self._settings.get("office_avatar") or {}
        style = avatars.resolve_style(self._settings)
        extra = len((cfg.get("agents") or {})) + (1 if cfg.get("lead") else 0)
        self.avatar_summary.setText(
            f"Mặc định: {avatars.MODELS[style['model']]} · {int(style['size'] * 100)}%"
            + (f" · {extra} tuỳ chỉnh riêng" if extra else ""))

    def _open_avatar_dialog(self):
        from .avatar_dialog import AvatarDialog

        AvatarDialog(self._settings, self._store, self).exec()
        self._sync_avatar_summary()

    @staticmethod
    def _scrolled(page: QWidget) -> QWidget:
        """V6.5: mọi tab cài đặt cuộn được — nội dung dài không bị ép
        bẹp (combobox ma trận giám sát từng bị che chữ)."""
        if isinstance(page, QScrollArea):
            return page
        from PySide6.QtWidgets import QAbstractSpinBox

        for spin in page.findChildren(QAbstractSpinBox):
            # trong vùng cuộn ô số co về sizeHint → mũi tên ▲▼ bị che
            spin.setMinimumWidth(max(spin.minimumWidth(), 140))
            spin.setMinimumHeight(max(spin.minimumHeight(), 34))
        for combo in page.findChildren(QComboBox):
            combo.setMinimumHeight(max(combo.minimumHeight(), 34))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        scroll.setStyleSheet(
            f"QScrollArea, QScrollArea > QWidget > QWidget {{ background: {theme.BG}; }}"
        )
        scroll.setWidget(page)
        return scroll

    def _rebuild_matrix_editor(self):
        """Dựng lại các hàng chọn giám sát viên theo danh sách agent
        HIỆN TẠI (agent thêm/xoá thì dựng lại ở lần refresh sau)."""
        from .. import supervision

        while self.matrix_layout.count():
            item = self.matrix_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        self._matrix_combos = {}
        agents = [a for a in self._store.list_agents() if not a.get("revoked")]
        ring = supervision.default_ring([int(a["id"]) for a in agents])
        overrides = self._settings.get("supervision_matrix") or {}
        if len(agents) < 2:
            note = theme.muted_label(
                "Cần ít nhất 2 tài khoản Muse còn hiệu lực mới chấm "
                "chéo được (không ai tự chấm mình)."
            )
            note.setWordWrap(True)
            self.matrix_layout.addWidget(note)
            return
        for agent in agents:
            worker_id = int(agent["id"])
            row = QHBoxLayout()
            name = agent.get("name") or agent.get("email") or f"Muse #{worker_id}"
            label = QLabel(f"{name} — do ai chấm:")
            label.setMinimumWidth(240)
            row.addWidget(label)
            combo = QComboBox()
            # V6.5: đủ cao cho chữ + padding (bản cũ bị layout ép bẹp).
            combo.setMinimumHeight(36)
            combo.setMinimumWidth(280)
            default_supervisor = ring.get(worker_id)
            default_name = next(
                (a.get("name") or a.get("email") for a in agents
                 if int(a["id"]) == default_supervisor),
                "—",
            )
            combo.addItem(f"Tự động (vòng chéo → {default_name})", None)
            for other in agents:
                if int(other["id"]) == worker_id:
                    continue
                combo.addItem(
                    other.get("name") or other.get("email") or f"Muse #{other['id']}",
                    int(other["id"]),
                )
            chosen = overrides.get(str(worker_id), overrides.get(worker_id))
            if chosen is not None:
                index = combo.findData(int(chosen))
                if index >= 0:
                    combo.setCurrentIndex(index)
            row.addWidget(combo)
            row.addStretch(1)
            holder = QWidget()
            holder.setLayout(row)
            holder.setMinimumHeight(40)
            self.matrix_layout.addWidget(holder)
            self._matrix_combos[worker_id] = combo

    def refresh(self):
        s = self._settings
        self.keep_chrome_check.setChecked(bool(s.get("keep_chrome_open_on_exit", True)))
        self.autostart_check.setChecked(bool(s.get("autostart_windows")))
        self.full_auto_check.setChecked(bool(s.get("full_auto_enabled", True)))
        self.lease_spin.setValue(int(s.get("lease_seconds", 120)))
        self.attempts_spin.setValue(int(s.get("max_attempts", 3)))
        self.wait_alert_spin.setValue(int(s.get("wait_alert_minutes", 10)))
        self.chrome_path_edit.setText(str(s.get("chrome_path") or ""))
        self.fps_active_spin.setValue(float(s.get("live_fps_active", 5.0)))
        self.fps_idle_spin.setValue(float(s.get("live_fps_idle", 1.0)))
        # V5.3 (A7): mặc định MỚI là BẬT khi khoá chưa từng lưu.
        self.auto_open_check.setChecked(bool(s.get("auto_open_browsers_on_start", False)))
        self.hidden_mode_check.setChecked(bool(s.get("browsers_hidden_mode")))
        self.embed_always_check.setChecked(bool(s.get("embed_browser_always", True)))
        self.port_spin.setValue(int(s.get("agent_port", 19500)))
        self.localhost_check.setChecked(bool(s.get("agent_bind_localhost")))
        self.token_edit.setText(str(s.get("agent_token") or ""))
        self.bridge_status_label.setText(self._agent_status())
        self.data_dir_label.setText(f"Thư mục dữ liệu: {config.data_dir()}")
        try:
            integrity = self._store.integrity_check()
        except Exception as exc:
            integrity = f"lỗi: {exc}"
        self.integrity_label.setText(
            f"Toàn vẹn kho dữ liệu: {'OK' if integrity == 'ok' else integrity}"
        )
        self.rail_collapsed_check.setChecked(bool(s.get("ui_rail_collapsed")))
        self.profile_column_check.setChecked(bool(s.get("ui_profile_column_visible", True)))
        self.dock_expanded_check.setChecked(bool(s.get("ui_dock_expanded", True)))
        # V5.3.1 (M2): kích thước ô tường + độ cao nút hàng lệnh.
        # V6.0 — Giám sát chéo.
        self.supervision_enabled_check.setChecked(
            bool(s.get("supervision_enabled", True))
        )
        self.supervision_stall_spin.setValue(
            int(s.get("supervision_stall_minutes", 10))
        )
        self.supervision_sample_spin.setValue(
            int(s.get("supervision_sample_percent", 100))
        )
        self.supervision_rounds_spin.setValue(
            int(s.get("supervision_max_rounds", 2))
        )
        self._rebuild_matrix_editor()
        # V6.3 — Quy tắc & KPI + tự vận hành.
        from .. import kpi as _kpi

        self.kpi_enforce_check.setChecked(bool(s.get("kpi_enforce", True)))
        self.rules_agent_edit.setPlainText(str(s.get("rules_agent") or ""))
        self.rules_supervisor_edit.setPlainText(str(s.get("rules_supervisor") or ""))
        targets = _kpi.rules_settings(s)["targets"]
        for key, spin in self.kpi_spins.items():
            spin.setValue(int(targets.get(key, 0)))
        self.lead_auto_fix_check.setChecked(bool(s.get("lead_auto_fix", True)))
        self.lead_auto_replace_check.setChecked(bool(s.get("lead_auto_replace", True)))
        self.lead_extend_spin.setValue(int(s.get("lead_extend_minutes", 30)))
        self.lead_retries_spin.setValue(int(s.get("lead_max_auto_retries", 2)))
        from .. import lead_answer as _la

        self.lead_answers_check.setChecked(bool(s.get("lead_answers_questions", True)))
        from .. import lead_planner as _lp

        plan_cfg = _lp.cfg(s)
        self.lead_autoplan_check.setChecked(bool(plan_cfg["lead_autoplan"]))
        self.plan_yt_spin.setValue(int(plan_cfg["lead_plan_quota"].get("youtube", 1)))
        self.plan_fb_spin.setValue(int(plan_cfg["lead_plan_quota"].get("facebook", 1)))
        self.plan_tt_spin.setValue(int(plan_cfg["lead_plan_quota"].get("tiktok", 1)))
        self.plan_gap_spin.setValue(int(plan_cfg["lead_plan_min_gap_hours"]))
        self.plan_max_open_spin.setValue(int(plan_cfg["lead_plan_max_open"]))
        self.lead_policy_edit.setPlainText(_la.policy(s))
        self.chat_push_check.setChecked(bool(s.get("chat_push_to_muse", True)))
        self.auto_reconnect_check.setChecked(bool(s.get("auto_reconnect_muse", True)))
        self.idle_close_spin.setValue(int(s.get("browser_idle_close_minutes", 15)))
        self.muse_idle_spin.setValue(int(s.get("muse_idle_close_minutes", 10)))
        self.muse_max_spin.setValue(int(s.get("muse_max_browsers", 6)))
        self.muse_headless_check.setChecked(bool(s.get("muse_headless", True)))
        self.automation_overlay_check.setChecked(bool(s.get("automation_overlay", True)))
        self.automation_follow_check.setChecked(bool(s.get("automation_follow", True)))
        self.automation_kickoff_check.setChecked(bool(s.get("automation_kickoff", True)))
        self.stream_view_check.setChecked(str(s.get("browser_view_mode") or "stream") == "stream")
        self.daily_report_check.setChecked(bool(s.get("daily_report_enabled", True)))
        self.daily_report_time_edit.setText(str(s.get("daily_report_time") or "08:00"))
        self.large_file_spin.setValue(int(float(s.get("large_file_max_gb", 50) or 50)))
        self.wall_tile_width_spin.setValue(int(s.get("wall_tile_width", 600)))
        self.wall_tile_height_spin.setValue(int(s.get("wall_tile_height", 800)))
        self.row_action_height_spin.setValue(
            int(s.get("row_action_button_height", 24))
        )

    # ------------------------------------------------------------------ #
    def _gather(self) -> dict:
        return {
            "keep_chrome_open_on_exit": self.keep_chrome_check.isChecked(),
            "autostart_windows": self.autostart_check.isChecked(),
            "full_auto_enabled": self.full_auto_check.isChecked(),
            "lease_seconds": self.lease_spin.value(),
            "max_attempts": self.attempts_spin.value(),
            "wait_alert_minutes": self.wait_alert_spin.value(),
            "chrome_path": self.chrome_path_edit.text().strip(),
            "live_fps_active": self.fps_active_spin.value(),
            "live_fps_idle": self.fps_idle_spin.value(),
            "auto_open_browsers_on_start": self.auto_open_check.isChecked(),
            "embed_browser_always": self.embed_always_check.isChecked(),
            "browsers_hidden_mode": self.hidden_mode_check.isChecked(),
            "agent_port": self.port_spin.value(),
            "agent_bind_localhost": self.localhost_check.isChecked(),
            "agent_token": self.token_edit.text().strip(),
            "ui_rail_collapsed": self.rail_collapsed_check.isChecked(),
            "ui_profile_column_visible": self.profile_column_check.isChecked(),
            "ui_dock_expanded": self.dock_expanded_check.isChecked(),
            "supervision_enabled": self.supervision_enabled_check.isChecked(),
            "supervision_stall_minutes": self.supervision_stall_spin.value(),
            "supervision_sample_percent": self.supervision_sample_spin.value(),
            "supervision_max_rounds": self.supervision_rounds_spin.value(),
            "supervision_matrix": {
                str(worker_id): int(combo.currentData())
                for worker_id, combo in self._matrix_combos.items()
                if combo.currentData() is not None
            },
            "wall_tile_width": self.wall_tile_width_spin.value(),
            "wall_tile_height": self.wall_tile_height_spin.value(),
            "row_action_button_height": self.row_action_height_spin.value(),
            # V6.3
            "kpi_enforce": self.kpi_enforce_check.isChecked(),
            "rules_agent": self.rules_agent_edit.toPlainText().strip(),
            "rules_supervisor": self.rules_supervisor_edit.toPlainText().strip(),
            "kpi_targets": {key: spin.value() for key, spin in self.kpi_spins.items()},
            "lead_auto_fix": self.lead_auto_fix_check.isChecked(),
            "lead_auto_replace": self.lead_auto_replace_check.isChecked(),
            "lead_extend_minutes": self.lead_extend_spin.value(),
            "lead_max_auto_retries": self.lead_retries_spin.value(),
            "lead_answers_questions": self.lead_answers_check.isChecked(),
            "lead_autoplan": self.lead_autoplan_check.isChecked(),
            "lead_plan_quota": {"youtube": self.plan_yt_spin.value(), "facebook": self.plan_fb_spin.value(),
                                "tiktok": self.plan_tt_spin.value()},
            "lead_plan_min_gap_hours": self.plan_gap_spin.value(),
            "lead_plan_max_open": self.plan_max_open_spin.value(),
            "lead_policy": self.lead_policy_edit.toPlainText().strip(),
            "chat_push_to_muse": self.chat_push_check.isChecked(),
            "auto_reconnect_muse": self.auto_reconnect_check.isChecked(),
            "browser_idle_close_minutes": self.idle_close_spin.value(),
            "muse_idle_close_minutes": self.muse_idle_spin.value(),
            "muse_max_browsers": self.muse_max_spin.value(),
            "muse_headless": self.muse_headless_check.isChecked(),
            "automation_overlay": self.automation_overlay_check.isChecked(),
            "automation_follow": self.automation_follow_check.isChecked(),
            "automation_kickoff": self.automation_kickoff_check.isChecked(),
            "browser_view_mode": "stream" if self.stream_view_check.isChecked() else "embed",
            "daily_report_enabled": self.daily_report_check.isChecked(),
            "daily_report_time": _valid_hhmm(self.daily_report_time_edit.text()),
            "large_file_max_gb": self.large_file_spin.value(),
        }

    def _on_save(self):
        values = self._gather()
        changed = {
            key for key, value in values.items() if self._settings.get(key) != value
        }
        self._settings.update(values)
        message = self._apply(changed)
        self.status_label.setText(message or "Đã lưu cài đặt.")
        self.refresh()

    def _on_detect_chrome(self):
        found = config.find_chrome()
        if found:
            self.chrome_path_edit.setText(found)
            self.status_label.setText(f"Đã dò thấy Chrome: {found}")
        else:
            self.status_label.setText("Không dò thấy Chrome trên máy này.")

    def _on_browse_chrome(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Chọn file chạy Chrome", "", "Chương trình (*.exe);;Mọi file (*)"
        )
        if path:
            self.chrome_path_edit.setText(path)

    def _on_toggle_token(self, shown: bool):
        self.token_edit.setEchoMode(
            QLineEdit.EchoMode.Normal if shown else QLineEdit.EchoMode.Password
        )
        self.show_token_button.setText("Ẩn" if shown else "Hiện")

    def _on_regen_token(self):
        answer = QMessageBox.question(
            self,
            "Sinh token mới",
            "Token cũ sẽ mất hiệu lực ngay — phía Muse phải dùng token "
            "mới mới nối lại được. Tiếp tục?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        self.token_edit.setText(secrets.token_urlsafe(32))
        self.status_label.setText("Đã sinh token mới — bấm Lưu để áp dụng.")

    def _on_export(self, kind: str, fmt: str):
        try:
            text = (
                self._store.export_channels(fmt)
                if kind == "channels"
                else self._store.export_journal(fmt)
            )
        except Exception as exc:
            QMessageBox.warning(self, "Xuất dữ liệu", f"Xuất thất bại: {exc}")
            return
        default_name = f"ccd-{kind}.{fmt}"
        path, _ = QFileDialog.getSaveFileName(
            self, "Lưu file xuất", default_name, f"File {fmt.upper()} (*.{fmt})"
        )
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8", newline="") as handle:
                handle.write(text)
        except OSError as exc:
            QMessageBox.warning(self, "Xuất dữ liệu", f"Ghi file thất bại: {exc}")
            return
        self.status_label.setText(f"Đã xuất {kind} ({fmt.upper()}) → {path}")
