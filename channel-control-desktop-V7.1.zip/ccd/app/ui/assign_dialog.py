"""Hộp thoại Giao việc theo kênh (V5.0) + checklist thường trực.

Một editor dùng chung (:class:`ChecklistEditor`) cho cả hai hộp thoại:

- :class:`AssignDialog` — "Giao việc — kênh X": tick mẫu việc + chọn
  skill + ghi chú → tạo đúng N lệnh cho kênh/hồ sơ/agent đó.
- :class:`StandingChecklistDialog` — "Việc Muse phải làm cho kênh":
  cùng editor nhưng nạp/lưu checklist THƯỜNG TRỰC của kênh
  (``app.assignments``), kèm nút tạo việc ngay từ checklist.

Khối Skill: chọn skill sẵn có trong thư viện (``app.skills_lib``) —
nội dung skill được đính vào mọi lệnh của lượt giao; nhập skill MỚI
ngay tại đây bằng file .md hoặc dán nội dung (validate tại chỗ: file
không đọc được / nội dung rỗng → báo lỗi trong hộp thoại, không lưu).
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .. import assignments, skills_lib
from ..store import COMMAND_TYPE_LABELS
from . import theme

# Loại lệnh được phép dùng cho mẫu việc (bỏ nhóm CDP/studio_script —
# đó là lệnh kỹ thuật, không phải "việc cho kênh").
TEMPLATE_TYPES = (
    "create_video",
    "optimize",
    "upload",
    "free",
    "create_channel",
    "check",
    "scan",
    "open_browser",
)


class TemplateEditDialog(QDialog):
    """Thêm/sửa một mẫu việc: tên + loại lệnh + nội dung mẫu."""

    def __init__(self, template: dict | None = None, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Mẫu việc" if template else "Thêm mẫu việc")
        self.setMinimumWidth(460)
        layout = QVBoxLayout(self)
        layout.addWidget(theme.muted_label("Tên việc mẫu:"))
        self.title_edit = QLineEdit(template.get("title", "") if template else "")
        layout.addWidget(self.title_edit)
        layout.addWidget(theme.muted_label("Loại lệnh khi giao:"))
        self.type_combo = QComboBox()
        for type_key in TEMPLATE_TYPES:
            self.type_combo.addItem(
                COMMAND_TYPE_LABELS.get(type_key, type_key), type_key
            )
        if template:
            index = self.type_combo.findData(template.get("type") or "free")
            if index >= 0:
                self.type_combo.setCurrentIndex(index)
        layout.addWidget(self.type_combo)
        layout.addWidget(
            theme.muted_label(
                "Nội dung gửi cho Muse (biến {channel} = tên kênh):"
            )
        )
        self.instruction_edit = QPlainTextEdit(
            template.get("instruction", "") if template else ""
        )
        self.instruction_edit.setMinimumHeight(110)
        layout.addWidget(self.instruction_edit)
        self.error_label = theme.muted_label("")
        layout.addWidget(self.error_label)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Huỷ")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        save = QPushButton("💾 Lưu mẫu")
        save.clicked.connect(self._on_save)
        buttons.addWidget(save)
        layout.addLayout(buttons)
        self._template = template

    def _on_save(self):
        if not self.title_edit.text().strip():
            self.error_label.setText("⚠ Tên việc mẫu không được để trống.")
            return
        self.accept()

    def result_template(self, existing: list[dict]) -> dict:
        title = self.title_edit.text().strip()
        template_id = (
            self._template.get("id")
            if self._template
            else assignments.new_template_id(title, existing)
        )
        return {
            "id": template_id,
            "title": title,
            "type": self.type_combo.currentData() or "free",
            "instruction": self.instruction_edit.toPlainText().strip(),
        }


class PasteSkillDialog(QDialog):
    """Dán nội dung skill mới: đặt tên + thân Markdown."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Dán skill mới")
        self.setMinimumWidth(480)
        layout = QVBoxLayout(self)
        layout.addWidget(theme.muted_label("Tên skill:"))
        self.name_edit = QLineEdit()
        layout.addWidget(self.name_edit)
        layout.addWidget(theme.muted_label("Nội dung skill (Markdown):"))
        self.body_edit = QPlainTextEdit()
        self.body_edit.setMinimumHeight(160)
        layout.addWidget(self.body_edit)
        self.error_label = theme.muted_label("")
        layout.addWidget(self.error_label)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Huỷ")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        save = QPushButton("💾 Lưu vào thư viện")
        save.clicked.connect(self._on_save)
        buttons.addWidget(save)
        layout.addLayout(buttons)

    def _on_save(self):
        if not self.name_edit.text().strip():
            self.error_label.setText("⚠ Chưa đặt tên cho skill.")
            return
        if not self.body_edit.toPlainText().strip():
            self.error_label.setText("⚠ Nội dung skill đang rỗng.")
            return
        self.accept()


class ChecklistEditor(QWidget):
    """Editor dùng chung: checklist mẫu việc + khối Skill + ghi chú.

    ``base`` = thư mục dữ liệu của app (nơi có task_templates.json,
    channel_checklists.json và thư mục skills/).
    """

    changed = Signal()

    def __init__(self, base, parent=None):
        super().__init__(parent)
        self._base = Path(base) if base is not None else None
        self._templates: list[dict] = assignments.load_templates(self._base)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        layout.addWidget(theme.muted_label("CHECKLIST CÔNG VIỆC MẪU"))
        self.template_list = QListWidget()
        self.template_list.setMinimumHeight(150)
        self.template_list.itemChanged.connect(lambda _i: self.changed.emit())
        layout.addWidget(self.template_list)
        template_buttons = QHBoxLayout()
        add_button = QPushButton("＋ Thêm mẫu")
        add_button.clicked.connect(self._on_add_template)
        template_buttons.addWidget(add_button)
        edit_button = QPushButton("✏ Sửa mẫu")
        edit_button.clicked.connect(self._on_edit_template)
        template_buttons.addWidget(edit_button)
        delete_button = QPushButton("🗑 Xoá mẫu")
        delete_button.clicked.connect(self._on_delete_template)
        template_buttons.addWidget(delete_button)
        template_buttons.addStretch(1)
        layout.addLayout(template_buttons)

        layout.addWidget(theme.muted_label("SKILL ĐÍNH KÈM (không bắt buộc)"))
        skill_row = QHBoxLayout()
        self.skill_combo = QComboBox()
        self.skill_combo.currentIndexChanged.connect(
            lambda _i: self.changed.emit()
        )
        skill_row.addWidget(self.skill_combo, 1)
        import_button = QPushButton("📥 Nhập file .md")
        import_button.setToolTip(
            "Đưa một file skill .md vào thư viện của app và chọn ngay"
        )
        import_button.clicked.connect(self._on_import_skill_file)
        skill_row.addWidget(import_button)
        paste_button = QPushButton("📋 Dán skill mới")
        paste_button.clicked.connect(self._on_paste_skill)
        skill_row.addWidget(paste_button)
        layout.addLayout(skill_row)
        self.skill_error_label = theme.muted_label("")
        layout.addWidget(self.skill_error_label)

        layout.addWidget(theme.muted_label("Ghi chú thêm cho Muse:"))
        self.note_edit = QPlainTextEdit()
        self.note_edit.setPlaceholderText(
            "Nhập ghi chú, yêu cầu cụ thể hoặc tài liệu tham khảo…"
        )
        self.note_edit.setMaximumHeight(64)
        layout.addWidget(self.note_edit)

        self._reload_templates()
        self._refresh_skill_combo()

    # ------------------------------------------------------------------ #
    # Mẫu việc
    # ------------------------------------------------------------------ #
    def _reload_templates(self, checked_ids: set | None = None):
        if checked_ids is None:
            checked_ids = set(self.checked_template_ids())
        self.template_list.blockSignals(True)
        try:
            self.template_list.clear()
            for template in self._templates:
                item = QListWidgetItem(template["title"])
                item.setData(Qt.ItemDataRole.UserRole, template["id"])
                item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                item.setCheckState(
                    Qt.CheckState.Checked
                    if template["id"] in checked_ids
                    else Qt.CheckState.Unchecked
                )
                self.template_list.addItem(item)
        finally:
            self.template_list.blockSignals(False)

    def checked_template_ids(self) -> list[str]:
        ids = []
        for row in range(self.template_list.count()):
            item = self.template_list.item(row)
            if item.checkState() == Qt.CheckState.Checked:
                ids.append(item.data(Qt.ItemDataRole.UserRole))
        return ids

    def checked_templates(self) -> list[dict]:
        wanted = set(self.checked_template_ids())
        return [t for t in self._templates if t["id"] in wanted]

    def set_checked(self, template_ids, skill_slug=None):
        """Nạp một checklist có sẵn (thường trực) vào editor."""
        self._reload_templates(set(template_ids or []))
        self._refresh_skill_combo(select_slug=skill_slug)
        self.changed.emit()

    def _persist_templates(self):
        # mẫu cài sẵn của Facebook/TikTok (V7.0) không ghi vào file mẫu chung
        assignments.save_templates([t for t in self._templates if not t.get("platform")], self._base)

    def set_platform(self, platform: str | None):
        """V7.0: kênh Facebook/TikTok → mẫu việc riêng của nền tảng lên đầu danh sách."""
        from .. import platforms

        base = [t for t in self._templates if not t.get("platform")]
        if platform and platform != "youtube":
            self._templates = platforms.templates_for(platform) + base
        else:
            self._templates = base
        self._reload_templates()

    def _on_add_template(self):
        dialog = TemplateEditDialog(None, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            template = dialog.result_template(self._templates)
            self._templates.append(template)
            self._persist_templates()
            checked = set(self.checked_template_ids()) | {template["id"]}
            self._reload_templates(checked)
            self.changed.emit()

    def _on_edit_template(self):
        item = self.template_list.currentItem()
        if item is None:
            return
        template_id = item.data(Qt.ItemDataRole.UserRole)
        template = next(
            (t for t in self._templates if t["id"] == template_id), None
        )
        if template is None:
            return
        dialog = TemplateEditDialog(template, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            updated = dialog.result_template(self._templates)
            self._templates = [
                updated if t["id"] == template_id else t
                for t in self._templates
            ]
            self._persist_templates()
            self._reload_templates()
            self.changed.emit()

    def _on_delete_template(self):
        item = self.template_list.currentItem()
        if item is None:
            return
        template_id = item.data(Qt.ItemDataRole.UserRole)
        self._templates = [
            t for t in self._templates if t["id"] != template_id
        ]
        self._persist_templates()
        self._reload_templates()
        self.changed.emit()

    # ------------------------------------------------------------------ #
    # Skill
    # ------------------------------------------------------------------ #
    def _refresh_skill_combo(self, select_slug: str | None = None):
        current = select_slug or self.skill_combo.currentData()
        self.skill_combo.blockSignals(True)
        try:
            self.skill_combo.clear()
            self.skill_combo.addItem("— Không dùng skill —", None)
            for skill in skills_lib.list_skills(self._base):
                self.skill_combo.addItem(f"✨ {skill.name}", skill.slug)
            if current:
                index = self.skill_combo.findData(current)
                if index >= 0:
                    self.skill_combo.setCurrentIndex(index)
        finally:
            self.skill_combo.blockSignals(False)

    def selected_skill(self) -> skills_lib.Skill | None:
        slug = self.skill_combo.currentData()
        if not slug:
            return None
        return skills_lib.load_skill(slug, self._base)

    def import_skill_from_path(self, path) -> skills_lib.Skill | None:
        """Nhập một file .md vào thư viện và CHỌN NGAY skill đó.
        File không đọc được / rỗng → báo lỗi tại chỗ, trả None."""
        self.skill_error_label.setText("")
        try:
            text = Path(path).read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            self.skill_error_label.setText(
                "⚠ Không đọc được file skill đã chọn."
            )
            return None
        if not text.strip():
            self.skill_error_label.setText("⚠ File skill rỗng — không lưu.")
            return None
        name = Path(path).stem
        for line in text.splitlines():
            if line.startswith("#"):
                name = line.lstrip("#").strip() or name
                break
        try:
            skill = skills_lib.save_skill(name, text, self._base)
        except ValueError as exc:
            self.skill_error_label.setText(f"⚠ {exc}")
            return None
        self._refresh_skill_combo(select_slug=skill.slug)
        self.changed.emit()
        return skill

    def add_pasted_skill(self, name: str, body: str) -> skills_lib.Skill | None:
        """Lưu skill dán tay vào thư viện và chọn ngay; rỗng → lỗi."""
        self.skill_error_label.setText("")
        if not (name or "").strip():
            self.skill_error_label.setText("⚠ Chưa đặt tên cho skill.")
            return None
        if not (body or "").strip():
            self.skill_error_label.setText("⚠ Nội dung skill đang rỗng.")
            return None
        try:
            skill = skills_lib.save_skill(name, body, self._base)
        except ValueError as exc:
            self.skill_error_label.setText(f"⚠ {exc}")
            return None
        self._refresh_skill_combo(select_slug=skill.slug)
        self.changed.emit()
        return skill

    def _on_import_skill_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Chọn file skill (.md)",
            "",
            "Skill Markdown (*.md);;Mọi file (*)",
        )
        if path:
            self.import_skill_from_path(path)

    def _on_paste_skill(self):
        dialog = PasteSkillDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.add_pasted_skill(
                dialog.name_edit.text(), dialog.body_edit.toPlainText()
            )

    def note_text(self) -> str:
        return self.note_edit.toPlainText().strip()


def _dialog_header(channel: dict, agent: dict | None) -> tuple[str, str]:
    channel_name = channel.get("name") or channel.get("handle") or "kênh"
    if agent:
        who = (
            f"Muse phụ trách: {agent.get('name') or ''} "
            f"({agent.get('email') or ''})"
        )
    else:
        who = "Chưa có Muse phụ trách kênh này"
    return channel_name, who


class AssignDialog(QDialog):
    """Hộp thoại Giao việc cho một kênh (ảnh phác thảo 3 + khối Skill)."""

    def __init__(self, store, *, agent, profile, channel, base, parent=None,
                 extra_targets: list[dict] | None = None):
        super().__init__(parent)
        self._store = store
        self._agent = agent
        self._profile = profile
        self._channel = channel
        # V6.9: giao HÀNG LOẠT — cùng checklist/skill/ghi chú cho mọi kênh
        # đã chọn ({agent, profile, channel} mỗi kênh, đúng Muse phụ trách).
        self._extra_targets = list(extra_targets or [])
        channel_name, who = _dialog_header(channel, agent)
        if self._extra_targets:
            channel_name = f"{1 + len(self._extra_targets)} kênh đã chọn"
            names = [channel.get("name") or "kênh"] + [
                (t.get("channel") or {}).get("name") or "kênh" for t in self._extra_targets]
            who = "Áp cho: " + ", ".join(names[:6]) + (f" +{len(names) - 6}" if len(names) > 6 else "")
        self.setWindowTitle(f"Giao việc — kênh {channel_name}")
        self.setMinimumWidth(540)
        layout = QVBoxLayout(self)
        title = QLabel(f"Giao việc — kênh {channel_name}")
        title.setObjectName("DialogTitle")
        title.setStyleSheet("font-size: 17px; font-weight: 700;")
        layout.addWidget(title)
        layout.addWidget(theme.muted_label(f"✦ {who}"))
        self.editor = ChecklistEditor(base, self)
        from .. import platforms as _platforms

        self.editor.set_platform(_platforms.of(channel) if channel.get("platform") else _platforms.of(profile))
        self.editor.changed.connect(self._sync_button)
        layout.addWidget(self.editor)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Huỷ")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        self.assign_button = QPushButton("Giao 0 việc")
        self.assign_button.setProperty("variant", "primary")
        self.assign_button.clicked.connect(self._on_assign)
        buttons.addWidget(self.assign_button)
        layout.addLayout(buttons)
        self.created: list[dict] = []
        self._sync_button()

    def _sync_button(self):
        count = len(self.editor.checked_template_ids())
        targets = 1 + len(getattr(self, "_extra_targets", []) or [])
        self.assign_button.setText(f"Giao {count} việc" + (f" × {targets} kênh" if targets > 1 else ""))
        self.assign_button.setEnabled(count > 0)

    def _on_assign(self):
        templates = self.editor.checked_templates()
        skill = self.editor.selected_skill()
        note = self.editor.note_text()
        self.created = []
        targets = [{"agent": self._agent, "profile": self._profile, "channel": self._channel}]
        targets += self._extra_targets
        for target in targets:
            self.created += assignments.create_assignments(
                self._store,
                agent=target.get("agent") or {},
                profile=target.get("profile") or {},
                channel=target.get("channel") or {},
                templates=templates,
                skill=skill,
                note=note,
            )
        self.accept()


class StandingChecklistDialog(QDialog):
    """Checklist THƯỜNG TRỰC của một kênh: xem/sửa/lưu + tạo việc ngay."""

    def __init__(self, store, *, agent, profile, channel, base, parent=None):
        super().__init__(parent)
        self._store = store
        self._agent = agent
        self._profile = profile
        self._channel = channel
        self._base = Path(base) if base is not None else None
        self._channel_key = str(channel.get("id"))
        channel_name, who = _dialog_header(channel, agent)
        self.setWindowTitle(f"Việc Muse phải làm — kênh {channel_name}")
        self.setMinimumWidth(540)
        layout = QVBoxLayout(self)
        title = QLabel(f"Việc Muse phải làm cho kênh {channel_name}")
        title.setObjectName("DialogTitle")
        title.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(title)
        layout.addWidget(theme.muted_label(f"✦ {who}"))
        layout.addWidget(
            theme.muted_label(
                "Checklist thường trực của kênh — lưu một lần, dùng lại "
                "mỗi lần giao việc. (Bản này chưa tự chạy theo lịch.)"
            )
        )
        self.editor = ChecklistEditor(base, self)
        saved = assignments.load_checklist(self._channel_key, self._base)
        if saved:
            self.editor.set_checked(
                saved["template_ids"], saved["skill_slug"]
            )
        layout.addWidget(self.editor)
        self.status_label = theme.muted_label("")
        layout.addWidget(self.status_label)
        buttons = QHBoxLayout()
        close_button = QPushButton("Đóng")
        close_button.clicked.connect(self.reject)
        buttons.addWidget(close_button)
        buttons.addStretch(1)
        save_button = QPushButton("💾 Lưu thường trực")
        save_button.clicked.connect(self.save_now)
        buttons.addWidget(save_button)
        self.create_button = QPushButton("▶ Tạo các việc này ngay")
        self.create_button.setProperty("variant", "primary")
        self.create_button.clicked.connect(self.create_now)
        buttons.addWidget(self.create_button)
        layout.addLayout(buttons)
        self.created: list[dict] = []

    def save_now(self):
        skill = self.editor.selected_skill()
        assignments.save_checklist(
            self._channel_key,
            self.editor.checked_template_ids(),
            skill.slug if skill else None,
            self._base,
        )
        count = len(self.editor.checked_template_ids())
        self.status_label.setText(
            f"✅ Đã lưu checklist thường trực: {count} mục."
        )

    def create_now(self):
        self.save_now()
        self.created = assignments.create_assignments(
            self._store,
            agent=self._agent or {},
            profile=self._profile or {},
            channel=self._channel,
            templates=self.editor.checked_templates(),
            skill=self.editor.selected_skill(),
            note=self.editor.note_text(),
        )
        self.accept()
