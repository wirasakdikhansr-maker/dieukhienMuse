"""Bảng "Tình trạng các kênh đang quản lý" (V4.3.1) — lớp tổng quan
của section Báo cáo (V4.3.2/F5: nằm DƯỚI khối Báo cáo kênh + Kiểm
tra sau đợt đảo thứ tự theo nghiệm thu máy thật).

V4.3.2 (F6): thẻ THU GỌN + 3 dạng hiện — Ô (thẻ đầy đủ), Lưới (ô
nhỏ: tên + pill + subs/video + việc chạy/chờ), Danh sách (hàng
ngang compact) — cộng điều khiển bề rộng thẻ S/M/L cho Ô/Lưới;
dạng + bề rộng LƯU settings và nạp lại khi mở app. refresh() có
vân dữ liệu: không đổi thì bỏ qua dựng lại (F4).

Chuẩn quản lý kênh đã chốt: một dòng điểm nghẽn chung ở trên, dưới là
lưới thẻ theo kênh — tên/handle/hồ sơ/Muse phụ trách, pill trạng
thái, số liệu thật, phát hiện chính, việc đang chạy/chờ, ghi chú đỏ
khi vướng. NGUYÊN TẮC TRUNG THỰC DỮ LIỆU: mọi con số/dòng chữ đều
suy từ dữ liệu app THẬT SỰ lưu (quét kênh, kiểm tra hồ sơ, lệnh
trong kho, sức khoẻ vòng tự động). Không có cơ sở thì ẨN — tuyệt
đối không bịa %, lịch hay phát hiện.

Nguồn dữ liệu:
- Kênh: ``store.list_channels`` (subs / số video / niche /
  ``last_scan_at`` từ các lần quét đã lưu).
- Trạng thái + phát hiện: ``store.get_last_check(profile_id)`` —
  kiểm tra lưu theo HỒ SƠ nên thẻ kênh dùng kết quả kiểm tra của hồ
  sơ chứa nó (ghi rõ "kiểm tra hồ sơ" ở dòng thời điểm).
- Việc của kênh: counts của nút kênh trong ``work_model`` (cùng
  nguồn với bảng việc ở mục Công việc).
- Điểm nghẽn chung: tổng lệnh ``needs_user`` toàn hệ + trạng thái
  degraded của ``automation_health``; cả hai đều trống thì ẩn dòng.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from .. import automation_health, config
from ..store import Store
from . import theme, work_model

# V4.3.2 (F6): 3 dạng hiện + bề rộng thẻ mục tiêu theo cỡ S/M/L.
VIEW_CARDS, VIEW_TILES, VIEW_LIST = "cards", "tiles", "list"
_CARD_TARGET_WIDTH = {"S": 600, "M": 460, "L": 350}
_TILE_TARGET_WIDTH = {"S": 320, "M": 250, "L": 195}

_ITEM_GLYPHS = {"ok": "✓", "fail": "✗", "na": "–"}
_SEVERITY = {"fail": 0, "na": 1, "ok": 2}


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m/%Y %H:%M")
    except ValueError:
        return str(value)


def _check_pill(check: dict | None) -> tuple[str, str]:
    """(nhãn pill, state) từ kết quả kiểm tra gần nhất của hồ sơ:
    chưa kiểm tra → Chưa có dữ liệu; có mục fail → Có lỗi; đạt hết
    mà còn mục chưa xác minh (na) → Cảnh báo; đạt hết → Tốt."""
    if not check:
        return "Chưa có dữ liệu", "unknown"
    items = check.get("items") or []
    fails = sum(1 for i in items if i.get("status") == "fail")
    oks = sum(1 for i in items if i.get("status") == "ok")
    nas = sum(1 for i in items if i.get("status") == "na")
    if fails:
        return "Có lỗi", "out"
    if oks and nas:
        return "Cảnh báo", "paused"
    if oks:
        return "Tốt", "in"
    return "Chưa rõ", "unknown"


class _ChannelCard(QFrame):
    """Một thẻ kênh trong lưới tình trạng — bấm thẻ phát tín hiệu để
    section nhảy tới đúng kênh ở khối Báo cáo bên dưới."""

    chosen = Signal(int, str)

    def __init__(self, profile_id: int, channel_id: str, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self._profile_id = profile_id
        self._channel_id = channel_id
        self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.chosen.emit(self._profile_id, self._channel_id)
        super().mousePressEvent(event)


class ChannelStatusPanel(QWidget):
    """Dòng điểm nghẽn chung + lưới thẻ tình trạng theo kênh."""

    channel_chosen = Signal(int, str)

    def __init__(self, store: Store, settings: dict | None = None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = (
            settings if settings is not None else config.load_settings()
        )
        view = str(self._settings.get("channel_status_view") or VIEW_CARDS)
        self._view_mode = view if view in (VIEW_CARDS, VIEW_TILES, VIEW_LIST) else VIEW_CARDS
        size = str(self._settings.get("channel_status_size") or "M")
        self._card_size = size if size in ("S", "M", "L") else "M"
        self._fingerprint = None
        # V4.3.2 (F4): resize → hẹn làm mới 120ms (gom cơn mưa sự
        # kiện resize), không dựng lại thẻ theo từng pixel kéo.
        self._resize_timer = QTimer(self)
        self._resize_timer.setSingleShot(True)
        self._resize_timer.setInterval(120)
        self._resize_timer.timeout.connect(self.refresh)
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 8)
        root.setSpacing(10)

        header = QHBoxLayout()
        header.addWidget(
            theme.section_header("Tình trạng các kênh đang quản lý")
        )
        header.addStretch(1)
        # V4.3.2 (F6): gạt 3 dạng hiện như bảng việc + cỡ thẻ S/M/L.
        self._view_group = QButtonGroup(self)
        self._view_group.setExclusive(True)
        self._view_buttons: dict[str, QPushButton] = {}
        for key, label in (
            (VIEW_CARDS, "▦ Ô"),
            (VIEW_TILES, "▤ Lưới"),
            (VIEW_LIST, "☰ Danh sách"),
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setChecked(key == self._view_mode)
            button.clicked.connect(
                lambda _c=False, k=key: self._set_view_mode(k)
            )
            self._view_group.addButton(button)
            self._view_buttons[key] = button
            header.addWidget(button)
        self._size_group = QButtonGroup(self)
        self._size_group.setExclusive(True)
        self._size_buttons: dict[str, QPushButton] = {}
        for key in ("S", "M", "L"):
            button = QPushButton(key)
            button.setCheckable(True)
            button.setChecked(key == self._card_size)
            button.setToolTip(
                "Bề rộng thẻ: S = thẻ rộng ít cột · L = thẻ hẹp nhiều cột"
            )
            button.clicked.connect(
                lambda _c=False, k=key: self._set_card_size(k)
            )
            self._size_group.addButton(button)
            self._size_buttons[key] = button
            header.addWidget(button)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        # Dòng điểm nghẽn chung — chỉ hiện khi CÓ dữ liệu thật.
        self.alert_frame = QFrame()
        self.alert_frame.setObjectName("ErrorBanner")
        alert_layout = QHBoxLayout(self.alert_frame)
        alert_layout.setContentsMargins(12, 8, 12, 8)
        self.alert_label = QLabel("")
        self.alert_label.setObjectName("ErrorBannerText")
        self.alert_label.setWordWrap(True)
        alert_layout.addWidget(self.alert_label)
        self.alert_frame.setVisible(False)
        root.addWidget(self.alert_frame)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.scroll.setStyleSheet(
            f"QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.BG}; }}"
        )
        self.cards_host = QWidget()
        self.cards_layout = QGridLayout(self.cards_host)
        self.cards_layout.setContentsMargins(0, 0, 0, 0)
        self.cards_layout.setSpacing(12)
        self.scroll.setWidget(self.cards_host)
        root.addWidget(self.scroll, 1)

    def _set_view_mode(self, mode: str):
        if mode == self._view_mode:
            return
        self._view_mode = mode
        self._settings["channel_status_view"] = mode
        config.save_settings(self._settings)
        self._fingerprint = None  # đổi dạng = ép dựng lại
        self.refresh()

    def _set_card_size(self, size: str):
        if size == self._card_size:
            return
        self._card_size = size
        self._settings["channel_status_size"] = size
        config.save_settings(self._settings)
        self._fingerprint = None
        self.refresh()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._columns_for(self._viewport_width()) != getattr(
            self, "_columns", None
        ):
            self._resize_timer.start()

    def _viewport_width(self) -> int:
        try:
            return self.scroll.viewport().width()
        except Exception:
            return 0

    def _columns_for(self, width: int) -> int:
        """Số cột theo dạng hiện + cỡ thẻ + bề rộng viewport (F6):
        Ô/Lưới dùng bề rộng mục tiêu của cỡ S/M/L; Danh sách 1 cột."""
        if self._view_mode == VIEW_LIST:
            return 1
        if self._view_mode == VIEW_TILES:
            target = _TILE_TARGET_WIDTH[self._card_size]
            return max(1, min(6, (width or 1200) // target))
        target = _CARD_TARGET_WIDTH[self._card_size]
        return max(1, min(4, (width or 1200) // target))

    # ------------------------------------------------------------------ #
    def refresh(self):
        try:
            profiles = self._store.list_profiles()
            agents = self._store.list_agents()
            channels_by_profile = {
                p["id"]: self._store.list_channels(p["id"]) for p in profiles
            }
            commands = self._store.list_commands(limit=500)
            checks = {
                p["id"]: self._store.get_last_check(p["id"]) for p in profiles
            }
            health = automation_health.read_health(self._store)
        except Exception:
            return
        self._refresh_alert(commands, health)
        # V4.3.2 (F4/F6): vân dữ liệu + dạng hiện + số cột — không
        # đổi thì GIỮ NGUYÊN thẻ (bản cũ dựng lại toàn bộ thẻ mỗi
        # lần mở section: ~20ms và mất vị trí cuộn).
        columns = self._columns_for(self._viewport_width())
        fingerprint = (
            self._view_mode,
            self._card_size,
            columns,
            work_model.work_fingerprint(commands, agents),
            tuple(
                (
                    p["id"],
                    tuple(
                        (
                            c.get("channel_id"), c.get("name"),
                            c.get("handle"), c.get("niche"),
                            c.get("subs"), c.get("video_count"),
                            c.get("last_scan_at"),
                        )
                        for c in channels_by_profile.get(p["id"]) or []
                    ),
                    (
                        (checks.get(p["id"]) or {}).get("ts"),
                        tuple(
                            i.get("status")
                            for i in (checks.get(p["id"]) or {}).get("items") or []
                        ),
                    ),
                )
                for p in profiles
            ),
            bool((health or {}).get("degraded")),
        )
        if fingerprint == self._fingerprint:
            return
        self._fingerprint = fingerprint
        model = work_model.build_work_model(
            commands, agents, profiles, channels_by_profile
        )
        # (profile_id, channel_id) -> (agent_name, counts) từ work model.
        channel_info: dict[tuple, tuple] = {}
        for node in model.get("agents") or []:
            agent = node.get("agent") or {}
            agent_name = (
                agent.get("name") or agent.get("email") or "Chưa phân công"
            )
            for profile_node in node.get("profiles") or []:
                profile = profile_node.get("profile") or {}
                for channel_node in profile_node.get("channels") or []:
                    channel = channel_node.get("channel") or {}
                    channel_info[
                        (profile.get("id"), channel.get("channel_id"))
                    ] = (agent_name, channel_node.get("counts") or {})
        profiles_by_id = {p["id"]: p for p in profiles}

        while self.cards_layout.count():
            item = self.cards_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                # V4.3.2: ẩn + gỡ parent NGAY rồi mới deleteLater —
                # chỉ deleteLater thì thẻ cũ còn vẽ chồng lên thẻ
                # mới tới khi vòng lặp sự kiện xử lý xoá (thấy rõ
                # nhất lúc đổi dạng Ô/Lưới/Danh sách liên tiếp).
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self._columns = columns
        entries = [
            (profile, channel)
            for profile in profiles
            for channel in channels_by_profile.get(profile["id"]) or []
        ]
        if not entries:
            empty = theme.muted_label(
                "Chưa có kênh nào — quét kênh ở mục Hồ sơ để bắt đầu có "
                "bảng tình trạng."
            )
            self.cards_layout.addWidget(empty, 0, 0)
            self.cards_host.setMinimumHeight(
                self.cards_layout.sizeHint().height()
            )
            return
        builder = {
            VIEW_CARDS: self._build_card,
            VIEW_TILES: self._build_tile,
            VIEW_LIST: self._build_row,
        }[self._view_mode]
        for index, (profile, channel) in enumerate(entries):
            agent_name, counts = channel_info.get(
                (profile["id"], channel["channel_id"]), ("Chưa phân công", {})
            )
            card = builder(
                profile,
                channel,
                checks.get(profile["id"]),
                agent_name,
                counts,
            )
            card.chosen.connect(self.channel_chosen.emit)
            self.cards_layout.addWidget(
                card, index // columns, index % columns
            )
        # V4.3.2: đặt lại stretch cho MỌI cột có thể có — stretch
        # của dạng cũ (nhiều cột) sót sang dạng mới (Danh sách 1
        # cột) sẽ bóp hàng còn 1/n bề rộng.
        for col in range(8):
            self.cards_layout.setColumnStretch(col, 1 if col < columns else 0)
        # Host nhận chiều cao tối thiểu tự nhiên: thiếu chỗ thì
        # cuộn, không ép thẻ dẹt (cùng bài học pill bị nén ở bảng
        # việc Công việc).
        self.cards_host.setMinimumHeight(
            self.cards_layout.sizeHint().height()
        )

    def _refresh_alert(self, commands: list, health: dict | None):
        parts = []
        needs_user = sum(
            1 for c in commands if c.get("status") == "needs_user"
        )
        if needs_user:
            parts.append(
                f"✋ Điểm nghẽn chung: {needs_user} lệnh đang chờ người "
                "xử lý (2FA/CAPTCHA/đăng nhập…) — xử lý ở mục Công việc."
            )
        if health and health.get("degraded"):
            parts.append(
                f"⚠ Vòng tự động đang lỗi ({health.get('source') or '?'}): "
                f"{health.get('error') or ''} — lúc {_fmt_ts(health.get('at'))}."
            )
        self.alert_label.setText(" ".join(parts))
        self.alert_frame.setVisible(bool(parts))

    @staticmethod
    def _faint(text: str) -> QLabel:
        """Dòng chữ phụ cỡ nhỏ (F6: chữ phụ của thẻ nhỏ lại một nấc)."""
        label = QLabel(text)
        label.setObjectName("Faint12")
        label.setWordWrap(True)
        return label

    # ------------------------------------------------------------------ #
    def _build_card(self, profile: dict, channel: dict, check: dict | None,
                    agent_name: str, counts: dict) -> _ChannelCard:
        card = _ChannelCard(profile["id"], channel["channel_id"])
        layout = QVBoxLayout(card)
        # V4.3.2 (F6): thẻ gọn — đệm và khoảng dòng giảm rõ.
        layout.setContentsMargins(12, 9, 12, 9)
        layout.setSpacing(4)

        head = QHBoxLayout()
        head.setSpacing(8)
        title = QLabel(channel.get("name") or channel["channel_id"])
        title.setObjectName("CardTitle")
        title.setWordWrap(True)
        head.addWidget(title, 1)
        pill_text, pill_state = _check_pill(check)
        head.addWidget(theme.pill(f"● {pill_text}", pill_state))
        layout.addLayout(head)

        sub_parts = []
        if channel.get("handle"):
            sub_parts.append(channel["handle"])
        if channel.get("niche"):
            sub_parts.append(channel["niche"])
        if sub_parts:
            layout.addWidget(self._faint(" · ".join(sub_parts)))
        layout.addWidget(
            self._faint(
                f"Hồ sơ {profile.get('label') or ''} · Muse phụ trách: "
                f"{agent_name}"
            )
        )

        stats = []
        subs = channel.get("subs")
        stats.append(f"👥 {subs:,} subs" if subs is not None else "👥 — subs")
        videos = channel.get("video_count")
        stats.append(
            f"🎬 {videos:,} video" if videos is not None else "🎬 — video"
        )
        layout.addWidget(QLabel(" · ".join(stats)))
        layout.addWidget(
            self._faint(
                f"Quét cuối: {_fmt_ts(channel.get('last_scan_at'))} · "
                f"Kiểm tra hồ sơ cuối: {_fmt_ts((check or {}).get('ts'))}"
            )
        )

        # Phát hiện chính: tối đa 3 mục từ lần kiểm tra hồ sơ gần
        # nhất, ưu tiên lỗi → chưa xác minh → đạt.
        items = sorted(
            (check or {}).get("items") or [],
            key=lambda i: _SEVERITY.get(i.get("status"), 3),
        )
        for item in items[:3]:
            status = item.get("status")
            glyph = _ITEM_GLYPHS.get(status, "–")
            line = QLabel(
                f"{glyph} {item.get('label') or ''}: {item.get('detail') or ''}"
            )
            line.setObjectName("Muted12")
            if status == "fail":
                line.setStyleSheet(f"color: {theme.DANGER};")
            line.setWordWrap(True)
            layout.addWidget(line)

        # Thanh đạt kiểm tra — CHỈ khi tính được từ mục kiểm tra
        # thật (đạt / (đạt + lỗi)); toàn mục "na" thì bỏ hẳn.
        oks = sum(
            1 for i in (check or {}).get("items") or [] if i.get("status") == "ok"
        )
        fails = sum(
            1 for i in (check or {}).get("items") or [] if i.get("status") == "fail"
        )
        if oks + fails:
            pct = round(oks * 100 / (oks + fails))
            bar_row = QHBoxLayout()
            bar_row.setSpacing(8)
            bar = QProgressBar()
            bar.setRange(0, 100)
            bar.setValue(pct)
            bar.setTextVisible(False)
            bar.setFixedHeight(theme.PROGRESS_HEIGHT)
            color = theme.SUCCESS if not fails else theme.WARNING
            # V6.3.1: một kiểu thanh tiến độ (accent) — màu trạng thái ở pill.
            bar_row.addWidget(bar, 1)
            bar_row.addWidget(theme.pill(f"{oks}/{oks + fails} mục đạt", "unknown"))
            layout.addLayout(bar_row)

        work_parts = []
        if counts.get("running"):
            work_parts.append(f"▶ {counts['running']} đang chạy")
        if counts.get("waiting"):
            work_parts.append(f"⏳ {counts['waiting']} đang chờ")
        layout.addWidget(
            theme.muted_label(
                "Việc của kênh: " + (" · ".join(work_parts) if work_parts else "không có lệnh đang chạy/chờ")
            )
        )

        # Ghi chú đỏ: lệnh chờ người / lỗi liên quan tới kênh này.
        notes = []
        if counts.get("needs_user"):
            notes.append(f"✋ {counts['needs_user']} lệnh chờ người xử lý")
        if counts.get("failed"):
            notes.append(f"❌ {counts['failed']} lệnh lỗi")
        if notes:
            note = QLabel(" · ".join(notes))
            note.setStyleSheet(f"color: {theme.DANGER}; font-weight: 600;")
            note.setWordWrap(True)
            layout.addWidget(note)
        layout.addStretch(1)
        return card

    # ------------------------------------------------------------------ #
    # V4.3.2 (F6) — Ô Lưới: chỉ tên + pill + subs/video + việc chạy/chờ.
    # ------------------------------------------------------------------ #
    def _build_tile(self, profile: dict, channel: dict, check: dict | None,
                    agent_name: str, counts: dict) -> _ChannelCard:
        tile = _ChannelCard(profile["id"], channel["channel_id"])
        layout = QVBoxLayout(tile)
        layout.setContentsMargins(10, 8, 10, 8)
        layout.setSpacing(3)

        head = QHBoxLayout()
        head.setSpacing(6)
        title = QLabel(channel.get("name") or channel["channel_id"])
        title.setObjectName("CardTitle")
        head.addWidget(title, 1)
        pill_text, pill_state = _check_pill(check)
        head.addWidget(theme.pill(f"● {pill_text}", pill_state))
        layout.addLayout(head)

        subs = channel.get("subs")
        videos = channel.get("video_count")
        stats = (
            f"👥 {subs:,}" if subs is not None else "👥 —"
        ) + " · " + (
            f"🎬 {videos:,}" if videos is not None else "🎬 —"
        )
        layout.addWidget(self._faint(stats))
        work_parts = []
        if counts.get("running"):
            work_parts.append(f"▶ {counts['running']} đang chạy")
        if counts.get("waiting"):
            work_parts.append(f"⏳ {counts['waiting']} đang chờ")
        if counts.get("needs_user"):
            work_parts.append(f"✋ {counts['needs_user']} chờ người")
        layout.addWidget(
            self._faint(" · ".join(work_parts) if work_parts else "Không có việc đang chạy/chờ")
        )
        layout.addStretch(1)
        return tile

    # ------------------------------------------------------------------ #
    # V4.3.2 (F6) — Hàng Danh sách: mỗi kênh một hàng ngang compact.
    # ------------------------------------------------------------------ #
    def _build_row(self, profile: dict, channel: dict, check: dict | None,
                   agent_name: str, counts: dict) -> _ChannelCard:
        row = _ChannelCard(profile["id"], channel["channel_id"])
        layout = QHBoxLayout(row)
        layout.setContentsMargins(12, 7, 12, 7)
        layout.setSpacing(10)

        name = QLabel(channel.get("name") or channel["channel_id"])
        name.setObjectName("CardTitle")
        layout.addWidget(name, 3)
        handle = channel.get("handle") or "—"
        layout.addWidget(self._faint(f"{handle} · {profile.get('label') or ''}"), 2)
        pill_text, pill_state = _check_pill(check)
        layout.addWidget(theme.pill(f"● {pill_text}", pill_state))
        subs = channel.get("subs")
        videos = channel.get("video_count")
        stats = (
            f"👥 {subs:,}" if subs is not None else "👥 —"
        ) + " · " + (
            f"🎬 {videos:,}" if videos is not None else "🎬 —"
        )
        layout.addWidget(self._faint(stats), 2)
        work_parts = []
        if counts.get("running"):
            work_parts.append(f"▶ {counts['running']}")
        if counts.get("waiting"):
            work_parts.append(f"⏳ {counts['waiting']}")
        if counts.get("needs_user"):
            work_parts.append(f"✋ {counts['needs_user']}")
        if counts.get("failed"):
            work_parts.append(f"❌ {counts['failed']}")
        layout.addWidget(
            self._faint(" · ".join(work_parts) if work_parts else "—"), 1
        )
        layout.addWidget(
            self._faint(f"Quét: {_fmt_ts(channel.get('last_scan_at'))}"), 2
        )
        return row
