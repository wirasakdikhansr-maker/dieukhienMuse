"""V6.7 — SỔ GIAO VIỆC của trưởng phòng (tab Công việc → "📒 Sổ giao việc").

Gom theo từng agent: đã giao bao nhiêu việc, đã nhận bao nhiêu, đang làm,
xong, kẹt, số lần trưởng phòng phải nhắc, thời gian xác nhận trung bình.
Mở một agent: từng việc với mốc Giao lúc → Nhận lúc → Báo cáo lúc, tiến độ,
và các quyết định trưởng phòng đã đưa ra cho việc đó.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QComboBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import work_board
from . import theme

COLUMNS = ["Agent / việc", "Kênh", "Giai đoạn", "Tiến độ", "Giao lúc", "Nhận lúc", "Báo cáo", "TP nhắc", "Chuyển", "Trưởng phòng đã làm"]
STAGE_COLOR = {"✓": theme.SUCCESS, "✕": theme.DANGER, "✋": theme.WARNING, "▶": theme.ACCENT, "✉": theme.INFO, "⏳": theme.MUTED}


class LedgerView(QWidget):
    command_chosen = Signal(str)

    def __init__(self, store, parent=None):
        super().__init__(parent)
        self._store = store
        self._fp = None
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(8)
        head = QHBoxLayout()
        head.addWidget(theme.section_header("📒 Sổ giao việc của trưởng phòng"))
        self.summary = QLabel("")
        self.summary.setStyleSheet(f"color: {theme.MUTED};")
        head.addWidget(self.summary, 1)
        head.addWidget(theme.muted_label("Trong:"))
        self.range_combo = QComboBox()
        for days, text in ((1, "Hôm nay"), (7, "7 ngày"), (30, "30 ngày")):
            self.range_combo.addItem(text, days)
        self.range_combo.setCurrentIndex(1)
        self.range_combo.currentIndexChanged.connect(lambda _i: self.refresh(force=True))
        head.addWidget(self.range_combo)
        root.addLayout(head)
        self.tree = QTreeWidget()
        self.tree.setColumnCount(len(COLUMNS))
        self.tree.setHeaderLabels(COLUMNS)
        self.tree.setRootIsDecorated(True)
        self.tree.setAlternatingRowColors(False)
        self.tree.setStyleSheet(
            f"QTreeWidget {{ background: {theme.PANEL}; color: {theme.TEXT}; border: 1px solid {theme.BORDER};"
            f" border-radius: 10px; }} QTreeWidget::item {{ padding: 4px 2px; }}"
            f" QTreeWidget::item:selected {{ background: rgba(206,252,25,40); color: {theme.TEXT}; }}"
            f" QHeaderView::section {{ background: {theme.CARD}; color: {theme.MUTED}; border: none; padding: 6px; }}")
        header = self.tree.header()
        header.setSectionResizeMode(QHeaderView.ResizeToContents)
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(9, QHeaderView.Stretch)
        self.tree.itemDoubleClicked.connect(self._on_double)
        root.addWidget(self.tree, 1)
        hint = theme.muted_label("Bấm đúp một việc để mở chi tiết. “TP nhắc” = số lần trưởng phòng phải hỏi đã nhận / đòi tiến độ; "
                                 "agent càng ít bị nhắc, xác nhận càng nhanh thì càng tốt.")
        hint.setWordWrap(True)
        root.addWidget(hint)
        self._expanded: set[int] = set()
        self._timer = QTimer(self)
        self._timer.setInterval(4000)
        self._timer.timeout.connect(self.refresh)

    def showEvent(self, event):
        super().showEvent(event)
        self._timer.start()
        self.refresh(force=True)

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def refresh(self, force: bool = False):
        try:
            data = work_board.assignment_ledger(self._store, days=int(self.range_combo.currentData() or 7))
        except Exception:
            return
        fp = repr(data)
        if fp == self._fp and not force:
            return
        self._fp = fp
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            key = item.data(0, Qt.ItemDataRole.UserRole + 1)
            if item.isExpanded():
                self._expanded.add(key)
            else:
                self._expanded.discard(key)
        self.tree.clear()
        groups = data["groups"]
        self.summary.setText(f"{data['total']} việc đã giao · {len(groups)} agent")
        for g in groups:
            avg = f" · xác nhận TB {g['avg_ack']:.0f} phút" if g["avg_ack"] is not None else ""
            top = QTreeWidgetItem([
                f"🤖 {g['name']}", "", f"giao {g['assigned']} · nhận {g['acked']} · đang làm {g['running']} · "
                                       f"xong {g['done']} · kẹt {g['stuck']}{avg}",
                "", "", "", "", str(g["nudges"]), "", ""])
            font = top.font(0)
            font.setBold(True)
            top.setFont(0, font)
            top.setData(0, Qt.ItemDataRole.UserRole + 1, g["agent_id"])
            if g["stuck"]:
                top.setForeground(2, QColor(theme.WARNING))
            for e in g["items"]:
                child = QTreeWidgetItem([
                    f"#{e['short']} · {e['title']}", e["channel"] or "", e["stage"], f"{e['pct']}%",
                    e["sent"], e["acked"] + (f" ({e['ack_min']:.0f}p)" if e["ack_min"] is not None else ""),
                    e["reported"], str(e["nudges"]), str(e["reassigned"]), e["actions"] or "—"])
                child.setData(0, Qt.ItemDataRole.UserRole, e["id"])
                child.setForeground(2, QColor(STAGE_COLOR.get(e["stage"][:1], theme.MUTED)))
                child.setToolTip(0, e["step"] or e["title"])
                top.addChild(child)
            self.tree.addTopLevelItem(top)
            top.setExpanded(g["agent_id"] in self._expanded or len(groups) <= 8)
        if not groups:
            empty = QTreeWidgetItem(["Chưa có việc nào qua tay trưởng phòng trong khoảng này."])
            self.tree.addTopLevelItem(empty)

    def _on_double(self, item, _col):
        command_id = item.data(0, Qt.ItemDataRole.UserRole)
        if command_id:
            self.command_chosen.emit(str(command_id))
