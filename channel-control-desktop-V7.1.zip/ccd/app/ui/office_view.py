"""Tab "🏢 Văn phòng" (V4.1) — diorama công sở nhìn từ trên xuống
(Concept C đã duyệt): phòng kính của Điều phối viên ở góc trái-trên,
bảng ghim "Hàng đợi chờ" ở tường phải, khu bàn nhân viên ở giữa với
robot Muse ngồi làm việc, bong bóng thoại trên đầu mỗi bàn hiện việc
đang làm + % tiến độ, góc nghỉ trang trí.

Vẽ 2.5D thuần Qt (QGraphicsView + QGraphicsItem, không WebEngine,
không file sprite): toàn bộ hình khối dựng bằng code nên nhẹ và test
offscreen được. Dữ liệu lấy qua ``office_scene.build_office_scene``
(tầng thuần) từ Store — bấm vào một bàn để chọn agent, panel chi tiết
bên phải hiện hồ sơ/kênh phụ trách, lệnh hiện tại và lịch sử gần đây.

Nhịp làm mới: cửa sổ chính gọi ``refresh()`` mỗi 1 giây khi tab đang
hiện (và khi chuyển sang tab); hoạt cảnh (robot nhún khi đang làm,
dấu ❗ nhấp nháy khi chờ người) chạy bằng timer 500ms RIÊNG của view,
chỉ chạy lúc view hiện — ẩn tab là dừng, không tốn CPU.
"""

from __future__ import annotations

import logging

from PySide6.QtCore import (
    QCoreApplication,
    QEvent,
    QPointF,
    QRectF,
    Qt,
    QTimer,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QPainter,
    QPen,
    QPixmap,
    QPolygonF,
)
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFrame,
    QGraphicsItemGroup,
    QGraphicsEllipseItem,
    QGraphicsPolygonItem,
    QGraphicsRectItem,
    QGraphicsScene,
    QGraphicsTextItem,
    QGraphicsView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSlider,
    QSplitter,
    QToolTip,
    QVBoxLayout,
    QWidget,
)

import time

from .. import config, office_issues
from ..store import COMMAND_TYPE_LABELS, Store
from . import office_scene, theme, work_model
from .agent_chat import AgentChatWidget
from .issues_panel import IssuesPanel

log = logging.getLogger(__name__)

SCENE_W, SCENE_H = 1060, 680

# V5.1: trạng thái bàn (office_scene) → trạng thái pill ở header cố
# định của panel chi tiết (theme.QLabel#Pill states).
_DESK_PILL_STATES = {
    "working": "run",
    "needs_user": "user",
    "waiting": "paused",
    "idle": "in",
    "offline": "out",
}

# V4.3 (G2): các mức mật độ sàn theo số agent — diorama đầy đủ khi ít
# agent; đông dần thì chuyển lưới ô gọn để 100+ agent vẫn xem được.
TIER_DIORAMA, TIER_MEDIUM, TIER_COMPACT, TIER_WALL = (
    "diorama", "medium", "compact", "wall",
)
DENSITY_LABELS = {
    "auto": "Tự động theo số agent",
    "roomy": "Thoáng (diorama)",
    "compact": "Gọn (ô)",
    "mini": "Siêu gọn (tường ô)",
}


def density_tier(agent_count: int, setting: str | None) -> str:
    """Mức bố trí sàn từ số agent + lựa chọn mật độ của người dùng."""
    setting = setting or "auto"
    if setting == "roomy":
        return TIER_DIORAMA
    if setting == "compact":
        return TIER_COMPACT
    if setting == "mini":
        return TIER_WALL
    if agent_count <= 8:
        return TIER_DIORAMA
    if agent_count <= 30:
        return TIER_MEDIUM
    if agent_count <= 100:
        return TIER_COMPACT
    return TIER_WALL

_INK = "#243B53"        # chữ chính trên nền sáng của diorama
_INK_SOFT = "#5B7186"   # chữ phụ
_FLOOR = "#F7F1E3"
_WALL = "#DCE9F5"

_STATE_BUBBLE = {
    "working": ("#D9F7EE", "#2DD4BF"),
    "waiting": ("#FEF3C7", "#F59E0B"),
    "needs_user": ("#FDE8E8", "#EF4444"),
}
_STATE_DOT = {
    "working": "#7DDC7A",
    "waiting": "#F59E0B",
    "needs_user": "#EF4444",
    "offline": "#9CA3AF",
    "idle": "#38BDF8",
}
_STATUS_ICON = {
    "done": "✅",
    "failed": "❌",
    "running": "▶",
    "waiting_muse": "⏳",
    "queued": "•",
    "needs_user": "✋",
    "interrupted": "⏸",
}
_STATUS_TEXT = {
    "done": "Xong",
    "failed": "Lỗi",
    "running": "Đang chạy",
    "waiting_muse": "Chờ Muse",
    "queued": "Trong hàng đợi",
    "needs_user": "Chờ người",
    "interrupted": "Bị gián đoạn",
}
_BOARD_CARD_COLORS = ["#FDE68A", "#BFDBFE", "#FBCFE8", "#BBF7D0", "#DDD6FE"]


_FONT_CACHE: dict = {}


def _font(size: float, bold: bool = False) -> QFont:
    """QFont dùng chung theo (size, bold) — V5.2 (hiệu năng §15):
    trước đây mỗi lần dựng cảnh tạo ~100 QFont mới (setFont là một
    trong các chi phí lớn nhất của _rebuild_scene); QFont là giá trị
    bất biến theo key nên cache ở mức module là an toàn."""
    key = (float(size), bool(bold))
    font = _FONT_CACHE.get(key)
    if font is None:
        font = QFont("Segoe UI", size)
        font.setBold(bold)
        _FONT_CACHE[key] = font
    return font


def _elide(text: str, font: QFont, width: float) -> str:
    return QFontMetrics(font).elidedText(
        str(text or ""), Qt.ElideRight, max(10, int(width))
    )


def _format_duration(seconds: int) -> str:
    """Khoảng chờ gọn cho thẻ/panel: '45 giây' / '3 phút' / '1 giờ 5 phút'."""
    seconds = max(0, int(seconds or 0))
    if seconds < 60:
        return f"{seconds} giây"
    minutes, rest = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes} phút" + (f" {rest} giây" if rest and minutes < 10 else "")
    hours, minutes = divmod(minutes, 60)
    return f"{hours} giờ" + (f" {minutes} phút" if minutes else "")


class _RoundRect(QGraphicsRectItem):
    """Rect bo góc: vẽ lại bằng painter path (QGraphicsRectItem gốc
    chỉ vẽ góc vuông)."""

    def __init__(self, x, y, w, h, radius, fill, pen=None, pen_width=1.0):
        super().__init__(QRectF(x, y, w, h))
        self._radius = radius
        self.setBrush(QBrush(QColor(fill)) if fill else QBrush(Qt.NoBrush))
        self.setPen(
            QPen(QColor(pen), pen_width) if pen else QPen(Qt.NoPen)
        )

    def paint(self, painter, option, widget=None):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        painter.setBrush(self.brush())
        painter.setPen(self.pen())
        painter.drawRoundedRect(self.rect(), self._radius, self._radius)
        painter.restore()


def _shell_rect(painter, x, y, w, h, radius, fill, pen=None,
                pen_width=1.0, opacity=1.0):
    painter.save()
    painter.setOpacity(opacity)
    painter.setBrush(QBrush(QColor(fill)))
    painter.setPen(
        QPen(QColor(pen), pen_width) if pen else QPen(Qt.NoPen)
    )
    painter.drawRoundedRect(QRectF(x, y, w, h), radius, radius)
    painter.restore()


def _paint_office_background(painter, rect, shell_diorama: bool):
    """Sơn lớp nền cảnh văn phòng (V4.3.2): nền app kín vùng lộ
    diện + (bậc diorama) VỎ PHÒNG tĩnh — sàn sáng, kính phòng Điều
    phối, bảng trắng, thẻ biển tên, khung bảng hàng đợi — đúng hình
    học các item vỏ của thiết kế V4.1 đã chốt. Hàm này được gọi từ
    drawBackground của CẢ scene (đường scene.render) lẫn view
    (đường sơn thật của QGraphicsView) nên vỏ phòng hiện ở mọi
    đường vẽ, không phụ thuộc item index/culling."""
    painter.save()
    painter.setRenderHint(QPainter.Antialiasing)
    painter.fillRect(rect, QColor(theme.BG))
    if shell_diorama:
        # V5.2: nền ẢNH THẬT (office_floor.jpg trong assets — văn
        # phòng isometric tối, cùng tông app) phủ kín khung cảnh
        # 1060x680 kiểu cover (cắt giữa, giữ tỉ lệ) thay cho sàn/vỏ
        # SÁNG sơn phẳng — chữ trần trên nền (tiêu đề phòng Điều
        # phối, biển tên, bảng hàng đợi) chuyển sang bản sáng tương
        # ứng (xem _TEXT_ON_PHOTO). Không nạp được ảnh thì rơi về
        # vỏ sơn cũ phía dưới.
        # V5.3 (A9): qua office_background_pixmap — ảnh TUỲ CHỌN
        # của người dùng (setting office_bg_image) thắng ảnh đóng
        # gói, cùng một đường cover-crop; nạp lỗi tự fallback.
        floor = theme.office_background_pixmap()
        if floor is not None:
            scene_rect = QRectF(0, 0, SCENE_W, SCENE_H)
            target = QRectF(rect).intersected(scene_rect)
            if not target.isEmpty():
                pw, ph = float(floor.width()), float(floor.height())
                scale = max(SCENE_W / pw, SCENE_H / ph)
                src_w, src_h = SCENE_W / scale, SCENE_H / scale
                source = QRectF(
                    (pw - src_w) / 2.0 + (target.x() / SCENE_W) * src_w,
                    (ph - src_h) / 2.0 + (target.y() / SCENE_H) * src_h,
                    (target.width() / SCENE_W) * src_w,
                    (target.height() / SCENE_H) * src_h,
                )
                painter.drawPixmap(target, floor, source)
            painter.restore()
            return
        # Sàn phòng (sáng, tương phản nền app) — robot đứng TRÊN sàn.
        _shell_rect(
            painter, 6, 6, SCENE_W - 12, SCENE_H - 12, 18,
            _FLOOR, "#D8C9A8", 1.5,
        )
        # Kính phòng Điều phối viên (24,24,330,190) + bảng trắng
        # trong phòng (192,58,148,128) — khớp hình học item cũ.
        _shell_rect(
            painter, 24, 24, 330, 190, 12,
            "#DCEEFF", "#7FB3E0", 2, opacity=0.85,
        )
        _shell_rect(
            painter, 192, 58, 148, 128, 8, "#FFFFFF", "#B9CFE8", 1.2,
        )
        # Thẻ biển tên văn phòng (378,24,312,92).
        _shell_rect(
            painter, 378, 24, 312, 92, 10, "#FFFFFF", "#E3D5B8", 1.2,
        )
        # Khung bảng hàng đợi (714,24,322,190).
        _shell_rect(
            painter, 714, 24, 322, 190, 8, "#EBCB9B", "#B07B4F", 3,
        )
    painter.restore()


class _OfficeScene(QGraphicsScene):
    """Scene Văn phòng (V4.3.2 — sửa lỗi mất nền trên máy thật).

    Căn nguyên lỗi V4.3.1 trên Windows thật: các item vỏ lớn dựng
    ĐẦU cảnh (sàn/kính/bảng) không hiện dù code + dữ liệu đúng và
    bản dựng offscreen vẫn vẽ đủ (đã kiểm chứng: zip giao trùng hệt
    mã nguồn, render offscreen đủ sàn) — cơ chế sơn item của
    QGraphicsView trên máy đó làm rơi đúng nhóm item này, trong khi
    item nhỏ dựng sau (robot/bàn/chữ) vẫn hiện. Vỏ tĩnh vì thế
    KHÔNG còn là item: scene/view sơn thẳng ở lớp background (xem
    ``_paint_office_background``) — không qua item index, không bị
    culling theo vùng lộ diện, không thể bị clear() nuốt. Nội dung
    động (chữ, robot, thẻ chờ, bong bóng) vẫn là item vẽ phía trên.
    Mọi bậc mật độ đều có nền riêng: diorama = sàn sáng + vỏ phòng;
    các bậc lưới = nền app (theme.BG) sơn kín vùng cảnh.
    """

    shell_diorama = False

    def drawBackground(self, painter, rect):
        _paint_office_background(painter, rect, self.shell_diorama)


class _OfficeGraphicsView(QGraphicsView):
    """View sàn văn phòng: override drawBackground vì đường sơn
    thật của QGraphicsView đi qua drawBackground CỦA VIEW (không
    phải của scene — scene.drawBackground chỉ được scene.render
    gọi). Cờ bậc vỏ đọc từ scene để một nguồn sự thật duy nhất."""

    def drawBackground(self, painter, rect):
        scene = self.scene()
        _paint_office_background(
            painter, rect, bool(getattr(scene, "shell_diorama", False))
        )


def _text(x, y, content, size=9.0, bold=False, color=_INK, width=None,
          align_center=False):
    item = QGraphicsTextItem(str(content or ""))
    item.setFont(_font(size, bold))
    item.setDefaultTextColor(QColor(color))
    if width:
        item.setTextWidth(width)
    if align_center and width:
        item.setX(x - 0)  # căn giữa bằng textWidth + alignment bên dưới
        option = item.document().defaultTextOption()
        option.setAlignment(Qt.AlignHCenter)
        item.document().setDefaultTextOption(option)
    item.setPos(x, y)
    return item


def _robot_group(color_hex: str, grey: bool = False, manager: bool = False):
    """Dựng một robot (gốc tại điểm thân chạm mặt bàn, trục y hướng
    lên âm). Trả (group, phần_thân_để_nhún)."""
    group = QGraphicsItemGroup()
    body_color = "#9AA7B4" if grey else color_hex
    dark = QColor(body_color).darker(125).name()
    face = "#4B5563" if grey else "#1F2937"
    eye = "#D1D5DB" if grey else "#7DF9FF"

    robot = QGraphicsItemGroup()
    # Ăng-ten
    antenna = QGraphicsRectItem(QRectF(-1, -104, 2, 16))
    antenna.setBrush(QBrush(QColor(dark)))
    antenna.setPen(QPen(Qt.NoPen))
    robot.addToGroup(antenna)
    tip = QGraphicsEllipseItem(QRectF(-4, -112, 8, 8))
    tip.setBrush(QBrush(QColor("#9CA3AF" if grey else "#F59E0B")))
    tip.setPen(QPen(Qt.NoPen))
    robot.addToGroup(tip)
    # Đầu + mặt
    robot.addToGroup(_RoundRect(-25, -88, 50, 42, 12, body_color, dark, 1.2))
    robot.addToGroup(_RoundRect(-18, -81, 36, 28, 8, face))
    for eye_x in (-9, 9):
        eye_item = QGraphicsEllipseItem(QRectF(eye_x - 3.5, -70, 7, 7))
        eye_item.setBrush(QBrush(QColor(eye)))
        eye_item.setPen(QPen(Qt.NoPen))
        robot.addToGroup(eye_item)
    mouth = QGraphicsRectItem(QRectF(-6, -59, 12, 2))
    mouth.setBrush(QBrush(QColor(eye)))
    mouth.setPen(QPen(Qt.NoPen))
    robot.addToGroup(mouth)
    # Thân + tay
    robot.addToGroup(_RoundRect(-21, -44, 42, 44, 9, body_color, dark, 1.2))
    robot.addToGroup(_RoundRect(-32, -40, 9, 30, 4, dark))
    robot.addToGroup(_RoundRect(23, -40, 9, 30, 4, dark))
    chest = QGraphicsEllipseItem(QRectF(-5, -30, 10, 10))
    chest.setBrush(QBrush(QColor("#FFFFFF")))
    chest.setPen(QPen(Qt.NoPen))
    chest.setOpacity(0.75)
    robot.addToGroup(chest)
    if manager:
        badge = _text(-7, -38, "★", 11, True, "#FDE68A")
        robot.addToGroup(badge)
    group.addToGroup(robot)
    return group, robot


def robot_head_pixmap(color_hex: str, grey: bool = False, size: int = 64) -> QPixmap:
    """Ảnh đầu robot (cho avatar ở panel chi tiết) — vẽ bằng QPainter
    cùng ngôn ngữ hình với robot trong cảnh."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    body = QColor("#9AA7B4" if grey else color_hex)
    dark = body.darker(125)
    scale = size / 64.0
    painter.setPen(QPen(dark, 1.4))
    painter.setBrush(QBrush(body))
    painter.drawRoundedRect(
        QRectF(10 * scale, 14 * scale, 44 * scale, 38 * scale),
        10 * scale, 10 * scale,
    )
    painter.setPen(QPen(Qt.NoPen))
    painter.setBrush(QBrush(QColor("#4B5563" if grey else "#1F2937")))
    painter.drawRoundedRect(
        QRectF(16 * scale, 20 * scale, 32 * scale, 24 * scale),
        7 * scale, 7 * scale,
    )
    painter.setBrush(QBrush(QColor("#D1D5DB" if grey else "#7DF9FF")))
    for eye_x in (26, 38):
        painter.drawEllipse(QRectF((eye_x - 3) * scale, 29 * scale, 6 * scale, 6 * scale))
    painter.setPen(QPen(dark, 2))
    painter.drawLine(QPointF(32 * scale, 14 * scale), QPointF(32 * scale, 6 * scale))
    painter.setPen(QPen(Qt.NoPen))
    painter.setBrush(QBrush(QColor("#9CA3AF" if grey else "#F59E0B")))
    painter.drawEllipse(QRectF(29 * scale, 1 * scale, 6 * scale, 6 * scale))
    painter.end()
    return pixmap


class OfficeView(QWidget):
    """Tab Văn phòng: cảnh diorama (trái) + panel chi tiết agent (phải)."""

    agent_selected = Signal(int)
    open_commands_requested = Signal()
    open_agents_requested = Signal()
    # V4.6 (sửa phạm vi 10:46): KHÔNG còn tín hiệu "nhảy sang mục
    # Tài khoản để chat" — chat sống NGAY trong panel chi tiết của
    # văn phòng này (cùng component AgentChatWidget).
    # V4.3 (G2): bấm một việc trong panel chi tiết → cửa sổ chính mở
    # mục Công việc và chọn đúng lệnh đó.
    open_command_requested = Signal(str)
    # V6.1: thao tác trên một sự cố (action, issue) — MainWindow thực thi.
    issue_action_requested = Signal(str, dict)

    # Nhịp tính lại sự cố (giây) — rẻ nhưng không cần mỗi giây.
    ISSUES_INTERVAL = 4.0

    def __init__(self, store: Store, settings: dict | None = None,
                 wake_bridge=None, parent=None):
        super().__init__(parent)
        self._store = store
        # wake_bridge: chuyển tiếp cho khung chat trong panel (đánh
        # thức long-poll của cầu nối khi người dùng gửi tin).
        self._wake_bridge = wake_bridge
        self._settings = settings if settings is not None else config.load_settings()
        self._model: dict | None = None
        self._profiles_by_id: dict[int, dict] = {}
        self._selected_agent_id: int | None = None
        # V4.3 (G2): dữ liệu thô của lần refresh gần nhất (cho panel
        # chi tiết dựng work model của đúng agent đang chọn) + hình
        # học các bàn/ô để hover/tìm kiếm/minimap dùng lại.
        self._raw_agents: list[dict] = []
        self._raw_commands: list[dict] = []
        self._raw_profiles: list[dict] = []
        self._desk_bounds: dict[int, QRectF] = {}
        self._tier: str = TIER_DIORAMA
        self._hover_agent_id: int | None = None
        self._hover_rect = None
        self._bob_items: list[tuple[QGraphicsItemGroup, float]] = []
        self._blink_items: list[QGraphicsTextItem] = []
        self._blink_on = True
        # V4.2 (O-09): vân dữ liệu đã vẽ — refresh() chỉ dựng lại cảnh
        # khi vân thay đổi; tick 1 giây vẫn chạy để đếm ngược lease.
        self._fingerprint = None
        # V4.2 (O-07): số kênh theo hồ sơ (aggregate một câu SQL) cho
        # panel chi tiết — thay vòng lặp list_channels từng hồ sơ.
        self._channel_counts: dict[int, int] = {}
        # V5.2.1: khoá câu hỏi needs_user đang chờ theo agent (id
        # lệnh) — refresh() tính lại mỗi nhịp, _update_detail nạp
        # vào khung chat thu/mở của panel (set_pending_question).
        self._pending_question_keys: dict[int, str] = {}
        # V4.6: tham chiếu Python GIỮ MẠNH tới mọi item của cảnh đang
        # hiện + số item kỳ vọng sau mỗi lần dựng — chống lỗi PySide
        # thu gom wrapper tạm (do itemAt/parentItem ở đường hover/
        # click tạo ra) làm C++ item bị xoá khỏi cảnh, và để
        # refresh() tự phát hiện cảnh hỏng mà dựng lại tự lành (xem
        # _rebuild_scene/_scene_intact).
        self._scene_items: list = []
        self._scene_item_count: int = -1
        # V6.1: sự cố cần xử lý (tính lại mỗi ISSUES_INTERVAL giây) +
        # huy hiệu ⚠ theo agent cho bàn/ô.
        self._issues: list[dict] = []
        self._issues_at = 0.0
        self._issue_badges: dict[int, dict] = {}
        self._build_ui()
        # V4.3.2: fit khung diorama BẤT ĐỊNH theo nhịp sự kiện (gom
        # các resize liên tiếp, chạy khi kích thước viewport đã ổn
        # định) — bản cũ fit ngay trong resizeEvent nên có lúc khoá
        # phải transform tính từ viewport tạm thời lúc dựng cửa sổ
        # (đã tái hiện: scale kẹt 0.258 dù cảnh 1060×680).
        self._fit_timer = QTimer(self)
        self._fit_timer.setSingleShot(True)
        self._fit_timer.setInterval(30)
        self._fit_timer.timeout.connect(self._do_scheduled_fit)
        self._anim_timer = QTimer(self)
        self._anim_timer.setInterval(500)
        self._anim_timer.timeout.connect(self._animate_tick)
        self.refresh()

    # ------------------------------------------------------------------ #
    # Dựng giao diện
    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        # V5.3.1 (M3d): lề phải của GỐC = 0 để panel chi tiết SÁT
        # mép phải vùng chứa (lệnh chủ kênh "sát viền luôn"); hai
        # hàng header/toolbar tự giữ lề phải 16px như cũ để phần
        # còn lại của tab không đổi.
        root.setContentsMargins(8, 10, 0, 10)
        root.setSpacing(8)

        header = QHBoxLayout()
        header.setContentsMargins(0, 0, 16, 0)
        header.addWidget(theme.section_header("🏢 Văn phòng — Điều phối viên & các Muse"))
        header.addStretch(1)
        # V4.2 (O-25): bộ chọn agent — văn phòng chỉ VẼ tối đa 8 bàn
        # nhưng panel chi tiết phải với tới MỌI agent (thứ 9 trở đi
        # chọn ở đây hoặc từ nơi khác trong app).
        header.addWidget(theme.muted_label("Xem agent:"))
        self.agent_picker = QComboBox()
        self.agent_picker.setMinimumWidth(170)
        self.agent_picker.currentIndexChanged.connect(self._on_agent_picked)
        header.addWidget(self.agent_picker)
        self.stats_label = QLabel("")
        self.stats_label.setObjectName("Muted")
        header.addWidget(self.stats_label)
        # V6.3: chuyển 2D / 3D (góc phải trên) + ẩn/hiện panel chi tiết.
        from PySide6.QtWidgets import QButtonGroup as _QButtonGroup

        self._mode_group = _QButtonGroup(self)
        self.mode_buttons = {}
        for key, label, tip in (
            ("iso", "🏢 Văn phòng 3D", "Phòng làm việc 3D: trưởng phòng giao việc, agent nhận việc/báo cáo có hiệu ứng + luồng trao đổi"),
            ("2d", "▦ 2D", "Sơ đồ phẳng: mỗi agent một thẻ lớn, trải hết bề ngang"),
            ("3d", "🧊 Khoang", "Khoang làm việc 3D (bản V6.4): nhân vật robot khối, bấm cả khoang để chọn"),
            ("classic", "🏢 Sàn cũ", "Văn phòng ảnh nền isometric của bản trước"),
        ):
            button = QPushButton(label)
            button.setCheckable(True)
            button.setToolTip(tip)
            button.clicked.connect(lambda _c=False, k=key: self.set_view_mode(k))
            self._mode_group.addButton(button)
            self.mode_buttons[key] = button
            header.addWidget(button)
        self.panel_toggle = QPushButton("◂ Chi tiết")
        self.panel_toggle.setCheckable(True)
        self.panel_toggle.setToolTip("Ẩn/hiện panel chi tiết agent (tự ẩn khi bấm vùng trống)")
        self.panel_toggle.clicked.connect(lambda checked: self._set_detail_visible(checked, manual=True))
        header.addWidget(self.panel_toggle)
        root.addLayout(header)

        # V4.3 (G2): thanh công cụ sàn — tìm agent (gõ là cuộn tới +
        # phát sáng), chọn mật độ bố trí, zoom + vừa khung, lọc chỉ
        # hiện agent đang có việc. Cần thiết khi sàn có 10–100+ agent.
        toolbar = QHBoxLayout()
        toolbar.setContentsMargins(0, 0, 16, 0)
        toolbar.setSpacing(8)
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("🔍 Tìm agent…")
        self.search_edit.setMaximumWidth(220)
        self.search_edit.textChanged.connect(self._on_search_text)
        toolbar.addWidget(self.search_edit)
        toolbar.addWidget(theme.muted_label("Mật độ:"))
        self.density_combo = QComboBox()
        for key, label in DENSITY_LABELS.items():
            self.density_combo.addItem(label, key)
        current_density = str(self._settings.get("office_density") or "auto")
        index = self.density_combo.findData(current_density)
        if index >= 0:
            self.density_combo.setCurrentIndex(index)
        self.density_combo.currentIndexChanged.connect(self._on_density_changed)
        toolbar.addWidget(self.density_combo)
        self.only_working_check = QCheckBox("Chỉ hiện đang làm việc")
        self.only_working_check.toggled.connect(lambda _c: self._rebuild_scene())
        toolbar.addWidget(self.only_working_check)
        toolbar.addStretch(1)
        toolbar.addWidget(theme.muted_label("Zoom:"))
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(40, 200)
        self.zoom_slider.setValue(100)
        self.zoom_slider.setMaximumWidth(140)
        self.zoom_slider.valueChanged.connect(self._on_zoom_changed)
        toolbar.addWidget(self.zoom_slider)
        self.fit_button = QPushButton("⤢ Vừa khung")
        self.fit_button.clicked.connect(self._fit_view)
        toolbar.addWidget(self.fit_button)
        # V6.6: gói thanh công cụ sàn vào một khung để ẩn ở Văn phòng 3D.
        self.toolbar_host = QWidget()
        self.toolbar_host.setLayout(toolbar)
        root.addWidget(self.toolbar_host)

        # V6.1: KHỐI SỰ CỐ CẦN XỬ LÝ — lỗi thật + cách xử lý + nút
        # thao tác ngay tại chỗ (thay cho bong bóng "0%" mơ hồ).
        issues_wrap = QHBoxLayout()
        issues_wrap.setContentsMargins(0, 0, 16, 0)
        self.issues_panel = IssuesPanel(self._settings)
        self.issues_panel.action_requested.connect(self.issue_action_requested.emit)
        issues_wrap.addWidget(self.issues_panel)
        root.addLayout(issues_wrap)

        # V5.3.1 (M3c): scene và panel chi tiết ngăn bằng SPLITTER
        # NGANG kéo tay (trước: panel ghim cứng 320px) — bề rộng
        # panel lưu vào settings office_detail_width như các
        # splitter khác của app, khoảng kéo 280–560px do min/max
        # của panel giữ.
        body = QSplitter(Qt.Orientation.Horizontal)
        body.setHandleWidth(6)
        body.setChildrenCollapsible(False)
        self.body_splitter = body
        self._scene = _OfficeScene(self)
        self._scene.setSceneRect(0, 0, SCENE_W, SCENE_H)
        # V4.3.2: tắt BSP index — scene nhỏ (vài trăm item), quét
        # tuyến tính luôn tươi sau mỗi clear()+dựng lại, loại hẳn
        # nguy cơ index cũ làm rơi item khi sơn lại từng phần.
        self._scene.setItemIndexMethod(QGraphicsScene.NoIndex)
        self.view = _OfficeGraphicsView(self._scene)
        self.view.setRenderHint(QPainter.Antialiasing)
        # V4.3.2: sơn lại TOÀN viewport mỗi lần cập nhật thay vì chỉ
        # vùng thay đổi — cảnh nhỏ nên rẻ, và không còn đường nào để
        # một item "không được sơn lại" trên Windows (một nửa căn
        # nguyên lỗi mất nền V4.3.1).
        self.view.setViewportUpdateMode(QGraphicsView.FullViewportUpdate)
        self.view.setBackgroundBrush(QBrush(QColor(theme.BG)))
        self.view.setFrameShape(QFrame.NoFrame)
        self.view.mousePressEvent = self._on_view_click
        self.view.mouseMoveEvent = self._on_view_hover
        self.view.setMouseTracking(True)
        from PySide6.QtWidgets import QStackedWidget as _QStacked

        from .office_2d import Office2DView

        self.view2d = Office2DView()
        self.view2d.agent_clicked.connect(self._on_2d_click)
        self.view_stack = _QStacked()
        from .office_3d import Office3DView

        self.view3d = Office3DView()
        self.view3d.agent_clicked.connect(self._on_2d_click)
        self.view_stack.addWidget(self.view)     # 0 = sàn cũ (ảnh nền)
        self.view_stack.addWidget(self.view2d)   # 1 = 2D
        self.view_stack.addWidget(self.view3d)   # 2 = 3D khoang (V6.4)
        # V6.6: VĂN PHÒNG 3D mới — trưởng phòng + agent + hiệu ứng giao/nhận/báo cáo.
        from .office_iso import OfficeIsoView

        self.view_iso = OfficeIsoView(self._store, self._settings)
        self.view_iso.agent_clicked.connect(self._on_2d_click)
        self.view_stack.addWidget(self.view_iso)  # 3 = Văn phòng 3D (V6.6)
        body.addWidget(self.view_stack)
        body.addWidget(self._build_detail_panel())
        body.setStretchFactor(0, 1)
        body.setStretchFactor(1, 0)
        # Bề rộng panel đã lưu (M3c) — áp ngay khi dựng; scene nhận
        # phần còn lại. Tổng giả định theo bề rộng tab thường gặp;
        # splitter tự chuẩn hoá khi cửa sổ có kích thước thật.
        saved_width = int(self._settings.get("office_detail_width") or 320)
        saved_width = max(280, min(560, saved_width))
        body.setSizes([1600 - saved_width, saved_width])
        body.splitterMoved.connect(self._on_body_splitter_moved)
        # Bộ đệm lưu bề rộng panel: kéo liên tục chỉ ghi settings
        # MỘT lần khi dừng tay (~400ms, mẫu table_persist).
        self._width_save_timer = QTimer(self)
        self._width_save_timer.setSingleShot(True)
        self._width_save_timer.setInterval(400)
        self._width_save_timer.timeout.connect(self._save_detail_width)
        root.addWidget(body, 1)

        # V4.3 (G2): minimap góc dưới-phải của khung sàn — chỉ hiện
        # khi cảnh lớn hơn khung nhìn (mức lưới/tường ô).
        self.minimap = QGraphicsView(self._scene)
        self.minimap.setParent(self)
        self.minimap.setRenderHint(QPainter.Antialiasing)
        self.minimap.setBackgroundBrush(QBrush(QColor(theme.BG)))
        self.minimap.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.minimap.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.minimap.setInteractive(False)
        self.minimap.setFixedSize(190, 128)
        self.minimap.setVisible(False)
        self._kpi_scores: dict = {}
        self._kpi_at = 0.0
        if not self._settings.get("office_view_v66_seen"):
            # V6.6: lần đầu chạy bản này → mở thẳng Văn phòng 3D mới.
            self._settings["office_view_v66_seen"] = True
            if str(self._settings.get("office_view_mode") or "3d") == "3d":
                self._settings["office_view_mode"] = "iso"  # mặc định cũ → bản mới; chọn 2D/Sàn cũ thì giữ
        mode = str(self._settings.get("office_view_mode") or "iso")
        self.set_view_mode(mode if mode in ("iso", "2d", "3d", "classic") else "iso", save=False)
        self.panel_toggle.setChecked(True)

    def _build_detail_panel(self) -> QFrame:
        # V5.1 (plan §2.1 — dựng lại HOÀN TOÀN sau sự cố máy thật):
        # header CỐ ĐỊNH (avatar 56px + tên/mail + pill, không phần
        # tử nào chồng nhãn nào — nhãn "CHI TIẾT AGENT" bỏ hẳn),
        # thân là QScrollArea CUỘN DỌC chứa mọi khối việc, khung
        # chat nằm NGOÀI vùng cuộn ở đáy panel (V5.2.1: thu/mở —
        # mặc định thu gọn nhường chiều cao cho khối việc, xem khối
        # dựng chat ở cuối hàm). Hai nút nhảy "Mở tab Lệnh"/"Tài
        # khoản Muse" đã bỏ:
        # việc và chat đều tại chỗ trong panel này (điều hướng bằng
        # thanh tab như mọi mục).
        panel = QFrame()
        panel.setObjectName("Panel")
        # V5.3.1 (M3c): panel KÉO RỘNG được qua splitter ngang —
        # bỏ ghim cứng 320px, giữ khoảng kéo 280–560px.
        panel.setMinimumWidth(280)
        panel.setMaximumWidth(560)
        self.detail_panel = panel
        layout = QVBoxLayout(panel)
        # V5.2: đệm thẻ theo ảnh mẫu (20px) cho panel chi tiết.
        # V5.3.2 (mục 6 — chat sát viền): lề NGANG của layout gốc
        # bỏ hẳn — header và khối việc tự giữ lề 20px của mình,
        # còn SPLITTER (thân cuộn + khung chat) tràn hết bề ngang
        # panel: khung chat không còn bị hai tầng lề (20 của panel
        # + 18 của chính nó) bóp lại như trước.
        # V5.3.3 (V3 — lệnh chủ kênh): lề DƯỚI = 1px — mép dưới
        # của khối chat (đáy splitter) cách viền dưới panel đúng
        # 1px thay vì 16px như cũ; các phía còn lại giữ nguyên.
        layout.setContentsMargins(0, 16, 0, 1)
        layout.setSpacing(12)

        # ----- Header cố định -----
        header = QWidget()
        self.header_widget = header
        header.setFixedHeight(76)
        head = QHBoxLayout(header)
        head.setContentsMargins(20, 0, 20, 0)
        head.setSpacing(10)
        self.avatar_label = QLabel()
        self.avatar_label.setFixedSize(56, 56)
        head.addWidget(self.avatar_label)
        names = QVBoxLayout()
        names.setSpacing(2)
        self.name_label = QLabel("Chưa chọn agent")
        self.name_label.setObjectName("CardTitle")
        self.name_label.setWordWrap(True)
        names.addWidget(self.name_label)
        self.agent_status_label = QLabel("")
        self.agent_status_label.setObjectName("Muted")
        self.agent_status_label.setWordWrap(True)
        names.addWidget(self.agent_status_label)
        head.addLayout(names, 1)
        self.state_label = theme.pill("—", "unknown")
        head.addWidget(self.state_label, 0, Qt.AlignTop)
        layout.addWidget(header)

        # ----- Thân cuộn dọc -----
        self.detail_scroll = QScrollArea()
        self.detail_scroll.setWidgetResizable(True)
        self.detail_scroll.setFrameShape(QFrame.NoFrame)
        self.detail_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarAlwaysOff
        )
        # Nền viewport TỐI như panel (bài học §10): QSS toàn cục
        # không đặt nền cho viewport của QScrollArea.
        self.detail_scroll.setStyleSheet(
            "QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.PANEL}; }}"
        )
        # V5.3.1 (M3e): thân panel (khối việc cuộn) và khối chat
        # ngăn bằng SPLITTER DỌC — người dùng kéo để đặt chiều
        # cao luồng chat theo ý khi chat đang bung; trạng thái
        # thu/mở tự động của V5.2.1 giữ nguyên (xem
        # _on_chat_expand_changed).
        self._applying_chat_split = False
        self._chat_split_sizes: list[int] | None = None
        self.panel_splitter = QSplitter(Qt.Orientation.Vertical)
        self.panel_splitter.setHandleWidth(6)
        self.panel_splitter.setChildrenCollapsible(False)
        self._chat_height_save_timer = QTimer(self)
        self._chat_height_save_timer.setSingleShot(True)
        self._chat_height_save_timer.setInterval(300)
        self._chat_height_save_timer.timeout.connect(
            self._save_chat_thread_height
        )
        self.panel_splitter.splitterMoved.connect(self._on_panel_splitter_moved)
        scroll_host = QWidget()
        host_layout = QVBoxLayout(scroll_host)
        # V5.3.2: khối việc tự giữ lề trái 20px như thiết kế cũ
        # (lề phải 24 = 20 + 4 thở cho thanh cuộn) sau khi layout
        # gốc của panel bỏ lề ngang để khung chat sát viền.
        host_layout.setContentsMargins(20, 0, 24, 0)
        host_layout.setSpacing(8)
        self.detail_hint = QLabel(
            "Bấm vào một bàn làm việc trong văn phòng để xem chi tiết "
            "agent: hồ sơ phụ trách, lệnh đang làm và lịch sử gần đây."
        )
        self.detail_hint.setObjectName("Muted")
        self.detail_hint.setWordWrap(True)
        host_layout.addWidget(self.detail_hint)

        self.detail_box = QWidget()
        box = QVBoxLayout(self.detail_box)
        box.setContentsMargins(0, 0, 0, 0)
        box.setSpacing(6)
        self.profiles_label = QLabel("")
        self.profiles_label.setWordWrap(True)
        box.addWidget(self.profiles_label)

        box.addWidget(theme.section_header("Việc hiện tại"))
        self.cur_title = QLabel("—")
        self.cur_title.setWordWrap(True)
        box.addWidget(self.cur_title)
        self.cur_instruction = QLabel("")
        self.cur_instruction.setObjectName("Muted")
        self.cur_instruction.setWordWrap(True)
        box.addWidget(self.cur_instruction)
        progress_row = QHBoxLayout()
        progress_row.setSpacing(8)
        self.cur_bar = QProgressBar()
        self.cur_bar.setRange(0, 100)
        self.cur_bar.setTextVisible(False)
        progress_row.addWidget(self.cur_bar, 1)
        self.cur_progress = QLabel("")
        self.cur_progress.setStyleSheet(
            f"color:{theme.ACCENT}; font-weight:700;"
        )
        progress_row.addWidget(self.cur_progress)
        box.addLayout(progress_row)
        self.cur_step = QLabel("")
        self.cur_step.setObjectName("Muted")
        self.cur_step.setWordWrap(True)
        box.addWidget(self.cur_step)
        self.cur_lease = QLabel("")
        self.cur_lease.setObjectName("Faint12")
        # V5.1 fix (đo thật trên preview): dòng lease dài KHÔNG wrap
        # ép host của vùng cuộn rộng 350px > viewport 278px → mọi
        # nhãn khác bị cắt ngang. Bật wrap cho nó như các nhãn khác.
        self.cur_lease.setWordWrap(True)
        box.addWidget(self.cur_lease)

        # Hàng đợi TIẾP THEO của agent đang chọn — pool nhãn cố định
        # (không tạo/huỷ widget theo nhịp refresh, tránh "bóng ma").
        box.addWidget(theme.section_header("Tiếp theo (hàng đợi của agent)"))
        self.next_labels: list[QLabel] = []
        for _ in range(5):
            next_label = QLabel("")
            next_label.setObjectName("Muted12")
            next_label.setWordWrap(True)
            self.next_labels.append(next_label)
            box.addWidget(next_label)
        self.next_empty = QLabel("Không có lệnh nào đang chờ.")
        self.next_empty.setObjectName("Faint12")
        box.addWidget(self.next_empty)

        box.addWidget(theme.section_header("Đã xong gần đây"))
        self.recent_labels: list[QLabel] = []
        for _ in range(5):
            recent_label = QLabel("")
            recent_label.setObjectName("Muted12")
            recent_label.setWordWrap(True)
            self.recent_labels.append(recent_label)
            box.addWidget(recent_label)
        self.recent_empty = QLabel("Chưa có lệnh nào.")
        self.recent_empty.setObjectName("Faint12")
        box.addWidget(self.recent_empty)

        # Khối "Đang làm & tiếp theo" — MỌI việc của agent theo work
        # model DÙNG CHUNG với mục Công việc; bấm một dòng → mở mục
        # Công việc chọn đúng lệnh đó. Pool nút cố định.
        # V5.1: rút ngắn tiêu đề (bản cũ "(bảng việc)" làm min-width
        # của host vượt viewport panel 320px — cùng sự cố cắt chữ).
        box.addWidget(theme.section_header("📊 Đang làm & tiếp theo"))
        self.work_buttons: list[QPushButton] = []
        for _ in range(6):
            work_button = QPushButton("")
            work_button.setProperty("variant", "ghost")
            work_button.setStyleSheet("text-align: left; padding: 3px 8px;")
            work_button.setVisible(False)
            work_button.clicked.connect(self._on_work_button_clicked)
            self.work_buttons.append(work_button)
            box.addWidget(work_button)
        self.work_empty = QLabel("Không có việc đang hoạt động.")
        self.work_empty.setObjectName("Faint12")
        box.addWidget(self.work_empty)

        # Dải luồng nhánh mini Agent → Hồ sơ → Kênh → Lệnh hiện tại.
        box.addWidget(theme.section_header("🌿 Luồng hiện tại"))
        branch_row = QHBoxLayout()
        branch_row.setSpacing(4)
        self.branch_labels: list[QLabel] = []
        for position in range(4):
            label = QLabel("—")
            label.setObjectName("Muted12")
            label.setWordWrap(True)
            self.branch_labels.append(label)
            branch_row.addWidget(label, 1)
            if position < 3:
                branch_row.addWidget(QLabel("→"))
        box.addLayout(branch_row)

        # Trạng thái luồng chat (toàn bộ khung chat nằm ngay dưới
        # vùng cuộn này — dòng này cho biết còn tin chưa đọc không
        # TRƯỚC khi mở luồng; mở panel là chat tự đánh dấu đã đọc).
        box.addWidget(theme.section_header("💬 Trò chuyện"))
        self.chat_status_label = QLabel(
            "Luồng chat ở ngay dưới — Muse trả lời tại đó."
        )
        self.chat_status_label.setObjectName("Muted12")
        self.chat_status_label.setWordWrap(True)
        box.addWidget(self.chat_status_label)
        host_layout.addWidget(self.detail_box)
        host_layout.addStretch(1)
        self.detail_scroll.setWidget(scroll_host)
        self.panel_splitter.addWidget(self.detail_scroll)
        layout.addWidget(self.panel_splitter, 1)

        # ----- Chat ở đáy panel (ngoài vùng cuộn của thân) -----
        # Component DÙNG CHUNG với mục Tài khoản Muse (cùng thread
        # trong Store, cùng đánh dấu đã đọc). V5.2.1 (góp ý máy
        # thật): bản ở đây bật chế độ THU/MỞ — mặc định chỉ còn
        # thanh tiêu đề mảnh để khối việc phía trên có đủ chiều cao;
        # tự bung khi có tin chưa đọc/câu hỏi needs_user chờ, tự thu
        # khi đã đọc/gửi xong; khi bung, luồng tin cuộn bên trong
        # khung đã chặn chiều cao (120–200px) và ô soạn nằm ngay
        # dưới luồng. (Thay chuẩn V5.1 "ô soạn ghim luôn hiện" —
        # lệnh trực tiếp của chủ kênh 30/10 thắng chuẩn cũ.)
        self.chat_widget = AgentChatWidget(
            self._store,
            wake_bridge=self._wake_bridge,
            on_store_changed=self._on_chat_store_changed,
            empty_hint=(
                "Bấm vào một bàn/robot trong văn phòng (hoặc chọn ở "
                "ô “Xem agent” phía trên) để trò chuyện với Muse đó "
                "ngay tại đây."
            ),
            # V5.2.1: bản Văn phòng bật chế độ THU/MỞ — mặc định chỉ
            # còn thanh tiêu đề mảnh, tự bung khi có tin/câu hỏi chờ,
            # tự thu khi đã xử lý xong; chiều cao KHÔNG còn bị ép tối
            # thiểu 250px như V5.1 (chính mức ép đó + luồng không
            # chặn chiều cao đã bóp khối việc của panel).
            # V5.3.2: bản này KHÔNG mang khung Panel riêng và không
            # lề ngoài (xem AgentChatWidget) — cộng với layout panel
            # bỏ lề ngang, luồng tin + dải ô nhập tràn hết bề ngang
            # panel chi tiết, hàng chữ giữ đệm trong 16px.
            collapsible=True,
        )
        # V5.3.1 (M3e): chat là nửa DƯỚI của splitter dọc — kéo
        # tay đổi chiều cao luồng (lưu office_chat_thread_height),
        # thu gọn thì splitter rút về đúng thanh tiêu đề.
        self.panel_splitter.addWidget(self.chat_widget)
        self.panel_splitter.setStretchFactor(0, 1)
        self.panel_splitter.setStretchFactor(1, 0)
        self.chat_widget.expand_changed.connect(self._on_chat_expand_changed)
        saved_thread = int(self._settings.get("office_chat_thread_height") or 0)
        if saved_thread > 0:
            # Đã có chiều cao kéo tay từ phiên trước: bật dải kéo
            # tay ngay; kích thước splitter áp khi chat bung lần
            # đầu qua _on_chat_expand_changed.
            self.chat_widget.set_user_thread_height(saved_thread)
        self.detail_box.setVisible(False)
        return panel

    # ------------------------------------------------------------------ #
    # Làm mới từ Store
    # ------------------------------------------------------------------ #
    @staticmethod
    def _data_fingerprint(agents, commands, bridge, profiles, counts,
                          chat_unread=None, pending_questions=None) -> tuple:
        """Vân dữ liệu QUYẾT ĐỊNH VẼ (O-09): mọi trường THẬT SỰ ảnh
        hưởng cảnh/panel — KHÔNG gồm các giá trị tự trôi theo thời
        gian (seconds_ago của cầu nối, giây lease còn lại: hai thứ đó
        cập nhật riêng trên tick mà không dựng lại cảnh)."""
        return (
            tuple(
                (
                    a.get("id"), a.get("name"), a.get("email"),
                    a.get("status"), bool(a.get("revoked")),
                    a.get("current_command_id"),
                    tuple(a.get("profile_ids") or []),
                )
                for a in agents
            ),
            tuple(
                (
                    c.get("id"), c.get("status"), c.get("type"),
                    c.get("source"), c.get("progress"), c.get("step"),
                    c.get("instruction"), c.get("agent_id"),
                    c.get("lease_agent_id"), c.get("lease_expires_at"),
                    c.get("profile_id"), c.get("profile_slug"),
                    c.get("created_at"), c.get("finished_at"),
                )
                for c in commands
            ),
            (
                bool(bridge.get("connected")), bool(bridge.get("ever")),
                bool(bridge.get("any_agent_online")),
            ),
            tuple((p.get("id"), p.get("label")) for p in profiles),
            tuple(sorted((counts or {}).items())),
            # V4.6: huy hiệu chat + câu hỏi chờ cũng là dữ liệu QUYẾT
            # ĐỊNH VẼ (bong bóng/huy hiệu trên bàn) — phải vào vân.
            tuple(sorted(
                (int(k), int(v)) for k, v in (chat_unread or {}).items()
            )),
            tuple(sorted(
                (int(k), str(v))
                for k, v in (pending_questions or {}).items()
            )),
        )

    def refresh(self):
        agents = self._store.list_agents()
        commands = self._store.list_commands(limit=200)
        bridge = self._store.bridge_state()
        profiles = self._store.list_profiles()
        # V4.3 (G2): giữ dữ liệu thô cho panel chi tiết + mức mật độ.
        self._raw_agents = agents
        self._raw_commands = commands
        self._raw_profiles = profiles
        self._tier = density_tier(
            len(agents), str(self._settings.get("office_density") or "auto")
        )
        self._profiles_by_id = {p["id"]: p for p in profiles}
        # V4.2 (O-07): tổng số TOÀN CỤC bằng aggregate SQL — danh sách
        # lệnh ở đây bị cắt 200 nên đếm từ nó sẽ thiếu khi hệ thống lớn.
        counts = self._store.command_status_counts()
        counts["done_today"] = self._store.count_done_today()
        self._channel_counts = self._store.channel_counts_by_profile()
        # V4.6 (10:46): dữ liệu CHAT cho huy hiệu 💬 + bong bóng câu
        # hỏi trên từng bàn — số tin user chưa đọc (tin Muse + tin
        # hệ thống) theo agent, và câu hỏi đang chờ của lệnh
        # needs_user (lý do nằm ở result/step của lệnh). Cả hai vào
        # VÂN dữ liệu: đổi là dựng lại cảnh, không đổi thì thôi —
        # đúng kỷ luật hiệu năng O-09.
        unread_counts = self._store.unread_counts()
        chat_unread = {
            int(aid): int(c.get("agent", 0)) + int(c.get("system", 0))
            for aid, c in (unread_counts or {}).items()
        }
        chat_unread = {aid: n for aid, n in chat_unread.items() if n}
        pending_questions: dict[int, str] = {}
        pending_keys: dict[int, str] = {}
        for command in commands:
            if command.get("status") != "needs_user":
                continue
            owner_id = command.get("agent_id")
            if not owner_id and command.get("profile_id"):
                for agent in agents:
                    if int(command["profile_id"]) in (
                        agent.get("profile_ids") or []
                    ):
                        owner_id = agent["id"]
                        break
            if owner_id and int(owner_id) not in pending_questions:
                reason = (
                    command.get("result") or command.get("step") or ""
                ).strip()
                pending_questions[int(owner_id)] = reason[:80]
                # V5.2.1: khoá ổn định của câu hỏi (id lệnh) để
                # khung chat thu/mở phân biệt câu hỏi MỚI với câu
                # hỏi người dùng đã chủ động thu gọn.
                pending_keys[int(owner_id)] = str(command.get("id"))
        self._pending_question_keys = pending_keys
        self.refresh_issues()
        fingerprint = self._data_fingerprint(
            agents, commands, bridge, profiles, counts,
            chat_unread, pending_questions,
        ) + (tuple(sorted(
            (aid, b["count"], b["worst"]) for aid, b in self._issue_badges.items()
        )),)
        if fingerprint == self._fingerprint and self._model is not None:
            # O-09: dữ liệu không đổi → KHÔNG dựng lại cảnh/panel;
            # chỉ làm mới đếm ngược lease (giá trị trôi theo giờ).
            # V4.6: NGOẠI LỆ tự lành — vân không đổi nhưng cảnh đã
            # mất item (lỗi vòng đời wrapper PySide, xem
            # _rebuild_scene) thì vẫn phải dựng lại, không về sớm.
            if self._scene_intact():
                self._refresh_lease_label()
                return
        self._fingerprint = fingerprint
        self._model = office_scene.build_office_scene(
            agents, commands, bridge, profiles, counts=counts,
            chat_unread=chat_unread, pending_questions=pending_questions,
        )
        stats = self._model["stats"]
        self.stats_label.setText(
            f"🤖 Online {stats['agents_online']}/{stats['agents_total']}"
            f"   ▶ Đang chạy {stats['running']}"
            f"   ⏳ Hàng đợi {stats['queued_total']}"
            f"   ✋ Chờ người {stats['needs_user']}"
            f"   ✅ Xong hôm nay {stats['done_today']}"
        )
        self._rebuild_scene()
        self._update_2d(chat_unread)
        self._sync_agent_picker(agents)
        known_ids = {a["id"] for a in agents}
        if self._selected_agent_id not in known_ids:
            self._selected_agent_id = (
                self._model["desks"][0]["agent_id"] if self._model["desks"] else None
            )
        self._sync_picker_selection()
        self._update_detail()

    def refresh_issues(self, force: bool = False) -> None:
        """V6.1: tính lại danh sách sự cố (tiết lưu ISSUES_INTERVAL)."""
        now = time.monotonic()
        if not force and now - self._issues_at < self.ISSUES_INTERVAL:
            return
        self._issues_at = now
        try:
            issues = office_issues.collect_issues(
                self._store,
                bridge_enabled=bool(self._settings.get("agent_enabled", True)),
            )
        except Exception:
            logging.getLogger(__name__).exception("collect_issues lỗi")
            issues = []
        # V6.7: kèm quyết định GẦN NHẤT của trưởng phòng cho từng sự cố.
        for issue in issues:
            try:
                last = self._store.last_lead_decision_for(issue.get("key") or "")
            except Exception:
                last = None
            if last:
                when = str(last.get("at") or "")[11:16]
                verb = "đã báo bạn" if last.get("outcome") == "escalated" else "đã xử lý"
                issue["lead_note"] = f"{verb} {when} — {last.get('detail')}"
        self._issues = issues
        self._issue_badges = office_issues.issues_by_agent(issues)
        self.issues_panel.set_issues(issues)
        # V6.3: khối sự cố TỰ ẨN khi không có sự cố nào.
        self.issues_panel.setVisible(bool(issues))
        if force:
            self._fingerprint = None

    def _sync_agent_picker(self, agents) -> None:
        """Đồng bộ danh sách bộ chọn agent với dữ liệu (giữ lựa chọn
        hiện tại; chặn tín hiệu để không tự kích hoạt chọn lại)."""
        signature = tuple(
            (a["id"], a.get("name") or a.get("email") or f"Muse #{a['id']}")
            for a in agents
        )
        if getattr(self, "_picker_signature", None) == signature:
            return
        self._picker_signature = signature
        self.agent_picker.blockSignals(True)
        try:
            self.agent_picker.clear()
            for agent_id, label in signature:
                self.agent_picker.addItem(label, agent_id)
        finally:
            self.agent_picker.blockSignals(False)
        self._sync_picker_selection()

    def _sync_picker_selection(self) -> None:
        if self._selected_agent_id is None:
            return
        index = self.agent_picker.findData(self._selected_agent_id)
        if index >= 0 and self.agent_picker.currentIndex() != index:
            self.agent_picker.blockSignals(True)
            try:
                self.agent_picker.setCurrentIndex(index)
            finally:
                self.agent_picker.blockSignals(False)

    def _on_agent_picked(self, index: int) -> None:
        agent_id = self.agent_picker.itemData(index)
        if agent_id is not None:
            self.select_agent(int(agent_id))

    def _selected_desk(self) -> dict | None:
        if not self._model:
            return None
        for desk in self._model.get("desks_all") or self._model.get("desks") or []:
            if desk["agent_id"] == self._selected_agent_id:
                return desk
        return None

    def _lease_text(self) -> str:
        """Dòng đếm ngược lease của lệnh hiện tại — tính LẠI từ mốc
        ``lease_expires_at`` thô trong mô hình đã lưu nên tick 1
        giây làm mới được mà không cần dựng lại cảnh (O-09)."""
        from datetime import datetime

        desk = self._selected_desk()
        current = (desk or {}).get("current") or {}
        if current.get("status") != "running":
            return ""
        left = office_scene.lease_seconds_left(
            {"lease_expires_at": current.get("lease_expires_at")},
            datetime.now().astimezone(),
        )
        if left is None:
            return ""
        return (
            f"Lease còn {left // 60}:{left % 60:02d} — quá hạn không "
            "tín hiệu, app sẽ thu hồi lệnh."
        )

    def _refresh_lease_label(self) -> None:
        if hasattr(self, "cur_lease"):
            self.cur_lease.setText(self._lease_text())

    def _animate_tick(self):
        self._blink_on = not self._blink_on
        for item in self._blink_items:
            item.setVisible(self._blink_on)
        for group, base_y in self._bob_items:
            group.setY(base_y + (2 if self._blink_on else -1))
        # V4.2 (O-09): tick hoạt cảnh cũng làm mới đếm ngược lease.
        self._refresh_lease_label()

    def showEvent(self, event):
        super().showEvent(event)
        if not self._anim_timer.isActive():
            self._anim_timer.start()
        self._schedule_fit()

    def hideEvent(self, event):
        self._anim_timer.stop()
        super().hideEvent(event)

    def _schedule_fit(self):
        """Hẹn fit lại khung diorama sau 30ms yên ắng (V4.3.2): mọi
        resize/show/dựng-lại-cảnh đều đi qua đây để transform cuối
        luôn tính từ viewport ĐÃ ỔN ĐỊNH, không kẹt số đo tạm thời."""
        timer = getattr(self, "_fit_timer", None)
        if timer is not None and self._tier == TIER_DIORAMA:
            timer.start()

    def _do_scheduled_fit(self):
        if self._tier != TIER_DIORAMA:
            return
        rect = self._scene.sceneRect()
        if not rect.isNull() and self.view.viewport().width() > 50:
            self.view.fitInView(rect, Qt.KeepAspectRatio)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._schedule_fit()
        self._position_minimap()

    # ------------------------------------------------------------------ #
    # V4.3 (G2) — Điều khiển sàn: zoom / tìm kiếm / mật độ / hover
    # ------------------------------------------------------------------ #
    def _on_zoom_changed(self, value: int):
        self.view.resetTransform()
        self.view.scale(value / 100.0, value / 100.0)

    def _fit_view(self):
        rect = self._scene.sceneRect()
        if not rect.isNull():
            self.view.fitInView(rect, Qt.KeepAspectRatio)
            self.zoom_slider.setValue(100)

    # ------------------------------------------------------------------ #
    # V5.3.1 (M3c/M3e): hình học panel chi tiết do người dùng kéo tay
    # ------------------------------------------------------------------ #
    def _on_body_splitter_moved(self, _pos, _index):
        self._width_save_timer.start()

    def _save_detail_width(self):
        sizes = self.body_splitter.sizes()
        if len(sizes) == 2 and sizes[1] > 0:
            self._settings["office_detail_width"] = int(sizes[1])
            config.save_settings(self._settings)

    def _on_panel_splitter_moved(self, _pos, _index):
        """Người dùng kéo splitter dọc trong panel (M3e): khi chat
        đang bung, chiều cao luồng tin THẬT lúc dừng kéo là ý của
        người dùng — nới dải chiều cao của luồng sang dải kéo tay
        ngay từ nhịp kéo đầu, và ghi settings sau ~300ms dừng tay."""
        if self._applying_chat_split or not self.chat_widget.is_expanded:
            return
        if self.chat_widget.user_thread_height() is None:
            self.chat_widget.set_user_thread_height(
                self.chat_widget.scroll.height()
            )
        self._chat_height_save_timer.start()

    def _save_chat_thread_height(self):
        if not self.chat_widget.is_expanded:
            return
        # V5.3.3 (V4): xả sự kiện LayoutRequest TRƯỚC khi đọc —
        # sau khi dải chiều cao luồng được nới (ở splitterMoved),
        # layout chỉ phân phối lại khi hàng sự kiện đó chạy, và
        # số đọc được nếu đọc ngay sẽ là chiều cao CŨ BỊ KẸP
        # (160) thay vì chiều cao người dùng thật sự kéo tới
        # (probe: xả xong đọc đúng 386).
        QCoreApplication.sendPostedEvents(
            None, QEvent.Type.LayoutRequest
        )
        height = self.chat_widget.scroll.height()
        height = max(100, min(420, int(height)))
        self.chat_widget.set_user_thread_height(height)
        self._settings["office_chat_thread_height"] = height
        config.save_settings(self._settings)

    def _on_chat_expand_changed(self, expanded: bool):
        """Chat bung/thu (tự động hay tay): bung thì khôi phục
        chiều cao luồng đã kéo (nếu có) vào splitter dọc; thu thì
        nhớ kích thước hiện tại rồi rút vùng chat về đúng chiều
        cao thanh tiêu đề — không để khoảng trống chết."""
        if expanded:
            saved = int(self._settings.get("office_chat_thread_height") or 0)
            if saved > 0:
                self.chat_widget.set_user_thread_height(saved)
            QTimer.singleShot(0, self._restore_chat_split)
        else:
            sizes = self.panel_splitter.sizes()
            if len(sizes) == 2 and sum(sizes) > 0:
                self._chat_split_sizes = sizes
            QTimer.singleShot(0, self._collapse_chat_split)

    def _restore_chat_split(self):
        if not self.chat_widget.is_expanded:
            return
        total = self.panel_splitter.height()
        if total <= 0:
            return
        saved = int(self._settings.get("office_chat_thread_height") or 0)
        self._applying_chat_split = True
        try:
            if saved > 0:
                # Tổng chiều cao widget chat cần = luồng đã lưu +
                # phần cố định (thanh tiêu đề + dải ô nhập + …).
                # V5.3.3 (V4): phần cố định đo bằng SIZEHINT tĩnh
                # (AgentChatWidget.fixed_chrome_height) — bản cũ
                # lấy hiệu số hình học thoáng qua ngay sau khi
                # bung (layout chưa yên) nên đánh giá thấp tới
                # 28px trong môi trường có QSS và luồng khôi
                # phục hụt đúng 28px (test full-suite V5.3.2:
                # lưu 160 → khôi phục 132).
                fixed = self.chat_widget.fixed_chrome_height()
                chat_total = max(80, saved + fixed)
            elif self._chat_split_sizes and sum(self._chat_split_sizes) == total:
                chat_total = self._chat_split_sizes[1]
            else:
                chat_total = self.chat_widget.sizeHint().height()
            chat_total = max(60, min(total - 120, chat_total))
            self.panel_splitter.setSizes([total - chat_total, chat_total])
        finally:
            self._applying_chat_split = False

    def _collapse_chat_split(self):
        if self.chat_widget.is_expanded:
            return
        total = self.panel_splitter.height()
        if total <= 0:
            return
        strip = max(28, self.chat_widget.sizeHint().height())
        self._applying_chat_split = True
        try:
            self.panel_splitter.setSizes([total - strip, strip])
        finally:
            self._applying_chat_split = False

    def _on_density_changed(self):
        self._settings["office_density"] = self.density_combo.currentData()
        config.save_settings(self._settings)
        self._tier = density_tier(
            len(self._raw_agents),
            str(self._settings.get("office_density") or "auto"),
        )
        self._fingerprint = None  # ép refresh sau dựng lại theo mức mới
        self.refresh()

    def _on_search_text(self, text: str):
        """Gõ tên/mail agent → chọn agent đầu tiên khớp, cuộn khung
        nhìn tới bàn/ô của nó và phát sáng (khung chọn sẵn có)."""
        query = (text or "").strip().casefold()
        if not query or not self._model:
            return
        for desk in self._model.get("desks_all") or []:
            haystack = f"{desk.get('name') or ''} {desk.get('email') or ''}".casefold()
            if query in haystack:
                self.select_agent(int(desk["agent_id"]))
                bounds = self._desk_bounds.get(int(desk["agent_id"]))
                if bounds is not None and self._tier != TIER_DIORAMA:
                    self.view.centerOn(bounds.center())
                return

    def _on_view_hover(self, event):
        """Hover lên một bàn/ô: bàn phát sáng (khung hover) + thẻ
        tooltip hiện tên agent, việc hiện tại và % — liếc là biết
        con đó đang làm gì."""
        item = self._scene.itemAt(
            self.view.mapToScene(event.pos()), self.view.transform()
        )
        agent_id = None
        while item is not None:
            data = item.data(0)
            if data is not None:
                agent_id = int(data)
                break
            item = item.parentItem()
        if agent_id != self._hover_agent_id:
            self._hover_agent_id = agent_id
            self._update_hover_rect()
        if agent_id is not None:
            desk = None
            for candidate in (self._model or {}).get("desks_all") or []:
                if candidate["agent_id"] == agent_id:
                    desk = candidate
                    break
            if desk is not None:
                current = desk.get("current")
                if current:
                    detail = (
                        f"{current['type_label']} — "
                        f"{int(current.get('progress') or 0)}%"
                    )
                else:
                    detail = desk["state_label"]
                QToolTip.showText(
                    event.globalPosition().toPoint(),
                    f"🤖 {desk['name']}\n{detail}",
                    self.view,
                )
        QGraphicsView.mouseMoveEvent(self.view, event)

    def _update_hover_rect(self):
        if self._hover_rect is not None:
            self._scene.removeItem(self._hover_rect)
            self._hover_rect = None
        if self._hover_agent_id is None:
            return
        bounds = self._desk_bounds.get(self._hover_agent_id)
        if bounds is None:
            return
        rect = _RoundRect(
            bounds.x() - 3, bounds.y() - 3,
            bounds.width() + 6, bounds.height() + 6,
            12, None, "#38BDF8", 2.2,
        )
        rect.setZValue(50)
        self._scene.addItem(rect)
        self._hover_rect = rect

    def _position_minimap(self):
        """Minimap chỉ hiện khi cảnh lớn hơn khung nhìn (mức lưới)."""
        if not hasattr(self, "minimap"):
            return
        scene_rect = self._scene.sceneRect()
        viewport = self.view.viewport().size()
        need = (
            self._tier != TIER_DIORAMA
            and (scene_rect.width() > viewport.width()
                 or scene_rect.height() > viewport.height())
        )
        self.minimap.setVisible(bool(need))
        if need:
            view_pos = self.view.mapTo(self, self.view.rect().bottomRight())
            self.minimap.move(
                view_pos.x() - self.minimap.width() - 10,
                view_pos.y() - self.minimap.height() - 10,
            )
            self.minimap.raise_()
            self.minimap.fitInView(scene_rect, Qt.KeepAspectRatio)

    # ------------------------------------------------------------------ #
    # Vẽ cảnh
    # ------------------------------------------------------------------ #
    def _scene_intact(self) -> bool:
        """Cảnh đang hiện còn đủ item như lúc dựng xong không? Khung
        hover là item phụ trợ (thêm/bớt theo chuột) nên không tính.
        Số item lệch = cảnh đã mất item → refresh() phải dựng lại
        dù vân dữ liệu không đổi (cơ chế tự lành)."""
        if self._scene_item_count < 0:
            return True
        current = sum(
            1 for item in self._scene.items()
            if item is not self._hover_rect
        )
        return current == self._scene_item_count

    def _rebuild_scene(self):
        """Dựng cảnh NGUYÊN TỬ (V4.6 — sửa lỗi mất hình trên máy thật).

        Hai lớp bảo vệ:
        1) Dựng vào một _OfficeScene MỚI rồi mới hoán đổi cho view +
           minimap: populate lỗi giữa chừng thì cảnh cũ còn nguyên
           trên màn hình (ghi log), KHÔNG bao giờ lộ cảnh rỗng nửa
           vời như đường clear()-rồi-vẽ-lại trước đây.
        2) Giữ THAM CHIẾU PYTHON mạnh tới mọi item của cảnh đang
           hiện (self._scene_items). Căn nguyên đã tái hiện trong
           sandbox: item dựng bằng object Python cục bộ có thể bị
           PySide XOÁ khỏi scene khi wrapper tạm do itemAt()/
           parentItem() (đường hover/click) tạo ra bị thu gom rác —
           chỉ hover qua robot Điều phối viên đã làm mất nguyên nhóm
           robot (14 item); có tham chiếu giữ mạnh thì item sống
           cùng cảnh. Chữ trạng thái rỗng chỉ vẽ khi model THẬT SỰ
           không có bàn nào.
        """
        saved = (
            self._bob_items, self._blink_items, self._desk_bounds,
            self._hover_rect, self._hover_agent_id,
        )
        old_scene = self._scene
        new_scene = _OfficeScene(self)
        new_scene.setSceneRect(0, 0, SCENE_W, SCENE_H)
        # Như cảnh gốc (V4.3.2): NoIndex — quét tuyến tính luôn tươi.
        new_scene.setItemIndexMethod(QGraphicsScene.NoIndex)
        self._scene = new_scene
        self._bob_items = []
        self._blink_items = []
        self._desk_bounds = {}
        self._hover_rect = None
        self._hover_agent_id = None
        try:
            model = self._model or {}
            if self._tier != TIER_DIORAMA:
                self._rebuild_grid_scene(model)
            else:
                scene = self._scene
                # V4.3.2: sàn + vỏ phòng KHÔNG còn là item — scene
                # tự sơn trong drawBackground (xem _OfficeScene),
                # không thể bị mất.
                scene.shell_diorama = True
                self._draw_manager_office(model.get("manager") or {})
                self._draw_decor_zone()
                self._draw_queue_board(model)
                desks = model.get("desks") or []
                if not desks:
                    scene.addItem(_text(
                        190, 400,
                        "Chưa có tài khoản Muse nào — thêm ở tab 🤖 Tài khoản Muse,\n"
                        "các bàn làm việc sẽ hiện ở đây.",
                        13, False, _INK_SOFT, width=680, align_center=True,
                    ))
                for index, desk in enumerate(desks):
                    self._draw_desk(index, desk)
                if model.get("desks_overflow"):
                    scene.addItem(_text(
                        700, SCENE_H - 30,
                        f"+{model['desks_overflow']} agent nữa (tối đa {office_scene.MAX_DESKS} bàn/trang)",
                        9, False, _INK_SOFT,
                    ))
        except Exception:
            log.exception(
                "Dựng cảnh Văn phòng lỗi — giữ nguyên cảnh cũ đang hiện."
            )
            (self._bob_items, self._blink_items, self._desk_bounds,
             self._hover_rect, self._hover_agent_id) = saved
            self._scene = old_scene
            new_scene.deleteLater()
            return
        # Hoán đổi nguyên tử: view + minimap cùng sang cảnh mới, giữ
        # tham chiếu mạnh tới mọi item của cảnh mới.
        self.view.setScene(new_scene)
        self.minimap.setScene(new_scene)
        self._scene_items = list(new_scene.items())
        self._scene_item_count = len(self._scene_items)
        if old_scene is not new_scene:
            old_scene.deleteLater()
        if self.isVisible():
            self._schedule_fit()
        self._position_minimap()

    # ------------------------------------------------------------------ #
    # V4.3 (G2) — Sàn dạng lưới khi đông agent (medium/compact/wall)
    # ------------------------------------------------------------------ #
    def _rebuild_grid_scene(self, model: dict):
        scene = self._scene
        desks = list(model.get("desks_all") or [])
        if self.only_working_check.isChecked():
            desks = [
                d for d in desks
                if d.get("current") or d.get("queue_count")
                or d.get("state") in ("working", "needs_user", "waiting")
            ]
        tier = self._tier
        if tier == TIER_MEDIUM:
            cell_w, cell_h, cols = 252, 118, 4
        elif tier == TIER_COMPACT:
            cell_w, cell_h, cols = 202, 88, 5
        else:  # TIER_WALL
            cell_w, cell_h, cols = 168, 66, 6
        margin, gap = 16, 10
        animate = len(desks) <= 30  # >30 agent: tắt hoạt ảnh bong bóng/nhún

        # Tường ô: chia KHU theo trạng thái (đang làm lên trước).
        groups: list[tuple[str, list[dict]]] = []
        if tier == TIER_WALL:
            zone_order = [
                ("needs_user", "✋ Chờ người xử lý"),
                ("working", "▶ Đang làm"),
                ("waiting", "⏳ Đang chờ việc"),
                ("idle", "💤 Đang rảnh"),
                ("offline", "⚪ Ngoại tuyến"),
            ]
            for state, label in zone_order:
                members = [d for d in desks if d.get("state") == state]
                if members:
                    groups.append((label, members))
        else:
            groups = [("", desks)]

        y = margin
        for label, members in groups:
            if label:
                scene.addItem(_text(margin, y, f"{label} ({len(members)})", 12, True, "#FFFFFF"))
                y += 26
            for index, desk in enumerate(members):
                col, row = index % cols, index // cols
                x = margin + col * (cell_w + gap)
                tile_y = y + row * (cell_h + gap)
                self._draw_tile(x, tile_y, cell_w, cell_h, desk, tier, animate)
            rows = (len(members) + cols - 1) // cols
            y += rows * (cell_h + gap) + 14
        width = margin * 2 + cols * cell_w + (cols - 1) * gap
        scene.setSceneRect(0, 0, width, max(200, y))
        # V4.3.2: bậc lưới nền = màu app, do drawBackground của
        # _OfficeScene sơn (shell_diorama=False) — mọi bậc đều có
        # nền riêng rõ ràng, không khoảng đen trống.
        self._scene.shell_diorama = False
        self._position_minimap()

    def _draw_tile(self, x, y, w, h, desk: dict, tier: str, animate: bool):
        scene = self._scene
        agent_id = int(desk["agent_id"])
        selected = agent_id == self._selected_agent_id
        state = desk["state"]
        border = _STATE_DOT.get(state, "#9CA3AF")
        tile = _RoundRect(
            x, y, w, h, 10, "#FFFFFF",
            theme.ACCENT if selected else border, 2.0 if selected else 1.2,
        )
        tile.setData(0, agent_id)
        scene.addItem(tile)
        self._desk_bounds[agent_id] = QRectF(x, y, w, h)
        # Đầu robot thu nhỏ ở góc trái ô.
        group, robot = _robot_group(
            desk["color"], grey=(state == "offline")
        )
        scale = 0.34 if tier == TIER_WALL else 0.42
        group.setScale(scale)
        group.setPos(x + 26, y + h - 8)
        group.setData(0, agent_id)
        scene.addItem(group)
        if animate and state == "working":
            self._bob_items.append((robot, 0.0))
        dot = QGraphicsEllipseItem(QRectF(x + w - 18, y + 8, 10, 10))
        dot.setBrush(QBrush(QColor(_STATE_DOT[state])))
        dot.setPen(QPen(Qt.NoPen))
        scene.addItem(dot)
        name_font = _font(9.5, True)
        # V4.6: huy hiệu 💬n (tin chat chưa đọc) trên ô lưới: góc
        # phải-dưới, riêng ô needs_user (đã có ❗ ở đó) thì lên góc
        # phải-trên và tên agent rút ngắn thêm để nhường chỗ.
        chat_unread = int(desk.get("chat_unread") or 0)
        name_width = w - 74 - (30 if chat_unread and state == "needs_user" else 0)
        scene.addItem(_text(
            x + 48, y + 6,
            _elide(desk["name"], name_font, name_width), 9.5, True, _INK,
        ))
        tile_badge = self._issue_badges.get(agent_id)
        if tile_badge:
            scene.addItem(_text(
                x + w - 80, y + h - 22, f"⚠{tile_badge['count']}", 9, True,
                "#DC2626" if tile_badge["worst"] == "critical" else "#D97706",
            ))
        if chat_unread:
            badge_y = y + 6 if state == "needs_user" else y + h - 22
            scene.addItem(_text(
                x + w - 48, badge_y, f"💬{chat_unread}",
                9, True, "#1E9E4A",
            ))
        current = desk.get("current")
        if tier != TIER_WALL:
            if current:
                label = f"{current['type_label']} · {int(current.get('progress') or 0)}%"
                scene.addItem(_text(
                    x + 48, y + 26,
                    _elide(label, _font(8.5), w - 58), 8.5, False, _INK_SOFT,
                ))
                # Thanh % mảnh dưới tên việc.
                pct = max(0, min(100, int(current.get("progress") or 0)))
                bar_w = w - 58
                scene.addItem(_RoundRect(x + 48, y + 48, bar_w, 4, 2, theme.PROGRESS_TRACK))
                if pct > 0:
                    scene.addItem(_RoundRect(
                        x + 48, y + 48, max(4, bar_w * pct / 100.0), 4, 2, theme.ACCENT
                    ))
            else:
                scene.addItem(_text(x + 48, y + 26, desk["state_label"], 8.5, False, _INK_SOFT))
            footer = desk["state_label"]
            if desk.get("queue_count"):
                footer += f" · +{desk['queue_count']} chờ"
            scene.addItem(_text(x + 48, y + h - 20, footer, 8, False, _INK_SOFT))
        else:
            pct_text = (
                f"{int(current.get('progress') or 0)}%" if current else "—"
            )
            scene.addItem(_text(
                x + 48, y + 26,
                f"{desk['state_label']} · {pct_text}", 8.5, False, _INK_SOFT,
            ))
        if state == "needs_user":
            bang = _text(x + w - 30, y + h - 24, "❗", 13, True, "#EF4444")
            scene.addItem(bang)
            if animate:
                self._blink_items.append(bang)

    def _draw_manager_office(self, manager: dict):
        scene = self._scene
        x, y, w, h = 24, 24, 330, 190
        # V4.3.2: kính phòng + bảng trắng là VỎ TĨNH — scene sơn ở
        # drawBackground (cùng toạ độ), ở đây chỉ còn nội dung động.
        scene.addItem(_text(x + 14, y + 8, "PHÒNG ĐIỀU PHỐI", 10, True, "#8FC7F0"))
        # Bàn + robot quản lý
        group, robot = _robot_group("#6366F1", manager=True)
        group.setPos(x + 78, y + 148)
        scene.addItem(group)
        scene.addItem(_RoundRect(x + 18, y + 148, 130, 10, 3, "#C98B54"))
        scene.addItem(_RoundRect(x + 18, y + 158, 130, 26, 3, "#B57A45"))
        scene.addItem(_RoundRect(x + 86, y + 112, 52, 34, 3, "#334155"))
        scene.addItem(_RoundRect(x + 90, y + 116, 44, 26, 2, "#BAE6FD"))
        name = _text(x + 12, y + h - 24, "🧭 Điều phối viên", 9.5, True, "#E9EEF3",
                     width=150, align_center=True)
        scene.addItem(name)
        # Bảng trạng thái trong phòng quản lý (khung trắng do
        # drawBackground sơn tại 192,58,148,128 — toạ độ cũ giữ nguyên).
        scene.addItem(_text(x + 178, y + 40, "BẢNG ĐIỀU PHỐI", 8.5, True, "#8FC7F0"))
        lines = manager.get("lines") or []
        for row, line in enumerate(lines[:5]):
            scene.addItem(_text(x + 178, y + 62 + row * 20, line, 8.5, False, "#C9D4DE"))
        # Cây trang trí góc phòng
        scene.addItem(_RoundRect(x + w - 34, y + h - 34, 18, 14, 3, "#C08457"))
        for dx, dy in ((-6, -18), (6, -24), (16, -14)):
            leaf = QGraphicsEllipseItem(QRectF(x + w - 30 + dx, y + h - 30 + dy, 16, 16))
            leaf.setBrush(QBrush(QColor("#7FB069")))
            leaf.setPen(QPen(Qt.NoPen))
            scene.addItem(leaf)

    def _draw_decor_zone(self):
        """Khoảng giữa phía trên: biển tên văn phòng + sofa + cây —
        trang trí nhẹ đúng tinh thần diorama (góc nghỉ thu nhỏ)."""
        scene = self._scene
        x, y = 378, 24
        # V4.3.2: thẻ trắng dưới biển tên do drawBackground sơn.
        scene.addItem(_text(x + 16, y + 12, "🏢 VĂN PHÒNG CLAUDE", 13, True, "#EBCB9B"))
        scene.addItem(_text(
            x + 16, y + 44,
            "Mỗi bàn là một tài khoản Muse.\nBong bóng = việc đang làm + % tiến độ.",
            9, False, "#B7C3CE",
        ))
        # Sofa góc nghỉ dưới biển tên: lưng + đệm ngồi + hai tay vịn
        # + thảm dưới — vẽ thành một cụm rõ hình, không rời rạc.
        sx, sy = 396, 136
        rug = QGraphicsEllipseItem(QRectF(sx - 8, sy + 40, 150, 15))
        rug.setBrush(QBrush(QColor("#EBD9B4")))
        rug.setPen(QPen(Qt.NoPen))
        scene.addItem(rug)
        scene.addItem(_RoundRect(sx, sy, 122, 20, 8, "#A7C4A0"))
        scene.addItem(_RoundRect(sx, sy + 16, 122, 18, 8, "#8FB287"))
        scene.addItem(_RoundRect(sx - 2, sy + 8, 15, 28, 6, "#7CA374"))
        scene.addItem(_RoundRect(sx + 109, sy + 8, 15, 28, 6, "#7CA374"))
        scene.addItem(_text(sx + 140, sy + 12, "🛋 Góc nghỉ", 9, False, "#B7C3CE"))
        pot_x, pot_y = 648, 138
        scene.addItem(_RoundRect(pot_x, pot_y + 22, 22, 16, 3, "#C08457"))
        for dx, dy in ((-8, -6), (4, -14), (14, -4)):
            leaf = QGraphicsEllipseItem(QRectF(pot_x + dx, pot_y + dy, 18, 18))
            leaf.setBrush(QBrush(QColor("#7FB069")))
            leaf.setPen(QPen(Qt.NoPen))
            scene.addItem(leaf)

    def _draw_queue_board(self, model: dict):
        scene = self._scene
        x, y, w, h = 714, 24, 322, 190
        # V4.3.2: khung bảng do drawBackground sơn; thẻ chờ là item.
        total = model.get("queue_total", 0)
        scene.addItem(_text(x + 14, y + 8, f"📌 HÀNG ĐỢI CHỜ ({total})", 11, True, "#EBCB9B"))
        board = model.get("queue_board") or []
        if not board:
            scene.addItem(_text(x + 14, y + 52, "Không có lệnh nào đang chờ 🎉", 10, False, "#B7C3CE"))
            return
        card_y = y + 38
        for index, item in enumerate(board):
            color = _BOARD_CARD_COLORS[index % len(_BOARD_CARD_COLORS)]
            scene.addItem(_RoundRect(x + 12, card_y, w - 24, 25, 5, color, "#FFFFFF", 1))
            tag = "⏳" if item["status"] == "waiting_muse" else "•"
            label = f"{tag} {item['type_label']}"
            if item.get("profile_slug"):
                label += f" · {item['profile_slug']}"
            # V4.2 (O-11): thẻ hiện cả Muse phụ trách + đã chờ bao
            # lâu — bản cũ chỉ có loại lệnh + hồ sơ nên không biết
            # lệnh đang kẹt ở ai.
            if item.get("agent_name"):
                label += f" · 👤 {item['agent_name']}"
            if item.get("waiting_seconds") is not None:
                label += f" · chờ {_format_duration(item['waiting_seconds'])}"
            font = _font(8.5, True)
            scene.addItem(_text(
                x + 20, card_y + 4, _elide(label, font, w - 44), 8.5, True, _INK,
            ))
            card_y += 29
        if total > len(board):
            scene.addItem(_text(x + 14, card_y + 1, f"+{total - len(board)} lệnh nữa…", 9, True, "#EBCB9B"))

    def _draw_desk(self, index: int, desk: dict):
        scene = self._scene
        col, row = index % 4, index // 4
        slot_x = 24 + col * 259
        slot_y = 238 + row * 214
        cx = slot_x + 124
        desk_top = slot_y + 148

        if desk["agent_id"] == self._selected_agent_id:
            highlight = _RoundRect(slot_x + 2, slot_y - 4, 248, 208, 14, "#E0F2FE", theme.ACCENT, 2.2)
            highlight.setOpacity(0.65)
            scene.addItem(highlight)

        state = desk["state"]
        current = desk.get("current")
        grey = state == "offline"
        # V4.6: có CÂU HỎI needs_user đang chờ → bong bóng trích đoạn
        # câu hỏi được ƯU TIÊN hơn bong bóng việc thường (đó là thứ
        # người dùng cần trả lời); bấm bong bóng = chọn agent này.
        if desk.get("pending_question"):
            self._draw_question_bubble(slot_x, slot_y, cx, desk)
        elif current and state in _STATE_BUBBLE:
            self._draw_bubble(slot_x, slot_y, cx, desk, state, current)

        # V4.3 (G2): ghi hình học slot bàn cho hover/tìm kiếm.
        self._desk_bounds[int(desk["agent_id"])] = QRectF(
            slot_x + 2, slot_y - 4, 248, 208
        )
        group, robot = _robot_group(desk["color"], grey=grey)
        group.setPos(cx, desk_top)
        group.setData(0, desk["agent_id"])
        scene.addItem(group)
        if state == "working":
            self._bob_items.append((robot, 0.0))
        # Bàn + màn hình (đặt sau robot để robot "ngồi sau bàn")
        desk_group = QGraphicsItemGroup()
        desk_group.setData(0, desk["agent_id"])
        desk_group.addToGroup(_RoundRect(cx - 80, desk_top, 160, 10, 3, "#C98B54"))
        desk_group.addToGroup(_RoundRect(cx - 80, desk_top + 10, 160, 30, 3, "#B57A45"))
        desk_group.addToGroup(_RoundRect(cx + 12, desk_top - 36, 54, 36, 3, "#334155"))
        desk_group.addToGroup(_RoundRect(cx + 16, desk_top - 32, 46, 28, 2, "#475569" if grey else "#93C5FD"))
        desk_group.addToGroup(_RoundRect(cx - 58, desk_top - 8, 40, 6, 2, "#6B7280"))
        scene.addItem(desk_group)

        # Bảng tên + trạng thái dưới bàn
        plate_y = desk_top + 46
        scene.addItem(_RoundRect(cx - 74, plate_y, 148, 21, 9, "#FFFFFF", "#E3D5B8", 1))
        dot = QGraphicsEllipseItem(QRectF(cx - 66, plate_y + 6, 9, 9))
        dot.setBrush(QBrush(QColor(_STATE_DOT[state])))
        dot.setPen(QPen(Qt.NoPen))
        scene.addItem(dot)
        name_font = _font(9, True)
        scene.addItem(_text(
            cx - 52, plate_y + 3,
            _elide(desk["name"], name_font, 118), 9, True, _INK,
        ))
        label = desk["state_label"]
        if desk.get("queue_count"):
            label += f" · +{desk['queue_count']} lệnh chờ"
        scene.addItem(_text(cx - 90, plate_y + 24, label, 8.5, False, "#B7C3CE",
                            width=180, align_center=True))
        # V4.6: huy hiệu tin chat CHƯA ĐỌC — viên xanh lá ở góc phải
        # dưới bàn (cạnh bảng tên); bấm vào cũng là chọn agent.
        if desk.get("chat_unread"):
            self._draw_chat_badge(cx, plate_y, desk)
        self._draw_issue_badge(cx - 82, plate_y - 24, desk)

    def _draw_issue_badge(self, x, y, desk):
        """V6.1: huy hiệu ⚠ N sự cố (đỏ = nghiêm trọng, vàng = cần
        chú ý) — bấm là chọn agent; chi tiết ở khối Sự cố phía trên."""
        badge = self._issue_badges.get(int(desk["agent_id"]))
        if not badge:
            return
        color = {"critical": "#EF4444", "warning": "#F59E0B"}.get(badge["worst"], "#3B82F6")
        pill = _RoundRect(x, y, 66, 19, 9, color, None, 0)
        pill.setData(0, desk["agent_id"])
        self._scene.addItem(pill)
        text = _text(x, y + 2, f"⚠ {badge['count']} lỗi", 9, True, "#FFFFFF",
                     width=66, align_center=True)
        text.setData(0, desk["agent_id"])
        self._scene.addItem(text)

    def _draw_question_bubble(self, slot_x, slot_y, cx, desk):
        """Bong bóng CÂU HỎI needs_user trên đầu robot (V4.6): trích
        đoạn lý do/câu hỏi của lệnh đang chờ người dùng (cắt ~80 ký
        tự ở tầng dữ liệu) — bấm vào là chọn agent, panel chat bên
        phải đã mở đúng luồng để trả lời ngay."""
        scene = self._scene
        fill, border = _STATE_BUBBLE["needs_user"]
        bx, by, bw, bh = slot_x + 17, slot_y + 4, 214, 60
        tail = QGraphicsPolygonItem(QPolygonF([
            QPointF(cx - 8, by + bh), QPointF(cx + 8, by + bh),
            QPointF(cx, by + bh + 10),
        ]))
        tail.setBrush(QBrush(QColor(fill)))
        tail.setPen(QPen(QColor(border), 1.2))
        tail.setData(0, desk["agent_id"])
        scene.addItem(tail)
        box = _RoundRect(bx, by, bw, bh, 12, fill, border, 1.4)
        box.setData(0, desk["agent_id"])
        scene.addItem(box)
        scene.addItem(_text(
            bx + 10, by + 5, "⏸ Câu hỏi đang chờ bạn trả lời",
            9, True, _INK,
        ))
        excerpt = str(desk.get("pending_question") or "")
        # Bong bóng cao 60px chỉ chứa gọn 2 dòng ở cỡ 8.5 — cắt
        # trích đoạn theo ĐÚNG mét chữ cho 2 dòng (kèm "…") để
        # không tràn khỏi khung bong bóng.
        excerpt = _elide(excerpt, _font(8.5), (bw - 20) * 2)
        scene.addItem(_text(
            bx + 10, by + 24, excerpt, 8.5, False, _INK,
            width=bw - 20,
        ))
        bang = _text(bx + bw - 26, by - 14, "❗", 15, True, "#EF4444")
        scene.addItem(bang)
        self._blink_items.append(bang)

    def _draw_chat_badge(self, cx, plate_y, desk):
        """Huy hiệu 💬 + số tin chat chưa đọc ở góc phải dưới bàn."""
        scene = self._scene
        count = int(desk.get("chat_unread") or 0)
        pill = _RoundRect(
            cx + 34, plate_y - 24, 48, 19, 9, theme.ACCENT, None, 0,
        )
        pill.setData(0, desk["agent_id"])
        scene.addItem(pill)
        text = _text(
            cx + 34, plate_y - 22, f"💬 {count}", 9, True, "#0B0C0A",
            width=48, align_center=True,
        )
        text.setData(0, desk["agent_id"])
        scene.addItem(text)

    def _draw_bubble(self, slot_x, slot_y, cx, desk, state, current):
        scene = self._scene
        fill, border = _STATE_BUBBLE[state]
        bx, by, bw, bh = slot_x + 17, slot_y + 4, 214, 60
        tail = QGraphicsPolygonItem(QPolygonF([
            QPointF(cx - 8, by + bh), QPointF(cx + 8, by + bh), QPointF(cx, by + bh + 10),
        ]))
        tail.setBrush(QBrush(QColor(fill)))
        tail.setPen(QPen(QColor(border), 1.2))
        # V4.6: bong bóng mang id agent — bấm vào bong bóng cũng là
        # chọn agent đó (đường click đi bộ parent/data sẵn có).
        tail.setData(0, desk["agent_id"])
        scene.addItem(tail)
        box = _RoundRect(bx, by, bw, bh, 12, fill, border, 1.4)
        box.setData(0, desk["agent_id"])
        scene.addItem(box)
        title = current["type_label"]
        if current.get("instruction"):
            title += f" · {current['instruction']}"
        title_font = _font(9, True)
        scene.addItem(_text(bx + 10, by + 5, _elide(title, title_font, bw - 20), 9, True, _INK))
        if state == "needs_user":
            # V6.1: chờ người → hiện LÝ DO KẸT thay cho thanh 0% vô nghĩa.
            reason = (current.get("step") or "").strip() or "Muse chưa ghi lý do — bấm để mở chat hỏi Muse"
            scene.addItem(_text(
                bx + 10, by + 24, _elide("⏸ " + reason, _font(8.5), (bw - 20) * 2),
                8.5, False, "#991B1B", width=bw - 20,
            ))
            bang = _text(bx + bw - 26, by - 14, "❗", 15, True, "#EF4444")
            scene.addItem(bang)
            self._blink_items.append(bang)
            return
        # Thanh tiến độ + %
        bar_x, bar_y, bar_w = bx + 10, by + 36, 132
        scene.addItem(_RoundRect(bar_x, bar_y + 3, bar_w, 4, 2, theme.PROGRESS_TRACK))
        pct = max(0, min(100, int(current.get("progress") or 0)))
        if pct > 0:
            scene.addItem(_RoundRect(bar_x, bar_y + 3, max(4, bar_w * pct / 100.0), 4, 2, theme.ACCENT))
        scene.addItem(_text(bx + bar_w + 18, by + 30, f"{pct}%", 11, True, _INK))
        if state == "needs_user":
            bang = _text(bx + bw - 26, by - 14, "❗", 15, True, "#EF4444")
            scene.addItem(bang)
            self._blink_items.append(bang)

    # ------------------------------------------------------------------ #
    # Chọn agent + panel chi tiết
    # ------------------------------------------------------------------ #
    def _on_view_click(self, event):
        if event.button() == Qt.LeftButton:
            item = self._scene.itemAt(self.view.mapToScene(event.pos()), self.view.transform())
            while item is not None:
                agent_id = item.data(0)
                if agent_id is not None:
                    self.select_agent(int(agent_id))
                    break
                item = item.parentItem()
        QGraphicsView.mousePressEvent(self.view, event)

    # ------------------------------------------------------------------ #
    # V6.3: 2D / 3D + panel tự ẩn
    # ------------------------------------------------------------------ #
    def set_view_mode(self, mode: str, save: bool = True):
        self._view_mode = mode
        self.mode_buttons[mode].setChecked(True)
        self.view_stack.setCurrentIndex({"2d": 1, "3d": 2, "iso": 3}.get(mode, 0))
        if hasattr(self, "toolbar_host"):
            self.toolbar_host.setVisible(mode != "iso")
        for widget in (self.zoom_slider, self.fit_button, self.density_combo):
            widget.setEnabled(mode == "classic")
        if save:
            self._settings["office_view_mode"] = mode
            try:
                from .. import config as _config

                _config.save_settings(self._settings)
            except Exception:
                pass
        if mode in ("2d", "3d") and getattr(self, "_model", None) is not None:
            self._update_2d(getattr(self, "_last_unread", {}))

    def _update_2d(self, chat_unread):
        self._last_unread = chat_unread or {}
        if getattr(self, "_view_mode", "3d") not in ("2d", "3d") or self._model is None:
            return
        desks = list(self._model.get("desks") or [])
        ids = [d["current"]["id"] for d in desks if d.get("current")]
        try:
            steps = self._store.steps_for_commands([str(i) for i in ids], per_command=6)
        except Exception:
            steps = {}
        now = time.monotonic()
        if now - self._kpi_at > 60:
            self._kpi_at = now
            try:
                from .. import kpi as _kpi

                self._kpi_scores = {
                    int(d["agent_id"]): _kpi.agent_kpi(self._store, d["agent_id"], self._settings).get("score")
                    for d in desks
                }
            except Exception:
                self._kpi_scores = {}
        try:
            from .. import supervision as _sup

            lead = _sup.lead_agent_id(self._store, self._settings)
        except Exception:
            lead = None
        if self._view_mode == "3d":
            self.view3d.set_data(desks, self._last_unread, self._issue_badges, self._kpi_scores,
                                 lead, self._selected_agent_id)
            return
        self.view2d.set_data(desks, steps, self._kpi_scores, lead, self._last_unread, self._selected_agent_id)

    def _on_2d_click(self, agent_id):
        if agent_id is None:
            self._set_detail_visible(False)
            return
        self._set_detail_visible(True)
        self.select_agent(int(agent_id))
        self.view2d.set_selected(int(agent_id))
        self.view3d.set_selected(int(agent_id))
        self.view_iso.set_selected(int(agent_id))

    def _set_detail_visible(self, visible: bool, manual: bool = False):
        self.detail_panel.setVisible(bool(visible))
        self.panel_toggle.blockSignals(True)
        self.panel_toggle.setChecked(bool(visible))
        self.panel_toggle.setText("◂ Chi tiết" if visible else "▸ Chi tiết")
        self.panel_toggle.blockSignals(False)

    def select_agent(self, agent_id: int):
        """Chọn một agent (từ click bàn hoặc nơi gọi bên ngoài) — cập
        nhật panel chi tiết + vẽ lại điểm nhấn, phát tín hiệu chọn."""
        self._selected_agent_id = int(agent_id)
        for flat in ("view2d", "view3d", "view_iso"):
            if hasattr(self, flat):
                getattr(self, flat).set_selected(int(agent_id))
        self._rebuild_scene()
        self._update_detail()
        self.agent_selected.emit(int(agent_id))

    @property
    def selected_agent_id(self) -> int | None:
        return self._selected_agent_id

    def _set_state_pill(self, text: str, state: str):
        """Pill trạng thái ở header cố định: đổi chữ + state rồi
        polish lại (QLabel đổi property động không tự sơn lại)."""
        self.state_label.setText(text)
        self.state_label.setProperty("state", state)
        self.state_label.style().unpolish(self.state_label)
        self.state_label.style().polish(self.state_label)

    def _update_detail(self):
        desk = None
        if self._model:
            # V4.2 (O-25): tra trong desks_all (TOÀN BỘ agent) — bản
            # cũ chỉ tra 8 bàn đã vẽ nên agent thứ 9+ không có chi
            # tiết dù đã chọn được từ nơi khác.
            for candidate in self._model.get("desks_all") or self._model["desks"]:
                if candidate["agent_id"] == self._selected_agent_id:
                    desk = candidate
                    break
            if desk is None:
                desk = self._desk_from_agents()
        has = desk is not None
        self.detail_hint.setVisible(not has)
        self.detail_box.setVisible(has)
        if not has:
            # Header cố định về trạng thái trống (V5.1): avatar xám +
            # "Chưa chọn agent" + pill trung tính — không để sót dữ
            # liệu của agent vừa bỏ chọn trên header.
            self.avatar_label.setPixmap(
                theme.robot_avatar_pixmap(56, grey=True)
                or robot_head_pixmap(theme.FAINT, grey=True, size=56)
            )
            self.name_label.setText("Chưa chọn agent")
            self.agent_status_label.setText("")
            self._set_state_pill("—", "unknown")
            self._sync_chat_agent(None)
            return
        grey = desk["state"] == "offline"
        # V5.2: avatar robot ẢNH THẬT (assets) + vòng màu của agent
        # thay đầu robot vẽ tay; thiếu ảnh thì rơi về bản vẽ cũ.
        self.avatar_label.setPixmap(
            theme.robot_avatar_pixmap(
                56, ring=desk["color"], grey=grey
            )
            or robot_head_pixmap(desk["color"], grey=grey, size=56)
        )
        self.name_label.setText(desk["name"])
        self.agent_status_label.setText(
            f"{desk['agent_status_label']} · {desk['email']}" if desk["email"]
            else desk["agent_status_label"]
        )
        self._set_state_pill(
            desk["state_label"],
            _DESK_PILL_STATES.get(desk["state"], "unknown"),
        )
        labels = desk.get("profile_labels") or []
        # V4.2 (O-07): số kênh từ aggregate đã nạp ở refresh() — bản
        # cũ gọi list_channels từng hồ sơ trong try/except nuốt lỗi
        # thành "0 kênh", một hồ sơ lỗi là cả panel nói dối.
        channels = sum(
            self._channel_counts.get(pid, 0)
            for pid in desk.get("profile_ids") or []
        )
        self.profiles_label.setText(
            "Hồ sơ phụ trách: "
            + (", ".join(labels) if labels else "— chưa phân công —")
            + (f"\nKênh thuộc các hồ sơ: {channels}" if labels else "")
        )
        current = desk.get("current")
        if current:
            self.cur_title.setText(
                f"{_STATUS_ICON.get(current['status'], '')} {current['type_label']}"
                f" — {_STATUS_TEXT.get(current['status'], current['status'])}"
            )
            self.cur_instruction.setText(current.get("instruction") or "")
            pct = int(current.get("progress") or 0)
            # V5.1: thanh % THẬT (QProgressBar theo token §1.1) + số %
            # xanh bên phải, thay dải ký tự khối cũ.
            self.cur_bar.setValue(max(0, min(100, pct)))
            self.cur_progress.setText(f"{pct}%")
            self.cur_step.setText(
                f"Bước hiện tại: {current['step']}" if current.get("step") else ""
            )
            self.cur_lease.setText(self._lease_text())
        else:
            self.cur_title.setText("— không có lệnh nào —")
            self.cur_instruction.setText("")
            self.cur_bar.setValue(0)
            self.cur_progress.setText("")
            self.cur_step.setText("")
            self.cur_lease.setText("")
        # V4.2 (O-25): hàng đợi TIẾP THEO của agent — pool nhãn cố
        # định, ẩn nhãn thừa (cùng kỷ luật pool lệnh gần đây).
        waiting_next = desk.get("waiting_next") or []
        self.next_empty.setVisible(not waiting_next)
        for index, label in enumerate(self.next_labels):
            if index >= len(waiting_next):
                label.setVisible(False)
                continue
            nxt = waiting_next[index]
            waited = nxt.get("waiting_seconds")
            suffix = ""
            if waited is not None:
                suffix = f" · đã chờ {_format_duration(waited)}"
            label.setText(
                f"{index + 1}. {_STATUS_ICON.get(nxt['status'], '')} "
                f"{nxt['type_label']} — "
                f"{_STATUS_TEXT.get(nxt['status'], nxt['status'])}"
                + suffix
            )
            label.setVisible(True)
        # Lệnh gần đây: ghi vào pool nhãn cố định (ẩn nhãn thừa).
        recent = desk.get("recent") or []
        self.recent_empty.setVisible(not recent)
        for index, label in enumerate(self.recent_labels):
            if index >= len(recent):
                label.setVisible(False)
                continue
            command = recent[index]
            stamp = (command.get("finished_at") or command.get("created_at") or "")[11:16]
            label.setText(
                f"{_STATUS_ICON.get(command['status'], '')} {command['type_label']}"
                f" — {_STATUS_TEXT.get(command['status'], command['status'])}"
                + (f" · {stamp}" if stamp else "")
            )
            label.setVisible(True)
        # V5.1: dòng trạng thái luồng chat trong thân cuộn — số tin
        # Muse/hệ thống chưa đọc của agent này (khung chat ở đáy
        # panel mở ra là tự đánh dấu đã đọc, nhịp sau dòng này tự
        # về trạng thái yên).
        try:
            counts = self._store.unread_counts().get(desk["agent_id"], {})
        except Exception:
            counts = {}
        unread = int(counts.get("agent", 0)) + int(counts.get("system", 0))
        if unread:
            self.chat_status_label.setText(
                f"Có {unread} tin chưa đọc — khung chat ở ngay dưới "
                "đã tự mở; đọc xong nó sẽ tự thu gọn."
            )
        else:
            self.chat_status_label.setText(
                "Khung chat ở cuối panel — tự mở khi có tin mới "
                "hoặc câu hỏi chờ; bấm thanh “💬 Trò chuyện” để "
                "mở/thu bằng tay."
            )
        self._update_work_block(desk)
        # V4.6: khung chat trong panel luôn là luồng của agent này.
        self._sync_chat_agent(desk["agent_id"])
        # V5.2.1: nạp khoá câu hỏi needs_user đang chờ (nếu có) của
        # agent này vào khung chat thu/mở — câu hỏi mới làm chat tự
        # bung, câu hỏi được gỡ sau khi người dùng đã trả lời làm
        # chat tự thu (AgentChatWidget.set_pending_question).
        self.chat_widget.set_pending_question(
            self._pending_question_keys.get(desk["agent_id"])
        )

    # ------------------------------------------------------------------ #
    # V4.3 (G2) — Khối việc + dải nhánh mini từ work model dùng chung
    # ------------------------------------------------------------------ #
    # ------------------------------------------------------------------ #
    # V4.6 (10:46) — Chat NGAY trong panel chi tiết văn phòng
    # ------------------------------------------------------------------ #
    def _sync_chat_agent(self, agent_id):
        """Đồng bộ khung chat trong panel theo agent đang chọn —
        chỉ gọi set_agent khi agent THẬT SỰ đổi (set_agent tự làm
        mới luồng + đánh dấu đã đọc; gọi thừa sẽ nhấp nháy)."""
        target = int(agent_id) if agent_id is not None else None
        if self.chat_widget.agent_id == target:
            return
        agent = None
        if target is not None:
            for candidate in self._raw_agents:
                if candidate["id"] == target:
                    agent = candidate
                    break
        self.chat_widget.set_agent(agent)

    def _on_chat_store_changed(self):
        """Khung chat vừa ghi tin/đánh dấu đã đọc → làm mới văn
        phòng ở nhịp sự kiện KẾ (singleShot 0 cắt đệ quy đồng bộ
        refresh ↔ chat; huy hiệu 💬 trên bàn + ở mục Tài khoản đều
        đọc cùng Store nên tự khớp)."""
        QTimer.singleShot(0, self.refresh)

    def open_chat_for_command(self, agent_id, command_id=None):
        """Điểm đến của "💬 Hỏi về lệnh này" (V4.6 — 10:46): chọn
        đúng agent trong văn phòng và gắn chip ngữ cảnh lệnh vào
        khung chat TẠI ĐÂY — cuộc trò chuyện diễn ra ở Văn phòng,
        không nhảy sang mục Tài khoản."""
        self.select_agent(int(agent_id))
        if command_id:
            self.chat_widget.set_context_command(str(command_id))
        # V5.2.1: người dùng bấm "Hỏi về lệnh này" là có ý chat —
        # bung khung chat (tính như mở tay) để ô soạn tới được ngay,
        # kể cả khi nó đang thu gọn.
        self.chat_widget.expand_chat()
        self.chat_widget.composer.setFocus()

    def _on_work_button_clicked(self):
        command_id = self.sender().property("command_id") if self.sender() else None
        if command_id:
            self.open_command_requested.emit(str(command_id))

    def _agent_work_node(self, desk: dict) -> dict | None:
        """Node của agent đang chọn trong work model (cùng hàm dựng
        với mục Công việc — số liệu hai nơi không bao giờ lệch)."""
        from .work_panel import _iter_node_commands  # noqa: F401 — dùng ở dưới

        channels_by_profile = {p["id"]: [] for p in self._raw_profiles}
        for pid in desk.get("profile_ids") or []:
            try:
                channels_by_profile[pid] = self._store.list_channels(pid)
            except Exception:
                channels_by_profile[pid] = []
        model = work_model.build_work_model(
            self._raw_commands,
            self._raw_agents,
            self._raw_profiles,
            channels_by_profile,
        )
        for node in model.get("agents") or []:
            agent = node.get("agent") or {}
            if agent.get("id") == desk.get("agent_id"):
                return node
        return None

    def _update_work_block(self, desk: dict):
        from .work_panel import _iter_node_commands, bar_text

        node = None
        try:
            node = self._agent_work_node(desk)
        except Exception:
            node = None
        rows: list[tuple[dict, str]] = []
        if node is not None:
            active = {"running", "queued", "waiting_muse", "needs_user", "interrupted"}
            rows = [
                (c, ctx) for c, ctx in _iter_node_commands(node)
                if c.get("status") in active
            ]
        self.work_empty.setVisible(not rows)
        for index, button in enumerate(self.work_buttons):
            if index >= len(rows):
                button.setVisible(False)
                continue
            command, context = rows[index]
            label = COMMAND_TYPE_LABELS.get(
                command.get("type"), command.get("type") or ""
            )
            status = _STATUS_TEXT.get(command.get("status"), command.get("status") or "")
            # V5.1 fix: chữ nút dài (tên loại việc + trạng thái +
            # thanh %) ép min-width của host vùng cuộn vượt
            # viewport panel → cắt chữ toàn panel. Cắt gọn bằng
            # elide theo font của nút ở bề rộng nút thật (~250px);
            # nội dung đầy đủ vẫn ở tooltip + bấm để mở bảng việc.
            metrics = button.fontMetrics()
            first_line = metrics.elidedText(
                f"{label} — {status} · "
                f"{bar_text(work_model.command_percent(command), 6)}",
                Qt.TextElideMode.ElideRight,
                248,
            )
            button.setText(
                first_line
                + (
                    f"\n{metrics.elidedText(context, Qt.TextElideMode.ElideRight, 248)}"
                    if context
                    else ""
                )
            )
            button.setToolTip((command.get("instruction") or "")[:300])
            button.setProperty("command_id", command.get("id"))
            button.setVisible(True)
        # Dải nhánh mini: Agent → Hồ sơ → Kênh → Lệnh hiện tại.
        agent_pct = node.get("percent") if node else None
        self.branch_labels[0].setText(
            f"🤖 {desk.get('name') or 'Agent'}"
            + (f" · {agent_pct}%" if agent_pct is not None else "")
        )
        current_raw = None
        current_view = desk.get("current") or {}
        for candidate in self._raw_commands:
            if candidate.get("id") == current_view.get("id"):
                current_raw = candidate
                break
        profile_node = channel_node = None
        if node is not None and current_raw is not None:
            for candidate in node.get("profiles") or []:
                profile = candidate.get("profile") or {}
                if profile.get("id") == current_raw.get("profile_id"):
                    profile_node = candidate
                    for ch in candidate.get("channels") or []:
                        channel = ch.get("channel") or {}
                        if channel.get("channel_id") == current_raw.get("channel_id"):
                            channel_node = ch
                            break
                    break
        if profile_node is not None:
            profile = profile_node.get("profile") or {}
            pct = profile_node.get("percent")
            self.branch_labels[1].setText(
                f"👤 {profile.get('label') or profile.get('slug') or 'Hồ sơ'}"
                + (f" · {pct}%" if pct is not None else "")
            )
        else:
            self.branch_labels[1].setText("👤 —")
        if channel_node is not None:
            channel = channel_node.get("channel") or {}
            pct = channel_node.get("percent")
            self.branch_labels[2].setText(
                f"📺 {channel.get('name') or channel.get('channel_id')}"
                + (f" · {pct}%" if pct is not None else "")
            )
        else:
            self.branch_labels[2].setText("📺 —")
        if current_raw is not None:
            label = COMMAND_TYPE_LABELS.get(
                current_raw.get("type"), current_raw.get("type") or ""
            )
            self.branch_labels[3].setText(
                f"• {label} · {work_model.command_percent(current_raw)}%"
            )
        else:
            self.branch_labels[3].setText("• —")

    def _desk_from_agents(self) -> dict | None:
        if self._selected_agent_id is None or not self._model:
            return None
        agents = self._store.list_agents()
        commands = self._store.list_commands(limit=200)
        profiles = self._store.list_profiles()
        model = office_scene.build_office_scene(agents, commands, {}, profiles)
        for desk in model.get("desks_all") or model["desks"]:
            if desk["agent_id"] == self._selected_agent_id:
                return desk
        return None
