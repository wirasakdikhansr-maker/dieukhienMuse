"""Khung CHAT hai chiều với một tài khoản Muse (V4.6).

Người dùng trò chuyện trực tiếp với TỪNG Muse ngay trong mục Tài
khoản Muse — không qua khung chat ngoài. Tin lưu ở bảng
``agent_messages`` (Store); phía Muse đọc/trả lời qua Agent API
2.6 (docs/AGENT_CHAT.md), cầu nối đánh thức Muse khi có tin user
chưa đọc. Lệnh kẹt 'needs_user' tự để lại một tin hệ thống trong
đúng luồng này (Store.set_command_needs_user) — người dùng trả lời
tại đây để Muse chạy tiếp.

Kỷ luật làm mới: timer CHỈ chạy khi widget đang hiện (show/hide),
dựng lại luồng theo VÂN dữ liệu (không đổi → không vẽ lại), và GIỮ
vị trí cuộn khi người dùng đang đọc lịch sử (chỉ tự cuộn xuống đáy
khi vốn đang ở gần đáy).

V5.2.1 — CHẾ ĐỘ THU/MỞ (chỉ bản ở panel chi tiết VĂN PHÒNG bật,
qua tham số ``collapsible=True``; bản ở mục Tài khoản giữ nguyên
hành vi luôn mở): khung chat từng chiếm hơn nửa chiều cao panel
chi tiết và bóp chết khối "Việc hiện tại" (góp ý máy thật 30/10).
Ở chế độ này: thanh tiêu đề luôn hiện (tiêu đề + huy hiệu chưa
đọc + nút thu/mở), thân chat MẶC ĐỊNH THU GỌN khi không có gì chờ,
TỰ BUNG khi có tin chưa đọc/câu hỏi needs_user đang chờ/người dùng
mở tay, TỰ THU khi đã đọc/gửi xong và hết chờ (trừ khi người dùng
đang mở tay). Khi thu gọn, nhịp làm mới CHỈ đọc vân rẻ — không nạp
tin, không dựng bong bóng, không đánh dấu đã đọc. Khi bung, luồng
tin bị chặn chiều cao (120–200px, cuộn trong) để không trạng thái
nào của chat đẩy được nội dung công việc khỏi panel.

V5.3.2 — TRÌNH BÀY PHẲNG theo PHƯƠNG ÁN 1 chủ kênh duyệt
(2026-10-30 21:02; ảnh duyệt `ui_chat_redesign_preview/
chat_redesign_v1.png`, nửa trên): BỎ HẲN bong bóng tin — mỗi tin
là HÀNG CHỮ TRẦN trên nền panel (không khung/viền/nền riêng/bo
góc), phân biệt hai phía bằng căn lề + màu tên: tin Muse căn
trái (avatar tròn 28px + tên đậm sáng + giờ mờ cùng hàng, thân
tin thụt thẳng hàng dưới tên), tin người dùng căn phải (giờ mờ +
"Bạn" đậm accent, không avatar), tin hệ thống là chữ căn giữa
màu cảnh báo. Đầu ô chat một hàng mảnh + trạng thái đọc dạng chữ
mờ; ô nhập nằm trên DẢI nền tối hơn panel một bậc, không viền,
nút Gửi viên accent đặc. Ở panel Văn phòng khung chat KHÔNG còn
khung Panel riêng và không lề ngoài — nội dung tràn hết bề ngang
panel chứa, hàng chữ giữ đệm trong 16px. Toàn bộ HÀNH VI (thu/mở,
cổng vân, đã đọc, needs_user, Enter gửi) giữ nguyên — chỉ thay
lớp trình bày.

V5.3.3 — Ô NHẬP theo ảnh duyệt `chat_redesign_v3.png` (duyệt
2026-10-30 22:56) + DIỆT VIỀN TRẮNG MỜ: dải ô nhập cao CỐ ĐỊNH
~88px (theme.chat_composer_height), một hàng duy nhất — ô soạn
chiếm hết chiều cao dải, chữ căn giữa theo chiều cao khi ngắn
(viewport margin trong _ComposerEdit), tràn thì cuộn trong ô;
nút Gửi neo góc phải-dưới; placeholder rút còn "Nhắn cho
Muse…", gợi ý phím vào tooltip. Ba nguồn viền thật trên đường
chat bị diệt ở gốc: khung StyledPanel chìm native của
QPlainTextEdit (→ NoFrame ở mức C++), hộp "ghost" quanh nút
thu/mở và nút ✕ chip (→ style phẳng scope theo objectName),
viền + nền tint của huy hiệu chưa đọc (→ chữ đậm phẳng). Kèm
theo: phép khôi phục chiều cao luồng kéo tay chuyển sang đo
phần cố định bằng sizeHint (fixed_chrome_height) — sửa lệch
28px lộ ở full-suite V5.3.2 (xem §21 ccd_dev_lessons).
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QCoreApplication, QEvent, QSize, Qt, QTimer, Signal
from PySide6.QtGui import QFontMetrics, QTextLayout
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QScrollArea,
    QVBoxLayout,
    QWidget,
)

from ..store import Store
from . import theme

# V5.3.2: các hằng màu bong bóng (_USER_BUBBLE / _AGENT_BUBBLE /
# _SYSTEM_BUBBLE) và _BUBBLE_MAX_WIDTH đã XOÁ — Phương án 1 duyệt
# bỏ hẳn bong bóng, tin là hàng chữ trần trên nền panel (xem
# _message_row). Hình học của hàng tin đặt tên tại đây:
_MESSAGE_AVATAR_SIZE = 28
#: Thụt đầu dòng của thân tin Muse = avatar 28 + khoảng cách 7 —
#: thân tin thẳng hàng với tên phía trên (đúng ảnh duyệt).
_MESSAGE_BODY_INDENT = _MESSAGE_AVATAR_SIZE + 7
#: Trần bề rộng thân tin ở bề mặt RỘNG (tab Tài khoản): quá dài
#: thì xuống dòng thay vì chạy hết bề ngang cửa sổ; panel hẹp
#: (Văn phòng) luôn bị bề ngang thật chặn trước trần này.
_MESSAGE_BODY_MAX_WIDTH = 640
#: Đệm ngang TRONG của mọi hàng chữ trong khung chat (đầu ô chat,
#: luồng tin, dải ô nhập) — đệm chữ, không phải khe khung: khung
#: chat ở Văn phòng không còn lề ngoài nào khác (V5.3.2, mục 6).
_CHAT_SIDE_PADDING = 16

# V5.2.1: chiều cao khung luồng tin khi BUNG ở chế độ thu/mở (panel
# chi tiết Văn phòng) — đủ đọc vài tin gần nhất + cuộn trong để xem
# tiếp, và đủ thấp để khối việc phía trên luôn còn chỗ. Hằng số đặt
# tên ở một chỗ theo luật code chuyên nghiệp.
# V5.3.1 (M3a): bong bóng phẳng không viền. V5.3.2: bong bóng bị
# BỎ HẲN theo Phương án 1 đã duyệt — xem khối hằng phía trên.
# V5.3.1 (M3b): trần mặc định 200 → 160 theo lệnh chủ kênh; người
# dùng vẫn kéo tay cao hơn qua splitter dọc (M3e) — khoảng kéo
# 100–420 dưới đây, và chiều cao đã kéo THẮNG hằng trần này.
OFFICE_THREAD_MIN_HEIGHT = 200
OFFICE_THREAD_MAX_HEIGHT = 420  # V6.5: chat Văn phòng rộng rãi hơn (bản cũ 160px)
OFFICE_THREAD_USER_MIN_HEIGHT = 100
OFFICE_THREAD_USER_MAX_HEIGHT = 420


class _MessageBodyLabel(QLabel):
    """Nhãn thân tin trong hàng tin chat (V5.3.2 đổi tên từ
    _BubbleBodyLabel — bong bóng đã bỏ hẳn; cơ chế giữ nguyên).

    V5.3.1 (phát hiện khi kiểm chứng M3a bằng render): sizeHint
    của QLabel bật wordWrap KHÔNG theo độ dài câu — Qt trả một
    bề rộng hẹp cố định (~122px) nên khung chứa không bao giờ nở
    theo nội dung: tin dài bị bóp vào khung hẹp, dồn nhiều dòng
    và phần đầu tin trôi khỏi vùng nhìn của khung chat đã chặn
    chiều cao (chỉ còn thấy đuôi câu). Lỗi CÓ SẴN từ các bản
    trước, tin ngắn không lộ. Ghi đè bề rộng gợi ý = bề rộng
    dòng chữ dài nhất theo fontMetrics, chặn trần ở bề rộng
    thân tin tối đa — chiều cao vẫn do heightForWidth của QLabel
    tính theo bề rộng thật được cấp."""

    def sizeHint(self):
        hint = super().sizeHint()
        metrics = self.fontMetrics()
        longest = max(
            (metrics.horizontalAdvance(line)
             for line in self.text().splitlines() or [""]),
            default=0,
        )
        width = min(longest + 2, _MESSAGE_BODY_MAX_WIDTH)
        return QSize(max(hint.width(), int(width)), hint.height())


class _ComposerEdit(QPlainTextEdit):
    """Ô soạn tin: Enter = gửi, Shift+Enter = xuống dòng.

    V5.3.3 (V1 — ảnh duyệt chat_redesign_v3): ô nhập cao CỐ ĐỊNH
    (dải chứa ghim bằng theme.chat_composer_height) và CHỮ CĂN
    GIỮA THEO CHIỀU CAO khi nội dung còn ngắn: lề trên của
    viewport được đặt = nửa phần cao thừa; nội dung vượt ô thì
    lề về 0, chữ chạy từ trên xuống và thanh cuộn dọc tự hiện
    (ScrollBarAsNeeded). Căn giữa làm bằng viewport margin trên
    CHÍNH ô nhập thật — gõ/xoá/dán/cuộn/con trỏ đều là đường
    gốc của QPlainTextEdit, không widget giả chồng lên.

    V5.3.3 (V2): QPlainTextEdit mặc định mang khung StyledPanel
    CHÌM (frameShape=6, shadow=Sunken) — widget DUY NHẤT trên
    đường chat còn khung native; trên Windows đường sơn native
    vẽ viền sáng-chìm quanh ô nhập ("viền trắng mờ" chủ kênh
    chụp ở V5.3.2). Tắt khung ở mức C++ (setFrameShape NoFrame)
    để không đường sơn nào vẽ lại được, QSS chỉ còn lo màu."""

    send_requested = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.NoFrame)
        self._centering_guard = False
        self.textChanged.connect(self._recenter_vertically)

    def _document_height(self) -> float:
        """Chiều cao nội dung (px) — con số duy nhất phép căn
        giữa cần. Đo BẰNG QTextLayout trên từng block với đúng
        font + bề rộng dòng hiệu lực của ô, KHÔNG dùng
        document().size(): layout văn bản thuần của
        QPlainTextEdit bố cục LƯỜI — probe V5.3.3 cho thấy
        size().height() của 6 dòng trả 6.0 (không phải pixel)
        và blockBoundingRect của block chưa tới lượt bố cục
        trả y=0; cả hai đều làm phép căn giữa tính sai. Ô soạn
        chỉ có một font, văn bản thuần — đo phân tích thế này
        khớp pixel với layout thật."""
        doc = self.document()
        # Bề rộng dòng hiệu lực = bề rộng viewport (layout văn
        # bản thuần trải block hết bề ngang viewport, lề tài
        # liệu không chừa riêng — đối chứng blockBoundingRect
        # của block đầu: x=0, rộng = viewport). Chiều cao cũng
        # KHÔNG cộng lề tài liệu: block đầu bắt đầu ở y=0 và
        # cao đúng lineSpacing (probe V5.3.3) — cộng lề vào là
        # margin căn giữa lệch đúng phần lề đó.
        available = max(1.0, float(self.viewport().width()))
        line_height = QFontMetrics(self.font()).lineSpacing()
        total = 0.0
        block = doc.firstBlock()
        while block.isValid():
            layout = QTextLayout(block.text(), self.font())
            layout.beginLayout()
            lines = 0
            while True:
                line = layout.createLine()
                if not line.isValid():
                    break
                line.setLineWidth(available)
                lines += 1
            layout.endLayout()
            total += max(1, lines) * line_height
            block = block.next()
        return float(total)

    def _recenter_vertically(self):
        """Đặt lề trên viewport = nửa phần cao thừa khi nội dung
        NGẮN hơn ô; nội dung dài hơn ô → lề 0 (cuộn chuẩn).
        Công thức tính theo chiều cao TOÀN Ô (viewport + lề
        hiện tại) nên gọi lại sau khi đặt lề cho cùng một kết
        quả — không dao động."""
        if self._centering_guard:
            return
        margins = self.viewportMargins()
        full_height = self.viewport().height() + margins.top() \
            + margins.bottom()
        if full_height <= 0:
            return
        doc_height = self._document_height()
        if doc_height >= full_height:
            target = 0
        else:
            target = int((full_height - doc_height) // 2)
        if margins.top() != target:
            self._centering_guard = True
            try:
                self.setViewportMargins(0, target, 0, 0)
            finally:
                self._centering_guard = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._recenter_vertically()

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            if event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                super().keyPressEvent(event)
            else:
                self.send_requested.emit()
            return
        super().keyPressEvent(event)


def _fmt_time(value) -> str:
    if not value:
        return ""
    try:
        moment = datetime.fromisoformat(str(value))
    except ValueError:
        return ""
    return moment.strftime("%H:%M %d/%m")


def _fmt_time_short(value) -> str:
    """Mốc thời gian NGẮN cho hàng tên + trạng thái đọc (V5.3.2,
    đúng ảnh duyệt "19:24"): tin HÔM NAY chỉ hiện giờ; tin ngày
    khác giữ cả ngày để khỏi nhầm lịch sử cũ là tin vừa tới."""
    if not value:
        return ""
    try:
        moment = datetime.fromisoformat(str(value))
    except ValueError:
        return ""
    if moment.date() == datetime.now().date():
        return moment.strftime("%H:%M")
    return moment.strftime("%H:%M %d/%m")


class AgentChatWidget(QFrame):
    """Luồng chat của MỘT agent đang chọn + ô soạn + chip ngữ cảnh lệnh."""

    # V6.3: MainWindow gắn hàm (agent, text) để đẩy tin vào muse.ai.
    user_message_hook = None
    # V6.4.3: các khung chat đang sống — cầu nối muse.ai "chọc" để vẽ
    # lại NGAY khi câu trả lời chảy chữ (không chờ nhịp 5 giây).
    _live = None

    @classmethod
    def poke(cls, agent_id: int, hint: str | None = None) -> None:
        for widget in list(cls._live or ()):
            try:
                agent = widget._agent
                if agent is None or int(agent["id"]) != int(agent_id):
                    continue
                if hint is not None:
                    widget._set_hint(hint)
                if widget.isVisible():
                    widget._fingerprint = None
                    widget.refresh()
            except Exception:
                continue

    # V5.3.1 (M3e): báo trạng thái bung/thu đổi — panel Văn phòng
    # nghe để khôi phục/nhớ chiều cao luồng do người dùng kéo tay
    # qua splitter dọc. Chỉ phát ở chế độ collapsible.
    expand_changed = Signal(bool)

    def __init__(self, store: Store, wake_bridge=None,
                 on_store_changed=None, parent=None, empty_hint=None,
                 collapsible: bool = False):
        super().__init__(parent)
        # V5.3.2 (mục 6 — sát viền): bản Văn phòng (collapsible)
        # KHÔNG mang khung "Panel" (viền + bo góc + nền riêng) —
        # nó nằm LIỀN trong panel chi tiết, nội dung tràn hết bề
        # ngang ô chứa; nền panel phía dưới (cùng màu PANEL) là
        # nền chung. Bản Tài khoản vẫn là thẻ Panel độc lập.
        self.setObjectName("ChatEmbed" if collapsible else "Panel")
        self._store = store
        # V5.2.1: chế độ thu/mở CHỈ dành cho bản nhúng trong panel
        # chi tiết Văn phòng. Mặc định False = hành vi cũ nguyên vẹn
        # (mục Tài khoản Muse dùng bản này).
        self._collapsible = bool(collapsible)
        # --- Trạng thái thu/mở (chỉ có nghĩa khi _collapsible) ---
        # Đang bung hay đang thu; bản không thu/mở luôn coi là bung.
        self._expanded = not self._collapsible
        # Lựa chọn TAY của người dùng trong lượt xem agent hiện tại:
        # None = tự động, "open" = người dùng bấm mở (không tự thu),
        # "closed" = người dùng bấm thu (chỉ bung lại khi có tin/câu
        # hỏi MỚI hơn mốc đã ghi). Đổi agent là xoá lựa chọn tay.
        self._manual: str | None = None
        self._manual_max_id = 0
        self._manual_pending_key: str | None = None
        # V5.3.1 (M3e): chiều cao luồng tin do NGƯỜI DÙNG kéo tay
        # (qua splitter dọc của panel Văn phòng) — None = chưa
        # kéo, dùng dải mặc định MIN..MAX; có giá trị thì ghim
        # đúng giá trị đó (đã kẹp 100–420) và thắng trần mặc định.
        self._user_thread_height: int | None = None
        # Câu hỏi needs_user đang chờ của agent hiện tại (Văn phòng
        # nạp vào qua set_pending_question — khoá = id lệnh).
        self._pending_key: str | None = None
        # Người dùng đã GỬI trả lời cho câu hỏi này — khi câu hỏi
        # được gỡ (Muse chạy tiếp) thì đó là chuyển có → không SAU
        # hành động gửi, đủ điều kiện tự thu.
        self._sent_for_pending_key: str | None = None
        # Đọc hết ở nhịp này → hẹn thu ở nhịp KẾ (chống giật: tin
        # vừa bung phải ở lại ít nhất một nhịp để người dùng đọc).
        self._collapse_armed = False
        # Lời nhắc khi chưa chọn agent — mỗi bề mặt chứa (Tài khoản /
        # Văn phòng) diễn đạt theo bố cục của mình.
        self._empty_hint = empty_hint or (
            "Chọn một tài khoản Muse ở danh sách bên trái để bắt "
            "đầu trò chuyện."
        )
        # wake_bridge: MainWindow nối tới AgentServer.notify_messages_changed
        # (đánh thức long-poll của cầu nối ngay khi người dùng gửi tin).
        self._wake_bridge = wake_bridge or (lambda: None)
        # on_store_changed: nơi chứa (AgentsPanel) làm mới huy hiệu
        # chưa đọc sau khi luồng này ghi/đọc tin.
        self._on_store_changed = on_store_changed or (lambda: None)
        self._agent: dict | None = None
        self._context_command_id: str | None = None
        # V5.3.2: mốc thời gian của tin MỚI NHẤT đã dựng — nuôi
        # dòng trạng thái đọc ở đầu ô chat ("đã đọc · 19:24").
        self._last_message_at = None
        self._fingerprint = None
        # V5.2 (hiệu năng §15): vân RẺ của luồng (số tin / id cuối /
        # số tin đến chưa đọc) — nhịp 5s chỉ nạp 200 tin + dựng lại
        # bong bóng khi vân này đổi; trước V5.2 mỗi nhịp vẫn SELECT *
        # 200 tin rồi mới so vân đầy đủ.
        self._sig = None
        self._pill_state: tuple | None = None
        self._build_ui()
        import weakref
        if AgentChatWidget._live is None:
            AgentChatWidget._live = weakref.WeakSet()
        AgentChatWidget._live.add(self)
        self._timer = QTimer(self)
        # V5.1 (plan §2.1): panel đang mở thì luồng tự làm mới mỗi 5
        # giây — câu trả lời của Muse hiện ra mà người dùng không
        # phải bấm đi đâu (cộng với refresh theo vân khi có sự kiện).
        self._timer.setInterval(5000)
        self._timer.timeout.connect(self._on_timer_tick)

    def _on_timer_tick(self):
        """Nhịp tự làm mới 5s: panel ẨN thì KHÔNG làm gì (phòng thủ
        hai lớp cùng show/hideEvent — timer của panel ẩn không được
        chạy refresh, bài học §8/§15)."""
        if not self.isVisible():
            return
        self.refresh()

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        if not self._timer.isActive():
            self._timer.start()
        self.refresh()
        # V6.5: mở khung chat là thấy tin MỚI NHẤT.
        self._stick_bottom = True
        QTimer.singleShot(0, self._scroll_to_bottom)

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        # V5.3.2: bố cục KHÔNG lề ngoài — mỗi khối tự giữ đệm
        # ngang _CHAT_SIDE_PADDING (16px) cho hàng chữ của mình:
        # khung chat (nhất là bản Văn phòng) tràn hết bề ngang ô
        # chứa, không còn hai tầng lề 18px + 16px chồng nhau.
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        self.agent_pill = theme.pill("chưa chọn", "unknown")
        self.unread_badge: QLabel | None = None
        self.expand_button: QPushButton | None = None
        # V5.3.2 (mục 4): trạng thái ĐỌC dạng chữ thường mờ ở đầu
        # ô chat ("đã đọc · 19:24") — không chip, không khung.
        self.read_status_label = QLabel("")
        self.read_status_label.setObjectName("Muted12")
        if self._collapsible:
            # V5.2.1: THANH TIÊU ĐỀ luôn hiện của chế độ thu/mở —
            # tiêu đề + huy hiệu chưa đọc/đang chờ + pill trạng thái
            # + nút thu/mở. Bấm vào thanh (trừ trên nút — nút tự xử
            # lý cú bấm của nó) cũng là thu/mở tay. Khi thu gọn, đây
            # là phần DUY NHẤT của khung chat còn chiếm chiều cao.
            strip = QWidget()
            strip_row = QHBoxLayout(strip)
            strip_row.setContentsMargins(
                _CHAT_SIDE_PADDING, 10, _CHAT_SIDE_PADDING, 2
            )
            strip_row.setSpacing(8)
            strip_row.addWidget(theme.section_header("💬 Trò chuyện"))
            self.unread_badge = QLabel("")
            # V5.3.3 (V2): huy hiệu PHẲNG — chữ đậm màu cảnh báo,
            # KHÔNG nền tint, KHÔNG viền. Bản cũ mang border hổ
            # phách + nền rgba = một "hộp" nữa ở đầu ô chat, trái
            # thiết kế phẳng đã duyệt (ảnh v3: đầu ô chat chỉ có
            # chữ trần + hai nút phẳng). Nghĩa đầy đủ vẫn ở
            # tooltip như chuẩn §17.
            self.unread_badge.setStyleSheet(
                f"color:{theme.WARNING}; font-weight:700;"
                " padding:1px 2px;"
            )
            self.unread_badge.setVisible(False)
            strip_row.addWidget(self.unread_badge)
            strip_row.addStretch(1)
            strip_row.addWidget(self.read_status_label)
            strip_row.addWidget(self.agent_pill)
            # Panel chi tiết đã có pill trạng thái ở header cố định
            # ngay phía trên — pill của khung chat KHÔNG chiếm chỗ
            # trên thanh này: render nghiệm thu V5.2.1 cho thấy
            # tiêu đề + huy hiệu + pill + nút chữ dài cùng chen
            # 244px khiến chữ bị CẮT ở cả ba (đúng lỗi luật cấm).
            self.agent_pill.setVisible(False)
            # Nút thu/mở chỉ là MŨI TÊN (đúng quy cách "nút/mũi tên
            # thu-mở") + tooltip nói rõ hành động — nút chữ dài
            # "▸ Mở chat"/"▾ Thu gọn" bị cắt cụt trong panel 320px.
            # V5.3.3 (V2): nút PHẲNG KHÔNG HỘP — bản cũ dùng
            # variant "ghost" của QSS toàn cục (viền 1px BORDER +
            # bo 12px) nên đầu ô chat có một ô vuông viền mờ quanh
            # mũi tên (quét pixel render V5.3.2 xác nhận cạnh nút
            # sơn đúng màu viền); ảnh duyệt v3 yêu cầu hai nút đầu
            # ô chat phẳng. Style scope theo objectName (§14).
            self.expand_button = QPushButton("▸")
            self.expand_button.setObjectName("ChatExpandButton")
            self.expand_button.setStyleSheet(
                "QPushButton#ChatExpandButton {"
                " background: transparent; border: none;"
                f" color:{theme.MUTED}; padding: 2px 6px;"
                " }"
                "QPushButton#ChatExpandButton:hover {"
                f" color:{theme.TEXT};"
                " }"
            )
            self.expand_button.setToolTip("Mở khung chat")
            self.expand_button.clicked.connect(self.toggle_expand)
            strip_row.addWidget(self.expand_button)
            strip.mousePressEvent = self._on_strip_pressed
            strip.setCursor(Qt.PointingHandCursor)
            strip.setToolTip(
                "Bấm để thu/mở khung chat — chat cũng tự mở khi có "
                "tin mới hoặc câu hỏi đang chờ bạn trả lời."
            )
            root.addWidget(strip)
        else:
            # V5.3.2 (mục 4): đầu ô chat ở tab Tài khoản cùng một
            # hàng mảnh như Văn phòng — tiêu đề + trạng thái đọc
            # mờ + pill trạng thái agent; không viền, không hộp.
            header_host = QWidget()
            header = QHBoxLayout(header_host)
            header.setContentsMargins(
                _CHAT_SIDE_PADDING, 14, _CHAT_SIDE_PADDING, 2
            )
            header.setSpacing(8)
            header.addWidget(theme.section_header("💬 Trò chuyện"))
            header.addStretch(1)
            header.addWidget(self.read_status_label)
            header.addWidget(self.agent_pill)
            root.addWidget(header_host)

        # V5.2.1: THÂN chat (hàng tên/avatar, chip ngữ cảnh, luồng
        # tin, ô soạn, dòng gợi ý) gom vào MỘT widget chứa — chế độ
        # thu/mở ẩn/hiện cả khối bằng một setVisible; bản không
        # thu/mở thì thân luôn hiện và bố cục y như trước.
        self.body_widget = QWidget()
        body_layout = QVBoxLayout(self.body_widget)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)

        # V5.2: avatar robot THẬT ở đầu khối chat (vòng màu theo
        # agent) — cùng ngôn ngữ với panel chi tiết Văn phòng.
        name_host = QWidget()
        name_row = QHBoxLayout(name_host)
        name_row.setContentsMargins(
            _CHAT_SIDE_PADDING, 6, _CHAT_SIDE_PADDING, 0
        )
        name_row.setSpacing(10)
        self.avatar_label = QLabel()
        self.avatar_label.setFixedSize(34, 34)
        name_row.addWidget(self.avatar_label)
        self._name_holder = QWidget()
        name_row.addWidget(self._name_holder, 1)
        body_layout.addWidget(name_host)
        self._name_host = name_host

        self.agent_name_label = QLabel(self._empty_hint)
        self.agent_name_label.setObjectName("CardTitle")
        self.agent_name_label.setWordWrap(True)
        name_layout = QVBoxLayout(self._name_holder)
        name_layout.setContentsMargins(0, 0, 0, 0)
        name_layout.addWidget(self.agent_name_label)
        name_layout.addStretch(1)
        if self._collapsible:
            # Panel chi tiết Văn phòng đã có header cố định (avatar
            # 56px + tên + email) ngay phía trên — hàng tên/avatar
            # của khung chat tại đây là trùng lặp: ẩn hẳn để nhường
            # chiều cao cho luồng tin và cho khối việc của panel.
            # V5.3.2: ẩn cả KHUNG chứa để đệm trên của hàng không
            # thành khoảng trống chết.
            self._name_host.setVisible(False)

        # Chip ngữ cảnh: tin gửi tiếp theo sẽ GẮN command_id này.
        self.chip_row = QFrame()
        chip_layout = QHBoxLayout(self.chip_row)
        chip_layout.setContentsMargins(8, 4, 4, 4)
        chip_layout.setSpacing(6)
        self.chip_label = QLabel("")
        self.chip_label.setObjectName("Muted12")
        # Cột chat hẹp (~450px): cho nhãn chip XUỐNG DÒNG thay vì bị
        # cắt cụt ở mép phải cạnh nút ✕.
        self.chip_label.setWordWrap(True)
        chip_layout.addWidget(self.chip_label, 1)
        chip_clear = QPushButton("✕")
        # V5.3.3 (V2): cùng họ với nút thu/mở — bỏ hộp "ghost"
        # (viền BORDER) quanh dấu ✕, giữ glyph phẳng + tooltip.
        chip_clear.setObjectName("ChatChipClearButton")
        chip_clear.setStyleSheet(
            "QPushButton#ChatChipClearButton {"
            " background: transparent; border: none;"
            f" color:{theme.MUTED}; padding: 2px 6px;"
            " }"
            "QPushButton#ChatChipClearButton:hover {"
            f" color:{theme.TEXT};"
            " }"
        )
        chip_clear.setToolTip("Bỏ ngữ cảnh lệnh — tin tiếp theo là tin thường")
        chip_clear.clicked.connect(lambda: self.set_context_command(None))
        chip_layout.addWidget(chip_clear)
        self.chip_row.setStyleSheet(
            f"background:{theme.CARD}; border:1px solid {theme.BORDER};"
            " border-radius:8px;"
        )
        self.chip_row.setVisible(False)
        # V5.3.2: chip nằm trong khung đệm ngang 16px như mọi hàng
        # chữ của khung chat (chip là điều khiển ngữ cảnh, KHÔNG
        # phải tin nhắn — giữ thẻ viền mảnh của nó như cũ).
        chip_host = QWidget()
        chip_host_layout = QVBoxLayout(chip_host)
        chip_host_layout.setContentsMargins(
            _CHAT_SIDE_PADDING, 8, _CHAT_SIDE_PADDING, 0
        )
        chip_host_layout.addWidget(self.chip_row)
        body_layout.addWidget(chip_host)
        self._chip_host = chip_host
        self._chip_host.setVisible(False)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        # Nền viewport phải TỐI như panel (mẫu WorkPanel V4.5):
        # QSS toàn cục chỉ đặt QScrollArea trong suốt, viewport con
        # vẫn sơn màu palette sáng mặc định.
        self.scroll.setStyleSheet(
            "QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.PANEL}; }}"
        )
        self.thread_host = QWidget()
        self.thread_layout = QVBoxLayout(self.thread_host)
        # V5.3.2: hàng tin giữ đệm TRONG 16px (đệm chữ theo ảnh
        # duyệt) và khoảng cách giữa các tin thoáng như ảnh mẫu;
        # khung ngoài không còn lề nào khác — luồng tràn hết bề
        # ngang ô chứa.
        self.thread_layout.setContentsMargins(
            _CHAT_SIDE_PADDING, 8, _CHAT_SIDE_PADDING, 12
        )
        self.thread_layout.setSpacing(16)
        self.thread_layout.addStretch(1)
        self.scroll.setWidget(self.thread_host)
        # V6.5: BÁM ĐÁY — thanh cuộn luôn ở dưới cùng; mỗi khi nội dung
        # cao thêm (tin mới, Muse đang chảy chữ, ảnh/bong bóng vừa dựng
        # xong) mà đang bám đáy thì kéo xuống đáy ngay. Người dùng tự
        # cuộn lên đọc lịch sử thì thôi bám, cuộn về đáy thì bám lại.
        self._stick_bottom = True
        bar = self.scroll.verticalScrollBar()
        bar.rangeChanged.connect(self._on_range_changed)
        bar.valueChanged.connect(self._on_scroll_value)
        self._jump_btn = QPushButton("↓ Tin mới nhất", self.scroll)
        self._jump_btn.setObjectName("ChatJumpBottom")
        self._jump_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._jump_btn.setStyleSheet(
            f"QPushButton#ChatJumpBottom {{ background: {theme.ACCENT}; color: {theme.ACCENT_INK};"
            " border: none; border-radius: 13px; padding: 4px 12px; font-weight: 600; }"
        )
        self._jump_btn.clicked.connect(self.stick_to_bottom)
        self._jump_btn.hide()
        if self._collapsible:
            # V5.2.1: luồng tin khi BUNG bị chặn chiều cao — cuộn
            # BÊN TRONG khung, không bao giờ đẩy nội dung công việc
            # của panel chi tiết khỏi vùng nhìn.
            self.scroll.setMinimumHeight(OFFICE_THREAD_MIN_HEIGHT)
            self.scroll.setMaximumHeight(OFFICE_THREAD_MAX_HEIGHT)
        body_layout.addWidget(self.scroll, 1)

        # V5.3.2 (mục 5): ô nhập nằm trên DẢI nền tối hơn panel
        # một bậc (theme.CHAT_COMPOSER_BG), giãn hết bề ngang,
        # KHÔNG viền/khung quanh ô nhập; stylesheet của dải scope
        # theo objectName để không rò xuống widget con (§14).
        # V5.3.3 (V1 — ảnh duyệt chat_redesign_v3): dải cao CỐ
        # ĐỊNH ~88px (theme.chat_composer_height từ line-height
        # thật), bố cục MỘT HÀNG: ô soạn chiếm hết chiều cao dải
        # (chữ tự căn giữa theo chiều cao khi ngắn — xem
        # _ComposerEdit), nút Gửi là viên accent đặc NEO GÓC
        # PHẢI-DƯỚI trong cùng dải. Bản V5.3.2 xếp ô soạn + hàng
        # nút thành hai tầng dọc nên dải cao ~150px và chữ dính
        # trên — chủ kênh chê "dòng nhắn tin quá cao".
        self.composer_strip = QFrame()
        self.composer_strip.setObjectName("ChatComposerStrip")
        self.composer_strip.setStyleSheet(
            "QFrame#ChatComposerStrip {"
            f" background:{theme.CHAT_COMPOSER_BG}; border:none;"
            " }"
        )
        self.composer_strip.setFixedHeight(
            theme.chat_composer_height(self.font())
        )
        strip_layout = QHBoxLayout(self.composer_strip)
        strip_layout.setContentsMargins(
            _CHAT_SIDE_PADDING, theme.CHAT_COMPOSER_VPAD,
            8, theme.CHAT_COMPOSER_VPAD
        )
        strip_layout.setSpacing(8)
        self.composer = _ComposerEdit()
        self.composer.setPlaceholderText("Nhắn cho Muse…")
        # Gợi ý phím đầy đủ nằm ở tooltip của ô nhập (ảnh duyệt
        # rút placeholder còn một câu ngắn).
        self.composer.setToolTip(
            "Enter: gửi tin · Shift+Enter: xuống dòng"
        )
        # Trên dải, ô soạn là chữ trần: nền trong suốt, không
        # viền (khung native đã tắt ở _ComposerEdit). Thanh cuộn
        # dọc giữ kiểu mảnh của QSS toàn cục như các bảng.
        self.composer.setStyleSheet(
            "QPlainTextEdit { background: transparent; border: none;"
            " padding: 2px 0px; }"
            " QPlainTextEdit:focus { border: none; }"
        )
        self.composer.send_requested.connect(self._send)
        strip_layout.addWidget(self.composer, 1)
        send_column = QVBoxLayout()
        send_column.setContentsMargins(0, 0, 0, 0)
        send_column.setSpacing(0)
        send_column.addStretch(1)
        self.send_button = QPushButton("Gửi")
        self.send_button.setProperty("variant", "primary")
        self.send_button.clicked.connect(self._send)
        send_column.addWidget(self.send_button)
        strip_layout.addLayout(send_column)
        body_layout.addWidget(self.composer_strip)

        # Dòng gợi ý/lỗi dưới dải nhập: chỉ hiện khi có nội dung
        # (gửi lỗi, tin quá dài) — ẩn hẳn khi trống để không thành
        # dải chết thường trực dưới ô nhập.
        hint_host = QWidget()
        hint_layout = QVBoxLayout(hint_host)
        hint_layout.setContentsMargins(
            _CHAT_SIDE_PADDING, 6, _CHAT_SIDE_PADDING, 10
        )
        self.hint_label = QLabel("")
        self.hint_label.setObjectName("Faint12")
        self.hint_label.setWordWrap(True)
        hint_layout.addWidget(self.hint_label)
        body_layout.addWidget(hint_host)
        self._hint_host = hint_host
        self._hint_host.setVisible(False)

        root.addWidget(self.body_widget, 1)
        if self._collapsible:
            # Mặc định THU GỌN ngay từ lúc dựng — nhịp refresh đầu
            # tiên (set_agent) sẽ tự bung nếu agent có tin/câu hỏi
            # đang chờ.
            self._apply_expanded(False)
        self._sync_enabled()

    # ------------------------------------------------------------------ #
    # Chọn agent / ngữ cảnh
    # ------------------------------------------------------------------ #
    def set_agent(self, agent: dict | None, context_command_id: str | None = None):
        """Mở luồng của `agent`; context_command_id (nếu có) gắn vào
        tin user đầu tiên được gửi sau đó. ĐỔI agent thì chip ngữ
        cảnh của agent trước bị xoá (không rò ngữ cảnhข้าม luồng)."""
        new_id = agent["id"] if agent else None
        if new_id != self.agent_id:
            self._context_command_id = None
            self._set_chip_visible(False)
            # V5.3.2: luồng mới — chưa biết tin cuối, xoá mốc
            # nuôi trạng thái đọc của agent trước.
            self._last_message_at = None
            if self._collapsible:
                # V5.2.1: đổi agent = lượt xem MỚI — xoá lựa chọn
                # tay + hẹn thu của agent trước và về THU GỌN;
                # refresh() ngay dưới đây tự bung lại nếu agent mới
                # có tin chưa đọc/câu hỏi chờ của chính mình.
                self._manual = None
                self._manual_max_id = 0
                self._manual_pending_key = None
                self._pending_key = None
                self._sent_for_pending_key = None
                self._collapse_armed = False
                self._apply_expanded(False)
        self._agent = dict(agent) if agent else None
        # V5.3.2: trạng thái đọc theo agent VỪA chọn (refresh dưới
        # đây sẽ chốt lại sau khi nạp tin).
        self._sync_read_status()
        if context_command_id is not None:
            self.set_context_command(context_command_id)
        self._fingerprint = None
        self._sig = None
        self._sync_header()
        self._sync_enabled()
        self.refresh()

    def _set_chip_visible(self, visible: bool):
        """Ẩn/hiện chip ngữ cảnh CÙNG khung đệm của nó (V5.3.2) —
        chip ẩn mà khung còn hiện sẽ để lại khoảng trống chết."""
        self.chip_row.setVisible(visible)
        self._chip_host.setVisible(visible)

    def set_context_command(self, command_id: str | None):
        self._context_command_id = command_id or None
        if self._context_command_id:
            self.chip_label.setText(
                f"Đang hỏi về lệnh #{self._context_command_id} — tin bạn "
                "gửi tiếp theo sẽ gắn với lệnh này."
            )
            self._set_chip_visible(True)
        else:
            self._set_chip_visible(False)

    def _set_hint(self, text: str):
        """Dòng gợi ý/lỗi dưới dải nhập (V5.3.2): có chữ mới hiện
        khung chứa — trống thì ẩn hẳn."""
        self.hint_label.setText(text)
        self._hint_host.setVisible(bool(text))

    def _sync_read_status(self, unread: int | None = None):
        """Dòng trạng thái đọc ở đầu ô chat (V5.3.2, mục 4): chữ
        thường mờ "đã đọc · 19:24" / "chưa đọc · 19:24" theo tin
        MỚI NHẤT đã dựng; chưa dựng được tin nào mà còn tin chưa
        đọc thì hiện số tin; không có gì thì để trống. Chỉ ĐỌC
        truy vấn gộp rẻ — không nạp tin (giữ cổng vân §16)."""
        if self.read_status_label is None:
            return
        if self._agent is None:
            text = ""
        else:
            if unread is None:
                unread, _max_id = self._attention()
            if self._last_message_at:
                when = _fmt_time_short(self._last_message_at)
                state = "đã đọc" if unread == 0 else "chưa đọc"
                text = f"{state} · {when}" if when else state
            elif unread > 0:
                text = f"{unread} tin chưa đọc"
            else:
                text = ""
        if self.read_status_label.text() != text:
            self.read_status_label.setText(text)

    @property
    def agent_id(self) -> int | None:
        return self._agent["id"] if self._agent else None

    # ------------------------------------------------------------------ #
    # V5.2.1 — Thu/mở khung chat (chỉ chế độ collapsible; bản thường
    # ở mục Tài khoản không bao giờ đi qua các đường này)
    # ------------------------------------------------------------------ #
    @property
    def is_expanded(self) -> bool:
        """Đang bung (True) hay đang thu gọn (False). Bản không
        thu/mở luôn coi là đang bung."""
        return self._expanded if self._collapsible else True

    def _attention(self) -> tuple[int, int]:
        """(số tin đến chưa đọc, id tin lớn nhất) của luồng hiện
        tại bằng MỘT truy vấn gộp rẻ — không nạp tin, không dựng
        widget, không đánh dấu đã đọc."""
        if self._agent is None:
            return (0, 0)
        try:
            _count, max_id, unread = self._store.messages_signature(
                self._agent["id"]
            )[:3]
        except Exception:
            return (0, 0)
        return (int(unread or 0), int(max_id or 0))

    def _sync_unread_badge(self, unread: int | None = None):
        """Huy hiệu trên thanh tiêu đề: số tin chưa đọc; khi chưa
        đọc = 0 mà còn câu hỏi chờ thì hiện lời nhắc chờ trả lời."""
        if self.unread_badge is None:
            return
        if unread is None:
            unread, _max_id = self._attention()
        if unread > 0:
            # Huy hiệu SỐ gọn (đúng nghĩa "huy hiệu số tin chưa
            # đọc") — bản chữ dài từng bị cắt trong panel 320px;
            # nghĩa đầy đủ nằm ở tooltip + dòng trạng thái chat
            # trong thân cuộn của panel.
            self.unread_badge.setText(str(unread))
            self.unread_badge.setToolTip(f"{unread} tin chưa đọc")
            self.unread_badge.setVisible(True)
        elif self._pending_key:
            self.unread_badge.setText("⏸")
            self.unread_badge.setToolTip(
                "Đang chờ bạn trả lời câu hỏi của Muse"
            )
            self.unread_badge.setVisible(True)
        else:
            self.unread_badge.setVisible(False)

    def _apply_expanded(self, expanded: bool):
        """Đặt trạng thái bung/thu THUẦN hiển thị (không nạp dữ
        liệu — nơi gọi chịu trách nhiệm refresh khi bung). Thu gọn
        thì xoá vân vẽ: lần bung kế phải dựng lại theo dữ liệu mới
        nhất thay vì tin theo bong bóng cũ."""
        if not self._collapsible:
            return
        self._expanded = bool(expanded)
        self.body_widget.setVisible(self._expanded)
        if self.expand_button is not None:
            self.expand_button.setText("▾" if self._expanded else "▸")
            self.expand_button.setToolTip(
                "Thu gọn khung chat" if self._expanded
                else "Mở khung chat"
            )
        if not self._expanded:
            self._fingerprint = None
        # V5.3.1 (M3e): panel Văn phòng khôi phục/nhớ chiều cao
        # luồng kéo tay theo đúng nhịp bung/thu này.
        self.expand_changed.emit(self._expanded)

    def set_user_thread_height(self, height):
        """Bật chế độ chiều cao luồng KÉO TAY (V5.3.1 M3e —
        splitter dọc trong panel Văn phòng giữ chiều cao THỰC;
        hàm này chỉ làm hai việc: nới dải chặn của luồng từ mặc
        định 120–160 sang dải kéo tay 100–420 — chiều cao kéo
        tay THẮNG trần mặc định 160 của M3b — và ghi lại giá trị
        để panel khôi phục đúng khi bung lại). height=None → tắt
        chế độ kéo tay, quay về dải mặc định. Chỉ có tác dụng ở
        chế độ collapsible."""
        if not self._collapsible:
            return
        if height is None:
            self._user_thread_height = None
            self.scroll.setMinimumHeight(OFFICE_THREAD_MIN_HEIGHT)
            self.scroll.setMaximumHeight(OFFICE_THREAD_MAX_HEIGHT)
        else:
            self._user_thread_height = max(
                OFFICE_THREAD_USER_MIN_HEIGHT,
                min(OFFICE_THREAD_USER_MAX_HEIGHT, int(height)),
            )
            self.scroll.setMinimumHeight(OFFICE_THREAD_USER_MIN_HEIGHT)
            self.scroll.setMaximumHeight(OFFICE_THREAD_USER_MAX_HEIGHT)
        # V5.3.3 (V4): đổi dải min/max của luồng KHÔNG tự làm
        # layout phân phối lại ngay — việc phân phối lại chỉ chạy
        # khi sự kiện LayoutRequest được xử lý, nên nơi đọc chiều
        # cao luồng ngay sau đó (lưu/khôi phục) đo phải số CŨ BỊ
        # KẸP (probe: nới dải xong luồng vẫn 160, qua một vòng sự
        # kiện mới thành 386; activate() đơn thuần KHÔNG ép
        # được). Xả hàng sự kiện LayoutRequest ĐỒNG BỘ ngay tại
        # đây để mọi phép đo hình học sau lời gọi này đều là số
        # đã yên.
        QCoreApplication.sendPostedEvents(
            None, QEvent.Type.LayoutRequest
        )
        if self.layout() is not None:
            self.layout().activate()

    def user_thread_height(self) -> int | None:
        """Chiều cao kéo tay đã ghi (None = đang ở dải mặc định)."""
        return self._user_thread_height

    def fixed_chrome_height(self) -> int:
        """Tổng chiều cao phần CỐ ĐỊNH của khung chat — mọi khối
        TRỪ luồng tin: thanh tiêu đề/đầu ô chat, hàng tên, chip
        ngữ cảnh, dải ô nhập, dòng gợi ý (chỉ tính khối ĐANG
        HIỆN) + khoảng cách layout giữa chúng.

        V5.3.3 (V4): con số này nuôi phép khôi phục splitter của
        panel Văn phòng (tổng chat = luồng đã lưu + phần cố
        định). Bản cũ đo bằng HIỆU SỐ HÌNH HỌC THOÁNG QUA
        (chat.height() − scroll.height()) ngay sau khi bung —
        lúc đó layout chưa yên nên phần cố định bị đánh giá
        THẤP (thiếu đúng 28px ở môi trường có QSS: 170 thay vì
        198) và luồng khôi phục hụt đúng 28px. Đo bằng sizeHint
        của từng khối (số tĩnh theo font/QSS, không phụ thuộc
        nhịp layout) cho đúng số vật chất ở cả hai môi trường
        có/không QSS (probe V5.3.3: 198/176 — khớp tuyệt đối
        với hình học sau khi yên)."""
        def _height_of(widget) -> int:
            # Widget GHIM chiều cao (min == max, như dải ô nhập
            # V5.3.3): chiều cao vật chất là đúng số đã ghim —
            # sizeHint của nó (suy từ layout con) không phải số
            # thật sẽ hiện. Còn lại lấy sizeHint theo font/QSS.
            if 0 < widget.minimumHeight() == widget.maximumHeight():
                return widget.minimumHeight()
            return widget.sizeHint().height()

        def _sum_except(layout, skip) -> int:
            total = 0
            visible = 0
            for index in range(layout.count()):
                widget = layout.itemAt(index).widget()
                if widget is None or widget is skip:
                    continue
                if not widget.isVisible():
                    continue
                total += _height_of(widget)
                visible += 1
            if visible > 1:
                total += layout.spacing() * (visible - 1)
            return total

        root = self.layout()
        if root is None:
            return 0
        total = 0
        visible = 0
        for index in range(root.count()):
            widget = root.itemAt(index).widget()
            if widget is None or not widget.isVisible():
                continue
            if widget is self.body_widget:
                total += _sum_except(
                    self.body_widget.layout(), self.scroll
                )
            else:
                total += _height_of(widget)
            visible += 1
        if visible > 1:
            total += root.spacing() * (visible - 1)
        return total

    def _on_strip_pressed(self, _event):
        """Bấm vào thanh tiêu đề (ngoài nút thu/mở) = thu/mở tay."""
        self.toggle_expand()

    def toggle_expand(self):
        """Thu/mở TAY bằng nút hoặc bấm thanh tiêu đề. Lựa chọn tay
        giữ cho agent này tới khi có tin chưa đọc MỚI hoặc câu hỏi
        chờ MỚI (mốc ghi tại đây — xem _maybe_auto_expand)."""
        if not self._collapsible or self._agent is None:
            return
        target = not self._expanded
        _unread, max_id = self._attention()
        self._manual = "open" if target else "closed"
        self._manual_max_id = max_id
        self._manual_pending_key = self._pending_key
        self._collapse_armed = False
        self._apply_expanded(target)
        if target:
            self.refresh()

    def expand_chat(self):
        """Mở chat theo ý người dùng từ bên ngoài (vd điểm vào
        "💬 Hỏi về lệnh này" ở Văn phòng): tính như bấm mở tay —
        không tự thu trong lượt xem này."""
        if not self._collapsible:
            return
        _unread, max_id = self._attention()
        self._manual = "open"
        self._manual_max_id = max_id
        self._manual_pending_key = self._pending_key
        self._apply_expanded(True)
        self.refresh()

    def set_pending_question(self, key):
        """Nơi chứa (Văn phòng) nạp khoá câu hỏi needs_user đang
        chờ của agent hiện tại — id lệnh dạng chuỗi, None = không
        còn câu hỏi chờ. Câu hỏi MỚI xuất hiện → tự bung; câu hỏi
        được gỡ SAU KHI người dùng đã gửi trả lời cho chính nó →
        tự thu (khi không còn tin chưa đọc và không mở tay)."""
        key = str(key) if key else None
        old = self._pending_key
        if key == old:
            return
        self._pending_key = key
        if not self._collapsible:
            return
        self._sync_unread_badge()
        if key is not None:
            if self._expanded:
                return
            if (self._manual == "closed"
                    and self._manual_pending_key == key):
                return  # người dùng đã chủ động thu cho đúng câu hỏi này
            if self._manual == "closed":
                self._manual = None  # câu hỏi MỚI phá lựa chọn thu tay
            self._apply_expanded(True)
            self.refresh()
        elif old is not None and self._sent_for_pending_key == old:
            self._sent_for_pending_key = None
            unread, _max_id = self._attention()
            if unread == 0 and self._manual != "open":
                self._apply_expanded(False)

    def _maybe_auto_expand(self, unread: int, max_id: int) -> bool:
        """Đang THU GỌN ở một nhịp refresh: có tự bung không? Trả
        True khi đã bung (nơi gọi nạp đầy đủ tiếp). Lựa chọn THU
        TAY chỉ bị phá bởi tin/câu hỏi MỚI hơn mốc lúc bấm thu."""
        if self._manual == "closed":
            new_message = unread > 0 and max_id > self._manual_max_id
            new_question = (
                bool(self._pending_key)
                and self._pending_key != self._manual_pending_key
            )
            if not (new_message or new_question):
                return False
            self._manual = None
        if unread > 0 or self._pending_key:
            self._apply_expanded(True)
            return True
        return False

    # ------------------------------------------------------------------ #
    def _sync_header(self):
        if self._agent is None:
            self.agent_name_label.setText(self._empty_hint)
            self._set_pill("chưa chọn", "unknown")
            pixmap = theme.robot_avatar_pixmap(34, grey=True)
            if pixmap is not None:
                self.avatar_label.setPixmap(pixmap)
            return
        name_text = f"{self._agent['name']} · {self._agent['email']}"
        if self.agent_name_label.text() != name_text:
            self.agent_name_label.setText(name_text)
        status = self._agent.get("status") or "offline"
        labels = {
            "online": ("🟢 đang hoạt động", "in"),
            "idle": ("🟡 vừa rời đi", "unknown"),
            "offline": ("⚪ ngoại tuyến", "out"),
            "revoked": ("🚫 đã thu hồi", "out"),
        }
        text, state = labels.get(status, (status, "unknown"))
        self._set_pill(text, state)
        # V5.2: avatar robot thật + vòng màu theo agent; agent không
        # online thì bản xám. Pixmap lấy từ cache của theme (rẻ).
        pixmap = theme.robot_avatar_pixmap(
            34,
            ring=theme.agent_ring_color(self._agent["id"]),
            grey=status not in ("online", "idle"),
        )
        if pixmap is not None:
            self.avatar_label.setPixmap(pixmap)

    def _set_pill(self, text: str, state: str):
        """Đặt pill trạng thái — V5.2: chỉ unpolish/polish khi (chữ,
        trạng thái) THẬT SỰ đổi (nắn style mỗi nhịp 5s là việc thừa
        trên luồng UI)."""
        if self._pill_state == (text, state):
            return
        self._pill_state = (text, state)
        self.agent_pill.setText(text)
        self.agent_pill.setProperty("state", state)
        # QLabel đổi property động phải nắn lại style mới áp màu pill.
        self.agent_pill.style().unpolish(self.agent_pill)
        self.agent_pill.style().polish(self.agent_pill)

    def _sync_enabled(self):
        enabled = self._agent is not None
        self.composer.setEnabled(enabled)
        self.send_button.setEnabled(enabled)

    # ------------------------------------------------------------------ #
    # Làm mới luồng (vân dữ liệu + giữ vị trí cuộn)
    # ------------------------------------------------------------------ #
    def refresh(self):
        if self._agent is None:
            return
        try:
            fresh = self._store.get_agent(self._agent["id"])
            if fresh is not None:
                self._agent = fresh
            # V5.2 (hiệu năng §15): cổng vân RẺ trước — một truy vấn
            # gộp; vân không đổi thì DỪNG, không nạp 200 tin. (Trạng
            # thái đã-đọc của tin 'user' không còn nằm trong cổng này:
            # nó không được vẽ lên bong bóng nên bỏ qua là an toàn.)
            sig = (self._agent["id"],) + tuple(
                self._store.messages_signature(self._agent["id"])
            )
        except Exception:
            return
        # sig = (agent_id, số tin, id lớn nhất, số tin đến chưa đọc)
        if self._collapsible:
            unread_now = int(sig[3] or 0)
            self._sync_unread_badge(unread_now)
            if not self.isVisible():
                # V5.2.1: widget CHƯA HIỆN (panel chưa mở, đang
                # dựng) — chỉ ghi vân: KHÔNG tự bung, KHÔNG đánh
                # dấu đã đọc cho thứ người dùng chưa thể nhìn thấy.
                # showEvent gọi refresh lại ngay khi hiện và quyết
                # định bung/thu lúc đó. (Thiếu cổng này, nhịp dựng
                # ban đầu bung+đọc+hẹn thu, rồi showEvent thi hành
                # hẹn thu ngay — tin chưa đọc không bao giờ kịp
                # hiện. Test V5.2.1 bắt được đúng lỗi này.)
                self._sig = sig
                return
            if not self._expanded:
                # V5.2.1: đang THU GỌN — nhịp này CHỈ dùng vân rẻ:
                # không nạp tin, không dựng bong bóng, KHÔNG đánh
                # dấu đã đọc (người dùng chưa nhìn thấy gì cả). Có
                # tin/câu hỏi chờ MỚI thì tự bung rồi nạp đầy đủ ở
                # phần dưới; không thì dừng ngay tại đây.
                self._sig = sig
                self._sync_header()
                # V5.3.2: trạng thái đọc vẫn tươi khi THU GỌN (chỉ
                # từ vân rẻ + mốc tin cuối đã biết — không nạp tin).
                self._sync_read_status(unread_now)
                if not self._maybe_auto_expand(
                    unread_now, int(sig[2] or 0)
                ):
                    return
            elif self._collapse_armed:
                # V5.2.1: nhịp TRƯỚC đã đọc hết tin (đánh dấu đã đọc
                # ở cuối refresh đó) — thu lại ở nhịp này, tức tin
                # đã nằm trên màn hình ít nhất một nhịp cho người
                # dùng đọc (thu ngay trong nhịp vừa bung = giật).
                self._collapse_armed = False
                if (unread_now == 0 and not self._pending_key
                        and self._manual != "open"):
                    self._apply_expanded(False)
                    self._sig = sig
                    self._sync_header()
                    self._sync_unread_badge(0)
                    self._sync_read_status(0)
                    return
        try:
            if sig == self._sig and self._fingerprint is not None:
                self._sync_header()
                return
            messages = self._store.list_messages(self._agent["id"], limit=200)
        except Exception:
            return
        self._sync_header()
        fingerprint = (
            self._agent["id"],
            tuple(
                (m["id"], m["direction"], m["body"], m["command_id"],
                 m["read_at"] is None)
                for m in messages
            ),
        )
        if fingerprint == self._fingerprint:
            self._sig = sig
            return
        bar = self.scroll.verticalScrollBar()
        was_at_bottom = self._stick_bottom or bar.value() >= bar.maximum() - 48
        old_value = bar.value()
        self._fingerprint = fingerprint
        stick_before = self._stick_bottom
        self._rebuilding = True  # V6.5: dựng lại bong bóng không được đổi trạng thái bám đáy
        self._rebuild(messages)
        # Đánh dấu đã đọc NGAY khi luồng đang mở: tin Muse + tin hệ
        # thống không còn 'chưa đọc' sau khi người dùng đã nhìn thấy.
        try:
            marked = self._store.mark_read(self._agent["id"], "agent")
            marked += self._store.mark_read(self._agent["id"], "system")
        except Exception:
            marked = 0
        if marked:
            self._on_store_changed()
        # V5.2: chốt vân RẺ theo trạng thái SAU đánh dấu đã đọc —
        # nhịp 5s kế tiếp thấy vân khớp và dừng ngay ở cổng rẻ,
        # không dựng lại bong bóng thêm một vòng thừa.
        try:
            self._sig = (self._agent["id"],) + tuple(
                self._store.messages_signature(self._agent["id"])
            )
        except Exception:
            self._sig = sig
        if self._collapsible:
            # V5.2.1: huy hiệu phải theo trạng thái SAU khi đọc —
            # đồng bộ lại tại đây, không đợi nhịp kế (bản đầu để
            # badge "N tin chưa đọc" treo trên luồng đã đọc hết).
            unread_after = int(self._sig[3] or 0) if self._sig else 0
            self._sync_unread_badge(unread_after)
            if (marked and unread_after == 0 and not self._pending_key
                    and self._manual != "open"):
                # Nhịp này vừa ĐÁNH DẤU ĐÃ ĐỌC tin cuối cùng và
                # không còn câu hỏi chờ → HẸN thu ở nhịp refresh KẾ
                # — không thu ngay trong nhịp vừa bung/đọc vì tin
                # phải ở trên màn hình ít nhất một nhịp cho người
                # dùng đọc. Đang mở TAY thì không hẹn.
                self._collapse_armed = True
        # V5.3.2: chốt trạng thái đọc theo vân SAU khi đã đánh
        # dấu đã đọc — đầu ô chat hiện "đã đọc · <giờ tin cuối>".
        self._sync_read_status(
            int(self._sig[3] or 0) if self._sig else None
        )
        # Cuộn: đang ở đáy (hoặc lần dựng đầu) → bám đáy; đang đọc
        # lịch sử ở trên → giữ nguyên vị trí.
        from PySide6.QtWidgets import QApplication

        QApplication.processEvents()
        self._rebuilding = False
        self._stick_bottom = stick_before
        bar = self.scroll.verticalScrollBar()
        if was_at_bottom or (old_value == 0 and stick_before):
            bar.setValue(bar.maximum())
            # V5.3.2 (hồi quy lộ qua render nghiệm thu): lần dựng
            # ĐẦU ngay trong nhịp TỰ BUNG vì tin chưa đọc — khung
            # vừa hiện, hàng tin vừa chèn, hình học luồng chưa yên
            # khi setValue chạy nên maximum chưa đúng và vị trí
            # "đáy" trôi về ĐẦU luồng (người dùng mở panel thấy
            # tin CŨ nhất, các nhịp sau bị cổng vân chặn nên không
            # tự lành). Hẹn áp lại ĐÚNG Ý ĐỊNH bám đáy sau một
            # vòng lặp sự kiện, khi layout đã yên.
            QTimer.singleShot(0, self._scroll_to_bottom)
        else:
            bar.setValue(min(old_value, bar.maximum()))
            # V6.5: layout có thể chưa yên → giữ đúng vị trí người đang đọc.
            QTimer.singleShot(0, lambda v=old_value: self._restore_scroll(v))

    def _restore_scroll(self, value: int):
        if self._stick_bottom:
            return
        bar = self.scroll.verticalScrollBar()
        bar.setValue(min(value, bar.maximum()))
        self._stick_bottom = False
        self._place_jump()

    def _on_range_changed(self, _minimum, maximum):
        if getattr(self, "_rebuilding", False):
            return
        if self._stick_bottom:
            self.scroll.verticalScrollBar().setValue(maximum)
        self._place_jump()

    def _on_scroll_value(self, value):
        if getattr(self, "_rebuilding", False):
            return
        bar = self.scroll.verticalScrollBar()
        self._stick_bottom = value >= bar.maximum() - 24
        self._place_jump()

    def _place_jump(self):
        btn = getattr(self, "_jump_btn", None)
        if btn is None:
            return
        show = not self._stick_bottom and self.scroll.verticalScrollBar().maximum() > 0
        if show:
            btn.adjustSize()
            vp = self.scroll.viewport().geometry()
            btn.move(vp.center().x() - btn.width() // 2, vp.bottom() - btn.height() - 8)
            btn.raise_()
        btn.setVisible(show)

    def stick_to_bottom(self):
        """Kéo xuống đáy và bám đáy lại."""
        self._stick_bottom = True
        self._scroll_to_bottom()
        self._place_jump()

    def _scroll_to_bottom(self):
        """Áp vị trí cuộn xuống ĐÁY luồng theo maximum HIỆN TẠI
        (được hẹn gọi từ refresh sau khi layout yên — xem trên)."""
        bar = self.scroll.verticalScrollBar()
        bar.setValue(bar.maximum())

    def _clear_thread(self):
        while self.thread_layout.count() > 1:
            item = self.thread_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()

    def _rebuild(self, messages: list[dict]):
        self._clear_thread()
        if not messages:
            self._last_message_at = None
            empty = QLabel(
                "Chưa có tin nhắn nào. Gửi lời nhắn đầu tiên — Muse "
                "sẽ đọc và trả lời qua cầu nối ngay trong khung này. "
                "Khi một lệnh kẹt cần bạn xử lý, Muse cũng sẽ hỏi "
                "tại đây."
            )
            empty.setObjectName("Muted")
            empty.setWordWrap(True)
            self.thread_layout.insertWidget(0, empty)
            return
        self._last_message_at = messages[-1].get("created_at")
        for index, message in enumerate(messages):
            self.thread_layout.insertWidget(
                index, self._message_row(message)
            )

    # ------------------------------------------------------------------ #
    # V5.3.2 — Hàng tin PHẲNG (Phương án 1 đã duyệt): chữ trần trên
    # nền panel, KHÔNG khung/viền/nền riêng cho từng tin. Phân biệt
    # hai phía bằng căn lề + màu tên; mốc thời gian là chữ nhỏ mờ
    # CÙNG HÀNG với tên.
    # ------------------------------------------------------------------ #
    def _agent_display_name(self) -> str:
        """Tên hiển thị của phía Muse: "Muse · <nhãn hồ sơ/kênh>"
        (đúng ảnh duyệt) — tên agent đã bắt đầu bằng "Muse" thì
        giữ nguyên, không nhân đôi."""
        name = (self._agent or {}).get("name") or "Muse"
        if name.lower().startswith("Muse"):
            return name
        return f"Muse · {name}"

    def _message_name_label(self, text: str, color: str) -> QLabel:
        label = QLabel(text)
        label.setStyleSheet(f"color:{color}; font-weight:700;")
        return label

    def _message_time_label(self, message: dict) -> QLabel:
        label = QLabel(_fmt_time_short(message.get("created_at")))
        label.setStyleSheet(f"color:{theme.MUTED}; font-size:11px;")
        return label

    def _message_ref_label(self, message: dict) -> QLabel | None:
        if not message.get("command_id"):
            return None
        ref = QLabel(f"↳ về lệnh #{message['command_id']}")
        ref.setObjectName("Faint12")
        ref.setStyleSheet(f"color:{theme.ACCENT};")
        return ref

    def _message_body_label(self, message: dict) -> _MessageBodyLabel:
        body = _MessageBodyLabel(message["body"])
        body.setWordWrap(True)
        body.setTextInteractionFlags(Qt.TextSelectableByMouse)
        return body

    def _message_row(self, message: dict) -> QWidget:
        direction = message["direction"]
        if direction == "system":
            return self._system_row(message)
        host = QWidget()
        column = QVBoxLayout(host)
        column.setContentsMargins(0, 0, 0, 0)
        column.setSpacing(3)
        ref = self._message_ref_label(message)
        if direction == "user":
            # Phía NGƯỜI DÙNG — căn PHẢI toàn bộ: hàng tên gồm giờ
            # mờ + "Bạn" đậm accent; thân tin căn phải; không
            # avatar.
            name_row = QHBoxLayout()
            name_row.setContentsMargins(0, 0, 0, 0)
            name_row.setSpacing(6)
            name_row.addStretch(1)
            name_row.addWidget(self._message_time_label(message))
            name_row.addWidget(
                self._message_name_label("Bạn", theme.ACCENT)
            )
            column.addLayout(name_row)
            if ref is not None:
                ref.setAlignment(Qt.AlignRight)
                column.addWidget(ref)
            body_row = QHBoxLayout()
            body_row.setContentsMargins(0, 0, 0, 0)
            body_row.addStretch(1)
            body = self._message_body_label(message)
            body.setAlignment(Qt.AlignRight)
            body_row.addWidget(body)
            column.addLayout(body_row)
            return host
        # Phía CLAUDE — căn TRÁI: hàng tên gồm avatar tròn (asset
        # robot thật, vòng màu theo agent) + tên đậm sáng + giờ mờ
        # cùng hàng; thân tin thụt đúng bề rộng avatar + khoảng
        # cách để thẳng hàng với tên.
        name_row = QHBoxLayout()
        name_row.setContentsMargins(0, 0, 0, 0)
        name_row.setSpacing(7)
        avatar = QLabel()
        avatar.setFixedSize(_MESSAGE_AVATAR_SIZE, _MESSAGE_AVATAR_SIZE)
        if self._agent is not None:
            status = self._agent.get("status") or "offline"
            pixmap = theme.robot_avatar_pixmap(
                _MESSAGE_AVATAR_SIZE,
                ring=theme.agent_ring_color(self._agent["id"]),
                grey=status not in ("online", "idle"),
            )
            if pixmap is not None:
                avatar.setPixmap(pixmap)
        name_row.addWidget(avatar)
        name_row.addWidget(
            self._message_name_label(
                self._agent_display_name(), theme.TEXT
            )
        )
        name_row.addWidget(self._message_time_label(message))
        name_row.addStretch(1)
        column.addLayout(name_row)
        if ref is not None:
            ref_row = QHBoxLayout()
            ref_row.setContentsMargins(0, 0, 0, 0)
            ref_row.addSpacing(_MESSAGE_BODY_INDENT)
            ref_row.addWidget(ref)
            ref_row.addStretch(1)
            column.addLayout(ref_row)
        body_row = QHBoxLayout()
        body_row.setContentsMargins(0, 0, 0, 0)
        body_row.addSpacing(_MESSAGE_BODY_INDENT)
        body_row.addWidget(self._message_body_label(message))
        body_row.addStretch(1)
        column.addLayout(body_row)
        return host

    def _system_row(self, message: dict) -> QWidget:
        """Tin hệ thống (lệnh kẹt needs_user): chữ căn giữa màu
        cảnh báo, nghiêng — PHẲNG như mọi tin khác (V5.3.2 bỏ nền
        tint vàng của V5.1): vẫn nổi bật nhờ màu + vị trí giữa,
        không cần hộp."""
        host = QWidget()
        column = QVBoxLayout(host)
        column.setContentsMargins(24, 0, 24, 0)
        column.setSpacing(3)
        ref = self._message_ref_label(message)
        if ref is not None:
            ref.setAlignment(Qt.AlignCenter)
            column.addWidget(ref)
        label = QLabel(message["body"])
        label.setWordWrap(True)
        label.setAlignment(Qt.AlignCenter)
        label.setStyleSheet(
            f"color:{theme.WARNING}; font-style:italic;"
        )
        column.addWidget(label)
        return host

    # ------------------------------------------------------------------ #
    # Gửi tin
    # ------------------------------------------------------------------ #
    def _send(self):
        if self._agent is None:
            return
        text = self.composer.toPlainText().strip()
        if not text:
            return
        if len(text) > Store.MESSAGE_BODY_LIMIT:
            self._set_hint(
                f"Tin quá dài ({len(text)}/{Store.MESSAGE_BODY_LIMIT} "
                "ký tự) — rút gọn rồi gửi lại."
            )
            return
        try:
            self._store.add_message(
                self._agent["id"], "user", text,
                command_id=self._context_command_id,
            )
        except Exception as exc:
            self._set_hint(f"Không gửi được tin: {exc}")
            return
        self.composer.clear()
        self._stick_bottom = True  # V6.5: vừa gửi → luôn thấy tin của mình
        self._set_hint("")
        # Ngữ cảnh lệnh CHỈ gắn vào tin đầu tiên sau khi mở chip.
        if self._context_command_id:
            self.set_context_command(None)
        try:
            self._wake_bridge()
        except Exception:
            pass
        # V6.3: đẩy tin thẳng vào muse.ai của tài khoản (chat tức thì).
        hook = type(self).user_message_hook
        if hook is not None:
            try:
                hook(dict(self._agent), text)
            except Exception:
                pass
        self._on_store_changed()
        self._fingerprint = None
        self.refresh()
        if self._collapsible and self._expanded and self._manual != "open":
            # V5.2.1: vừa GỬI trả lời — còn câu hỏi chờ thì ghi nhớ
            # đã trả lời cho CHÍNH câu hỏi đó (tự thu khi câu hỏi
            # được gỡ, xem set_pending_question); không còn gì chờ
            # thì thu NGAY — đây là hệ quả trực tiếp của hành động
            # gửi của người dùng, không cần hẹn sang nhịp kế.
            if self._pending_key:
                self._sent_for_pending_key = self._pending_key
            else:
                self._collapse_armed = False
                self._apply_expanded(False)
                self._sync_unread_badge(0)
