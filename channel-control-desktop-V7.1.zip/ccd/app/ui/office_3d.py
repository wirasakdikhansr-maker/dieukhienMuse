"""V6.4 — VĂN PHÒNG 3D (isometric, vẽ bằng QPainter — nhẹ, không cần
WebGL/OpenGL, chạy được mọi máy Windows).

Mỗi tài khoản Muse là một "khoang làm việc" 3D:
- Sàn khoang hình thoi (isometric) có vòng sáng màu trạng thái dưới chân.
- Bàn khối 3 mặt (mặt trên sáng, hai mặt bên tối) + màn hình phát sáng,
  trên màn hình là thanh tiến độ của việc đang làm.
- Nhân vật robot khối 3D (thân trụ đổ bóng chuyển màu, đầu bo tròn có kính
  mặt, hai mắt sáng theo trạng thái, ăng-ten nháy) — màu thân riêng cho
  từng agent, nhấp nhô nhẹ khi đang làm, cúi khi rảnh, mờ khi ngoại tuyến.
- Thẻ nổi trên đầu: tên, trạng thái, việc đang làm, thanh tiến độ 4px, %,
  huy hiệu ★ trưởng phòng / 💬 tin chưa đọc / ⚠ sự cố.

BẤM DỄ: cả khối khoang (thẻ + nhân vật + bàn + sàn) là MỘT vùng bấm hình
chữ nhật lớn; rê chuột vào thì khoang nổi lên + viền sáng, con trỏ thành
bàn tay, tooltip ghi việc đang làm. Bấm vùng trống = bỏ chọn.
"""

from __future__ import annotations

import math
import time

from PySide6.QtCore import QPointF, QRect, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QPolygonF,
    QRadialGradient,
)
from PySide6.QtWidgets import QScrollArea, QToolTip, QWidget

from . import theme

POD_W = 300          # bề rộng một khoang (px)
POD_H = 312          # chiều cao một khoang
GAP_X = 18
GAP_Y = 10

STATE_LABEL = {
    "working": "Đang làm",
    "needs_user": "Chờ bạn",
    "waiting": "Chờ nhận việc",
    "idle": "Rảnh",
    "offline": "Ngoại tuyến",
}


def _state_color(state: str) -> QColor:
    return QColor(theme.status_color(state))


def _shade(color: QColor, factor: float) -> QColor:
    return color.lighter(int(100 * factor)) if factor >= 1 else color.darker(int(100 / factor))


class _Stage(QWidget):
    agent_clicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.desks: list[dict] = []
        self.unread: dict[int, int] = {}
        self.issues: dict[int, dict] = {}
        self.kpi: dict[int, int | None] = {}
        self.lead_id: int | None = None
        self.selected: int | None = None
        self.hover: int | None = None
        self._hits: list[tuple[QRectF, dict]] = []
        self._t0 = time.monotonic()
        self.setMouseTracking(True)
        self.setAttribute(Qt.WA_OpaquePaintEvent, True)
        # V6.4.1 (tối ưu): phần TĨNH (sàn, lưới, bàn, thẻ chữ) vẽ MỘT lần
        # vào ảnh đệm; mỗi khung chỉ vẽ lại vùng robot của các khoang ĐANG
        # ĐỘNG và NHÌN THẤY. Cửa sổ không được focus → 5 khung/giây;
        # không có ai cần chuyển động → 2 khung/giây (chỉ ăng-ten nháy).
        self._floor_cache: QPixmap | None = None
        self._pod_cache: dict = {}
        self._timer = QTimer(self)
        self._timer.setInterval(66)
        self._timer.timeout.connect(self._tick)

    # ------------------------------------------------------------ bố cục
    def columns(self) -> int:
        fit = max(1, (self.width() - GAP_X) // (POD_W + GAP_X))
        return max(1, min(fit, len(self.desks) or 1))

    def relayout(self):
        cols = self.columns()
        rows = max(1, -(-len(self.desks) // cols))
        self.setMinimumHeight(rows * (POD_H + GAP_Y) + 40)
        self.update()

    def pod_rect(self, index: int) -> QRectF:
        cols = self.columns()
        row, col = divmod(index, cols)
        total_w = cols * POD_W + (cols - 1) * GAP_X
        left = max(GAP_X, (self.width() - total_w) / 2)
        # hàng sau lệch nửa khoang → cảm giác chiều sâu isometric
        offset = (POD_W + GAP_X) / 2 if (row % 2 and cols > 1 and len(self.desks) > cols) else 0
        return QRectF(left + col * (POD_W + GAP_X) + offset * 0, 24 + row * (POD_H + GAP_Y), POD_W, POD_H)

    def showEvent(self, event):
        super().showEvent(event)
        self._timer.start()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._floor_cache = None
        self._pod_cache.clear()
        self.relayout()

    # ------------------------------------------------------------ nhịp động
    @staticmethod
    def _animated(desk: dict) -> bool:
        if desk.get("agent_status") in ("offline", "revoked") or desk.get("state") == "offline":
            return False
        return desk.get("state") in ("working", "needs_user", "waiting")

    def _robot_zone(self, rect: QRectF) -> QRect:
        cx = rect.center().x()
        floor_y = rect.bottom() - 50
        return QRectF(cx - 118, floor_y - 175, 236, 220).toAlignedRect()

    def _tick(self):
        if not self.isVisible() or not self.desks:
            return
        visible = self.visibleRegion().boundingRect()
        if visible.isEmpty():
            return
        moving = 0
        for index, desk in enumerate(self.desks):
            rect = self.pod_rect(index)
            zone = self._robot_zone(rect).adjusted(0, -8, 0, 8)
            if not zone.intersects(visible):
                continue
            if self._animated(desk) or desk.get("agent_status") == "online":
                self.update(zone)
                moving += self._animated(desk)
        window = self.window()
        active = window is not None and window.isActiveWindow()
        interval = 66 if (moving and active) else (200 if moving else 500)
        if self._timer.interval() != interval:
            self._timer.setInterval(interval)

    # ------------------------------------------------------------ chuột
    def _desk_at(self, pos) -> dict | None:
        for rect, desk in self._hits:
            if rect.contains(pos):
                return desk
        return None

    def mouseMoveEvent(self, event):
        desk = self._desk_at(event.position())
        new = desk["agent_id"] if desk else None
        if new != self.hover:
            old_hover = self.hover
            self.hover = new
            self.setCursor(Qt.PointingHandCursor if desk else Qt.ArrowCursor)
            for rect, d in self._hits:
                if d["agent_id"] in (old_hover, new):
                    self.update(rect.adjusted(-6, -12, 6, 8).toAlignedRect())
        if desk:
            cur = desk.get("current") or {}
            tip = f"<b>{desk.get('name')}</b> — {STATE_LABEL.get(desk.get('state'), desk.get('state'))}"
            if cur:
                tip += (f"<br>{cur.get('type_label')} · {cur.get('instruction') or ''}"
                        f"<br>{int(cur.get('progress') or 0)}% · {cur.get('step') or 'chưa báo bước'}")
            tip += "<br><i>Bấm để xem chi tiết + chat</i>"
            QToolTip.showText(event.globalPosition().toPoint(), tip, self)

    def leaveEvent(self, event):
        self.hover = None
        self.setCursor(Qt.ArrowCursor)
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        desk = self._desk_at(event.position())
        self.agent_clicked.emit(desk["agent_id"] if desk else None)

    # ------------------------------------------------------------ vẽ
    def paintEvent(self, event):
        p = QPainter(self)
        clip = event.rect()
        if self._floor_cache is None or self._floor_cache.size() != self.size() * self.devicePixelRatioF():
            self._floor_cache = self._render_floor()
        dpr = self._floor_cache.devicePixelRatio()
        p.drawPixmap(clip, self._floor_cache,
                     QRect(int(clip.x() * dpr), int(clip.y() * dpr), int(clip.width() * dpr), int(clip.height() * dpr)))
        p.setRenderHint(QPainter.Antialiasing)
        self._hits = []
        if not self.desks:
            p.setPen(QColor(theme.MUTED))
            p.drawText(self.rect(), Qt.AlignCenter, "Chưa có tài khoản Muse nào — thêm ở tab Tài khoản Muse.")
            p.end()
            return
        t = time.monotonic() - self._t0
        for index, desk in enumerate(self.desks):
            rect = self.pod_rect(index)
            self._hits.append((rect, desk))
            if not rect.adjusted(0, -10, 0, 10).toAlignedRect().intersects(clip):
                continue  # khoang ngoài vùng cần vẽ → bỏ qua hẳn
            self._paint_pod(p, rect, desk, t, index)
        p.end()
        if len(self._pod_cache) > 6 * max(1, len(self.desks)):
            self._pod_cache.clear()

    def _render_floor(self) -> QPixmap:
        dpr = self.devicePixelRatioF()
        pix = QPixmap(self.size() * dpr)
        pix.setDevicePixelRatio(dpr)
        q = QPainter(pix)
        q.setRenderHint(QPainter.Antialiasing)
        self._paint_floor(q)
        q.end()
        return pix

    def _paint_floor(self, p: QPainter):
        g = QLinearGradient(0, 0, 0, self.height())
        g.setColorAt(0, QColor("#101215"))
        g.setColorAt(1, QColor(theme.BG))
        p.fillRect(self.rect(), g)
        # lưới isometric mờ
        p.setPen(QPen(QColor(255, 255, 255, 10), 1))
        step = 46
        h = self.height()
        for x in range(-h, self.width() + h, step):
            p.drawLine(QPointF(x, 0), QPointF(x + h * 0.58, h))
            p.drawLine(QPointF(x, 0), QPointF(x - h * 0.58, h))
        # quầng sáng accent giữa sàn
        glow = QRadialGradient(QPointF(self.width() / 2, self.height() * 0.35), max(self.width(), 400) * 0.6)
        accent = QColor(theme.ACCENT)
        accent.setAlpha(18)
        glow.setColorAt(0, accent)
        glow.setColorAt(1, QColor(0, 0, 0, 0))
        p.fillRect(self.rect(), glow)

    def _pod_key(self, rect: QRectF, desk: dict) -> tuple:
        aid = desk["agent_id"]
        cur = desk.get("current") or {}
        issue = (self.issues.get(aid) or {}).get("count")
        return (
            aid, desk.get("state"), desk.get("agent_status"), desk.get("name"),
            cur.get("id"), cur.get("progress"), cur.get("step"), cur.get("instruction"),
            cur.get("type_label"), desk.get("queue_count"), self.unread.get(aid), issue,
            self.lead_id == aid, self.kpi.get(aid), aid == self.hover, aid == self.selected,
            int(rect.width()), int(rect.height()),
        )

    def _layer(self, rect: QRectF, painter_fn) -> QPixmap:
        dpr = self.devicePixelRatioF()
        pix = QPixmap(int(rect.width() * dpr), int(rect.height() * dpr))
        pix.setDevicePixelRatio(dpr)
        pix.fill(Qt.transparent)
        q = QPainter(pix)
        q.setRenderHint(QPainter.Antialiasing)
        q.translate(-rect.x(), -rect.y())
        painter_fn(q)
        q.end()
        return pix

    def _paint_pod(self, p: QPainter, rect: QRectF, desk: dict, t: float, index: int):
        aid = desk["agent_id"]
        state = desk.get("state") or "idle"
        offline = state == "offline" or desk.get("agent_status") in ("offline", "revoked")
        hovered = aid == self.hover
        selected = aid == self.selected
        lift = -6 if hovered else 0
        st_color = _state_color(state)
        body = QColor(theme.agent_ring_color(aid))
        if offline:
            body = QColor("#5B616B")
        cx = rect.center().x()
        floor_y = rect.bottom() - 50
        # Vùng ảnh đệm rộng hơn khoang một chút (viền hover/vòng chọn).
        box = rect.adjusted(-4, -4, 4, 4)
        key = self._pod_key(rect, desk)
        layers = self._pod_cache.get(key)
        if layers is None:
            def back(q):
                if hovered or selected:
                    bg = QPainterPath()
                    bg.addRoundedRect(rect.adjusted(2, 2, -2, -2), 16, 16)
                    fill = QColor(theme.ACCENT if selected else "#FFFFFF")
                    fill.setAlpha(14 if selected else 8)
                    q.fillPath(bg, fill)
                    pen = QColor(theme.ACCENT if selected else "#FFFFFF")
                    pen.setAlpha(150 if selected else 60)
                    q.setPen(QPen(pen, 1.5))
                    q.drawPath(bg)
                dw, dh = 118, 40
                diamond = QPolygonF([QPointF(cx, floor_y - dh), QPointF(cx + dw, floor_y),
                                     QPointF(cx, floor_y + dh), QPointF(cx - dw, floor_y)])
                q.setPen(Qt.NoPen)
                tile = QLinearGradient(cx - dw, floor_y, cx + dw, floor_y)
                tile.setColorAt(0, QColor("#1A1C21"))
                tile.setColorAt(1, QColor("#141518"))
                q.setBrush(tile)
                q.drawPolygon(diamond)
                if selected:
                    q.setPen(QPen(QColor(theme.ACCENT), 2.5))
                    q.setBrush(Qt.NoBrush)
                    q.drawEllipse(QPointF(cx, floor_y + 4), 104, 33)

            def front(q):
                self._paint_desk(q, cx + 18, floor_y + 6, desk, st_color, offline)
                self._paint_card(q, QRectF(rect.x() + 14, rect.y() + 8, rect.width() - 28, 96),
                                 desk, st_color, offline)
                q.setFont(self._font(12, True))
                q.setPen(QColor(theme.TEXT if not offline else theme.MUTED))
                q.drawText(QRectF(rect.x(), floor_y + 34, rect.width(), 18), Qt.AlignCenter,
                           desk.get("name") or "—")

            layers = (self._layer(box, back), self._layer(box, front))
            self._pod_cache[key] = layers
        back_pix, front_pix = layers
        p.save()
        p.translate(0, lift)
        p.drawPixmap(box.topLeft(), back_pix)
        # ---- phần ĐỘNG: vòng trạng thái nhấp nháy + robot
        ring = QColor(st_color)
        pulse = 0.5 + 0.5 * math.sin(t * 3 + index) if state in ("working", "needs_user") else 0.4
        ring.setAlpha(int(70 + 90 * pulse) if not offline else 40)
        p.setPen(QPen(ring, 2.2))
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QPointF(cx, floor_y + 4), 92, 28)
        bob = 0 if offline else math.sin(t * 4 + index * 1.3) * (3 if state == "working" else 1.2)
        p.save()
        p.translate(cx - 34, floor_y - 92 + bob)
        p.scale(1.18, 1.18)
        self._paint_robot(p, 0, 0, body, st_color, state, offline, t, index)
        p.restore()
        p.drawPixmap(box.topLeft(), front_pix)
        p.restore()

    def _paint_robot(self, p, cx, base_y, body: QColor, st: QColor, state, offline, t, index):
        # bóng đổ
        shadow = QRadialGradient(QPointF(cx, base_y + 70), 46)
        shadow.setColorAt(0, QColor(0, 0, 0, 120))
        shadow.setColorAt(1, QColor(0, 0, 0, 0))
        p.setPen(Qt.NoPen)
        p.setBrush(shadow)
        p.drawEllipse(QPointF(cx, base_y + 70), 46, 12)
        # thân trụ (gradient ngang tạo khối)
        torso = QRectF(cx - 30, base_y + 6, 60, 62)
        g = QLinearGradient(torso.left(), 0, torso.right(), 0)
        g.setColorAt(0, _shade(body, 0.62))
        g.setColorAt(0.45, _shade(body, 1.12))
        g.setColorAt(1, _shade(body, 0.55))
        path = QPainterPath()
        path.addRoundedRect(torso, 22, 22)
        p.setBrush(g)
        p.drawPath(path)
        # ngực: đèn trạng thái
        chest = QColor(st)
        chest.setAlpha(230 if not offline else 80)
        p.setBrush(chest)
        p.drawEllipse(QPointF(cx, base_y + 34), 6, 6)
        # tay
        arm = _shade(body, 0.75)
        p.setBrush(arm)
        typing = math.sin(t * 9 + index) * 3 if state == "working" else 0
        p.drawRoundedRect(QRectF(cx - 42, base_y + 20 + typing, 14, 34), 7, 7)
        p.drawRoundedRect(QRectF(cx + 28, base_y + 20 - typing, 14, 34), 7, 7)
        # cổ + đầu
        p.setBrush(_shade(body, 0.5))
        p.drawRect(QRectF(cx - 7, base_y - 2, 14, 10))
        head = QRectF(cx - 34, base_y - 46, 68, 48)
        hg = QLinearGradient(head.left(), head.top(), head.right(), head.bottom())
        hg.setColorAt(0, _shade(body, 1.22))
        hg.setColorAt(1, _shade(body, 0.6))
        hp = QPainterPath()
        hp.addRoundedRect(head, 18, 18)
        p.setBrush(hg)
        p.drawPath(hp)
        # kính mặt tối
        visor = QRectF(cx - 25, base_y - 36, 50, 26)
        vp = QPainterPath()
        vp.addRoundedRect(visor, 11, 11)
        p.setBrush(QColor("#0B0D10"))
        p.drawPath(vp)
        # mắt sáng (nháy mắt định kỳ)
        blink = (t * 1.0 + index * 0.37) % 4.0 < 0.12
        eye = QColor(st if not offline else QColor("#4A4F57"))
        p.setBrush(eye)
        eh = 2 if blink or state == "idle" else 9
        for ex in (cx - 11, cx + 11):
            p.drawRoundedRect(QRectF(ex - 5, base_y - 23 - eh / 2, 10, eh), 3, 3)
        # ánh sáng phản chiếu trên đầu
        hl = QColor(255, 255, 255, 46)
        p.setBrush(hl)
        p.drawEllipse(QRectF(cx - 22, base_y - 44, 26, 8))
        # ăng-ten nháy
        p.setPen(QPen(_shade(body, 0.6), 2))
        p.drawLine(QPointF(cx, base_y - 46), QPointF(cx, base_y - 58))
        p.setPen(Qt.NoPen)
        on = (t * 2 + index) % 2 < 1 and not offline
        tip = QColor(st if on else QColor("#3A3D44"))
        p.setBrush(tip)
        p.drawEllipse(QPointF(cx, base_y - 61), 4.5, 4.5)

    def _paint_desk(self, p, cx, top_y, desk, st: QColor, offline):
        w, d, h = 82, 24, 22  # nửa rộng, nửa sâu, cao
        top = QPolygonF([QPointF(cx - w, top_y), QPointF(cx, top_y - d),
                         QPointF(cx + w, top_y), QPointF(cx, top_y + d)])
        left = QPolygonF([QPointF(cx - w, top_y), QPointF(cx, top_y + d),
                          QPointF(cx, top_y + d + h), QPointF(cx - w, top_y + h)])
        right = QPolygonF([QPointF(cx + w, top_y), QPointF(cx, top_y + d),
                           QPointF(cx, top_y + d + h), QPointF(cx + w, top_y + h)])
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#2A2D34"))
        p.drawPolygon(top)
        p.setBrush(QColor("#1D1F24"))
        p.drawPolygon(left)
        p.setBrush(QColor("#17191D"))
        p.drawPolygon(right)
        p.setPen(QPen(QColor(255, 255, 255, 22), 1))
        p.drawLine(QPointF(cx - w, top_y), QPointF(cx, top_y - d))
        p.drawLine(QPointF(cx, top_y - d), QPointF(cx + w, top_y))
        # màn hình
        mon = QRectF(cx + 4, top_y - 50, 64, 40)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor("#0E1013"))
        p.drawRoundedRect(mon, 5, 5)
        screen = mon.adjusted(4, 4, -4, -8)
        sg = QLinearGradient(screen.topLeft(), screen.bottomLeft())
        glow = QColor(st if not offline else QColor("#2A2D34"))
        c1 = QColor(glow)
        c1.setAlpha(90)
        c2 = QColor(glow)
        c2.setAlpha(30)
        sg.setColorAt(0, c1)
        sg.setColorAt(1, c2)
        p.setBrush(sg)
        p.drawRoundedRect(screen, 3, 3)
        cur = desk.get("current") or {}
        if cur and not offline:
            theme.paint_progress(p, QRectF(screen.x() + 4, screen.bottom() - 8, screen.width() - 8, 6),
                                 int(cur.get("progress") or 0))
        p.setBrush(QColor("#0E1013"))
        p.drawRect(QRectF(cx + 32, mon.bottom(), 8, 8))
        # bàn phím
        p.setBrush(QColor("#3A3D44"))
        kb = QPolygonF([QPointF(cx - 46, top_y + 2), QPointF(cx - 18, top_y - 12),
                        QPointF(cx + 6, top_y), QPointF(cx - 22, top_y + 14)])
        p.drawPolygon(kb)

    def _paint_card(self, p, rect: QRectF, desk, st: QColor, offline):
        path = QPainterPath()
        path.addRoundedRect(rect, 12, 12)
        bg = QColor(theme.PANEL)
        bg.setAlpha(238)
        p.fillPath(path, bg)
        border = QColor(st)
        border.setAlpha(110 if not offline else 40)
        p.setPen(QPen(border, 1.2))
        p.drawPath(path)
        # đuôi thẻ chỉ xuống nhân vật
        tail = QPolygonF([QPointF(rect.center().x() - 8, rect.bottom()),
                          QPointF(rect.center().x() + 8, rect.bottom()),
                          QPointF(rect.center().x(), rect.bottom() + 9)])
        p.setPen(Qt.NoPen)
        p.setBrush(bg)
        p.drawPolygon(tail)
        x = rect.x() + 12
        w = rect.width() - 24
        y = rect.y() + 10
        # tên + pill trạng thái + KPI
        online = desk.get("agent_status") == "online"
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(theme.SUCCESS if online else "#4A4F57"))
        p.drawEllipse(QPointF(x + 4, y + 9), 4, 4)
        x_name = x + 14
        name_font = self._font(13, True)
        p.setFont(name_font)
        p.setPen(QColor(theme.TEXT))
        name = desk.get("name") or "—"
        fm = QFontMetrics(name_font)
        name_w = min(fm.horizontalAdvance(name) + 6, w * 0.5)
        p.drawText(QRectF(x_name, y, name_w + 4, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   fm.elidedText(name, Qt.ElideRight, int(name_w)))
        px = x_name + name_w + 6
        px = self._pill(p, px, y, STATE_LABEL.get(desk.get("state"), desk.get("state") or ""), st)
        aid = desk["agent_id"]
        badges = []
        if self.lead_id is not None and aid == self.lead_id:
            badges.append(("★", QColor(theme.WARNING)))
        if self.unread.get(aid):
            badges.append((f"💬{self.unread[aid]}", QColor(theme.INFO)))
        issue = self.issues.get(aid)
        if issue and issue.get("count"):
            badges.append((f"⚠{issue['count']}", QColor(theme.DANGER)))
        bx = rect.right() - 12
        p.setFont(self._font(11, True))
        for text, color in reversed(badges):
            tw = QFontMetrics(p.font()).horizontalAdvance(text) + 12
            bx -= tw
            self._pill(p, bx, y, text, color, fixed_w=tw)
            bx -= 4
        y += 26
        cur = desk.get("current")
        p.setFont(self._font(11.5))
        if cur:
            title = f"{cur.get('type_label')} · {cur.get('instruction') or ''}"
            p.setPen(QColor(theme.TEXT))
            p.drawText(QRectF(x, y, w, 16), Qt.AlignLeft | Qt.AlignVCenter,
                       QFontMetrics(p.font()).elidedText(title, Qt.ElideRight, int(w)))
            y += 20
            pct = int(cur.get("progress") or 0)
            theme.paint_progress(p, QRectF(x, y, w - 42, 10), pct)
            p.setPen(QColor(theme.ACCENT))
            p.setFont(self._font(11.5, True))
            p.drawText(QRectF(x + w - 38, y - 3, 38, 16), Qt.AlignRight | Qt.AlignVCenter, f"{pct}%")
            y += 14
            p.setFont(self._font(11))
            p.setPen(QColor(theme.MUTED))
            step = cur.get("step") or "Chưa báo bước nào"
            p.drawText(QRectF(x, y, w, 16), Qt.AlignLeft | Qt.AlignVCenter,
                       QFontMetrics(p.font()).elidedText("▸ " + step, Qt.ElideRight, int(w)))
        else:
            p.setPen(QColor(theme.MUTED))
            msg = "Ngoại tuyến" if offline else "Đang rảnh — chưa có việc"
            p.drawText(QRectF(x, y, w, 16), Qt.AlignLeft | Qt.AlignVCenter, msg)
            y += 20
            queue = int(desk.get("queue_count") or 0)
            score = self.kpi.get(aid)
            p.drawText(QRectF(x, y, w, 16), Qt.AlignLeft | Qt.AlignVCenter,
                       f"Hàng đợi: {queue} việc · KPI {score if score is not None else '—'}")

    def _pill(self, p, x, y, text, color: QColor, fixed_w=None) -> float:
        font = self._font(10.5, True)
        p.setFont(font)
        tw = fixed_w or QFontMetrics(font).horizontalAdvance(text) + 14
        r = QRectF(x, y, tw, 18)
        path = QPainterPath()
        path.addRoundedRect(r, 9, 9)
        bg = QColor(color)
        bg.setAlpha(36)
        p.fillPath(path, bg)
        p.setPen(color)
        p.drawText(r, Qt.AlignCenter, text)
        return r.right()

    _FONTS: dict = {}

    def _font(self, px: float, bold: bool = False) -> QFont:
        key = (px, bold)
        font = self._FONTS.get(key)
        if font is None:
            font = QFont(self.font())
            font.setPixelSize(int(round(px)))
            font.setBold(bold)
            self._FONTS[key] = font
        return font


class Office3DView(QScrollArea):
    agent_clicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QScrollArea.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.stage = _Stage()
        self.stage.agent_clicked.connect(self.agent_clicked)
        self.setWidget(self.stage)

    def set_data(self, desks, unread, issues, kpi_scores, lead_id, selected):
        s = self.stage
        s.desks = list(desks or [])
        s.unread = dict(unread or {})
        s.issues = dict(issues or {})
        s.kpi = dict(kpi_scores or {})
        s.lead_id = lead_id
        s.selected = selected
        s.relayout()

    def set_selected(self, agent_id):
        self.stage.selected = agent_id
        self.stage.update()
