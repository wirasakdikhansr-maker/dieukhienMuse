"""V6.9 — MỌI NÚT ĐỀU CÓ PHẢN HỒI khi bấm.

1. Bộ lọc sự kiện toàn app: bấm một QPushButton → nút sáng viền màu nhấn +
   nền nhạt ngay lập tức (≈0,7 giây) để người dùng biết app ĐÃ nhận lệnh,
   kể cả với thao tác chạy rất nhanh hay chạy nền.
2. ``busy(button, text)``: thao tác dài (quét, mở trình duyệt, đăng nhập…)
   đổi chữ thành "⏳ Đang …", khoá nút, đổi màu cho tới khi gọi hàm trả về
   (hoặc hết ``timeout_ms`` để không bao giờ kẹt vĩnh viễn).
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, QTimer
from PySide6.QtWidgets import QApplication, QPushButton, QToolButton

FLASH_MS = 700
_FLASH_QSS = ("QPushButton {{ border: 1px solid {accent}; background: rgba(206, 252, 25, 0.20);"
              " color: {accent}; }}")
_BUSY_QSS = ("QPushButton, QPushButton:disabled {{ border: 1px solid #F2C94C; background: rgba(242, 201, 76, 0.16);"
             " color: #F2C94C; }}")


def _accent() -> str:
    try:
        from . import theme

        return theme.ACCENT
    except Exception:
        return "#CEFC19"


def flash(button: QPushButton, ms: int = FLASH_MS) -> None:
    if button is None or button.property("ccd_busy"):
        return
    if button.property("ccd_flash"):
        return
    base = button.styleSheet()
    button.setProperty("ccd_flash", True)
    button.setProperty("ccd_flash_base", base)
    qss = _FLASH_QSS.format(accent=_accent())
    if isinstance(button, QToolButton):
        qss = qss.replace("QPushButton", "QToolButton")
    button.setStyleSheet(base + "\n" + qss)

    def restore(btn=button):
        try:
            if btn.property("ccd_flash") and not btn.property("ccd_busy"):
                btn.setStyleSheet(btn.property("ccd_flash_base") or "")
            btn.setProperty("ccd_flash", False)
        except RuntimeError:  # nút đã bị huỷ
            pass

    QTimer.singleShot(ms, button, restore)


def busy(button: QPushButton, text: str = "⏳ Đang xử lý…", timeout_ms: int = 60_000):
    """Đặt nút ở trạng thái ĐANG XỬ LÝ. Trả hàm ``done(ok=True, text=None)``
    để khôi phục; tự khôi phục sau timeout_ms."""
    if button is None:
        return lambda *a, **k: None
    if button.property("ccd_busy"):
        return button.property("ccd_busy_done") or (lambda *a, **k: None)
    original_text = button.text()
    original_qss = button.property("ccd_flash_base") if button.property("ccd_flash") else button.styleSheet()
    was_enabled = button.isEnabled()
    button.setProperty("ccd_busy", True)
    button.setText(text)
    button.setStyleSheet((original_qss or "") + "\n" + _BUSY_QSS)
    button.setEnabled(False)
    try:
        button.repaint()  # hiện "⏳ Đang …" NGAY cả khi thao tác chạy đồng bộ
    except Exception:
        pass
    state = {"done": False}

    def done(ok: bool = True, result_text: str | None = None, hold_ms: int = 1200):
        if state["done"]:
            return
        state["done"] = True
        try:
            if result_text:
                button.setText(result_text)
                color = "#7DDC7A" if ok else "#FF7A7A"
                button.setStyleSheet((original_qss or "") + f"\nQPushButton, QPushButton:disabled {{ border: 1px solid {color};"
                                     f" color: {color}; }}")

                def final(btn=button):
                    try:
                        btn.setText(original_text)
                        btn.setStyleSheet(original_qss or "")
                        btn.setEnabled(was_enabled)
                        btn.setProperty("ccd_busy", False)
                    except RuntimeError:
                        pass

                QTimer.singleShot(hold_ms, button, final)
            else:
                button.setText(original_text)
                button.setStyleSheet(original_qss or "")
                button.setEnabled(was_enabled)
                button.setProperty("ccd_busy", False)
            button.setProperty("ccd_flash", False)
        except RuntimeError:
            pass

    button.setProperty("ccd_busy_done", done)
    QTimer.singleShot(timeout_ms, button, lambda: done(True))
    return done


class _ClickFeedback(QObject):
    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.MouseButtonRelease and isinstance(obj, (QPushButton, QToolButton)):
            try:
                if obj.isEnabled() and obj.rect().contains(event.position().toPoint()):
                    flash(obj)
            except Exception:
                pass
        return False


_FILTER = None


def install(app: QApplication | None = None) -> None:
    """Gắn phản hồi bấm nút cho TOÀN app (gọi một lần, gọi lại vô hại)."""
    global _FILTER
    app = app or QApplication.instance()
    if app is None or _FILTER is not None:
        return
    _FILTER = _ClickFeedback(app)
    app.installEventFilter(_FILTER)
