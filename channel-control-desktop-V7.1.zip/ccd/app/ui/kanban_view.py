"""V6.5 — tab Công việc dạng KANBAN (theo bản thiết kế đã duyệt).

Dải KPI (Đang chạy · Chờ Muse nhận · Chờ bạn · Trễ hạn · Xong hôm nay)
→ lọc theo Muse + tìm → 4 cột thẻ việc → panel chi tiết bên phải với
dòng thời gian từng bước Muse/trưởng phòng đã làm và nút thao tác.
"""

from __future__ import annotations

from datetime import datetime, timedelta

from PySide6.QtCore import QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (
    QComboBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .. import work_board
from . import theme

STATUS_TEXT = {
    "queued": ("Chờ xếp lịch", theme.MUTED), "waiting_muse": ("Chờ Muse nhận", theme.INFO),
    "running": ("Đang làm", theme.ACCENT), "needs_user": ("Chờ bạn", theme.WARNING),
    "interrupted": ("Bị ngắt", theme.WARNING), "failed": ("Lỗi", theme.DANGER),
    "done": ("Xong", theme.SUCCESS),
}
COLUMN_COLORS = {"waiting": theme.INFO, "running": theme.ACCENT, "user": theme.WARNING, "done": theme.SUCCESS}


class _Bar(QWidget):
    """Thanh tiến độ MỘT kiểu chung của app (theme.paint_progress)."""

    def __init__(self, pct: int = 0, color: str | None = None, parent=None):
        super().__init__(parent)
        self.pct = pct
        self.color = color
        self.setFixedHeight(theme.PROGRESS_HEIGHT + 2)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def paintEvent(self, _event):
        painter = QPainter(self)
        theme.paint_progress(painter, QRectF(0, 1, self.width(), theme.PROGRESS_HEIGHT), self.pct, self.color)
        painter.end()


class _Tile(QFrame):
    def __init__(self, label: str, color: str, parent=None):
        super().__init__(parent)
        self.setObjectName("KanbanTile")
        self.setStyleSheet(
            f"QFrame#KanbanTile {{ background: {theme.CARD}; border: 1px solid {theme.BORDER};"
            f" border-left: 3px solid {color}; border-radius: 10px; }}"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(0)
        self.label = QLabel(label)
        self.label.setStyleSheet(f"color: {theme.MUTED}; font-size: 11px; background: transparent; border: none;")
        self.value = QLabel("0")
        self.value.setStyleSheet(f"color: {theme.TEXT}; font-size: 22px; font-weight: 700; background: transparent; border: none;")
        layout.addWidget(self.label)
        layout.addWidget(self.value)


class _Card(QFrame):
    clicked = Signal(str)

    def __init__(self, item: dict, column: str, selected: bool, parent=None):
        super().__init__(parent)
        self.item = item
        self.setObjectName("KanbanCard")
        # V6.5: thẻ co theo bề rộng cột (không đẩy cột sinh thanh cuộn ngang).
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        self.setMinimumWidth(0)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        border = theme.ACCENT if selected else (theme.DANGER if item["overdue"] else theme.BORDER)
        self.setStyleSheet(
            f"QFrame#KanbanCard {{ background: {theme.CARD}; border: 1px solid {border}; border-radius: 10px; }}"
            f"QFrame#KanbanCard:hover {{ border-color: {theme.ACCENT}; }}"
            "QLabel { background: transparent; border: none; }"
        )
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(5)
        type_label = QLabel(item["type"])
        type_label.setStyleSheet(f"color: {COLUMN_COLORS.get(column, theme.MUTED)}; font-size: 11px; font-weight: 600;")
        layout.addWidget(type_label)
        title = QLabel(item["title"])
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {theme.TEXT}; font-weight: 600;")
        layout.addWidget(title)
        if item["due"]:
            due = QLabel(("⏰ " if item["overdue"] else "🕑 ") + item["due"])
            due.setWordWrap(True)
            due.setStyleSheet(f"color: {theme.DANGER if item['overdue'] else theme.FAINT}; font-size: 11px;")
            layout.addWidget(due)
        if item["channel"]:
            ch = QLabel(item["channel"])
            ch.setStyleSheet(f"color: {theme.MUTED}; font-size: 11px;")
            layout.addWidget(ch)
        if column != "waiting" or item["pct"]:
            bar_row = QHBoxLayout()
            bar_row.addWidget(_Bar(item["pct"], theme.SUCCESS if column == "done" else None), 1)
            pct = QLabel(f"{item['pct']}%")
            pct.setStyleSheet(f"color: {theme.MUTED}; font-size: 11px;")
            bar_row.addWidget(pct)
            layout.addLayout(bar_row)
        step_text = item["error"] if item["status"] == "failed" and item["error"] else item["step"]
        if step_text:
            step = QLabel(f"▸ {step_text}")
            step.setWordWrap(True)
            step.setStyleSheet(f"color: {theme.DANGER if item['status'] == 'failed' else theme.MUTED}; font-size: 11px;")
            layout.addWidget(step)
        foot = QHBoxLayout()
        muse = QLabel(f"🤖 {item['muse']}")
        muse.setStyleSheet(f"color: {theme.FAINT}; font-size: 11px;")
        foot.addWidget(muse)
        foot.addStretch(1)
        if item["age"]:
            age = QLabel(item["age"])
            age.setStyleSheet(f"color: {theme.FAINT}; font-size: 11px;")
            foot.addWidget(age)
        layout.addLayout(foot)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.item["id"])
        super().mousePressEvent(event)


class KanbanView(QWidget):
    command_chosen = Signal(str)
    chat_requested = Signal(str)
    browser_requested = Signal(int)

    def __init__(self, store, settings: dict, commands_panel=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._commands_panel = commands_panel
        self._selected: str | None = None
        self._fingerprint = None
        self._detail_fp = None
        self._build()
        self._timer = QTimer(self)
        self._timer.setInterval(2500)
        self._timer.timeout.connect(self.refresh)
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(10)
        strip = QHBoxLayout()
        strip.setSpacing(10)
        self.tiles = {}
        for key, label, color in (
            ("running", "Đang chạy", theme.ACCENT), ("waiting", "Chờ Muse nhận", theme.INFO),
            ("user", "Cần xử lý (TP tự lo)", theme.WARNING), ("overdue", "Trễ hạn", theme.DANGER),
            ("done", "Xong hôm nay", theme.SUCCESS),
        ):
            tile = _Tile(label, color)
            self.tiles[key] = tile
            strip.addWidget(tile, 1)
        root.addLayout(strip)

        filters = QHBoxLayout()
        filters.addWidget(theme.muted_label("Lọc theo Muse:"))
        self.muse_combo = QComboBox()
        self.muse_combo.setMinimumWidth(180)
        self.muse_combo.currentIndexChanged.connect(lambda _i: self._force())
        filters.addWidget(self.muse_combo)
        self.search = QLineEdit()
        self.search.setPlaceholderText("🔍 Tìm việc / kênh / Muse…")
        self.search.setMinimumWidth(220)
        self.search.textChanged.connect(lambda _t: self._force())
        filters.addWidget(self.search)
        filters.addStretch(1)
        root.addLayout(filters)

        body = QHBoxLayout()
        body.setSpacing(10)
        self.columns = {}
        self.column_heads = {}
        for key, label, _st in work_board.COLUMNS:
            col = QFrame()
            col.setObjectName("KanbanCol")
            col.setStyleSheet(
                f"QFrame#KanbanCol {{ background: {theme.PANEL}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}"
            )
            col.setMinimumWidth(170)
            col.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
            col_layout = QVBoxLayout(col)
            col_layout.setContentsMargins(8, 10, 8, 8)
            col_layout.setSpacing(8)
            head = QLabel(label)
            head.setStyleSheet(
                f"color: {theme.TEXT}; font-weight: 700; background: transparent; border: none;"
                f" border-left: 3px solid {COLUMN_COLORS[key]}; padding-left: 8px;"
            )
            self.column_heads[key] = head
            col_layout.addWidget(head)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }")
            host = QWidget()
            host.setMinimumWidth(0)
            host_layout = QVBoxLayout(host)
            host_layout.setContentsMargins(0, 0, 4, 0)
            host_layout.setSpacing(8)
            host_layout.addStretch(1)
            scroll.setWidget(host)
            col_layout.addWidget(scroll, 1)
            self.columns[key] = host_layout
            body.addWidget(col, 1)
        self.detail = self._build_detail()
        body.addWidget(self.detail, 0)
        root.addLayout(body, 1)

    def _build_detail(self) -> QFrame:
        frame = QFrame()
        frame.setObjectName("KanbanDetail")
        frame.setFixedWidth(340)
        frame.setStyleSheet(
            f"QFrame#KanbanDetail {{ background: {theme.PANEL}; border: 1px solid {theme.BORDER}; border-radius: 12px; }}"
            "QFrame#KanbanDetail QLabel { background: transparent; border: none; }"
        )
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(8)
        layout.addWidget(theme.section_header("Chi tiết việc"))
        self.d_title = QLabel("Chọn một thẻ việc để xem chi tiết")
        self.d_title.setWordWrap(True)
        self.d_title.setStyleSheet(f"color: {theme.TEXT}; font-size: 14px; font-weight: 700;")
        layout.addWidget(self.d_title)
        self.d_meta = QLabel("")
        self.d_meta.setWordWrap(True)
        self.d_meta.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(self.d_meta)
        self.d_bar = _Bar(0)
        layout.addWidget(self.d_bar)
        self.d_steps_scroll = QScrollArea()
        self.d_steps_scroll.setWidgetResizable(True)
        self.d_steps_scroll.setFrameShape(QFrame.NoFrame)
        self.d_steps_scroll.setStyleSheet("QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }")
        steps_host = QWidget()
        self.d_steps = QVBoxLayout(steps_host)
        self.d_steps.setContentsMargins(0, 0, 0, 0)
        self.d_steps.setSpacing(6)
        self.d_steps.addStretch(1)
        self.d_steps_scroll.setWidget(steps_host)
        layout.addWidget(self.d_steps_scroll, 1)
        self.d_text = QLabel("")
        self.d_text.setWordWrap(True)
        self.d_text.setStyleSheet(f"color: {theme.MUTED}; font-size: 12px;")
        self.d_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        layout.addWidget(self.d_text)
        row1 = QHBoxLayout()
        self.btn_chat = QPushButton("💬 Nhắn Muse")
        self.btn_chat.clicked.connect(lambda: self._selected and self.chat_requested.emit(self._selected))
        self.btn_browser = QPushButton("🌐 Trình duyệt")
        self.btn_browser.clicked.connect(self._open_browser)
        row1.addWidget(self.btn_chat)
        row1.addWidget(self.btn_browser)
        layout.addLayout(row1)
        row2 = QHBoxLayout()
        self.btn_resume = QPushButton("▶ Chạy tiếp")
        self.btn_resume.setProperty("variant", "primary")
        self.btn_resume.clicked.connect(self._resume)
        self.btn_extend = QPushButton("⏱ +1 giờ")
        self.btn_extend.clicked.connect(self._extend)
        self.btn_cancel = QPushButton("✕ Huỷ")
        self.btn_cancel.setProperty("variant", "danger")
        self.btn_cancel.clicked.connect(self._cancel)
        row2.addWidget(self.btn_resume)
        row2.addWidget(self.btn_extend)
        row2.addWidget(self.btn_cancel)
        layout.addLayout(row2)
        self._set_buttons(None)
        return frame

    # ------------------------------------------------------------------ #
    def showEvent(self, event):
        super().showEvent(event)
        self._timer.start()
        self.refresh()

    def hideEvent(self, event):
        self._timer.stop()
        super().hideEvent(event)

    def _force(self):
        self._fingerprint = None
        self.refresh()

    def select(self, command_id: str | None):
        self._selected = command_id
        self._fingerprint = None
        self._detail_fp = None
        self.refresh()

    def _sync_muses(self):
        agents = [a for a in self._store.list_agents() if not a.get("revoked")]
        wanted = [("Tất cả Muse", None)] + [(a.get("name") or a.get("email"), int(a["id"])) for a in agents]
        current = [(self.muse_combo.itemText(i), self.muse_combo.itemData(i)) for i in range(self.muse_combo.count())]
        if wanted != current:
            keep = self.muse_combo.currentData()
            self.muse_combo.blockSignals(True)
            self.muse_combo.clear()
            for text, data in wanted:
                self.muse_combo.addItem(text, data)
            index = self.muse_combo.findData(keep)
            self.muse_combo.setCurrentIndex(max(0, index))
            self.muse_combo.blockSignals(False)

    def refresh(self):
        try:
            self._sync_muses()
            data = work_board.kanban(self._store, agent_id=self.muse_combo.currentData(),
                                     search=self.search.text())
        except Exception:
            return
        self._data = data
        for key, tile in self.tiles.items():
            tile.value.setText(str(data["strip"][key]))
        # V6.9: rê chuột lên ô đếm → popup liệt kê từng việc + lý do.
        from .. import command_actions

        cols = data["columns"]
        tile_ids = {
            "running": [c["id"] for c in cols.get("running", [])],
            "waiting": [c["id"] for c in cols.get("waiting", [])],
            "user": [c["id"] for c in cols.get("user", [])],
            "overdue": [c["id"] for k in ("waiting", "running", "user") for c in cols.get(k, []) if c["overdue"]],
            "done": [c["id"] for c in cols.get("done", [])],
        }
        for key, tile in self.tiles.items():
            command_actions.attach_lazy_tooltip(
                tile, lambda k=key, i=tuple(tile_ids.get(key, [])):
                command_actions.group_html(self._store, self.tiles[k].label.text(), i))
        fingerprint = (self._selected, tuple(
            (k, tuple((c["id"], c["status"], c["pct"], c["step"], c["due"], c["overdue"], c["muse"])
                      for c in v)) for k, v in data["columns"].items()))
        if fingerprint != self._fingerprint:
            self._fingerprint = fingerprint
            for key, layout in self.columns.items():
                while layout.count() > 1:
                    item = layout.takeAt(0)
                    if item.widget() is not None:
                        item.widget().deleteLater()
                cards = data["columns"][key]
                self.column_heads[key].setText(f"{data['labels'][key]}  ·  {len(cards)}")
                for item in cards[:80]:
                    card = _Card(item, key, item["id"] == self._selected)
                    card.clicked.connect(self._on_card)
                    # V6.9: rê chuột lên thẻ → popup kẹt gì / vì sao / bước kế
                    from .. import command_actions

                    command_actions.attach_lazy_tooltip(
                        card, lambda cid=item["id"]: command_actions.explain_html(self._store, cid))
                    layout.insertWidget(layout.count() - 1, card)
                if not cards:
                    empty = theme.muted_label("— trống —")
                    empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
                    layout.insertWidget(0, empty)
        self._refresh_detail()

    def _on_card(self, command_id: str):
        self.select(command_id)
        self.command_chosen.emit(command_id)

    def _refresh_detail(self):
        info = work_board.detail(self._store, self._selected) if self._selected else None
        fp = None if info is None else (info["status"], info["pct"], len(info["steps"]), info["due"], info["result"][:50])
        if fp == self._detail_fp and info is not None:
            return
        self._detail_fp = fp
        while self.d_steps.count() > 1:
            item = self.d_steps.takeAt(0)
            if item.widget() is not None:
                item.widget().deleteLater()
        if info is None:
            self.d_title.setText("Chọn một thẻ việc để xem chi tiết")
            self.d_meta.setText("")
            self.d_bar.pct = 0
            self.d_bar.update()
            self.d_text.setText("Mọi việc bạn hoặc trưởng phòng giao đều hiện ở đây, kèm từng bước Muse báo.")
            self._set_buttons(None)
            return
        text, color = STATUS_TEXT.get(info["status"], (info["status"], theme.MUTED))
        self.d_title.setText(f"{info['type']} · {info['title']}")
        parts = [f"<span style='color:{color}'>● {text}</span>", f"🤖 {info['muse']}"]
        if info["channel"]:
            parts.append(f"📺 {info['channel']}")
        if info["due"]:
            parts.append(f"<span style='color:{theme.DANGER if info['overdue'] else theme.MUTED}'>{info['due']}</span>")
        self.d_meta.setText(" &nbsp;·&nbsp; ".join(parts))
        self.d_bar.pct = info["pct"]
        self.d_bar.update()
        for step in info["steps"][-40:]:
            row = QLabel(f"{step['icon']}  {step['label']}"
                         f"<br><span style='color:{theme.FAINT}; font-size:11px'>{step['note']}"
                         f"{' · ' + step['actor'] if step['actor'] else ''}</span>")
            row.setTextFormat(Qt.TextFormat.RichText)
            row.setWordWrap(True)
            row.setStyleSheet(f"color: {theme.TEXT}; background: {theme.CARD}; border-radius: 8px; padding: 6px 8px;")
            self.d_steps.insertWidget(self.d_steps.count() - 1, row)
        if not info["steps"]:
            self.d_steps.insertWidget(0, theme.muted_label("Chưa có bước nào được báo."))
        bottom = info["result"] or info["error"] or info["instruction"]
        self.d_text.setText(bottom[:600])
        self._set_buttons(info)
        QTimer.singleShot(0, lambda: self.d_steps_scroll.verticalScrollBar().setValue(
            self.d_steps_scroll.verticalScrollBar().maximum()))

    def _set_buttons(self, info):
        status = (info or {}).get("status")
        self.btn_chat.setEnabled(bool(info and info.get("agent_id")))
        self.btn_browser.setEnabled(bool(info and info.get("profile_id")))
        self.btn_resume.setEnabled(status in ("needs_user", "failed", "interrupted"))
        self.btn_resume.setText("↻ Chạy lại" if status in ("failed", "interrupted") else "▶ Chạy tiếp")
        self.btn_extend.setEnabled(status in ("queued", "waiting_muse", "running", "needs_user"))
        self.btn_cancel.setEnabled(status in ("queued", "waiting_muse", "running", "needs_user"))

    # ------------------------------------------------------------------ #
    def _open_browser(self):
        info = work_board.detail(self._store, self._selected) if self._selected else None
        if info and info.get("profile_id"):
            self.browser_requested.emit(int(info["profile_id"]))

    def _resume(self):
        command = self._store.get_command(self._selected) if self._selected else None
        if command is None:
            return
        if command["status"] == "needs_user":
            self._store.resume_command(command["id"])
        else:
            self._store.requeue_command(command["id"])
        self._store.update_command_payload_flags(command["id"], clear_keys=("chat_sent",))
        self._detail_fp = None
        self._force()

    def _extend(self):
        command = self._store.get_command(self._selected) if self._selected else None
        if command is None:
            return
        now = datetime.now().astimezone()
        base = work_board._parse(command.get("due_at")) or now
        new_due = max(base, now) + timedelta(hours=1)
        self._store.set_command_due(command["id"], new_due.isoformat(timespec="seconds"))
        self._detail_fp = None
        self._force()

    def _cancel(self):
        command = self._store.get_command(self._selected) if self._selected else None
        if command is None:
            return
        if self._commands_panel is not None and hasattr(self._commands_panel, "_cancel_one"):
            self._commands_panel._cancel_one(command)
        else:
            self._store.finish_command(command["id"], "failed", result="Đã huỷ bởi người dùng.",
                                       error="Đã huỷ bởi người dùng.")
        self._detail_fp = None
        self._force()
