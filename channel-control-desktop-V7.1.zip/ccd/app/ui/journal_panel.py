"""Panel "Nhật ký" (V3.1) — nhật ký hệ thống + trình xem log file.

Hai tầng:
- Nhật ký nghiệp vụ (bảng journal trong kho, MỌI hồ sơ) — cùng dữ liệu
  với thẻ nhật ký ở mục Hồ sơ nhưng không lọc theo hồ sơ.
- Log file kỹ thuật (data/logs/ccd.log, ghi xoay vòng bởi
  app.logging_setup) — xem phần cuối file, nút Làm mới. Đây là nơi nhìn
  khi app có lỗi lạ trên máy người dùng.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .. import config, logging_setup
from ..store import Store
from . import theme


class JournalPanel(QWidget):
    def __init__(self, store: Store, parent=None):
        super().__init__(parent)
        self._store = store
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)

        header = QHBoxLayout()
        header.addWidget(theme.section_header("Nhật ký hệ thống"))
        header.addStretch(1)
        refresh_button = QPushButton("↻ Làm mới")
        refresh_button.clicked.connect(self.refresh)
        header.addWidget(refresh_button)
        root.addLayout(header)

        self.journal_view = QPlainTextEdit()
        self.journal_view.setObjectName("Journal")
        self.journal_view.setReadOnly(True)
        self.journal_view.setMaximumBlockCount(3000)
        root.addWidget(self.journal_view, 3)

        log_header = QHBoxLayout()
        log_header.addWidget(theme.section_header("Log file (kỹ thuật)"))
        self.log_path_label = theme.muted_label(str(logging_setup.log_file_path()))
        log_header.addWidget(self.log_path_label)
        log_header.addStretch(1)
        log_refresh = QPushButton("↻ Tải lại log")
        log_refresh.clicked.connect(self._refresh_log)
        log_header.addWidget(log_refresh)
        root.addLayout(log_header)

        self.log_view = QPlainTextEdit()
        self.log_view.setObjectName("Journal")
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(3000)
        root.addWidget(self.log_view, 2)

    # ------------------------------------------------------------------ #
    def refresh(self):
        entries = self._store.list_journal(limit=300)
        lines = [f"[{_fmt_ts(e['ts'])}] {e['message']}" for e in entries]
        self.journal_view.setPlainText(
            "\n".join(lines) if lines else "Chưa có dòng nhật ký nào."
        )
        self._refresh_log()

    def _refresh_log(self):
        tail = logging_setup.read_log_tail()
        self.log_view.setPlainText(
            tail if tail else "Chưa có log file (app chưa ghi dòng kỹ thuật nào)."
        )
        # Cuộn xuống cuối — phần mới nhất của log nằm ở cuối.
        cursor = self.log_view.textCursor()
        cursor.movePosition(cursor.MoveOperation.End)
        self.log_view.setTextCursor(cursor)


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m/%Y %H:%M:%S")
    except ValueError:
        return str(value)
