"""V6.3 — VĂN PHÒNG dạng 2D (sơ đồ phẳng chuyên nghiệp).

Trải HẾT bề ngang vùng chứa (không viền đen hai bên như cảnh 3D ảnh nền
cố định tỉ lệ). Mỗi agent là một thẻ "bàn làm việc" lớn, đọc được ngay:

  ┌───────────────────────────────────────────────┐
  │ ● Muse 01   [Đang làm] [★ Trưởng phòng]  KPI 82│
  │ ▶ Tạo video · Làm video 8 phút về tâm lý…      │
  │ ████████████░░░░░░░░  45%   hạn còn 2g10p      │
  │ Bước đang làm: Đang viết kịch bản cảnh 3/8     │
  │ ✓ Đọc yêu cầu  ✓ Nghiên cứu  ▶ Kịch bản  ○ …   │
  │ Lịch sử: 05:20 Nhận việc · 05:28 Viết kịch bản │
  │ Tiếp theo: 2 việc · 💬 1 tin chưa đọc           │
  └───────────────────────────────────────────────┘

Số cột tự tính theo bề rộng (thẻ tối thiểu 380px). Bấm thẻ = chọn agent
(panel chi tiết bên phải mở ra), bấm vùng trống = bỏ chọn.
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetrics, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QScrollArea, QWidget

from ..store import _parse_iso
from . import theme
from .steps_table import TYPE_PLAN

CARD_MIN_W = 380
CARD_H = 236
GAP = 14

STATE_COLORS = {
    "working": "#6CC7FF",
    "needs_user": "#C4A7FF",
    "waiting": "#F2C94C",
    "idle": "#6F7680",
    "offline": "#3A3D44",
}


class _Canvas(QWidget):
    agent_clicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.desks: list[dict] = []
        self.steps: dict[str, list[dict]] = {}
        self.kpi: dict[int, int | None] = {}
        self.lead_id: int | None = None
        self.unread: dict[int, int] = {}
        self.selected: int | None = None
        self._hit: list[tuple[QRectF, int]] = []
        self.setMouseTracking(True)

    def columns(self) -> int:
        fit = max(1, (self.width() - GAP) // (CARD_MIN_W + GAP))
        # Ít agent thì thẻ giãn ra lấp hết bề ngang.
        return max(1, min(fit, len(self.desks) or 1))

    def relayout(self):
        cols = self.columns()
        rows = max(1, -(-len(self.desks) // cols))
        self.setMinimumHeight(rows * (CARD_H + GAP) + GAP)
        self.update()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.relayout()

    def mousePressEvent(self, event):
        pos = event.position()
        for rect, agent_id in self._hit:
            if rect.contains(pos):
                self.agent_clicked.emit(agent_id)
                return
        self.agent_clicked.emit(None)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(), QColor(theme.BG))
        self._hit = []
        if not self.desks:
            p.setPen(QColor(theme.MUTED))
            p.drawText(self.rect(), Qt.AlignCenter, "Chưa có tài khoản Muse nào — thêm ở tab Tài khoản Muse.")
            return
        cols = self.columns()
        card_w = (self.width() - GAP * (cols + 1)) / cols
        for index, desk in enumerate(self.desks):
            row, col = divmod(index, cols)
            rect = QRectF(GAP + col * (card_w + GAP), GAP + row * (CARD_H + GAP), card_w, CARD_H)
            self._paint_card(p, rect, desk)
            self._hit.append((rect, desk["agent_id"]))
        p.end()

    # ------------------------------------------------------------------ #
    def _paint_card(self, p: QPainter, rect: QRectF, desk: dict):
        state = desk.get("state") or "idle"
        accent = QColor(STATE_COLORS.get(state, "#6F7680"))
        selected = desk["agent_id"] == self.selected
        path = QPainterPath()
        path.addRoundedRect(rect, 14, 14)
        p.fillPath(path, QColor(theme.CARD))
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(theme.ACCENT) if selected else QColor(theme.BORDER), 2 if selected else 1))
        p.drawPath(path)
        # dải màu trạng thái bên trái
        strip = QPainterPath()
        strip.addRoundedRect(QRectF(rect.x(), rect.y(), 6, rect.height()), 3, 3)
        p.fillPath(strip, accent)

        x = rect.x() + 18
        w = rect.width() - 30
        y = rect.y() + 14
        bold = QFont(self.font())
        bold.setBold(True)
        bold.setPixelSize(15)
        normal = QFont(self.font())
        normal.setPixelSize(12)
        small = QFont(self.font())
        small.setPixelSize(11)

        # Dòng 1: chấm online + tên + pill trạng thái + KPI
        online = desk.get("agent_status") == "online"
        p.setBrush(QColor("#6CC7FF" if online else "#6F7680"))
        p.setPen(Qt.NoPen)
        p.drawEllipse(QRectF(x, y + 5, 9, 9))
        p.setFont(bold)
        p.setPen(QColor(theme.TEXT))
        name = desk.get("name") or "—"
        fm = QFontMetrics(bold)
        name_w = min(fm.horizontalAdvance(name), w * 0.45)
        p.drawText(QRectF(x + 16, y, name_w + 4, 20), Qt.AlignLeft | Qt.AlignVCenter,
                   fm.elidedText(name, Qt.ElideRight, int(name_w)))
        px = x + 24 + name_w
        px = self._pill(p, px, y + 1, desk.get("state_label") or state, accent)
        if self.lead_id is not None and desk["agent_id"] == self.lead_id:
            px = self._pill(p, px + 6, y + 1, "★ Trưởng phòng", QColor("#F2C94C"))
        score = self.kpi.get(desk["agent_id"])
        p.setFont(normal)
        p.setPen(QColor(theme.MUTED))
        kpi_text = f"KPI {score}" if score is not None else "KPI —"
        p.drawText(QRectF(rect.right() - 90, y, 76, 20), Qt.AlignRight | Qt.AlignVCenter, kpi_text)
        y += 28

        current = desk.get("current")
        p.setFont(normal)
        if current is None:
            p.setPen(QColor(theme.MUTED))
            label = "Đang rảnh — chưa có việc" if state != "offline" else "Ngoại tuyến"
            p.drawText(QRectF(x, y, w, 18), Qt.AlignLeft | Qt.AlignVCenter, label)
            y += 24
            self._footer(p, x, rect.bottom() - 26, w, desk)
            return
        icon = {"working": "▶", "needs_user": "✋", "waiting": "⏳"}.get(state, "•")
        title = f"{icon} {current.get('type_label')} · {current.get('instruction') or ''}"
        p.setPen(QColor(theme.TEXT))
        p.drawText(QRectF(x, y, w, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   QFontMetrics(normal).elidedText(title, Qt.ElideRight, int(w)))
        y += 24
        # thanh tiến độ
        pct = int(current.get("progress") or 0)
        bar = QRectF(x, y + 3, w - 120, 10)
        theme.paint_progress(p, bar, pct)
        p.setPen(QColor(theme.TEXT))
        p.drawText(QRectF(bar.right() + 8, y, 40, 16), Qt.AlignLeft | Qt.AlignVCenter, f"{pct}%")
        due = _parse_iso(current.get("due_at")) if current.get("due_at") else None
        if due:
            left = int((due - datetime.now().astimezone()).total_seconds() // 60)
            p.setPen(QColor("#FF7A7A") if left < 0 else QColor(theme.MUTED))
            due_txt = f"trễ {-left}p" if left < 0 else f"còn {left // 60}g{left % 60:02d}p"
            p.drawText(QRectF(bar.right() + 46, y, 70, 16), Qt.AlignLeft | Qt.AlignVCenter, due_txt)
        y += 22
        # bước đang làm
        step = current.get("step") or "Muse chưa báo bước — đang chờ báo cáo tiến độ"
        p.setPen(QColor(theme.TEXT))
        p.drawText(QRectF(x, y, w, 18), Qt.AlignLeft | Qt.AlignVCenter,
                   QFontMetrics(normal).elidedText(f"Bước đang làm: {step}", Qt.ElideRight, int(w)))
        y += 22
        # kế hoạch bước
        p.setFont(small)
        plan = TYPE_PLAN.get(current.get("type") or "") or []
        cx = x
        marked = False
        for mark, label in plan:
            if pct >= mark:
                icon, color = "✓", QColor("#7DDC7A")
            elif not marked:
                icon, color = "▶", accent
                marked = True
            else:
                icon, color = "○", QColor(theme.FAINT)
            text = f"{icon} {label.split(',')[0]}"
            tw = QFontMetrics(small).horizontalAdvance(text) + 12
            if cx + tw > x + w:
                break
            p.setPen(color)
            p.drawText(QRectF(cx, y, tw, 16), Qt.AlignLeft | Qt.AlignVCenter, text)
            cx += tw
        y += 22
        # lịch sử bước
        history = self.steps.get(str(current.get("id"))) or []
        p.setPen(QColor(theme.MUTED))
        if history:
            parts = []
            for item in history[-4:]:
                at = _parse_iso(item.get("at"))
                parts.append(f"{at.strftime('%H:%M') if at else ''} {item.get('step')}")
            text = "Lịch sử: " + " · ".join(parts)
        else:
            text = "Lịch sử: chưa có bước nào được báo"
        p.drawText(QRectF(x, y, w, 32), Qt.AlignLeft | Qt.TextWordWrap,
                   QFontMetrics(small).elidedText(text, Qt.ElideRight, int(w * 2 - 20)))
        self._footer(p, x, rect.bottom() - 26, w, desk)

    def _footer(self, p, x, y, w, desk):
        p.setFont(self.font())
        p.setPen(QColor(theme.MUTED))
        parts = [f"Tiếp theo: {desk.get('queue_count', 0)} việc"]
        unread = self.unread.get(desk["agent_id"])
        if unread:
            parts.append(f"💬 {unread} tin chưa đọc")
        parts.append(f"{len(desk.get('profile_ids') or [])} hồ sơ phụ trách")
        p.drawText(QRectF(x, y, w, 18), Qt.AlignLeft | Qt.AlignVCenter, "   ·   ".join(parts))

    def _pill(self, p, x, y, text, color: QColor) -> float:
        font = QFont(self.font())
        font.setPixelSize(11)
        font.setBold(True)
        p.setFont(font)
        tw = QFontMetrics(font).horizontalAdvance(text) + 16
        rect = QRectF(x, y, tw, 18)
        path = QPainterPath()
        path.addRoundedRect(rect, 9, 9)
        bg = QColor(color)
        bg.setAlpha(40)
        p.fillPath(path, bg)
        p.setPen(color)
        p.drawText(rect, Qt.AlignCenter, text)
        return rect.right()


class Office2DView(QScrollArea):
    agent_clicked = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QScrollArea.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.canvas = _Canvas()
        self.canvas.agent_clicked.connect(self.agent_clicked)
        self.setWidget(self.canvas)
        self.setStyleSheet(f"QScrollArea {{ background: {theme.BG}; border: none; }}")

    def set_data(self, desks, steps, kpi_scores, lead_id, unread, selected):
        c = self.canvas
        c.desks = list(desks or [])
        c.steps = steps or {}
        c.kpi = kpi_scores or {}
        c.lead_id = lead_id
        c.unread = unread or {}
        c.selected = selected
        c.relayout()

    def set_selected(self, agent_id):
        self.canvas.selected = agent_id
        self.canvas.update()
