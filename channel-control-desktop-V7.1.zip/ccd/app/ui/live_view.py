"""Widget hiển thị luồng trực tiếp của Chrome + bắt thao tác điều khiển.

LiveViewLabel vẽ ảnh chụp từ CDP (đã scale vừa khung, căn giữa). Khi bật chế
độ "Điều khiển", nó chuyển tiếp thao tác thật sang Chrome qua worker:
- click chuột  -> Input.dispatchMouseEvent (toạ độ quy đổi theo tỉ lệ ảnh)
- lăn chuột    -> mouseWheel
- bàn phím     -> Input.dispatchKeyEvent

Toạ độ phát ra dạng TỈ LỆ (0..1) theo vùng ảnh hiển thị; worker quy đổi sang
toạ độ CSS của trang bằng kích thước layout viewport thật.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QLabel


class LiveViewLabel(QLabel):
    mouse_clicked = Signal(float, float)          # (x_ratio, y_ratio)
    mouse_wheeled = Signal(float, float, int)     # (x_ratio, y_ratio, delta_y)
    key_event = Signal(dict)                      # tham số CDP Input.dispatchKeyEvent

    def __init__(self, parent=None):
        super().__init__(parent)
        self._source: QPixmap | None = None
        self._control = False
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(300)
        self.setStyleSheet(
            "background:#0B0C0A; color:#9BA196;"
            " border:1px solid #23261F; border-radius:10px;"
        )
        self.setFocusPolicy(Qt.StrongFocus)

    # ------------------------------------------------------------------ #
    def set_control_enabled(self, enabled: bool):
        self._control = enabled
        self.setCursor(Qt.PointingHandCursor if enabled else Qt.ArrowCursor)

    def control_enabled(self) -> bool:
        return self._control

    def set_source_pixmap(self, pixmap: QPixmap):
        self._source = pixmap
        self._rescale()

    def clear_frame(self):
        """Xoá khung hình cũ (khi đổi hồ sơ) để hiện lại chữ chờ."""
        self._source = None
        self.clear()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._rescale()

    def _rescale(self):
        if self._source is not None and not self._source.isNull():
            self.setPixmap(
                self._source.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            )

    def _image_rect(self):
        """Hình chữ nhật của ảnh đã scale trong widget (đã căn giữa)."""
        pixmap = self.pixmap()
        if pixmap is None or pixmap.isNull():
            return None
        x = (self.width() - pixmap.width()) // 2
        y = (self.height() - pixmap.height()) // 2
        return x, y, pixmap.width(), pixmap.height()

    def _ratios_at(self, pos) -> tuple[float, float] | None:
        rect = self._image_rect()
        if rect is None:
            return None
        x, y, w, h = rect
        if not (x <= pos.x() < x + w and y <= pos.y() < y + h):
            return None
        return (pos.x() - x) / w, (pos.y() - y) / h

    # ------------------------------------------------------------------ #
    # Thao tác chuột / bàn phím
    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event):
        if self._control and event.button() == Qt.LeftButton:
            ratios = self._ratios_at(event.position().toPoint())
            if ratios is not None:
                self.mouse_clicked.emit(*ratios)
                self.setFocus()
                event.accept()
                return
        super().mousePressEvent(event)

    def wheelEvent(self, event):
        if self._control:
            ratios = self._ratios_at(event.position().toPoint())
            if ratios is not None:
                self.mouse_wheeled.emit(ratios[0], ratios[1], event.angleDelta().y())
                event.accept()
                return
        super().wheelEvent(event)

    def keyPressEvent(self, event):
        if self._control and self._forward_key(event, is_press=True):
            event.accept()
            return
        super().keyPressEvent(event)

    def keyReleaseEvent(self, event):
        if self._control and self._forward_key(event, is_press=False):
            event.accept()
            return
        super().keyReleaseEvent(event)

    def _forward_key(self, event, is_press: bool) -> bool:
        params = qt_key_to_cdp(event, is_press)
        if params is None:
            return False
        self.key_event.emit(params)
        return True


# --------------------------------------------------------------------------- #
# Ánh xạ phím Qt -> CDP
# --------------------------------------------------------------------------- #
_SPECIAL_KEYS = {
    Qt.Key_Return: ("Enter", "Enter", 13),
    Qt.Key_Enter: ("Enter", "Enter", 13),
    Qt.Key_Backspace: ("Backspace", "Backspace", 8),
    Qt.Key_Delete: ("Delete", "Delete", 46),
    Qt.Key_Tab: ("Tab", "Tab", 9),
    Qt.Key_Backtab: ("Tab", "Tab", 9),
    Qt.Key_Escape: ("Escape", "Escape", 27),
    Qt.Key_Space: (" ", "Space", 32),
    Qt.Key_Left: ("ArrowLeft", "ArrowLeft", 37),
    Qt.Key_Up: ("ArrowUp", "ArrowUp", 38),
    Qt.Key_Right: ("ArrowRight", "ArrowRight", 39),
    Qt.Key_Down: ("ArrowDown", "ArrowDown", 40),
    Qt.Key_Home: ("Home", "Home", 36),
    Qt.Key_End: ("End", "End", 35),
    Qt.Key_PageUp: ("PageUp", "PageUp", 33),
    Qt.Key_PageDown: ("PageDown", "PageDown", 34),
    Qt.Key_Shift: ("Shift", "ShiftLeft", 16),
    Qt.Key_Control: ("Control", "ControlLeft", 17),
    Qt.Key_Alt: ("Alt", "AltLeft", 18),
    Qt.Key_Meta: ("Meta", "MetaLeft", 91),
    Qt.Key_CapsLock: ("CapsLock", "CapsLock", 20),
    Qt.Key_Insert: ("Insert", "Insert", 45),
}


def qt_key_to_cdp(event, is_press: bool) -> dict | None:
    """Chuyển QKeyEvent thành tham số Input.dispatchKeyEvent.
    Trả về None cho phím không ánh xạ được (để widget xử lý mặc định)."""
    key = event.key()
    params: dict = {"type": "keyDown" if is_press else "keyUp"}

    modifiers = 0
    mods = event.modifiers()
    if mods & Qt.AltModifier:
        modifiers |= 1
    if mods & Qt.ControlModifier:
        modifiers |= 2
    if mods & Qt.MetaModifier:
        modifiers |= 4
    if mods & Qt.ShiftModifier:
        modifiers |= 8
    if modifiers:
        params["modifiers"] = modifiers

    native_vk = event.nativeVirtualKey()
    if key in _SPECIAL_KEYS:
        name, code, vk = _SPECIAL_KEYS[key]
        params.update({"key": name, "code": code, "windowsVirtualKeyCode": vk})
    elif Qt.Key_F1 <= key <= Qt.Key_F35:
        n = key - Qt.Key_F1 + 1
        if n > 12:
            return None
        params.update({"key": f"F{n}", "code": f"F{n}", "windowsVirtualKeyCode": 111 + n})
    elif Qt.Key_A <= key <= Qt.Key_Z:
        letter = chr(key)
        text = event.text()
        params.update(
            {
                "key": text if text else letter.lower(),
                "code": f"Key{letter}",
                "windowsVirtualKeyCode": key,  # Qt.Key_A..Z trùng mã VK trên Windows
            }
        )
    elif Qt.Key_0 <= key <= Qt.Key_9:
        digit = chr(key)
        params.update(
            {"key": event.text() or digit, "code": f"Digit{digit}", "windowsVirtualKeyCode": key}
        )
    else:
        text = event.text()
        if not text:
            return None
        params.update({"key": text, "code": "", "windowsVirtualKeyCode": native_vk or 0})

    if native_vk:
        params.setdefault("nativeVirtualKeyCode", native_vk)
    # Gửi kèm text ở keyDown để ký tự thật sự được gõ vào ô nhập của trang.
    if is_press and event.text() and len(event.text()) == 1 and event.text().isprintable():
        params["text"] = event.text()
        params["unmodifiedText"] = event.text()
    return params
