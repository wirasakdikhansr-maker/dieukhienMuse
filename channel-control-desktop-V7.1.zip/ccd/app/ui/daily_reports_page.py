"""V6.3 — Tab "📅 Báo cáo ngày": danh sách báo cáo kênh hằng ngày đã tạo,
xem ngay trong app (QTextBrowser), nút tạo ngay + mở thư mục."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QListWidget,
    QPushButton,
    QSplitter,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .. import daily_report
from . import theme


class DailyReportsPage(QWidget):
    def __init__(self, store, settings: dict, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 8, 0, 0)
        head = QHBoxLayout()
        self.info = QLabel("")
        self.info.setObjectName("Muted")
        head.addWidget(self.info, 1)
        make = QPushButton("📊 Tạo báo cáo ngay")
        make.clicked.connect(self.generate_now)
        head.addWidget(make)
        folder = QPushButton("📁 Mở thư mục báo cáo")
        folder.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._dir()))))
        head.addWidget(folder)
        layout.addLayout(head)
        split = QSplitter()
        self.list = QListWidget()
        self.list.setMaximumWidth(260)
        self.list.currentTextChanged.connect(self._show)
        split.addWidget(self.list)
        self.viewer = QTextBrowser()
        self.viewer.setOpenExternalLinks(True)
        split.addWidget(self.viewer)
        split.setSizes([220, 1000])
        layout.addWidget(split, 1)
        self.refresh()

    def _dir(self) -> Path:
        return daily_report.reports_dir(self._store.db_file.parent)

    def refresh(self):
        files = sorted(self._dir().glob("bao-cao-*.html"), reverse=True)
        current = self.list.currentItem().text() if self.list.currentItem() else None
        self.list.blockSignals(True)
        self.list.clear()
        for path in files[:120]:
            self.list.addItem(path.name)
        self.list.blockSignals(False)
        when = self._settings.get("daily_report_time") or "08:00"
        on = self._settings.get("daily_report_enabled", True)
        self.info.setText(
            (f"Tự tạo mỗi ngày lúc {when}" if on else "Đang TẮT tự tạo (Cài đặt → ⚙ Tự vận hành)")
            + f" · {len(files)} báo cáo"
        )
        target = current or (files[0].name if files else None)
        if target:
            matches = self.list.findItems(target, Qt.MatchExactly)
            if matches:
                self.list.setCurrentItem(matches[0])
            elif self.list.count():
                self.list.setCurrentRow(0)

    def _show(self, name: str):
        if not name:
            return
        path = self._dir() / name
        if path.exists():
            self.viewer.setHtml(path.read_text("utf-8"))

    def generate_now(self):
        path = daily_report.generate(self._store, self._settings)
        self.refresh()
        items = self.list.findItems(path.name, Qt.MatchExactly)
        if items:
            self.list.setCurrentItem(items[0])
        return path
