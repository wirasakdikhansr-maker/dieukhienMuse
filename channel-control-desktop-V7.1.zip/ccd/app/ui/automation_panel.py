"""Panel "Tự động" (V3) — quy tắc tự động + công tắc mở app.

Quy tắc lưu trong bảng automation_rules: hành động (Quét kênh / Kiểm tra
kênh / Mở trình duyệt) × hồ sơ đích hoặc tất cả × lịch (hằng ngày lúc
HH:MM hoặc mỗi N giờ) × bật/tắt. Bộ máy AutomationEngine (app/automation)
do cửa sổ chính chạy bằng QTimer 30 giây sẽ tạo lệnh qua đúng đường lệnh
dùng chung — panel này chỉ quản lý quy tắc và hiển thị lần chạy
cuối/kế tiếp.

Kèm công tắc "Tự mở trình duyệt các hồ sơ khi mở app" ghi vào
data/settings.json (khóa auto_open_browsers_on_start).
"""

from __future__ import annotations

from datetime import datetime

from PySide6.QtCore import Qt, QTime
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
)

from .. import automation, automation_health, config
from ..store import COMMAND_TYPE_LABELS, RULE_ACTIONS, Store
from . import theme

# V5.1: công tắc dạng PILL cho checkbox bật/tắt (quy tắc + tự mở
# trình duyệt) — viên thuốc xám khi tắt, xanh #CEFC19 khi bật.
_PILL_SWITCH_QSS = (
    "QCheckBox::indicator { width: 38px; height: 22px;"
    " border-radius: 11px; background: #2C2E34;"
    f" border: 1px solid {theme.BORDER}; }}"
    " QCheckBox::indicator:checked { background: #CEFC19;"
    " border-color: #DBFD5E; }"
    " QCheckBox::indicator:hover { border-color: #3A3D44; }"
    " QCheckBox::indicator:checked:hover { border-color: #CEFC19; }"
)


def pill_switch(checkbox: QCheckBox) -> QCheckBox:
    checkbox.setStyleSheet(_PILL_SWITCH_QSS)
    return checkbox


class AutomationPanel(QWidget):
    def __init__(self, store: Store, settings: dict, notify=None, parent=None):
        super().__init__(parent)
        self._store = store
        self._settings = settings
        self._notify = notify or (lambda _line: None)
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(20, 16, 20, 16)
        root.setSpacing(12)
        root.addWidget(theme.section_header("Tự động"))

        # ---- Công tắc khi mở app ----
        app_card = theme.card_frame()
        app_layout = QVBoxLayout(app_card)
        app_layout.setContentsMargins(16, 14, 16, 14)
        self.auto_open_check = pill_switch(
            QCheckBox("Tự mở trình duyệt các hồ sơ khi mở app")
        )
        self.auto_open_check.setChecked(
            # V5.3 (A7): mặc định MỚI là BẬT khi khoá chưa từng lưu.
            bool(self._settings.get("auto_open_browsers_on_start", False))
        )
        self.auto_open_check.setToolTip(
            "Khi bật: mỗi lần mở app, Chrome của mọi hồ sơ (không bị "
            "tạm dừng) được mở sẵn để phiên đăng nhập luôn ấm."
        )
        self.auto_open_check.toggled.connect(self._on_auto_open_toggled)
        app_layout.addWidget(self.auto_open_check)
        # V5.3 (A6): dòng giải thích dưới công tắc đã BỎ (nội dung
        # chuyển vào tooltip của chính công tắc).
        root.addWidget(app_card)

        # ---- Sức khoẻ vòng tự động (V5.1, plan §2.5) ----
        # Banner tint đỏ khi vòng tự động degraded, IM LẶNG khi
        # khoẻ (cùng dữ liệu automation_health với thanh trạng thái).
        self.health_banner = QFrame()
        self.health_banner.setObjectName("ErrorBanner")
        banner_layout = QHBoxLayout(self.health_banner)
        banner_layout.setContentsMargins(12, 8, 12, 8)
        self.health_banner_label = QLabel("")
        self.health_banner_label.setObjectName("ErrorBannerText")
        self.health_banner_label.setWordWrap(True)
        banner_layout.addWidget(self.health_banner_label)
        self.health_banner.setVisible(False)
        root.addWidget(self.health_banner)

        # ---- Quy tắc dạng THẺ (V5.1, plan §2.5) ----
        root.addWidget(theme.section_header("Quy tắc tự động"))
        self.rules_scroll = QScrollArea()
        self.rules_scroll.setWidgetResizable(True)
        self.rules_scroll.setFrameShape(QFrame.NoFrame)
        self.rules_scroll.setStyleSheet(
            "QScrollArea, QScrollArea > QWidget > QWidget "
            f"{{ background: {theme.BG}; }}"
        )
        self.rules_host = QWidget()
        self.rules_layout = QVBoxLayout(self.rules_host)
        self.rules_layout.setContentsMargins(2, 2, 6, 2)
        self.rules_layout.setSpacing(10)
        self.rules_layout.addStretch(1)
        self.rules_scroll.setWidget(self.rules_host)
        self.rule_cards: list[QFrame] = []
        root.addWidget(self.rules_scroll, 1)

        # ---- Form thêm quy tắc ----
        form = theme.card_frame()
        form_layout = QVBoxLayout(form)
        form_layout.setContentsMargins(16, 14, 16, 14)
        form_layout.setSpacing(10)
        row = QHBoxLayout()
        row.setSpacing(10)

        action_box = QVBoxLayout()
        action_box.addWidget(theme.muted_label("Hành động"))
        self.action_combo = QComboBox()
        for key in RULE_ACTIONS:
            self.action_combo.addItem(COMMAND_TYPE_LABELS[key], key)
        action_box.addWidget(self.action_combo)
        row.addLayout(action_box, 1)

        profile_box = QVBoxLayout()
        profile_box.addWidget(theme.muted_label("Hồ sơ đích"))
        self.profile_combo = QComboBox()
        profile_box.addWidget(self.profile_combo)
        row.addLayout(profile_box, 1)

        kind_box = QVBoxLayout()
        kind_box.addWidget(theme.muted_label("Kiểu lịch"))
        self.kind_combo = QComboBox()
        self.kind_combo.addItem("Hằng ngày lúc", "daily")
        self.kind_combo.addItem("Mỗi N giờ", "interval")
        self.kind_combo.currentIndexChanged.connect(self._sync_kind_fields)
        kind_box.addWidget(self.kind_combo)
        row.addLayout(kind_box, 1)

        time_box = QVBoxLayout()
        time_box.addWidget(theme.muted_label("Giờ (hằng ngày)"))
        self.time_edit = QTimeEdit()
        self.time_edit.setDisplayFormat("HH:mm")
        self.time_edit.setTime(QTime(8, 0))
        time_box.addWidget(self.time_edit)
        row.addLayout(time_box, 1)

        hours_box = QVBoxLayout()
        hours_box.addWidget(theme.muted_label("Số giờ (chu kỳ)"))
        self.hours_spin = QSpinBox()
        self.hours_spin.setRange(1, 168)
        self.hours_spin.setValue(6)
        hours_box.addWidget(self.hours_spin)
        row.addLayout(hours_box, 1)
        form_layout.addLayout(row)

        row2 = QHBoxLayout()
        self.enabled_check = QCheckBox("Bật quy tắc ngay")
        row2.addWidget(self.enabled_check)
        row2.addStretch(1)
        add_button = QPushButton("＋ Thêm quy tắc")
        add_button.setProperty("variant", "primary")
        add_button.clicked.connect(self._on_add_rule)
        row2.addWidget(add_button)
        form_layout.addLayout(row2)
        root.addWidget(form)
        self._sync_kind_fields()

    # ------------------------------------------------------------------ #
    def refresh(self):
        self._refresh_health_banner()
        self._refresh_profiles()
        profiles = {p["id"]: p["label"] for p in self._store.list_profiles()}
        rules = self._store.list_rules()
        # V4.3.2 (F4): vân quy tắc — không đổi thì giữ nguyên bảng
        # (mỗi dòng có widget con, nạp lại là tốn nhất trong các bảng).
        fingerprint = tuple(
            (
                r["id"], bool(r["enabled"]), r["action"], r["profile_id"],
                r["schedule_kind"], r["daily_time"], r["interval_hours"],
                r["last_run_at"], r["next_run_at"],
                profiles.get(r["profile_id"]),
            )
            for r in rules
        )
        if fingerprint == getattr(self, "_rules_fingerprint", None):
            return
        self._rules_fingerprint = fingerprint
        self._fill_rules(rules, profiles)

    def _refresh_health_banner(self):
        try:
            health = automation_health.read_health(self._store)
        except Exception:
            health = None
        if health and health.get("degraded"):
            at = str(health.get("at") or "")[11:16]
            self.health_banner_label.setText(
                f"⚠ Vòng tự động đang lỗi ({health.get('source') or '?'})"
                + (f" lúc {at}" if at else "")
                + f" — {health.get('error') or ''}"
            )
            self.health_banner.setVisible(True)
        else:
            self.health_banner.setVisible(False)

    def _fill_rules(self, rules, profiles):
        # Dọn thẻ cũ đúng chuẩn (hide + setParent(None) +
        # deleteLater) — tránh widget mồ côi vẽ chồng (skill §8).
        while self.rules_layout.count() > 1:
            item = self.rules_layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.hide()
                widget.setParent(None)
                widget.deleteLater()
        self.rule_cards = []
        if not rules:
            empty = QLabel(
                "Chưa có quy tắc nào — tạo ở biểu mẫu bên dưới."
            )
            empty.setObjectName("EmptyState")
            self.rules_layout.insertWidget(0, empty)
            return
        for rule in rules:
            card = self._rule_card(rule, profiles)
            self.rule_cards.append(card)
            self.rules_layout.insertWidget(
                self.rules_layout.count() - 1, card
            )

    def _rule_card(self, rule, profiles) -> QFrame:
        card = theme.card_frame()
        card.rule_id = rule["id"]  # test/chẩn đoán bám theo thẻ
        layout = QHBoxLayout(card)
        layout.setContentsMargins(16, 12, 16, 12)
        layout.setSpacing(12)
        toggle = pill_switch(QCheckBox())
        toggle.setChecked(bool(rule["enabled"]))
        toggle.setToolTip("Bật/tắt quy tắc này")
        toggle.toggled.connect(
            lambda checked, rid=rule["id"]: self._on_rule_toggled(rid, checked)
        )
        layout.addWidget(toggle, 0, Qt.AlignmentFlag.AlignTop)

        texts = QVBoxLayout()
        texts.setSpacing(3)
        title = QLabel(
            COMMAND_TYPE_LABELS.get(rule["action"], rule["action"])
        )
        title.setObjectName("CardTitle")
        texts.addWidget(title)
        target = (
            profiles.get(rule["profile_id"], "Hồ sơ đã xoá")
            if rule["profile_id"]
            else "Tất cả hồ sơ"
        )
        schedule = (
            f"Hằng ngày {rule['daily_time']}"
            if rule["schedule_kind"] == "daily"
            else f"Mỗi {rule['interval_hours']} giờ"
        )
        desc = QLabel(f"{target} · {schedule}")
        desc.setObjectName("Muted12")
        desc.setWordWrap(True)
        texts.addWidget(desc)
        runs = QLabel(
            f"Chạy lần cuối: {_fmt_ts(rule['last_run_at'])} · "
            f"Lần chạy kế: "
            f"{_fmt_ts(rule['next_run_at']) if rule['enabled'] else '— (đang tắt)'}"
        )
        runs.setObjectName("Faint12")
        runs.setWordWrap(True)
        texts.addWidget(runs)
        layout.addLayout(texts, 1)

        buttons = QHBoxLayout()
        buttons.setSpacing(6)
        run_button = QPushButton("▶ Chạy ngay")
        run_button.setProperty("variant", "ghost")
        run_button.setToolTip("Bắn lệnh của quy tắc này ngay bây giờ")
        run_button.clicked.connect(
            lambda _=False, rid=rule["id"]: self._on_run_rule_now(rid)
        )
        buttons.addWidget(run_button)
        edit_button = QPushButton("✎ Sửa")
        edit_button.setProperty("variant", "ghost")
        edit_button.clicked.connect(
            lambda _=False, r=rule: self._on_edit_rule(r)
        )
        buttons.addWidget(edit_button)
        delete_button = QPushButton("🗑 Xoá")
        delete_button.setProperty("variant", "danger")
        delete_button.clicked.connect(
            lambda _=False, rid=rule["id"]: self._on_delete_rule(rid)
        )
        buttons.addWidget(delete_button)
        layout.addLayout(buttons)
        return card

    def _refresh_profiles(self):
        current = self.profile_combo.currentData()
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItem("Tất cả hồ sơ", None)
        for profile in self._store.list_profiles():
            self.profile_combo.addItem(
                f"{profile['label']} — {profile['gmail']}", profile["id"]
            )
        index = self.profile_combo.findData(current)
        if index >= 0:
            self.profile_combo.setCurrentIndex(index)
        self.profile_combo.blockSignals(False)

    # ------------------------------------------------------------------ #
    def _sync_kind_fields(self):
        daily = self.kind_combo.currentData() == "daily"
        self.time_edit.setEnabled(daily)
        self.hours_spin.setEnabled(not daily)

    def _on_auto_open_toggled(self, checked: bool):
        self._settings["auto_open_browsers_on_start"] = bool(checked)
        config.save_settings(self._settings)
        self._notify(
            "Đã "
            + ("BẬT" if checked else "TẮT")
            + " tự mở trình duyệt các hồ sơ khi mở app."
        )

    def _on_rule_toggled(self, rule_id: int, checked: bool):
        rule = self._store.update_rule(rule_id, enabled=checked)
        if rule is not None and checked and not rule["next_run_at"]:
            nxt = automation.compute_next_run(rule, datetime.now().astimezone())
            self._store.update_rule(
                rule_id, next_run_at=nxt.isoformat(timespec="seconds")
            )
        self._notify(
            f"Quy tắc #{rule_id} đã {'bật' if checked else 'tắt'}."
        )
        self.refresh()

    def _on_delete_rule(self, rule_id: int):
        self._store.delete_rule(rule_id)
        self._notify(f"Đã xoá quy tắc #{rule_id}.")
        self.refresh()

    def _on_run_rule_now(self, rule_id: int):
        # V5.1: nút "Chạy ngay" trên thẻ quy tắc — bắn lệnh qua
        # ĐÚNG đường engine dùng cho nhịp tới hạn (run_rule_now).
        engine = automation.AutomationEngine(self._store, log=self._notify)
        created = engine.run_rule_now(rule_id)
        self._notify(
            f"Quy tắc #{rule_id}: đã tạo {len(created)} lệnh ngay."
            if created
            else f"Quy tắc #{rule_id}: không tạo lệnh nào "
                 "(hồ sơ đích đang tạm dừng hoặc đã xoá)."
        )
        self.refresh()

    def _on_edit_rule(self, rule: dict):
        dialog = RuleEditDialog(self._store, rule, parent=self)
        if not dialog.exec():
            return
        values = dialog.values()
        updated = self._store.update_rule(rule["id"], **values)
        if updated is not None and updated["enabled"]:
            nxt = automation.compute_next_run(
                updated, datetime.now().astimezone()
            )
            self._store.update_rule(
                rule["id"], next_run_at=nxt.isoformat(timespec="seconds")
            )
        self._notify(f"Đã sửa quy tắc #{rule['id']}.")
        self.refresh()

    def _on_add_rule(self):
        kind = self.kind_combo.currentData()
        rule = self._store.add_rule(
            self.action_combo.currentData(),
            profile_id=self.profile_combo.currentData(),
            schedule_kind=kind,
            daily_time=self.time_edit.time().toString("HH:mm"),
            interval_hours=self.hours_spin.value(),
            enabled=self.enabled_check.isChecked(),
        )
        if rule["enabled"]:
            nxt = automation.compute_next_run(rule, datetime.now().astimezone())
            self._store.update_rule(
                rule["id"], next_run_at=nxt.isoformat(timespec="seconds")
            )
        self._notify(
            f"Đã thêm quy tắc #{rule['id']}: {COMMAND_TYPE_LABELS[rule['action']]} "
            f"({'hằng ngày ' + rule['daily_time'] if kind == 'daily' else 'mỗi ' + str(rule['interval_hours']) + ' giờ'})"
            f"{' — đang bật' if rule['enabled'] else ' — đang tắt'}."
        )
        self.refresh()


class RuleEditDialog(QDialog):
    """Sửa một quy tắc tự động (V5.1) — cùng các trường với biểu
    mẫu thêm quy tắc; nền panel + tiêu đề đậm theo plan §3."""

    def __init__(self, store: Store, rule: dict, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Sửa quy tắc #{rule['id']}")
        self._store = store
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 16, 20, 16)
        layout.setSpacing(10)
        title = QLabel(f"Sửa quy tắc #{rule['id']}")
        title.setObjectName("DialogTitle")
        layout.addWidget(title)

        layout.addWidget(theme.muted_label("Hành động"))
        self.action_combo = QComboBox()
        for key in RULE_ACTIONS:
            self.action_combo.addItem(COMMAND_TYPE_LABELS[key], key)
        index = self.action_combo.findData(rule["action"])
        if index >= 0:
            self.action_combo.setCurrentIndex(index)
        layout.addWidget(self.action_combo)

        layout.addWidget(theme.muted_label("Hồ sơ đích"))
        self.profile_combo = QComboBox()
        self.profile_combo.addItem("Tất cả hồ sơ", None)
        for profile in store.list_profiles():
            self.profile_combo.addItem(
                f"{profile['label']} — {profile['gmail']}", profile["id"]
            )
        index = self.profile_combo.findData(rule.get("profile_id"))
        if index >= 0:
            self.profile_combo.setCurrentIndex(index)
        layout.addWidget(self.profile_combo)

        layout.addWidget(theme.muted_label("Kiểu lịch"))
        self.kind_combo = QComboBox()
        self.kind_combo.addItem("Hằng ngày lúc", "daily")
        self.kind_combo.addItem("Mỗi N giờ", "interval")
        index = self.kind_combo.findData(rule["schedule_kind"])
        if index >= 0:
            self.kind_combo.setCurrentIndex(index)
        self.kind_combo.currentIndexChanged.connect(self._sync_kind_fields)
        layout.addWidget(self.kind_combo)

        layout.addWidget(theme.muted_label("Giờ (hằng ngày)"))
        self.time_edit = QTimeEdit()
        self.time_edit.setDisplayFormat("HH:mm")
        parsed = QTime.fromString(rule.get("daily_time") or "08:00", "HH:mm")
        self.time_edit.setTime(parsed if parsed.isValid() else QTime(8, 0))
        layout.addWidget(self.time_edit)

        layout.addWidget(theme.muted_label("Số giờ (chu kỳ)"))
        self.hours_spin = QSpinBox()
        self.hours_spin.setRange(1, 168)
        self.hours_spin.setValue(int(rule.get("interval_hours") or 6))
        layout.addWidget(self.hours_spin)

        self.enabled_check = pill_switch(QCheckBox("Đang bật"))
        self.enabled_check.setChecked(bool(rule["enabled"]))
        layout.addWidget(self.enabled_check)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Huỷ")
        cancel.clicked.connect(self.reject)
        buttons.addWidget(cancel)
        save = QPushButton("Lưu")
        save.setProperty("variant", "primary")
        save.clicked.connect(self.accept)
        buttons.addWidget(save)
        layout.addLayout(buttons)
        self._sync_kind_fields()

    def _sync_kind_fields(self):
        daily = self.kind_combo.currentData() == "daily"
        self.time_edit.setEnabled(daily)
        self.hours_spin.setEnabled(not daily)

    def values(self) -> dict:
        return {
            "action": self.action_combo.currentData(),
            "profile_id": self.profile_combo.currentData(),
            "schedule_kind": self.kind_combo.currentData(),
            "daily_time": self.time_edit.time().toString("HH:mm"),
            "interval_hours": self.hours_spin.value(),
            "enabled": self.enabled_check.isChecked(),
        }


def _fmt_ts(value) -> str:
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value)).strftime("%d/%m %H:%M")
    except ValueError:
        return str(value)
