"""V7.0.1 — NÚT TAM GIÁC ẨN/HIỆN cho MỌI vùng chia (splitter) trong app.

Mỗi thanh chia giữa hai panel có một nút nhỏ ◀ ▶ / ▲ ▼ nằm giữa thanh:
bấm → thu gọn panel NHỎ HƠN về 0 để mở rộng panel còn lại; bấm lần nữa →
trả lại đúng bề rộng cũ. Trạng thái thu gọn được nhớ theo tên splitter
(settings["collapsed_panes"]) và áp lại lần mở app sau.

``install(root, settings)`` gọi lại nhiều lần vô hại (splitter đã gắn thì bỏ qua),
nên gọi mỗi khi đổi tab để bắt cả các splitter dựng muộn.
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, Qt, QTimer
from PySide6.QtWidgets import QSplitter, QToolButton, QWidget

BUTTON_LONG, BUTTON_SHORT = 34, 14
_ARROWS = {  # (orientation, side bị thu) → mũi tên khi đang MỞ / đang THU
    (Qt.Orientation.Horizontal, "before"): ("◀", "▶"),
    (Qt.Orientation.Horizontal, "after"): ("▶", "◀"),
    (Qt.Orientation.Vertical, "before"): ("▲", "▼"),
    (Qt.Orientation.Vertical, "after"): ("▼", "▲"),
}
_QSS = ("QToolButton { background: rgba(28,30,35,0.92); color: #CEFC19; border: 1px solid #3A3D44;"
        " border-radius: 6px; font-size: 10px; padding: 0; }"
        "QToolButton:hover { background: rgba(206,252,25,0.22); border-color: #CEFC19; }")


def _key(splitter: QSplitter, index: int) -> str:
    name = splitter.objectName() or splitter.property("ccd_collapse_name") or ""
    if not name:
        chain, w = [], splitter
        while w is not None and len(chain) < 6:
            chain.append(type(w).__name__)
            w = w.parentWidget()
        name = "/".join(reversed(chain))
    return f"{name}#{index}"


class _Toggle(QObject):
    def __init__(self, splitter: QSplitter, index: int, settings: dict | None):
        super().__init__(splitter)
        self.splitter = splitter
        self.index = index  # handle giữa widget(index-1) và widget(index)
        self.settings = settings
        self.saved: list[int] | None = None
        self.side: str | None = None
        # Nút KHÔNG được là con trực tiếp của QSplitter (splitter tự biến con
        # thành panel mới) → gắn vào widget cha rồi đặt đè lên đúng thanh chia.
        host = splitter.parentWidget()
        while isinstance(host, QSplitter):
            host = host.parentWidget()
        host = host or splitter.window()
        self.button = QToolButton(host)
        self.button.setObjectName("CollapseToggle")
        self.button.setStyleSheet(_QSS)
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.setToolTip("Ẩn/hiện panel để mở rộng giao diện")
        self.button.clicked.connect(self.toggle)
        splitter.installEventFilter(self)
        try:
            splitter.handle(index).installEventFilter(self)  # thanh chia di chuyển (cả khi setSizes)
        except Exception:
            pass
        splitter.splitterMoved.connect(lambda *_a: self.place())
        QTimer.singleShot(0, self.place)
        QTimer.singleShot(50, self._restore)

    # -- trạng thái
    def collapsed(self) -> bool:
        return self.side is not None

    def _restore(self):
        if self.settings and _key(self.splitter, self.index) in (self.settings.get("collapsed_panes") or {}):
            side = self.settings["collapsed_panes"][_key(self.splitter, self.index)]
            self.collapse(side, remember=False)

    def _remember(self):
        if self.settings is None:
            return
        panes = dict(self.settings.get("collapsed_panes") or {})
        key = _key(self.splitter, self.index)
        if self.side:
            panes[key] = self.side
        else:
            panes.pop(key, None)
        self.settings["collapsed_panes"] = panes

    def toggle(self):
        if self.collapsed():
            self.expand()
        else:
            sizes = self.splitter.sizes()
            a, b = sizes[self.index - 1], sizes[self.index]
            self.collapse("before" if a <= b else "after")

    def collapse(self, side: str, remember: bool = True):
        sp = self.splitter
        if sp.count() <= self.index:
            return
        sizes = sp.sizes()
        if sum(sizes) <= 0:
            return
        self.saved = list(sizes)
        victim = self.index - 1 if side == "before" else self.index
        other = self.index if side == "before" else self.index - 1
        sizes[other] += sizes[victim]
        sizes[victim] = 0
        sp.setCollapsible(victim, True)
        widget = sp.widget(victim)
        self._min = widget.minimumSize()
        widget.setMinimumSize(0, 0)
        sp.setSizes(sizes)
        self.side = side
        if remember:
            self._remember()
        self.place()

    def expand(self):
        sp = self.splitter
        victim = self.index - 1 if self.side == "before" else self.index
        widget = sp.widget(victim)
        if getattr(self, "_min", None) is not None:
            widget.setMinimumSize(self._min)
        sizes = self.saved
        if not sizes or len(sizes) != sp.count() or sizes[victim] <= 0:
            total = sum(sp.sizes())
            sizes = sp.sizes()
            sizes[victim] = max(260, total // 4)
            sizes[self.index if self.side == "before" else self.index - 1] -= sizes[victim]
        sp.setSizes(sizes)
        self.side = None
        self._remember()
        self.place()

    # -- vị trí nút
    def place(self):
        sp = self.splitter
        if sp.count() <= self.index:
            self.button.hide()
            return
        handle = sp.handle(self.index)
        if self.side is None and (sp.widget(self.index - 1).isHidden() or sp.widget(self.index).isHidden()):
            self.button.hide()  # panel bên cạnh đang ẩn hẳn (vd "Ẩn panel") → không cần nút
            return
        host = self.button.parentWidget()
        if not sp.isVisible() or host is None:
            self.button.hide()
            return
        from PySide6.QtCore import QRect

        top_left = handle.mapTo(host, handle.rect().topLeft())
        geo = QRect(top_left, handle.size())
        horizontal = sp.orientation() == Qt.Orientation.Horizontal
        side = self.side
        if side is None:
            sizes = sp.sizes()
            side = "before" if sizes[self.index - 1] <= sizes[self.index] else "after"
            arrow = _ARROWS[(sp.orientation(), side)][0]
        else:
            arrow = _ARROWS[(sp.orientation(), side)][1]
        self.button.setText(arrow)
        if horizontal:
            self.button.setFixedSize(BUTTON_SHORT, BUTTON_LONG)
            x = geo.center().x() - BUTTON_SHORT // 2
            y = max(4, geo.center().y() - BUTTON_LONG // 2)
        else:
            self.button.setFixedSize(BUTTON_LONG, BUTTON_SHORT)
            x = max(4, geo.center().x() - BUTTON_LONG // 2)
            y = geo.center().y() - BUTTON_SHORT // 2
        self.button.move(int(x), int(y))
        self.button.show()
        self.button.raise_()

    def eventFilter(self, obj, event):
        if event.type() in (QEvent.Type.Resize, QEvent.Type.Show, QEvent.Type.Hide, QEvent.Type.Move,
                            QEvent.Type.LayoutRequest):
            QTimer.singleShot(0, self.place)
        return False


def install(root: QWidget, settings: dict | None = None) -> int:
    """Gắn nút tam giác cho mọi QSplitter ≥ 2 panel dưới ``root``. Trả số nút mới."""
    added = 0
    for splitter in root.findChildren(QSplitter):
        if splitter.property("ccd_collapse") or splitter.count() < 2:
            continue
        if splitter.property("ccd_no_collapse"):
            continue
        splitter.setProperty("ccd_collapse", True)
        splitter.toggles = []
        for index in range(1, splitter.count()):
            splitter.toggles.append(_Toggle(splitter, index, settings))
            added += 1
    return added
