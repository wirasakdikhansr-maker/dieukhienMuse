"""Zoom trình duyệt nhúng theo hồ sơ (V4.3 — G5).

Yêu cầu của người dùng: Muse điều khiển trình duyệt NHÚNG trong app
(không phải tab web muse.ai hay văng đăng nhập) — và trình duyệt khi
nhúng vào app phải TỰ zoom 75% để vừa khung.

Cơ chế: Chrome của mỗi hồ sơ nghe CDP ở cổng tất định; áp tỉ lệ trang
bằng lệnh CDP ``Emulation.setPageScaleFactor`` lên target trang của
hồ sơ. Việc áp lại sau mỗi lần điều hướng do cửa sổ chính đảm nhiệm
(nó theo dõi URL trang hiện tại của hồ sơ đang xem — URL đổi là áp
lại). Module này giữ phần THUẦN + hàm áp scale qua một CDP client bất
kỳ (kiểm thử bằng client giả lập, không cần Chrome thật).

Mức zoom lưu trong settings khoá ``browser_zoom_pct``: dict
slug → phần trăm (50–150). Thiếu slug = mặc định 75.
"""

from __future__ import annotations

DEFAULT_ZOOM_PCT = 75
MIN_ZOOM_PCT = 50
MAX_ZOOM_PCT = 150
SETTINGS_KEY = "browser_zoom_pct"


def clamp_zoom_pct(value) -> int:
    """Ép một giá trị bất kỳ về khoảng zoom hợp lệ (sai kiểu → mặc định)."""
    try:
        pct = int(round(float(value)))
    except (TypeError, ValueError):
        return DEFAULT_ZOOM_PCT
    return max(MIN_ZOOM_PCT, min(MAX_ZOOM_PCT, pct))


def get_zoom_pct(settings: dict | None, slug: str | None) -> int:
    """% zoom của một hồ sơ từ settings (mặc định 75 khi chưa đặt)."""
    if not settings or not slug:
        return DEFAULT_ZOOM_PCT
    table = settings.get(SETTINGS_KEY)
    if not isinstance(table, dict):
        return DEFAULT_ZOOM_PCT
    if slug not in table:
        return DEFAULT_ZOOM_PCT
    return clamp_zoom_pct(table.get(slug))


def set_zoom_pct(settings: dict, slug: str, pct) -> int:
    """Ghi % zoom cho một hồ sơ vào settings (tại chỗ). Trả % đã kẹp."""
    value = clamp_zoom_pct(pct)
    table = settings.get(SETTINGS_KEY)
    if not isinstance(table, dict):
        table = {}
        settings[SETTINGS_KEY] = table
    table[slug] = value
    return value


def page_scale_factor(pct) -> float:
    """% → hệ số scale cho Emulation.setPageScaleFactor (75 → 0.75)."""
    return clamp_zoom_pct(pct) / 100.0


def apply_page_scale(client, pct) -> float:
    """Áp scale lên một CDP client đã nối trang. Trả hệ số đã áp.

    ``client`` chỉ cần có ``call(method, params)`` đúng giao diện
    ``app.cdp.CDPClient`` — kiểm thử dùng client giả lập ghi lại lời
    gọi. Lỗi CDP để nguyên cho nơi gọi xử lý (nơi gọi coi zoom là
    việc phụ — hỏng thì ghi nhận, không làm hỏng luồng chính)."""
    factor = page_scale_factor(pct)
    client.call("Emulation.setPageScaleFactor", {"pageScaleFactor": factor})
    return factor


def apply_zoom_for_profile(manager, profile: dict, pct) -> bool:
    """Nối trang Chrome của hồ sơ qua manager và áp zoom. True = đã áp.

    Mọi lỗi (Chrome chưa chạy, CDP rớt…) → False, KHÔNG ném ra ngoài:
    zoom là lớp trang trí trên luồng nhúng, không được phép chặn việc
    chính. Nơi gọi muốn biết lý do thì tự kiểm tra trạng thái Chrome."""
    client = None
    try:
        client = manager.connect_page(profile)
        apply_page_scale(client, pct)
        return True
    except Exception:
        return False
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass
