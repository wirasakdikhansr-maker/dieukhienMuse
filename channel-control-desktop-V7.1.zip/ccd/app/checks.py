"""Kiểm tra sức khoẻ hồ sơ/kênh (V3 — mục "Kiểm tra").

Mỗi lượt kiểm tra một hồ sơ cho ra một danh sách mục kiểm (checklist):

- ``chrome``:    Chrome của hồ sơ có đang chạy + cổng debug có mở không.
- ``cdp``:       CDP có nối được không (gọi /json/version + evaluate nhẹ).
- ``login``:     Đã đăng nhập Google/YouTube chưa (probe bằng phiên trang,
                 dùng lại CHECK_LOGIN_JS của scanner).
- ``channels``:  Kênh có truy cập/đọc được không — suy từ dữ liệu kênh trong
                 kho (đã quét được ít nhất một kênh).
- ``last_scan``: Số liệu kênh cập nhật lần cuối khi nào (last_scan_at).
- ``scheduled``: Có video nào đang ở trạng thái Scheduled không (đọc từ
                 bảng videos trong kho — hiện chưa có luồng nào ghi video
                 theo từng video, nên thường là "chưa có dữ liệu").

Trạng thái mỗi mục: ``ok`` (✓) / ``fail`` (✗) / ``na`` (–, không áp dụng /
chưa đủ điều kiện kiểm). Hàm ``build_check_items`` thuần dữ liệu (nhận
probes đã thu thập) để kiểm thử không cần Chrome; ``run_profile_checks``
làm phần thu thập probes thật qua CDP rồi lưu kết quả vào Store.
"""

from __future__ import annotations

from datetime import datetime

from . import cdp
from .chrome_manager import ChromeManager
from .store import Store

STATUS_OK = "ok"
STATUS_FAIL = "fail"
STATUS_NA = "na"


# --------------------------------------------------------------------------- #
# Thuần dữ liệu: định hình kết quả từ probes
# --------------------------------------------------------------------------- #
def _fmt_ts(iso_value) -> str:
    if not iso_value:
        return ""
    try:
        date_part, time_part = str(iso_value).split("T", 1)
        year, month, day = date_part.split("-")
        return f"{day}/{month}/{year} {time_part[:5]}"
    except Exception:
        return str(iso_value)


def _scan_age_hours(last_scan_at: str | None, now: datetime | None = None) -> float | None:
    if not last_scan_at:
        return None
    try:
        ts = datetime.fromisoformat(str(last_scan_at))
    except ValueError:
        return None
    now = now or datetime.now().astimezone()
    if ts.tzinfo is None:
        ts = ts.astimezone()
    return (now - ts).total_seconds() / 3600.0


def build_check_items(probes: dict, now: datetime | None = None) -> list[dict]:
    """Định hình checklist từ probes đã thu thập. probes gồm:

    - chrome_running: bool — cổng debug của hồ sơ có mở không.
    - cdp_ok: bool | None — CDP trả lời được (None = chưa thử/không áp dụng).
    - logged_in: bool | None — phiên YouTube đã đăng nhập (None = chưa rõ).
    - channels: list[dict] — kênh đang có trong kho của hồ sơ.
    - last_scan_at: str | None — mốc quét gần nhất của hồ sơ.
    - scheduled_videos: list[dict] — video trạng thái 'scheduled' trong kho.
    - videos_known: bool — kho có BẤT KỲ bản ghi video nào của hồ sơ không
      (False -> mục scheduled chỉ là "chưa có dữ liệu", không kết luận).
    """
    chrome_running = bool(probes.get("chrome_running"))
    cdp_ok = probes.get("cdp_ok")
    ws_handshake = probes.get("ws_handshake")
    ws_error = probes.get("ws_error")
    logged_in = probes.get("logged_in")
    channels = probes.get("channels") or []
    last_scan_at = probes.get("last_scan_at")
    scheduled = probes.get("scheduled_videos") or []
    videos_known = bool(probes.get("videos_known"))

    items: list[dict] = []

    items.append(
        {
            "key": "chrome",
            "label": "Chrome của hồ sơ đang chạy",
            "status": STATUS_OK if chrome_running else STATUS_FAIL,
            "detail": "Cổng debug đang mở."
            if chrome_running
            else "Chrome chưa chạy (hoặc mở mà không bật cổng debug).",
        }
    )

    if not chrome_running:
        cdp_status, cdp_detail = STATUS_NA, "Bỏ qua — Chrome chưa chạy."
    elif cdp_ok is None:
        cdp_status, cdp_detail = STATUS_NA, "Chưa thử kết nối CDP."
    elif cdp_ok:
        cdp_status, cdp_detail = STATUS_OK, "CDP phản hồi bình thường."
    else:
        cdp_status, cdp_detail = STATUS_FAIL, "Cổng mở nhưng CDP không phản hồi."
    items.append(
        {"key": "cdp", "label": "Kết nối CDP tới Chrome", "status": cdp_status, "detail": cdp_detail}
    )

    # V3.1: bắt tay WebSocket CDP thật (HTTP /json/version mở KHÔNG có
    # nghĩa là điều khiển được — Chrome thiếu cờ --remote-allow-origins
    # vẫn trả version qua HTTP nhưng từ chối WebSocket với lỗi 403).
    # Chỉ hiện mục này khi probe có chạy (khoá ws_handshake tồn tại).
    if ws_handshake is not None or "ws_handshake" in probes:
        if not chrome_running:
            hs_status, hs_detail = STATUS_NA, "Bỏ qua — Chrome chưa chạy."
        elif ws_handshake:
            hs_status, hs_detail = STATUS_OK, "Bắt tay WebSocket CDP thành công — điều khiển được Chrome."
        elif ws_handshake is None:
            hs_status, hs_detail = STATUS_NA, "Chưa thử bắt tay WebSocket CDP."
        else:
            from .cdp import classify_ws_error

            friendly = classify_ws_error(ws_error or "")
            hs_status = STATUS_FAIL
            hs_detail = friendly or (
                "Không bắt tay được WebSocket CDP"
                + (f": {str(ws_error)[:160]}" if ws_error else ".")
            )
        items.append(
            {
                "key": "handshake",
                "label": "Bắt tay WebSocket CDP (điều khiển)",
                "status": hs_status,
                "detail": hs_detail,
            }
        )

    if not chrome_running or cdp_ok is not True:
        login_status, login_detail = STATUS_NA, "Bỏ qua — chưa nối được CDP."
    elif logged_in is None:
        login_status, login_detail = STATUS_NA, "Chưa đọc được trạng thái đăng nhập."
    elif logged_in:
        login_status, login_detail = STATUS_OK, "Đã đăng nhập Google/YouTube."
    else:
        login_status, login_detail = STATUS_FAIL, "Chưa đăng nhập — cần đăng nhập trong cửa sổ Chrome của hồ sơ."
    items.append(
        {
            "key": "login",
            "label": "Đã đăng nhập Google/YouTube",
            "status": login_status,
            "detail": login_detail,
        }
    )

    if channels:
        names = ", ".join((ch.get("name") or ch.get("channel_id") or "?") for ch in channels[:3])
        extra = f" (+{len(channels) - 3} kênh nữa)" if len(channels) > 3 else ""
        items.append(
            {
                "key": "channels",
                "label": "Kênh truy cập/đọc được",
                "status": STATUS_OK,
                "detail": f"{len(channels)} kênh trong kho: {names}{extra}.",
            }
        )
    elif last_scan_at:
        items.append(
            {
                "key": "channels",
                "label": "Kênh truy cập/đọc được",
                "status": STATUS_FAIL,
                "detail": "Đã quét trước đây nhưng kho không có kênh nào — phiên có thể đã mất.",
            }
        )
    else:
        items.append(
            {
                "key": "channels",
                "label": "Kênh truy cập/đọc được",
                "status": STATUS_NA,
                "detail": "Chưa có dữ liệu kênh — hãy chạy Quét kênh trước.",
            }
        )

    age = _scan_age_hours(last_scan_at, now)
    if last_scan_at is None:
        items.append(
            {
                "key": "last_scan",
                "label": "Số liệu kênh cập nhật lần cuối",
                "status": STATUS_NA,
                "detail": "Chưa từng quét kênh cho hồ sơ này.",
            }
        )
    else:
        fresh = age is not None and age <= 24
        items.append(
            {
                "key": "last_scan",
                "label": "Số liệu kênh cập nhật lần cuối",
                "status": STATUS_OK if fresh else STATUS_FAIL,
                "detail": f"Lần quét cuối: {_fmt_ts(last_scan_at)}"
                + ("." if fresh else " — đã quá 24 giờ, nên quét lại."),
            }
        )

    if scheduled:
        items.append(
            {
                "key": "scheduled",
                "label": "Video đang Scheduled",
                "status": STATUS_OK,
                "detail": f"{len(scheduled)} video đang hẹn giờ công khai trong kho.",
            }
        )
    elif videos_known:
        items.append(
            {
                "key": "scheduled",
                "label": "Video đang Scheduled",
                "status": STATUS_OK,
                "detail": "Không có video nào đang Scheduled.",
            }
        )
    else:
        items.append(
            {
                "key": "scheduled",
                "label": "Video đang Scheduled",
                "status": STATUS_NA,
                "detail": "Kho chưa có dữ liệu từng video — chưa kết luận được.",
            }
        )

    return items


def summarize_items(items: list[dict]) -> str:
    ok = sum(1 for i in items if i["status"] == STATUS_OK)
    fail = sum(1 for i in items if i["status"] == STATUS_FAIL)
    na = sum(1 for i in items if i["status"] == STATUS_NA)
    return f"{ok} đạt, {fail} lỗi, {na} chưa rõ (tổng {len(items)} mục)"


# --------------------------------------------------------------------------- #
# Thu thập probes thật qua CDP
# --------------------------------------------------------------------------- #
def probe_login(manager: ChromeManager, profile: dict) -> bool | None:
    """Đọc trạng thái đăng nhập YouTube của hồ sơ qua CDP.
    Trả None nếu không đọc được (trang không phải YouTube, CDP lỗi...)."""
    from . import scanner  # import lười: scanner không import checks, không vòng lặp

    client = None
    try:
        client = manager.connect_page(profile)
        client.navigate("https://www.youtube.com/")
        scanner._wait_ready(client)
        info = client.evaluate(scanner.CHECK_LOGIN_JS) or {}
        href = info.get("href") or ""
        if "accounts.google.com" in href:
            return False
        return bool(info.get("loggedIn"))
    except Exception:
        return None
    finally:
        if client is not None:
            client.close()


def probe_ws_handshake(manager: ChromeManager, profile: dict) -> tuple[bool | None, str | None]:
    """Thử bắt tay WebSocket CDP thật: mở kết nối tới một tab và chạy một
    lệnh vô hại. Trả (True, None) nếu thông; (False, lỗi-gốc) nếu bị từ
    chối (điển hình 403 khi Chrome chạy thiếu --remote-allow-origins);
    (None, None) nếu không thử được."""
    client = None
    try:
        client = manager.connect_page(profile)
        client.evaluate("1")
        return True, None
    except Exception as exc:
        return False, str(exc)
    finally:
        if client is not None:
            client.close()


def collect_probes(store: Store, profile: dict, manager: ChromeManager) -> dict:
    """Thu thập probes cho một hồ sơ (IO thật: cổng debug, CDP, kho dữ liệu)."""
    chrome_running = False
    try:
        chrome_running = bool(manager.is_running(profile))
    except Exception:
        chrome_running = False

    cdp_ok: bool | None = None
    if chrome_running:
        try:
            cdp.http_json(profile["port"], "/json/version", timeout=2.0)
            cdp_ok = True
        except Exception:
            cdp_ok = False

    # Bắt tay WebSocket thật (V3.1) — chỉ thử khi HTTP version đã trả lời.
    ws_handshake: bool | None = None
    ws_error: str | None = None
    if chrome_running and cdp_ok:
        ws_handshake, ws_error = probe_ws_handshake(manager, profile)

    logged_in: bool | None = None
    if chrome_running and cdp_ok:
        logged_in = probe_login(manager, profile)

    profile_id = profile["id"]
    all_videos = store.list_videos(profile_id)
    return {
        "chrome_running": chrome_running,
        "cdp_ok": cdp_ok,
        "ws_handshake": ws_handshake,
        "ws_error": ws_error,
        "logged_in": logged_in,
        "channels": store.list_channels(profile_id),
        "last_scan_at": profile.get("last_scan_at"),
        "scheduled_videos": [v for v in all_videos if v.get("status") == "scheduled"],
        "videos_known": bool(all_videos),
    }


def run_profile_checks(store: Store, profile: dict, manager: ChromeManager) -> dict:
    """Chạy kiểm tra đầy đủ cho một hồ sơ: thu probes, định hình, lưu kết
    quả vào kho và ghi nhật ký tóm tắt. Trả về dict kết quả đã lưu."""
    probes = collect_probes(store, profile, manager)
    items = build_check_items(probes)
    summary = summarize_items(items)
    saved = store.save_check(profile["id"], items, summary)
    store.append_journal(
        f"Kiểm tra hồ sơ '{profile['label']}': {summary}.", profile["id"]
    )
    return saved
