"""Tự động hoá theo lịch (V3 — mục "Tự động").

Hai tầng tách bạch:

- Logic lịch THUẦN (không Qt, không IO): ``next_daily_run``,
  ``next_interval_run``, ``compute_next_run``, ``is_due`` — kiểm thử độc lập.
- ``AutomationEngine``: mỗi nhịp tick (UI gọi mỗi 30 giây bằng QTimer),
  engine rà các quy tắc đang BẬT trong kho; quy tắc nào tới hạn thì
  engine TẠO LỆNH vào đúng bảng commands dùng chung (source='auto') để
  CommandRunner của UI thực thi bằng cùng đường chạy như lệnh tạo tay,
  đồng thời cập nhật last_run_at / next_run_at và (qua callback) ghi
  nhật ký tiền tố "[Tự động]".

Quy tắc nhắm một hồ sơ cụ thể hoặc TẤT CẢ hồ sơ (profile_id = None);
hồ sơ đang tạm dừng luôn bị bỏ qua khi bắn lệnh.
"""

from __future__ import annotations

from datetime import datetime, time as dtime, timedelta

from .store import Store

AUTOMATION_TAG = "[Tự động]"


# --------------------------------------------------------------------------- #
# Logic lịch thuần
# --------------------------------------------------------------------------- #
def parse_daily_time(value: str | None) -> dtime:
    """'HH:MM' -> datetime.time; sai định dạng -> 08:00."""
    try:
        hour, minute = str(value or "").split(":", 1)
        return dtime(hour=int(hour) % 24, minute=int(minute) % 60)
    except (TypeError, ValueError):
        return dtime(hour=8, minute=0)


def next_daily_run(daily_time: str | None, after: datetime) -> datetime:
    """Lần chạy hằng-ngày TIẾP THEO tính từ mốc ``after`` (nghiêm ngặt sau)."""
    target = parse_daily_time(daily_time)
    candidate = datetime.combine(after.date(), target, tzinfo=after.tzinfo)
    if candidate <= after:
        candidate += timedelta(days=1)
    return candidate


def next_interval_run(interval_hours: float | None, after: datetime) -> datetime:
    """Lần chạy theo chu kỳ TIẾP THEO: ``after`` + N giờ (N tối thiểu 0.25)."""
    hours = float(interval_hours) if interval_hours else 6.0
    hours = max(0.25, hours)
    return after + timedelta(hours=hours)


def _parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


def compute_next_run(rule: dict, now: datetime) -> datetime:
    """Tính next_run cho một quy tắc tại thời điểm ``now``:
    - Chưa từng chạy (không có last_run_at): daily -> mốc hằng ngày kế tiếp;
      interval -> ``now`` (tới hạn ngay khi bật) nếu chưa có next_run_at,
      ngược lại giữ next_run_at đã lưu.
    - Đã chạy: daily -> mốc kế tiếp sau ``now``; interval -> last_run + N giờ.
    """
    saved_next = _parse_iso(rule.get("next_run_at"))
    last_run = _parse_iso(rule.get("last_run_at"))
    if rule.get("schedule_kind") == "interval":
        if last_run is not None:
            return next_interval_run(rule.get("interval_hours"), last_run)
        return saved_next if saved_next is not None else now
    return next_daily_run(rule.get("daily_time"), now)


def is_due(rule: dict, now: datetime) -> bool:
    """Quy tắc tới hạn chưa: đang bật VÀ next_run (đã lưu hoặc tính tươi) <= now."""
    if not rule.get("enabled"):
        return False
    next_run = _parse_iso(rule.get("next_run_at")) or compute_next_run(rule, now)
    return next_run <= now


# --------------------------------------------------------------------------- #
# Engine — nối kho dữ liệu với hàng đợi lệnh
# --------------------------------------------------------------------------- #
class AutomationEngine:
    """Rà quy tắc tới hạn và bắn lệnh. ``log`` (tuỳ chọn) nhận các dòng
    nhật ký đã có tiền tố [Tự động] để UI hiển thị ngay."""

    def __init__(self, store: Store, log=None):
        self._store = store
        self._log = log or (lambda msg: None)

    def ensure_next_runs(self, now: datetime | None = None) -> None:
        """Điền next_run_at cho các quy tắc đang bật mà chưa có — để UI
        hiển thị "lần chạy kế" ngay cả trước nhịp tick đầu tiên."""
        now = now or datetime.now().astimezone()
        for rule in self._store.list_rules():
            if rule["enabled"] and not rule.get("next_run_at"):
                nxt = compute_next_run(rule, now)
                self._store.update_rule(rule["id"], next_run_at=nxt.isoformat(timespec="seconds"))

    def tick(self, now: datetime | None = None) -> list[dict]:
        """Một nhịp rà soát. Trả về danh sách lệnh đã tạo ở nhịp này."""
        now = now or datetime.now().astimezone()
        created: list[dict] = []
        for rule in self._store.list_rules():
            if not rule.get("enabled"):
                continue
            fresh = self._store.get_rule(rule["id"]) or rule
            if not fresh.get("next_run_at"):
                nxt = compute_next_run(fresh, now)
                self._store.update_rule(fresh["id"], next_run_at=nxt.isoformat(timespec="seconds"))
                fresh["next_run_at"] = nxt.isoformat(timespec="seconds")
            if not is_due(fresh, now):
                continue
            created.extend(self._fire(fresh, now))
        return created

    def run_rule_now(self, rule_id: int, now: datetime | None = None) -> list[dict]:
        """Chạy NGAY một quy tắc theo yêu cầu tay (nút "Chạy ngay" ở
        mục Tự động, V5.1): bắn lệnh như một nhịp tới hạn, kể cả khi
        quy tắc đang tắt (ý định tay của người dùng là tối cao) —
        lịch kế tiếp vẫn được tính lại như một lần chạy thật."""
        now = now or datetime.now().astimezone()
        rule = self._store.get_rule(rule_id)
        if rule is None:
            return []
        return self._fire(rule, now)

    def _fire(self, rule: dict, now: datetime) -> list[dict]:
        from .store import COMMAND_TYPE_LABELS

        action = rule["action"]
        if rule.get("profile_id"):
            profile = self._store.get_profile(rule["profile_id"])
            targets = [profile] if profile else []
        else:
            targets = self._store.list_profiles()
        created = []
        # V4.0 (H5): khoá chống trùng theo (quy tắc + kỳ lịch + hồ sơ) —
        # hai nhịp tick chồng nhau cho cùng một kỳ chỉ ra ĐÚNG một lệnh.
        period = rule.get("next_run_at") or now.isoformat(timespec="minutes")
        for profile in targets:
            if profile is None or profile.get("paused"):
                continue
            idem_key = f"auto-rule:{rule['id']}:{period}:{profile['id']}"
            if action == "create_video":
                # Lệnh chờ Muse: gắn đúng tài khoản Muse phụ trách hồ
                # sơ (nếu đã phân công) để Muse đó nhận việc cho kênh
                # này; cập nhật tiến độ qua cầu nối như các lệnh Muse.
                # V4.0 (Đ5): vào 'queued' — dispatcher xét điều kiện rồi
                # mới đẩy lên 'waiting_muse'.
                owner = self._store.agent_for_profile(profile["id"])
                command = self._store.create_command(
                    action,
                    source="auto",
                    profile_id=profile["id"],
                    profile_slug=profile["slug"],
                    instruction=(
                        f"{AUTOMATION_TAG} Tạo video MỚI trên Muse cho các "
                        f"kênh thuộc hồ sơ '{profile['label']}' (đúng chủ đề "
                        "từng kênh), hoàn tất thì cập nhật trạng thái + tiến "
                        f"độ vào app. Theo quy tắc #{rule['id']}."
                    ),
                    payload={"automation": "create_video", "rule_id": rule["id"]},
                    status="queued",
                    agent_id=owner["id"] if owner else None,
                    idempotency_key=idem_key,
                )
            else:
                command = self._store.create_command(
                    action,
                    source="auto",
                    profile_id=profile["id"],
                    profile_slug=profile["slug"],
                    instruction=f"{AUTOMATION_TAG} {COMMAND_TYPE_LABELS.get(action, action)}"
                    f" theo quy tắc #{rule['id']}.",
                    status="queued",
                    idempotency_key=idem_key,
                )
            created.append(command)
        if rule.get("schedule_kind") == "interval":
            next_run = next_interval_run(rule.get("interval_hours"), now)
        else:
            next_run = next_daily_run(rule.get("daily_time"), now)
        self._store.update_rule(
            rule["id"],
            last_run_at=now.isoformat(timespec="seconds"),
            next_run_at=next_run.isoformat(timespec="seconds"),
        )
        message = (
            f"{AUTOMATION_TAG} Quy tắc #{rule['id']} ({COMMAND_TYPE_LABELS.get(action, action)})"
            f" tới hạn — đã tạo {len(created)} lệnh; lần chạy kế: "
            f"{next_run.strftime('%d/%m %H:%M')}."
        )
        self._store.append_journal(message, rule.get("profile_id"))
        self._log(message)
        return created
