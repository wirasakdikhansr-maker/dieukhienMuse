"""V6.3 — BỘ QUY TẮC + KPI cho GIÁM SÁT (trưởng phòng / người chấm) và
NHÂN VIÊN (tài khoản Muse làm việc).

- Quy tắc: hai bộ văn bản (giám sát / nhân viên) người dùng sửa trong
  Cài đặt → "📏 Quy tắc & KPI"; để trống thì dùng bộ MẶC ĐỊNH cụ thể
  bên dưới. Quy tắc được gửi kèm MỌI lệnh trả cho Muse qua Agent API
  (trường ``rules`` trong lệnh + GET /api/rules) nên Muse luôn làm
  việc theo đúng bộ quy tắc hiện hành.
- KPI: chấm 0–100 điểm theo dữ liệu THẬT trong DB (không tự khai):
  nhân viên = hoàn thành, đúng hạn, đạt lần đầu, không treo, không
  để người dùng phải xử lý, trả lời chat nhanh; giám sát = chấm kịp,
  đội đúng hạn, tự xử lý sự cố, không để sự cố tồn đọng.
- Chỉ tiêu (target) của từng chỉ số chỉnh được; KPI dưới ngưỡng "đạt"
  → cảnh báo; trưởng phòng dưới ngưỡng thay thế liên tiếp → app tự
  đổi trưởng phòng (xem lead_autopilot).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from . import config
from .store import Store, _parse_iso

DEFAULT_AGENT_RULES = """\
1. Nhận việc trong 5 phút kể từ khi lệnh tới (claim), báo tiến độ ít nhất 10 phút/lần.
2. Mỗi lần báo tiến độ ghi RÕ bước cụ thể đang làm (vd "Viết kịch bản cảnh 3/8", "Render 62%", "Đăng video lên kênh X") — cấm ghi chung chung kiểu "đang xử lý".
3. Hoàn thành TRƯỚC hạn chót; thấy có nguy cơ trễ thì báo lý do + giờ xong dự kiến ngay khi biết.
4. Kết quả phải kèm BẰNG CHỨNG: link video/bài đăng, file, ảnh chụp hoặc số liệu kiểm chứng.
5. Làm đúng hồ sơ/kênh được giao; không đụng vào kênh không thuộc phân công.
6. Gặp đăng nhập/OTP/CAPTCHA: chuyển needs_user và nhắn rõ cần người dùng làm gì — không tự vượt.
7. Trả lời tin nhắn của người dùng trong 10 phút; việc người dùng nhắn là việc ưu tiên.
8. Không bỏ dở việc: nếu không làm được, trả lệnh (release) kèm lý do để người khác nhận.
9. Bị chấm "làm lại" thì sửa đúng các điểm giám sát nêu, không làm lại từ đầu nếu không cần.
"""

DEFAULT_SUPERVISOR_RULES = """\
1. Chấm mọi việc kiểm tra trong 15 phút kể từ khi được giao; dùng đủ checklist và bằng chứng.
2. Chỉ cho "Đạt" khi kết quả có bằng chứng kiểm chứng được; thiếu bằng chứng = "Làm lại".
3. Theo dõi bảng tiến độ: việc quá 75% thời hạn mà dưới 50% tiến độ → nhắc người làm ngay.
4. Tự xử lý sự cố trong phạm vi được phép (nhắc việc, gia hạn 1 lần, chuyển việc cho người rảnh, thử lại lỗi tạm thời) — không chờ người dùng.
5. Chỉ leo thang lên người dùng khi cần thao tác thật của người (đăng nhập, OTP, CAPTCHA, quyết định nội dung nhạy cảm).
6. Mỗi ngày đảm bảo không còn việc nào treo quá 30 phút không người nhận.
7. Không tự chấm việc của chính mình; không sửa kết quả của người làm.
8. Báo cáo ngắn gọn mỗi quyết định: việc gì, làm gì, vì sao.
"""

# Chỉ tiêu mặc định (người dùng sửa trong Cài đặt).
DEFAULT_TARGETS = {
    "agent_on_time_pct": 90,        # % việc xong đúng hạn
    "agent_first_pass_pct": 80,     # % việc đạt ngay lần chấm đầu
    "agent_max_stuck": 1,           # số lần bị bắt treo / tuần
    "agent_max_needs_user": 3,      # số lần đẩy việc cho người dùng / tuần
    "agent_chat_reply_minutes": 10, # thời gian trả lời chat trung bình
    "agent_min_done_week": 5,       # số việc tối thiểu / tuần
    "lead_review_minutes": 15,      # thời gian chấm trung bình
    "lead_team_on_time_pct": 85,    # % đúng hạn của cả đội
    "lead_auto_fix_pct": 70,        # % sự cố trưởng phòng tự xử lý
    "pass_score": 70,               # điểm KPI tối thiểu để "Đạt"
    "lead_replace_after": 2,        # số lần chấm liên tiếp dưới ngưỡng → thay trưởng phòng
}


def rules_settings(settings: dict | None = None) -> dict:
    source = settings if settings is not None else config.load_settings()
    targets = dict(DEFAULT_TARGETS)
    for key, value in (source.get("kpi_targets") or {}).items():
        if key in targets:
            try:
                targets[key] = int(value)
            except (TypeError, ValueError):
                pass
    agent_rules = str(source.get("rules_agent") or "").strip() or DEFAULT_AGENT_RULES.strip()
    supervisor_rules = str(source.get("rules_supervisor") or "").strip() or DEFAULT_SUPERVISOR_RULES.strip()
    return {
        "agent_rules": agent_rules,
        "supervisor_rules": supervisor_rules,
        "targets": targets,
        "enforce": bool(source.get("kpi_enforce", True)),
        "lead_auto_fix": bool(source.get("lead_auto_fix", True)),
        "lead_auto_replace": bool(source.get("lead_auto_replace", True)),
    }


def rules_for_command(command: dict, settings: dict | None = None) -> dict:
    """Quy tắc gửi kèm lệnh cho Muse: lệnh 'review' (việc của giám
    sát) nhận quy tắc giám sát; còn lại nhận quy tắc nhân viên. Kèm
    chỉ tiêu KPI để Muse biết mình bị chấm theo gì."""
    cfg = rules_settings(settings)
    role = "supervisor" if (command or {}).get("type") == "review" else "agent"
    return {
        "role": role,
        "text": cfg["supervisor_rules"] if role == "supervisor" else cfg["agent_rules"],
        "kpi_targets": cfg["targets"],
        "mandatory": cfg["enforce"],
    }


# --------------------------------------------------------------------------- #
# Tính KPI
# --------------------------------------------------------------------------- #
def _week_start(now: datetime) -> datetime:
    start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    return start


def _ratio(num: int, den: int) -> float | None:
    return round(100.0 * num / den, 1) if den else None


def chat_reply_minutes(store: Store, agent_id: int, since_iso: str) -> float | None:
    """Thời gian trung bình (phút) từ tin người dùng tới tin trả lời kế
    tiếp của agent, trong khoảng từ since."""
    rows = store._conn.execute(
        "SELECT direction, created_at FROM agent_messages WHERE agent_id = ?"
        " AND created_at >= ? AND direction IN ('user', 'agent') ORDER BY id",
        (int(agent_id), since_iso),
    ).fetchall()
    waits: list[float] = []
    pending: datetime | None = None
    for row in rows:
        at = _parse_iso(row["created_at"])
        if at is None:
            continue
        if row["direction"] == "user":
            pending = pending or at
        elif pending is not None:
            waits.append((at - pending).total_seconds() / 60.0)
            pending = None
    return round(sum(waits) / len(waits), 1) if waits else None


def _count(store: Store, sql: str, params: tuple) -> int:
    try:
        return int(store._conn.execute(sql, params).fetchone()[0])
    except Exception:
        return 0


def _score_part(value, target, higher_better=True) -> float | None:
    """Điểm 0–1 cho một chỉ số so với chỉ tiêu (None = chưa đủ dữ liệu)."""
    if value is None:
        return None
    if higher_better:
        if target <= 0:
            return 1.0
        return max(0.0, min(1.0, float(value) / float(target)))
    if value <= target:
        return 1.0
    # vượt trần: mỗi lần vượt trừ dần, tối đa về 0 ở mức gấp 3 trần
    span = max(1.0, float(target) * 2 or 2.0)
    return max(0.0, 1.0 - (float(value) - float(target)) / span)


def _combine(parts: list[tuple[float | None, float]]) -> int | None:
    usable = [(score, weight) for score, weight in parts if score is not None]
    if not usable:
        return None
    total_weight = sum(weight for _s, weight in usable)
    return int(round(100.0 * sum(s * w for s, w in usable) / total_weight))


def agent_kpi(store: Store, agent_id: int, settings: dict | None = None,
              now: datetime | None = None) -> dict:
    cfg = rules_settings(settings)
    t = cfg["targets"]
    now = now or datetime.now().astimezone()
    since = _week_start(now).isoformat(timespec="seconds")
    aid = int(agent_id)
    deadline = store.deadline_stats(aid, since)
    done = deadline["on_time"] + deadline["late"]
    done_all = _count(store, "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND status = 'done'"
                      " AND type <> 'review' AND finished_at >= ?", (aid, since))
    failed = _count(store, "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND status = 'failed'"
                    " AND type <> 'review' AND updated_at >= ?", (aid, since))
    open_now = _count(store, "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND type <> 'review'"
                      " AND status IN ('queued','waiting_muse','running','needs_user')", (aid,))
    needs_user = _count(store, "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND status = 'needs_user'", (aid,))
    try:
        passed0, decided0 = store.review_round_zero_pass_rate(aid, since)
    except Exception:
        passed0, decided0 = 0, 0
    try:
        stuck = store.review_stuck_count(aid, since)
    except Exception:
        stuck = 0
    reply = chat_reply_minutes(store, aid, since)
    on_time_pct = _ratio(deadline["on_time"], done)
    first_pass_pct = _ratio(passed0, decided0)
    score = _combine([
        (_score_part(on_time_pct, t["agent_on_time_pct"]), 3),
        (_score_part(first_pass_pct, t["agent_first_pass_pct"]), 3),
        (_score_part(done_all, t["agent_min_done_week"]), 2),
        (_score_part(stuck, t["agent_max_stuck"], higher_better=False), 1),
        (_score_part(needs_user, t["agent_max_needs_user"], higher_better=False), 1),
        (_score_part(reply, t["agent_chat_reply_minutes"], higher_better=False), 1),
        (_score_part(failed, 1, higher_better=False) if (done_all + failed) else None, 1),
    ])
    misses = []
    if on_time_pct is not None and on_time_pct < t["agent_on_time_pct"]:
        misses.append(f"Đúng hạn {on_time_pct}% < {t['agent_on_time_pct']}%")
    if first_pass_pct is not None and first_pass_pct < t["agent_first_pass_pct"]:
        misses.append(f"Đạt lần đầu {first_pass_pct}% < {t['agent_first_pass_pct']}%")
    if done_all < t["agent_min_done_week"]:
        misses.append(f"Mới xong {done_all}/{t['agent_min_done_week']} việc tuần này")
    if stuck > t["agent_max_stuck"]:
        misses.append(f"Bị bắt treo {stuck} lần")
    if needs_user > t["agent_max_needs_user"]:
        misses.append(f"{needs_user} việc đang đẩy cho người dùng")
    if reply is not None and reply > t["agent_chat_reply_minutes"]:
        misses.append(f"Trả lời chat chậm ({reply} phút)")
    return {
        "agent_id": aid,
        "role": "agent",
        "score": score,
        "passed": None if score is None else score >= t["pass_score"],
        "done": done_all,
        "failed": failed,
        "open": open_now,
        "on_time_pct": on_time_pct,
        "first_pass_pct": first_pass_pct,
        "stuck": stuck,
        "needs_user": needs_user,
        "chat_reply_min": reply,
        "misses": misses,
        "since": since,
    }


def lead_kpi(store: Store, lead_id: int, settings: dict | None = None,
             now: datetime | None = None) -> dict:
    cfg = rules_settings(settings)
    t = cfg["targets"]
    now = now or datetime.now().astimezone()
    since = _week_start(now).isoformat(timespec="seconds")
    lid = int(lead_id)
    rows = store._conn.execute(
        "SELECT created_at, decided_at, status FROM reviews WHERE supervisor_agent_id = ?"
        " AND created_at >= ?", (lid, since),
    ).fetchall()
    waits = []
    open_reviews = 0
    for row in rows:
        created = _parse_iso(row["created_at"])
        decided = _parse_iso(row["decided_at"])
        if row["status"] == "open":
            open_reviews += 1
            if created is not None:
                waits.append((now - created).total_seconds() / 60.0)
        elif created and decided:
            waits.append((decided - created).total_seconds() / 60.0)
    review_min = round(sum(waits) / len(waits), 1) if waits else None
    team = store.deadline_stats(None, since)
    team_on_time = _ratio(team["on_time"], team["on_time"] + team["late"])
    decisions = store.list_lead_decisions(since, limit=1000)
    auto = sum(1 for d in decisions if d.get("outcome") == "done")
    escalated = sum(1 for d in decisions if d.get("outcome") == "escalated")
    auto_pct = _ratio(auto, auto + escalated)
    score = _combine([
        (_score_part(review_min, t["lead_review_minutes"], higher_better=False), 3),
        (_score_part(team_on_time, t["lead_team_on_time_pct"]), 3),
        (_score_part(auto_pct, t["lead_auto_fix_pct"]), 2),
        (_score_part(open_reviews, 2, higher_better=False) if rows else None, 1),
    ])
    misses = []
    if review_min is not None and review_min > t["lead_review_minutes"]:
        misses.append(f"Chấm chậm ({review_min} phút)")
    if team_on_time is not None and team_on_time < t["lead_team_on_time_pct"]:
        misses.append(f"Đội đúng hạn {team_on_time}% < {t['lead_team_on_time_pct']}%")
    if auto_pct is not None and auto_pct < t["lead_auto_fix_pct"]:
        misses.append(f"Tự xử lý sự cố {auto_pct}% < {t['lead_auto_fix_pct']}%")
    return {
        "agent_id": lid,
        "role": "lead",
        "score": score,
        "passed": None if score is None else score >= t["pass_score"],
        "review_min": review_min,
        "open_reviews": open_reviews,
        "team_on_time_pct": team_on_time,
        "auto_fixed": auto,
        "escalated": escalated,
        "auto_fix_pct": auto_pct,
        "misses": misses,
        "since": since,
    }


def team_kpi(store: Store, settings: dict | None = None, now: datetime | None = None) -> list[dict]:
    """KPI của mọi agent còn hiệu lực; trưởng phòng có thêm khối 'lead'."""
    from . import supervision

    lead = supervision.lead_agent_id(store, settings)
    out = []
    for agent in store.list_agents():
        if agent.get("revoked"):
            continue
        row = agent_kpi(store, agent["id"], settings, now)
        row["name"] = agent.get("name") or agent.get("email")
        row["is_lead"] = lead is not None and int(agent["id"]) == int(lead)
        if row["is_lead"]:
            row["lead"] = lead_kpi(store, agent["id"], settings, now)
        out.append(row)
    out.sort(key=lambda r: (not r["is_lead"], -(r["score"] if r["score"] is not None else -1)))
    return out


def fmt(value, suffix: str = "") -> str:
    return "—" if value is None else f"{value}{suffix}"
