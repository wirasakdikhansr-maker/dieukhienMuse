"""Kịch bản Studio chạy trong Chrome NHÚNG của app (V4.4).

Loại lệnh ``studio_script``: payload ``{"steps": [...]}`` — app tự
lái Chrome nhúng của ĐÚNG hồ sơ đích qua CDP (app/cdp.py) theo từng
bước; Muse chỉ ra lệnh + nhận báo cáo (trạng thái từng bước, giá trị
đọc được, ảnh chụp) qua cầu nối. Đây là đường thực thi cho các việc
Studio nặng (upload video, điền metadata, lên lịch) mà trước V4.4
phía thực thi phải dùng trình duyệt riêng.

Các bước hỗ trợ (STEP_ACTIONS):
  goto{url, timeout_s?}            mở trang + chờ tải xong
  wait_for{selector|text, timeout_s?}  chờ phần tử xuất hiện
  click{selector|text}             bấm phần tử
  fill{selector, text}             điền chữ vào ô nhập
  press{key}                       Enter/Tab/Escape/mũi tên/1 ký tự…
  upload{selector?, file}          nạp file ĐÃ GIAO KÈM LỆNH vào
                                   <input type=file>; `file` CHỈ là
                                   tên file thuần (app tự resolve
                                   trong thư mục file của lệnh) —
                                   đường dẫn tuyệt đối/../ bị chặn
  read{selector, save_as, attr?}   đọc text/thuộc tính → kết quả lệnh
  screenshot{name}                 chụp màn hình (lưu phía app)
  sleep{seconds}                   chờ (tối đa 300s)
  require_no_login_wall{url_markers?, text_markers?}
                                   nếu trang đang ở màn hình đăng
                                   nhập/xác minh Google → dừng ở
                                   needs_user (KHÔNG tự vượt OTP/
                                   CAPTCHA — việc của chủ kênh)

Runner thuần logic: nhận `client` (CDPClient thật hoặc giả lập trong
test), `resolve_file(name) -> Path`, `save_screenshot(name) -> tên đã
lưu`, `progress(percent, step_text)` — cả executor (UI) lẫn
agent_server (API) đều dùng chung module này.
"""

from __future__ import annotations

import re
import time

from .cdp import CDPError

STEP_ACTIONS = (
    "goto",
    "wait_for",
    "click",
    "fill",
    "press",
    "upload",
    "read",
    "screenshot",
    "sleep",
    "require_no_login_wall",
)

MAX_SLEEP_SECONDS = 300
DEFAULT_GOTO_TIMEOUT_S = 30
DEFAULT_WAIT_TIMEOUT_S = 15

# Dấu hiệu "tường đăng nhập" mặc định: URL của Google Accounts hoặc
# chữ trên màn hình xác minh 2 bước (Anh + Việt).
LOGIN_WALL_URL_MARKERS = ("accounts.google.com",)
LOGIN_WALL_TEXT_MARKERS = (
    "Verify it's you",
    "2-Step Verification",
    "Xác minh đó là bạn",
    "To continue, sign in",
    "Đăng nhập để tiếp tục",
)

_SAFE_FILE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._()\- ]*$")
_SAFE_SCREENSHOT_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-]*$")


class StudioNeedsUser(Exception):
    """Kịch bản chạm tường cần NGƯỜI xử lý (đăng nhập/OTP/CAPTCHA).

    Mang theo `result` = tiến trình đã chạy tới lúc dừng để lệnh kết
    thúc ở needs_user vẫn cho thấy các bước trước đã làm được gì."""

    def __init__(self, reason: str, result: dict | None = None):
        super().__init__(reason)
        self.reason = reason
        self.result = result


class StudioStepError(Exception):
    """Một bước trong kịch bản lỗi — dừng ngay, mang theo kết quả dở
    dang (trạng thái từng bước + ảnh lỗi nếu chụp được)."""

    def __init__(self, message: str, result: dict | None = None):
        super().__init__(message)
        self.result = result


def is_safe_file_ref(name) -> bool:
    """Tên file tham chiếu trong step upload phải là TÊN THUẦN: không
    đường dẫn tuyệt đối, không '/', '\\', không '..'"""
    if not isinstance(name, str) or not name.strip():
        return False
    if "/" in name or "\\" in name or ".." in name:
        return False
    return bool(_SAFE_FILE_NAME_RE.match(name))


def _is_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def validate_steps(steps) -> list[str]:
    """Kiểm tra danh sách bước; trả list lỗi tiếng Việt (rỗng = hợp
    lệ). Dùng ở command_schema (lúc tạo lệnh) và UI (trước khi tạo)."""
    errors: list[str] = []
    if not isinstance(steps, list) or not steps:
        return ["payload.steps phải là danh sách có ít nhất 1 bước"]
    for index, step in enumerate(steps, start=1):
        label = f"Bước {index}"
        if not isinstance(step, dict):
            errors.append(f"{label}: mỗi bước phải là một object JSON")
            continue
        action = step.get("action")
        if action not in STEP_ACTIONS:
            errors.append(
                f"{label}: action {action!r} không hỗ trợ — dùng một trong: "
                + ", ".join(STEP_ACTIONS)
            )
            continue
        if action == "goto":
            url = step.get("url")
            if not isinstance(url, str) or not url.startswith(("http://", "https://")):
                errors.append(f"{label} (goto): thiếu 'url' http(s) hợp lệ")
            if "timeout_s" in step and not _is_number(step["timeout_s"]):
                errors.append(f"{label} (goto): 'timeout_s' phải là số giây")
        elif action == "wait_for":
            if not step.get("selector") and not step.get("text"):
                errors.append(f"{label} (wait_for): cần 'selector' hoặc 'text'")
            if "timeout_s" in step and not _is_number(step["timeout_s"]):
                errors.append(f"{label} (wait_for): 'timeout_s' phải là số giây")
        elif action == "click":
            if not step.get("selector") and not step.get("text"):
                errors.append(f"{label} (click): cần 'selector' hoặc 'text'")
        elif action == "fill":
            if not step.get("selector"):
                errors.append(f"{label} (fill): thiếu 'selector' của ô nhập")
            if not isinstance(step.get("text"), str):
                errors.append(f"{label} (fill): thiếu 'text' cần điền")
        elif action == "press":
            if not isinstance(step.get("key"), str) or not step.get("key"):
                errors.append(f"{label} (press): thiếu 'key' (vd 'Enter')")
        elif action == "upload":
            file_ref = step.get("file")
            if not file_ref:
                errors.append(f"{label} (upload): thiếu 'file' (tên file đã giao kèm lệnh)")
            elif not is_safe_file_ref(file_ref):
                errors.append(
                    f"{label} (upload): 'file' phải là TÊN FILE THUẦN đã giao "
                    "kèm lệnh — không chấp nhận đường dẫn/'/'/'..'"
                )
            if "selector" in step and not isinstance(step["selector"], str):
                errors.append(f"{label} (upload): 'selector' phải là chuỗi")
        elif action == "read":
            if not step.get("selector"):
                errors.append(f"{label} (read): thiếu 'selector'")
            if not step.get("save_as"):
                errors.append(f"{label} (read): thiếu 'save_as' (tên biến lưu kết quả)")
        elif action == "screenshot":
            name = step.get("name")
            if not name:
                errors.append(f"{label} (screenshot): thiếu 'name'")
            elif not isinstance(name, str) or not _SAFE_SCREENSHOT_NAME_RE.match(name):
                errors.append(
                    f"{label} (screenshot): 'name' chỉ gồm chữ/số/._- "
                    "(không dấu cách, không đường dẫn)"
                )
        elif action == "sleep":
            seconds = step.get("seconds")
            if not _is_number(seconds) or seconds < 0 or seconds > MAX_SLEEP_SECONDS:
                errors.append(
                    f"{label} (sleep): 'seconds' phải là số 0–{MAX_SLEEP_SECONDS}"
                )
        elif action == "require_no_login_wall":
            for key in ("url_markers", "text_markers"):
                value = step.get(key)
                if value is not None and not (
                    isinstance(value, list)
                    and all(isinstance(item, str) for item in value)
                ):
                    errors.append(f"{label} (require_no_login_wall): '{key}' phải là danh sách chuỗi")
    return errors


def describe_step(step: dict) -> str:
    """Mô tả ngắn 1 bước — hiện ở cột 'đang làm gì' + log tiến trình."""
    action = step.get("action")
    if action == "goto":
        return f"Mở trang {step.get('url', '')}"
    if action == "wait_for":
        target = step.get("selector") or f"chữ “{step.get('text', '')}”"
        return f"Chờ xuất hiện: {target}"
    if action == "click":
        target = step.get("selector") or f"nút “{step.get('text', '')}”"
        return f"Bấm {target}"
    if action == "fill":
        return f"Điền chữ vào {step.get('selector', '')}"
    if action == "press":
        return f"Nhấn phím {step.get('key', '')}"
    if action == "upload":
        return f"Nạp file {step.get('file', '')} vào ô upload"
    if action == "read":
        return f"Đọc {step.get('selector', '')} → {step.get('save_as', '')}"
    if action == "screenshot":
        return f"Chụp màn hình “{step.get('name', '')}”"
    if action == "sleep":
        return f"Chờ {step.get('seconds', 0)} giây"
    if action == "require_no_login_wall":
        return "Kiểm tra không bị chặn ở màn hình đăng nhập"
    return str(action)


def detect_login_wall(client, extra_url_markers=(), extra_text_markers=()) -> str | None:
    """Trả về MÔ TẢ dấu hiệu tường đăng nhập nếu trang hiện tại đang
    bị chặn ở màn hình đăng nhập/xác minh Google; None nếu không."""
    info = client.evaluate(
        "(() => ({"
        " url: location.href,"
        " text: ((document.body && document.body.innerText) || '').slice(0, 6000)"
        " }))()"
    ) or {}
    url = str(info.get("url") or "")
    text = str(info.get("text") or "")
    for marker in tuple(LOGIN_WALL_URL_MARKERS) + tuple(extra_url_markers):
        if marker and marker in url:
            return f"URL đang ở trang Google Accounts ({marker})"
    for marker in tuple(LOGIN_WALL_TEXT_MARKERS) + tuple(extra_text_markers):
        if marker and marker in text:
            return f"trang hiện chữ xác minh “{marker}”"
    return None


def run_studio_script(
    client,
    steps: list[dict],
    *,
    resolve_file,
    save_screenshot,
    progress=None,
    sleep=time.sleep,
) -> dict:
    """Chạy tuần tự các bước trên `client` (CDPClient hoặc tương
    thích). progress(percent:int, step_text:str) được gọi trước mỗi
    bước. Lỗi ở bước nào → dừng ngay tại đó (kèm chụp màn hình lỗi
    nếu được), ném StudioStepError/StudioNeedsUser mang kết quả dở
    dang. Thành công → trả dict kết quả đầy đủ."""
    result: dict = {
        "kind": "studio_script",
        "total_steps": len(steps),
        "completed_steps": 0,
        "steps": [],
        "reads": {},
        "screenshots": [],
        "status": "running",
    }

    def _fail(exc_type, message):
        result["status"] = "needs_user" if exc_type is StudioNeedsUser else "failed"
        try:
            # Entry của bước lỗi đã được append trước khi tới đây nên
            # len(steps) chính là index của bước vừa hỏng.
            shot = save_screenshot(f"error-step-{max(1, len(result['steps']))}")
            if shot:
                result["error_screenshot"] = shot
        except Exception:
            pass  # ảnh lỗi là phụ — không để nó che lỗi chính
        return exc_type(message, result=result)

    total = max(1, len(steps))
    for index, step in enumerate(steps, start=1):
        action = step.get("action")
        if progress is not None:
            progress(
                int((index - 1) * 100 / total),
                f"Bước {index}/{len(steps)}: {describe_step(step)}",
            )
        entry = {"index": index, "action": action, "status": "ok", "detail": ""}
        try:
            detail = _run_one_step(
                client, step, result, resolve_file=resolve_file,
                save_screenshot=save_screenshot, sleep=sleep,
            )
            entry["detail"] = detail
        except StudioNeedsUser as exc:
            entry["status"] = "needs_user"
            entry["detail"] = exc.reason
            result["steps"].append(entry)
            raise _fail(StudioNeedsUser, exc.reason) from exc
        except Exception as exc:  # CDPError + lỗi resolve file…
            entry["status"] = "failed"
            entry["detail"] = str(exc)
            result["steps"].append(entry)
            raise _fail(
                StudioStepError,
                f"Bước {index}/{len(steps)} ({describe_step(step)}) lỗi: {exc}",
            ) from exc
        result["steps"].append(entry)
        result["completed_steps"] = index
    result["status"] = "done"
    if progress is not None:
        progress(100, f"Xong {len(steps)}/{len(steps)} bước kịch bản Studio")
    return result


def _run_one_step(client, step, result, *, resolve_file, save_screenshot, sleep) -> str:
    action = step.get("action")
    if action == "goto":
        timeout = step.get("timeout_s", DEFAULT_GOTO_TIMEOUT_S)
        client.navigate_and_wait(step["url"], timeout=float(timeout))
        return f"Đã tải xong {step['url']}"
    if action == "wait_for":
        info = client.wait_for(
            selector=step.get("selector") or None,
            text=step.get("text") or None,
            timeout_s=float(step.get("timeout_s", DEFAULT_WAIT_TIMEOUT_S)),
        )
        return f"Đã thấy phần tử ({info.get('tag', '?')})"
    if action == "click":
        clicked = client.click_element(
            selector=step.get("selector") or None,
            text=step.get("text") or None,
        )
        return f"Đã bấm {clicked.get('tag', '?')} “{clicked.get('text', '')}”"
    if action == "fill":
        filled = client.fill_element(step["selector"], step["text"])
        return f"Đã điền {filled.get('chars', len(step['text']))} ký tự"
    if action == "press":
        pressed = client.press_key(step["key"])
        return f"Đã nhấn {pressed.get('key', step['key'])}"
    if action == "upload":
        path = resolve_file(step["file"])
        selector = step.get("selector") or 'input[type="file"]'
        client.set_file_input(selector, [str(path)])
        return f"Đã nạp file {step['file']} ({path})"
    if action == "read":
        value = client.read_text(step["selector"], attr=step.get("attr") or None)
        result["reads"][step["save_as"]] = value
        preview = value if len(value) <= 120 else value[:117] + "…"
        return f"{step['save_as']} = “{preview}”"
    if action == "screenshot":
        saved = save_screenshot(step["name"])
        if not saved:
            raise CDPError(f"Không chụp được màn hình “{step['name']}”")
        result["screenshots"].append(saved)
        return f"Đã lưu ảnh {saved}"
    if action == "sleep":
        sleep(float(step["seconds"]))
        return f"Đã chờ {step['seconds']} giây"
    if action == "require_no_login_wall":
        wall = detect_login_wall(
            client,
            extra_url_markers=step.get("url_markers") or (),
            extra_text_markers=step.get("text_markers") or (),
        )
        if wall:
            raise StudioNeedsUser(
                "Trang đang bị chặn ở màn hình đăng nhập/xác minh của "
                f"Google ({wall}). Hãy đăng nhập/hoàn tất xác minh "
                "trong cửa sổ Chrome nhúng của đúng hồ sơ này rồi bấm "
                "“Đã xử lý — chạy tiếp”; app KHÔNG tự vượt OTP/CAPTCHA."
            )
        return "Không có tường đăng nhập"
    raise CDPError(f"Action không hỗ trợ: {action!r}")


# Mẫu kịch bản cho UI tạo lệnh + tài liệu docs/EMBEDDED_STUDIO.md:
# mở Studio của kênh, chụp màn hình xác nhận đang ở đúng kênh (vô hại,
# không đăng/sửa gì) — cũng là kịch bản kiểm chứng đầu tiên nên chạy
# trên máy thật.
EXAMPLE_STEPS: list[dict] = [
    {"action": "goto", "url": "https://studio.youtube.com/"},
    {"action": "require_no_login_wall"},
    {"action": "wait_for", "selector": "ytcp-app", "timeout_s": 20},
    {"action": "screenshot", "name": "studio-home"},
]
