"""V6.4.2 — TỰ NỐI LẠI khi mất kết nối Muse.

Nguyên nhân "mất kết nối không tự nối lại" (đã phân tích trong mã):
1. Tailscale: app chỉ tự chạy `tailscale up` ĐÚNG MỘT LẦN mỗi đợt mất
   nối; lần đó hỏng (mạng chưa sẵn sau khi máy thức dậy…) là đứng yên.
   → sửa ở MainWindow: thử lại giãn dần 1 → 2 → 5 → 10 phút.
2. Cầu nối của app (Agent API): không ai kiểm tra nó còn sống; luồng
   server chết hoặc cổng kẹt sau khi máy ngủ là Muse gọi mãi không tới.
   → probe_bridge() tự gọi /api/health mỗi 30 giây, 2 lần liền không
   trả lời thì khởi động lại server.
3. Phía Muse: Muse làm việc theo lượt trên server của nó — hết phiên /
   hook dừng là thôi gọi vào app, app không có cách nào "kéo" nó về.
   → plan_agent_wakeups(): Muse TỪNG kết nối mà mất nhịp tim quá 3 phút
   (và còn việc mở, hoặc mới online trong 24 giờ) thì app gõ lời nhắc
   kết nối lại vào khung chat muse.ai của đúng tài khoản đó (muse_push),
   giãn dần 5 → 10 → 20 → 40 phút; phiên muse.ai đã văng thì tự đăng
   nhập lại bằng tinyhost (V6.2) trước.
"""

from __future__ import annotations

import json
import time
import urllib.request
from datetime import datetime

from .store import Store, agent_status

STALE_SECONDS = 180
BACKOFF_MINUTES = (5, 10, 20, 40)
RECENT_HOURS = 24

_LOCAL = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def probe_bridge(port: int, timeout: float = 4.0) -> bool:
    try:
        with _LOCAL.open(f"http://127.0.0.1:{int(port)}/api/health", timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8") or "{}")
            return bool(data.get("ok", True))
    except Exception:
        return False


def _age_seconds(value, now: datetime) -> float | None:
    if not value:
        return None
    try:
        return (now - datetime.fromisoformat(str(value))).total_seconds()
    except ValueError:
        return None


def plan_agent_wakeups(store: Store, memory: dict | None = None, now: datetime | None = None,
                       clock=time.monotonic) -> dict:
    """Chọn các Muse cần đánh thức. ``memory`` = {agent_id: (lần_thử, mốc_lần_sau)}
    giữ giữa các nhịp; agent online trở lại thì xoá khỏi memory."""
    now = now or datetime.now().astimezone()
    memory = dict(memory or {})
    wake: list[tuple[dict, str]] = []
    try:
        open_by_agent: dict[int, int] = {}
        for row in store._conn.execute(
            "SELECT agent_id, COUNT(*) FROM commands WHERE agent_id IS NOT NULL AND status IN"
            " ('queued','waiting_muse','running','needs_user') GROUP BY agent_id"
        ).fetchall():
            open_by_agent[int(row[0])] = int(row[1])
    except Exception:
        open_by_agent = {}
    for agent in store.list_agents():
        aid = int(agent["id"])
        if agent.get("revoked"):
            memory.pop(aid, None)
            continue
        age = _age_seconds(agent.get("last_seen_at"), now)
        if age is None:
            continue  # chưa từng kết nối → không phải "mất kết nối"
        if agent_status(agent.get("last_seen_at")) == "online" or age < STALE_SECONDS:
            memory.pop(aid, None)
            continue
        busy = open_by_agent.get(aid, 0)
        if not busy and age > RECENT_HOURS * 3600:
            continue
        tries, next_at = memory.get(aid, (0, 0.0))
        if clock() < next_at:
            continue
        minutes = int(age // 60)
        reason = f"mất nhịp tim {minutes} phút" + (f", còn {busy} việc" if busy else "")
        wake.append((agent, reason))
        memory[aid] = (tries + 1, clock() + 60 * BACKOFF_MINUTES[min(tries, len(BACKOFF_MINUTES) - 1)])
    return {"wake": wake, "memory": memory}


def reconnect_text(agent: dict, settings: dict, reason: str) -> str:
    port = settings.get("agent_port", 19500)
    return (
        f"🔌 [Channel Control Desktop] Bạn đã mất kết nối với app ({reason}). "
        f"Hãy kết nối lại NGAY bằng phiếu kết nối của tài khoản #{agent['id']} "
        f"(cầu nối http://<địa chỉ Tailscale của PC>:{port}, header X-Agent-Id + X-Agent-Token): "
        f"gửi POST /api/agents/{agent['id']}/heartbeat, rồi bật lại vòng nhận việc "
        "GET /api/commands?status=waiting_muse&wait=25 và tin nhắn "
        f"GET /api/agents/{agent['id']}/messages?unread=1&wait=25. Làm tiếp các việc đang dở."
    )
