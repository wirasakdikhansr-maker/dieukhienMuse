"""Bộ máy hàng đợi việc (V3.1) — một đường chạy nền DUY NHẤT cho mọi
việc nặng của app: quét kênh, kiểm tra, thực thi lệnh, bắn quy tắc tự
động (quy tắc vẫn chỉ TẠO lệnh vào bảng commands như cũ, engine lo phần
thực thi lệnh đó).

Tính chất:

- **Tuần tự theo hồ sơ**: không bao giờ có hai việc "chạm trình duyệt"
  chạy cùng lúc trên MỘT hồ sơ (hai việc cùng profile_id khác None sẽ
  xếp hàng chờ nhau). Việc của các hồ sơ khác nhau, hoặc việc không gắn
  hồ sơ (profile_id=None), chạy song song tự do.
- **Ưu tiên**: số càng nhỏ càng trước — lệnh người dùng bấm tay
  (PRIORITY_MANUAL) chạy trước việc do tự động hoá bắn ra
  (PRIORITY_AUTO).
- **Huỷ được**: mỗi việc có CancellationToken; huỷ việc đang chờ = việc
  không bao giờ chạy; huỷ việc đang chạy = token được bật, hàm việc tự
  quyết định điểm dừng an toàn (kiểm token giữa các bước / sau khi chạy).
- **Thử lại**: hàm việc ném ``TransientJobError`` (lỗi tạm thời kiểu
  CDP/socket/IO) → engine thử lại tối đa ``max_retries`` lần (mặc định
  2) với backoff tăng dần. Lỗi khác → thất bại ngay, không thử lại.

Module thuần threading (không Qt): tầng UI bọc nó bằng adapter Qt
(app/ui/command_runner.py) để nhận sự kiện qua Signal. Hàm việc nhận
token và trả kết quả tuỳ ý; mọi sự kiện vòng đời đi qua callback
``on_event(job, event)`` với event ∈ queued/started/retry/finished —
callback được gọi TỪ LUỒNG ENGINE, nơi nhận tự lo đồng bộ về luồng của
mình (Qt Signal tự xếp hàng chéo luồng an toàn).
"""

from __future__ import annotations

import heapq
import itertools
import threading
import time
import uuid

PRIORITY_MANUAL = 0
PRIORITY_NORMAL = 5
PRIORITY_AUTO = 10

DEFAULT_MAX_RETRIES = 2


class TransientJobError(Exception):
    """Lỗi tạm thời (CDP rớt, socket, IO chập chờn) — đáng thử lại."""


class JobCancelled(Exception):
    """Hàm việc tự ném khi thấy token đã huỷ và muốn dừng gọn gàng."""


class CancellationToken:
    """Cờ huỷ thread-safe cho một việc."""

    def __init__(self):
        self._event = threading.Event()

    def cancel(self) -> None:
        self._event.set()

    @property
    def cancelled(self) -> bool:
        return self._event.is_set()

    def raise_if_cancelled(self) -> None:
        if self.cancelled:
            raise JobCancelled("Việc đã bị huỷ.")


class Job:
    """Một đơn vị việc trong hàng đợi."""

    _seq = itertools.count()

    def __init__(
        self,
        fn,
        profile_id: int | None = None,
        priority: int = PRIORITY_NORMAL,
        kind: str = "custom",
        command_id: str | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        self.id = uuid.uuid4().hex[:12]
        self.fn = fn  # callable(token) -> kết quả tuỳ ý
        self.profile_id = profile_id
        self.priority = int(priority)
        self.kind = kind
        self.command_id = command_id
        self.max_retries = max(0, int(max_retries))
        self.token = CancellationToken()
        self.attempts = 0
        self.status = "queued"  # queued | running | done | failed | cancelled
        self.result = None
        self.error: str | None = None
        self._seq_no = next(Job._seq)

    def __lt__(self, other: "Job") -> bool:
        # heapq: ưu tiên nhỏ trước, cùng ưu tiên thì FIFO theo lúc nộp.
        return (self.priority, self._seq_no) < (other.priority, other._seq_no)

    def __repr__(self) -> str:  # pragma: no cover - gỡ lỗi
        return f"<Job {self.id} {self.kind} p={self.profile_id} {self.status}>"


class JobEngine:
    """Hàng đợi + bể luồng chạy việc. ``num_workers`` luồng nền rút việc
    từ heap ưu tiên; mỗi việc chiếm "khoá hồ sơ" của nó trong lúc chạy.

    ``sleep`` tiêm được để kiểm thử backoff không phải chờ thật.
    """

    def __init__(self, num_workers: int = 3, on_event=None, sleep=None):
        self._on_event = on_event or (lambda job, event: None)
        self._sleep = sleep or time.sleep
        self._cond = threading.Condition()
        self._heap: list[Job] = []
        self._jobs: dict[str, Job] = {}
        self._busy_profiles: set[int] = set()
        self._stopped = False
        self._workers = [
            threading.Thread(target=self._worker_loop, daemon=True, name=f"job-engine-{i}")
            for i in range(max(1, int(num_workers)))
        ]
        for thread in self._workers:
            thread.start()

    # ------------------------------------------------------------------ #
    # API nộp / huỷ việc
    # ------------------------------------------------------------------ #
    def submit(
        self,
        fn,
        profile_id: int | None = None,
        priority: int = PRIORITY_NORMAL,
        kind: str = "custom",
        command_id: str | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> Job:
        job = Job(
            fn,
            profile_id=profile_id,
            priority=priority,
            kind=kind,
            command_id=command_id,
            max_retries=max_retries,
        )
        with self._cond:
            self._jobs[job.id] = job
            heapq.heappush(self._heap, job)
            self._cond.notify_all()
        self._emit(job, "queued")
        return job

    def cancel(self, job_id: str) -> bool:
        """Huỷ một việc: đang chờ → đánh dấu cancelled và rút khỏi heap;
        đang chạy → bật token để hàm việc tự dừng. True nếu có việc đó."""
        with self._cond:
            job = self._jobs.get(job_id)
            if job is None:
                return False
            job.token.cancel()
            if job.status == "queued":
                job.status = "cancelled"
                job.error = "Đã huỷ khi đang chờ."
                self._heap = [j for j in self._heap if j.id != job_id]
                heapq.heapify(self._heap)
                self._cond.notify_all()
        if job.status == "cancelled":
            self._emit(job, "finished")
        return True

    def get(self, job_id: str) -> Job | None:
        with self._cond:
            return self._jobs.get(job_id)

    def find_by_command(self, command_id: str) -> Job | None:
        """Việc mới nhất gắn với một command_id (cho nút Huỷ ở panel Lệnh)."""
        with self._cond:
            matches = [j for j in self._jobs.values() if j.command_id == command_id]
        active = [j for j in matches if j.status in ("queued", "running")]
        pool = active or matches
        return pool[-1] if pool else None

    @property
    def pending_count(self) -> int:
        with self._cond:
            return sum(1 for j in self._jobs.values() if j.status == "queued")

    @property
    def running_profiles(self) -> set[int]:
        with self._cond:
            return set(self._busy_profiles)

    def shutdown(self, wait: bool = True, timeout: float = 5.0) -> None:
        with self._cond:
            self._stopped = True
            self._cond.notify_all()
        if wait:
            for thread in self._workers:
                thread.join(timeout=timeout)

    # ------------------------------------------------------------------ #
    # Vòng lặp worker
    # ------------------------------------------------------------------ #
    def _emit(self, job: Job, event: str) -> None:
        try:
            self._on_event(job, event)
        except Exception:
            pass  # callback lỗi không được làm sập engine

    def _take_runnable(self) -> Job | None:
        """(Đã giữ khoá) Lấy việc ưu tiên nhất mà hồ sơ của nó đang rảnh.
        Việc bị chặn vì hồ sơ bận được GIỮ trong heap chờ nhịp sau."""
        blocked: list[Job] = []
        chosen: Job | None = None
        while self._heap:
            candidate = heapq.heappop(self._heap)
            if candidate.status != "queued":
                continue  # đã huỷ trong lúc chờ — bỏ qua
            if candidate.profile_id is not None and candidate.profile_id in self._busy_profiles:
                blocked.append(candidate)
                continue
            chosen = candidate
            break
        for job in blocked:
            heapq.heappush(self._heap, job)
        if chosen is not None:
            chosen.status = "running"
            if chosen.profile_id is not None:
                self._busy_profiles.add(chosen.profile_id)
        return chosen

    def _worker_loop(self) -> None:
        while True:
            with self._cond:
                job = None
                while job is None:
                    if self._stopped:
                        return
                    job = self._take_runnable()
                    if job is None:
                        self._cond.wait(timeout=0.5)
            self._run_job(job)
            with self._cond:
                if job.profile_id is not None:
                    self._busy_profiles.discard(job.profile_id)
                self._cond.notify_all()

    def _run_job(self, job: Job) -> None:
        self._emit(job, "started")
        backoff = 0.5
        while True:
            job.attempts += 1
            try:
                if job.token.cancelled:
                    raise JobCancelled("Việc đã bị huỷ.")
                job.result = job.fn(job.token)
                job.status = "cancelled" if job.token.cancelled else "done"
                if job.token.cancelled:
                    job.error = "Đã huỷ bởi người dùng."
                break
            except JobCancelled:
                job.status = "cancelled"
                job.error = "Đã huỷ bởi người dùng."
                break
            except TransientJobError as exc:
                if job.attempts <= job.max_retries and not job.token.cancelled:
                    self._emit(job, "retry")
                    self._sleep(backoff)
                    backoff *= 2
                    continue
                job.status = "failed"
                job.error = str(exc)
                break
            except Exception as exc:
                job.status = "failed"
                job.error = str(exc)
                break
        self._emit(job, "finished")
