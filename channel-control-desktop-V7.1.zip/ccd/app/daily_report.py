"""V6.3 — BÁO CÁO KÊNH HẰNG NGÀY (mặc định 08:00).

Mỗi sáng app tự tạo một báo cáo HTML (data/reports/bao-cao-YYYY-MM-DD.html)
nhóm theo TỪNG TÀI KHOẢN MUSE → từng hồ sơ → TỪNG KÊNH Muse đó quản lý:

- Số liệu kênh: subs, số video, thay đổi 24h / 7 ngày (từ snapshot quét
  kênh), lần quét cuối.
- Việc 24h qua của kênh: xong / thất bại / đang làm / chờ người, kèm bước
  cuối và kết quả (link, lỗi).
- Phân tích + đề xuất cụ thể theo luật: kênh đứng subs, không có video mới
  trong 7 ngày, dữ liệu quét cũ, lỗi lặp, việc treo, Muse ngoại tuyến...
- KPI tuần của Muse phụ trách.

Số liệu chỉ lấy từ DB của app (không bịa); thiếu dữ liệu thì ghi rõ
"chưa đủ dữ liệu" kèm cách có dữ liệu (quét kênh).
"""

from __future__ import annotations

import html
from datetime import datetime, timedelta
from pathlib import Path

from . import kpi
from .store import COMMAND_TYPE_LABELS, Store, _parse_iso, agent_status

META_KEY = "daily_report_last_day"


def _fmt_int(value) -> str:
    return "—" if value is None else f"{int(value):,}".replace(",", ".")


def _delta(value) -> str:
    if value is None:
        return "chưa đủ dữ liệu"
    return f"+{_fmt_int(value)}" if value > 0 else (_fmt_int(value) if value < 0 else "0")


def _commands_24h(store: Store, profile_id: int, since: str) -> list[dict]:
    from .store import _command_row

    rows = store._conn.execute(
        "SELECT * FROM commands WHERE profile_id = ? AND type <> 'review' AND"
        " (updated_at >= ? OR status IN ('queued','waiting_muse','running','needs_user'))"
        " ORDER BY updated_at DESC LIMIT 50",
        (profile_id, since),
    ).fetchall()
    return [_command_row(r) for r in rows]


def analyse_channel(channel: dict, growth: dict, commands: list[dict], now: datetime) -> list[str]:
    notes: list[str] = []
    scan = _parse_iso(channel.get("last_scan_at"))
    if scan is None:
        notes.append("⚠ Chưa từng quét kênh — bấm Quét kênh để có số liệu subs/video.")
    elif now - scan > timedelta(hours=36):
        notes.append(f"⚠ Số liệu cũ ({(now - scan).days} ngày chưa quét) — nên quét lại để báo cáo chính xác.")
    d1, d7, v7 = growth.get("subs_delta_1d"), growth.get("subs_delta_7d"), growth.get("videos_delta_7d")
    if d7 is not None and d7 <= 0:
        notes.append("📉 Subs không tăng trong 7 ngày — đề xuất: đổi chủ đề/tiêu đề thumbnail, tăng tần suất đăng.")
    elif d1 is not None and d1 > 0:
        notes.append(f"📈 Subs tăng {d1} trong 24h — giữ nhịp nội dung đang hiệu quả.")
    if v7 is not None and v7 <= 0:
        notes.append("🎬 Không có video mới trong 7 ngày — đề xuất giao lệnh Tạo video cho Muse phụ trách.")
    failed = [c for c in commands if c["status"] == "failed"]
    if len(failed) >= 2:
        notes.append(f"✕ {len(failed)} việc thất bại 24h — xem lý do lỗi, xử lý gốc thay vì thử lại mù.")
    stuck = [c for c in commands if c["status"] == "needs_user"]
    if stuck:
        notes.append(f"✋ {len(stuck)} việc đang chờ người — xử lý ở Văn phòng → Sự cố cần xử lý.")
    if not commands:
        notes.append("💤 Không có việc nào trong 24h — kênh đang không được chăm.")
    return notes or ["✓ Kênh ổn định, không có điểm cần xử lý."]


def build(store: Store, settings: dict | None = None, now: datetime | None = None) -> dict:
    now = now or datetime.now().astimezone()
    since = (now - timedelta(hours=24)).isoformat(timespec="seconds")
    profiles = {p["id"]: p for p in store.list_profiles()}
    owned: set[int] = set()
    sections = []
    for agent in store.list_agents():
        if agent.get("revoked"):
            continue
        entry = {
            "agent": agent,
            "status": agent_status(agent.get("last_seen_at"), agent.get("revoked")),
            "kpi": kpi.agent_kpi(store, agent["id"], settings, now),
            "profiles": [],
        }
        for pid in agent.get("profile_ids") or []:
            profile = profiles.get(pid)
            if profile is None:
                continue
            owned.add(pid)
            entry["profiles"].append(_profile_block(store, profile, since, now))
        sections.append(entry)
    unowned = [_profile_block(store, p, since, now) for pid, p in profiles.items() if pid not in owned]
    totals = {
        "channels": sum(len(b["channels"]) for s in sections for b in s["profiles"]) + sum(len(b["channels"]) for b in unowned),
        "done": store._conn.execute(
            "SELECT COUNT(*) FROM commands WHERE status='done' AND type<>'review' AND finished_at >= ?", (since,)).fetchone()[0],
        "failed": store._conn.execute(
            "SELECT COUNT(*) FROM commands WHERE status='failed' AND type<>'review' AND updated_at >= ?", (since,)).fetchone()[0],
        "needs_user": store._conn.execute(
            "SELECT COUNT(*) FROM commands WHERE status='needs_user'").fetchone()[0],
    }
    return {"generated_at": now, "sections": sections, "unowned": unowned, "totals": totals}


def _profile_block(store: Store, profile: dict, since: str, now: datetime) -> dict:
    commands = _commands_24h(store, profile["id"], since)
    channels = []
    for channel in store.list_channels(profile["id"]):
        growth = store.channel_growth(profile["id"], channel["channel_id"])
        own = [c for c in commands if not c.get("channel_id") or c.get("channel_id") in (channel["channel_id"], str(channel["id"]))]
        channels.append({
            "channel": channel,
            "growth": growth,
            "commands": own,
            "notes": analyse_channel(channel, growth, own, now),
        })
    return {"profile": profile, "channels": channels, "commands": commands}


_CSS = """
body{font-family:Segoe UI,Arial,sans-serif;background:#0f1110;color:#e6e8e3;margin:0;padding:24px;}
h1{font-size:22px;margin:0 0 4px} h2{font-size:18px;margin:28px 0 8px;border-bottom:1px solid #2a2f2b;padding-bottom:6px}
h3{font-size:15px;margin:16px 0 6px;color:#9fd8b4} .muted{color:#8b918b;font-size:13px}
.tiles{display:flex;gap:12px;flex-wrap:wrap;margin:14px 0} .tile{background:#171a18;border:1px solid #2a2f2b;border-radius:10px;padding:10px 14px;min-width:120px}
.tile b{display:block;font-size:20px} table{border-collapse:collapse;width:100%;margin:6px 0 10px;font-size:13px}
th,td{border-bottom:1px solid #2a2f2b;padding:6px 8px;text-align:left;vertical-align:top} th{color:#8b918b;font-weight:600}
.card{background:#151816;border:1px solid #2a2f2b;border-radius:12px;padding:12px 14px;margin:10px 0}
.ok{color:#3ecf6a}.bad{color:#f05252}.warn{color:#d9a441} ul{margin:4px 0 4px 18px;padding:0} li{margin:2px 0}
"""


def render_html(report: dict) -> str:
    esc = html.escape
    now = report["generated_at"]
    t = report["totals"]
    out = [f"<!doctype html><html lang='vi'><head><meta charset='utf-8'><title>Báo cáo kênh {now:%d/%m/%Y}</title>"
           f"<style>{_CSS}</style></head><body>",
           f"<h1>📊 Báo cáo kênh ngày {now:%d/%m/%Y}</h1>",
           f"<div class='muted'>Tạo lúc {now:%H:%M} · số liệu 24h qua từ dữ liệu của app</div>",
           "<div class='tiles'>",
           f"<div class='tile'><b>{t['channels']}</b>kênh</div>",
           f"<div class='tile'><b class='ok'>{t['done']}</b>việc xong 24h</div>",
           f"<div class='tile'><b class='bad'>{t['failed']}</b>việc thất bại 24h</div>",
           f"<div class='tile'><b class='warn'>{t['needs_user']}</b>việc chờ người</div>",
           "</div>"]
    for section in report["sections"]:
        agent = section["agent"]
        k = section["kpi"]
        score = "—" if k.get("score") is None else k["score"]
        status = {"online": "🟢 đang online", "idle": "🟡 vừa rời", "offline": "⚪ ngoại tuyến"}.get(section["status"], section["status"])
        out.append(f"<h2>🤖 {esc(agent.get('name') or '')} <span class='muted'>({esc(agent.get('email') or '')}) · {status}"
                   f" · KPI tuần: {score} điểm</span></h2>")
        if k.get("misses"):
            out.append("<div class='muted'>Chưa đạt: " + esc("; ".join(k["misses"])) + "</div>")
        if not section["profiles"]:
            out.append("<div class='muted'>Chưa được phân công hồ sơ/kênh nào.</div>")
        for block in section["profiles"]:
            out.extend(_render_profile(block))
    if report["unowned"]:
        out.append("<h2>❓ Hồ sơ chưa có Muse phụ trách</h2>")
        for block in report["unowned"]:
            out.extend(_render_profile(block))
    out.append("</body></html>")
    return "\n".join(out)


def _render_profile(block: dict) -> list[str]:
    esc = html.escape
    profile = block["profile"]
    out = [f"<h3>👤 Hồ sơ {esc(profile.get('label') or '')} · {esc(profile.get('gmail') or '')}</h3>"]
    if not block["channels"]:
        out.append("<div class='muted'>Chưa có kênh nào (chưa quét hồ sơ).</div>")
    for item in block["channels"]:
        ch = item["channel"]
        g = item["growth"]
        out.append("<div class='card'>")
        out.append(f"<b>📺 {esc(ch.get('name') or ch.get('handle') or 'Kênh')}</b> <span class='muted'>{esc(ch.get('handle') or '')}</span>")
        out.append("<table><tr><th>Subs</th><th>Δ 24h</th><th>Δ 7 ngày</th><th>Video</th><th>Video mới 7 ngày</th><th>Quét cuối</th></tr>")
        scan = _parse_iso(ch.get("last_scan_at"))
        out.append(f"<tr><td>{_fmt_int(ch.get('subs'))}</td><td>{_delta(g.get('subs_delta_1d'))}</td>"
                   f"<td>{_delta(g.get('subs_delta_7d'))}</td><td>{_fmt_int(ch.get('video_count'))}</td>"
                   f"<td>{_delta(g.get('videos_delta_7d'))}</td><td>{scan.strftime('%d/%m %H:%M') if scan else '—'}</td></tr></table>")
        if item["commands"]:
            out.append("<table><tr><th>Việc</th><th>Trạng thái</th><th>Tiến độ</th><th>Bước cuối / kết quả</th></tr>")
            for c in item["commands"][:12]:
                label = COMMAND_TYPE_LABELS.get(c["type"], c["type"])
                detail = c.get("error") or c.get("result") or c.get("step") or ""
                out.append(f"<tr><td>{esc(label)} · {esc((c.get('instruction') or '')[:90])}</td><td>{esc(c['status'])}</td>"
                           f"<td>{int(c.get('progress') or 0)}%</td><td>{esc(str(detail)[:200])}</td></tr>")
            out.append("</table>")
        out.append("<b>Phân tích & đề xuất</b><ul>" + "".join(f"<li>{esc(n)}</li>" for n in item["notes"]) + "</ul>")
        out.append("</div>")
    return out


def reports_dir(data_dir: Path) -> Path:
    folder = Path(data_dir) / "reports"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def generate(store: Store, settings: dict | None = None, now: datetime | None = None) -> Path:
    now = now or datetime.now().astimezone()
    report = build(store, settings, now)
    path = reports_dir(store.db_file.parent) / f"bao-cao-{now:%Y-%m-%d}.html"
    path.write_text(render_html(report), encoding="utf-8")
    store.set_meta(META_KEY, now.strftime("%Y-%m-%d"))
    store.append_journal(f"📊 Đã tạo báo cáo kênh ngày {now:%d/%m/%Y}: {path.name}")
    return path


def due(store: Store, settings: dict, now: datetime | None = None) -> bool:
    """Đã tới giờ báo cáo hôm nay và hôm nay chưa tạo?"""
    if not settings.get("daily_report_enabled", True):
        return False
    now = now or datetime.now().astimezone()
    try:
        hh, mm = str(settings.get("daily_report_time") or "08:00").split(":")
        at = now.replace(hour=int(hh), minute=int(mm), second=0, microsecond=0)
    except ValueError:
        at = now.replace(hour=8, minute=0, second=0, microsecond=0)
    if now < at:
        return False
    return store.get_meta(META_KEY) != now.strftime("%Y-%m-%d")
