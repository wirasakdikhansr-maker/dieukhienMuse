"""Chẩn đoán khởi động (V3.1) — tự kiểm tra môi trường ngay khi mở app.

Các mục chẩn đoán (định dạng GIỐNG hệt mục kiểm tra hồ sơ của app.checks:
{key, label, status: ok/fail/na, detail}) để panel Kiểm tra hiển thị
chung một kiểu ✓ / ✗ / –:

- ``chrome``:       tìm thấy Google Chrome không (kể cả đường dẫn ép tay).
- ``agent_port``:   cổng Agent API có đang trống không (trước khi server mở).
- ``token``:        token của cầu nối Muse đã có trong settings chưa.
- ``data_writable``: thư mục dữ liệu có ghi được không.
- ``db_integrity``: PRAGMA integrity_check của kho SQLite.

``shape_diagnostics`` THUẦN dữ liệu (nhận probes đã thu) để kiểm thử
không cần IO; ``collect_diagnostics`` làm phần thu thập thật.
``run_startup_diagnostics`` chạy + lưu kết quả vào app_meta (khoá
``startup_diagnostics``) để panel Kiểm tra đọc lại, và trả về items.
"""

from __future__ import annotations

import json
import socket
import tempfile
from pathlib import Path

from . import config
from .store import Store, now_iso

META_KEY = "startup_diagnostics"

STATUS_OK = "ok"
STATUS_FAIL = "fail"
STATUS_NA = "na"


# --------------------------------------------------------------------------- #
# Thuần dữ liệu
# --------------------------------------------------------------------------- #
def shape_diagnostics(probes: dict) -> list[dict]:
    """Định hình danh sách mục chẩn đoán từ probes:

    - chrome_path: str | None — đường dẫn Chrome tìm thấy.
    - port_free: bool | None — cổng Agent API trống (None = chưa rõ).
    - agent_port: int — cổng đang xét (cho câu chữ chi tiết).
    - bind_host: str — interface dự kiến bind.
    - token_present: bool — settings đã có agent_token.
    - data_writable: bool — ghi thử vào thư mục dữ liệu thành công.
    - db_integrity: str | None — kết quả integrity_check ('ok' = lành).
    """
    items: list[dict] = []

    chrome_path = probes.get("chrome_path")
    items.append(
        {
            "key": "chrome",
            "label": "Tìm thấy Google Chrome",
            "status": STATUS_OK if chrome_path else STATUS_FAIL,
            "detail": f"Đường dẫn: {chrome_path}"
            if chrome_path
            else "Không tìm thấy Chrome — cài Chrome hoặc đặt đường dẫn "
            "trong Cài đặt > Trình duyệt & Nhúng.",
        }
    )

    port = probes.get("agent_port")
    host = probes.get("bind_host") or "0.0.0.0"
    port_free = probes.get("port_free")
    if port_free is None:
        port_status, port_detail = STATUS_NA, "Chưa kiểm tra được cổng Agent API."
    elif port_free:
        port_status = STATUS_OK
        port_detail = f"Cổng {port} ({host}) đang trống, sẵn sàng cho cầu nối."
    else:
        port_status = STATUS_FAIL
        port_detail = (
            f"Cổng {port} đang bị chiếm — Agent API có thể không mở được; "
            "đổi cổng trong Cài đặt > Cầu nối Muse."
        )
    items.append(
        {"key": "agent_port", "label": "Cổng Agent API trống", "status": port_status, "detail": port_detail}
    )

    token_present = bool(probes.get("token_present"))
    items.append(
        {
            "key": "token",
            "label": "Token cầu nối Muse",
            "status": STATUS_OK if token_present else STATUS_NA,
            "detail": "Đã có token riêng trong data/settings.json."
            if token_present
            else "Chưa có token — Agent API sẽ tự sinh khi khởi động.",
        }
    )

    writable = bool(probes.get("data_writable"))
    items.append(
        {
            "key": "data_writable",
            "label": "Thư mục dữ liệu ghi được",
            "status": STATUS_OK if writable else STATUS_FAIL,
            "detail": "Ghi thử thành công."
            if writable
            else "Không ghi được vào thư mục data/ — kiểm tra quyền thư mục.",
        }
    )

    integrity = probes.get("db_integrity")
    if integrity is None:
        db_status, db_detail = STATUS_NA, "Chưa kiểm tra được kho dữ liệu."
    elif integrity == "ok":
        db_status, db_detail = STATUS_OK, "Kho SQLite lành lặn (integrity_check = ok)."
    else:
        db_status = STATUS_FAIL
        db_detail = f"integrity_check báo: {integrity} — nên sao lưu/xuất dữ liệu sớm."
    items.append(
        {"key": "db_integrity", "label": "Toàn vẹn kho dữ liệu", "status": db_status, "detail": db_detail}
    )
    return items


def summarize_diagnostics(items: list[dict]) -> str:
    ok = sum(1 for i in items if i["status"] == STATUS_OK)
    fail = sum(1 for i in items if i["status"] == STATUS_FAIL)
    na = sum(1 for i in items if i["status"] == STATUS_NA)
    return f"Chẩn đoán khởi động: {ok} đạt, {fail} lỗi, {na} chưa rõ"


# --------------------------------------------------------------------------- #
# Thu thập probes thật
# --------------------------------------------------------------------------- #
def port_is_free(host: str, port: int) -> bool:
    """Thử bind thử (host, port): bind được = cổng trống."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind((host, int(port)))
        return True
    except OSError:
        return False
    finally:
        sock.close()


def data_dir_writable(base: Path) -> bool:
    try:
        base.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=str(base), delete=True) as probe:
            probe.write(b"ccd")
        return True
    except OSError:
        return False


def collect_probes(store: Store, settings: dict, base: Path | None = None) -> dict:
    base = base or config.data_dir()
    from .agent_server import DEFAULT_AGENT_PORT

    port = int(settings.get("agent_port", DEFAULT_AGENT_PORT))
    host = "127.0.0.1" if settings.get("agent_bind_localhost") else "0.0.0.0"
    try:
        integrity = store.integrity_check()
    except Exception:
        integrity = None
    return {
        "chrome_path": config.find_chrome(settings.get("chrome_path") or None),
        "agent_port": port,
        "bind_host": host,
        "port_free": port_is_free(host, port),
        "token_present": bool(str(settings.get("agent_token") or "").strip()),
        "data_writable": data_dir_writable(base),
        "db_integrity": integrity,
    }


def run_startup_diagnostics(store: Store, settings: dict, base: Path | None = None) -> list[dict]:
    """Chạy chẩn đoán, lưu vào app_meta cho panel Kiểm tra đọc lại."""
    probes = collect_probes(store, settings, base)
    items = shape_diagnostics(probes)
    payload = {"ts": now_iso(), "items": items, "summary": summarize_diagnostics(items)}
    try:
        store.set_meta(META_KEY, json.dumps(payload, ensure_ascii=False))
    except Exception:
        pass
    return items


def load_saved_diagnostics(store: Store) -> dict | None:
    """Đọc chẩn đoán đã lưu (panel Kiểm tra hiển thị ở lần mở app này)."""
    raw = store.get_meta(META_KEY)
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None
