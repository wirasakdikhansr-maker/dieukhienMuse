"""V6.9 — THAO TÁC HÀNG LOẠT trên lệnh + GIẢI THÍCH trạng thái (popup).

Dùng chung cho: menu chuột phải "Bảng việc chi tiết từng bước", bảng
Theo Agent, Kanban, bảng tiến độ theo hạn chót ở tab Giám sát.

- Các hàm ``bulk_*`` thuần dữ liệu (không hộp thoại) → kiểm thử được.
- ``explain_command`` trả lời "việc này KẸT GÌ / vì sao trễ / bước kế
  tiếp là gì" từ dữ liệu thật: lỗi, bước Muse báo cuối, tin nhắn cuối của
  Muse, quyết định cuối của trưởng phòng, hạn chót.
"""

from __future__ import annotations

import html
from datetime import datetime

from .store import COMMAND_TYPE_LABELS, Store, _parse_iso

OPEN_STATUSES = ("queued", "waiting_muse", "running", "needs_user")
CHAT_FLAGS = ("chat_sent", "acked", "chat_sent_at")

STATUS_VI = {
    "queued": "Xếp hàng", "waiting_muse": "Chờ Muse nhận", "running": "Đang làm",
    "needs_user": "Chờ người xử lý", "done": "Đã xong", "failed": "Thất bại",
    "interrupted": "Bị ngắt", "cancelled": "Đã huỷ",
}


def _fresh(store: Store, ids) -> list[dict]:
    out, seen = [], set()
    for cid in ids or []:
        cid = str(cid)
        if not cid or cid in seen:
            continue
        seen.add(cid)
        row = store.get_command(cid)
        if row is not None:
            out.append(row)
    return out


# --------------------------------------------------------------------------- #
# Hàng loạt
# --------------------------------------------------------------------------- #
def bulk_delete(store: Store, ids) -> dict:
    """Xoá mọi lệnh KHÔNG đang chạy. Trả {deleted, kept_running}."""
    deleted = kept = 0
    for row in _fresh(store, ids):
        if row["status"] == "running":
            kept += 1
            continue
        store.delete_command(row["id"])
        deleted += 1
    return {"deleted": deleted, "kept_running": kept}


def bulk_assign(store: Store, ids, agent_id: int) -> dict:
    """Giao (lại) N lệnh cho MỘT Muse: ghi danh, phân công hồ sơ đích,
    xoá cờ chat để cầu nối gửi lại TRỌN nội dung việc cho người mới.
    Lệnh đang làm/chờ người của người cũ → về 'waiting_muse'.
    Lệnh đã kết thúc (xong/thất bại/huỷ) bỏ qua."""
    assigned = skipped = 0
    profiles_added = 0
    for row in _fresh(store, ids):
        if row["status"] not in OPEN_STATUSES and row["status"] not in ("failed", "interrupted"):
            skipped += 1
            continue
        if row["status"] in ("failed", "interrupted"):
            store.requeue_command(row["id"])
        elif row["status"] == "needs_user":
            store.resume_command(row["id"])
        store.set_command_agent(row["id"], int(agent_id))
        if row.get("profile_id"):
            try:
                if store.ensure_agent_assignment(int(agent_id), int(row["profile_id"])):
                    profiles_added += 1
            except Exception:
                pass
        store.update_command_payload_flags(row["id"], clear_keys=CHAT_FLAGS)
        fresh = store.get_command(row["id"])
        if fresh and fresh["status"] == "running":
            store.update_command(row["id"], status="waiting_muse")
        assigned += 1
    return {"assigned": assigned, "skipped": skipped, "profiles_added": profiles_added}


def bulk_resume(store: Store, ids) -> dict:
    """Chờ người → chạy tiếp; thất bại/bị ngắt → thử lại."""
    resumed = skipped = 0
    for row in _fresh(store, ids):
        result = None
        if row["status"] == "needs_user":
            result = store.resume_command(row["id"])
        elif row["status"] in ("failed", "interrupted"):
            result = store.requeue_command(row["id"])
        if result is None:
            skipped += 1
            continue
        store.update_command_payload_flags(row["id"], clear_keys=CHAT_FLAGS)
        resumed += 1
    return {"resumed": resumed, "skipped": skipped}


def bulk_resend(store: Store, ids) -> dict:
    """Gửi lại TRỌN nội dung việc qua chat muse.ai (xoá cờ đã gửi/đã nhận)."""
    count = skipped = 0
    for row in _fresh(store, ids):
        if row["status"] not in OPEN_STATUSES:
            skipped += 1
            continue
        if row["status"] == "needs_user":
            store.resume_command(row["id"])
        store.update_command_payload_flags(row["id"], clear_keys=CHAT_FLAGS)
        fresh = store.get_command(row["id"])
        if fresh and fresh["status"] == "running":
            store.update_command(row["id"], status="waiting_muse")
        count += 1
    return {"resent": count, "skipped": skipped}


def bulk_extend(store: Store, ids, minutes: int = 60) -> dict:
    count = 0
    for row in _fresh(store, ids):
        if row["status"] in OPEN_STATUSES and store.extend_command_due(row["id"], minutes) is not None:
            count += 1
    return {"extended": count}


def bulk_cancel(store: Store, ids, cancel_one) -> dict:
    """``cancel_one(command) -> bool`` là đường huỷ chuẩn của
    CommandsPanel (_cancel_one) — huỷ cả lệnh đang chạy qua bộ chạy nền."""
    cancelled = skipped = 0
    for row in _fresh(store, ids):
        if row["status"] not in OPEN_STATUSES:
            skipped += 1
            continue
        try:
            ok = bool(cancel_one(row))
        except Exception:
            ok = False
        if ok:
            cancelled += 1
        else:
            skipped += 1
    return {"cancelled": cancelled, "skipped": skipped}


def summarize_selection(store: Store, ids) -> dict:
    rows = _fresh(store, ids)
    counts: dict[str, int] = {}
    for row in rows:
        counts[row["status"]] = counts.get(row["status"], 0) + 1
    return {
        "total": len(rows),
        "counts": counts,
        "open": sum(counts.get(s, 0) for s in OPEN_STATUSES),
        "running": counts.get("running", 0),
        "resumable": counts.get("needs_user", 0) + counts.get("failed", 0) + counts.get("interrupted", 0),
        "deletable": len(rows) - counts.get("running", 0),
    }


# --------------------------------------------------------------------------- #
# Giải thích trạng thái (popup khi rê chuột)
# --------------------------------------------------------------------------- #
def _ago(value, now: datetime) -> str:
    at = _parse_iso(value) if value else None
    if at is None:
        return ""
    seconds = int((now - at).total_seconds())
    if seconds < 0:
        seconds = -seconds
        if seconds < 3600:
            return f"còn {max(1, seconds // 60)} phút"
        if seconds < 86400:
            return f"còn {seconds // 3600} giờ {seconds % 3600 // 60} phút"
        return f"còn {seconds // 86400} ngày"
    if seconds < 60:
        return "vừa xong"
    if seconds < 3600:
        return f"{seconds // 60} phút trước"
    if seconds < 86400:
        return f"{seconds // 3600} giờ {seconds % 3600 // 60} phút trước"
    return f"{seconds // 86400} ngày trước"


def _last_muse_message(store: Store, command: dict) -> str:
    agent_id = command.get("agent_id")
    if not agent_id:
        return ""
    try:
        messages = store.list_messages(int(agent_id), limit=40)
    except TypeError:
        try:
            messages = store.list_messages(int(agent_id))
        except Exception:
            return ""
    except Exception:
        return ""
    for message in reversed(messages or []):
        if message.get("command_id") == command["id"] and message.get("direction") == "agent":
            return (message.get("body") or "").strip()
    return ""


def _last_lead_decision(store: Store, command_id: str) -> dict | None:
    try:
        row = store._conn.execute(
            "SELECT * FROM lead_decisions WHERE command_id = ? ORDER BY id DESC LIMIT 1",
            (command_id,),
        ).fetchone()
        return dict(row) if row else None
    except Exception:
        return None


def explain_command(store: Store, command_id: str, now: datetime | None = None) -> dict:
    """Trả {headline, reason, lines:[(nhãn, nội dung)], next} — vì sao việc
    ở trạng thái này, kẹt gì, bước kế tiếp."""
    now = now or datetime.now().astimezone()
    command = store.get_command(str(command_id)) if command_id else None
    if command is None:
        return {"headline": "Không còn việc này", "reason": "", "lines": [], "next": ""}
    status = command["status"]
    payload = command.get("payload") or {}
    label = COMMAND_TYPE_LABELS.get(command["type"], command["type"])
    agent = store.get_agent(int(command["agent_id"])) if command.get("agent_id") else None
    agent_name = (agent or {}).get("name") or "chưa có Muse"
    lines: list[tuple[str, str]] = []
    reason = ""
    nxt = ""
    error = (command.get("error") or "").strip()
    step = (command.get("step") or "").strip()
    muse_said = _last_muse_message(store, command)
    due = _parse_iso(command.get("due_at")) if command.get("due_at") else None

    if status == "needs_user":
        reason = error or step or "Muse dừng lại và cần người xác nhận / cung cấp thêm thông tin."
        nxt = "Trưởng phòng sẽ tự xử lý (toàn quyền); hoặc bấm ▶ Chạy tiếp / 🎯 Giao lại."
    elif status == "failed":
        reason = error or "Muse báo LỖI hoặc hết số lần thử."
        nxt = "↻ Thử lại, hoặc 🎯 giao cho Muse khác."
    elif status == "interrupted":
        reason = error or "App/Chrome tắt khi việc đang chạy."
        nxt = "↻ Thử lại — app sẽ gửi lại trọn nội dung việc."
    elif status == "waiting_muse":
        if not payload.get("chat_sent"):
            reason = "Chưa gửi việc qua chat muse.ai (đang chờ tới lượt / ngoài giờ làm việc / Muse đang bận 2 việc)."
        elif not payload.get("acked"):
            sent = _ago(payload.get("chat_sent_at"), now)
            reason = f"Đã gửi việc {sent} nhưng Muse CHƯA trả lời \"ĐÃ NHẬN\"."
            nxt = "Trưởng phòng tự nhắc sau 3 phút, quá 2 lần sẽ giao người khác."
        else:
            reason = "Muse đã nhận việc, đang chờ báo tiến độ đầu tiên."
    elif status == "queued":
        reason = step or "Đang xếp hàng chờ điều kiện (hồ sơ có Muse phụ trách, giới hạn song song)."
    elif status == "running":
        updated = _parse_iso(command.get("updated_at"))
        quiet = int((now - updated).total_seconds() // 60) if updated else 0
        reason = step or "Muse đang làm."
        if quiet >= 15:
            reason += f" — {quiet} phút chưa báo tiến độ mới."
            nxt = "Trưởng phòng sẽ hỏi tiến độ; không trả lời → giao lại."
    elif status == "done":
        reason = (command.get("result") or "Đã báo KẾT QUẢ.").strip()
    else:
        reason = error or step or STATUS_VI.get(status, status)

    if due is not None and status in OPEN_STATUSES:
        left = int((due - now).total_seconds())
        if left < 0:
            lines.append(("⏰ Hạn", f"TRỄ {_ago(command.get('due_at'), now).replace(' trước', '')} (hạn {due.strftime('%d/%m %H:%M')})"))
        else:
            lines.append(("⏰ Hạn", f"{due.strftime('%d/%m %H:%M')} · {_ago(command.get('due_at'), now)}"))
    elif status in OPEN_STATUSES:
        lines.append(("⏰ Hạn", "chưa đặt hạn"))
    lines.append(("👤 Muse", agent_name))
    lines.append(("📊 Tiến độ", f"{int(command.get('progress') or 0)}%" + (f" · {step}" if step and step not in reason else "")))
    if error and error not in reason:
        lines.append(("✕ Lỗi", error))
    if muse_said:
        lines.append(("💬 Muse nói", muse_said))
    decision = _last_lead_decision(store, command["id"])
    if decision:
        lines.append(("🧑‍💼 Trưởng phòng", f"{decision.get('detail') or decision.get('action')} ({_ago(decision.get('at'), now)})"))
    if payload.get("resend_count"):
        lines.append(("📨 Đã gửi lại", f"{payload['resend_count']} lần"))
    return {
        "headline": f"{label} · #{command['id'][:8]} — {STATUS_VI.get(status, status)}",
        "reason": reason,
        "lines": lines,
        "next": nxt,
    }


def _clip(text: str, n: int = 260) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= n else text[: n - 1] + "…"


def explain_html(store: Store, command_id: str, now: datetime | None = None) -> str:
    info = explain_command(store, command_id, now)
    parts = [f"<b>{html.escape(info['headline'])}</b>"]
    if info["reason"]:
        parts.append(f"<div style='color:#F2C94C;margin-top:4px'>⚠ {html.escape(_clip(info['reason']))}</div>")
    rows = "".join(
        f"<tr><td style='color:#9AA3AD;padding-right:8px;white-space:nowrap'>{html.escape(k)}</td>"
        f"<td>{html.escape(_clip(v, 200))}</td></tr>"
        for k, v in info["lines"]
    )
    if rows:
        parts.append(f"<table style='margin-top:4px'>{rows}</table>")
    if info["next"]:
        parts.append(f"<div style='color:#7DDC7A;margin-top:4px'>→ {html.escape(info['next'])}</div>")
    return "<qt>" + "".join(parts) + "</qt>"


def group_html(store: Store, title: str, command_ids, limit: int = 8, now: datetime | None = None) -> str:
    """Popup cho NÚT ĐẾM (Đang kẹt · 3, Sắp trễ…): liệt kê từng việc + lý do."""
    ids = [str(c) for c in command_ids or []]
    if not ids:
        return f"<qt><b>{html.escape(title)}</b><br><span style='color:#9AA3AD'>Không có việc nào.</span></qt>"
    now = now or datetime.now().astimezone()
    items = []
    for cid in ids[:limit]:
        info = explain_command(store, cid, now)
        who = next((v for k, v in info["lines"] if k == "👤 Muse"), "")
        items.append(
            f"<li><b>{html.escape(info['headline'].split(' — ')[0])}</b>"
            + (f" · {html.escape(who)}" if who else "")
            + f"<br><span style='color:#F2C94C'>{html.escape(_clip(info['reason'], 160))}</span></li>"
        )
    more = f"<div style='color:#9AA3AD'>+{len(ids) - limit} việc nữa…</div>" if len(ids) > limit else ""
    return (f"<qt><b>{html.escape(title)} — {len(ids)} việc</b>"
            f"<ul style='margin-left:-20px'>{''.join(items)}</ul>{more}"
            "<div style='color:#9AA3AD'>Bấm để lọc · chuột phải để xử lý hàng loạt</div></qt>")


# --------------------------------------------------------------------------- #
# Popup lười: dựng HTML đúng lúc rê chuột (dùng cho nút/pill đếm)
# --------------------------------------------------------------------------- #
_LAZY_FILTER = None


def attach_lazy_tooltip(widget, provider) -> None:
    """Gắn ``provider() -> html`` cho widget; HTML chỉ dựng khi rê chuột."""
    global _LAZY_FILTER
    from PySide6.QtCore import QEvent, QObject
    from PySide6.QtWidgets import QToolTip

    if _LAZY_FILTER is None:
        class _LazyTip(QObject):
            def eventFilter(self, obj, event):
                if event.type() == QEvent.Type.ToolTip:
                    fn = getattr(obj, "_ccd_tip_provider", None)
                    if fn is not None:
                        try:
                            QToolTip.showText(event.globalPos(), fn(), obj)
                            return True
                        except Exception:
                            return False
                return False

        _LAZY_FILTER = _LazyTip()
    widget._ccd_tip_provider = provider
    if not getattr(widget, "_ccd_tip_installed", False):
        widget.installEventFilter(_LAZY_FILTER)
        widget._ccd_tip_installed = True
