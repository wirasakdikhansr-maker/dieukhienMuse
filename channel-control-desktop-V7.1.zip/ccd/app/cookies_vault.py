"""Kho cookies đăng nhập theo hồ sơ (V3.2).

Mỗi hồ sơ (một Gmail) có một file cookies riêng tại
``data/cookies/<slug>.json``. Ba nguồn vào:

1. Người dùng NHẬP file cookies có sẵn (JSON kiểu EditThisCookie /
   "Get cookies.txt" hoặc file Netscape cookies.txt) — hỗ trợ đăng nhập
   kênh Gmail bằng cookies mà không cần gõ mật khẩu trong app.
2. App TỰ XUẤT cookies từ Chrome của hồ sơ sau mỗi lần quét thành công
   (chỉ giữ domain Google/YouTube) để lần sau tự nạp lại.
3. Muse gửi qua Agent API (cùng bộ phân tích như nguồn 1).

Định dạng chuẩn nội bộ của một cookie::

    {"name", "value", "domain", "path", "expires" (epoch|None),
     "secure", "http_only", "same_site" ('Lax'|'Strict'|'None'|None),
     "host_only"}

LƯU Ý AN TOÀN: giá trị cookie là bí mật phiên đăng nhập. Module này
không bao giờ in/ghi log giá trị cookie; phần tóm tắt (summarize) chỉ
trả TÊN cookie và số đếm.
"""

from __future__ import annotations

import json
import time
from datetime import datetime

from . import config

# Tên cookie xác thực quen thuộc của Google — chỉ dùng để BÁO có/không.
AUTH_COOKIE_NAMES = (
    "SID",
    "HSID",
    "SSID",
    "APISID",
    "SAPISID",
    "__Secure-1PSID",
    "__Secure-3PSID",
    "__Secure-1PAPISID",
    "__Secure-3PAPISID",
    "LOGIN_INFO",
)

_GOOGLE_BASE_DOMAINS = ("google.com", "youtube.com", "gmail.com", "googleapis.com")

_SAMESITE_MAP = {
    "lax": "Lax",
    "strict": "Strict",
    "none": "None",
    "no_restriction": "None",
    "unspecified": None,
    "": None,
}


def is_google_youtube_domain(domain: str | None) -> bool:
    """Cookie thuộc hệ Google/YouTube? (gồm domain quốc gia google.*)"""
    base = (domain or "").strip().lstrip(".").lower()
    if not base:
        return False
    if "google." in base or "youtube." in base:
        return True
    return any(base == d or base.endswith("." + d) for d in _GOOGLE_BASE_DOMAINS)


# --------------------------------------------------------------------------- #
# Chuẩn hoá + chuyển đổi CDP
# --------------------------------------------------------------------------- #
def _norm_same_site(raw) -> str | None:
    if raw is None:
        return None
    return _SAMESITE_MAP.get(str(raw).strip().lower(), None)


def _norm_expires(raw) -> float | None:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return None
    return value if value > 0 else None


def normalize_cookie(raw: dict) -> dict | None:
    """Chuẩn hoá một cookie từ bất kỳ nguồn nào (CDP / EditThisCookie /
    JSON phổ thông) về định dạng nội bộ. None nếu thiếu name/value/domain."""
    if not isinstance(raw, dict):
        return None
    name = str(raw.get("name") or "").strip()
    value = raw.get("value")
    domain = str(raw.get("domain") or "").strip()
    if not name or value is None or not domain:
        return None
    expires = _norm_expires(
        raw.get("expires", raw.get("expirationDate", raw.get("expiry")))
    )
    if raw.get("session"):
        expires = None
    return {
        "name": name,
        "value": str(value),
        "domain": domain,
        "path": str(raw.get("path") or "/"),
        "expires": expires,
        "secure": bool(raw.get("secure", False)),
        "http_only": bool(raw.get("httpOnly", raw.get("http_only", False))),
        "same_site": _norm_same_site(raw.get("sameSite", raw.get("same_site"))),
        "host_only": bool(raw.get("hostOnly", raw.get("host_only", False))),
    }


def to_cdp_cookie(cookie: dict) -> dict:
    """Định dạng nội bộ -> tham số cho CDP Storage.setCookies."""
    params = {
        "name": cookie["name"],
        "value": cookie["value"],
        "domain": cookie["domain"],
        "path": cookie.get("path") or "/",
        "secure": bool(cookie.get("secure")),
        "httpOnly": bool(cookie.get("http_only")),
    }
    if cookie.get("expires"):
        params["expires"] = float(cookie["expires"])
    same_site = cookie.get("same_site")
    if same_site in ("Lax", "Strict", "None"):
        params["sameSite"] = same_site
        if same_site == "None":
            params["secure"] = True
    return params


def filter_google_youtube(cookies: list[dict]) -> list[dict]:
    return [c for c in cookies if is_google_youtube_domain(c.get("domain"))]


# --------------------------------------------------------------------------- #
# Đọc file cookies người dùng cung cấp
# --------------------------------------------------------------------------- #
def parse_cookies_bytes(data: bytes) -> list[dict]:
    """Đọc cookies từ nội dung file: JSON (mảng / {'cookies': [...]} /
    EditThisCookie) hoặc Netscape cookies.txt. Trả về list đã chuẩn hoá
    (có thể rỗng nếu file không đọc được)."""
    if not data:
        return []
    text = data.decode("utf-8", errors="replace").strip()
    if not text:
        return []
    if text.startswith(("{", "[")):
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError:
            parsed = None
        if parsed is not None:
            if isinstance(parsed, dict):
                parsed = parsed.get("cookies") or parsed.get("data") or []
            if isinstance(parsed, list):
                return [c for c in (normalize_cookie(r) for r in parsed) if c]
    return _parse_netscape(text)


def _parse_netscape(text: str) -> list[dict]:
    cookies: list[dict] = []
    for line in text.splitlines():
        line = line.rstrip("\n")
        if not line.strip():
            continue
        http_only = False
        if line.startswith("#HttpOnly_"):
            http_only = True
            line = line[len("#HttpOnly_"):]
        elif line.startswith("#"):
            continue
        parts = line.split("\t")
        if len(parts) < 7:
            continue
        domain, _flag, path, secure, expires, name, value = parts[:7]
        cookie = normalize_cookie(
            {
                "name": name,
                "value": value,
                "domain": domain,
                "path": path or "/",
                "secure": secure.upper() == "TRUE",
                "expires": _norm_expires(expires),
                "httpOnly": http_only,
                "hostOnly": not domain.startswith("."),
            }
        )
        if cookie:
            cookies.append(cookie)
    return cookies


def normalize_cdp_cookies(raw_cookies: list[dict]) -> list[dict]:
    """Cookie thô từ CDP Storage.getCookies -> định dạng nội bộ."""
    return [c for c in (normalize_cookie(r) for r in raw_cookies or []) if c]


# --------------------------------------------------------------------------- #
# Lưu / đọc kho theo hồ sơ
# --------------------------------------------------------------------------- #
def save_cookies(slug: str, cookies: list[dict], source: str = "", base=None) -> dict:
    """Ghi kho cookies của hồ sơ. Trả về tóm tắt (không kèm giá trị)."""
    path = config.cookies_path(slug, base)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "slug": slug,
        "saved_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "source": source,
        "cookies": cookies,
    }
    path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
    return summarize_payload(payload)


def load_cookies(slug: str, base=None) -> dict | None:
    """Đọc kho cookies của hồ sơ (dict đầy đủ gồm 'cookies'). None nếu
    chưa có file / file hỏng."""
    path = config.cookies_path(slug, base)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(payload, dict) or not isinstance(payload.get("cookies"), list):
        return None
    payload["cookies"] = [
        c for c in (normalize_cookie(r) for r in payload["cookies"]) if c
    ]
    return payload


def summarize_payload(payload: dict | None) -> dict:
    """Tóm tắt an toàn của một kho cookies: số lượng, domain, TÊN cookie
    xác thực đang có, mốc lưu — tuyệt đối không có giá trị cookie."""
    if not payload:
        return {
            "exists": False,
            "count": 0,
            "saved_at": None,
            "source": "",
            "domains": [],
            "auth_cookies": [],
            "expired": 0,
        }
    cookies = payload.get("cookies") or []
    now = time.time()
    names = {c.get("name") for c in cookies}
    return {
        "exists": True,
        "count": len(cookies),
        "saved_at": payload.get("saved_at"),
        "source": payload.get("source") or "",
        "domains": sorted({(c.get("domain") or "") for c in cookies if c.get("domain")}),
        "auth_cookies": [n for n in AUTH_COOKIE_NAMES if n in names],
        "expired": sum(
            1 for c in cookies if c.get("expires") and c["expires"] < now
        ),
    }


def summarize(slug: str, base=None) -> dict:
    return summarize_payload(load_cookies(slug, base))
