"""V7.0 — TRƯỞNG PHÒNG TRẢ LỜI THAY CHỦ KÊNH mọi câu hỏi của agent.

Agent hỏi "đăng luôn hay nháp?", "làm mấy bài?", "chủ đề gì?"… → KHÔNG đẩy
về người dùng nữa:

1. Có trưởng phòng (một Muse khác, đang dùng được) → app chuyển câu hỏi kèm
   bối cảnh việc + CHÍNH SÁCH TỰ QUYẾT cho trưởng phòng qua chat muse.ai; câu
   trả lời của trưởng phòng được chuyển thẳng lại cho agent, việc chạy tiếp.
2. Không có trưởng phòng / trưởng phòng im quá ``LEAD_ANSWER_WAIT_MIN`` phút →
   app trả lời bằng CHÍNH SÁCH TỰ QUYẾT (cài đặt được) và bắt agent tự chọn
   phương án hợp lý nhất cho từng ý, ghi rõ lựa chọn trong báo cáo.
3. Chỉ những việc CHỈ NGƯỜI THẬT làm được (mã 2FA/OTP, mật khẩu, thanh toán,
   captcha bằng điện thoại…) mới còn đến tay người dùng.
"""

from __future__ import annotations

import re

LEAD_ANSWER_WAIT_MIN = 3
LEAD_TAG = "[Trưởng phòng]"

DEFAULT_POLICY = """\
- Bạn có TOÀN QUYỀN quyết định thay chủ kênh. Không hỏi lại, không chờ duyệt.
- Chủ đề/nội dung: tự chọn theo ngách và phong cách của kênh/page, tránh trùng 10 bài gần nhất; ưu tiên chủ đề đang lên.
- Định dạng: theo skill/việc được giao; không nói rõ thì làm video dọc 60–90 giây (Shorts/Reels/TikTok) + tiêu đề, mô tả, hashtag.
- Đăng: ĐĂNG CÔNG KHAI luôn khi đã đủ tiêu đề, mô tả, ảnh bìa; thiếu gì thì tự tạo cho đủ rồi đăng.
- Số lượng & giờ đăng: theo lệnh; không nói thì 1 bài/ngày, khung 19:00–21:00 giờ của khán giả chính.
- Ngôn ngữ: theo ngôn ngữ kênh/page.
- Tài khoản cá nhân quản lý page: chuyển sang đúng page rồi làm; không tìm thấy page thì dùng page đầu tiên tài khoản đang quản lý và ghi rõ.
- Chỉ dừng lại khi cần thứ CHỈ chủ kênh có: mã 2FA/OTP, mật khẩu, thanh toán, xác minh bằng điện thoại."""

_HUMAN_ONLY = re.compile(
    r"\b(2fa|otp|mã xác (minh|nhận|thực)|verification code|security code|captcha|"
    r"mật khẩu|password|thẻ (tín dụng|ngân hàng)|thanh toán|payment|số điện thoại|"
    r"xác minh (danh tính|bằng điện thoại)|passkey|authenticator)\b",
    re.IGNORECASE,
)
_ANSWER_HEAD = re.compile(r"^\s*(TRẢ LỜI|TRA LOI|ANSWER)\b[^:\n]{0,40}:\s*", re.IGNORECASE | re.MULTILINE)


def policy(settings: dict | None) -> str:
    text = str((settings or {}).get("lead_policy") or "").strip()
    return text or DEFAULT_POLICY


def human_only(text: str) -> bool:
    """Câu hỏi CHỈ người thật trả lời được (mã/mật khẩu/thanh toán…)."""
    return bool(_HUMAN_ONLY.search(text or ""))


def _clip(text: str, n: int) -> str:
    text = (text or "").strip()
    return text if len(text) <= n else text[: n - 1] + "…"


def lead_prompt(command: dict, asker: str, question: str, settings: dict | None = None) -> str:
    """Tin gửi cho TRƯỞNG PHÒNG (Muse) nhờ quyết định thay chủ kênh."""
    from .lead_autopilot import task_summary

    return (
        f"{LEAD_TAG} Agent {asker} đang làm việc #{command['id']} và HỎI chủ kênh. "
        "Bạn là trưởng phòng, có toàn quyền quyết định THAY chủ kênh.\n\n"
        f"VIỆC: {_clip(task_summary(command, 600), 600)}\n\n"
        f"{asker} HỎI:\n{_clip(question, 2500)}\n\n"
        f"CHÍNH SÁCH TỰ QUYẾT:\n{policy(settings)}\n\n"
        f"Trả lời NGAY, cụ thể từng ý, theo mẫu:\nTRẢ LỜI #{command['id']}: <quyết định cho từng ý>\n"
        "Không hỏi lại chủ kênh."
    )


def extract_answer(text: str) -> str:
    """Lấy phần quyết định trong câu trả lời của trưởng phòng."""
    text = (text or "").strip()
    match = _ANSWER_HEAD.search(text)
    if match:
        text = text[match.end():]
    return _clip(text, 3000)


def forward_text(command: dict, answer: str, by_lead: bool = True) -> str:
    """Tin gửi lại cho AGENT: câu trả lời + lệnh làm tiếp."""
    who = "Trưởng phòng quyết định" if by_lead else "Trưởng phòng quyết định theo chính sách tự quyết"
    return (
        f"{LEAD_TAG} {who} cho việc #{command['id']}:\n{answer.strip()}\n\n"
        "Làm tiếp NGAY theo quyết định này, không hỏi lại. Báo TIẾN ĐỘ: x% — bước đang làm; "
        "xong thì KẾT QUẢ: … kèm link/bằng chứng."
    )


def policy_answer(command: dict, question: str, settings: dict | None = None) -> str:
    """Trả lời KHÔNG cần AI: chính sách tự quyết + bắt agent tự chọn từng ý."""
    return (
        "Mọi câu hỏi trong tin của bạn: TỰ QUYẾT theo chính sách dưới đây, chọn phương án hợp lý nhất "
        "cho từng ý và GHI RÕ lựa chọn trong báo cáo.\n" + policy(settings)
    )


def continue_text(command: dict, note: str = "") -> str:
    """Tin ngắn khi việc ĐÃ được nhận trước đó và nay chạy tiếp — KHÔNG gửi
    lại trọn nội dung (tránh "tin này được gửi lại lần thứ ba")."""
    from .lead_autopilot import task_summary

    body = f"{LEAD_TAG} Tiếp tục việc #{command['id']} ({_clip(task_summary(command, 160), 160)})."
    if note:
        body += f"\n{note.strip()}"
    body += "\nLàm tiếp từ bước đang dở, không hỏi lại. Báo TIẾN ĐỘ: x% — bước đang làm."
    return body
