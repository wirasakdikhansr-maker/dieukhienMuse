"""Cấu hình đường dẫn, slug và cổng — chỉ dùng thư viện chuẩn (không phụ thuộc Qt).

Quy ước tất định (deterministic) từ slug của hồ sơ:
- Thư mục Chrome user-data:  <data_dir>/profiles/<slug>/
- Cổng remote-debugging:    19400 + crc32(slug) % 500   (khoảng 19400–19899)

Thư mục dữ liệu mặc định là ``data/`` ngay trong thư mục dự án; có thể đổi
bằng biến môi trường ``CCD_DATA_DIR``. Đường dẫn Chrome có thể ép bằng
``CCD_CHROME_PATH``.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import unicodedata
import zlib
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

PORT_BASE = 19400
PORT_SPAN = 500

DEFAULT_SETTINGS = {
    # True = đóng app KHÔNG tắt các cửa sổ Chrome đã mở (mặc định).
    "keep_chrome_open_on_exit": True,
    # V3 (Tự động): True = khi mở app, tự mở Chrome cho mọi hồ sơ
    # đang hoạt động. V5.3 (A7 — lệnh chủ kênh): mặc định MỚI là
    # BẬT — trình duyệt khởi động CÙNG tool; giá trị False do
    # người dùng ĐÃ LƯU trước đây vẫn được tôn trọng (chỉ mặc
    # định cho cài đặt chưa từng lưu khoá này mới đổi).
    "auto_open_browsers_on_start": False,  # V6.7: trình duyệt chỉ mở khi cần
    # V5.3 (A8 — ngoại lệ chủ kênh ra lệnh cho quy tắc chỉ-nhúng):
    # True = trình duyệt chạy ẨN NGOÀI app (cửa sổ riêng/thu nhỏ,
    # không nhúng vào app, điều khiển qua CDP như thường).
    "browsers_hidden_mode": False,
    # V5.3 (A9): ảnh nền Văn phòng tuỳ chọn — đường dẫn file ĐÃ
    # SAO vào data/office_bg/ (rỗng = nền đóng gói office_floor).
    "office_bg_image": "",
    # V5.3.1 (M2 — góp ý máy thật 30/10): kích thước ô tường trình
    # duyệt + độ cao nút hàng lệnh do NGƯỜI DÙNG chỉnh trong Cài
    # đặt → Giao diện (trước đây là hằng số cứng trong code). Dải
    # chặn nằm ở helper đọc (browser_wall.tile_size /
    # theme.row_action_height) — một nguồn sự thật cho cả hai.
    "wall_tile_width": 600,
    "wall_tile_height": 800,
    "row_action_button_height": 24,
    # V5.3.1 (M3): hình học panel chi tiết Văn phòng do người dùng
    # kéo tay — bề rộng panel (splitter ngang) và chiều cao luồng
    # chat khi bung (splitter dọc). 0 ở khoá chat = chưa từng kéo,
    # dùng mặc định OFFICE_THREAD_MAX_HEIGHT của agent_chat.
    "office_detail_width": 320,
    "office_chat_thread_height": 0,
    "embed_browser_always": True,
    # Nhịp luồng trực tiếp (khung hình/giây): khi cửa sổ app đang focus
    # và khi không focus (adaptive — giảm tải khi không nhìn).
    "live_fps_active": 5.0,
    "live_fps_idle": 1.0,
    # V3.1 — Cầu nối Muse (Agent API): cổng lắng nghe (xem app.agent_server),
    # chỉ nghe localhost (127.0.0.1) thay vì mọi interface, và đường dẫn
    # Chrome ép tay (rỗng = tự dò). agent_token KHÔNG có mặc định ở đây —
    # app.agent_server.ensure_agent_token tự sinh + lưu lần đầu.
    "agent_port": 19500,
    "agent_bind_localhost": False,
    # V4.0 — Vòng tự động cho lệnh chờ Muse (dispatcher + sweeper lease
    # chạy trong worker của Agent API, xem app.dispatcher/app.lease_sweeper):
    # công tắc tổng + hạn lease + số lần giữ-lệnh-mất-dấu tối đa trước
    # khi chốt failed + mốc phút cảnh báo "chờ quá lâu chưa ai nhận".
    "full_auto_enabled": True,
    # V6.0 — GIÁM SÁT CHÉO giữa các tài khoản Muse (UI_V60_PLAN):
    # công tắc tổng; ngưỡng phút không-báo-tiến-độ bị watchdog coi là
    # "nghi treo"; tỷ lệ % lệnh 'done' bị lấy mẫu kiểm tra (lệnh
    # 'failed' luôn kiểm tra 100%, lệnh đã làm lại luôn kiểm tra lại);
    # số vòng làm lại tối đa trước khi leo thang needs_user; ma trận
    # giám sát ghi tay {agent_id_người_làm: agent_id_giám_sát} dạng
    # chuỗi JSON-safe — rỗng/thiếu mục = vòng chéo mặc định theo id.
    "supervision_enabled": True,
    "supervision_stall_minutes": 10,
    "supervision_sample_percent": 100,
    "supervision_max_rounds": 2,
    "supervision_matrix": {},
    # V6.1: chế độ giám sát — "lead" (một TRƯỞNG PHÒNG giám sát mọi
    # tài khoản khác) hoặc "ring" (vòng chéo cũ). Trưởng phòng chưa
    # chọn (0) thì tự rơi về vòng chéo.
    "supervision_mode": "lead",
    "supervision_lead_agent_id": 0,
    # Hạn chót (phút) theo loại lệnh — ghi đè DEFAULT_DEADLINE_MINUTES.
    "deadline_minutes": {},
    # Cảnh báo "sắp trễ" khi thời gian đã dùng ≥ % này của hạn mà
    # tiến độ còn thấp hơn.
    "deadline_warn_percent": 75,
    # V6.3 — Quy tắc & KPI: rỗng = dùng bộ mặc định trong app/kpi.py.
    "rules_agent": "",
    "rules_supervisor": "",
    "kpi_targets": {},
    "kpi_enforce": True,
    # Trưởng phòng TỰ xử lý sự cố trong phạm vi cho phép + tự thay
    # trưởng phòng khi KPI dưới ngưỡng liên tiếp (app/lead_autopilot.py).
    "lead_auto_fix": True,
    "lead_auto_replace": True,
    "lead_extend_minutes": 30,
    "lead_max_auto_retries": 2,
    # Chat tức thì: tin người dùng gửi trong app được ĐẨY thẳng vào ô
    # chat muse.ai trong Chrome riêng của tài khoản (đánh thức Muse
    # ngay thay vì chờ Muse tự hỏi lại theo nhịp của nó).
    "chat_push_to_muse": True,
    # V6.4.2: Muse mất kết nối → tự nhắc kết nối lại qua muse.ai (+ tự
    # đăng nhập lại muse.ai nếu phiên đã văng); cầu nối không phản hồi →
    # tự khởi động lại.
    "auto_reconnect_muse": True,
    # Báo cáo kênh hằng ngày (giờ địa phương HH:MM).
    "daily_report_enabled": True,
    "daily_report_time": "08:00",
    # Hồ sơ: tự tắt Chrome không ai dùng sau N phút (0 = tắt tính năng).
    "browser_idle_close_minutes": 15,
    "muse_idle_close_minutes": 10,   # V6.7: tắt Chrome muse.ai rảnh quá N phút
    "muse_max_browsers": 6,          # V6.7: tối đa N Chrome muse.ai mở cùng lúc
    "lead_full_authority": True,     # V6.7: trưởng phòng tự xử lý mọi sự cố

    "browser_wall_layout": "auto",
    # Văn phòng: "3d" (isometric) hoặc "2d" (sơ đồ phẳng).
    "office_view_mode": "3d",
    # Nhận file lớn từ server của Muse: thư mục lưu + trần mỗi file (GB).
    "large_file_max_gb": 50,
    "lease_seconds": 120,
    "max_attempts": 3,
    "wait_alert_minutes": 10,
    # V4.0 — Tự khởi động cùng Windows (ghi khoá Run HKCU khi bật; mặc
    # định TẮT, người dùng chủ động bật trong Cài đặt sau nghiệm thu).
    "autostart_windows": False,
    # V3.9 — Lớp vận chuyển Tailscale: app tự kiểm tra trạng thái khi mở
    # và mỗi 30 giây; True = tự chạy "tailscale up" nối lại khi máy đã
    # đăng nhập sẵn mà đang mất kết nối (chưa đăng nhập thì KHÔNG tự mở
    # trình duyệt — chỉ báo trong banner/hộp thoại cầu nối).
    "ts_auto_connect": True,
    "chrome_path": "",
    # V3.1 — Trạng thái giao diện được nhớ giữa các lần mở app:
    # thanh điều hướng thu gọn (chỉ icon), cột hồ sơ đang hiện, dock dưới
    # (Kênh/Nhật ký/Hàng đợi) đang mở, chiều cao dock, tab dock đã chọn,
    # và cờ "đã chạy lần đầu" cho việc tự thu dock khi chưa có dữ liệu.
    "ui_rail_collapsed": False,  # V3.4: topbar ngang mặc định hiện cả nhãn chữ
    "ui_browser_offscreen": True,  # V3.7: Chrome không nhúng chạy ngoài phạm vi màn hình
    "ui_profile_column_visible": True,
    "ui_dock_expanded": True,
    "ui_dock_height": 220,
    "ui_dock_tab": 0,
    "ui_first_run_done": False,
    # V4.3 — Mục Công việc: dạng xem bảng việc (list | cards | tree) và
    # kiểu sắp xếp agent (recent | percent | name) — nhớ giữa các lần mở.
    "work_view_mode": "list",
    "work_sort": "recent",
    # V4.3 — Văn phòng: mật độ sàn do người dùng chọn (auto = tự theo
    # số agent; roomy | compact | mini = ép mức tương ứng).
    "office_density": "auto",
    # V4.3 — Zoom trình duyệt nhúng THEO TỪNG HỒ SƠ: dict slug → % (50–
    # 150, mặc định 75 khi slug chưa có mục riêng).
    "browser_zoom_pct": {},
    # V4.3 — Giao diện (theme): preset đang dùng, bộ tokens hiệu lực
    # (dict — rỗng = theo preset) và các preset riêng của người dùng
    # (tên → tokens dict).
    "theme_preset": "metamint",
    "theme_tokens": {},
    "theme_custom_presets": {},
    # V5.1 — Kỷ nguyên giao diện (theme epoch, plan §1.2): epoch của
    # bộ giao diện đang áp + sao lưu nguyên vẹn bộ token TRƯỚC kỷ
    # nguyên hiện tại (để khôi phục). Xem app/ui/theme.py.
    "theme_epoch": 0,
    "theme_backup_pre_v51": {},
}


# --------------------------------------------------------------------------- #
# Đường dẫn
# --------------------------------------------------------------------------- #
def data_dir() -> Path:
    env = os.environ.get("CCD_DATA_DIR")
    return Path(env).expanduser() if env else PROJECT_ROOT / "data"


def db_path(base: Path | None = None) -> Path:
    return (base or data_dir()) / "channel_control.sqlite3"


def profiles_root(base: Path | None = None) -> Path:
    return (base or data_dir()) / "profiles"


def profile_dir(slug: str, base: Path | None = None) -> Path:
    """Thư mục Chrome user-data riêng của một hồ sơ."""
    return profiles_root(base) / slug


def snapshots_dir(base: Path | None = None) -> Path:
    return (base or data_dir()) / "snapshots"


def cookies_dir(base: Path | None = None) -> Path:
    """Thư mục kho cookies đăng nhập theo hồ sơ (V3.2): data/cookies/."""
    return (base or data_dir()) / "cookies"


def cookies_path(slug: str, base: Path | None = None) -> Path:
    """File cookies đã lưu của một hồ sơ: data/cookies/<slug>.json.
    Chứa cookie PHIÊN ĐĂNG NHẬP — dữ liệu nhạy cảm, chỉ nằm trên máy
    người dùng, không bao giờ ghi giá trị cookie vào nhật ký/log."""
    return cookies_dir(base) / f"{slug}.json"


def logs_dir(base: Path | None = None) -> Path:
    """Thư mục log file của app (V3.1): data/logs/."""
    return (base or data_dir()) / "logs"


def screenshots_dir(base: Path | None = None) -> Path:
    """Thư mục ảnh chụp khung live do người dùng lưu (V3.1): data/screenshots/."""
    return (base or data_dir()) / "screenshots"


# V4.4: file GIAO KÈM một lệnh (vd video cho lệnh studio_script) —
# mỗi lệnh một thư mục riêng data/command_files/<command_id>/, file
# giữ đúng TÊN THUẦN (không tiền tố thời gian như inbox) để bước
# upload trong kịch bản tham chiếu theo tên. Giới hạn 2 GiB/file:
# đủ cho video dài chất lượng cao, chặn nạp vô hạn làm đầy đĩa.
MAX_COMMAND_FILE_BYTES = 2 * 1024 * 1024 * 1024

_COMMAND_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$")


def command_files_dir(command_id: str, base: Path | None = None) -> Path:
    """Thư mục file đính kèm của MỘT lệnh (tạo nếu chưa có). Id lạ
    (chứa '/', '..'…) → ValueError — không cho thoát khỏi thư mục gốc."""
    if not _COMMAND_ID_RE.match(str(command_id or "")):
        raise ValueError(f"Mã lệnh không hợp lệ cho thư mục file: {command_id!r}")
    directory = (base or data_dir()) / "command_files" / str(command_id)
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def settings_path(base: Path | None = None) -> Path:
    return (base or data_dir()) / "settings.json"


def load_settings(base: Path | None = None) -> dict:
    path = settings_path(base)
    settings = dict(DEFAULT_SETTINGS)
    if path.exists():
        try:
            saved = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(saved, dict):
                settings.update(saved)
        except (OSError, json.JSONDecodeError):
            pass
    return settings


def save_settings(settings: dict, base: Path | None = None) -> None:
    path = settings_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(settings, ensure_ascii=False, indent=2), encoding="utf-8")


# --------------------------------------------------------------------------- #
# Slug & cổng tất định
# --------------------------------------------------------------------------- #
def slugify(text: str) -> str:
    """Chuyển nhãn thành slug an toàn cho tên thư mục: bỏ dấu tiếng Việt,
    chữ thường, ký tự không phải [a-z0-9] thành '-'."""
    normalized = unicodedata.normalize("NFKD", text or "")
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", ascii_text.lower()).strip("-")
    return slug or "profile"


def port_for_slug(slug: str) -> int:
    """Cổng remote-debugging tất định theo slug (ổn định giữa các lần chạy —
    KHÔNG dùng hash() của Python vì bị salt ngẫu nhiên theo tiến trình)."""
    return PORT_BASE + (zlib.crc32(slug.encode("utf-8")) % PORT_SPAN)


# --------------------------------------------------------------------------- #
# Tìm Chrome
# --------------------------------------------------------------------------- #
def find_chrome(override: str | None = None) -> str | None:
    """Tìm file chạy Google Chrome trên máy. Trả về đường dẫn hoặc None.

    Thứ tự ưu tiên: ``override`` (cài đặt chrome_path trong app, V3.1) →
    biến môi trường CCD_CHROME_PATH → các vị trí cài đặt quen thuộc →
    PATH. Override trỏ tới file không tồn tại thì bỏ qua, dò tiếp."""
    if override and Path(override).exists():
        return str(override)
    env = os.environ.get("CCD_CHROME_PATH")
    if env and Path(env).exists():
        return env

    candidates: list[Path] = []
    for var in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        root = os.environ.get(var)
        if root:
            candidates.append(Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe")
    candidates.append(Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"))

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)

    for name in ("chrome", "google-chrome", "google-chrome-stable", "chromium", "chromium-browser"):
        found = shutil.which(name)
        if found:
            return found
    return None
