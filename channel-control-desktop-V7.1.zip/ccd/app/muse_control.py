"""V6.5 — MUSE ĐIỀU KHIỂN TRÌNH DUYỆT NHÚNG QUA CHAT (giao thức ```ccd```).

Muse không gọi được về máy bạn, nhưng app đọc được câu trả lời của Muse
trên muse.ai. Vì vậy Muse "bấm/gõ" bằng cách viết khối:

    ```ccd
    {"action": "open", "profile": "KenhNhat"}
    {"action": "goto", "url": "https://studio.youtube.com"}
    {"action": "click", "text": "Tạo"}
    {"action": "type", "selector": "#textbox", "text": "Tiêu đề mới"}
    {"action": "key", "key": "Enter"}
    {"action": "read"}
    ```

App chạy từng hành động trên Chrome NHÚNG của đúng hồ sơ (tự mở nếu
chưa chạy, không bật cửa sổ ra ngoài trừ khi bạn bật "chạy ẩn ngoài
app"), rồi tự gửi lại vào chat: kết quả từng bước + ảnh chụp dạng chữ
của trang (URL, tiêu đề, chữ chính, danh sách phần tử bấm được có số
thứ tự). Muse đọc, quyết định bước tiếp → vòng lặp tới khi xong việc.
"""

from __future__ import annotations

import json
import re
import time

from . import cdp, cdp_vision

ACTIONS = ("open", "goto", "click", "type", "key", "scroll", "wait", "read", "back", "eval", "create_profiles")
# V6.7: lệnh cấp APP (không chạm trình duyệt) — chỉ TRƯỞNG PHÒNG được dùng
APP_ACTIONS = ("create_profiles",)
MAX_ACTIONS_PER_ROUND = 25
_BLOCK = re.compile(r"```\s*ccd\s*\n(.*?)```", re.S | re.I)

GUIDE = """[CCD] Bạn có TOÀN QUYỀN điều khiển trình duyệt nhúng của các hồ sơ kênh trong app Channel Control Desktop.
Muốn thao tác, viết một khối ```ccd``` (mỗi dòng một lệnh JSON), app sẽ làm rồi gửi lại kết quả + nội dung trang:
```ccd
{"action":"open","profile":"<tên hồ sơ>"}
{"action":"goto","url":"https://studio.youtube.com"}
{"action":"click","text":"<chữ trên nút>"}      (hoặc "selector":"css" / "element":<số thứ tự trong danh sách phần tử>)
{"action":"type","selector":"<css ô nhập>","text":"<nội dung>"}
{"action":"key","key":"Enter"}
{"action":"scroll","dy":600}
{"action":"wait","seconds":3}
{"action":"read"}
```
(Chỉ trưởng phòng) Tạo hồ sơ + giao agent: {"action":"create_profiles","accounts":["<email|mật khẩu>"],"agent":"auto","task":"<việc giao kèm>"}
Báo tiến độ bằng: TIẾN ĐỘ: <số>% — <bước vừa xong> — <bước tiếp>. Xong: KẾT QUẢ: … Chỉ khi bắt buộc cần chủ kênh: CẦN BẠN: …"""


def parse_actions(text: str) -> list[dict]:
    """Lấy mọi lệnh trong các khối ```ccd``` (mỗi dòng một JSON, hoặc
    một mảng JSON). Lệnh lạ/hỏng bị bỏ qua."""
    out: list[dict] = []
    if "[CCD] Bạn có TOÀN QUYỀN" in (text or ""):
        text = text.split("[CCD] Bạn có TOÀN QUYỀN")[0]  # phần hướng dẫn của app, không phải lời Muse
    for block in _BLOCK.findall(text or ""):
        block = block.strip()
        candidates: list = []
        if block.startswith("["):
            try:
                candidates = json.loads(block)
            except ValueError:
                candidates = []
        else:
            for line in block.splitlines():
                line = line.strip().rstrip(",")
                if not line or line.startswith(("//", "#")):
                    continue
                try:
                    candidates.append(json.loads(line))
                except ValueError:
                    continue
        for item in candidates:
            # V6.7: bỏ dòng MẪU (còn chỗ trống "<...>") — đó là hướng dẫn, không phải lệnh thật
            if isinstance(item, dict) and any(isinstance(v, str) and "<" in v and ">" in v for v in item.values()):
                continue
            if isinstance(item, dict) and str(item.get("action", "")).lower() in ACTIONS:
                item["action"] = str(item["action"]).lower()
                out.append(item)
    return out[:MAX_ACTIONS_PER_ROUND]


def wanted_profile(actions: list[dict]) -> str | None:
    for action in actions:
        if action["action"] == "open":
            value = action.get("profile") or action.get("profile_id")
            if value is not None:
                return str(value)
    return None


def resolve_profile(store, wanted: str | None, command: dict | None, agent: dict | None) -> dict | None:
    profiles = store.list_profiles()
    if wanted:
        w = str(wanted).strip().lower()
        for p in profiles:
            if str(p["id"]) == w or (p.get("label") or "").lower() == w or (p.get("slug") or "").lower() == w \
                    or (p.get("gmail") or "").lower() == w:
                return p
        for p in profiles:
            if w and w in (p.get("label") or "").lower():
                return p
        for p in profiles:  # tên KÊNH
            for ch in store.list_channels(p["id"]):
                if w == (ch.get("name") or "").lower() or w == (ch.get("handle") or "").lower():
                    return p
    if command and command.get("profile_id"):
        return store.get_profile(int(command["profile_id"]))
    if agent:
        for pid in agent.get("profile_ids") or []:
            profile = store.get_profile(int(pid))
            if profile:
                return profile
    return None


# V7.0: LỚP HIỂN THỊ thao tác ngay trên trang — dải trên cùng "🤖 Muse … bước i/n"
# + vòng tròn con trỏ nhấp nháy tại điểm bấm. Không chặn chuột (pointer-events:none).
OVERLAY_JS = r"""(function(label, x, y, done){
  try {
    var d = document, b = d.getElementById('__ccd_bar');
    if (!b) { b = d.createElement('div'); b.id = '__ccd_bar';
      b.style.cssText = 'position:fixed;left:50%;top:8px;transform:translateX(-50%);z-index:2147483647;'
        + 'background:rgba(12,13,15,.92);color:#CEFC19;border:1px solid #CEFC19;border-radius:999px;'
        + 'padding:6px 16px;font:600 13px Segoe UI,Arial,sans-serif;pointer-events:none;'
        + 'box-shadow:0 4px 18px rgba(0,0,0,.45);max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;';
      (d.body || d.documentElement).appendChild(b); }
    b.textContent = label; b.style.opacity = '1';
    clearTimeout(window.__ccd_t);
    if (done) { window.__ccd_t = setTimeout(function(){ b.style.transition='opacity .6s'; b.style.opacity='0'; }, 2500); }
    if (x !== null && y !== null) {
      var c = d.getElementById('__ccd_cur');
      if (!c) { c = d.createElement('div'); c.id = '__ccd_cur';
        (d.body || d.documentElement).appendChild(c); }
      c.style.cssText = 'position:fixed;z-index:2147483647;pointer-events:none;width:26px;height:26px;'
        + 'border-radius:50%;border:3px solid #CEFC19;box-shadow:0 0 0 6px rgba(206,252,25,.25);'
        + 'left:' + (x - 13) + 'px;top:' + (y - 13) + 'px;transition:all .25s;';
      setTimeout(function(){ c.style.boxShadow = '0 0 0 16px rgba(206,252,25,0)'; }, 60);
      setTimeout(function(){ if (c && c.parentNode) c.parentNode.removeChild(c); }, 1600);
    }
  } catch (e) {}
  return true;
})(__LABEL__, __X__, __Y__, __DONE__)"""


def describe(action: dict) -> str:
    kind = action.get("action")
    if kind == "goto":
        return f"mở {str(action.get('url') or '')[:70]}"
    if kind == "click":
        target = action.get("text") or action.get("selector") or (
            f"phần tử {action.get('element')}" if action.get("element") is not None else "")
        return f"bấm «{str(target)[:50]}»"
    if kind == "type":
        return f"gõ {len(str(action.get('text') or ''))} ký tự" + (f" vào {action['selector']}" if action.get("selector") else "")
    if kind == "key":
        return f"phím {action.get('key') or 'Enter'}"
    if kind == "scroll":
        return f"cuộn {int(action.get('dy', 600))}px"
    if kind == "wait":
        return f"chờ {action.get('seconds', 2)} giây"
    if kind == "back":
        return "quay lại trang trước"
    if kind == "eval":
        return "chạy JS đọc trang"
    if kind == "read":
        return "đọc trang"
    if kind == "open":
        return f"mở trình duyệt hồ sơ {action.get('profile') or ''}".strip()
    return str(kind)


def show_overlay(client, label: str, x=None, y=None, done: bool = False) -> None:
    try:
        client.evaluate(OVERLAY_JS.replace("__LABEL__", json.dumps(label)).replace("__X__", json.dumps(x))
                        .replace("__Y__", json.dumps(y)).replace("__DONE__", "true" if done else "false"))
    except Exception:
        pass


def run_actions(client, actions: list[dict], sleep=time.sleep, on_step=None, who: str = "Muse",
                visual: bool = True) -> tuple[list[str], dict]:
    """Chạy lần lượt; dừng ở lỗi đầu tiên (Muse sẽ thấy lỗi và sửa).
    V7.0: ``on_step(index, total, text, state)`` báo từng bước cho giao diện
    (state: 'run' / 'ok' / 'error' / 'done'); ``visual`` vẽ lớp chỉ dẫn trên trang."""
    lines: list[str] = []
    total = len(actions)
    overridden = prepare_page(client)

    def step(index, text, state):
        if on_step is not None:
            try:
                on_step(index, total, text, state)
            except Exception:
                pass

    for index, action in enumerate(actions, start=1):
        kind = action["action"]
        label = f"🤖 {who} · bước {index}/{total}: {describe(action)}"
        step(index, describe(action), "run")
        if visual:
            point = None
            if kind == "click":
                try:
                    if action.get("element") is not None and not action.get("selector") and not action.get("text"):
                        snap0 = cdp_vision.snapshot(client)
                        info0 = next((e for e in snap0.get("elements") or []
                                      if e.get("i") == int(action.get("element"))), None)
                    else:
                        finder = getattr(client, "_find_element", None)
                        info0 = finder(action.get("selector"), action.get("text")) if finder else None
                    if info0 and info0.get("x") is not None:
                        point = (float(info0["x"]), float(info0["y"]))
                except Exception:
                    point = None
            show_overlay(client, label, *(point or (None, None)))
            if point is not None:
                sleep(0.45)  # để mắt người kịp thấy điểm sắp bấm
        try:
            if kind == "open":
                lines.append(f"{index}. open ✓ trình duyệt hồ sơ đã sẵn sàng")
                continue
            if kind == "goto":
                url = str(action.get("url") or "")
                if not re.match(r"^https?://", url):
                    raise ValueError("url phải bắt đầu bằng http(s)://")
                try:
                    client.navigate_and_wait(url, timeout=30)
                except Exception:
                    client.navigate(url)
                    sleep(3)
                lines.append(f"{index}. goto ✓ {url}")
            elif kind == "click":
                if action.get("element") is not None and not action.get("selector") and not action.get("text"):
                    wanted_i = int(action.get("element"))
                    snap_now = cdp_vision.snapshot(client)
                    info = next((e for e in snap_now.get("elements") or [] if e.get("i") == wanted_i), None)
                    if not info:
                        raise ValueError(f"không có phần tử số {wanted_i}")
                    for event_type in ("mousePressed", "mouseReleased"):
                        client.dispatch_mouse({"type": event_type, "x": float(info["x"]), "y": float(info["y"]),
                                               "button": "left", "clickCount": 1})
                    lines.append(f"{index}. click ✓ phần tử {action.get('element')} «{info.get('text', '')}»")
                else:
                    info = client.click_element(action.get("selector"), action.get("text"))
                    lines.append(f"{index}. click ✓ «{info.get('text') or action.get('text') or action.get('selector')}»")
                sleep(float(action.get("after", 1.0)))
            elif kind == "type":
                text = str(action.get("text") or "")
                if action.get("selector"):
                    client.fill_element(action["selector"], text)
                else:
                    client.call("Input.insertText", {"text": text})
                lines.append(f"{index}. type ✓ {len(text)} ký tự")
            elif kind == "key":
                client.press_key(str(action.get("key") or "Enter"))
                lines.append(f"{index}. key ✓ {action.get('key') or 'Enter'}")
                sleep(0.5)
            elif kind == "scroll":
                client.scroll_by(int(action.get("dy", 600)))
                lines.append(f"{index}. scroll ✓ {int(action.get('dy', 600))}px")
            elif kind == "wait":
                seconds = max(0.0, min(30.0, float(action.get("seconds", 2))))
                sleep(seconds)
                lines.append(f"{index}. wait ✓ {seconds:g}s")
            elif kind == "back":
                client.evaluate("history.back()")
                sleep(1.5)
                lines.append(f"{index}. back ✓")
            elif kind == "eval":
                value = client.evaluate(str(action.get("js") or ""))
                lines.append(f"{index}. eval ✓ {json.dumps(value, ensure_ascii=False)[:400]}")
            elif kind == "read":
                lines.append(f"{index}. read ✓")
        except Exception as exc:  # noqa: BLE001
            lines.append(f"{index}. {kind} ✕ {type(exc).__name__}: {exc}"[:300])
            lines.append("(Dừng ở bước lỗi — xem trang bên dưới rồi gửi khối ```ccd``` mới.)")
            step(index, f"{describe(action)} — LỖI: {exc}"[:200], "error")
            if visual:
                show_overlay(client, f"⚠ {who} · bước {index}/{total} lỗi: {str(exc)[:80]}", done=True)
            break
        step(index, describe(action), "ok")
    else:
        if visual and total:
            show_overlay(client, f"✓ {who} đã xong {total} thao tác", done=True)
        step(total, f"xong {total} thao tác", "done")
    try:
        snap = cdp_vision.compact(cdp_vision.snapshot(client), max_elements=40)
    except Exception:
        snap = {}
    if overridden:
        release_page(client)
    return lines, snap


DESKTOP_W, DESKTOP_H = 1366, 900


def prepare_page(client) -> bool:
    """V7.1: trang LUÔN làm việc như đang được chọn + đủ rộng như màn hình
    laptop dù cửa sổ đang bị che / ngoài màn hình / nhúng trong ô nhỏ:
    - giả lập focus (ô nhập của Studio/Facebook nhận chữ);
    - cửa sổ hẹp hơn 1100px → ép viewport 1366×900 trong lúc Muse thao tác
      (bố cục desktop, menu không bị giấu). Trả True nếu đã ép viewport."""
    call = getattr(client, "call", None)
    if call is None:
        return False
    try:
        call("Emulation.setFocusEmulationEnabled", {"enabled": True})
    except Exception:
        pass
    try:
        width = float(client.evaluate("window.innerWidth") or 0)
    except Exception:
        width = 0
    if 0 < width < 1100:
        try:
            call("Emulation.setDeviceMetricsOverride",
                 {"width": DESKTOP_W, "height": DESKTOP_H, "deviceScaleFactor": 0, "mobile": False})
            return True
        except Exception:
            return False
    return False


def release_page(client) -> None:
    try:
        client.call("Emulation.clearDeviceMetricsOverride")
    except Exception:
        pass


def format_result(profile_label: str, lines: list[str], snap: dict, limit: int = 3500) -> str:
    parts = [f"[CCD · {profile_label}] Kết quả:", *lines]
    if snap:
        parts.append(f"Trang: {snap.get('title') or ''} — {snap.get('url') or ''}")
        if snap.get("dialogs"):
            parts.append("Hộp thoại: " + " | ".join(str(d)[:120] for d in snap["dialogs"][:3]))
        text = " ".join((snap.get("text") or "").split())
        if text:
            parts.append("Chữ trên trang: " + text[:1200])
        elements = []
        for i, el in enumerate(snap.get("elements") or []):
            label = (el.get("text") or "").strip()[:50]
            if label:
                elements.append(f"[{el.get('i', i)}] {el.get('tag', '')} «{label}»")
        if elements:
            parts.append("Phần tử bấm được: " + " · ".join(elements[:40]))
    parts.append("Gửi khối ```ccd``` tiếp theo, hoặc TIẾN ĐỘ / KẾT QUẢ.")
    return "\n".join(parts)[:limit]


def connect(port: int, wait_s: float = 15.0, sleep=time.sleep):
    for _ in range(int(wait_s / 0.5)):
        if cdp.debug_port_open(port):
            break
        sleep(0.5)
    return cdp.CDPClient(cdp.page_websocket_url(port))
