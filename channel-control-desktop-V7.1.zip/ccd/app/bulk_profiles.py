"""V6.7 — TẠO HỒ SƠ HÀNG LOẠT + GIAO CHO AGENT từ danh sách ``mail|pass``.

Mỗi dòng: ``email|mật khẩu`` (tuỳ chọn ``|tên hồ sơ``). App tự:
1. tạo hồ sơ (bỏ qua email đã có hồ sơ — vẫn giao lại nếu cần),
2. lưu mật khẩu vào kho riêng của hồ sơ (``credentials_vault`` — không vào
   nhật ký, không gửi qua chat),
3. phân công hồ sơ cho agent: chỉ định một Muse, hoặc TỰ ĐỘNG chia đều cho
   Muse ít hồ sơ nhất (trưởng phòng không nhận khi còn người khác),
4. (tuỳ chọn) tạo luôn một việc cho từng hồ sơ để trưởng phòng giao.
Đăng nhập Google chạy sau đó trong trình duyệt nhúng (login_helper).
"""

from __future__ import annotations

import re
from pathlib import Path

from . import credentials_vault
from .store import Store

_EMAIL = re.compile(r"^[^@\s|]+@[^@\s|]+\.[^@\s|]+$")


def parse_lines(text: str) -> tuple[list[dict], list[str]]:
    """→ (mục hợp lệ, lỗi theo dòng). Ngăn cách bằng | hoặc tab."""
    entries, errors, seen = [], [], set()
    for number, raw in enumerate((text or "").splitlines(), start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = [p.strip() for p in (line.split("|") if "|" in line else line.split("\t"))]
        email = parts[0].lower()
        if not _EMAIL.match(email):
            errors.append(f"Dòng {number}: '{parts[0]}' không phải email")
            continue
        if email in seen:
            errors.append(f"Dòng {number}: {email} bị lặp")
            continue
        seen.add(email)
        entries.append({"email": email, "password": parts[1] if len(parts) > 1 else "",
                        "label": parts[2] if len(parts) > 2 and parts[2] else email})
    return entries, errors


def _load(store: Store, agent_id: int) -> int:
    agent = store.get_agent(int(agent_id)) or {}
    return len(agent.get("profile_ids") or [])


def pick_agents(store: Store, count: int, target: int | str | None, lead_id: int | None = None) -> list[int | None]:
    """Danh sách agent nhận cho ``count`` hồ sơ mới."""
    agents = [a for a in store.list_agents() if not a.get("revoked")]
    if not agents:
        return [None] * count
    if target not in (None, "", "auto"):
        return [int(target)] * count
    pool = [a for a in agents if a["id"] != lead_id] or agents
    load = {a["id"]: _load(store, a["id"]) for a in pool}
    out = []
    for _ in range(count):
        best = min(pool, key=lambda a: (load[a["id"]], a["id"]))
        out.append(best["id"])
        load[best["id"]] += 1
    return out


def create_and_assign(store: Store, entries: list[dict], target: int | str | None = "auto",
                      lead_id: int | None = None, task: dict | None = None,
                      base: Path | None = None) -> list[dict]:
    results = []
    owners = pick_agents(store, len(entries), target, lead_id)
    for entry, agent_id in zip(entries, owners):
        result = {"email": entry["email"], "agent_id": agent_id, "status": "", "profile_id": None,
                  "command_id": None, "password_saved": False}
        try:
            existing = store.find_profile_by_gmail(entry["email"])
            if existing is not None:
                profile = existing
                result["status"] = "exists"
            else:
                profile = store.add_profile(entry["label"], entry["email"])
                result["status"] = "created"
            result["profile_id"] = profile["id"]
            if entry.get("password"):
                credentials_vault.save_password(profile["slug"], entry["email"], entry["password"], base)
                result["password_saved"] = True
            if agent_id is not None:
                store.ensure_agent_assignment(int(agent_id), int(profile["id"]))
            if task and (task.get("instruction") or "").strip():
                command = store.create_command(
                    task.get("type") or "free", source="ui", profile_id=profile["id"],
                    profile_slug=profile["slug"], instruction=task["instruction"].strip(),
                    agent_id=agent_id)
                result["command_id"] = command["id"]
        except Exception as exc:  # noqa: BLE001 — báo theo từng dòng
            result["status"] = "error"
            result["error"] = str(exc)
        results.append(result)
    created = sum(1 for r in results if r["status"] == "created")
    store.append_journal(f"👥 Tạo hồ sơ hàng loạt: {created} hồ sơ mới, {len(results) - created} hồ sơ có sẵn/lỗi "
                         f"— đã phân công cho agent (mật khẩu lưu kho riêng, không ghi nhật ký).")
    return results
