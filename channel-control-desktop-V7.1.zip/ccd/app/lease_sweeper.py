"""Sweeper lease (V4.0 — H1): thu hồi lệnh chờ Muse bị "mất dấu".

Logic THUẦN trên Store (không Qt, không HTTP) để kiểm thử độc lập;
AgentServer gọi ``sweep_once`` theo nhịp 15 giây trong vòng lặp worker
của nó (Đ4 — sống chết theo cầu nối, không thêm QTimer phía UI).

Việc của sweeper mỗi nhịp:

1. **Lease hết hạn**: lệnh chờ Muse đang 'running' mà
   ``lease_expires_at`` đã qua → trả về 'waiting_muse', xoá lease,
   attempts += 1, ghi nhật ký. attempts vượt ``max_attempts`` → chốt
   'failed' với lỗi nói rõ số lần Muse giữ lệnh rồi mất dấu.
2. **Cảnh báo chờ quá lâu**: lệnh 'waiting_muse' nằm quá
   ``wait_alert_minutes`` mà Muse phụ trách đang offline (hoặc hồ sơ
   chưa có Muse phụ trách) → ghi nhật ký cảnh báo ĐÚNG MỘT LẦN mỗi
   lệnh (cờ ``warned_no_agent`` trong payload — payload là dữ liệu nội
   bộ của lệnh, không phải nơi chứa bí mật).

Mọi chuyển trạng thái đi qua UPDATE có điều kiện trong Store/hàm này —
không đọc–sửa–ghi lỏng lẻo, để hai nhịp sweeper chồng nhau cũng an toàn.
"""

from __future__ import annotations

from datetime import datetime

from .store import CLAUDE_COMMAND_TYPES, Store, agent_status, now_iso

SWEEP_TAG = "[Tự động]"


def _parse_iso(value) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


class LeaseSweeper:
    """Rà lease + cảnh báo chờ. ``log`` (tuỳ chọn) nhận dòng nhật ký đã
    có tiền tố để nơi gọi hiển thị/ghi tiếp nếu cần."""

    def __init__(
        self,
        store: Store,
        lease_seconds: int = 120,
        max_attempts: int = 3,
        wait_alert_minutes: int = 10,
        log=None,
    ):
        self._store = store
        self._lease_seconds = max(10, int(lease_seconds or 120))
        self._max_attempts = max(1, int(max_attempts or 3))
        self._wait_alert_seconds = max(1, int(wait_alert_minutes or 10)) * 60
        self._log = log or (lambda _msg: None)

    # ------------------------------------------------------------------ #
    def sweep_once(self, now: datetime | None = None) -> dict:
        """Một nhịp quét. Trả {'requeued': [...], 'failed': [...],
        'warned': [...]} — danh sách id lệnh đã xử lý ở nhịp này."""
        now = now or datetime.now().astimezone()
        result = {"requeued": [], "failed": [], "warned": []}
        result.update(self._sweep_expired_leases(now))
        result["warned"] = self._sweep_wait_alerts(now)
        return result

    # ------------------------------------------------------------------ #
    def _sweep_expired_leases(self, now: datetime) -> dict:
        requeued: list[str] = []
        failed: list[str] = []
        # V4.2 (O-13): SQL lọc sẵn lease đã hết hạn (so chuỗi ISO cùng
        # định dạng/offset như now_iso()) thay vì nạp 200 lệnh
        # 'running' rồi lọc Python — lease thứ 201+ hết hạn vẫn được
        # thấy. Vẫn xác minh lại bằng datetime đã parse bên dưới.
        rows = self._store.list_expired_lease_commands(now_iso())
        for row in rows:
            deadline = _parse_iso(row.get("lease_expires_at"))
            if deadline is None or deadline > now:
                continue
            holder = row.get("lease_agent_id")
            holder_agent = self._store.get_agent(holder) if holder else None
            holder_name = (
                holder_agent["name"] if holder_agent else f"#{holder}" if holder else "?"
            )
            attempts = int(row.get("attempts") or 0) + 1
            ts = now_iso()
            if attempts > self._max_attempts:
                error = (
                    f"Muse giữ lệnh nhưng mất dấu {attempts} lần "
                    f"(lease hết hạn, lần cuối do {holder_name} giữ)."
                )
                cur = self._store._conn.execute(
                    "UPDATE commands SET status = 'failed', error = ?,"
                    " result = ?, finished_at = ?, lease_agent_id = NULL,"
                    " lease_expires_at = NULL, attempts = ?, updated_at = ?"
                    " WHERE id = ? AND status = 'running'",
                    (error, error, ts, attempts, ts, row["id"]),
                )
                self._store._conn.commit()
                if cur.rowcount == 1:
                    failed.append(row["id"])
                    # V4.5: đường chốt failed này đi qua UPDATE thô
                    # (không qua finish_command) nên phải ghi nhận
                    # tự-chạy-lại TƯỜNG MINH như mọi đường khác.
                    self._store._note_failure_for_auto_retry(
                        self._store.get_command(row["id"])
                    )
                    self._note(
                        f"{SWEEP_TAG} Lệnh #{row['id']} ({row['type']}) THẤT BẠI: {error}",
                        row.get("profile_id"),
                    )
                continue
            cur = self._store._conn.execute(
                "UPDATE commands SET status = 'waiting_muse', attempts = ?,"
                " lease_agent_id = NULL, lease_expires_at = NULL,"
                " step = ?, updated_at = ?"
                " WHERE id = ? AND status = 'running'",
                (
                    attempts,
                    f"Lease hết hạn — đã xếp hàng lại (lần {attempts}).",
                    ts,
                    row["id"],
                ),
            )
            self._store._conn.commit()
            if cur.rowcount == 1:
                requeued.append(row["id"])
                self._note(
                    f"{SWEEP_TAG} Lease lệnh #{row['id']} ({row['type']}) hết hạn "
                    f"(Muse {holder_name} mất dấu) — đã xếp hàng lại (lần {attempts}).",
                    row.get("profile_id"),
                )
        return {"requeued": requeued, "failed": failed}

    # ------------------------------------------------------------------ #
    def _sweep_wait_alerts(self, now: datetime) -> list[str]:
        warned: list[str] = []
        # V4.2 (O-13): phân trang qua toàn bộ hàng 'waiting_muse'
        # (trang 200) — bản cũ chỉ thấy 200 lệnh mới nhất.
        rows: list[dict] = []
        offset = 0
        while True:
            page = self._store.list_commands(
                status="waiting_muse", limit=200, offset=offset
            )
            rows.extend(page)
            if len(page) < 200:
                break
            offset += 200
        for row in rows:
            if row["type"] not in CLAUDE_COMMAND_TYPES:
                continue
            payload = row.get("payload") or {}
            created = _parse_iso(row.get("created_at"))
            if created is None or (now - created).total_seconds() < self._wait_alert_seconds:
                continue
            owner = None
            if row.get("agent_id"):
                owner = self._store.get_agent(int(row["agent_id"]))
            if owner is None and row.get("profile_id"):
                owner = self._store.agent_for_profile(int(row["profile_id"]))
            if owner is not None:
                status = agent_status(owner.get("last_seen_at"), bool(owner.get("revoked")))
                if status in ("online", "idle"):
                    # V4.2 (O-04): Muse phụ trách đã online/idle →
                    # điều kiện cảnh báo đã hết; dọn cờ cũ (nếu có)
                    # để một lần offline sau lại cảnh báo được.
                    if payload.get("warned_no_agent"):
                        self._store.update_command_payload_flags(
                            row["id"], clear_keys=["warned_no_agent"]
                        )
                    continue
                reason = f"Muse phụ trách '{owner['name']}' đang {status}"
            else:
                reason = "hồ sơ CHƯA có Muse phụ trách"
            if payload.get("warned_no_agent"):
                continue  # đã cảnh báo đúng một lần cho đợt chờ này
            # V4.2 (O-04): đặt cờ qua helper tập trung của Store —
            # không còn UPDATE payload thẳng qua _conn ở đây. Điều
            # kiện status='waiting_muse' giữ bằng cách chỉ đặt cờ khi
            # hàng vừa đọc vẫn ở trạng thái đó.
            current = self._store.get_command(row["id"])
            if current is None or current["status"] != "waiting_muse":
                continue
            self._store.update_command_payload_flags(
                row["id"], set_flags={"warned_no_agent": True}
            )
            warned.append(row["id"])
            self._note(
                f"{SWEEP_TAG} ⚠ Lệnh #{row['id']} ({row['type']}) đã chờ "
                f"quá {self._wait_alert_seconds // 60} phút mà {reason} — "
                "chưa có ai nhận việc này.",
                row.get("profile_id"),
            )
        return warned

    # ------------------------------------------------------------------ #
    def _note(self, message: str, profile_id: int | None) -> None:
        try:
            self._store.append_journal(message, profile_id)
        except Exception:
            pass  # nhật ký lỗi không được làm sập nhịp quét
        self._log(message)
