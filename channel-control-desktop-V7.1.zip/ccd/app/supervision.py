"""V6.0 — GIÁM SÁT CHÉO giữa các tài khoản Muse (UI_V60_PLAN).

Tầng điều phối nằm TRÊN Store: ma trận giám sát (ai chấm ai), sinh
VIỆC KIỂM TRA (một lệnh loại 'review' như mọi lệnh chờ Muse khác),
gói bằng chứng, watchdog tiến độ chạy trong app, và áp ba kết luận
(Đạt / Chưa đạt–làm lại / Leo thang chủ kênh). Store chỉ giữ tầng dữ
liệu (bảng reviews + cột truy vết trên lệnh gốc).

Nguyên tắc bất biến:
- Tối đa MỘT vòng kiểm tra 'open' cho mỗi lệnh gốc tại một thời điểm.
- Không ai tự chấm mình — chặn ở tầng dữ liệu của module này (mọi
  đường sinh việc và áp kết luận đều qua supervisor_for()).
- Giám sát viên chỉ CHẤM và TRẢ VIỆC: module này không bao giờ sửa
  kết quả của lệnh gốc, trừ việc xếp lại hàng đợi khi "làm lại" và
  đặt needs_user khi "leo thang" (đúng hai hành động plan cho phép).
- Mọi kết luận đều ghi Nhật ký (append_journal).
"""

from __future__ import annotations

import re
import zlib
from datetime import datetime, timedelta

from . import config
from .store import (
    CLAUDE_COMMAND_TYPES,
    Store,
    _command_row,
    _parse_iso,
    now_iso,
)

SUPERVISION_TAG = "[Giám sát]"

# Bộ câu hỏi chuẩn khi lệnh KHÔNG có skill đính kèm (plan §4).
STANDARD_CHECKLIST = (
    "Kết quả có đúng yêu cầu của lệnh gốc không?",
    "Kết quả có đủ bằng chứng (link / file / báo cáo kiểm chứng) không?",
    "Việc có làm đúng kênh / hồ sơ đích không?",
    "Kết quả có lỗi nhìn thấy được (thiếu, sai, hỏng) không?",
)

VERDICT_PASS = "pass"
VERDICT_REWORK = "rework"
VERDICT_ESCALATE = "escalate"
VERDICTS = (VERDICT_PASS, VERDICT_REWORK, VERDICT_ESCALATE)

# Mốc mất nhịp tim của agent bị watchdog coi là "mất dấu" (plan §2).
HEARTBEAT_LOST_MINUTES = 15
# Nhịp tối thiểu giữa hai lần quét watchdog (chống quét dồn dập khi
# nhiều nhịp worker gọi liên tiếp) — mốc lưu trong app_meta.
WATCHDOG_MIN_INTERVAL_SECONDS = 30
_WATCHDOG_META_KEY = "supervision_watchdog_last_scan"


# --------------------------------------------------------------------------- #
# Cài đặt + ma trận giám sát
# --------------------------------------------------------------------------- #
def supervision_settings(settings: dict | None = None) -> dict:
    """Chuẩn hoá các khoá giám sát từ settings của app (thiếu khoá thì
    lấy mặc định ở config.DEFAULT_SETTINGS — cùng kỷ luật §18)."""
    source = settings if settings is not None else config.load_settings()
    defaults = config.DEFAULT_SETTINGS
    return {
        "enabled": bool(source.get("supervision_enabled", defaults["supervision_enabled"])),
        "stall_minutes": max(1, int(source.get(
            "supervision_stall_minutes", defaults["supervision_stall_minutes"]))),
        "sample_percent": max(0, min(100, int(source.get(
            "supervision_sample_percent", defaults["supervision_sample_percent"])))),
        "max_rounds": max(0, int(source.get(
            "supervision_max_rounds", defaults["supervision_max_rounds"]))),
        "matrix_overrides": source.get("supervision_matrix") or {},
        "mode": str(source.get("supervision_mode", defaults.get("supervision_mode", "lead")) or "ring"),
        "lead_agent_id": int(source.get(
            "supervision_lead_agent_id", defaults.get("supervision_lead_agent_id", 0)) or 0),
        "warn_percent": max(10, min(95, int(source.get(
            "deadline_warn_percent", defaults.get("deadline_warn_percent", 75)) or 75))),
    }


def active_agent_ids(store: Store) -> list[int]:
    """Id các agent còn hiệu lực (chưa thu hồi), tăng dần — nền của
    vòng chéo mặc định."""
    return [
        int(agent["id"]) for agent in store.list_agents()
        if not agent.get("revoked")
    ]


def default_ring(agent_ids: list[int]) -> dict[int, int]:
    """Vòng chéo mặc định: mỗi agent do agent KẾ TIẾP trong danh sách
    id chấm, cuối vòng quay về đầu. Một agent duy nhất → rỗng (không
    ai chấm được — tự chấm bị cấm)."""
    ids = sorted(int(a) for a in agent_ids)
    if len(ids) < 2:
        return {}
    return {worker: ids[(index + 1) % len(ids)] for index, worker in enumerate(ids)}


def effective_matrix(store: Store, settings: dict | None = None) -> dict[int, int]:
    """Ma trận hiệu lực: vòng chéo mặc định + ghi đè tay từ cài đặt.
    Ghi đè chỉ nhận khi: người làm và giám sát đều còn hiệu lực, khác
    nhau (chặn tự chấm ở tầng dữ liệu), và là số nguyên hợp lệ."""
    cfg = supervision_settings(settings)
    ids = active_agent_ids(store)
    matrix = default_ring(ids)
    valid = set(ids)
    lead = lead_agent_id(store, settings, ids)
    if lead is not None:
        # V6.1 — CHẾ ĐỘ TRƯỞNG PHÒNG: trưởng phòng chấm MỌI tài khoản
        # khác; việc của chính trưởng phòng do agent kế tiếp trong vòng
        # chéo chấm (không ai tự chấm mình — bất biến giữ nguyên).
        for worker in ids:
            if worker != lead:
                matrix[worker] = lead
    overrides = cfg["matrix_overrides"]
    if isinstance(overrides, dict):
        for raw_worker, raw_supervisor in overrides.items():
            try:
                worker = int(raw_worker)
                supervisor = int(raw_supervisor)
            except (TypeError, ValueError):
                continue
            if worker in valid and supervisor in valid and worker != supervisor:
                matrix[worker] = supervisor
    return matrix


def lead_agent_id(
    store: Store, settings: dict | None = None, ids: list[int] | None = None,
) -> int | None:
    """Trưởng phòng hiệu lực (V6.1): chế độ 'lead' + id đã chọn còn
    hiệu lực (chưa thu hồi). Không thoả → None (dùng vòng chéo)."""
    cfg = supervision_settings(settings)
    if cfg["mode"] != "lead" or not cfg["lead_agent_id"]:
        return None
    ids = ids if ids is not None else active_agent_ids(store)
    return cfg["lead_agent_id"] if cfg["lead_agent_id"] in set(ids) else None


def supervisor_for(
    store: Store, worker_agent_id: int | None, settings: dict | None = None,
) -> int | None:
    """Giám sát viên của một người làm — None khi không xác định được
    (không có người làm / ma trận rỗng / chỉ còn một agent)."""
    if worker_agent_id is None:
        return None
    return effective_matrix(store, settings).get(int(worker_agent_id))


# --------------------------------------------------------------------------- #
# Gói bằng chứng + checklist
# --------------------------------------------------------------------------- #
def build_evidence(store: Store, target: dict) -> dict:
    """Gói bằng chứng đính kèm việc kiểm tra (plan §3): lệnh gốc đầy
    đủ + các dòng Nhật ký nhắc tới lệnh + thông tin kênh/hồ sơ đích.
    Giám sát viên chấm TRÊN gói này và link công khai trong kết quả."""
    journal_hits = []
    try:
        for entry in store.list_journal(limit=500):
            if f"#{target['id']}" in str(entry.get("message") or ""):
                journal_hits.append(
                    {"ts": entry.get("ts"), "message": entry.get("message")}
                )
            if len(journal_hits) >= 20:
                break
    except Exception:
        journal_hits = []
    payload = target.get("payload") or {}
    return {
        "target": {
            "id": target["id"],
            "type": target.get("type"),
            "profile_id": target.get("profile_id"),
            "profile_slug": target.get("profile_slug"),
            "channel_id": target.get("channel_id") or "",
            "instruction": target.get("instruction") or "",
            "payload": payload,
            "status": target.get("status"),
            "progress": target.get("progress") or 0,
            "step": target.get("step") or "",
            "result": target.get("result"),
            "result_data": target.get("result_data"),
            "error": target.get("error"),
            "created_at": target.get("created_at"),
            "started_at": target.get("started_at"),
            "finished_at": target.get("finished_at"),
        },
        "journal": journal_hits,
    }


def build_checklist(store: Store, target: dict) -> list[dict]:
    """Danh mục chấm cho một việc kiểm tra: tách từ skill đính kèm
    khi lệnh có skill (xem extract_checklist_from_skill — GĐ2), không
    thì bộ câu hỏi chuẩn của plan §4. Mỗi mục: {item, status: None}
    — giám sát viên điền 'pass'/'fail'/'na' khi chấm."""
    texts = extract_checklist_texts(store, target)
    if not texts:
        texts = list(STANDARD_CHECKLIST)
    return [{"item": text, "status": None, "note": ""} for text in texts]


def extract_checklist_texts(store: Store, target: dict) -> list[str]:
    """Tách các mục chấm từ nội dung skill đính kèm của lệnh gốc:
    payload.assignment.skill_slug → skills_lib. Ưu tiên dòng checkbox
    '- [ ] ...' và gạch đầu dòng trong các mục có tiêu đề chứa
    QC/kiểm tra/nghiệm thu/chất lượng. Không có skill/không tách được
    → danh sách rỗng (nơi gọi dùng bộ chuẩn)."""
    payload = target.get("payload") or {}
    assignment = payload.get("assignment") or {}
    slug = assignment.get("skill_slug")
    if not slug:
        return []
    try:
        from . import skills_lib

        skill = skills_lib.load_skill(str(slug))
    except Exception:
        return []
    if skill is None:
        return []
    return extract_checklist_from_text(str(getattr(skill, "body", "") or ""))


_QC_HEADING_HINTS = ("qc", "kiểm tra", "nghiệm thu", "chất lượng", "checklist")
_CHECKBOX_RE = re.compile(r"^\s*[-*]\s*\[.\]\s*(.+?)\s*$")
_BULLET_RE = re.compile(r"^\s*[-*]\s+(.+?)\s*$")
_HEADING_RE = re.compile(r"^\s*#{1,6}\s+(.+?)\s*$")


def extract_checklist_from_text(text: str) -> list[str]:
    """Tách mục chấm từ markdown của một skill: (1) mọi dòng
    checkbox; (2) gạch đầu dòng nằm dưới tiêu đề có hint QC. Khử
    trùng, giữ thứ tự, tối đa 20 mục."""
    items: list[str] = []
    in_qc_section = False
    for line in (text or "").splitlines():
        heading = _HEADING_RE.match(line)
        if heading:
            title = heading.group(1).lower()
            in_qc_section = any(hint in title for hint in _QC_HEADING_HINTS)
            continue
        checkbox = _CHECKBOX_RE.match(line)
        if checkbox:
            items.append(checkbox.group(1))
            continue
        if in_qc_section:
            bullet = _BULLET_RE.match(line)
            if bullet and not bullet.group(1).startswith("["):
                items.append(bullet.group(1))
    seen: set[str] = set()
    unique = []
    for item in items:
        cleaned = item.strip().rstrip(".")
        if cleaned and cleaned not in seen:
            seen.add(cleaned)
            unique.append(cleaned)
    return unique[:20]


def result_has_evidence(target: dict) -> bool:
    """Luật cứng của plan §3: 'done' phải có bằng chứng — result có
    chữ (link/file/báo cáo đều nằm trong result/result_data). Result
    rỗng hoặc chỉ vài ký tự cho có → coi như THIẾU bằng chứng."""
    result = str(target.get("result") or "").strip()
    if len(result) >= 12:
        return True
    return target.get("result_data") is not None


# --------------------------------------------------------------------------- #
# Sinh việc kiểm tra
# --------------------------------------------------------------------------- #
def create_review_for_target(
    store: Store, target: dict, trigger_kind: str,
    settings: dict | None = None,
) -> dict | None:
    """Sinh MỘT việc kiểm tra cho lệnh gốc. Trả hàng review đã mở,
    hoặc None khi không sinh được (đã tắt giám sát / lệnh là việc
    kiểm tra / đã có vòng đang mở / không có người làm / không tìm
    được giám sát viên khác người làm)."""
    cfg = supervision_settings(settings)
    if not cfg["enabled"]:
        return None
    if target.get("type") == "review":
        return None
    if store.open_review_for_command(target["id"]) is not None:
        return None
    worker_id = target.get("agent_id")
    if worker_id is None and target.get("profile_id") is not None:
        owner = store.agent_for_profile(int(target["profile_id"]))
        worker_id = owner["id"] if owner else None
    if worker_id is None:
        return None
    supervisor_id = supervisor_for(store, int(worker_id), settings)
    if supervisor_id is None or supervisor_id == int(worker_id):
        return None
    checklist = build_checklist(store, target)
    review = store.create_review(
        command_id=target["id"],
        worker_agent_id=int(worker_id),
        supervisor_agent_id=int(supervisor_id),
        trigger_kind=trigger_kind,
        round=int(target.get("review_round") or 0),
        checklist=checklist,
    )
    evidence = build_evidence(store, target)
    instruction = (
        f"Kiểm tra chéo lệnh #{target['id']} ({target.get('type')}) "
        f"do Muse #{worker_id} thực hiện — kích hoạt: {trigger_kind}. "
        "Đọc gói bằng chứng trong payload, chấm từng mục checklist, "
        "rồi gửi kết luận qua POST /api/commands/<id lệnh kiểm tra "
        "này>/verdict với verdict pass | rework | escalate kèm notes."
    )
    review_command = store.create_command(
        "review",
        source="supervision",
        profile_id=target.get("profile_id"),
        profile_slug=target.get("profile_slug"),
        channel_id=target.get("channel_id") or "",
        instruction=instruction,
        payload={
            "review_id": review["id"],
            "target_command_id": target["id"],
            "trigger": trigger_kind,
            "round": int(target.get("review_round") or 0),
            "evidence": evidence,
            "checklist": checklist,
        },
        agent_id=int(supervisor_id),
    )
    review = store.set_review_command(review["id"], review_command["id"])
    store.append_journal(
        f"{SUPERVISION_TAG} Mở kiểm tra lệnh #{target['id']} "
        f"({target.get('type')}, {trigger_kind}) — Muse #{worker_id} làm, "
        f"Muse #{supervisor_id} chấm (vòng {int(target.get('review_round') or 0)}).",
        target.get("profile_id"),
    )
    return review


def _sampled_in(command_id: str, percent: int) -> bool:
    """Lấy mẫu TẤT ĐỊNH theo id lệnh (crc32 % 100 < percent) — cùng
    một lệnh luôn cho cùng một kết quả, test được không cần seed."""
    if percent >= 100:
        return True
    if percent <= 0:
        return False
    return (zlib.crc32(str(command_id).encode("utf-8")) % 100) < percent


def on_command_finished(
    store: Store, command: dict, settings: dict | None = None,
) -> dict | None:
    """Điểm nghẽn khi một lệnh chốt done/failed (Store.finish_command
    gọi): failed → kiểm tra 100%; done → theo % lấy mẫu, RIÊNG lệnh
    đã qua vòng làm lại (review_round > 0) thì LUÔN kiểm tra lại.
    Trả review đã sinh hoặc None."""
    cfg = supervision_settings(settings)
    if not cfg["enabled"] or command.get("type") == "review":
        return None
    # V6.1: CHỈ kiểm tra việc do Muse làm. Bản V6.0 sinh việc kiểm
    # tra cho cả lệnh app tự chạy (quét/kiểm tra/mở trình duyệt) →
    # hàng đợi phình hàng trăm lệnh 'Kiểm tra chéo' vô nghĩa, giám sát
    # viên tốn lượt và bảng Công việc rối.
    if command.get("type") not in CLAUDE_COMMAND_TYPES:
        return None
    status = command.get("status")
    if status == "failed":
        return create_review_for_target(store, command, "failed", settings)
    if status == "done":
        if int(command.get("review_round") or 0) > 0:
            return create_review_for_target(store, command, "done", settings)
        if _sampled_in(command["id"], cfg["sample_percent"]):
            return create_review_for_target(store, command, "done", settings)
    return None


# --------------------------------------------------------------------------- #
# Watchdog tiến độ (app tự chạy — không tốn lượt Muse)
# --------------------------------------------------------------------------- #
def watchdog_scan(
    store: Store, settings: dict | None = None,
    now: datetime | None = None, force: bool = False,
) -> list[dict]:
    """Một nhịp quét watchdog: phát hiện lệnh Muse 'running' bị
    treo (không tiến triển quá ngưỡng / lease chết / agent mất nhịp
    tim) và sinh việc kiểm tra loại 'stuck' cho từng lệnh chưa có
    vòng mở. Trả danh sách review đã sinh ở nhịp này. Tiết lưu bằng
    app_meta (tối thiểu WATCHDOG_MIN_INTERVAL_SECONDS giữa hai nhịp)
    trừ khi force=True (test / nút quét tay)."""
    cfg = supervision_settings(settings)
    if not cfg["enabled"]:
        return []
    now = now or datetime.now().astimezone()
    if not force:
        last_raw = store.get_meta(_WATCHDOG_META_KEY)
        last = _parse_iso(last_raw)
        if last is not None and (now - last).total_seconds() < WATCHDOG_MIN_INTERVAL_SECONDS:
            return []
    store.set_meta(_WATCHDOG_META_KEY, now.isoformat(timespec="seconds"))
    stall_after = timedelta(minutes=cfg["stall_minutes"])
    heartbeat_lost_after = timedelta(minutes=HEARTBEAT_LOST_MINUTES)
    created: list[dict] = []
    placeholders = ", ".join("?" for _ in CLAUDE_COMMAND_TYPES)
    rows = store._conn.execute(
        f"SELECT * FROM commands WHERE status = 'running'"
        f" AND type IN ({placeholders}) AND type <> 'review'",
        tuple(CLAUDE_COMMAND_TYPES),
    ).fetchall()
    agents_seen = {
        int(a["id"]): _parse_iso(a.get("last_seen_at"))
        for a in store.list_agents()
    }
    for row in rows:
        command = _command_row(row)
        reasons = []
        updated = _parse_iso(command.get("updated_at"))
        if updated is not None and now - updated > stall_after:
            reasons.append(
                f"không tiến triển quá {cfg['stall_minutes']} phút"
            )
        lease_end = _parse_iso(command.get("lease_expires_at"))
        if lease_end is not None and lease_end < now:
            reasons.append("lease đã hết hạn mà chưa gia hạn")
        holder = command.get("lease_agent_id") or command.get("agent_id")
        if holder is not None:
            seen = agents_seen.get(int(holder))
            if seen is not None and now - seen > heartbeat_lost_after:
                reasons.append("agent giữ lệnh mất nhịp tim > 15 phút")
        if not reasons:
            continue
        review = create_review_for_target(store, command, "stuck", settings)
        if review is not None:
            store.append_journal(
                f"{SUPERVISION_TAG} ⚠ Watchdog: lệnh #{command['id']} "
                f"nghi treo ({'; '.join(reasons)}) — đã giao kiểm tra.",
                command.get("profile_id"),
            )
            created.append(review)
    try:
        deadline_scan(store, settings, now)
    except Exception:
        pass
    return created


# --------------------------------------------------------------------------- #
# V6.1 — Hạn chót: phân loại + cảnh báo trễ hạn cho trưởng phòng
# --------------------------------------------------------------------------- #
HEALTH_DONE = "done"
HEALTH_ON_TRACK = "on_track"
HEALTH_AT_RISK = "at_risk"
HEALTH_OVERDUE = "overdue"
HEALTH_BLOCKED = "blocked"
HEALTH_NO_DUE = "no_due"
HEALTH_LABELS = {
    HEALTH_DONE: "Đã xong",
    HEALTH_ON_TRACK: "Đúng tiến độ",
    HEALTH_AT_RISK: "Sắp trễ",
    HEALTH_OVERDUE: "Trễ hạn",
    HEALTH_BLOCKED: "Đang kẹt",
    HEALTH_NO_DUE: "Chưa đặt hạn",
}


def deadline_health(
    command: dict, now: datetime | None = None, warn_percent: int = 75,
) -> dict:
    """Đánh giá MỘT việc so với hạn chót — hàm thuần, dùng chung cho
    bảng Giám sát, khối sự cố Văn phòng và watchdog.

    Trả {health, label, time_used_pct (0–100+), progress, due_at,
    seconds_left (âm = đã trễ)}. Quy tắc: xong → done; quá hạn →
    overdue; needs_user/interrupted → blocked; thời gian đã dùng ≥
    warn_percent mà tiến độ thấp hơn thời gian đã dùng → at_risk."""
    now = now or datetime.now().astimezone()
    status = command.get("status")
    progress = max(0, min(100, int(command.get("progress") or 0)))
    due = _parse_iso(command.get("due_at"))
    start = (
        _parse_iso(command.get("started_at"))
        or _parse_iso(command.get("scheduled_at"))
        or _parse_iso(command.get("created_at"))
    )
    result = {
        "progress": progress,
        "due_at": command.get("due_at"),
        "seconds_left": None,
        "time_used_pct": None,
    }
    if status == "done":
        finished = _parse_iso(command.get("finished_at"))
        late = bool(due and finished and finished > due)
        result.update(health=HEALTH_DONE, label="Xong trễ hạn" if late else "Xong đúng hạn",
                      late=late)
        return result
    if due is None:
        result.update(health=HEALTH_NO_DUE, label=HEALTH_LABELS[HEALTH_NO_DUE])
        return result
    seconds_left = int((due - now).total_seconds())
    result["seconds_left"] = seconds_left
    if start is not None and due > start:
        total = (due - start).total_seconds()
        used = (now - start).total_seconds()
        result["time_used_pct"] = max(0.0, round(100.0 * used / total, 1))
    if seconds_left < 0:
        health = HEALTH_OVERDUE
    elif status in ("needs_user", "interrupted", "failed"):
        health = HEALTH_BLOCKED
    elif (
        result["time_used_pct"] is not None
        and result["time_used_pct"] >= warn_percent
        and progress < result["time_used_pct"]
    ):
        health = HEALTH_AT_RISK
    else:
        health = HEALTH_ON_TRACK
    result.update(health=health, label=HEALTH_LABELS[health])
    return result


def format_left(seconds: int | None) -> str:
    """'còn 1g20p' / 'trễ 35p' / '' — chữ ngắn cho ô hạn chót."""
    if seconds is None:
        return ""
    late = seconds < 0
    seconds = abs(int(seconds))
    hours, rem = divmod(seconds, 3600)
    minutes = rem // 60
    if hours >= 24:
        text = f"{hours // 24}n{hours % 24}g"
    elif hours:
        text = f"{hours}g{minutes:02d}p"
    elif seconds >= 60:
        text = f"{minutes}p"
    else:
        text = "<1p"
    return ("trễ " if late else "còn ") + text


DEADLINE_ALERT_FLAG = "deadline_alerted"


def deadline_scan(
    store: Store, settings: dict | None = None, now: datetime | None = None,
) -> list[str]:
    """Việc ĐANG MỞ vừa quá hạn → ghi Nhật ký + gửi MỘT tin hệ thống
    cho trưởng phòng (chế độ lead) hoặc giám sát viên của người làm,
    kèm tin cho chính người làm. Cờ payload 'deadline_alerted' chống
    nhắc lặp; gia hạn (set_command_due) xoá cờ. Trả id lệnh đã báo."""
    cfg = supervision_settings(settings)
    if not cfg["enabled"]:
        return []
    now = now or datetime.now().astimezone()
    alerted: list[str] = []
    try:
        store.backfill_due_dates()
    except Exception:
        pass
    for command in store.list_open_commands(limit=500):
        if command.get("type") == "review":
            continue
        payload = command.get("payload") or {}
        if payload.get(DEADLINE_ALERT_FLAG):
            continue
        health = deadline_health(command, now, cfg["warn_percent"])
        if health["health"] != HEALTH_OVERDUE:
            continue
        worker = command.get("agent_id") or command.get("lease_agent_id")
        watcher = supervisor_for(store, worker, settings) if worker else lead_agent_id(store, settings)
        label = command.get("type") or ""
        text = (
            f"⏰ [Hạn chót] Lệnh #{command['id']} ({label}, hồ sơ "
            f"{command.get('profile_slug') or '—'}) đã QUÁ HẠN "
            f"{format_left(health['seconds_left']).replace('trễ ', '')} — "
            f"tiến độ {health['progress']}%."
        )
        store.append_journal(f"{SUPERVISION_TAG} {text}", command.get("profile_id"))
        for agent_id in {a for a in (watcher, worker) if a}:
            try:
                store.add_message(int(agent_id), "system", text, command_id=command["id"])
            except Exception:
                pass
        store.update_command_payload_flags(
            command["id"], set_flags={DEADLINE_ALERT_FLAG: now.isoformat(timespec="seconds")}
        )
        alerted.append(command["id"])
    return alerted


# --------------------------------------------------------------------------- #
# Áp kết luận (verdict)
# --------------------------------------------------------------------------- #
def apply_verdict(
    store: Store,
    review_command_id: str,
    verdict: str,
    notes: str = "",
    checklist: list | None = None,
    actor: str = "supervisor",
    settings: dict | None = None,
) -> dict:
    """Áp một kết luận lên vòng kiểm tra gắn với LỆNH KIỂM TRA
    ``review_command_id``. actor: 'supervisor' (qua API) hoặc 'owner'
    (chủ kênh override — verdict khi đó là 'pass' hoặc 'skip').

    - pass → vòng 'passed'; lệnh gốc last_verdict='pass'.
    - rework → còn vòng: lệnh gốc xếp lại 'queued' cho agent gốc làm
      lại kèm ghi chú (review_round + 1); hết vòng → leo thang.
    - escalate → lệnh gốc sang needs_user kèm tóm tắt.
    - skip (chỉ owner) → vòng 'skipped', lệnh gốc không đổi trạng thái.

    Trả {"review": ..., "target": ..., "outcome": ...}. Ném ValueError
    với thông điệp rõ ràng khi vòng không tồn tại/đã chốt/verdict sai."""
    cfg = supervision_settings(settings)
    review = store.get_review_by_review_command(review_command_id)
    if review is None:
        raise ValueError(f"Không thấy vòng kiểm tra của lệnh kiểm tra '{review_command_id}'")
    if review["status"] != "open":
        raise ValueError("Vòng kiểm tra này đã có kết luận — không chấm lại được")
    target = store.get_command(review["command_id"])
    if target is None:
        raise ValueError(f"Lệnh gốc #{review['command_id']} không còn tồn tại")
    notes = (notes or "").strip()
    review_command = store.get_command(review_command_id)

    if actor == "owner" and verdict == "skip":
        decided = store.decide_review(
            review["id"], "skipped", "skip_by_owner", notes, checklist
        )
        store.set_command_review_state(target["id"], last_verdict="skipped")
        _close_review_command(store, review_command, "Đã bỏ qua kiểm tra theo quyết định của chủ kênh.")
        store.append_journal(
            f"{SUPERVISION_TAG} Chủ kênh BỎ QUA kiểm tra lệnh #{target['id']}.",
            target.get("profile_id"),
        )
        return {"review": decided, "target": store.get_command(target["id"]), "outcome": "skipped"}

    if verdict not in VERDICTS:
        raise ValueError(f"verdict phải là một trong {list(VERDICTS)} (hoặc 'skip' khi chủ kênh override)")
    verdict_label = verdict + ("_by_owner" if actor == "owner" else "")

    if verdict == VERDICT_PASS:
        decided = store.decide_review(
            review["id"], "passed", verdict_label, notes, checklist
        )
        store.set_command_review_state(target["id"], last_verdict="pass")
        _close_review_command(store, review_command, f"Kết luận: ĐẠT. {notes}".strip())
        store.append_journal(
            f"{SUPERVISION_TAG} ✅ Lệnh #{target['id']} ĐẠT kiểm tra "
            f"(Muse #{review['supervisor_agent_id']} chấm, vòng {review['round']}).",
            target.get("profile_id"),
        )
        return {"review": decided, "target": store.get_command(target["id"]), "outcome": "passed"}

    if verdict == VERDICT_REWORK:
        current_round = int(target.get("review_round") or 0)
        if current_round < cfg["max_rounds"]:
            decided = store.decide_review(
                review["id"], "rework", verdict_label, notes, checklist
            )
            _requeue_target_for_rework(store, target, review, notes, checklist)
            _close_review_command(store, review_command, f"Kết luận: CHƯA ĐẠT — đã trả làm lại. {notes}".strip())
            store.append_journal(
                f"{SUPERVISION_TAG} ↩ Lệnh #{target['id']} CHƯA ĐẠT — trả Muse "
                f"#{review['worker_agent_id']} làm lại (vòng {current_round + 1}/"
                f"{cfg['max_rounds']}): {notes[:200]}",
                target.get("profile_id"),
            )
            _notify_verdict_in_chat(store, target, review, "rework", notes)
            return {
                "review": decided,
                "target": store.get_command(target["id"]),
                "outcome": "rework",
            }
        # Hết vòng làm lại → leo thang như kết luận escalate.
        verdict = VERDICT_ESCALATE
        notes = (notes + " " if notes else "") + (
            f"(Đã hết {cfg['max_rounds']} vòng làm lại.)"
        )

    # escalate (trực tiếp hoặc do hết vòng làm lại)
    decided = store.decide_review(
        review["id"], "escalated", verdict_label, notes, checklist
    )
    store.set_command_review_state(target["id"], last_verdict="escalate")
    summary = (
        f"Kiểm tra chéo (Muse #{review['supervisor_agent_id']} chấm) cần anh "
        f"quyết định cho lệnh #{target['id']} ({target.get('type')}): {notes}"
        if notes else
        f"Kiểm tra chéo cần anh quyết định cho lệnh #{target['id']} "
        f"({target.get('type')}) — xem lịch sử kiểm tra trong chi tiết lệnh."
    )
    _close_review_command(store, review_command, f"Kết luận: LEO THANG chủ kênh. {notes}".strip())
    _force_needs_user(store, target, summary)
    store.append_journal(
        f"{SUPERVISION_TAG} ⬆ Lệnh #{target['id']} LEO THANG chủ kênh: {notes[:200]}",
        target.get("profile_id"),
    )
    _notify_verdict_in_chat(store, target, review, "escalate", notes)
    return {
        "review": decided,
        "target": store.get_command(target["id"]),
        "outcome": "escalated",
    }


def _force_needs_user(store: Store, target: dict, summary: str) -> None:
    """Đặt lệnh gốc sang 'needs_user' cho đường LEO THANG. Không dùng
    Store.set_command_needs_user vì hàm đó CHẶN lệnh đã ở trạng thái
    cuối — mà lệnh được kiểm tra thì theo định nghĩa đã done/failed
    (hoặc đang running với vòng 'stuck'): leo thang chính là mở lại
    quyết định cho chủ kênh trên một lệnh như vậy. Vẫn giữ đủ hệ quả
    phụ của đường chuẩn: nhả lease, cờ chặn tự-chạy-lại, và tin hệ
    thống vào luồng chat của Muse phụ trách."""
    store._conn.execute(
        "UPDATE commands SET status = 'needs_user',"
        " lease_agent_id = NULL, lease_expires_at = NULL,"
        " result = ?, error = NULL, step = ?, updated_at = ?"
        " WHERE id = ?",
        (summary, summary[:300], now_iso(), target["id"]),
    )
    store._conn.commit()
    try:
        from . import auto_retry

        store.update_command_payload_flags(
            target["id"],
            set_flags={auto_retry.KEY_HIT_NEEDS_USER: True},
        )
    except Exception:
        pass
    try:
        store._note_needs_user_in_chat(target, summary)
    except Exception:
        pass


def _close_review_command(store: Store, review_command: dict | None, result: str) -> None:
    """Chốt lệnh kiểm tra ở 'done' sau khi có kết luận (đi qua
    finish_command — hook giám sát tự bỏ qua loại 'review')."""
    if review_command is None or review_command.get("status") in ("done", "failed"):
        return
    store.finish_command(review_command["id"], "done", result=result)


def _requeue_target_for_rework(
    store: Store, target: dict, review: dict, notes: str,
    checklist: list | None,
) -> None:
    """Xếp lệnh gốc lại 'queued' cho chính agent gốc làm lại: giữ
    nguyên agent_id/lịch sử, đính kèm ghi chú + mục checklist chưa
    đạt vào payload.review_feedback, tăng review_round. Dispatcher
    sẽ promote lại như lệnh mới."""
    payload = dict(target.get("payload") or {})
    failed_items = [
        item for item in (checklist or review.get("checklist") or [])
        if isinstance(item, dict) and item.get("status") == "fail"
    ]
    payload["review_feedback"] = {
        "round": int(target.get("review_round") or 0) + 1,
        "by_supervisor_agent_id": review.get("supervisor_agent_id"),
        "notes": notes,
        "failed_items": failed_items,
        # Thiếu bằng chứng là lỗi hình thức hay gặp nhất — cờ đi
        # CÙNG khối feedback để phiên làm lại đọc một chỗ là đủ
        # (luật cứng plan §3 nằm ở hướng dẫn chấm; ở đây truy vết).
        "missing_evidence": not result_has_evidence(target),
    }
    import json as _json

    store._conn.execute(
        "UPDATE commands SET status = 'queued', progress = 0, step = '',"
        " result = NULL, error = NULL, started_at = NULL,"
        " finished_at = NULL, lease_agent_id = NULL,"
        " lease_expires_at = NULL, payload = ?, review_round = ?,"
        " last_verdict = 'rework', due_at = ?, updated_at = ? WHERE id = ?",
        (
            _json.dumps(payload, ensure_ascii=False),
            int(target.get("review_round") or 0) + 1,
            # V6.1: làm lại = hạn MỚI theo loại lệnh tính từ lúc trả việc.
            Store.default_due_at(target.get("type") or "") or target.get("due_at"),
            now_iso(),
            target["id"],
        ),
    )
    store._conn.commit()


def _notify_verdict_in_chat(
    store: Store, target: dict, review: dict, kind: str, notes: str,
) -> None:
    """GĐ2 (plan §7): kết luận Chưa đạt / leo thang tự sinh tin hệ
    thống vào luồng chat của agent BỊ CHẤM (để phiên của nó thấy việc
    làm lại ngay) và của giám sát viên. Khử trùng (§10): bỏ qua khi
    tin gần nhất trong luồng đã là đúng thông báo của vòng này.
    Best-effort — chat là kênh phụ, lỗi không làm hỏng kết luận."""
    label = "CHƯA ĐẠT — cần làm lại" if kind == "rework" else "LEO THANG chủ kênh"
    body = (
        f"[Kiểm tra chéo] Lệnh #{target['id']} ({target.get('type')}): {label}. "
        f"Ghi chú của Muse #{review.get('supervisor_agent_id')} (giám sát): "
        f"{notes[:400] if notes else '(không có ghi chú)'}"
    )
    for agent_id in (review.get("worker_agent_id"), review.get("supervisor_agent_id")):
        if agent_id is None:
            continue
        try:
            recent = store.list_messages(int(agent_id), limit=5)
            if any(
                m.get("direction") == "system" and m.get("body") == body
                for m in recent
            ):
                continue
            store.add_message(
                int(agent_id), "system", body, command_id=target["id"]
            )
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# Thẻ điểm (scorecard)
# --------------------------------------------------------------------------- #
def week_start_iso(now: datetime | None = None) -> str:
    """Mốc đầu tuần (thứ Hai 00:00 giờ địa phương) dạng ISO — thẻ
    điểm tính theo tuần dương lịch hiện tại."""
    now = now or datetime.now().astimezone()
    monday = (now - timedelta(days=now.weekday())).replace(
        hour=0, minute=0, second=0, microsecond=0
    )
    return monday.isoformat(timespec="seconds")


def scorecard(
    store: Store, agent_id: int, now: datetime | None = None,
) -> dict:
    """Thẻ điểm tuần của một agent (plan §6): % đạt ngay lần đầu,
    số vòng làm lại trung bình, số lần bị watchdog bắt treo, thời
    gian hoàn thành trung bình, số ca leo thang, số lệnh đã xong."""
    since = week_start_iso(now)
    passed0, decided0 = store.review_round_zero_pass_rate(int(agent_id), since)
    counts = store.review_verdict_counts(int(agent_id), since)
    decided_total = sum(counts.values())
    rework_count = counts.get("rework", 0)
    # Tổng số vòng đã qua trên các lệnh của agent này = tổng
    # review_round của các lệnh đã từng bị chấm trong tuần — suy từ
    # các vòng đã chốt: mỗi vòng 'rework' là một vòng làm lại.
    done_count, avg_seconds = store.command_completion_stats(int(agent_id), since)
    return {
        "agent_id": int(agent_id),
        "week_start": since,
        "first_pass_rate": (
            round(100.0 * passed0 / decided0, 1) if decided0 else None
        ),
        "first_pass_decided": decided0,
        "verdicts": counts,
        "rework_rounds": rework_count,
        "avg_rework_rounds": (
            round(rework_count / decided_total, 2) if decided_total else None
        ),
        "stuck_count": store.review_stuck_count(int(agent_id), since),
        "escalations": counts.get("escalated", 0),
        "commands_done": done_count,
        "deadline": store.deadline_stats(int(agent_id), since),
        "avg_completion_seconds": (
            round(avg_seconds, 1) if avg_seconds is not None else None
        ),
    }
