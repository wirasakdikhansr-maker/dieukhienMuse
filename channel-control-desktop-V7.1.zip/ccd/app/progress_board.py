"""V7.1 — BẢNG TIẾN ĐỘ CÔNG VIỆC từng agent (cột trái Văn phòng).

Mỗi agent một khối: việc ĐANG LÀM cụ thể ("Làm video kids tập 1 — kênh A"),
% tiến độ, bước Muse báo gần nhất, TIẾN ĐỘ CON đếm được ("cảnh 20/30"), ai giao
(trưởng phòng / bạn) + lúc nào, hạn chót, và số việc đang xếp hàng. Thuần dữ liệu.
"""

from __future__ import annotations

import re
from datetime import datetime

from .store import COMMAND_TYPE_LABELS, Store, _parse_iso

OPEN = ("running", "needs_user", "waiting_muse", "queued")
ORDER = {"running": 0, "needs_user": 1, "waiting_muse": 2, "queued": 3}
STATUS_TEXT = {
    "running": "Đang làm", "needs_user": "Đang hỏi", "waiting_muse": "Chờ nhận việc", "queued": "Xếp hàng",
}
# "cảnh 20/30", "scene 3 of 8", "video 2/5", "đã xong 12 trên 40 cảnh"
_SUB = re.compile(
    r"(?P<label>[A-Za-zÀ-ỹđĐ][\wÀ-ỹđĐ ]{0,20}?)\s*(?P<done>\d{1,4})\s*(?:/|trên|of)\s*(?P<total>\d{1,4})"
    r"(?:\s*(?P<unit>[A-Za-zÀ-ỹđĐ]{2,12}))?", re.IGNORECASE)


def sub_progress(text: str | None) -> dict | None:
    """Tiến độ đếm được trong câu Muse báo: {'label','done','total','pct'}."""
    for match in _SUB.finditer(text or ""):
        done, total = int(match.group("done")), int(match.group("total"))
        if total <= 0 or done > total or total > 5000:
            continue
        unit = (match.group("unit") or "").strip()
        before = (match.group("label") or "").strip(" :—-·").split(" ")[-1]
        label = unit if unit and unit.lower() not in ("xong", "done", "rồi") else before
        return {"label": label, "done": done, "total": total, "pct": round(100 * done / total)}
    return None


def task_title(command: dict) -> str:
    payload = command.get("payload") or {}
    assignment = payload.get("assignment") or {}
    title = payload.get("title") or assignment.get("template_title") or ""
    first = next((ln.strip() for ln in (command.get("instruction") or "").splitlines() if ln.strip()), "")
    if first.startswith("Trưởng phòng giao:"):
        first = first.split(":", 1)[1].strip()
    if not title:
        title = first or COMMAND_TYPE_LABELS.get(command.get("type"), command.get("type") or "Việc")
    return " ".join(title.split())[:110]


def _channel_name(command: dict, channels: dict, profiles: dict) -> str:
    key = (command.get("profile_id"), command.get("channel_id"))
    if key in channels:
        return channels[key]
    profile = profiles.get(command.get("profile_id"))
    return (profile or {}).get("label") or ""


def _assigned_by(command: dict) -> str:
    payload = command.get("payload") or {}
    if command.get("source") == "lead" or payload.get("plan"):
        return "Trưởng phòng"
    if command.get("source") in ("auto", "rule", "automation"):
        return "Tự động"
    return "Bạn"


def build(store: Store, settings: dict | None = None, now: datetime | None = None) -> dict:
    from . import supervision
    from .store import _command_row, agent_status

    now = now or datetime.now().astimezone()
    agents = [a for a in store.list_agents() if not a.get("revoked")]
    profiles = {p["id"]: p for p in store.list_profiles()}
    channels = {}
    for pid in profiles:
        for ch in store.list_channels(pid):
            channels[(pid, ch.get("channel_id"))] = ch.get("name") or ch.get("handle") or ""
    rows = store._conn.execute(
        "SELECT * FROM commands WHERE status IN ('running','needs_user','waiting_muse','queued')"
        " AND agent_id IS NOT NULL ORDER BY updated_at DESC LIMIT 600").fetchall()
    by_agent: dict[int, list[dict]] = {}
    for row in rows:
        c = _command_row(row)
        by_agent.setdefault(int(c["agent_id"]), []).append(c)
    try:
        lead_id = supervision.lead_agent_id(store, settings or {})
    except Exception:
        lead_id = None
    out = []
    for agent in agents:
        aid = int(agent["id"])
        tasks = sorted(by_agent.get(aid, []), key=lambda c: (ORDER.get(c["status"], 9), c.get("created_at") or ""))
        items = []
        for c in tasks:
            step = (c.get("step") or "").strip()
            due = _parse_iso(c.get("due_at")) if c.get("due_at") else None
            items.append({
                "id": c["id"],
                "title": task_title(c),
                "channel": _channel_name(c, channels, profiles),
                "status": c["status"],
                "status_text": STATUS_TEXT.get(c["status"], c["status"]),
                "pct": max(0, min(100, int(c.get("progress") or 0))),
                "step": step,
                "sub": sub_progress(step),
                "by": _assigned_by(c),
                "assigned_at": (_parse_iso(c.get("created_at")).strftime("%H:%M") if c.get("created_at") else ""),
                "due": due.strftime("%H:%M %d/%m") if due else "",
                "overdue": bool(due and due < now),
            })
        status = agent_status(agent.get("last_seen_at"), bool(agent.get("revoked")))
        out.append({
            "agent_id": aid,
            "name": agent.get("name") or agent.get("email") or f"Muse #{aid}",
            "lead": lead_id is not None and int(lead_id) == aid,
            "online": status == "online",
            "current": items[0] if items else None,
            "queue": items[1:],
        })
    out.sort(key=lambda a: (not a["lead"], a["current"] is None, ORDER.get((a["current"] or {}).get("status"), 9),
                            a["name"].lower()))
    lead_log = []
    try:
        for d in store.list_lead_decisions(limit=6):
            at = _parse_iso(d.get("at"))
            lead_log.append({"at": at.strftime("%H:%M") if at else "", "text": d.get("detail") or d.get("action") or ""})
    except Exception:
        pass
    busy = sum(1 for a in out if a["current"] and a["current"]["status"] == "running")
    return {"agents": out, "lead_log": lead_log, "busy": busy, "total": len(out)}
