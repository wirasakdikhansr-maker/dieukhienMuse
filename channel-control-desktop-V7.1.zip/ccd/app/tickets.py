"""Phiếu kết nối tài khoản Muse (V4.1.1) — ghi file phiếu ra đĩa.

Trước V4.1.1: mọi tài khoản dồn vào MỘT file "phieu-ket-noi-claude.txt"
xuất tay qua hộp Lưu file — dễ nhầm phiếu giữa các tài khoản, và cấp
lại token xong phải nhớ xuất lại thủ công (quên là cầu nối của Muse
đó mù âm thầm vì token trong phiếu cũ đã chết).

Nay:
- Mỗi tài khoản một file RIÊNG ``phieu-ket-noi-<slug>.txt`` (slug từ
  email của agent, không có email thì từ tên — ``config.slugify``),
  nội dung chỉ chứa thông tin đăng nhập của đúng tài khoản đó.
- File GỘP ``phieu-ket-noi-claude.txt`` giữ NGUYÊN định dạng cũ từng
  dòng (khối ``## <tên> (#<id>) — <email>`` + ``X-Agent-Id`` +
  ``X-Agent-Token`` + ``Hồ sơ phụ trách``): parser phía Muse (hook
  long-poll) tách khối theo ``^## `` và đọc đúng hai dòng id/token —
  KHÔNG được đổi định dạng này.
- Thư mục phiếu: settings ``ticket_export_dir``; chưa đặt thì mặc
  định ``<data dir>/phieu-ket-noi``.
- Panel Tài khoản Muse TỰ ghi lại phiếu ở mọi sự kiện vòng đời
  (thêm / cấp lại token / thu hồi / xoá tài khoản) qua các hàm ở đây;
  ghi lỗi thì nơi gọi nuốt lỗi và báo trạng thái — không bao giờ để
  việc ghi phiếu làm hỏng thao tác chính.
"""

from __future__ import annotations

from pathlib import Path

from . import config

COMBINED_FILENAME = "phieu-ket-noi-claude.txt"
SETTINGS_KEY = "ticket_export_dir"

_HEADER_LINES = [
    "PHIẾU KẾT NỐI TÀI KHOẢN MUSE — Channel Control Desktop",
    "Cầu nối: http://<địa chỉ Tailscale của PC này>:19500",
    "Mỗi Muse gọi API kèm 2 header: X-Agent-Id + X-Agent-Token (token riêng dưới đây).",
    "Heartbeat: POST /api/agents/<id>/heartbeat — báo tiến độ: POST /api/commands/<id>/progress.",
    "",
]


# V6.3: hướng dẫn ngắn các khả năng mới — nằm trong MỌI phiếu để phiên
# Muse đọc phiếu là biết dùng.
V63_GUIDE = [
    "=== V6.3 — BẮT BUỘC ĐỌC ===",
    "1. QUY TẮC + KPI: GET /api/rules (mỗi lệnh cũng có trường 'rules'). Làm đúng quy tắc; KPI của bạn: GET /api/agents/<id>/kpi.",
    "2. BÁO BƯỚC CỤ THỂ: mỗi lần POST /api/commands/<id>/progress ghi 'step' rõ việc đang làm (vd 'Render 62%'), app lưu thành lịch sử bước.",
    "3. NHÌN TRANG KHI THAO TÁC: tạo lệnh cdp_snapshot (profile=<slug>) để đọc URL/chữ/danh sách phần tử có số thứ tự;",
    "   cdp_click nhận 'element' (số thứ tự snapshot), 'label' (aria-label), 'text' hoặc 'selector'. Mọi cdp_* trả kèm 'page' (snapshot sau thao tác)",
    "   và 'screenshot_api' (GET /api/screenshots/<tên> trả ảnh base64). Gắn 'parent_command_id' để thao tác hiện thành bước của việc chính.",
    "   Quy trình dài lặp lại (đăng video...) dùng studio_script (nhiều bước chạy tại máy, nhanh hơn từng lệnh).",
    "4. FILE LỚN (hàng GB) TỪ SERVER CỦA BẠN VỀ MÁY: POST /api/files/upload {name,size,sha256,command_id?} → PUT /api/files/upload/<id>?offset=N",
    "   từng khúc 16MB → POST /api/files/upload/<id>/complete. Đứt mạng: GET /api/files/upload/<id> lấy offset rồi gửi tiếp.",
    "   Hoặc đưa link: POST /api/files/fetch {url,name?,command_id?} — app tự tải (nối tiếp được). tools/muse_client.py: send-large / fetch-url.",
    "5. TIN NHẮN: người dùng nhắn trong app sẽ được đẩy thẳng vào khung chat muse.ai của bạn — đọc GET /api/agents/<id>/messages?unread=1 và trả lời ngay.",
    "6. TRƯỞNG PHÒNG (nếu được chỉ định) nhận tin '[Trưởng phòng]' — nhân viên phải làm theo trong phạm vi quy tắc.",
    "",
]


def agent_ticket_slug(agent: dict) -> str:
    """Slug cho tên file phiếu riêng: từ email của agent (định danh
    ổn định nhất), agent thiếu email thì từ tên hiển thị."""
    base = (agent.get("email") or "").strip() or (agent.get("name") or "").strip()
    return config.slugify(base)


def agent_ticket_filename(agent: dict) -> str:
    return f"phieu-ket-noi-{agent_ticket_slug(agent)}.txt"


def ticket_export_dir(settings: dict | None, data_dir=None) -> Path:
    """Thư mục phiếu hiệu lực: settings 'ticket_export_dir' nếu đã
    đặt, ngược lại <data dir>/phieu-ket-noi."""
    stored = ((settings or {}).get(SETTINGS_KEY) or "").strip()
    if stored:
        return Path(stored).expanduser()
    base = Path(data_dir) if data_dir is not None else config.data_dir()
    return base / "phieu-ket-noi"


def _owned_labels(agent: dict, profiles: dict) -> list[str]:
    return [
        profiles[pid]["label"]
        for pid in agent.get("profile_ids") or []
        if pid in profiles
    ]


def _agent_block_lines(agent: dict, profiles: dict) -> list[str]:
    """Khối phiếu của MỘT agent — dùng chung cho file gộp và file
    riêng; định dạng là HỢP ĐỒNG với parser phía Muse, giữ nguyên."""
    owned = _owned_labels(agent, profiles)
    return [
        f"## {agent['name']} (#{agent['id']}) — {agent['email']}",
        f"X-Agent-Id: {agent['id']}",
        f"X-Agent-Token: {agent.get('token', '')}",
        f"Hồ sơ phụ trách: {', '.join(owned) if owned else '(chưa phân công)'}",
        "",
    ]


def combined_ticket_text(agents: list[dict], profiles: dict) -> str:
    """File gộp — định dạng Y HỆT bản xuất tay trước V4.1.1."""
    lines = list(_HEADER_LINES)
    for agent in agents:
        lines.extend(_agent_block_lines(agent, profiles))
    return "\n".join(lines)


def agent_ticket_text(agent: dict, profiles: dict) -> str:
    """File phiếu RIÊNG của một tài khoản: tiêu đề nêu rõ tài khoản,
    khối thông tin đăng nhập cùng định dạng file gộp (parser tách
    khối đọc được luôn), cộng vài dòng cách dùng. CHỈ chứa token của
    đúng tài khoản này."""
    lines = [
        f"PHIẾU KẾT NỐI RIÊNG — {agent['name']} ({agent['email']})",
        f"Tài khoản Muse #{agent['id']} — file này CHỈ chứa token của "
        "tài khoản này, đừng nhầm với phiếu của tài khoản khác.",
        "Cầu nối: http://<địa chỉ Tailscale của PC này>:19500",
        "",
    ]
    lines.extend(_agent_block_lines(agent, profiles))
    if agent.get("revoked"):
        lines.append(
            "⚠ Tài khoản này ĐÃ BỊ THU HỒI quyền cầu nối — token trên "
            "không còn hiệu lực cho tới khi được mở lại trong app."
        )
    lines.extend(
        [
            "Cách dùng: mọi lời gọi API kèm 2 header X-Agent-Id + "
            "X-Agent-Token ở trên.",
            "Heartbeat: POST /api/agents/<id>/heartbeat — báo tiến độ: "
            "POST /api/commands/<id>/progress.",
            "",
        ]
    )
    lines.extend(V63_GUIDE)
    return "\n".join(lines)


def write_all_tickets(store, folder: Path) -> Path:
    """Ghi file gộp + file riêng cho MỌI tài khoản vào ``folder``
    (tạo thư mục nếu chưa có). Trả đường dẫn file gộp."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    agents = store.list_agents()
    profiles = {p["id"]: p for p in store.list_profiles()}
    combined_path = folder / COMBINED_FILENAME
    combined_path.write_text(
        combined_ticket_text(agents, profiles), encoding="utf-8"
    )
    for agent in agents:
        (folder / agent_ticket_filename(agent)).write_text(
            agent_ticket_text(agent, profiles), encoding="utf-8"
        )
    return combined_path


def write_agent_ticket(store, agent_id: int, folder: Path) -> Path | None:
    """Ghi lại file riêng của MỘT tài khoản + làm tươi file gộp.
    Agent không còn tồn tại → None (nơi gọi dùng remove_agent_ticket
    cho trường hợp xoá). Trả đường dẫn file riêng."""
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    agent = store.get_agent(agent_id)
    if agent is None:
        return None
    profiles = {p["id"]: p for p in store.list_profiles()}
    path = folder / agent_ticket_filename(agent)
    path.write_text(agent_ticket_text(agent, profiles), encoding="utf-8")
    (folder / COMBINED_FILENAME).write_text(
        combined_ticket_text(store.list_agents(), profiles),
        encoding="utf-8",
    )
    return path


def remove_agent_ticket(agent: dict, folder: Path) -> None:
    """Xoá file phiếu riêng của một tài khoản ĐÃ bị xoá khỏi app —
    không để lại file chứa token mồ côi trên đĩa."""
    try:
        (Path(folder) / agent_ticket_filename(agent)).unlink(missing_ok=True)
    except OSError:
        pass
