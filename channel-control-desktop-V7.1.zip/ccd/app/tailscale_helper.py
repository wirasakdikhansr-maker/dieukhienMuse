"""Trợ lý Tailscale (V3.9) — CHỈ dùng thư viện chuẩn, không phụ thuộc Qt.

Bài học V3.8/V3.9: lệnh "Chờ Muse" không chạy được vì CẦU NỐI chưa
từng được nối, trong khi app im lặng. Cầu nối có HAI lớp độc lập:

1. Lớp vận chuyển — Tailscale TRÊN CHÍNH MÁY NÀY: máy Windows và thiết
   bị của Muse ("muse") phải cùng một mạng riêng (tailnet). Lớp này
   app tự kiểm tra được bằng CLI ``tailscale status --json`` và tự nối
   lại được bằng ``tailscale up`` khi tài khoản đã đăng nhập sẵn.
2. Lớp người gọi — một Muse thật cầm phiếu kết nối và gọi vào Agent
   API (theo dõi bền bằng store.bridge_state, V3.8).

Module này lo lớp 1: tìm tailscale.exe, đọc trạng thái, phân lớp trạng
thái (hàm thuần — test không cần máy Windows thật), chạy ``up`` và bắt
link đăng nhập khi CLI in ra. TUYỆT ĐỐI không đụng tới token của cầu
nối hay bất kỳ bí mật nào; đầu ra của CLI không chứa bí mật.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

# Tên thiết bị của phía Muse trong tailnet (đặt cố định phía Muse).
MUSE_DEVICE_NAME = "muse"

_AUTH_URL_RE = re.compile(r"https://login\.tailscale\.com/\S+")

# BackendState của tailscaled (theo tài liệu Tailscale):
#   Running     — đã kết nối
#   NeedsLogin  — chưa đăng nhập tài khoản
#   Stopped     — đã đăng nhập nhưng đang tắt kết nối
#   NoState / Starting / NeedsMachineAuth — các trạng thái trung gian


def find_tailscale(override: str | None = None) -> str | None:
    """Tìm tailscale.exe trên máy. Ưu tiên: override → biến môi trường
    CCD_TAILSCALE_PATH → vị trí cài chuẩn của Windows → PATH."""
    if override and Path(override).exists():
        return str(override)
    env = os.environ.get("CCD_TAILSCALE_PATH")
    if env and Path(env).exists():
        return env
    candidates: list[Path] = []
    for var in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"):
        root = os.environ.get(var)
        if root:
            candidates.append(Path(root) / "Tailscale" / "tailscale.exe")
    candidates.append(Path(r"C:\Program Files\Tailscale\tailscale.exe"))
    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    for name in ("tailscale", "tailscale.exe"):
        found = shutil.which(name)
        if found:
            return found
    return None


def _first_ipv4(ips) -> str:
    for ip in ips or []:
        if isinstance(ip, str) and ip.startswith("100."):
            return ip
    for ip in ips or []:
        if isinstance(ip, str) and ":" not in ip:
            return ip
    return ""


def parse_status_json(text: str) -> dict:
    """Phân tích đầu ra ``tailscale status --json`` (hàm thuần).

    Trả về dict trạng thái lớp vận chuyển:
      backend      — BackendState gốc ("Running"/"Stopped"/"NeedsLogin"…)
      connected    — backend == Running
      needs_login  — backend == NeedsLogin
      self_name    — tên máy này trong tailnet
      self_ip      — IPv4 100.x của máy này
      account      — email tài khoản Tailscale đang đăng nhập (nếu có)
      peers        — [{name, ip, online}] các máy khác trong tailnet
      muse_seen    — có thiết bị tên "muse" trong danh sách peer
      muse_online  — thiết bị "muse" đang trực tuyến
    JSON hỏng/thiếu → backend "Unknown", các trường còn lại rỗng."""
    state = {
        "backend": "Unknown",
        "connected": False,
        "needs_login": False,
        "self_name": "",
        "self_ip": "",
        "account": "",
        "peers": [],
        "muse_seen": False,
        "muse_online": False,
    }
    try:
        data = json.loads(text or "")
    except (json.JSONDecodeError, TypeError):
        return state
    if not isinstance(data, dict):
        return state
    backend = str(data.get("BackendState") or "Unknown")
    state["backend"] = backend
    state["connected"] = backend == "Running"
    state["needs_login"] = backend == "NeedsLogin"
    self_info = data.get("Self") or {}
    if isinstance(self_info, dict):
        state["self_name"] = str(self_info.get("HostName") or "")
        state["self_ip"] = _first_ipv4(self_info.get("TailscaleIPs"))
    users = data.get("User") or {}
    if isinstance(users, dict):
        for user in users.values():
            if isinstance(user, dict) and user.get("LoginName"):
                state["account"] = str(user["LoginName"])
                break
    peers = data.get("Peer") or {}
    if isinstance(peers, dict):
        for peer in peers.values():
            if not isinstance(peer, dict):
                continue
            name = str(peer.get("HostName") or "")
            entry = {
                "name": name,
                "ip": _first_ipv4(peer.get("TailscaleIPs")),
                "online": bool(peer.get("Online")),
            }
            state["peers"].append(entry)
            if name.strip().lower() == MUSE_DEVICE_NAME:
                state["muse_seen"] = True
                state["muse_online"] = entry["online"]
    return state


def classify(state: dict | None) -> str:
    """Phân lớp trạng thái lớp vận chuyển (hàm thuần):
      missing      — chưa cài Tailscale trên máy này
      needs_login  — đã cài, chưa đăng nhập tài khoản
      down         — đã đăng nhập nhưng chưa kết nối (app tự `up` được)
      no_muse      — đã kết nối nhưng không thấy thiết bị "muse" trực tuyến
      ok           — đã kết nối và thấy "muse" trực tuyến
      error        — CLI lỗi/không đọc được trạng thái
    """
    if not state or not state.get("installed"):
        return "missing"
    if state.get("backend") == "Error":
        return "error"
    if state.get("needs_login"):
        return "needs_login"
    if not state.get("connected"):
        return "down"
    if not state.get("muse_online"):
        return "no_muse"
    return "ok"


def layer_state(ts_state: dict | None, bridge: dict | None) -> tuple[str, str]:
    """Gộp HAI lớp thành một thông điệp sự thật cho banner (hàm thuần).

    Trả về (level, message) với level thuộc {"ok", "warn", "bad"}.
    Nguyên tắc: lớp vận chuyển hỏng thì nói lớp vận chuyển trước —
    Muse chưa gọi vào chỉ là vấn đề khi đường đã thông."""
    bridge = bridge or {"connected": False, "ever": False, "seconds_ago": None}
    if ts_state is not None:
        level = classify(ts_state)
        if level == "missing":
            return (
                "bad",
                "🌐 Tailscale: CHƯA CÀI trên máy này — lệnh của Muse không "
                "thể tới được app. Cài Tailscale, đăng nhập cùng tài khoản "
                "với phía Muse, rồi bấm “🔌 Kết nối Muse…” để app tự kiểm tra.",
            )
        if level == "needs_login":
            return (
                "bad",
                "🌐 Tailscale: CHƯA ĐĂNG NHẬP trên máy này — bấm “🔌 Kết nối "
                "Muse…” → “Kết nối Tailscale ngay”, app sẽ mở trang đăng "
                "nhập; đăng nhập CÙNG tài khoản Tailscale với phía Muse.",
            )
        if level == "down":
            return (
                "bad",
                "🌐 Tailscale: ĐÃ ĐĂNG NHẬP nhưng CHƯA KẾT NỐI — app tự "
                "chạy “tailscale up” để nối lại; hoặc bấm “🔌 Kết nối "
                "Muse…” → “Kết nối Tailscale ngay”.",
            )
        if level == "error":
            return (
                "warn",
                "🌐 Tailscale: không đọc được trạng thái "
                f"({ts_state.get('error') or 'lỗi lạ'}) — app sẽ tự kiểm tra lại.",
            )
        if level == "no_muse":
            seen = "có thấy nhưng đang ngoại tuyến" if ts_state.get("muse_seen") else "chưa thấy"
            return (
                "warn",
                f"🌐 Tailscale: ĐÃ KẾT NỐI (máy này: {ts_state.get('self_ip') or '—'}) "
                f"nhưng {seen} thiết bị “muse” của phía Muse — phía Muse "
                "chưa vào mạng hoặc chưa được duyệt thiết bị.",
            )
        # level == ok: đường thông — xét tiếp lớp người gọi.
        if bridge.get("connected"):
            return (
                "ok",
                "🔌 Cầu nối Muse: ĐANG KẾT NỐI (Tailscale thông, Muse "
                "đang gọi vào) — lệnh của Muse sẽ được nhận và thực hiện.",
            )
        if bridge.get("ever"):
            return (
                "warn",
                "🔌 Tailscale đã thông nhưng Muse ĐANG MẤT KẾT NỐI (đã "
                "từng gọi vào trước đây) — lệnh của Muse sẽ nằm chờ cho "
                "tới khi Muse gọi lại.",
            )
        return (
            "bad",
            "🔌 Tailscale đã thông (đã thấy thiết bị “muse”) nhưng Muse "
            "CHƯA TỪNG gọi vào app — Muse cần PHIẾU KẾT NỐI: tab 🤖 Tài "
            "khoản Muse → 📄 Xuất phiếu kết nối → gửi cho Muse.",
        )
    # Chưa có trạng thái Tailscale (bản cũ/kiểm tra chưa chạy): giữ hành
    # vi V3.8 — chỉ dựa vào bằng chứng cầu nối.
    if bridge.get("connected"):
        return (
            "ok",
            "🔌 Cầu nối Muse: ĐANG KẾT NỐI — lệnh của Muse sẽ được nhận và thực hiện.",
        )
    if bridge.get("ever"):
        return (
            "warn",
            "🔌 Cầu nối Muse: MẤT KẾT NỐI — lệnh của Muse sẽ nằm chờ "
            "cho tới khi Muse kết nối lại.",
        )
    return (
        "bad",
        "🔌 Cầu nối Muse: CHƯA CÓ MUSE NÀO KẾT NỐI — lệnh của Muse sẽ "
        "KHÔNG chạy được cho tới khi một Muse kết nối cầu nối này. Bấm "
        "“🔌 Kết nối Muse…” để xem hướng dẫn.",
    )


def extract_auth_url(text: str) -> str:
    """Bắt link đăng nhập/duyệt thiết bị mà `tailscale up` in ra."""
    match = _AUTH_URL_RE.search(text or "")
    return match.group(0) if match else ""


def _run_cli(args: list[str], timeout: float) -> tuple[int, str]:
    """Chạy tailscale CLI, gộp stdout+stderr. Trả về (returncode, text).
    Trên Windows dùng CREATE_NO_WINDOW để không bật cửa sổ console."""
    creationflags = 0
    if sys.platform.startswith("win"):
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    proc = subprocess.run(
        args,
        capture_output=True,
        text=True,
        timeout=timeout,
        creationflags=creationflags,
    )
    return proc.returncode, (proc.stdout or "") + (proc.stderr or "")


def run_status(exe: str | None, timeout: float = 12.0) -> dict:
    """Đọc trạng thái Tailscale thật trên máy này. exe=None (chưa cài)
    → state installed=False. CLI lỗi → backend "Error" + trường error."""
    if not exe:
        state = parse_status_json("")
        state.update({"installed": False, "exe": "", "error": ""})
        return state
    try:
        _rc, out = _run_cli([exe, "status", "--json"], timeout)
        state = parse_status_json(out)
        state.update({"installed": True, "exe": exe, "error": ""})
        if state["backend"] == "Unknown":
            state["backend"] = "Error"
            state["error"] = (out or "CLI không trả JSON").strip()[:200]
        return state
    except (OSError, subprocess.SubprocessError) as exc:
        state = parse_status_json("")
        state.update(
            {"installed": True, "exe": exe, "backend": "Error", "error": str(exc)[:200]}
        )
        return state


def run_up(exe: str, timeout: float = 30.0) -> dict:
    """Chạy ``tailscale up``. Khi tài khoản đã đăng nhập sẵn, lệnh này
    nối lại ngay và thoát 0. Khi cần đăng nhập, CLI in link
    login.tailscale.com rồi CHỜ duyệt — hết thời gian chờ thì giết
    tiến trình và trả về auth_url để app mở trình duyệt cho người dùng.

    Trả về {ok, auth_url, output} — output là đoạn cuối của CLI (không
    chứa bí mật nào)."""
    creationflags = 0
    if sys.platform.startswith("win"):
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.Popen(
            [exe, "up"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=creationflags,
        )
    except OSError as exc:
        return {"ok": False, "auth_url": "", "output": str(exc)[:300]}
    try:
        out, _ = proc.communicate(timeout=timeout)
        return {
            "ok": proc.returncode == 0,
            "auth_url": extract_auth_url(out or ""),
            "output": (out or "").strip()[-300:],
        }
    except subprocess.TimeoutExpired as exc:
        # Đang chờ người dùng đăng nhập/duyệt: phần CLI đã in nằm trong
        # exc.output của lần communicate đầu (giết tiến trình rồi đọc
        # tiếp có thể mất đoạn này) — gộp cả hai nguồn.
        partial = exc.output or ""
        if isinstance(partial, bytes):
            partial = partial.decode("utf-8", "replace")
        try:
            proc.kill()
            rest, _ = proc.communicate(timeout=5)
        except Exception:
            rest = ""
        out = (partial or "") + (rest or "")
        return {
            "ok": False,
            "auth_url": extract_auth_url(out),
            "output": out.strip()[-300:],
        }
