"""Gói sống sót trên PC local (V4.0 — H4): single-instance + autostart.

Phần LOGIC THUẦN (đóng gói/giải mã thông điệp focus, dựng lệnh khởi
động cùng Windows, cờ thoát-sạch) tách khỏi Qt/winreg để kiểm thử độc
lập; hiệu ứng thật (QLocalServer/QLocalSocket, khoá Run của Windows)
nằm ở các hàm mỏng phía dưới và chỉ chạy trên nền tương ứng.

- Single-instance: bản app đầu tiên giữ một QLocalServer tên cố định.
  Bản thứ hai mở lên → nối vào, gửi thông điệp "focus" (kèm argv để
  bản chính biết cửa sổ cần hiện) rồi thoát êm — chặn tận gốc cảnh hai
  tiến trình tranh cổng Agent API 19500 và cùng ghi một SQLite.
- Autostart: khoá Run ở HKCU (chỉ Windows, qua winreg); nền khác là
  no-op có ghi nhận. Lệnh khởi động luôn kèm cờ --autostart để app
  biết mình được mở tự động (vào thẳng tray, không bật cửa sổ).
- Cờ thoát sạch: app ghi file data/.clean_exit khi người dùng chọn
  Thoát hẳn; watchdog (app/watchdog.py) đọc nó để phân biệt "người
  dùng tự tắt" với "sập" — thoát sạch thì không mở lại.
"""

from __future__ import annotations

import json
import shlex
import sys
from pathlib import Path

SERVER_NAME = "ChannelControlDesktop-single-instance"
AUTOSTART_VALUE_NAME = "ChannelControlDesktop"
CLEAN_EXIT_FILE = ".clean_exit"
_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"


# --------------------------------------------------------------------------- #
# Thông điệp focus giữa hai bản app
# --------------------------------------------------------------------------- #
def build_focus_message(argv: list[str] | None = None) -> bytes:
    """Đóng gói thông điệp bản-thứ-hai → bản-chính: hiện cửa sổ lên."""
    payload = {"action": "focus", "args": list(argv or [])}
    return (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")


def parse_focus_message(data: bytes) -> dict | None:
    """Giải mã thông điệp focus; rác/không đúng dạng → None."""
    try:
        payload = json.loads(bytes(data).decode("utf-8").strip())
    except (ValueError, UnicodeDecodeError):
        return None
    if not isinstance(payload, dict) or payload.get("action") != "focus":
        return None
    return payload


def notify_existing_instance(argv: list[str] | None = None, timeout_ms: int = 700) -> bool:
    """Thử nối vào bản app đang chạy và gửi thông điệp focus.
    True = đã có bản chính nhận (bản này nên thoát). Qt được import
    lười trong hàm để module vẫn thuần cho kiểm thử logic."""
    try:
        from PySide6.QtNetwork import QLocalSocket
    except ImportError:
        return False
    socket = QLocalSocket()
    socket.connectToServer(SERVER_NAME)
    if not socket.waitForConnected(timeout_ms):
        return False
    socket.write(build_focus_message(argv))
    socket.flush()
    socket.waitForBytesWritten(timeout_ms)
    socket.disconnectFromServer()
    return True


# --------------------------------------------------------------------------- #
# Autostart cùng Windows
# --------------------------------------------------------------------------- #
def build_autostart_command(
    executable: str,
    script_path: str | None = None,
    frozen: bool = False,
    watchdog: bool = True,
) -> str:
    """Dựng dòng lệnh cho khoá Run: bản frozen chạy thẳng exe; bản
    nguồn chạy `pythonw/python <run_exe.py>`. Luôn có --autostart;
    mặc định bọc --watchdog để sập là tự mở lại (H4.3)."""
    parts = [f'"{executable}"']
    if not frozen and script_path:
        parts.append(f'"{script_path}"')
    if watchdog:
        parts.append("--watchdog")
    parts.append("--autostart")
    return " ".join(parts)


def set_autostart(enabled: bool, command: str, registry=None) -> str:
    """Bật/tắt khoá Run. Trả 'ok' | 'noop:<lý do>'.

    ``registry``: module winreg (hoặc bản giả trong test). Không
    truyền → tự import winreg khi đang ở Windows; nền khác → noop."""
    if registry is None:
        if not sys.platform.startswith("win"):
            return "noop:not-windows"
        try:
            import winreg as registry  # type: ignore[import-not-found]
        except ImportError:
            return "noop:no-winreg"
    try:
        key = registry.OpenKey(
            registry.HKEY_CURRENT_USER, _RUN_KEY, 0, registry.KEY_SET_VALUE
        )
    except OSError as exc:
        return f"noop:open-key-failed:{exc}"
    try:
        if enabled:
            registry.SetValueEx(
                key, AUTOSTART_VALUE_NAME, 0, registry.REG_SZ, command
            )
        else:
            try:
                registry.DeleteValue(key, AUTOSTART_VALUE_NAME)
            except FileNotFoundError:
                pass  # chưa từng bật — tắt là xong, không phải lỗi
    finally:
        registry.CloseKey(key)
    return "ok"


# --------------------------------------------------------------------------- #
# Cờ thoát sạch (cho watchdog)
# --------------------------------------------------------------------------- #
def mark_clean_exit(data_dir) -> None:
    path = Path(data_dir) / CLEAN_EXIT_FILE
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("clean\n", encoding="utf-8")
    except OSError:
        pass


def was_clean_exit(data_dir) -> bool:
    return (Path(data_dir) / CLEAN_EXIT_FILE).exists()


def clear_clean_exit(data_dir) -> None:
    try:
        (Path(data_dir) / CLEAN_EXIT_FILE).unlink()
    except OSError:
        pass


def split_child_argv(argv: list[str]) -> list[str]:
    """argv cho tiến trình con của watchdog: bỏ cờ --watchdog (con
    không được tự làm watchdog lồng nhau), giữ mọi cờ còn lại."""
    return [arg for arg in argv if arg != "--watchdog"]


def quote_command(argv: list[str]) -> str:
    """Ghép argv thành một dòng lệnh (hiển thị/log + khoá Run)."""
    return " ".join(shlex.quote(str(a)) for a in argv)
