"""V6.3 — TRƯỞNG PHÒNG TỰ XỬ LÝ SỰ CỐ (không cần người dùng can thiệp).

Chạy trong nhịp tự động của cầu nối (mỗi ~15 giây, tự tiết lưu 60 giây).
Với mỗi sự cố ở khối "Sự cố cần xử lý" (app.office_issues), trưởng
phòng ra quyết định TRONG PHẠM VI CHO PHÉP:

| Sự cố                     | Quyết định tự động                                         |
|---------------------------|------------------------------------------------------------|
| Lệnh thất bại (lỗi tạm)   | Thử lại (tối đa lead_max_auto_retries lần / lệnh)          |
| Lệnh thất bại (nội dung)  | Nhắn người làm sửa + làm lại, rồi xếp lại hàng             |
| Chờ người, chưa ghi lý do | Nhắn người làm ghi rõ lý do / tự chạy tiếp                 |
| Chờ người: đăng nhập/OTP  | LEO THANG lên người dùng (việc của người thật)             |
| Trễ hạn lần 1             | Gia hạn lead_extend_minutes + nhắc người làm               |
| Trễ hạn lần 2+            | Chuyển việc cho Muse rảnh nhất đang online (nếu chưa ai giữ)|
| Chờ nhận quá lâu          | Chuyển cho Muse rảnh nhất đang online                      |
| Hồ sơ chưa phân công      | Phân công cho Muse ít việc nhất                            |
| Muse ngoại tuyến ôm việc  | Chuyển việc chưa bắt đầu sang Muse đang online             |
| Cầu nối / lỗi tự động     | Leo thang (cần người kiểm tra máy)                         |

Mọi quyết định ghi vào bảng lead_decisions (outcome 'done' = tự xử lý,
'escalated' = phải nhờ người dùng) + Nhật ký + nhắn cho người làm qua
luồng chat. Tỉ lệ tự xử lý là một chỉ số KPI của trưởng phòng.

THAY TRƯỞNG PHÒNG: mỗi giờ chấm KPI trưởng phòng; dưới ngưỡng "đạt"
lead_replace_after lần liên tiếp → app tự chọn Muse có KPI cao nhất
làm trưởng phòng mới (ghi Nhật ký + báo cả hai).
"""

from __future__ import annotations

from datetime import datetime, timedelta

from . import kpi, office_issues, supervision
from .store import CLAUDE_COMMAND_TYPES, Store, _parse_iso

THROTTLE_KEY = "lead_autopilot_last_run"
STREAK_KEY = "lead_kpi_fail_streak"
LEAD_CHECK_KEY = "lead_kpi_last_check"
COOLDOWN_MINUTES = 15
TEMPORARY_ACTIONS = {"retry"}
HUMAN_ACTIONS = {"open_profile"}
LEAD_TAG = "[Trưởng phòng]"
# V6.5: đường GỬI THẬT tới Muse (cầu nối chat muse.ai). MainWindow gắn
# hàm send(agent_id, text, command_id) vào đây; None → chỉ ghi tin vào
# luồng chat trong app như trước.
SENDER = None
# V7.0: MainWindow gắn hàm (command, question) để trưởng phòng (AI) trả lời thay chủ kênh.
QUESTION_HANDLER = None
_FULL_AUTHORITY = True
UI_OWNER_KEY = "lead_ui_owner_at"   # MainWindow chạy trưởng phòng → cầu nối API nhường
SELF_FIX_LIMIT = 2                  # số lần trưởng phòng bắt Muse tự xử lý trước khi báo người dùng
PROGRESS_PING_LIMIT = 3             # số lần đòi báo tiến độ không phản hồi → coi là kẹt, chuyển người
ACK_WAIT_MINUTES = 3                # V6.6: giao việc xong mà chưa nghe "ĐÃ NHẬN" sau 3 phút → hỏi lại
ACK_PING_LIMIT = 2                  # hỏi 2 lần vẫn im → chuyển việc cho người khác


def _now(now=None) -> datetime:
    return now or datetime.now().astimezone()


def _cooling(store: Store, key: str, now: datetime) -> bool:
    last = store.last_lead_decision_for(key)
    if not last:
        return False
    at = _parse_iso(last.get("at"))
    return at is not None and now - at < timedelta(minutes=COOLDOWN_MINUTES)


def _online_agents(store: Store, exclude: set[int] | None = None) -> list[dict]:
    from .store import agent_status

    out = []
    for agent in store.list_agents():
        if agent.get("revoked") or int(agent["id"]) in (exclude or set()):
            continue
        if agent_status(agent.get("last_seen_at"), agent.get("revoked")) == "online":
            out.append(agent)
    return out


def _load(store: Store, agent_id: int) -> int:
    try:
        return int(store._conn.execute(
            "SELECT COUNT(*) FROM commands WHERE agent_id = ? AND status IN"
            " ('queued','waiting_muse','running','needs_user')", (int(agent_id),),
        ).fetchone()[0])
    except Exception:
        return 0


def _least_loaded(store: Store, candidates: list[dict]) -> dict | None:
    if not candidates:
        return None
    return min(candidates, key=lambda a: (_load(store, a["id"]), int(a["id"])))


def _tell(store: Store, agent_id, text: str, command_id=None) -> None:
    """Nhắn cho người làm: tin 'user' để phiên Muse đọc ở luồng của nó."""
    if agent_id is None:
        return
    # V6.7: tin về một việc LUÔN kèm nội dung việc — bản cũ chỉ gửi mã
    # "#c129acf35228" nên Muse trả lời "chỉ có mã, chưa có nội dung lệnh".
    if command_id:
        command = store.get_command(command_id)
        if command is not None:
            summary = task_summary(command)
            if summary and summary not in text:
                text = f"{text}\nNội dung việc #{command_id}: {summary}"
    body = f"{LEAD_TAG} {text}"[:3900]
    try:
        store.add_message(int(agent_id), "user", body, command_id=command_id)
    except Exception:
        pass
    if SENDER is not None:
        try:
            agent = store.get_agent(int(agent_id))
            if agent is not None and not agent.get("revoked"):
                SENDER(agent, body, command_id)
        except Exception:
            pass


def task_summary(command: dict, limit: int = 400) -> str:
    instruction = " ".join((command.get("instruction") or "").split())
    payload = command.get("payload") or {}
    title = payload.get("title") or ""
    parts = [p for p in (title, instruction) if p]
    text = " — ".join(parts) or (command.get("type") or "")
    return text[:limit]


def _count(store: Store, command_id: str, action: str) -> int:
    return sum(1 for d in store.list_lead_decisions(limit=1000)
               if d.get("command_id") == command_id and d.get("action") == action)


def _self_fix(store, lead_id, issue, command, owner, why: str) -> dict | None:
    """V6.5 — TOÀN QUYỀN: thay vì đẩy việc về người dùng, trưởng phòng
    bắt Muse tự xử lý trên trình duyệt nhúng (Muse điều khiển được qua
    lệnh CCD trong chat) rồi cho lệnh chạy tiếp. Chỉ báo người dùng khi
    đã thử SELF_FIX_LIMIT lần mà vẫn kẹt."""
    tried = _count(store, command["id"], "self_fix")
    # V6.7 TOÀN QUYỀN: tự xử lý nhiều vòng hơn (mỗi vòng cách 15 phút) trước khi báo bạn
    limit = SELF_FIX_LIMIT * 3 if _FULL_AUTHORITY else SELF_FIX_LIMIT
    if tried >= SELF_FIX_LIMIT and _count(store, command["id"], "reassign") < 2:
        target = _reassign(store, command, {int(owner)} if owner else set())
        if target is not None:
            _resume_any(store, command["id"])
            _tell(store, target["id"], f"Bạn nhận lệnh #{command['id']} ({why}; người trước không tự xử lý được). "
                                       "Tự xử lý trên trình duyệt nhúng của hồ sơ rồi làm tiếp, báo TIẾN ĐỘ cụ thể.",
                  command["id"])
            return _decide(store, lead_id, issue, "reassign",
                           f"Chuyển lệnh #{command['id']} sang {target['name']} sau {tried} lần tự xử lý không xong ({why}).",
                           agent_id=target["id"])
    if tried >= limit:
        return _decide(store, lead_id, issue, "escalate",
                       f"{issue.get('title')}: đã bắt Muse tự xử lý {tried} lần + đã chuyển người — "
                       "cần bạn thao tác (vd nhập mã 2FA thật).", outcome="escalated")
    _resume_any(store, command["id"])
    _tell(store, owner,
          f"Lệnh #{command['id']} kẹt vì: {why}. Bạn có TOÀN QUYỀN điều khiển trình duyệt nhúng của hồ sơ "
          "(dùng khối ```ccd``` như hướng dẫn) — tự mở, đăng nhập lại/bấm qua bước kẹt rồi làm tiếp. "
          "Chỉ khi cần mã/thiết bị của chủ kênh mới trả lời CẦN BẠN: … kèm việc cụ thể.", command["id"])
    return _decide(store, lead_id, issue, "self_fix",
                   f"Bắt Muse tự xử lý lệnh #{command['id']} ({why}) — lần {tried + 1}/{limit}.")


def _resume_any(store: Store, command_id: str) -> None:
    command = store.get_command(command_id)
    if command is None:
        return
    try:
        if command["status"] == "needs_user":
            store.resume_command(command_id)
        elif command["status"] in ("failed", "interrupted"):
            store.requeue_command(command_id)
        store.update_command_payload_flags(command_id, clear_keys=("chat_sent",))
    except Exception:
        pass


def _decide(store, lead_id, issue, action, detail, outcome="done", command_id=None, agent_id=None):
    record = store.add_lead_decision(
        lead_id, issue.get("key", ""), action, command_id=command_id or issue.get("command_id"),
        agent_id=agent_id if agent_id is not None else issue.get("agent_id"),
        detail=detail, outcome=outcome,
    )
    icon = "🤖" if outcome == "done" else "⬆"
    store.append_journal(f"{LEAD_TAG} {icon} {detail}", issue.get("profile_id"))
    return record


def _reassign(store: Store, command: dict, exclude: set[int]) -> dict | None:
    """Chuyển lệnh CHƯA có ai giữ lease sang Muse online rảnh nhất."""
    if command.get("lease_agent_id") and command.get("status") == "running":
        lease_end = _parse_iso(command.get("lease_expires_at"))
        if lease_end and lease_end > _now():
            return None
    target = _least_loaded(store, _online_agents(store, exclude))
    if target is None:
        return None
    store.set_command_agent(command["id"], int(target["id"]))
    # V6.5: việc đổi người → cầu nối chat gửi lại cho người MỚI.
    # V6.7: gửi lại TRỌN nội dung việc (dạng giao việc, chờ ĐÃ NHẬN) —
    # việc đang 'running' của người cũ về 'waiting_muse' để được giao lại.
    try:
        store.update_command_payload_flags(command["id"], clear_keys=("chat_sent", "acked", "chat_sent_at"))
        if command.get("status") == "running":
            store.update_command(command["id"], status="waiting_muse")
    except Exception:
        pass
    return target


def handle_issue(store: Store, issue: dict, lead_id: int | None, cfg: dict, now: datetime,
                 ignore_cooldown: bool = False) -> dict | None:
    kind = issue.get("kind")
    key = issue.get("key") or ""
    if not ignore_cooldown and _cooling(store, key, now):
        return None
    global _FULL_AUTHORITY
    _FULL_AUTHORITY = bool(cfg.get("lead_full_authority", True))
    command = store.get_command(issue["command_id"]) if issue.get("command_id") else None
    owner = issue.get("agent_id")

    if kind in ("bridge", "auto_error"):
        return _decide(store, lead_id, issue, "escalate",
                       f"Không tự xử lý được: {issue.get('title')} — cần người kiểm tra máy/kết nối.",
                       outcome="escalated")

    if kind == "failed" and command is not None:
        _fix, primary = office_issues.suggest_fix(issue.get("detail") or "", "")
        attempts = int(command.get("attempts") or 0)
        if primary in HUMAN_ACTIONS:
            return _self_fix(store, lead_id, issue, command, owner, issue.get("detail") or "cần thao tác trên trình duyệt")
        if attempts >= int(cfg.get("lead_max_auto_retries", 2)) + 1:
            return _self_fix(store, lead_id, issue, command, owner,
                             f"đã thử lại {attempts} lần vẫn lỗi: {issue.get('detail') or ''}")
        if primary != "retry" and command.get("type") in CLAUDE_COMMAND_TYPES:
            _tell(store, owner, f"Lệnh #{command['id']} thất bại ({issue.get('detail')}). "
                                "Sửa đúng nguyên nhân rồi làm lại; báo bước cụ thể khi làm.", command["id"])
        if store.requeue_command(command["id"]) is None:
            return None
        return _decide(store, lead_id, issue, "retry",
                       f"Tự xếp lại lệnh #{command['id']} ({issue.get('title')}) — lần {attempts + 1}.")

    if kind == "needs_user" and command is not None:
        # V7.0: câu hỏi/thắc mắc của agent → TRƯỞNG PHÒNG TRẢ LỜI THAY chủ kênh
        # (qua AI trưởng phòng, hoặc theo chính sách tự quyết). Chỉ mã 2FA/OTP,
        # mật khẩu, thanh toán… mới còn để người dùng.
        from . import lead_answer

        question = " ".join(x for x in (command.get("error"), command.get("step"), command.get("result"),
                                        issue.get("detail")) if x)
        _fix0, primary0 = office_issues.suggest_fix(issue.get("detail") or "", "")
        if primary0 not in HUMAN_ACTIONS and cfg.get("lead_answers_questions", True) \
                and not lead_answer.human_only(question):
            handled = False
            if QUESTION_HANDLER is not None:
                try:
                    QUESTION_HANDLER(command, question)
                    handled = True
                except Exception:
                    handled = False
            if not handled:
                _resume_any(store, command["id"])
                _tell(store, owner, lead_answer.forward_text(
                    command, lead_answer.policy_answer(command, question, cfg), by_lead=False), command["id"])
            return _decide(store, lead_id, issue, "answer",
                           f"Trả lời thay chủ kênh câu hỏi của việc #{command['id']} — Muse làm tiếp, không cần bạn.")
        _fix, primary = office_issues.suggest_fix(issue.get("detail") or "", "")
        if primary in HUMAN_ACTIONS:
            return _self_fix(store, lead_id, issue, command, owner, issue.get("detail") or "cần đăng nhập/nhập mã")
        _tell(store, owner,
              f"Lệnh #{command['id']} đang 'chờ người' mà lý do chưa rõ. Nếu tự làm tiếp được thì chạy tiếp ngay; "
              "nếu thật sự cần người dùng, ghi RÕ cần làm gì.", command["id"])
        if "chưa ghi lý do" in (issue.get("detail") or ""):
            for cid in issue.get("command_ids") or [command["id"]]:
                try:
                    store.resume_command(cid)
                except Exception:
                    pass
            return _decide(store, lead_id, issue, "resume",
                           f"Cho chạy tiếp {len(issue.get('command_ids') or [1])} lệnh chờ người không lý do + nhắc người làm.")
        return _decide(store, lead_id, issue, "nudge",
                       f"Nhắc Muse làm rõ/chạy tiếp: {issue.get('title')}.")

    if kind == "overdue" and command is not None:
        extended = [d for d in store.list_lead_decisions(limit=500)
                    if d.get("command_id") == command["id"] and d.get("action") == "extend"]
        if not extended:
            minutes = int(cfg.get("lead_extend_minutes", 30))
            store.extend_command_due(command["id"], minutes)
            _tell(store, owner, f"Lệnh #{command['id']} đã trễ hạn — gia hạn {minutes} phút LẦN DUY NHẤT. "
                                "Báo tiến độ cụ thể ngay.", command["id"])
            return _decide(store, lead_id, issue, "extend", f"Gia hạn {minutes} phút cho lệnh #{command['id']} + nhắc người làm.")
        target = _reassign(store, command, {int(owner)} if owner else set())
        if target is not None:
            store.extend_command_due(command["id"], int(cfg.get("lead_extend_minutes", 30)))
            _tell(store, target["id"], f"Bạn nhận lệnh #{command['id']} (chuyển từ người làm trễ hạn).", command["id"])
            return _decide(store, lead_id, issue, "reassign",
                           f"Chuyển lệnh trễ hạn #{command['id']} sang {target['name']}.", agent_id=target["id"])
        # V6.5: không ai nhận thay → KHÔNG để lịch treo: gia hạn ngắn
        # thêm + đòi báo tiến độ ngay (lặp lại mỗi nhịp nguội 15 phút).
        store.extend_command_due(command["id"], max(15, int(cfg.get("lead_extend_minutes", 30)) // 2))
        _tell(store, owner, f"Lệnh #{command['id']} trễ hạn — hoàn thành ngay. Trả lời ngay theo mẫu "
                            "TIẾN ĐỘ: <số>% — <bước đang làm> — <bước tiếp theo>.", command["id"])
        return _decide(store, lead_id, issue, "nudge",
                       f"Gia hạn ngắn + đòi báo tiến độ lệnh trễ hạn #{command['id']} (không có Muse rảnh để chuyển).")

    if kind == "unclaimed" and command is not None:
        target = _reassign(store, command, {int(owner)} if owner else set())
        if target is None:
            _tell(store, owner, f"Lệnh #{command['id']} chờ nhận quá lâu — nhận ngay.", command["id"])
            return _decide(store, lead_id, issue, "nudge", f"Nhắc nhận lệnh #{command['id']}.")
        _tell(store, target["id"], f"Bạn nhận lệnh #{command['id']} (người được giao chưa nhận).", command["id"])
        return _decide(store, lead_id, issue, "reassign",
                       f"Chuyển lệnh chờ nhận #{command['id']} sang {target['name']}.", agent_id=target["id"])

    if kind == "unassigned" and issue.get("profile_id"):
        candidates = [a for a in store.list_agents() if not a.get("revoked")]
        target = _least_loaded(store, _online_agents(store) or candidates)
        if target is None:
            return None
        store.ensure_agent_assignment(int(target["id"]), int(issue["profile_id"]))
        return _decide(store, lead_id, issue, "assign",
                       f"Phân công hồ sơ #{issue['profile_id']} cho {target['name']} (ít việc nhất).", agent_id=target["id"])

    if kind == "agent_offline" and owner is not None:
        moved = 0
        for row in store.list_open_commands(limit=500):
            if row.get("agent_id") != owner or row.get("status") not in ("queued", "waiting_muse"):
                continue
            if _reassign(store, row, {int(owner)}) is not None:
                moved += 1
        if moved:
            return _decide(store, lead_id, issue, "reassign", f"Chuyển {moved} việc chưa bắt đầu của Muse ngoại tuyến sang Muse online.")
        return _decide(store, lead_id, issue, "escalate",
                       f"{issue.get('title')}: không có Muse online để nhận thay — cần kiểm tra kết nối.", outcome="escalated")
    return None


def run(store: Store, settings: dict, now: datetime | None = None, force: bool = False,
        save_settings=None, ignore_cooldown: bool = False) -> list[dict]:
    """Một nhịp tự xử lý. Trả danh sách quyết định vừa ra."""
    cfg_rules = kpi.rules_settings(settings)
    now = _now(now)
    if not cfg_rules["lead_auto_fix"]:
        return []
    if not force:
        last = _parse_iso(store.get_meta(THROTTLE_KEY) or "")
        if last and now - last < timedelta(seconds=60):
            return []
    store.set_meta(THROTTLE_KEY, now.isoformat(timespec="seconds"))
    lead = supervision.lead_agent_id(store, settings)
    decisions: list[dict] = []
    replaced = maybe_replace_lead(store, settings, now, save_settings)
    if replaced:
        decisions.append(replaced)
        lead = supervision.lead_agent_id(store, settings)
    try:
        issues = office_issues.collect_issues(store, now=now)
    except Exception:
        issues = []
    try:
        decisions.extend(ack_watch(store, settings, lead, now))
    except Exception as exc:  # noqa: BLE001
        store.append_journal(f"{LEAD_TAG} Lỗi khi hỏi xác nhận nhận việc: {exc}")
    try:
        decisions.extend(progress_watch(store, settings, lead, now))
    except Exception as exc:  # noqa: BLE001
        store.append_journal(f"{LEAD_TAG} Lỗi khi đòi báo tiến độ: {exc}")
    for issue in issues:
        try:
            record = handle_issue(store, issue, lead, settings, now, ignore_cooldown=ignore_cooldown)
        except Exception as exc:  # một sự cố lỗi không chặn sự cố khác
            store.append_journal(f"{LEAD_TAG} Lỗi khi xử lý '{issue.get('title')}': {exc}")
            continue
        if record:
            decisions.append(record)
    return decisions


def ack_watch(store: Store, settings: dict, lead_id, now: datetime) -> list[dict]:
    """V6.6 — GIAO VIỆC HAI CHIỀU: đã chuyển việc tới Muse mà sau
    ACK_WAIT_MINUTES vẫn chưa nghe "ĐÃ NHẬN việc #id" → trưởng phòng hỏi
    lại "X ơi, đã nhận việc #id chưa?"; hỏi ACK_PING_LIMIT lần vẫn im →
    chuyển việc cho Muse rảnh khác."""
    out = []
    for command in store.list_open_commands(limit=300):
        payload = command.get("payload") or {}
        if not payload.get("chat_sent") or payload.get("acked"):
            continue
        if command.get("status") not in ("waiting_muse", "running"):
            continue
        sent_at = _parse_iso(payload.get("chat_sent_at"))
        if sent_at is None or now - sent_at < timedelta(minutes=ACK_WAIT_MINUTES):
            continue
        owner = command.get("agent_id") or command.get("lease_agent_id")
        if owner is None:
            continue
        pings = [d for d in store.list_lead_decisions(limit=1000)
                 if d.get("command_id") == command["id"] and d.get("action") == "ack_ping"
                 and (_parse_iso(d.get("at")) or now) >= sent_at]
        if pings and now - (_parse_iso(pings[-1].get("at")) or now) < timedelta(minutes=ACK_WAIT_MINUTES):
            continue
        agent = store.get_agent(int(owner)) or {}
        name = agent.get("name") or f"Muse #{owner}"
        issue = {"key": f"ack:{command['id']}", "command_id": command["id"], "agent_id": owner,
                 "profile_id": command.get("profile_id"), "title": f"{name} chưa xác nhận việc #{command['id']}"}
        if len(pings) >= ACK_PING_LIMIT:
            target = _reassign(store, command, {int(owner)})
            if target is not None:
                _tell(store, target["id"], f"{target['name']} ơi, nhận việc #{command['id']} giúp (người trước chưa "
                                           f"xác nhận). Trả lời mở đầu bằng: ĐÃ NHẬN việc #{command['id']}.",
                      command["id"])
                out.append(_decide(store, lead_id, issue, "reassign",
                                   f"{name} không xác nhận việc #{command['id']} sau {len(pings)} lần hỏi → giao {target['name']}.",
                                   agent_id=target["id"]))
            continue
        _tell(store, owner, f"{name} ơi, đã nhận được việc #{command['id']} chưa? "
                            f"Trả lời ngay, mở đầu bằng: ĐÃ NHẬN việc #{command['id']} — <bước đầu tiên>.",
              command["id"])
        out.append(_decide(store, lead_id, issue, "ack_ping",
                           f"Hỏi {name} đã nhận việc #{command['id']} chưa (lần {len(pings) + 1}).", agent_id=owner))
    return out


def progress_watch(store: Store, settings: dict, lead_id, now: datetime) -> list[dict]:
    """V6.5 — BẮT BUỘC BÁO TIẾN ĐỘ: việc đang chờ/đang làm mà quá
    ``lead_progress_minutes`` (mặc định 10) không có cập nhật → trưởng
    phòng nhắn Muse báo theo mẫu "TIẾN ĐỘ: x% — …" (app tự đọc số này
    vào bảng việc). Hỏi PROGRESS_PING_LIMIT lần không phản hồi → coi là
    kẹt: chuyển Muse khác (hoặc báo người dùng nếu hết người)."""
    from . import office_feed

    minutes = max(3, int(settings.get("lead_progress_minutes", 10) or 10))
    off_hours = office_feed.work_mode(settings, now) == "off"
    out = []
    for command in store.list_open_commands(limit=300):
        if command.get("status") not in ("running", "waiting_muse") or command.get("type") == "review":
            continue
        if off_hours and not office_feed.is_urgent(command):
            continue  # V6.6: ngoài giờ không đòi tiến độ việc thường
        updated = _parse_iso(command.get("updated_at"))
        if updated is None or now - updated < timedelta(minutes=minutes):
            continue
        owner = command.get("agent_id") or command.get("lease_agent_id")
        if owner is None and command.get("profile_id"):
            agent = store.agent_for_profile(int(command["profile_id"]))
            owner = agent["id"] if agent else None
        if owner is None:
            continue
        key = f"progress:{command['id']}"
        last = [d for d in store.list_lead_decisions(limit=1000)
                if d.get("command_id") == command["id"] and d.get("action") == "progress_ping"]
        recent = [d for d in last if (_parse_iso(d.get("at")) or now) > updated]
        if recent and now - (_parse_iso(recent[-1].get("at")) or now) < timedelta(minutes=minutes):
            continue
        issue = {"key": key, "command_id": command["id"], "agent_id": owner,
                 "profile_id": command.get("profile_id"), "title": f"Lệnh #{command['id']} im lặng"}
        if len(recent) >= PROGRESS_PING_LIMIT:
            target = _reassign(store, command, {int(owner)})
            if target is not None:
                store.update_command_payload_flags(command["id"], clear_keys=("chat_sent",))
                _tell(store, target["id"], f"Bạn nhận lệnh #{command['id']} (người trước im lặng {len(recent)} lần hỏi tiến độ).",
                      command["id"])
                out.append(_decide(store, lead_id, issue, "reassign",
                                   f"Lệnh #{command['id']} không báo tiến độ sau {len(recent)} lần hỏi → chuyển {target['name']}.",
                                   agent_id=target["id"]))
                continue
        pct = int(command.get("progress") or 0)
        _tell(store, owner,
              f"Báo tiến độ việc #{command['id']} NGAY (đã {minutes} phút chưa cập nhật, đang ở {pct}%). "
              "Trả lời đúng mẫu: TIẾN ĐỘ: <số>% — <bước vừa xong> — <bước tiếp theo>. "
              "Xong thì: KẾT QUẢ: … ; kẹt thì tự xử lý, chỉ khi bắt buộc mới: CẦN BẠN: ….", command["id"])
        out.append(_decide(store, lead_id, issue, "progress_ping",
                           f"Đòi báo tiến độ lệnh #{command['id']} (lần {len(recent) + 1}).", agent_id=owner))
    return out


def maybe_replace_lead(store: Store, settings: dict, now: datetime, save_settings=None) -> dict | None:
    """Chấm KPI trưởng phòng mỗi giờ; dưới ngưỡng N lần liên tiếp → thay."""
    cfg = kpi.rules_settings(settings)
    if not cfg["lead_auto_replace"] or settings.get("supervision_mode", "lead") != "lead":
        return None
    last = _parse_iso(store.get_meta(LEAD_CHECK_KEY) or "")
    if last and now - last < timedelta(hours=1):
        return None
    store.set_meta(LEAD_CHECK_KEY, now.isoformat(timespec="seconds"))
    agents = [a for a in store.list_agents() if not a.get("revoked")]
    if len(agents) < 2:
        return None
    lead = supervision.lead_agent_id(store, settings)
    scores = {int(a["id"]): kpi.agent_kpi(store, a["id"], settings, now).get("score") for a in agents}
    if lead is None:
        # Chưa có trưởng phòng → chọn người KPI cao nhất.
        best = max(agents, key=lambda a: (scores.get(int(a["id"])) or 0, -int(a["id"])))
        return _set_lead(store, settings, best, None, "chưa có trưởng phòng", save_settings)
    lead_score = kpi.lead_kpi(store, lead, settings, now).get("score")
    if lead_score is None or lead_score >= cfg["targets"]["pass_score"]:
        store.set_meta(STREAK_KEY, "0")
        return None
    streak = int(store.get_meta(STREAK_KEY) or 0) + 1
    store.set_meta(STREAK_KEY, str(streak))
    if streak < cfg["targets"]["lead_replace_after"]:
        store.append_journal(f"{LEAD_TAG} KPI trưởng phòng {lead_score} < {cfg['targets']['pass_score']} "
                             f"(lần {streak}/{cfg['targets']['lead_replace_after']}).")
        return None
    others = [a for a in agents if int(a["id"]) != int(lead)]
    best = max(others, key=lambda a: (scores.get(int(a["id"])) or 0, -int(a["id"])))
    store.set_meta(STREAK_KEY, "0")
    return _set_lead(store, settings, best, lead, f"KPI {lead_score} dưới ngưỡng {streak} lần liên tiếp", save_settings)


def _set_lead(store, settings, best, old_lead, reason, save_settings):
    settings["supervision_lead_agent_id"] = int(best["id"])
    if save_settings is not None:
        try:
            save_settings(settings)
        except Exception:
            pass
    detail = f"Đổi trưởng phòng → {best['name']} ({reason})."
    record = store.add_lead_decision(old_lead, "lead_replace", "replace_lead", agent_id=int(best["id"]),
                                     detail=detail, outcome="done")
    store.append_journal(f"{LEAD_TAG} 🔁 {detail}")
    _tell(store, best["id"], "Bạn được chọn làm TRƯỞNG PHÒNG giám sát. Đọc GET /api/rules (quy tắc giám sát) và làm theo.")
    if old_lead:
        _tell(store, old_lead, f"Bạn không còn là trưởng phòng ({reason}). Tiếp tục làm việc của nhân viên theo quy tắc.")
    return record
