"""Dispatcher (V4.0 — H2): bộ điều phối lệnh chờ Muse trong app.

AgentServer gọi ``tick`` theo nhịp 15 giây trong vòng lặp worker của
nó (Đ4) và NGAY LẬP TỨC khi có yêu cầu dispatch-now (V4.2 — O-27).
Dispatcher KHÔNG tự claim thay Muse — nó chuẩn bị để lệnh "sẵn
sàng nhận": lệnh chờ Muse mới tạo nằm ở 'queued'; qua được mọi cổng
điều kiện DỮ LIỆU thì dispatcher mới đẩy lên 'waiting_muse' cho
đúng Muse phụ trách claim (H1). Lệnh chưa đủ điều kiện nằm yên ở
'queued' kèm ``step`` nói rõ đang chờ gì — không treo im lặng, không
failed oan.

Thứ tự xét: hẹn giờ (scheduled_at) → phụ thuộc (depends_on) → một hồ
sơ một lệnh Muse đang chạy → điều kiện dữ liệu theo loại lệnh
(phân công, file upload, trùng Gmail). Ưu tiên: nguồn ui (tạo tay) >
auto (quy tắc) > api, cùng nhóm thì cũ trước (tie-break bằng rowid).

V4.2 (O-18): cổng trình duyệt/đăng nhập đã bị XOÁ DỨT ĐIỂM khỏi
dispatcher. Từ V4.1.2, bản chạy thật không tiêm hooks và lệnh đã cấp
là tới thẳng Muse bất kể web/Chrome của hồ sơ đang mở hay chưa —
Muse tự xử lý trình duyệt trong lúc thi công, cần người thì báo
'needs_user' từ bên trong lệnh. Tham số ``hooks`` của constructor
chỉ còn để tương thích nơi khởi tạo cũ và bị BỎ QUA hoàn toàn —
đừng "nối lại" cổng trình duyệt vào đây.
"""

from __future__ import annotations

import hashlib
import logging
from datetime import datetime
from pathlib import Path

from . import config
from .store import CLAUDE_COMMAND_TYPES, Store

logger = logging.getLogger("ccd.automation")

DISPATCH_TAG = "[Tự động]"
SOURCE_PRIORITY = {"ui": 0, "auto": 1, "api": 2}
# Phân trang xét hàng đợi (O-13): mỗi trang 200 lệnh, quét tối đa
# _MAX_SCAN lệnh mỗi tick để backlog lớn không làm một tick chạy mãi.
_PAGE_SIZE = 200
_MAX_SCAN = 5000


def _parse_iso(value) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.astimezone()


class Dispatcher:
    def __init__(
        self,
        store: Store,
        hooks: dict | None = None,
        log=None,
        data_dir=None,
        on_error=None,
    ):
        self._store = store
        # ``hooks``: tham số TƯƠNG THÍCH CŨ (cổng trình duyệt đã xoá ở
        # V4.2 — O-18). Nhận vào nhưng BỎ QUA: dispatcher chỉ xét điều
        # kiện dữ liệu, không bao giờ chạm trình duyệt/đăng nhập.
        self._hooks = hooks or {}
        self._log = log or (lambda _msg: None)
        self._data_dir = Path(data_dir) if data_dir is not None else config.data_dir()
        # V4.2 (O-06): lỗi pipeline (vd tự phân công) được BÁO ra qua
        # callback này để nơi gọi ghi automation health — không nuốt
        # lặng như trước. None = chỉ ghi log có cấu trúc.
        self._on_error = on_error
        # V4.2 (O-31): cache SHA-256 theo dấu vân file (size, mtime).
        self._sha_cache: dict[str, tuple[int, int, str]] = {}

    def _report_error(self, source: str, exc: BaseException) -> None:
        logger.error("dispatcher: %s failed: %s: %s", source, type(exc).__name__, exc)
        if self._on_error is not None:
            try:
                self._on_error(source, exc)
            except Exception:
                logger.exception("dispatcher: on_error callback failed")

    # ------------------------------------------------------------------ #
    def tick(self, now: datetime | None = None) -> list[dict]:
        """Một nhịp điều phối. Trả danh sách lệnh vừa được đẩy lên
        'waiting_muse' ở nhịp này."""
        now = now or datetime.now().astimezone()
        # V4.1.1: TRƯỚC khi xét lệnh — tự phân công theo email (Muse
        # có email trùng gmail của hồ sơ = phụ trách hồ sơ đó). Nhờ
        # vậy lệnh không còn kẹt "chưa phân công" chỉ vì chưa ai bấm
        # phân công tay. Lỗi ở bước này KHÔNG chặn điều phối nhưng từ
        # V4.2 (O-06) phải BÁO RA (log + automation health), không
        # nuốt lặng.
        try:
            self._store.auto_assign_email_matches()
        except Exception as exc:
            self._report_error("auto_assign", exc)
        # V4.2 (O-13): phân trang qua TOÀN BỘ backlog 'queued' theo
        # trang 200 (tối đa _MAX_SCAN lệnh/tick) — bản cũ chỉ lấy 200
        # lệnh MỚI NHẤT nên lệnh cũ bị lệnh mới chen khỏi cửa sổ xét
        # và chết đói khi backlog lớn.
        queued: list[dict] = []
        offset = 0
        while len(queued) < _MAX_SCAN:
            page = self._store.list_commands(
                status="queued", limit=_PAGE_SIZE, offset=offset
            )
            queued.extend(
                c for c in page if c["type"] in CLAUDE_COMMAND_TYPES
            )
            if len(page) < _PAGE_SIZE:
                break
            offset += _PAGE_SIZE
        # Bẻ hoà bằng _seq (rowid = thứ tự CHÈN thật), KHÔNG dùng id:
        # id là UUID ngẫu nhiên, hai lệnh tạo cùng một giây (created_at
        # trùng nhau) sẽ bị xếp thứ tự ngẫu nhiên — test flaky thật đã
        # bắt được lỗi này (test_one_running_claude_command_per_profile).
        queued.sort(
            key=lambda c: (
                SOURCE_PRIORITY.get(c["source"], 3),
                c["created_at"] or "",
                c.get("_seq") or 0,
            )
        )
        busy = self._busy_profiles()
        promoted: list[dict] = []
        for command in queued:
            row = self._consider(command, now, busy)
            if row is not None:
                promoted.append(row)
                # V6.0: việc KIỂM TRA được promote KHÔNG chiếm hồ sơ —
                # giám sát chạy song song, không chặn việc của hồ sơ.
                if row.get("profile_id") and row.get("type") != "review":
                    busy.add(row["profile_id"])
        return promoted

    # ------------------------------------------------------------------ #
    def _busy_profiles(self) -> set:
        # V4.2 (O-13): một câu SQL aggregate — bản cũ quét 200 lệnh
        # 'running' mới nhất nên lệnh chạy thứ 201+ vô hình, tuần tự
        # theo hồ sơ có thể bị phá khi số lệnh chạy lớn.
        return self._store.running_claude_profile_ids()

    def _consider(self, command: dict, now: datetime, busy: set) -> dict | None:
        # 1) Hẹn giờ: chưa tới hạn thì giữ nguyên, không đụng step.
        scheduled = _parse_iso(command.get("scheduled_at"))
        if scheduled is not None and scheduled > now:
            return None
        # 2) Phụ thuộc: lệnh gốc chưa done thì chờ; gốc failed thì con
        #    failed kèm lý do (không treo theo một lệnh đã chết).
        dep_id = command.get("depends_on")
        if dep_id:
            dep = self._store.get_command(dep_id)
            if dep is None:
                # V4.2 (O-08): lệnh phụ thuộc KHÔNG TỒN TẠI thì không
                # bao giờ 'done' được — giữ yên là treo vĩnh viễn và
                # im lặng. Chuyển 'needs_user' kèm lý do để anh thấy
                # và xử lý (resume sau khi sửa/xoá phụ thuộc).
                message = (
                    f"Lệnh phụ thuộc #{dep_id} không tồn tại — lệnh này "
                    "không thể tự chạy tiếp. Kiểm tra lại phụ thuộc "
                    "rồi bấm 'Đã xử lý — chạy tiếp'."
                )
                self._store.set_command_needs_user(command["id"], message)
                self._note(
                    f"{DISPATCH_TAG} ⏸ Lệnh #{command['id']} ({command['type']}) "
                    f"CHỜ NGƯỜI XỬ LÝ: {message}",
                    command.get("profile_id"),
                )
                return None
            if dep["status"] == "failed":
                reason = (
                    f"Lệnh phụ thuộc #{dep_id} ({dep['type']}) đã thất bại"
                    + (f": {dep.get('error')}" if dep.get("error") else "")
                    + " — lệnh này không thể chạy."
                )
                self._store.finish_command(
                    command["id"], "failed", result=reason, error=reason
                )
                self._note(
                    f"{DISPATCH_TAG} Lệnh #{command['id']} ({command['type']}) "
                    f"THẤT BẠI: {reason}",
                    command.get("profile_id"),
                )
                return None
            if dep["status"] != "done":
                self._set_step(command, f"Đang chờ lệnh #{dep_id} hoàn tất…")
                return None
        # 3) Một hồ sơ — một lệnh Muse chạm việc cùng lúc.
        # V6.0: việc KIỂM TRA (type 'review') được MIỄN quy tắc này —
        # nó do Muse giám sát giữ, không phải việc của hồ sơ, và
        # phải chấm được ngay cả khi hồ sơ đang bận việc khác.
        if (
            command.get("type") != "review"
            and command.get("profile_id")
            and command["profile_id"] in busy
        ):
            self._set_step(command, "Đang chờ lệnh Muse khác của hồ sơ này chạy xong…")
            return None
        # 4) Preflight theo loại lệnh.
        verdict = self._preflight(command, now)
        if verdict != "promote":
            return None
        row = self._store.promote_command_to_waiting(command["id"])
        if row is not None:
            self._note(
                f"{DISPATCH_TAG} Lệnh #{row['id']} ({row['type']}) đã sẵn sàng — "
                "chờ Muse phụ trách nhận (claim).",
                row.get("profile_id"),
            )
        return row

    # ------------------------------------------------------------------ #
    # Preflight
    # ------------------------------------------------------------------ #
    def _preflight(self, command: dict, now: datetime) -> str:
        """'promote' | 'hold' | 'handled' (đã tự chuyển needs_user)."""
        store = self._store
        profile = None
        if command.get("profile_id"):
            profile = store.get_profile(int(command["profile_id"]))
        if profile is None and command.get("profile_slug"):
            profile = store.get_profile_by_slug(str(command["profile_slug"]))
        if profile is None:
            self._set_step(command, "Chưa tìm thấy hồ sơ đích — đang chờ hồ sơ xuất hiện…")
            return "hold"
        if profile.get("paused"):
            self._set_step(command, f"Hồ sơ '{profile['label']}' đang tạm dừng — chờ mở lại…")
            return "hold"

        owner = store.agent_for_profile(profile["id"])
        if owner is None and command.get("agent_id"):
            owner = store.get_agent(int(command["agent_id"]))
        if owner is None:
            if not (command.get("payload") or {}).get("dispatch_warned_no_owner"):
                self._set_payload_flags(command, dispatch_warned_no_owner=True)
                self._note(
                    f"{DISPATCH_TAG} ⚠ Lệnh #{command['id']} ({command['type']}) "
                    f"CHƯA CÓ CHỦ: hồ sơ '{profile['label']}' chưa được phân "
                    "công cho Muse nào — vào tab Tài khoản Muse để phân công.",
                    profile["id"],
                )
            self._set_step(command, "Chưa có Muse phụ trách hồ sơ này — chờ phân công…")
            return "hold"
        if owner.get("revoked"):
            self._set_step(command, f"Muse phụ trách '{owner['name']}' đã bị thu hồi quyền — chờ phân công lại…")
            return "hold"
        # V4.2 (O-04): đã có chủ còn hiệu lực → điều kiện của cờ
        # "chưa có chủ" đã hết, dọn cờ để banner/số đếm không nói dối
        # (promote cũng dọn; đây là điểm sớm nhất biết điều kiện hết).
        if (command.get("payload") or {}).get("dispatch_warned_no_owner"):
            self._clear_payload_flags(command, "dispatch_warned_no_owner")

        ctype = command["type"]
        if ctype == "upload" and not self._upload_gate(command):
            return "hold"
        if ctype == "create_channel" and not self._create_channel_gate(command, profile):
            return "hold"

        # V4.2 (O-18): KHÔNG còn cổng trình duyệt/đăng nhập — điều
        # kiện dữ liệu qua hết là promote. Trình duyệt/đăng nhập do
        # Muse tự xử lý trong lúc thi công (quyết định V4.1.2).
        return "promote"

    # ------------------------- cổng upload ------------------------- #
    def _upload_gate(self, command: dict) -> bool:
        payload = command.get("payload") or {}
        found = self._find_upload_file(payload)
        if found is not None:
            expected_size = payload.get("size")
            expected_sha = payload.get("sha256")
            if expected_size is not None:
                try:
                    if found.stat().st_size != int(expected_size):
                        self._set_step(command, "File video đã có nhưng dung lượng chưa khớp — đang chờ file đúng…")
                        return False
                except (TypeError, ValueError):
                    pass
            if expected_sha:
                digest = self._file_sha256(found)
                if digest is None or digest.lower() != str(expected_sha).strip().lower():
                    self._set_step(command, "File video đã có nhưng SHA-256 chưa khớp — đang chờ file đúng…")
                    return False
            return True
        video_id = payload.get("video_id")
        if video_id and command.get("profile_id"):
            videos = self._store.list_videos(int(command["profile_id"]))
            if any(v["video_id"] == str(video_id) for v in videos):
                return True
        self._set_step(command, "Đang chờ file video về inbox của app…")
        return False

    def _file_sha256(self, path: Path) -> str | None:
        """SHA-256 của file, ĐỌC STREAMING theo khối 1MB (O-31: bản cũ
        ``read_bytes()`` nạp cả file video vào RAM mỗi nhịp 15s khi
        hash chưa khớp). Cache theo dấu vân (size, mtime_ns): file
        không đổi thì nhịp sau dùng lại, không băm lại."""
        try:
            stat = path.stat()
        except OSError:
            return None
        key = str(path)
        cached = self._sha_cache.get(key)
        if cached and cached[0] == stat.st_size and cached[1] == stat.st_mtime_ns:
            return cached[2]
        digest = hashlib.sha256()
        try:
            with path.open("rb") as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                    digest.update(chunk)
        except OSError:
            return None
        value = digest.hexdigest()
        self._sha_cache[key] = (stat.st_size, stat.st_mtime_ns, value)
        return value

    def _find_upload_file(self, payload: dict) -> Path | None:
        raw = payload.get("file")
        if not raw:
            return None
        name = str(raw).replace("\\", "/").split("/")[-1]
        inbox_file = self._data_dir / "inbox" / name
        if inbox_file.exists():
            return inbox_file
        candidate = Path(str(raw))
        if candidate.is_absolute() and candidate.exists():
            return candidate
        return None

    # ---------------------- cổng create_channel --------------------- #
    def _create_channel_gate(self, command: dict, profile: dict) -> bool:
        payload = command.get("payload") or {}
        gmail = str(payload.get("gmail") or profile.get("gmail") or "").strip()
        if gmail:
            other = self._store.find_profile_by_gmail(gmail)
            if other is not None and other["id"] != profile["id"]:
                self._set_step(
                    command,
                    f"Gmail đích đã thuộc hồ sơ '{other['label']}' — chờ xử lý trùng lặp…",
                )
                return False
        if self._store.list_channels(profile["id"]):
            self._set_step(
                command,
                "Hồ sơ đã có kênh — lệnh tạo kênh đầu tiên không còn đúng, chờ người dùng xác nhận…",
            )
            return False
        return True

    # ------------------------------------------------------------------ #
    # Tiện ích ghi trạng thái (chỉ ghi khi THẬT SỰ thay đổi — tránh nhịp
    # 15 giây nào cũng chạm DB/ghi nhật ký rác)
    # ------------------------------------------------------------------ #
    def _set_step(self, command: dict, step: str) -> None:
        if (command.get("step") or "") == step:
            return
        # progress=None: chỉ đổi chữ bước; TUYỆT ĐỐI không truyền
        # progress > 0 ở đây — lệnh đang 'queued', báo % sẽ bị hiểu là
        # Muse đã nhận việc (đường tự-claim tương thích Đ1).
        self._store.update_command_progress(command["id"], step=step)
        command["step"] = step

    def _set_payload_flags(self, command: dict, **flags) -> None:
        # V4.2 (O-04): ghi cờ qua helper TẬP TRUNG của Store — không
        # còn nơi nào tự viết payload thẳng qua store._conn. Giữ đồng
        # bộ dict trong bộ nhớ cho các lần đọc tiếp trong cùng tick.
        self._store.update_command_payload_flags(
            command["id"], set_flags=flags
        )
        payload = dict(command.get("payload") or {})
        payload.update(flags)
        command["payload"] = payload

    def _clear_payload_flags(self, command: dict, *keys: str) -> None:
        self._store.update_command_payload_flags(
            command["id"], clear_keys=list(keys)
        )
        payload = dict(command.get("payload") or {})
        for key in keys:
            payload.pop(key, None)
        command["payload"] = payload

    def _note(self, message: str, profile_id: int | None) -> None:
        try:
            self._store.append_journal(message, profile_id)
        except Exception:
            pass
        self._log(message)
