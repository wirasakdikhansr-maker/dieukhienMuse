"""Phân tích (parse) dữ liệu kênh YouTube — hàm thuần, không phụ thuộc Qt/mạng.

Nguồn dữ liệu chính: JSON trả về từ endpoint nội bộ của YouTube
``/youtubei/v1/account/account_menu`` (danh sách kênh của tài khoản, lấy bằng
chính phiên đăng nhập trong Chrome của hồ sơ). App cũng lưu một "snapshot"
HTML chứa JSON đó trong thẻ::

    <script id="ccd-account-menu" type="application/json"> {...} </script>

``parse_channels_from_html`` đọc đúng định dạng snapshot này — và file mẫu
``tests/fixtures/channel_list_sample.html`` dùng để kiểm thử.
"""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser

SNAPSHOT_SCRIPT_ID = "ccd-account-menu"

_HANDLE_RE = re.compile(r"@[\w.\-]+")
_CHANNEL_ID_RE = re.compile(r"^UC[\w-]{10,30}$")
_UC_ANYWHERE_RE = re.compile(r"UC[\w-]{20,24}")
_EMAIL_RE = re.compile(r"^[\w.+-]+@[\w-]+\.[\w.]+$")
_SUBS_RE = re.compile(
    r"([\d]+(?:[.,]\d+)?)\s*([KMBN])?\s+(?:subscribers?|suscriptores|người đăng ký|inscritos|abonnés)",
    re.IGNORECASE,
)
_NO_SUBS_RE = re.compile(
    r"(?:no\s+subscribers|sin\s+suscriptores|không có người đăng ký|chưa có người đăng ký)",
    re.IGNORECASE,
)
_COUNT_TEXT_RE = re.compile(r"([\d][\d.,]*)\s*(?:videos?|video)", re.IGNORECASE)
_VIDEOS_COUNT_JSON_RE = re.compile(r'"videosCount"\s*:\s*\{\s*"simpleText"\s*:\s*"([\d,\.]+)"')
_VIDEO_COUNT_JSON_RE = re.compile(r'"videoCount"\s*:\s*"?(?P<n>[\d,\.]+)"?')


# --------------------------------------------------------------------------- #
# Số đếm
# --------------------------------------------------------------------------- #
def parse_subscriber_text(text: str | None) -> int | None:
    """'1.23K subscribers' -> 1230, '43 subscribers' -> 43,
    'No subscribers' -> 0, không đọc được -> None."""
    if not text:
        return None
    if _NO_SUBS_RE.search(text):
        return 0
    match = _SUBS_RE.search(text)
    if not match:
        return None
    raw = match.group(1)
    suffix = (match.group(2) or "").upper()
    if not suffix and re.fullmatch(r"\d{1,3}([.,]\d{3})+", raw):
        # Không hậu tố mà có dấu phân cách theo nhóm 3 số -> dấu nghìn
        # ('4,780 subscribers' = 4780, không phải 4.78).
        value = float(int(raw.replace(",", "").replace(".", "")))
    else:
        # Có hậu tố K/M/B (hoặc 'N' = nghìn ở giao diện tiếng Việt) thì
        # dấu ,/. là dấu thập phân ('1,23K', '5,18 N người đăng ký').
        value = float(raw.replace(",", "."))
    multiplier = {"K": 1_000, "N": 1_000, "M": 1_000_000, "B": 1_000_000_000}.get(suffix, 1)
    return int(round(value * multiplier))


def parse_count_text(text: str | None) -> int | None:
    """'1,234 videos' -> 1234, '57 videos' -> 57, không đọc được -> None."""
    if not text:
        return None
    match = _COUNT_TEXT_RE.search(text)
    if not match:
        return None
    return int(match.group(1).replace(",", "").replace(".", ""))


def parse_video_count_from_html(html: str | None) -> int | None:
    """Đọc số video từ HTML trang kênh (ytInitialData nhúng trong trang)."""
    if not html:
        return None
    for pattern in (_VIDEOS_COUNT_JSON_RE, _VIDEO_COUNT_JSON_RE):
        match = pattern.search(html)
        if match:
            digits = (match.group("n") if "n" in match.groupdict() else match.group(1))
            return int(digits.replace(",", "").replace(".", ""))
    return None


# --------------------------------------------------------------------------- #
# Danh sách kênh từ account_menu JSON
# --------------------------------------------------------------------------- #
def _text_of(node) -> str:
    """Lấy text hiển thị từ node kiểu YouTube: {'simpleText': ...} hoặc
    {'runs': [{'text': ...}, ...]} hoặc chuỗi thuần."""
    if isinstance(node, str):
        return node
    if isinstance(node, dict):
        if isinstance(node.get("simpleText"), str):
            return node["simpleText"]
        runs = node.get("runs")
        if isinstance(runs, list):
            return "".join(r.get("text", "") for r in runs if isinstance(r, dict))
    return ""


def _walk(node):
    """Duyệt đệ quy mọi dict trong cấu trúc JSON lồng nhau."""
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _walk(value)
    elif isinstance(node, list):
        for item in node:
            yield from _walk(item)


def _subtree_texts(node, depth: int = 0) -> list[str]:
    texts: list[str] = []
    if depth > 6:
        return texts
    if isinstance(node, dict):
        for key, value in node.items():
            if key in ("simpleText", "text") and isinstance(value, str):
                texts.append(value)
            else:
                texts.extend(_subtree_texts(value, depth + 1))
    elif isinstance(node, list):
        for item in node:
            texts.extend(_subtree_texts(item, depth + 1))
    return texts


def _find_uc_in_subtree(node, depth: int = 0, anywhere: bool = False) -> str:
    """Tìm chuỗi channel ID (UC...) đầu tiên trong cây con của một node —
    dùng khi renderer đời mới không còn để ID ở field riêng mà giấu trong
    endpoint lồng nhau. Chỉ áp dụng cho node cấp 'item' (có accountName...)
    để không vớ nhầm ID của kênh khác trong node cha chứa nhiều kênh."""
    if depth > 5:
        return ""
    if isinstance(node, str):
        text = node.strip()
        if _CHANNEL_ID_RE.match(text):
            return text
        # Lượt 2 (anywhere=True) mới tìm ID nằm lẫn trong chuỗi dài như
        # URL '/channel/UC...'; bỏ qua URL ảnh (ggpht...) để không vớ nhầm
        # chuỗi ngẫu nhiên trong link avatar.
        if anywhere and not (text.startswith("http") and "/channel/" not in text):
            match = _UC_ANYWHERE_RE.search(text)
            if match:
                return match.group(0)
        return ""
    if isinstance(node, dict):
        for value in node.values():
            hit = _find_uc_in_subtree(value, depth + 1, anywhere)
            if hit:
                return hit
    elif isinstance(node, list):
        for item in node:
            hit = _find_uc_in_subtree(item, depth + 1, anywhere)
            if hit:
                return hit
    return ""


def _channel_from_node(node: dict) -> dict | None:
    # ID kênh: field channelId (đời cũ) hoặc accountId (đời mới); nếu không
    # có field riêng, node cấp item có thể giấu ID trong endpoint con.
    channel_id = ""
    for key in ("channelId", "accountId"):
        value = node.get(key)
        if isinstance(value, str) and _CHANNEL_ID_RE.match(value.strip()):
            channel_id = value.strip()
            break
    if not channel_id:
        if not any(k in node for k in ("accountName", "channelHandle", "accountByline")):
            return None
        channel_id = _find_uc_in_subtree(node) or _find_uc_in_subtree(node, anywhere=True)
        if not channel_id:
            return None
    name = ""
    for key in ("accountName", "title", "channelName", "name"):
        name = _text_of(node.get(key))
        if name:
            break
    url = ""
    handle = _text_of(node.get("channelHandle"))
    if handle and not handle.startswith("@"):
        handle = "@" + handle.lstrip("@")
    vanity = node.get("vanityChannelUrl")
    if isinstance(vanity, str) and vanity:
        url = vanity
        if not handle:
            match = _HANDLE_RE.search(vanity)
            if match:
                handle = match.group(0)
    if not url:
        url = (
            f"https://www.youtube.com/{handle}"
            if handle
            else f"https://www.youtube.com/channel/{channel_id}"
        )
    texts = _subtree_texts(node)
    if not handle:
        for text in texts:
            match = _HANDLE_RE.search(text)
            if match:
                handle = match.group(0)
                break
    subs = None
    for text in texts:
        subs = parse_subscriber_text(text)
        if subs is not None:
            break
    return {
        "channel_id": channel_id,
        "name": name,
        "handle": handle,
        "url": url,
        "subs": subs,
        "video_count": None,
        "niche": "",
        "avatar_url": _find_avatar_url(node),
    }


_AVATAR_RE = re.compile(r"https://yt3\.(?:ggpht|googleusercontent)\.com/[^\s\"'\\]+")


def _find_avatar_url(node) -> str:
    """Tìm URL logo/avatar kênh (yt3.ggpht / googleusercontent) trong
    cây con của một mục kênh account_menu. Trả '' khi không có."""
    try:
        blob = json.dumps(node, ensure_ascii=False)
    except (TypeError, ValueError):
        return ""
    match = _AVATAR_RE.search(blob)
    return match.group(0) if match else ""


def parse_account_menu(data) -> list[dict]:
    """Trích danh sách kênh từ JSON account_menu. Khớp mọi dict có
    ``channelId`` dạng UC... kèm tên kênh; khử trùng lặp theo channel_id,
    giữ bản ghi đầy đủ hơn (có handle/subs)."""
    found: dict[str, dict] = {}
    for node in _walk(data):
        record = _channel_from_node(node)
        if record is None:
            continue
        previous = found.get(record["channel_id"])
        if previous is None or _richness(record) > _richness(previous):
            found[record["channel_id"]] = record
    return sorted(found.values(), key=lambda r: r["name"].lower())


def _richness(record: dict) -> int:
    return sum(bool(record.get(k)) for k in ("name", "handle")) + (record.get("subs") is not None)


def summarize_structure(data, max_renderers: int = 12) -> str:
    """Tóm tắt CẤU TRÚC (chỉ tên khoá + số đếm, KHÔNG kèm giá trị riêng tư)
    của một JSON account_menu — để khi parse ra 0 kênh, dòng nhật ký tự nó
    nói được YouTube đã đổi cấu trúc ra sao, khỏi cần mở file snapshot."""
    if not isinstance(data, (dict, list)):
        return f"kiểu dữ liệu lạ: {type(data).__name__}"
    top_keys = list(data.keys())[:8] if isinstance(data, dict) else ["<list>"]
    renderer_counts: dict[str, int] = {}
    uc_ids: set[str] = set()
    node_count = 0
    for node in _walk(data):
        node_count += 1
        for key, value in node.items():
            if key.endswith("Renderer"):
                renderer_counts[key] = renderer_counts.get(key, 0) + 1
            if isinstance(value, str):
                uc_ids.update(_UC_ANYWHERE_RE.findall(value))
    top = sorted(renderer_counts.items(), key=lambda kv: -kv[1])[:max_renderers]
    renderers = ", ".join(f"{k}×{c}" for k, c in top) or "không có renderer nào"
    return (
        f"khoá cấp cao nhất: {', '.join(top_keys) or '(trống)'}; "
        f"tổng {node_count} node; renderer: {renderers}; "
        f"số chuỗi giống channel ID (UC...) trong dữ liệu: {len(uc_ids)}"
    )


# --------------------------------------------------------------------------- #
# Dự phòng: đọc menu tài khoản ngay trên DOM trang YouTube
# --------------------------------------------------------------------------- #
def _name_from_menu_text(text: str) -> str:
    """Dòng tên kênh trong innerText của một mục menu tài khoản: dòng đầu
    tiên không phải email / handle / dòng subs / nhãn hệ thống."""
    for line in (ln.strip() for ln in (text or "").splitlines()):
        if not line:
            continue
        if _EMAIL_RE.match(line):
            continue
        if _HANDLE_RE.fullmatch(line):
            continue
        if parse_subscriber_text(line) is not None:
            continue
        if line.lower() in ("google account", "tài khoản google", "your channel", "kênh của bạn"):
            continue
        return line
    return ""


def parse_dom_menu_texts(header_text: str, item_texts: list[str]) -> list[dict]:
    """Dựng bản ghi kênh (chưa có channel_id) từ innerText của menu tài
    khoản mở ngay trên trang: header = kênh đang active, items = từng mục
    ``ytd-account-item-renderer``. Scanner sẽ bổ sung channel_id sau bằng
    cách đọc trang @handle của từng kênh."""
    records: dict[str, dict] = {}

    def _add(text: str) -> None:
        if not text:
            return
        handle_match = _HANDLE_RE.search(text)
        handle = handle_match.group(0) if handle_match else ""
        name = _name_from_menu_text(text)
        if not name and not handle:
            return
        key = (handle or name).lower()
        record = records.setdefault(
            key,
            {
                "channel_id": "",
                "name": name,
                "handle": handle,
                "url": f"https://www.youtube.com/{handle}" if handle else "",
                "subs": parse_subscriber_text(text),
                "video_count": None,
                "niche": "",
                "avatar_url": "",
            },
        )
        if name and not record["name"]:
            record["name"] = name
        if record["subs"] is None:
            record["subs"] = parse_subscriber_text(text)

    _add(header_text)
    for item in item_texts or []:
        _add(item)
    return sorted(records.values(), key=lambda r: r["name"].lower())


def parse_switcher_entries(entries: list[dict]) -> list[dict]:
    """Dựng bản ghi kênh (có thể chưa có channel_id) từ các mục đọc được
    trên trang 'View all channels' (youtube.com/channel_switcher): mỗi
    mục là {href, text} — href dạng '/channel/UC...' (có luôn ID) hoặc
    '/@handle'; text là chữ hiển thị của thẻ kênh (tên / handle / subs).
    Khử trùng lặp theo ID → handle → tên."""
    records: dict[str, dict] = {}
    for entry in entries or []:
        href = (entry.get("href") or "").strip()
        text = entry.get("text") or ""
        channel_id = ""
        id_match = re.search(r"/channel/(UC[\w-]{10,30})", href)
        if id_match:
            channel_id = id_match.group(1)
        elif not href.startswith("/@"):
            continue  # không phải liên kết kênh -> bỏ qua hẳn
        handle = ""
        if href.startswith("/@"):
            handle = href[1:].split("/")[0].split("?")[0]
            if handle and not handle.startswith("@"):
                handle = "@" + handle
        if not handle:
            handle_match = _HANDLE_RE.search(text)
            if handle_match:
                handle = handle_match.group(0)
        name = _name_from_menu_text(text)
        if not (channel_id or handle or name):
            continue
        key = channel_id or handle.lower() or name.lower()
        record = records.setdefault(
            key,
            {
                "channel_id": channel_id,
                "name": name,
                "handle": handle,
                "url": (
                    f"https://www.youtube.com/{handle}"
                    if handle
                    else f"https://www.youtube.com/channel/{channel_id}"
                ),
                "subs": parse_subscriber_text(text),
                "video_count": None,
                "niche": "",
                "avatar_url": "",
            },
        )
        if name and not record["name"]:
            record["name"] = name
        if record["subs"] is None:
            record["subs"] = parse_subscriber_text(text)
    return sorted(records.values(), key=lambda r: r["name"].lower())


def merge_channel_records(records: list[dict]) -> list[dict]:
    """Hợp nhất bản ghi kênh từ nhiều nguồn (account_menu JSON, panel
    Accounts, trang channel_switcher) thành một danh sách duy nhất:
    khớp theo channel_id, rồi tới @handle; trường nào còn trống thì
    lấy từ bản ghi khác điền vào."""
    merged: dict[str, dict] = {}
    by_handle: dict[str, str] = {}

    def _key(record: dict) -> str:
        if record.get("channel_id"):
            return "id:" + record["channel_id"]
        if record.get("handle"):
            return "h:" + record["handle"].lower()
        return "n:" + (record.get("name") or "").lower()

    for record in records or []:
        if not record:
            continue
        key = _key(record)
        if not record.get("channel_id") and record.get("handle"):
            known = by_handle.get(record["handle"].lower())
            if known:
                key = known
        if key not in merged:
            merged[key] = {
                "channel_id": record.get("channel_id") or "",
                "name": record.get("name") or "",
                "handle": record.get("handle") or "",
                "url": record.get("url") or "",
                "subs": record.get("subs"),
                "video_count": record.get("video_count"),
                "niche": record.get("niche") or "",
                "avatar_url": record.get("avatar_url") or "",
            }
        else:
            base = merged[key]
            for field in ("channel_id", "name", "handle", "url", "niche", "avatar_url"):
                if not base.get(field) and record.get(field):
                    base[field] = record[field]
            for field in ("subs", "video_count"):
                if base.get(field) is None and record.get(field) is not None:
                    base[field] = record[field]
        current = merged[key]
        if current.get("handle") and current.get("channel_id"):
            by_handle[current["handle"].lower()] = key
        if current.get("handle") and not current.get("url"):
            current["url"] = f"https://www.youtube.com/{current['handle']}"
    return sorted(merged.values(), key=lambda r: (r.get("name") or "").lower())


def exclude_personal_channel(records: list[dict], account_name: str):
    """Bỏ KÊNH CHÍNH (kênh cá nhân của tài khoản Google) — chỉ lấy kênh
    thương hiệu. Kênh chính nhận diện bằng TÊN TRÙNG tên hiển thị của
    tài khoản Google (đọc từ đầu panel Accounts) và chỉ bỏ TỐI ĐA MỘT
    bản ghi đầu tiên khớp, để một kênh thương hiệu trùng tên (hiếm) vẫn
    được giữ. Trả về (danh sách giữ lại, bản ghi đã bỏ | None)."""
    target = (account_name or "").strip().lower()
    if not target:
        return list(records), None
    kept: list[dict] = []
    dropped = None
    for record in records or []:
        if dropped is None and (record.get("name") or "").strip().lower() == target:
            dropped = record
            continue
        kept.append(record)
    return kept, dropped


_CHANNEL_ID_HTML_RES = (
    re.compile(r'"channelId"\s*:\s*"(UC[\w-]{22})"'),
    re.compile(r'"externalId"\s*:\s*"(UC[\w-]{22})"'),
    re.compile(r'itemprop="channelId"\s+content="(UC[\w-]{22})"'),
    re.compile(r'rel="canonical"\s+href="https://www\.youtube\.com/channel/(UC[\w-]{22})"'),
)


def parse_channel_id_from_html(html: str | None) -> str:
    """Đọc channel ID từ HTML trang kênh (@handle) — trang kênh luôn nhúng
    ID của chính nó trong ytInitialData / thẻ meta."""
    if not html:
        return ""
    for pattern in _CHANNEL_ID_HTML_RES:
        match = pattern.search(html)
        if match:
            return match.group(1)
    return ""


# --------------------------------------------------------------------------- #
# Snapshot HTML
# --------------------------------------------------------------------------- #
class _SnapshotExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self._capturing = False
        self.chunks: list[str] = []

    def handle_starttag(self, tag, attrs):
        if tag == "script" and dict(attrs).get("id") == SNAPSHOT_SCRIPT_ID:
            self._capturing = True

    def handle_endtag(self, tag):
        if tag == "script":
            self._capturing = False

    def handle_data(self, data):
        if self._capturing:
            self.chunks.append(data)


def extract_snapshot_json(html: str) -> dict | None:
    """Lấy JSON account_menu từ snapshot HTML của app. None nếu không có."""
    extractor = _SnapshotExtractor()
    extractor.feed(html or "")
    raw = "".join(extractor.chunks).strip()
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def parse_channels_from_html(html: str) -> list[dict]:
    """Parse snapshot HTML (định dạng app lưu) thành danh sách bản ghi kênh."""
    data = extract_snapshot_json(html)
    if data is None:
        return []
    return parse_account_menu(data)


def build_snapshot_html(account_menu_json: dict) -> str:
    """Đóng gói JSON account_menu thành snapshot HTML (đúng định dạng mà
    ``parse_channels_from_html`` đọc được) để lưu gỡ lỗi."""
    payload = json.dumps(account_menu_json, ensure_ascii=False)
    return (
        "<!DOCTYPE html>\n<html><head><meta charset='utf-8'>"
        "<title>CCD scan snapshot</title></head><body>\n"
        f'<script id="{SNAPSHOT_SCRIPT_ID}" type="application/json">\n'
        f"{payload}\n</script>\n</body></html>\n"
    )
