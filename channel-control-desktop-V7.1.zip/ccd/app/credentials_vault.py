"""Kho mật khẩu đăng nhập theo hồ sơ (V3.4).

Khi người dùng thêm hồ sơ kèm mật khẩu (dán dạng ``email|matkhau``),
app lưu mật khẩu vào file riêng của hồ sơ tại
``data/credentials/<slug>.json`` để lần đăng nhập sau tự điền trong
trình duyệt nhúng của chính hồ sơ đó.

Nguyên tắc an toàn:
- Mật khẩu CHỈ nằm trong file này trên máy người dùng — không bao giờ
  ghi nhật ký, không trả qua Agent API, không đưa vào báo cáo/lỗi.
  Mọi thông báo chỉ nói "đã lưu mật khẩu: có/không".
- Đây là lưu trữ văn bản thuần trên máy cá nhân (giống kho cookies) —
  người dùng tự chịu trách nhiệm với máy của mình; app không mã hoá
  thêm để tránh cảm giác an toàn giả.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from . import config


def credentials_dir(base: Path | None = None) -> Path:
    folder = (Path(base) if base is not None else config.data_dir()) / "credentials"
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def _file_for(slug: str, base: Path | None = None) -> Path:
    safe = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(slug))
    return credentials_dir(base) / f"{safe}.json"


def save_password(slug: str, gmail: str, password: str, base: Path | None = None) -> None:
    payload = {
        "gmail": gmail or "",
        "password": password or "",
        "saved_at": datetime.now().astimezone().isoformat(timespec="seconds"),
    }
    _file_for(slug, base).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def load_password(slug: str, base: Path | None = None) -> dict | None:
    """Đọc mật khẩu đã lưu của hồ sơ. None nếu chưa lưu/hỏng file."""
    path = _file_for(slug, base)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(data, dict) or not data.get("password"):
        return None
    return data


def has_password(slug: str, base: Path | None = None) -> bool:
    return load_password(slug, base) is not None


def delete_password(slug: str, base: Path | None = None) -> bool:
    path = _file_for(slug, base)
    if path.exists():
        path.unlink()
        return True
    return False
