"""Điểm vào của ứng dụng."""

from __future__ import annotations

import sys


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        from PySide6.QtWidgets import QApplication
    except ImportError:
        print(
            "Chưa cài PySide6. Chạy: pip install -r requirements.txt",
            file=sys.stderr,
        )
        return 1

    from . import config, diagnostics, instance_guard, logging_setup
    from .chrome_manager import ChromeManager
    from .store import Store
    from .ui import theme
    from .ui.main_window import MainWindow

    data = config.data_dir()
    data.mkdir(parents=True, exist_ok=True)
    config.profiles_root().mkdir(parents=True, exist_ok=True)
    settings = config.load_settings()

    # V4.0 (H4.1): SINGLE-INSTANCE — đã có bản app đang chạy thì gửi
    # tín hiệu "hiện cửa sổ" cho bản đó rồi thoát êm, thay vì mở bản
    # thứ hai tranh cổng Agent API + cùng ghi một SQLite.
    if instance_guard.notify_existing_instance(argv):
        print("[CCD] Đã có một bản Channel Control Desktop đang chạy — đã gọi bản đó lên.")
        return 0
    # Mở app = phiên làm việc mới: xoá cờ thoát-sạch của lần trước để
    # watchdog phân biệt đúng lần thoát TỚI (xem app/watchdog.py).
    instance_guard.clear_clean_exit(data)

    # V3.1: log file xoay vòng. KHÔNG tự đặt DPI awareness ở đây: Qt 6
    # tự đặt PER_MONITOR_AWARE_V2 khi tạo QApplication; việc đặt trước
    # bằng shcore khiến Qt bị Access denied và in cảnh báo ra console
    # (xem docking.enable_dpi_awareness — nay là no-op).
    log = logging_setup.setup_logging()

    # V7.0: CSDL hỏng ("database disk image is malformed") → tự cách ly
    # file hỏng, cứu dữ liệu đọc được + bù từ bản sao lưu, rồi mới mở.
    db_repair_note = None
    try:
        from . import db_health

        report = db_health.ensure_healthy(config.db_path())
        if report is not None:
            db_repair_note = db_health.describe(report)
            log.warning(db_repair_note)
            print("[CCD] " + db_repair_note)
    except Exception as exc:
        log.warning("db_health lỗi: %s", exc)

    store = Store(config.db_path())
    if db_repair_note:
        try:
            store.append_journal("🛠 " + db_repair_note)
        except Exception:
            pass

    # V3.1: khôi phục lệnh kẹt 'running' từ lần chạy trước (app thoát
    # giữa chừng) — đánh dấu 'interrupted' để người dùng thử lại có chủ đích.
    try:
        recovered = store.recover_interrupted_commands()
        if recovered:
            message = (
                f"Khôi phục khởi động: {recovered} lệnh đang chạy dở từ lần "
                "trước đã được đánh dấu 'Bị gián đoạn' — mở mục Lệnh công "
                "việc để Thử lại."
            )
            store.append_journal(message)
            log.info(message)
    except Exception as exc:  # khôi phục lỗi không được chặn app mở
        log.warning("recover_interrupted_commands lỗi: %s", exc)

    # V4.1.1: TỰ PHÂN CÔNG THEO EMAIL ngay khi mở app — tài khoản
    # Muse có email trùng gmail của hồ sơ chưa có chủ thì chính là
    # người phụ trách hồ sơ đó (không cần bấm phân công tay; nhật ký
    # từng cặp do store tự ghi). Lỗi ở đây không chặn app mở.
    try:
        auto_pairs = store.auto_assign_email_matches()
        if auto_pairs:
            log.info(
                "Tự phân công theo email khi khởi động: %d cặp hồ sơ ↔ Muse.",
                len(auto_pairs),
            )
    except Exception as exc:
        log.warning("auto_assign_email_matches lỗi: %s", exc)

    # V3.1: chẩn đoán khởi động (Chrome? cổng trống? token? thư mục ghi
    # được? kho toàn vẹn?) — lưu vào app_meta cho panel Kiểm tra hiển thị.
    # Chạy TRƯỚC khi Agent API mở để mục "cổng trống" còn ý nghĩa.
    try:
        items = diagnostics.run_startup_diagnostics(store, settings, data)
        log.info(diagnostics.summarize_diagnostics(items))
    except Exception as exc:
        log.warning("run_startup_diagnostics lỗi: %s", exc)

    manager = ChromeManager(chrome_path=settings.get("chrome_path") or None)

    app = QApplication([sys.argv[0], *argv])
    app.setApplicationName("Channel Control Desktop")
    app.setOrganizationName("ChannelControl")
    # V3.7: logo Muse Automation là icon CHUNG — cửa sổ chính, mọi hộp
    # thoại và biểu tượng taskbar đều dùng icon này.
    from pathlib import Path as _Path

    from PySide6.QtGui import QIcon as _QIcon

    _icon = _Path(__file__).resolve().parent / "assets" / "app_icon.png"
    if _icon.exists():
        app.setWindowIcon(_QIcon(str(_icon)))
    # Theme "Mission Control": stylesheet trung tâm + font Segoe UI.
    from PySide6.QtGui import QColor, QFont, QPalette

    app.setFont(QFont("Segoe UI", 10))
    # V6.3: Qt trên Windows in "QFont::setPointSize: Point size <= 0 (-1)"
    # một lần khi khởi động (font cỡ pixel từ stylesheet bị Qt sao chép
    # nội bộ) — vô hại, lọc khỏi console; mọi cảnh báo khác vẫn in.
    from PySide6.QtCore import qInstallMessageHandler

    def _qt_messages(_mode, _context, message):
        if "QFont::setPointSize" in message:
            return
        sys.stderr.write(message + "\n")

    qInstallMessageHandler(_qt_messages)
    palette = app.palette()
    palette.setColor(QPalette.PlaceholderText, QColor(theme.FAINT))
    app.setPalette(palette)
    app.setStyleSheet(theme.APP_QSS)

    # V2/V3.1: Agent API — "cầu nối" để Muse điều khiển app từ xa.
    # Tạo TRƯỚC cửa sổ để cửa sổ hiển thị trạng thái cầu nối và khởi
    # động lại được khi đổi cổng/token trong Cài đặt.
    agent_server = None
    if settings.get("agent_enabled", True):
        from .agent_server import AgentServer

        # V4.1.2 (yêu cầu người dùng 2026-10-29): KHÔNG tiêm hooks
        # preflight trình duyệt/đăng nhập cho dispatcher nữa. Lệnh đã
        # tạo/bấm chạy = lệnh đã cấp đầy đủ — phải tới thẳng Muse
        # (waiting_muse) bất kể web/Chrome của hồ sơ đang mở hay đã
        # đăng nhập hay chưa; Muse tự xử lý trình duyệt trong lúc
        # làm, cần người thì Muse báo needs_user TỪ BÊN TRONG lệnh.
        # settings truyền NGUYÊN dict dùng chung với cửa sổ chính để
        # các giá trị V4.0 (lease/giây, công tắc tự động) sửa trong
        # Cài đặt có hiệu lực ngay, không cần mở lại cầu nối.
        agent_server = AgentServer(
            settings=settings,
            manager=manager,
        )
        try:
            agent_server.start()
        except OSError as exc:
            print(f"[Agent API] Không khởi động được: {exc}", file=sys.stderr)
            log.warning("Agent API không khởi động được: %s", exc)
            agent_server = None

    window = MainWindow(store, manager, settings, agent_server=agent_server)

    # V4.0 (H4.1): giữ QLocalServer cho single-instance — bản thứ hai
    # mở lên sẽ gửi thông điệp focus vào đây; nhận được thì hiện cửa
    # sổ bản chính lên (kể cả khi đang thu ở tray do --autostart).
    from PySide6.QtNetwork import QLocalServer

    instance_server = QLocalServer(app)
    QLocalServer.removeServer(instance_guard.SERVER_NAME)  # dọn socket mồ côi của lần sập trước
    if instance_server.listen(instance_guard.SERVER_NAME):
        def _on_instance_connection():
            socket = instance_server.nextPendingConnection()
            if socket is None:
                return
            socket.readyRead.connect(lambda s=socket: _read_instance_message(s))

        def _read_instance_message(socket):
            message = instance_guard.parse_focus_message(bytes(socket.readAll()))
            if message is not None:
                window.show()
                window.raise_()
                window.activateWindow()
            socket.disconnectFromServer()

        instance_server.newConnection.connect(_on_instance_connection)
    else:
        instance_server = None

    # V4.0 (H4.2): mở bằng --autostart (cùng Windows) → vào thẳng
    # tray, không bật cửa sổ; Agent API + dispatcher vẫn chạy nền.
    if "--autostart" in argv:
        window.hide()
        log.info("Mở app bằng --autostart: chạy nền ở tray.")
    else:
        window.show()
    code = app.exec()
    active_server = window.agent_server
    if active_server is not None:
        active_server.stop()
    if instance_server is not None:
        instance_server.close()
    store.close()
    # Thoát qua đường bình thường (đóng cửa sổ/Thoát ở tray) = thoát
    # sạch: ghi cờ để watchdog không mở lại oan.
    instance_guard.mark_clean_exit(data)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
