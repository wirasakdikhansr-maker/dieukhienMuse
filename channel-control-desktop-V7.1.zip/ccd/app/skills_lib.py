"""Thư viện skill (V4.3) — mẫu hướng dẫn dùng lại theo hồ sơ/kênh/chủ đề.

Skill là một file Markdown nằm tại ``<data_dir>/skills/<slug>.md``:

- Dòng đầu ``# Tên hiển thị`` là tên skill; phần còn lại là thân
  (mẫu hướng dẫn, có thể chứa các biến ``{profile}``, ``{channel}``,
  ``{topic}`` để :func:`render_body` thay khi dùng).
- Parse khoan dung: file không có dòng ``#`` ở đầu thì tên hiển thị
  lấy theo slug (tên file bỏ ``.md``) và thân là toàn bộ nội dung.

Slug luôn đi qua ``config.slugify`` nên tên/định danh lạ (chứa
``..``, ``/``…) không bao giờ thoát ra khỏi thư mục skills được;
các hàm ghi/xoá còn kiểm tra thêm file đích nằm TRONG thư mục đó
(resolve + ``is_relative_to``) trước khi chạm vào đĩa.

Module thuần, chỉ dùng thư viện chuẩn — không phụ thuộc Qt.
Mọi hàm nhận ``base: Path | None = None`` (None → ``config.data_dir()``).
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from pathlib import Path

from . import config

# Các biến được render_body hỗ trợ; biến ngoài danh sách này giữ nguyên.
_TEMPLATE_VARS = ("profile", "channel", "topic")


# --------------------------------------------------------------------------- #
# Đường dẫn
# --------------------------------------------------------------------------- #
def skills_dir(base: Path | None = None) -> Path:
    """Thư mục thư viện skill: ``<data_dir>/skills/``."""
    return (base or config.data_dir()) / "skills"


def skill_file_name(slug: str) -> str:
    return f"{slug}.md"


def _resolve_skill_path(slug: str, base: Path | None = None) -> Path | None:
    """Đường dẫn file của một slug ĐÃ chuẩn hoá, hoặc None nếu file
    đích (sau resolve) không nằm trong thư mục skills — chốt chặn
    path traversal cuối cùng dù slug đầu vào có dạng gì đi nữa."""
    safe_slug = config.slugify(slug or "")
    directory = skills_dir(base).resolve()
    path = (directory / skill_file_name(safe_slug)).resolve()
    if not path.is_relative_to(directory):
        return None
    return path


def _slug_from_name(name: str) -> str:
    """Slug cho một TÊN hiển thị mới; ValueError nếu tên không còn
    ký tự [a-z0-9] nào sau khi bỏ dấu (toàn ký tự lạ).

    Lưu ý: ``config.slugify`` tự trả ``"profile"`` khi slug rỗng —
    đó là quy ước đặt tên hồ sơ, không dùng được ở đây: tên skill
    rỗng slug phải bị từ chối thay vì âm thầm thành "profile"."""
    normalized = unicodedata.normalize("NFKD", name or "")
    ascii_text = normalized.encode("ascii", "ignore").decode("ascii")
    if not re.search(r"[a-z0-9]", ascii_text.lower()):
        raise ValueError(f"Tên skill không tạo được slug hợp lệ: {name!r}")
    return config.slugify(name)


# --------------------------------------------------------------------------- #
# Kiểu dữ liệu + parse
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class Skill:
    slug: str
    name: str
    body: str
    path: Path


def _parse_skill(path: Path, text: str) -> Skill:
    """Parse nội dung file skill (khoan dung, xem docstring đầu file).

    Thân được chuẩn hoá strip hai đầu khi đọc, để vòng save → load
    ổn định (file ghi ra luôn kết thúc bằng đúng một newline)."""
    slug = path.stem
    lines = text.splitlines()
    if lines and lines[0].startswith("#"):
        name = lines[0].lstrip("#").strip() or slug
        body = "\n".join(lines[1:]).strip()
    else:
        name = slug
        body = text.strip()
    return Skill(slug=slug, name=name, body=body, path=path)


def _read_skill(path: Path) -> Skill | None:
    try:
        text = path.read_text(encoding="utf-8")
    except (OSError, UnicodeError):
        return None
    return _parse_skill(path, text)


# --------------------------------------------------------------------------- #
# Đọc / liệt kê
# --------------------------------------------------------------------------- #
def list_skills(base: Path | None = None) -> list[Skill]:
    """Mọi skill hiện có, sắp theo tên hiển thị (casefold).
    Thư mục chưa có → danh sách rỗng; file lỗi đọc thì bỏ qua."""
    directory = skills_dir(base)
    if not directory.is_dir():
        return []
    skills: list[Skill] = []
    for path in directory.glob("*.md"):
        if not path.is_file():
            continue
        skill = _read_skill(path)
        if skill is not None:
            skills.append(skill)
    skills.sort(key=lambda s: s.name.casefold())
    return skills


def load_skill(slug: str, base: Path | None = None) -> Skill | None:
    """Đọc một skill theo slug (slug được chuẩn hoá qua slugify
    trước khi tra file). Không tồn tại / lỗi đọc → None."""
    path = _resolve_skill_path(slug, base)
    if path is None or not path.is_file():
        return None
    return _read_skill(path)


# --------------------------------------------------------------------------- #
# Ghi / xoá
# --------------------------------------------------------------------------- #
def save_skill(name: str, body: str, base: Path | None = None) -> Skill:
    """Lưu skill (tạo thư mục nếu chưa có). Lưu trùng tên = ghi đè
    cùng một file (slug suy ra từ tên). Trả Skill đã lưu.

    File ghi ra: dòng đầu ``# {name}``, tiếp theo là thân đã strip,
    kết thúc bằng đúng một newline. Tên không tạo được slug (toàn
    ký tự lạ) → ValueError, không ghi gì cả."""
    display_name = (name or "").strip()
    slug = _slug_from_name(display_name)
    directory = skills_dir(base)
    directory.mkdir(parents=True, exist_ok=True)
    path = _resolve_skill_path(slug, base)
    if path is None:  # không xảy ra với slug đã slugify — chốt an toàn
        raise ValueError(f"Tên skill không hợp lệ: {name!r}")
    normalized_body = (body or "").strip()
    if normalized_body:
        text = f"# {display_name}\n{normalized_body}\n"
    else:
        text = f"# {display_name}\n"
    path.write_text(text, encoding="utf-8")
    return Skill(slug=slug, name=display_name, body=normalized_body, path=path)


def delete_skill(slug: str, base: Path | None = None) -> bool:
    """Xoá skill theo slug. Xoá được → True; không tồn tại → False.
    Slug chứa ``..`` hay ``/`` được chuẩn hoá qua slugify + kiểm tra
    containment nên không bao giờ xoá được file ngoài thư mục skills."""
    path = _resolve_skill_path(slug, base)
    if path is None or not path.is_file():
        return False
    try:
        path.unlink()
    except OSError:
        return False
    return True


# --------------------------------------------------------------------------- #
# Render mẫu
# --------------------------------------------------------------------------- #
def render_body(body: str, profile: str = "", channel: str = "", topic: str = "") -> str:
    """Thay các biến ``{profile}`` ``{channel}`` ``{topic}`` trong
    thân skill bằng giá trị truyền vào (mặc định rỗng → thay bằng
    chuỗi rỗng). Biến lạ (``{xyz}``) giữ nguyên — vì vậy KHÔNG dùng
    ``str.format`` ở đây, chỉ thay đúng ba biến đã biết."""
    values = {
        "profile": "" if profile is None else profile,
        "channel": "" if channel is None else channel,
        "topic": "" if topic is None else topic,
    }
    rendered = body or ""
    for key in _TEMPLATE_VARS:
        rendered = rendered.replace("{" + key + "}", values[key])
    return rendered


# --------------------------------------------------------------------------- #
# V6.5 — NẠP SKILL TỪ THƯ MỤC
# --------------------------------------------------------------------------- #
_FRONT = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)
MAX_IMPORT_BYTES = 200_000


def _frontmatter(text: str) -> tuple[dict, str]:
    match = _FRONT.match(text)
    if not match:
        return {}, text
    meta = {}
    for line in match.group(1).splitlines():
        if ":" in line and not line.startswith((" ", "\t")):
            key, _, value = line.partition(":")
            meta[key.strip().lower()] = value.strip().strip("'\"")
    return meta, text[match.end():]


def import_folder(folder: Path, base: Path | None = None) -> list[Skill]:
    """Nạp skill từ một thư mục bất kỳ (vd thư mục skill kiểu Claude):

    - Mỗi thư mục con có ``SKILL.md`` → MỘT skill: tên lấy từ
      frontmatter ``name`` (không có thì tên thư mục), thân = mô tả +
      nội dung SKILL.md + các file .md tham chiếu nhỏ đi kèm.
    - Các file ``.md`` lẻ khác (không thuộc thư mục có SKILL.md) → mỗi
      file một skill (dòng ``#`` đầu là tên, như thư viện cũ).
    Trả danh sách skill đã lưu vào thư viện (ghi đè skill trùng tên)."""
    folder = Path(folder)
    if not folder.is_dir():
        raise ValueError(f"Không phải thư mục: {folder}")
    saved: list[Skill] = []
    skill_dirs = sorted({p.parent for p in folder.rglob("SKILL.md")} |
                        {p.parent for p in folder.rglob("skill.md")})
    covered = set(skill_dirs)
    for directory in skill_dirs:
        main = directory / "SKILL.md"
        if not main.is_file():
            main = directory / "skill.md"
        try:
            text = main.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        meta, body = _frontmatter(text)
        name = meta.get("name") or directory.name
        parts = []
        if meta.get("description"):
            parts.append(f"Mô tả: {meta['description']}")
        parts.append(body.strip())
        total = len(text)
        for extra in sorted(directory.rglob("*.md")):
            if extra == main or not extra.is_file():
                continue
            try:
                size = extra.stat().st_size
                if total + size > MAX_IMPORT_BYTES:
                    parts.append(f"(Tài liệu kèm: {extra.relative_to(directory)} — quá dài, chưa gộp)")
                    continue
                parts.append(f"\n## Tài liệu kèm: {extra.relative_to(directory)}\n"
                             + extra.read_text(encoding="utf-8", errors="replace").strip())
                total += size
            except OSError:
                continue
        try:
            saved.append(save_skill(name, "\n\n".join(p for p in parts if p), base))
        except ValueError:
            continue
    for path in sorted(folder.rglob("*.md")):
        if path.name.lower() == "skill.md" or any(d in path.parents for d in covered):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        meta, body = _frontmatter(text)
        lines = body.strip().splitlines()
        if meta.get("name"):
            name, rest = meta["name"], body.strip()
        elif lines and lines[0].startswith("#"):
            name, rest = lines[0].lstrip("#").strip(), "\n".join(lines[1:])
        else:
            name, rest = path.stem, body
        try:
            saved.append(save_skill(name or path.stem, rest, base))
        except ValueError:
            continue
    return saved
