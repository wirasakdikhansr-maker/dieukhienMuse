"""Trợ lý Windows Firewall (V3.9) — chỉ thư viện chuẩn, không Qt.

Mục đích: khi đường Tailscale đã thông mà Muse vẫn không gọi vào
được cổng Agent API, thủ phạm thường gặp là Windows Firewall chặn kết
nối ĐẾN trên giao diện mạng Tailscale (adapter này hay bị xếp vào hồ
sơ Public). Thay vì bắt người dùng mò trong Settings, app cung cấp
nút "Mở cổng cho app" chạy đúng MỘT rule tường lửa có tên riêng,
kèm UAC (người dùng tự bấm Yes) — gỡ được bằng rule cùng tên.

Các hàm dựng lệnh là hàm thuần để test; phần chạy thật dùng
Start-Process -Verb RunAs (hộp thoại UAC của Windows là chốt chặn
của người dùng, app không vượt qua được và không cố vượt).
"""

from __future__ import annotations

import subprocess
import sys

RULE_NAME = "Channel Control Desktop — Agent API"


def build_add_rule_script(port: int) -> str:
    """Script PowerShell tạo rule mở cổng TCP đến cho Agent API trên
    MỌI hồ sơ mạng (Private/Public/Domain) — cố ý Any vì adapter
    Tailscale bị xếp hồ sơ nào là do Windows quyết, không đoán trước
    được. Rule trùng tên thì xoá trước rồi tạo lại (idempotent)."""
    return (
        f"Remove-NetFirewallRule -DisplayName '{RULE_NAME}' "
        "-ErrorAction SilentlyContinue; "
        f"New-NetFirewallRule -DisplayName '{RULE_NAME}' "
        "-Direction Inbound -Action Allow -Protocol TCP "
        f"-LocalPort {int(port)} -Profile Any"
    )


def build_remove_rule_script() -> str:
    """Script PowerShell gỡ rule của app (dọn dẹp khi không dùng nữa)."""
    return (
        f"Remove-NetFirewallRule -DisplayName '{RULE_NAME}' "
        "-ErrorAction SilentlyContinue"
    )


def run_elevated_powershell(script: str) -> bool:
    """Chạy script PowerShell với quyền quản trị qua UAC. Trả về True
    nếu hộp thoại UAC đã được mở (người dùng bấm Yes thì lệnh chạy
    trong cửa sổ PowerShell riêng); False nếu không khởi chạy được
    (không phải Windows / lỗi hệ thống). Không chờ kết quả của cửa
    sổ được nâng quyền — nơi gọi báo người dùng kiểm tra lại sau."""
    if not sys.platform.startswith("win"):
        return False
    escaped = script.replace("'", "''")
    launcher = (
        "Start-Process powershell -Verb RunAs -ArgumentList "
        f"'-NoProfile','-Command','{escaped}'"
    )
    try:
        subprocess.run(
            ["powershell", "-NoProfile", "-Command", launcher],
            capture_output=True,
            timeout=30,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def run_add_rule(port: int) -> bool:
    """Mở cổng Agent API trong Windows Firewall (qua UAC)."""
    return run_elevated_powershell(build_add_rule_script(port))


def run_remove_rule() -> bool:
    """Gỡ rule tường lửa của app (qua UAC)."""
    return run_elevated_powershell(build_remove_rule_script())
