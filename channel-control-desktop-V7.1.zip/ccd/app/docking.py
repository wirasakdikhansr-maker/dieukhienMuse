"""Nhúng cửa sổ Chrome THẬT vào trong app (V3 — Windows only).

Cơ chế: tìm cửa sổ top-level của đúng tiến trình Chrome thuộc về hồ sơ
(đối chiếu PID đang nghe trên cổng remote-debugging của hồ sơ), rồi dùng
Win32 ``SetParent`` gắn nó làm cửa sổ con của một widget chứa trong panel
LIVE, đồng bộ kích thước theo khung chứa. "Gỡ nhúng" khôi phục cửa sổ về
trạng thái cửa sổ thường (parent/style/vị trí cũ đều được lưu lại trước
khi nhúng).

MỌI hàm đều có chốt chặn: không phải Windows, không tìm thấy cửa sổ, API
lỗi... -> trả False/None êm thấm để UI tự rơi về luồng ảnh CDP (chế độ
"Luồng trực tiếp" vốn có). Không bao giờ ép tắt Chrome.

LƯU Ý TRUNG THỰC: hành vi SetParent với cửa sổ Chrome phụ thuộc vào bản
Windows/Chrome cụ thể và KHÔNG kiểm chứng được từ môi trường Linux —
trên Windows thật có thể cần bấm "Nhúng lại" sau khi Chrome đổi cửa sổ
(đăng nhập xong, mở tab tách...). Xem thêm README mục V3.
"""

from __future__ import annotations

import subprocess
import sys

IS_WINDOWS = sys.platform == "win32"

# Hằng số Win32
GWL_STYLE = -16
WS_CHILD = 0x40000000
WS_VISIBLE = 0x10000000
WS_POPUP = 0x80000000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_MINIMIZEBOX = 0x00020000
WS_MAXIMIZEBOX = 0x00010000
WS_SYSMENU = 0x00080000
SWP_NOZORDER = 0x0004
SWP_NOACTIVATE = 0x0010
SWP_FRAMECHANGED = 0x0020

CHROME_WINDOW_CLASS = "Chrome_WidgetWin_1"


def _user32():
    """Trả về ctypes.windll.user32 trên Windows, None ở nơi khác.
    Khai báo restype/argtypes cho các hàm chạm tới HWND (con trỏ) để
    không bị cắt 32-bit trên Windows 64-bit."""
    if not IS_WINDOWS:
        return None
    try:
        import ctypes

        user32 = ctypes.windll.user32
        try:
            user32.SetParent.restype = ctypes.c_void_p
            user32.SetParent.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
            user32.GetParent.restype = ctypes.c_void_p
            user32.GetParent.argtypes = [ctypes.c_void_p]
            user32.GetWindowLongW.restype = ctypes.c_long
            user32.GetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int]
            user32.SetWindowLongW.restype = ctypes.c_long
            user32.SetWindowLongW.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long]
        except Exception:
            pass
        return user32
    except Exception:
        return None


def is_supported() -> bool:
    return _user32() is not None


def enable_dpi_awareness() -> bool:
    """KHÔNG còn tự đặt DPI awareness nữa (bản vá V3.1).

    Trước đây hàm này gọi ``shcore.SetProcessDpiAwareness`` TRƯỚC khi
    QApplication ra đời. Nhận thức DPI của tiến trình chỉ đặt được MỘT
    lần: khi Qt 6 khởi tạo, nó tự gọi ``SetProcessDpiAwarenessContext``
    để đặt mức mặc định tốt hơn (PER_MONITOR_AWARE_V2) và bị Windows từ
    chối (Access is denied) vì mức cũ đã chốt — in cảnh báo
    ``qt.qpa.window: SetProcessDpiAwarenessContext() failed`` ra console
    mỗi lần mở app. Nay để Qt tự lo hoàn toàn (mặc định của Qt 6 chính
    là Per-Monitor V2, tốt hơn mức shcore cũ), hàm này là no-op giữ lại
    cho tương thích ngược và luôn trả False."""
    return False


# --------------------------------------------------------------------------- #
# Tìm cửa sổ Chrome của hồ sơ
# --------------------------------------------------------------------------- #
def pid_listening_on_port(port: int) -> int | None:
    """PID của tiến trình đang NGHE trên 127.0.0.1:<port> (Windows: netstat).
    Mỗi hồ sơ có cổng debug riêng nên PID này xác định đúng bản Chrome đó."""
    if not IS_WINDOWS:
        return None
    try:
        output = subprocess.run(
            ["netstat", "-ano", "-p", "TCP"],
            capture_output=True,
            text=True,
            timeout=10,
        ).stdout
    except Exception:
        return None
    suffix = f":{port}"
    for line in output.splitlines():
        parts = line.split()
        # TCP  127.0.0.1:19500  0.0.0.0:0  LISTENING  12345
        if len(parts) >= 5 and parts[0] == "TCP" and parts[3] == "LISTENING":
            local = parts[1]
            if local.endswith(suffix) and (
                local.startswith("127.0.0.1") or local.startswith("0.0.0.0")
            ):
                try:
                    return int(parts[4])
                except ValueError:
                    return None
    return None


def enumerate_windows_for_pid(pid: int, include_hidden: bool = False) -> list[int]:
    """Liệt kê HWND top-level THUỘC tiến trình pid, là cửa sổ Chrome và
    đang hiển thị. Sắp xếp theo diện tích giảm dần (cửa sổ chính trước)."""
    user32 = _user32()
    if user32 is None or not pid:
        return []
    import ctypes
    from ctypes import wintypes

    found: list[tuple[int, int]] = []  # (hwnd, area)

    enum_proc_type = ctypes.WINFUNCTYPE(
        wintypes.BOOL, wintypes.HWND, wintypes.LPARAM
    )

    def _callback(hwnd, _lparam):
        window_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(window_pid))
        if window_pid.value != pid:
            return True
        if not user32.IsWindowVisible(hwnd):
            if not include_hidden:
                return True
            # V6.9: cửa sổ chính bị ẩn (SW_HIDE) vẫn nhúng được — cần có tiêu đề
            if user32.GetWindowTextLengthW(hwnd) <= 0:
                return True
        class_buf = ctypes.create_unicode_buffer(256)
        user32.GetClassNameW(hwnd, class_buf, 256)
        if class_buf.value != CHROME_WINDOW_CLASS:
            return True
        rect = wintypes.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(rect))
        area = max(0, rect.right - rect.left) * max(0, rect.bottom - rect.top)
        if area > 0:
            found.append((int(hwnd), area))
        return True

    try:
        user32.EnumWindows(enum_proc_type(_callback), 0)
    except Exception:
        return []
    found.sort(key=lambda item: -item[1])
    return [hwnd for hwnd, _area in found]


def find_chrome_window(profile: dict, manager=None) -> int | None:
    """Tìm HWND cửa sổ Chrome chính của một hồ sơ. Ưu tiên PID do chính
    phiên app này mở (manager ghi lại), sau đó tới PID nghe trên cổng
    debug của hồ sơ (trường hợp Chrome do Muse mở từ trước)."""
    if not IS_WINDOWS:
        return None
    pid = None
    if manager is not None:
        try:
            pid = manager.launched_pid(profile["slug"])
        except Exception:
            pid = None
    if not pid:
        pid = pid_listening_on_port(profile["port"])
    if not pid:
        return None
    windows = enumerate_windows_for_pid(pid)
    if not windows:
        # V6.9: Chrome đang bị cất/ẩn → vẫn tìm được cửa sổ chính để nhúng
        windows = [h for h in enumerate_windows_for_pid(pid, include_hidden=True)]
    return windows[0] if windows else None


def minimize_window(hwnd: int | None) -> bool:
    """Thu nhỏ một cửa sổ về taskbar (SW_MINIMIZE). Dùng khi tự đổi
    nhúng sang hồ sơ khác: cửa sổ Chrome của hồ sơ cũ được gỡ nhúng
    nhưng KHÔNG để bật ra ngoài màn hình — đúng yêu cầu 'trình duyệt
    chạy là nhúng thẳng vào giao diện, không mở ngoài' (V3.2)."""
    user32 = _user32()
    if user32 is None or not hwnd:
        return False
    try:
        return bool(user32.ShowWindow(int(hwnd), 6))  # SW_MINIMIZE
    except Exception:
        return False


def is_window_alive(hwnd: int | None) -> bool:
    user32 = _user32()
    if user32 is None or not hwnd:
        return False
    try:
        return bool(user32.IsWindow(int(hwnd)))
    except Exception:
        return False


# --------------------------------------------------------------------------- #
# Nhúng / gỡ nhúng — trạng thái gốc được lưu để khôi phục nguyên vẹn
# --------------------------------------------------------------------------- #
def _child_style(original_style: int) -> int:
    """Style cho cửa sổ đã nhúng: bỏ toàn bộ khung cửa sổ thường (caption,
    nút min/max/close của hệ thống, menu hệ thống, viền kéo giãn, popup)
    và đặt WS_CHILD + WS_VISIBLE — để Chrome không còn vẽ thanh tiêu đề
    riêng với nút thu/phóng/đóng bên trong app (V3.1)."""
    strip = (
        WS_POPUP
        | WS_CAPTION
        | WS_THICKFRAME
        | WS_MINIMIZEBOX
        | WS_MAXIMIZEBOX
        | WS_SYSMENU
    )
    return (original_style & ~strip) | WS_CHILD | WS_VISIBLE


SW_RESTORE = 9
SW_SHOWNOACTIVATE = 4


def ensure_restored(hwnd: int | None) -> bool:
    """V6.5.1: cửa sổ đang THU NHỎ (minimized) hoặc PHÓNG TO (maximized)
    thì Windows bỏ qua SetWindowPos đổi kích thước — nhúng vào khung sẽ
    chỉ còn một thanh tiêu đề nhỏ (lỗi "mở lại không full khung"). Đưa
    về trạng thái thường trước khi đặt kích thước. True nếu vừa khôi phục."""
    user32 = _user32()
    if user32 is None or not hwnd:
        return False
    try:
        if user32.IsIconic(int(hwnd)) or user32.IsZoomed(int(hwnd)):
            user32.ShowWindow(int(hwnd), SW_RESTORE)
            return True
    except Exception:
        pass
    return False


class BrowserDock:
    """Quản lý MỘT cửa sổ Chrome đang nhúng ở thời điểm hiện tại."""

    def __init__(self):
        self._hwnd: int | None = None
        self._saved: dict | None = None  # {parent, style, rect}
        # Ngữ cảnh khung chứa lần nhúng gần nhất — watchdog dùng để
        # nhúng LẠI vào đúng chỗ khi Chrome âm thầm tạo cửa sổ mới.
        self._container: int | None = None
        self._size: tuple[int, int] = (0, 0)

    @property
    def docked_hwnd(self) -> int | None:
        return self._hwnd

    @property
    def container_hwnd(self) -> int | None:
        return self._container

    def is_docked(self) -> bool:
        return self._hwnd is not None and is_window_alive(self._hwnd)

    def attach(self, chrome_hwnd: int, container_hwnd: int, width: int, height: int) -> bool:
        """Nhúng cửa sổ Chrome vào widget chứa. True nếu thành công."""
        user32 = _user32()
        if user32 is None or not chrome_hwnd or not container_hwnd:
            return False
        if self._hwnd is not None:
            self.detach()
        try:
            import ctypes
            from ctypes import wintypes

            rect = wintypes.RECT()
            user32.GetWindowRect(chrome_hwnd, ctypes.byref(rect))
            self._saved = {
                "parent": int(user32.GetParent(chrome_hwnd) or 0),
                "style": int(user32.GetWindowLongW(chrome_hwnd, GWL_STYLE)),
                "rect": (rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top),
            }
            self._hwnd = int(chrome_hwnd)
            self._container = int(container_hwnd)
            self._size = (int(width), int(height))
            user32.SetParent(chrome_hwnd, int(container_hwnd))
            child_style = _child_style(self._saved["style"])
            user32.SetWindowLongW(chrome_hwnd, GWL_STYLE, child_style)
            # V6.5.1: Chrome mở thu nhỏ (start_minimized) → khôi phục SAU
            # khi đã là cửa sổ con (không nháy ra màn hình) rồi mới giãn.
            ensure_restored(chrome_hwnd)
            try:
                user32.ShowWindow(int(chrome_hwnd), SW_SHOWNOACTIVATE)
            except Exception:
                pass
            self.sync_size(width, height)
            # Khẳng định lại style SAU SetWindowPos đầu tiên: một số bản
            # Chrome tự áp lại style khung của nó khi cửa sổ đổi parent —
            # đặt lại lần nữa (kèm FRAMECHANGED trong sync_size) để nút
            # min/max/close của Chrome biến mất hẳn. Mọi lỗi đều bỏ qua.
            try:
                user32.SetWindowLongW(chrome_hwnd, GWL_STYLE, child_style)
                self.sync_size(width, height)
            except Exception:
                pass
            return self.is_docked()
        except Exception:
            self._hwnd = None
            self._saved = None
            return False

    def sync_size(self, width: int, height: int) -> bool:
        """Đồng bộ kích thước cửa sổ đã nhúng theo khung chứa."""
        self._size = (int(width), int(height))
        user32 = _user32()
        if user32 is None or self._hwnd is None:
            return False
        ensure_restored(self._hwnd)
        try:
            user32.SetWindowPos(
                self._hwnd,
                0,
                0,
                0,
                max(1, int(width)),
                max(1, int(height)),
                SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED,
            )
            return True
        except Exception:
            return False

    def detach(self) -> bool:
        """Gỡ nhúng: trả cửa sổ Chrome về làm cửa sổ thường với style/vị
        trí như trước khi nhúng. Không tắt Chrome trong mọi trường hợp."""
        user32 = _user32()
        if user32 is None or self._hwnd is None:
            self._hwnd = None
            self._saved = None
            self._container = None
            return False
        hwnd, saved = self._hwnd, self._saved
        self._hwnd = None
        self._saved = None
        self._container = None
        if not is_window_alive(hwnd):
            return False
        try:
            user32.SetParent(hwnd, saved["parent"] if saved else 0)
            if saved:
                user32.SetWindowLongW(hwnd, GWL_STYLE, saved["style"])
                x, y, w, h = saved["rect"]
                user32.SetWindowPos(
                    hwnd, 0, x, y, w, h, SWP_NOZORDER | SWP_FRAMECHANGED
                )
            return True
        except Exception:
            return False


# --------------------------------------------------------------------------- #
# Watchdog (V3.1) — tự nhúng lại khi Chrome tạo lại cửa sổ
# --------------------------------------------------------------------------- #
class DockWatchdog:
    """Mỗi nhịp tick (UI gọi định kỳ): kiểm tra cửa sổ đang nhúng còn sống
    không. Chrome đôi khi tự HUỶ cửa sổ cũ và dựng cửa sổ mới (đăng nhập
    xong, tách tab, cập nhật...): khi đó watchdog tìm cửa sổ Chrome hiện
    tại của hồ sơ (qua ``find_window`` được tiêm vào) và nhúng lại vào
    đúng khung chứa cũ.

    Trả về một trong: 'idle' (chưa từng nhúng), 'ok' (còn sống),
    'redocked' (vừa nhúng lại), 'lost' (cửa sổ cũ chết và không tìm
    được cửa sổ mới — UI nên về Luồng trực tiếp), 'unavailable'
    (nền tảng không hỗ trợ nhúng). Logic tách khỏi Qt và nhận dock/find
    qua tham số để kiểm thử bằng bản giả.
    """

    def __init__(self, dock: BrowserDock, find_window):
        self._dock = dock
        self._find_window = find_window  # callable(profile, manager) -> hwnd|None
        self._profile: dict | None = None
        self._manager = None

    def watch(self, profile: dict | None, manager=None) -> None:
        """Ghi nhớ hồ sơ đang được nhúng (gọi sau mỗi lần nhúng thành công)."""
        self._profile = profile
        self._manager = manager

    def forget(self) -> None:
        self._profile = None
        self._manager = None

    def tick(self) -> str:
        dock = self._dock
        if not IS_WINDOWS:
            return "unavailable" if dock.docked_hwnd is not None else "idle"
        if dock.docked_hwnd is None:
            return "idle"
        if dock.is_docked():
            # V6.5.1: cửa sổ đã nhúng mà bị thu nhỏ (vd tự đổi hồ sơ thu
            # nhỏ cửa sổ cũ, Chrome tự minimize) → khôi phục + giãn lại.
            if ensure_restored(dock.docked_hwnd) and dock._size[0]:
                dock.sync_size(*dock._size)
            return "ok"
        # Cửa sổ cũ đã chết. Còn ngữ cảnh khung chứa + hồ sơ thì tìm lại.
        container = dock.container_hwnd
        profile = self._profile
        if container is None or profile is None:
            dock.detach()
            return "lost"
        try:
            hwnd = self._find_window(profile, self._manager)
        except Exception:
            hwnd = None
        if not hwnd:
            dock.detach()
            return "lost"
        width, height = dock._size if dock._size[0] else (800, 600)
        if dock.attach(hwnd, container, width, height):
            return "redocked"
        return "lost"


OFFSCREEN_POS = -32000


def move_window_offscreen(hwnd: int) -> bool:
    """Đưa cửa sổ RA NGOÀI phạm vi màn hình (vẫn chạy, không minimize) —
    tuỳ chọn ẩn trình duyệt ngoài khung nhúng mà người dùng yêu cầu:
    cửa sổ không hiện trên desktop nhưng phiên vẫn chạy nền."""
    if not hwnd:
        return False
    user32 = _user32()
    if user32 is None:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        SWP_NOSIZE = 0x0001
        SWP_NOZORDER = 0x0004
        return bool(
            user32.SetWindowPos(
                wintypes.HWND(hwnd), None, OFFSCREEN_POS, OFFSCREEN_POS,
                0, 0, SWP_NOSIZE | SWP_NOZORDER,
            )
        )
    except Exception:
        return False


GWL_EXSTYLE = -20
WS_EX_TOOLWINDOW = 0x00000080
WS_EX_APPWINDOW = 0x00040000


def hide_from_taskbar(hwnd: int) -> bool:
    """V6.7: gỡ nút của cửa sổ khỏi TASKBAR (kiểu cửa sổ công cụ) — 100
    Muse chạy nền không còn lấp đầy taskbar. Cửa sổ vẫn sống, CDP vẫn chạy,
    vẫn nhúng được vào app."""
    user32 = _user32()
    if user32 is None or not hwnd:
        return False
    try:
        ex = int(user32.GetWindowLongW(int(hwnd), GWL_EXSTYLE))
        wanted = (ex | WS_EX_TOOLWINDOW) & ~WS_EX_APPWINDOW
        if wanted == ex:
            return True
        user32.ShowWindow(int(hwnd), 0)  # SW_HIDE — taskbar chỉ cập nhật khi ẩn/hiện lại
        try:
            user32.SetWindowLongW(int(hwnd), GWL_EXSTYLE, wanted)
        finally:
            # LUÔN hiện lại (ngoài màn hình → vẫn vô hình) — cửa sổ bị kẹt ẩn
            # sẽ không tìm thấy để nhúng (lỗi "Đang chờ nhúng cửa sổ Chrome…").
            user32.ShowWindow(int(hwnd), 4)  # SW_SHOWNOACTIVATE
        return True
    except Exception:
        return False


def park_window(hwnd: int) -> bool:
    """Cất cửa sổ Chrome chưa nhúng: ra NGOÀI màn hình + khỏi taskbar.
    Không thu nhỏ (thu nhỏ làm trang chạy chậm/ngừng chảy chữ)."""
    if not hwnd:
        return False
    ensure_restored(hwnd)
    moved = move_window_offscreen(hwnd)
    hide_from_taskbar(hwnd)
    return moved


def move_window_onscreen(hwnd: int, x: int = 60, y: int = 60) -> bool:
    """Đưa cửa sổ ngoài màn hình trở lại vị trí nhìn thấy được."""
    if not hwnd:
        return False
    user32 = _user32()
    if user32 is None:
        return False
    try:
        from ctypes import wintypes
        SWP_NOSIZE = 0x0001
        SWP_NOZORDER = 0x0004
        return bool(
            user32.SetWindowPos(
                wintypes.HWND(hwnd), None, x, y,
                0, 0, SWP_NOSIZE | SWP_NOZORDER,
            )
        )
    except Exception:
        return False

