"""Chạy Channel Control Desktop:  python run.py

Cờ tuỳ chọn (V4.0):
- ``--watchdog``: chạy dưới tiến trình giám sát — app thoát bất
  thường thì tự mở lại (tối đa 5 lần/giờ, xem app/watchdog.py).
- ``--autostart``: mở vào thẳng tray (khoá Run của Windows dùng).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

if "--watchdog" in sys.argv:
    from app import config as _config
    from app.watchdog import watchdog_main

    raise SystemExit(
        watchdog_main(
            sys.argv[1:],
            [sys.executable, str(Path(__file__).resolve())],
            log_path=_config.logs_dir() / "watchdog.log",
        )
    )

from app.main import main

if __name__ == "__main__":
    raise SystemExit(main())
