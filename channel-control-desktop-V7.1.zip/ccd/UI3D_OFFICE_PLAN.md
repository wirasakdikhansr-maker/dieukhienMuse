# PHƯƠNG ÁN GIAO DIỆN "VĂN PHÒNG 3D" — Channel Control Desktop

> Trạng thái: **CHỜ DUYỆT — chưa code giao diện.**
> Ý tưởng của người dùng (29/10/2026): mỗi công việc do một AI agent làm và
> hiển thị dạng 3D kèm % hoàn thành; thấy trực quan từng agent đang làm gì,
> tiến độ bao nhiêu, ai là quản lý; mô hình văn phòng có quản lý + nhân viên;
> thay cách hiển thị toàn chữ hiện nay.
> Ảnh mẫu: thư mục `ui3d_concepts/` (3 phương án A/B/C).

## 1. Ba phương án hình ảnh

- **A — Văn phòng isometric ấm** (`ccd_ui3d_conceptA...webp`): sàn văn phòng
  gỗ sáng, quản lý đứng cạnh bảng trạng thái tổng, mỗi agent là robot ngồi
  bàn làm việc với thẻ hologram nổi (tên + việc + vòng % + trạng thái),
  panel phải = chi tiết agent đang chọn. Thân thiện, dễ nhìn lâu.
- **B — Mission Control tối** (`ccd_ui3d_conceptB...webp`): khớp theme tối
  hiện tại của app; agent đứng trong "pod" kính phát sáng theo trạng thái
  (xanh đang làm / vàng chờ / đỏ cần chú ý), quản lý ở bục trung tâm với
  bảng TEAM QUEUE sau lưng, dải dưới = hàng đợi lệnh. Ít "văn phòng" nhất
  nhưng đồng bộ nhất với app hiện tại và nổi bật % nhất.
- **C — Diorama nhìn từ trên** (`ccd_ui3d_conceptC...webp`): đúng nghĩa đen
  "công sở": phòng kính riêng của quản lý ở góc, khu bàn nhân viên, bảng
  ghim "Waiting Queue", góc nghỉ; bong bóng thoại trên đầu mỗi nhân viên
  hiện việc + %. Dễ hiểu nhất cho người mới, nhiều chi tiết trang trí nhất.

Có thể lai: bố cục của C (phòng quản lý + khu nhân viên + bảng chờ) với
tông màu/kiểu thẻ tiến độ của A hoặc B.

## 2. Bố cục khung (áp cho mọi phương án)

Giữ nguyên khung app hiện tại (titlebar + topbar điều hướng). Thêm tab đầu
tiên **🏢 Văn phòng** làm màn hình mặc định khi mở app:

```
┌─────────────────────────────────────────────────────────────┐
│ Topbar (giữ nguyên) + chip tổng: số agent online · số lệnh  │
│ đang chạy · % tổng hôm nay · cầu nối (2 lớp như hiện tại)   │
├──────────────────────────────────────────┬──────────────────┤
│                                          │  Panel chi tiết  │
│         SÀN VĂN PHÒNG 3D/2.5D           │  của agent được  │
│  ┌─────────┐   ┌────┐ ┌────┐ ┌────┐      │  click chọn:     │
│  │ QUẢN LÝ │   │ NV │ │ NV │ │ NV │      │  avatar, kênh    │
│  │ + bảng  │   └────┘ └────┘ └────┘      │  phụ trách, việc │
│  │  hàng   │   ┌────┐ ┌────┐ ┌────┐      │  hiện tại + % +  │
│  │  đợi    │   │ NV │ │ NV │ │ NV │      │  bước đang làm,  │
│  └─────────┘   └────┘ └────┘ └────┘      │  lịch sử gần đây │
├──────────────────────────────────────────┴──────────────────┤
│ Dải hàng đợi: các lệnh queued/waiting_muse dạng thẻ nhỏ     │
│ (kéo-thả không làm ở đợt 1; bấm thẻ = nhảy tới tab Lệnh)    │
└─────────────────────────────────────────────────────────────┘
```

Các tab chữ hiện tại (Hồ sơ, Lệnh, Tài khoản Muse, Tiến độ...) **giữ
nguyên** — màn văn phòng là lớp hiển thị trực quan phủ lên cùng dữ liệu,
không thay thế chức năng quản trị chi tiết.

## 3. Ánh xạ dữ liệu thật (không bịa số liệu trang trí)

| Phần tử trên hình | Dữ liệu thật trong app |
|---|---|
| Nhân viên (mỗi bàn/pod một người) | Một dòng trong bảng `agents` (tài khoản Muse) |
| Quản lý đứng giữa | "Điều phối viên" = dispatcher của V4.0 + Muse chính đang giám sát vòng lệnh (hiển thị trạng thái cầu nối 2 lớp trên bảng sau lưng) |
| Thẻ/vòng % trên đầu agent | Lệnh đang giữ lease của agent đó (`commands.lease_agent_id`), % = `commands.progress`, dòng chữ nhỏ = `commands.step` |
| Màu trạng thái | Xanh = running có lease sống · Vàng = waiting_muse/queued của agent đó · Đỏ = needs_user · Xám = agent offline (theo `agent_status` từ `last_seen_at`) · Không có việc = bàn trống, agent "ngồi chờ" |
| Bảng hàng đợi sau lưng quản lý | Lệnh `queued` + `waiting_muse` sắp theo dispatcher (ưu tiên ui > auto > api) |
| Chip tổng trên topbar | Đếm thật từ store: agents online, commands running, done hôm nay |
| Panel chi tiết khi click | Hồ sơ phụ trách (agent_assignments), lệnh hiện tại, 5 lệnh gần nhất, nút hành động: mở tab Lệnh của agent, tạm dừng/tiếp tục (dùng API sẵn có) |
| Hoạt cảnh | Agent đang chạy: gõ phím/nhân vật nhún nhẹ + vòng % quay; needs_user: dấu ❗ nhấp nháy trên đầu + bàn đỏ; done: ✓ bật lên rồi thẻ mờ dần về bàn trống |

Số bàn hiển thị: theo số agent thật (2 hiện tại), tối đa 8 bàn/trang —
nhiều hơn thì cuộn ngang/phân trang (ghi rõ để không vỡ bố cục khi thêm
nhiều tài khoản Muse).

## 4. Kỹ thuật thực thi (đề xuất)

- **2.5D isometric bằng QGraphicsView/QPainter thuần Qt** — KHÔNG dùng
  engine 3D nặng hay WebEngine: sàn + bàn + nhân vật là sprite vẽ sẵn
  theo đúng phong cách phương án được duyệt, thẻ % là item vẽ động.
  Nhẹ (chạy mượt trên PC cấu hình thường), không phình bản exe, test
  được bằng cơ chế offscreen sẵn có, và giữ đúng kỷ luật "không widget
  con trong ô bảng" của dự án.
- Tần suất cập nhật: 1 giây/lần đọc store (chỉ khi tab Văn phòng đang
  hiện) — đủ mượt cho vòng % và trạng thái, không tốn CPU như live view
  trình duyệt.
- Module mới `app/ui/office_view.py` + `app/ui/office_scene.py` (logic
  ánh xạ agent/lệnh → phần tử sàn tách thuần để test), tài nguyên sprite
  trong `app/assets/office/`. Không sửa schema DB — V4.0 (claim/lease)
  đã cung cấp đủ dữ kiện (lease_agent_id, progress, step, needs_user).
- Đợt 1 làm: sàn + agent + thẻ % + màu trạng thái + click chọn + panel
  chi tiết + dải hàng đợi. Đợt 2 (sau khi dùng thật): hoạt cảnh nâng cao,
  kéo-thả giao việc, âm thanh tắt/mở.

## 5. Cần duyệt

1. Chọn phương án A / B / C (hoặc lai — nói rõ lai phần nào).
2. Màn Văn phòng có làm **màn mặc định khi mở app** không (đề xuất: có).
3. Tên gọi hiển thị của "quản lý": đề xuất **"Điều phối viên"** (đúng vai
   dispatcher + Muse giám sát), tránh hiểu nhầm là một tài khoản Muse
   thứ ba.
