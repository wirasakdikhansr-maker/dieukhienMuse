"""Điểm vào cho bản ĐÓNG GÓI EXE (PyInstaller, xem buildexe.bat).

Khác run.py ở một điểm sống còn: khi chạy dạng frozen (exe), dữ liệu
người dùng (SQLite, hồ sơ Chrome, cookies, nhật ký) phải nằm ở thư mục
data/ NGAY CẠNH file exe — không nằm trong thư mục thư viện _internal
(có thể bị thay mới mỗi lần build lại). Đặt CCD_DATA_DIR trước khi
import app để config.data_dir() dùng đúng chỗ này.

V4.0: hỗ trợ cùng hai cờ như run.py — ``--watchdog`` (tiến trình cha
giám sát, sập thì mở lại) và ``--autostart`` (mở vào thẳng tray).
"""

import os
import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    _exe_dir = Path(sys.executable).resolve().parent
    os.environ.setdefault("CCD_DATA_DIR", str(_exe_dir / "data"))
else:
    sys.path.insert(0, str(Path(__file__).resolve().parent))

if "--watchdog" in sys.argv:
    from app import config as _config
    from app.watchdog import watchdog_main

    _entry = (
        [sys.executable]
        if getattr(sys, "frozen", False)
        else [sys.executable, str(Path(__file__).resolve())]
    )
    raise SystemExit(
        watchdog_main(
            sys.argv[1:],
            _entry,
            log_path=_config.logs_dir() / "watchdog.log",
        )
    )

from app.main import main

if __name__ == "__main__":
    raise SystemExit(main())
