@echo off
chcp 65001 >nul
setlocal EnableDelayedExpansion
cd /d %~dp0
title Dong goi Channel Control Desktop thanh EXE

echo ============================================================
echo   DONG GOI CHANNEL CONTROL DESKTOP THANH FILE EXE
echo   Ket qua: dist\ChannelControlDesktop\ChannelControlDesktop.exe
echo            kem thu muc thu vien _internal ngay ben canh.
echo ============================================================
echo.

REM ---------- 1. Tim Python ----------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
    where python >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo [LOI] Khong tim thay Python tren may.
    echo Hay cai Python 3.11 tro len tu https://www.python.org/downloads/
    echo va nho tick o "Add python.exe to PATH" khi cai dat.
    pause
    exit /b 1
)
for /f "tokens=*" %%v in ('%PY% --version 2^>^&1') do echo Tim thay: %%v

REM ---------- 2. Moi truong build rieng ----------
set "VENV=.build-venv"
set "BPY=%VENV%\Scripts\python.exe"
if not exist "%BPY%" (
    echo Tao moi truong build %VENV% ...
    %PY% -m venv %VENV%
    if errorlevel 1 (
        echo [LOI] Khong tao duoc moi truong ao Python.
        pause
        exit /b 1
    )
)

REM ---------- 3. Tu dong tai thu vien neu thieu ----------
echo Kiem tra thu vien...
"%BPY%" -m pip install --upgrade pip >nul 2>nul
"%BPY%" -c "import PySide6, websocket" >nul 2>nul
if errorlevel 1 (
    echo Thieu thu vien chay app - dang tai ve ^(PySide6, websocket-client^)...
    "%BPY%" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [LOI] Tai thu vien that bai - kiem tra mang roi chay lai file nay.
        pause
        exit /b 1
    )
)
"%BPY%" -c "import PyInstaller" >nul 2>nul
if errorlevel 1 (
    echo Thieu PyInstaller - dang tai ve...
    "%BPY%" -m pip install "PyInstaller>=6"
    if errorlevel 1 (
        echo [LOI] Tai PyInstaller that bai - kiem tra mang roi chay lai file nay.
        pause
        exit /b 1
    )
)

REM ---------- 4. Don ban build cu cua app nay ----------
if exist "dist\ChannelControlDesktop" (
    echo Don ban build cu trong dist\ ...
    rmdir /s /q "dist\ChannelControlDesktop"
)
if exist "build\ChannelControlDesktop" rmdir /s /q "build\ChannelControlDesktop"
if exist "ChannelControlDesktop.spec" del /q "ChannelControlDesktop.spec"

REM ---------- 5. Dong goi ----------
echo.
echo Dang dong goi - buoc nay mat vai phut, dung tat cua so nay...
"%BPY%" -m PyInstaller --noconfirm --clean --windowed --onedir ^
    --name ChannelControlDesktop ^
    --icon "app\assets\app_icon.ico" ^
    --add-data "app\assets\app_icon.png;app\assets" ^
    --add-data "app\assets\app_icon.ico;app\assets" ^
    run_exe.py
if errorlevel 1 (
    echo.
    echo [LOI] Dong goi that bai - xem dong loi phia tren.
    pause
    exit /b 1
)

if not exist "dist\ChannelControlDesktop\ChannelControlDesktop.exe" (
    echo [LOI] Da build xong nhung khong thay file exe ket qua.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   THANH CONG!
echo   File exe:  dist\ChannelControlDesktop\ChannelControlDesktop.exe
echo   Thu vien:  dist\ChannelControlDesktop\_internal\
echo.
echo   Cach dung: copy CA THU MUC dist\ChannelControlDesktop di noi
echo   khac neu muon, chay file exe trong do. Du lieu cua app
echo   (ho so, cookies, nhat ky) tu luu vao thu muc data\ ngay canh
echo   file exe - khi cap nhat ban moi, nho giu lai thu muc data\ do.
echo ============================================================
pause
