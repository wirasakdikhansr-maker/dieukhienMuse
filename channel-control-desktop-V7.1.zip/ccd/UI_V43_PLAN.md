# Phác thảo V4.3 (bản đầy đủ) — Bảng việc theo từng AI · Văn phòng trực quan · Gộp tab · Co giãn 100+ agent · Trình duyệt nhúng làm mặt điều khiển · Thư viện Skill · Cài đặt giao diện · Kết nối không cần web Muse

> Trạng thái: PHÁC THẢO chờ duyệt. v1 theo yêu cầu 2026-10-29 15:12; v2 bổ sung 6 yêu cầu của người dùng 15:33 cùng ngày. Chưa code.
> Ảnh mẫu: thư mục `ui_v43_concepts/` — A: bảng Ô, B: bảng Nhánh, C: Văn phòng + Chi tiết Agent, D: gộp tab, E: văn phòng quy mô lớn, F: form tạo lệnh có Skill, G: panel Giao diện.
> Nguyên tắc xuyên suốt: **thiết kế cho 1 → 100+ agent ngay từ đầu** (mọi danh sách đều có tìm kiếm/lọc/cửa sổ hiển thị), **một work model dùng chung** cho mọi nơi hiển thị tiến độ, **không bước nào của app phụ thuộc web muse.ai đang mở**.

## 1. Tab Công việc — bảng tiến độ theo TỪNG tài khoản AI + cơ chế co giãn

Thay tab "Tiến độ" phẳng hiện tại bằng bảng việc nhóm theo agent trên một `work model` thuần duy nhất (agent → hồ sơ → kênh → lệnh, % cuốn chiếu tính sẵn), 3 dạng xem chuyển bằng nút gạt **[Danh sách | Ô | Nhánh]**, nhớ lựa chọn. Đầu bảng luôn có **dải tổng hợp cố định**: tổng số agent · đang chạy · đang chờ · vướng · % chung + **ô tìm kiếm** + **chip lọc** (Tất cả / Đang chạy / Đang chờ / Vướng / Rảnh) + chọn sắp xếp (Hoạt động gần nhất / % cao nhất / Tên).

- **Danh sách:** bảng nhóm theo agent (dòng tiêu đề agent thu gọn được), ảo hoá dòng — 100 agent vẫn mượt.
- **Ô (ảnh A):** mỗi agent một cột thẻ khi ít agent; **trên 12 agent tự chuyển lưới thẻ gọn**: mỗi ô chỉ gồm avatar + tên + việc hiện tại + vòng % + chip đếm (chạy/chờ/vướng); bấm ô → nở thành cột thẻ đầy đủ ngay tại chỗ. Cột tự chảy theo bề rộng cửa sổ (auto-fit, tối thiểu 300px/cột), cuộn dọc theo cửa sổ dữ liệu.
- **Nhánh (ảnh B):** cây Agent → Hồ sơ → Kênh → Lệnh, nút cha hiện **% cuốn chiếu**; mặc định **thu gọn mọi nhánh trừ nhánh có việc đang chạy/vướng**; nút "Mở nhánh đang hoạt động"; chỉ vẽ các nút đang hiện trên màn; có trượt zoom + nút vừa khung; tìm kiếm → nhảy tới và mở đúng nút.
- Dữ liệu: chỉ lệnh đang hoạt động + xong/thất bại trong ngày (nút xem thêm lịch sử); thứ tự việc trong mỗi agent = đúng thứ tự dispatcher để khớp thứ tự Muse sẽ làm; % và bước lấy từ `progress`/`step` app đã có.

## 2. Văn phòng — bố trí theo quy mô (yêu cầu co giãn)

Thuật toán xếp sàn theo số agent, chuyển mức tự động (người dùng ghi đè được bằng chọn Mật độ: Thoáng / Gọn / Siêu gọn):

| Số agent | Bố trí |
|---|---|
| 1–8 | Diorama đầy đủ như hiện nay (bàn, bong bóng, phòng quản lý) |
| 9–30 | Lưới bàn vừa: giữ bàn + tên + bong bóng % rút gọn, bỏ đồ trang trí phụ |
| 31–100 | Ô gọn: avatar + tên + thanh % + chip trạng thái, xếp lưới đều |
| >100 | Tường ô siêu gọn + bắt buộc qua tìm kiếm/lọc; phân trang theo khu |

Kèm theo: **trượt zoom + nút Vừa khung**, kéo để pan, **minimap** góc dưới khi sàn lớn hơn màn hình, **ô tìm agent** (gõ → sàn cuộn tới + bàn phát sáng), lọc "Chỉ hiện đang làm việc", chia khu theo trạng thái (Đang chạy / Chờ / Rảnh) khi ở mức gọn. Hiệu năng: tắt hoạt ảnh bong bóng khi >30 agent; chỉ dựng lại cảnh khi fingerprint đổi (đã có từ V4.1/V4.2).

**Tương tác chi tiết (yêu cầu 2 cũ):** hover bàn → phát sáng + thẻ nổi (tên + việc + %); bấm → panel **Chi tiết Agent** thành "hồ sơ công việc trực quan" (ảnh C): khối việc hiện tại (thanh % lớn + bước + đếm ngược lease), khối **"Đang làm & tiếp theo"** (mọi việc của agent với thanh % mini — bấm là nhảy sang tab Công việc đúng lệnh), dải **luồng nhánh mini** Agent → Hồ sơ → Kênh → Lệnh ở đáy panel. Panel và tab Công việc dùng chung work model — số liệu không bao giờ lệch.

## 3. Gộp tab — 11 mục xuống 7 (ảnh D)

| Tab mới | Gộp từ |
|---|---|
| 🏢 Văn phòng | Văn phòng + KPI của Tổng quan (header đã có sẵn các số này) |
| 🗂 Hồ sơ | (nguyên) |
| 📋 Công việc | **Lệnh công việc + Tiến độ** — tạo lệnh xong thấy tiến độ của nó ngay cùng màn (bảng việc 3 dạng ở trên, form tạo lệnh + bảng lệnh ở dưới, giữ nguyên mọi nút hiện có) |
| 🤖 Tài khoản Muse | (nguyên) |
| 📊 Báo cáo | Báo cáo kênh + Kiểm tra (hai khối, nút con chuyển qua lại) |
| ⚡ Tự động | (nguyên) |
| 🛠 Hệ thống | Nhật ký + Cài đặt + **khối Giao diện mới** (mục 6) |

## 4. Trình duyệt NHÚNG là mặt điều khiển chính + zoom 75% + giữ đăng nhập

- Mọi thao tác trình duyệt khi Muse làm lệnh chạy trong **Chrome nhúng của app, đúng profile của hồ sơ** (CDP) — đường web muse.ai không còn nằm trong luồng thực thi, hết cảnh phụ thuộc tab web hay bị văng.
- **Tự động zoom 75%** ngay khi trình duyệt được nhúng/hiển thị trong app (áp qua CDP theo từng target, **áp lại sau mỗi lần chuyển trang**); mức zoom chỉnh được 50–150% **theo từng hồ sơ**, lưu vào settings; thêm nút zoom ngay trên thanh công cụ tab Hồ sơ.
- **Giữ phiên đăng nhập:** watchdog kiểm tra trạng thái đăng nhập của từng profile (tái dùng tín hiệu "Đã đăng nhập" ở tab Tài khoản Muse); phát hiện bị văng → báo ngay trong app (hàng Tài khoản Muse + thanh trạng thái) và mở sẵn khung nhúng đúng profile đó để đăng nhập lại tại chỗ trong app — không phải ra web ngoài.

## 5. Thư viện Skill cho tạo lệnh — lưu ở `data/skills`

- Mỗi skill là một file `data/skills/<ten-file>.md`: dòng đầu `# Tên hiển thị`, thân là mẫu hướng dẫn; hỗ trợ biến `{profile}`, `{channel}`, `{topic}` — thay bằng giá trị của lệnh khi tạo. Thư mục `data/` vốn đã ngoài zip phát hành.
- Form tạo lệnh (trong tab Công việc) thêm hàng **Skill**: **combobox** nạp từ `data/skills` (mục đầu "— Không dùng skill —") + nút **💾 Lưu skill** (lưu nội dung đang gõ trong ô hướng dẫn thành skill mới, hỏi tên), **✏ Sửa** (mở hộp soạn thảo tên + nội dung), **🗑 Xoá**, **🔄 Nạp lại**.
- Chọn skill → nội dung (đã thay biến) điền vào ô hướng dẫn; người dùng vẫn sửa thêm được trước khi bấm Tạo lệnh. Skill áp cho cả hai form (theo hồ sơ và theo kênh).

## 6. Cài đặt giao diện (theo bố cục D được duyệt)

Khối **🎨 Giao diện** trong tab Hệ thống (ảnh G):

- **Nền:** chọn màu nền, hoặc ảnh nền từ file (lưu vào `data/themes/`) + trượt làm tối lớp phủ.
- **Màu nút chính (accent), màu viền, độ bo góc** (trượt), **độ sáng tổng thể** (trượt).
- **Font chữ** (combobox font hệ thống) + **cỡ chữ** (trượt 90–120%).
- **Preset có sẵn:** Mission Control (mặc định hiện tại) · Sáng · Tương phản cao · Diorama (pastel theo Văn phòng) + **Lưu preset riêng** của người dùng.
- Khu **xem trước trực tiếp**; thay đổi áp dụng ngay toàn app, không khởi động lại. Kỹ thuật: bộ theme tokens tập trung → sinh QSS một chỗ (thay các màu rải rác hiện nay); Văn phòng giữ bảng màu diorama riêng nhưng accent đi theo theme.

## 7. Kết nối không cần qua duyệt trên web Muse (yêu cầu đã nêu ở các bản trước)

Hai lớp, nói rõ phần nào làm được tới đâu:

- **Phía app (làm triệt để trong V4.3):** không còn bất kỳ bước nào bắt mở web muse.ai — phiếu kết nối là file nội bộ trong thư mục phiếu, cầu nối chạy nền bằng token + Tailscale; token được **cảnh báo trước khi hết hạn** thay vì chết im lặng; watchdog **tự nối lại** khi rớt và tự ghi lại file phiếu; sức khoẻ kết nối (online/heartbeat/lần gọi cuối) hiện ngay trong tab Tài khoản Muse và thanh trạng thái.
- **Phía thực thi (giảm tối đa lần phải duyệt):** giữ luật đã có — *lệnh đã tạo = uỷ quyền đầy đủ*, worker làm liền mạch toàn bộ bước của một lệnh, gom thao tác để giảm số lượt hỏi; chỉ dừng ở `needs_user` cho việc thật sự cần người (mã OTP, CAPTCHA, đăng nhập lại) và khi đó **app hiện rõ lý do + nút mở đúng chỗ xử lý ngay trong app** (khung nhúng đúng profile), không im lặng treo ở "Chờ Muse". Các duyệt bảo mật thuộc về nền tảng Muse thì app không tự huỷ được — cam kết ở đây là: không bước thừa, không chờ im lặng, lý do luôn hiện rõ trong app.

## 8. Kỹ thuật & kiểm thử (tóm tắt)

- `app/ui/work_model.py` (thuần, có test): cây việc + % cuốn chiếu + fingerprint + cửa sổ hiển thị; test với **120 agent giả lập** ở mức model và mức dựng cảnh (offscreen) để khoá hiệu năng co giãn.
- Settings mới: theme tokens + preset, zoom theo hồ sơ, mật độ văn phòng, dạng xem bảng việc. Skills: đọc/ghi `data/skills` qua module nhỏ có test (tên file an toàn, thay biến).
- Zoom nhúng: áp scale qua CDP khi attach + sau điều hướng, có test ở mức hàm áp dụng.
- Đổi điều hướng 11 → 7: cập nhật pin test điều hướng trong cùng thay đổi (kỷ luật CCD). Không đổi schema DB, không đổi Agent API, không đổi định dạng phiếu. Phiên bản đích: **V4.3 (app 4.3.0)**.

## 9. Ngoài phạm vi

- Tách phiên Muse riêng theo tài khoản để chạy song song (việc riêng, đã đề xuất).
- Viết lại god-file `main_window` (để V4.4 như lộ trình V4.2).

## Ghi chú kỹ thuật đã kiểm chứng (2026-10-29 15:50, từ lệnh của user "mày điều khiển trình duyệt trong app ý")
- app/cdp.py ĐÃ có sẵn các primitive điều khiển đầy đủ: evaluate (Runtime.evaluate), dispatch_mouse, dispatch_key, capture_screenshot_png, navigate — app tự dùng nội bộ (live_worker/scanner).
- NHƯNG Agent API (2.4) chỉ phơi ra cho Muse đúng 1 loại lệnh CDP: cdp_navigate (xem app/command_schema.py). Không có cdp_evaluate/cdp_click/cdp_type → Muse mở/điều hướng được trình duyệt nhúng nhưng KHÔNG bấm like, gõ bình luận được qua API. Đây là nguyên nhân gốc lệnh tương tác f15900c881c0 quay vòng needs_user/lease hết hạn suốt buổi chiều 29/10.
- Việc cần làm trong V4.3 (yêu cầu 2): thêm các loại lệnh agent cdp_evaluate / cdp_click / cdp_type (hoặc 1 lệnh cdp_act tổng quát) bọc quanh primitive sẵn có + chụp screenshot xác nhận sau mỗi hành động. Khối lượng nhỏ vì primitive đã tồn tại và đã có test nền (test_agent_server, test_chrome_launch).
