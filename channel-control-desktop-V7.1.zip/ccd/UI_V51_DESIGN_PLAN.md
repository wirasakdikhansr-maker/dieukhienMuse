# PHƯƠNG ÁN THIẾT KẾ V5.1 — Channel Control Desktop
(Chờ chủ kênh duyệt mới triển khai. Ảnh mẫu: thư mục `ui_v51_concepts/` + 3 ảnh mẫu V4.7 đã duyệt trong `ui_v47_concepts/`.)

## 0. Ba sự cố trên máy thật phải diệt tận gốc trong bản này
1. **Panel chi tiết agent bị lấp/đè, avatar chồng nhãn "CHI TIẾT AGENT", không có thanh cuộn** → panel dựng lại theo cấu trúc cuộn ở mục 2.1.
2. **Chat không thấy phản hồi trên panel** → đã chẩn đoán: tin đến app ✓, cầu nối đánh thức ✓ (3 lần), khâu hỏng là phía Muse thực thi chưa đọc/trả lời. Sửa cả hai đầu: app tự làm mới luồng chat đang mở (mục 2.1), phía thực thi có kỷ luật xử lý wake chat trước việc dài + parent kiểm chứng bằng tin thật đầu-cuối.
3. **Giao diện "không thay đổi một chút gì"** → căn nguyên: cơ chế di trú theme đòi settings khớp TUYỆT ĐỐI với bộ gốc; dữ liệu máy thật lệch vài trường nên bị coi là "đã tuỳ biến" và giữ nguyên navy cũ. Sửa bằng cơ chế kỷ nguyên giao diện (mục 1.2) — áp vô điều kiện, có sao lưu/khôi phục.

## 1. Hệ phong cách khóa cứng (áp cho 100% màn hình + hộp thoại)
### 1.1 Token
- Nền app `#0B0E11`; panel nổi `#15181D` bo góc **20px**, viền 1px sáng nhẹ `#262B33`; thẻ con `#1B1F26` bo 16px.
- Xanh nhấn DUY NHẤT `#4ADE80`; phần tử đang hoạt động có viền sáng + tint xanh 12% (quầng sáng bằng viền/tint, không dùng hiệu ứng bóng đổ hàng loạt).
- Chữ chính `#F2F5F0`, chữ phụ `#9BA3AB`, chữ mờ `#5F6B66`.
- Nút chính: pill xanh ĐẶC, chữ đen đậm; nút phụ: pill tối, viền sáng, chữ trắng; nút nguy hiểm: tint đỏ.
- Pill trạng thái: tint theo màu + chữ sáng cùng họ + chấm tròn.
- Avatar: agent = robot trong vòng tròn viền xanh khi online; kênh = chữ cái đầu trong vòng tròn màu riêng của kênh.
- Thanh tiến độ: dày 10px, rãnh `#24282E`, phần chạy xanh `#4ADE80` bo tròn, số % xanh đậm nét bên phải.
- Tiêu đề mục: đậm 20–24px; nhãn khối: chữ hoa 12px màu phụ, giãn cách thoáng (padding panel 20px, khoảng cách khối 16px).
- Thanh cuộn toàn app: mảnh 8px, tay nắm bo tròn màu `#2C3138`, hover `#4ADE80` 60%.
- Điều hướng trên: tab đang chọn = pill xanh đặc chữ đen (như ảnh mẫu), tab khác = pill tối.

### 1.2 Cơ chế áp dụng (chống tái diễn)
- Settings có khóa `theme_epoch`. V5.1 đặt epoch mới: **lần chạy đầu tiên áp bộ token V5.1 vô điều kiện**, bộ giá trị cũ được sao lưu sang `theme_backup_pre_v51` (không mất).
- Mục Hệ thống → Giao diện có: nút "↩ Khôi phục giao diện trước V5.1" (áp lại bản sao lưu) và "Áp dụng giao diện V5.1" (áp lại khi đã khôi phục/đã nghịch màu).
- Test bắt buộc: bộ settings giả lập máy thật (token Concept D + lệch cỡ chữ/bán kính) → khởi động → giao diện phải là V5.1; và đường khôi phục phải trả lại đúng giá trị cũ.

## 2. Từng tab
### 2.1 Văn phòng (ảnh mẫu 1)
- Sơ đồ giữ nguyên cấu trúc đã khóa (phòng, bàn, robot, bong bóng câu hỏi 💬 khi needs_user / có tin chưa đọc).
- **Panel chi tiết agent (dựng lại hoàn toàn):**
  - Header CỐ ĐỊNH cao ~76px: avatar robot tròn 56px bên trái, tên agent + email 2 dòng, pill trạng thái — không phần tử nào chồng lên nhãn nào (nhãn "CHI TIẾT AGENT" bỏ hẳn, header tự nói lên điều đó).
  - Thân panel = **QScrollArea cuộn dọc** (thanh cuộn theo 1.1), các khối xếp dọc: "Việc hiện tại" (tên việc + bước + thanh %) → "Tiếp theo" (hàng đợi của agent) → "Đã xong gần đây" (tối đa 5, có giờ) → mục chat hiển thị trạng thái luồng.
  - **Khối TRÒ CHUYỆN nằm trong panel nhưng ô soạn GHIM ở đáy panel, ngoài vùng cuộn** — luôn nhìn thấy, không phải cuộn xuống mới nhắn được. Luồng tin là vùng cuộn riêng (cuộn trong), bong bóng: user phải/xanh, agent trái/tối, system căn giữa tint vàng.
  - Bỏ hai nút nhảy "Mở tab Lệnh" / "Tài khoản Muse" khỏi panel (chat và việc đã tại chỗ; Tài khoản mở bằng tab điều hướng như mọi mục).
  - Panel đang mở thì luồng chat tự làm mới mỗi 5 giây + ngay khi chọn agent khác (cộng với refresh theo vân sẵn có) — câu trả lời xuất hiện mà không cần bấm đi đâu.
- Minimap + zoom giữ nguyên, phủ lại màu theo token mới.

### 2.2 Hồ sơ (ảnh mẫu 3)
- Chế độ đơn: trình duyệt nhúng chiếm **100% vùng nội dung** của mục; panel dữ liệu hồ sơ thu thành một thanh chip ngang trên cùng (avatar + tên hồ sơ + pill đăng nhập + nút thu/mở bảng dữ liệu dạng trượt xuống khi cần).
- Thanh công cụ trình duyệt gộp 1 hàng mảnh trong khung: lùi/tiến/tải lại, địa chỉ rút gọn, zoom (50–150%), ⛶ khi đang ở tường.
- Tường trình duyệt (≥3): lưới như V4.5 nhưng mỗi ô theo style mới (header ô: avatar + tên + pill + ⛶); panel dữ liệu tự ẩn như cũ.

### 2.3 Công việc (ảnh mẫu 2)
- Bảng "Ai đang làm gì" dựng dạng THẺ (không dùng cây trần): mỗi agent = một thẻ lớn (viền sáng + tint khi đang có việc chạy): avatar robot, tên + mail, pill trạng thái, tiến độ tổng + thanh %.
- Trong thẻ agent: các kênh = thẻ con — avatar chữ của kênh, tên kênh, 2 dòng mô tả việc hiện tại/bước, thanh % + số %, pill trạng thái kênh, dòng chữ nhỏ "Thường trực: N mục".
- Chuột phải thẻ kênh: menu 5 mục (Giao việc cho kênh này… / Việc Muse phải làm cho kênh… / Xem tiến độ kênh / Mở trình duyệt của kênh / Tạm dừng kênh này) — style menu theo token mới.
- Cột phải: "Hàng đợi — <kênh đang chọn>" dạng danh sách thẻ nhỏ có % từng việc; dưới cùng là bảng lệnh chi tiết (giữ bộ lọc 1 hàng + 3 dạng xem) khi cần tra cứu.
- Form "Giao việc" (cột trái) giữ nguyên chức năng V5.0 (kênh checkbox → lô lệnh; skill) nhưng phủ style mới; hộp thoại Giao việc từ chuột phải giữ đủ checklist + khối Skill (chọn/nhập/dán) + ghi chú như V5.0.

### 2.4 Báo cáo
- Trên cùng: banner nghẽn chung 1 dòng (nền tint theo mức độ).
- Thẻ kênh theo chuẩn báo cáo đã khóa (tên/handle/thể loại/sub, pill trạng thái màu, tiến độ sản xuất, public/lịch + giờ, blockers, mục "Cần anh quyết" đỏ tách riêng) — dựng bằng thẻ bo 20 theo token mới; 3 dạng Ô/Lưới/Danh sách + cỡ S/M/L giữ nguyên.
- Khối báo cáo/kiểm tra đặt trên board như V4.3.2 đã chốt.

### 2.5 Tự động
- Mỗi quy tắc = một thẻ: tên, mô tả ngắn, công tắc pill bật/tắt (xanh khi bật), trạng thái lần chạy gần nhất + nút chạy ngay/sửa/xoá.
- Khối sức khỏe tự động (automation health) thành banner tint khi có lỗi, im lặng khi khỏe.

### 2.6 Tài khoản Muse (ảnh mẫu 4)
- Bảng theo style thẻ-dòng: avatar robot, tên, mail, pill trạng thái ('Đang hoạt động' xanh / 'Vừa rời đi' vàng / 'Ngoại tuyến' xám / 'Chưa kết nối' viền), cột Muse.ai (✓ Đã đăng nhập), cột Phiếu, cột Kết nối với nút pill "🔌 Kết nối" / "Đã kết nối ✓".
- Hộp thoại Kết nối: 2 lớp tách bạch (Cầu nối: nhịp cuối + lý do ngoại tuyến suy ra từ dữ liệu thật; Muse.ai: đã/chưa đăng nhập) + dòng giải thích 1 câu + nút "Xuất phiếu kết nối" / "Kiểm tra lại ngay".
- Khung chat từng agent giữ làm cửa thứ hai (cùng component với panel Văn phòng).

### 2.7 Hệ thống
- Hai cột thẻ: Nhật ký (cuộn, monospace, lọc theo mức) | Cài đặt + Giao diện (xem trước trực tiếp, thanh trượt gọn, nút áp dụng/khôi phục giao diện theo 1.2, thư mục phiếu, tự khởi động).
- Thẻ "Cầu nối" tóm tắt: số agent online/tổng, nhịp heartbeat cuối, nút mở thư mục phiếu.

## 3. Hộp thoại dùng chung
Giao việc, Kết nối, Thêm/Sửa mẫu việc, Nhập skill, Xác nhận xoá: nền panel `#15181D` bo 20, tiêu đề đậm 18px, nút Huỷ (phụ) + nút chính (xanh đặc) ở đáy phải, khoảng đệm 20px — đúng ảnh mẫu hộp thoại Giao việc đã duyệt.

## 4. Nghiệm thu (điều kiện đóng gói)
- Parent đối chiếu TỪNG TAB bằng ảnh render thật với ảnh mẫu đã duyệt trong `ui_v51_concepts/`; lệch cấu trúc/màu là trả làm lại trước khi đóng gói.
- Kiểm chứng trên bộ settings giả lập máy thật (mục 1.2) + panel chi tiết ở 2 kích thước cửa sổ (1366px và 1920px) không chồng chữ, cuộn được.
- Chat đầu-cuối bằng tin thật qua cầu nối thật: gửi trong app → Muse trả lời hiện trên panel đang mở.
- Toàn bộ test xanh (gồm test mới cho epoch + panel cuộn) mới đóng zip.
