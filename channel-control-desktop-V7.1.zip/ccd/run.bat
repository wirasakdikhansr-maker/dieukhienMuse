@echo off
chcp 65001 >nul
cd /d %~dp0
where python >nul 2>nul
if errorlevel 1 (
    echo Khong tim thay Python. Hay cai Python 3.11+ va nho tick "Add python.exe to PATH".
    pause
    exit /b 1
)
python run.py
pause
