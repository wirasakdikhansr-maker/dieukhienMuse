# Mô hình giao việc theo dòng Agent (V5.0)

Mục **Công việc** có view chính **🧑‍🤝‍🧑 Theo Agent**: mỗi agent một
dòng (tên, email, trạng thái, tổng tiến độ), mở ra thấy các **kênh**
agent quản lý — mỗi kênh một dòng con gồm việc hiện tại, thanh %, trạng
thái và bước hiện tại. Bên phải là hàng đợi việc của agent/kênh đang
chọn. Dữ liệu lấy từ work model dùng chung của mục Công việc — không
có nguồn dữ liệu song song. Form tạo lệnh thủ công vẫn ở cột trái làm
lối vào phụ.

## Luồng chính: chuột phải trên dòng kênh

| Mục menu | Hành vi |
|---|---|
| 📋 Giao việc cho kênh này… | Mở hộp thoại Giao việc (checklist mẫu + skill + ghi chú) |
| 🤖 Việc Muse phải làm cho kênh… | Mở checklist THƯỜNG TRỰC của kênh (xem/sửa/lưu, tạo việc ngay) |
| 📊 Xem tiến độ kênh | Chọn kênh đó — hàng đợi bên phải hiện việc của kênh |
| 🌐 Mở trình duyệt của kênh | Sang mục Hồ sơ, chọn đúng hồ sơ của kênh và mở trình duyệt |
| ⏸ Tạm dừng kênh này | Dùng cờ tạm dừng sẵn có ở **cấp hồ sơ** (dispatcher tôn trọng; app chưa có cờ riêng cho từng kênh) — hộp thoại xác nhận nói rõ phạm vi trước khi áp; bấm lại để bỏ dừng |

## Hộp thoại Giao việc

- **Checklist công việc mẫu**: tick N mục → bấm **Giao N việc** → tạo
  đúng N lệnh, mỗi lệnh gắn đúng agent phụ trách / hồ sơ / kênh đó
  (lệnh app tự chạy như `check` không gắn agent). Cả lượt dùng chung
  một `batch_id` khi N > 1.
- **Khối Skill**: chọn 1 skill trong thư viện (`data/skills/*.md`,
  cơ chế V4.3) → nội dung skill (đã thay biến `{profile}`/`{channel}`/
  `{topic}`) được nối vào instruction của MỌI lệnh trong lượt, đồng
  thời payload ghi rõ skill đã chọn. Có thể **nhập skill mới ngay tại
  đây**: nút "📥 Nhập file .md" (đọc file → lưu vào thư viện → chọn
  ngay) hoặc "📋 Dán skill mới" (đặt tên + dán nội dung). File rỗng /
  không đọc được → báo lỗi tại chỗ, không lưu.
- **Ghi chú**: đính kèm vào mọi lệnh của lượt.
- Mẫu việc **lưu được và sửa được** (Thêm/Sửa/Xoá mẫu trong hộp
  thoại) — xem định dạng file bên dưới.

## Checklist thường trực theo kênh

Bộ việc "Muse phải làm cho kênh này" lưu riêng cho từng kênh: các
mục mẫu đã tick + skill mặc định của kênh (nếu có). Trên dòng kênh
hiện tóm tắt **"Thường trực: N mục"**. Nút **"▶ Tạo các việc này
ngay"** tạo đủ lệnh như một lượt Giao việc.

Bản V5.0 **không** tự phát sinh lệnh theo lịch từ checklist thường
trực: cơ chế Tự động hiện có chưa nối vào được một cách sạch; việc
nối (kèm tuỳ chọn bật/tắt theo kênh) để dành bản sau.

## Định dạng dữ liệu (file trong thư mục dữ liệu của app)

Không dùng bảng DB mới — schema giữ nguyên 8.

`data/task_templates.json` — mảng mẫu việc dùng chung:

```json
[
  {"id": "tao-video-moi", "title": "Tạo video mới",
   "type": "create_video",
   "instruction": "Tạo một video mới cho kênh {channel} …"}
]
```

`type` là một loại lệnh hợp lệ của app (`create_video`, `optimize`,
`upload`, `free`, `create_channel`, `check`, `scan`, `open_browser`);
`{channel}` trong instruction được thay bằng tên kênh khi giao. Chưa
có file → dùng 6 mẫu mặc định: Tạo video mới · Tối ưu tiêu đề + mô tả
+ tags · Kiểm tra tình trạng kênh · Lên lịch phát hành · Ghim bình
luận sau khi đăng · Trả lời bình luận mới.

`data/channel_checklists.json` — checklist thường trực, khoá là id
dòng kênh trong DB:

```json
{"12": {"template_ids": ["tao-video-moi", "len-lich-phat-hanh"],
        "skill_slug": "quy-trinh-dang-video"}}
```

## Payload của lệnh được giao

```json
{"assignment": {"source": "agent_board",
                "template_id": "tao-video-moi",
                "template_title": "Tạo video mới",
                "skill_slug": "quy-trinh-dang-video",
                "skill_name": "Quy trình đăng video",
                "note": "ghi chú của người dùng"},
 "batch_id": "…", "batch_index": 1, "batch_total": 3}
```

Chi tiết lệnh (mục Công việc) tra được nguồn gốc của lệnh từ khối
`assignment` này; nội dung skill đầy đủ nằm ngay trong instruction để
Muse thực thi đọc được.
