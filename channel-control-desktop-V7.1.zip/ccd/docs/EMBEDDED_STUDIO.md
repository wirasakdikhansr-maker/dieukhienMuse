# Điều khiển YouTube Studio qua trình duyệt NHÚNG (V4.4)

Playbook cho phía thực thi (Muse) khi làm các việc Studio nặng —
upload video, điền metadata, lên lịch, kiểm tra trạng thái — **ngay
trong Chrome nhúng của app**, đúng hồ sơ/kênh, thay vì dùng trình
duyệt riêng. App là bên lái trình duyệt; Muse chỉ ra lệnh bằng
`studio_script` + nhận báo cáo (trạng thái từng bước, giá trị đọc
được, ảnh chụp) qua cầu nối.

## Cơ chế trong 30 giây

- Loại lệnh: `studio_script`, payload `{"steps": [...]}`.
- App mở (hoặc dùng lại) Chrome nhúng của **đúng hồ sơ đích**, chạy
  tuần tự các bước qua CDP, báo `progress` % + mô tả bước hiện tại.
- Bước lỗi → dừng ngay, chụp màn hình lỗi (`error_screenshot`), kết
  quả lệnh (`result_data`) ghi trạng thái TỪNG bước + `reads` +
  danh sách ảnh chụp (`screenshots/`, tên bắt đầu `studio-<id8>-`).
- Chạm tường đăng nhập/xác minh → lệnh dừng ở **`needs_user`** với
  lý do rõ. Đây là ranh giới cứng: chỉ OTP / CAPTCHA / đăng nhập /
  xác minh 2 bước mới là `needs_user`, và **không bao giờ tự vượt**
  — báo chủ kênh xử lý trong cửa sổ Chrome nhúng rồi chạy lại.

## Các bước (steps) được hỗ trợ

| action | trường | ý nghĩa |
|---|---|---|
| `goto` | `url`, `timeout_s?` | mở trang + chờ tải xong |
| `wait_for` | `selector` hoặc `text`, `timeout_s?` | chờ phần tử xuất hiện |
| `click` | `selector` hoặc `text` | bấm phần tử (chuột thật tại tâm) |
| `fill` | `selector`, `text` | focus + điền chữ vào ô nhập |
| `press` | `key` | Enter/Tab/Escape/Backspace/Delete/Space/mũi tên/Home/End/PageUp/PageDown hoặc 1 ký tự |
| `upload` | `file`, `selector?` | nạp file ĐÃ GIAO KÈM LỆNH vào `<input type=file>` (mặc định selector `input[type="file"]`) |
| `read` | `selector`, `save_as`, `attr?` | đọc text (hoặc thuộc tính) → lưu vào `reads[save_as]` |
| `screenshot` | `name` | chụp màn hình lưu phía app |
| `sleep` | `seconds` (0–300) | chờ |
| `require_no_login_wall` | `url_markers?`, `text_markers?` | đang ở màn hình đăng nhập/xác minh Google → dừng `needs_user` |

`file` trong bước `upload` **chỉ là tên file thuần** (vd
`video.mp4`) — app tự resolve trong thư mục file của lệnh. Đường
dẫn tuyệt đối, `/`, `\`, `..` bị chặn ở cả tầng validate lẫn lúc
chạy.

## Quy trình chuẩn

### 1. Chọn đúng hồ sơ/kênh
Xác định hồ sơ (profile) chứa kênh đích. Mọi lệnh `studio_script`
chạy trong Chrome của đúng hồ sơ đó — sai hồ sơ là sai kênh.

### 2. Tạo lệnh + giao file kèm lệnh
Thứ tự an toàn: **tạo lệnh trước → giao file ngay → lệnh mới chạy**
(lệnh tạo trong UI nằm ở `queued` tới khi bấm chạy/đến lượt; lệnh
tạo qua API được worker nhận nhanh — giao file NGAY sau khi có
`command_id`, nếu bước upload báo "Chưa có file" thì giao file rồi
chạy lại lệnh).

- Tạo lệnh qua Agent API: `POST /api/commands`
  `{"type": "studio_script", "profile": "<slug>", "payload": {"steps": [...]}}`
  → `202 {"command_id": "..."}`.
- Giao file: `POST /api/inbox` với header `X-File-Name: <tên file>`,
  `X-File-Sha256: <sha256 hex>` (kiểm tra toàn vẹn như chuẩn V4.2)
  và **`X-Command-Id: <command_id>`**, body = bytes của file.
  - File lưu ở `data/command_files/<command_id>/<tên thuần>` —
    giữ đúng tên để bước `upload` tham chiếu; gửi lại cùng tên = ghi đè.
  - Giới hạn **2 GiB/file** (413 nếu vượt). Lệnh không tồn tại →
    404; lệnh đã `done`/`failed` → 409.
  - Không có `X-Command-Id` → hành vi cũ (inbox dùng chung).
  - File bị xoá cùng lúc lệnh bị xoá (vòng đời gắn với lệnh).

### 3. Theo dõi tiến độ
Đọc lệnh qua API/UI: `progress` % + `step` (mô tả bước hiện tại).
Kết thúc:
- `done` → đọc `result_data`: trạng thái từng bước, `reads`,
  `screenshots`.
- `failed` → `error` nêu đúng bước hỏng + `error_screenshot`;
  `result_data.steps` cho biết đã làm được tới đâu. Sửa kịch bản /
  selector rồi chạy lệnh MỚI (đừng đoán mò — mở ảnh lỗi ra xem).
- `needs_user` → xem mục 4.

### 4. Xử lý `needs_user` (chỉ OTP/CAPTCHA/đăng nhập)
Báo chủ kênh: hồ sơ nào, đang chặn ở màn hình gì (lý do trong lệnh
đã ghi rõ dấu hiệu: URL `accounts.google.com` hoặc chữ xác minh).
Chủ kênh đăng nhập/xác minh ngay trong cửa sổ Chrome nhúng của hồ
sơ đó, xong thì chạy lại kịch bản. **Không tự vượt, không đoán
OTP, không chuyển sang trình duyệt khác để né.**

### 5. Xác minh sau cùng
Sau `done`, vẫn phải đối chiếu: kịch bản nên kết thúc bằng
`screenshot` + `read` trạng thái (tiêu đề/trạng thái video trong
Studio), và khi cần thì kiểm tra chéo ở trang Content của kênh.
Chỉ báo "xong" khi ảnh/đọc khớp với yêu cầu (đúng tiêu đề, đúng
chế độ hiển thị/lịch phát, đúng kênh).

## Kịch bản mẫu ĐẦY ĐỦ — upload 1 video lên Studio

Selector của Studio (ytcp-*) có thể thay đổi theo đợt cập nhật của
YouTube — kịch bản dưới là khung chuẩn: luôn có `wait_for` trước
mỗi thao tác và `screenshot`/`read` chốt ở cuối để tự kiểm chứng.

```json
{
  "steps": [
    {"action": "goto", "url": "https://studio.youtube.com/", "timeout_s": 45},
    {"action": "require_no_login_wall"},
    {"action": "wait_for", "selector": "ytcp-app", "timeout_s": 30},
    {"action": "click", "selector": "#upload-icon"},
    {"action": "wait_for", "selector": "ytcp-uploads-dialog", "timeout_s": 20},
    {"action": "upload", "file": "video.mp4", "selector": "ytcp-uploads-dialog input[type=\"file\"]"},
    {"action": "wait_for", "selector": "#textbox[aria-label*=\"title\" i], ytcp-social-suggestions-textbox #textbox", "timeout_s": 30},
    {"action": "fill", "selector": "#textbox[aria-label*=\"title\" i], ytcp-social-suggestions-textbox #textbox", "text": "Tiêu đề video"},
    {"action": "screenshot", "name": "after-upload"},
    {"action": "read", "selector": "ytcp-video-upload-progress .progress-label, .upload-progress-label", "save_as": "upload_status"},
    {"action": "sleep", "seconds": 10},
    {"action": "screenshot", "name": "final"}
  ]
}
```

(Metadata đầy đủ — mô tả, tags, chọn khán giả, đặt lịch/public —
thêm các bước `fill`/`click`/`wait_for` tương ứng sau bước điền
tiêu đề, theo đúng trình tự form của Studio ở thời điểm chạy; kết
thúc luôn bằng `read` trạng thái + `screenshot` xác nhận.)

## Kịch bản kiểm chứng đầu tiên (vô hại — nên chạy trước trên máy thật)

Chỉ mở Studio đúng hồ sơ + chụp màn hình, không đăng/sửa gì:

```json
{
  "steps": [
    {"action": "goto", "url": "https://studio.youtube.com/"},
    {"action": "require_no_login_wall"},
    {"action": "wait_for", "selector": "ytcp-app", "timeout_s": 20},
    {"action": "screenshot", "name": "studio-home"}
  ]
}
```

Kỳ vọng: lệnh `done`, ảnh `studio-<id8>-studio-home.png` trong
`data/screenshots/` cho thấy trang chủ Studio của đúng kênh; nếu
kênh chưa đăng nhập trong Chrome nhúng → `needs_user` (đúng thiết
kế — đăng nhập tay một lần trong cửa sổ nhúng rồi chạy lại).
