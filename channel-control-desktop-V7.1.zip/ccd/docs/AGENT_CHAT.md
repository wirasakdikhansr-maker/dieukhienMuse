# AGENT_CHAT — Hợp đồng chat hai chiều giữa người dùng và từng Muse (V4.6, API 2.6)

Tài liệu này là **hợp đồng dây** cho phía cầu nối (`ccd-bridge-watch`) và
phiên Muse thực thi: người dùng chat trực tiếp với TỪNG tài khoản Muse
ngay trong app, không qua khung chat ngoài. App cam kết đúng các
endpoint/ngữ nghĩa dưới đây; phía cầu nối dựa vào đây để chuyển tin
và đánh thức Muse.

**Bề mặt chat phía người dùng (V4.6 — sửa phạm vi 10:46):** bề mặt
CHÍNH là **panel chi tiết agent ở mục Văn phòng** — bấm robot/bàn là
thấy khối việc + luồng chat đầy đủ + ô soạn ngay tại đó, không nhảy
mục. Trên scene, mỗi bàn có huy hiệu `💬 <số>` khi có tin chưa đọc,
và **bong bóng trích đoạn câu hỏi** trên đầu robot khi agent có lệnh
`needs_user` đang chờ. Mục **Tài khoản Muse** giữ khung chat y hệt
(component dùng chung, cùng dữ liệu) như cửa vào thứ hai khi quản lý
tài khoản. Nút "💬 Hỏi về lệnh này" (bảng lệnh + hàng đợi ở Công
việc) chuyển sang **Văn phòng**, chọn đúng agent phụ trách và gắn
chip ngữ cảnh lệnh vào khung chat ở đó. Mở một luồng ở BẤT KỲ bề
mặt nào cũng đánh dấu tin `agent`/`system` của luồng đó là đã đọc —
huy hiệu ở mọi nơi tự tắt theo.

## 1. Khái niệm

- Mỗi tài khoản Muse (agent) có **một luồng chat riêng** trong app.
- Tin có `direction`:
  - `user` — người dùng gửi cho Muse (trong app).
  - `agent` — Muse trả lời (qua API này).
  - `system` — app tự chèn (hiện tại: khi một lệnh của agent đó kẹt
    `needs_user`, app chèn đúng một tin
    `⏸ Lệnh #<id> đang chờ bạn xử lý: <lý do>` kèm `command_id`).
- Tin có `read_at`: `null` = phía nhận chưa đọc. Hai phía đọc hai
  chiều khác nhau: Muse đọc tin `user`; người dùng đọc tin `agent`
  (+ `system`).
- Một tin có thể gắn `command_id` (ngữ cảnh một lệnh cụ thể).

## 2. Xác thực & phạm vi (CHẶT)

- Mọi lời gọi dùng phiếu kết nối như mọi endpoint khác:
  header `X-Agent-Id: <id>` + `X-Agent-Token: <token riêng của agent>`,
  hoặc token cầu nối chung (phía quản trị/hook).
- **Agent chỉ được chạm luồng của chính mình**: đọc/gửi/đánh dấu đọc
  luồng của agent khác → `403`.
- Agent không tồn tại → `404`. Thiếu/sai token → `401`.

## 3. Endpoints

### 3.1 Đọc tin chưa đọc (long-poll) — đường NHẬN tin của Muse

```
GET /api/agents/{id}/messages?unread=1&wait=25
Headers: X-Agent-Id: {id}   X-Agent-Token: {token}
```

- Trả về **chỉ các tin `direction="user"` chưa đọc** của agent đó,
  cũ → mới.
- `wait` (giây, kẹp 0–50): chưa có tin chưa đọc thì server **treo**
  lời gọi tới khi có tin mới hoặc hết giờ — cùng mẫu long-poll lệnh
  chờ. Khi bị đánh thức, server kiểm tra lại một lần rồi trả kết quả
  (có thể vẫn rỗng nếu hết giờ).

Phản hồi `200`:

```json
{
  "ok": true,
  "unread": 2,
  "messages": [
    {
      "id": 41, "agent_id": 3, "direction": "user",
      "body": "Lệnh này sao chậm vậy?",
      "command_id": "9f87ecb5",
      "created_at": "2026-10-30T10:12:03+07:00", "read_at": null
    },
    {
      "id": 42, "agent_id": 3, "direction": "user",
      "body": "Đổi tiêu đề thành ... giúp anh",
      "command_id": null,
      "created_at": "2026-10-30T10:12:40+07:00", "read_at": null
    }
  ]
}
```

### 3.2 Đọc lịch sử

```
GET /api/agents/{id}/messages?limit=50[&before=<message_id>]
```

Trả `limit` tin gần nhất (trước mốc `before` nếu phân trang), thứ tự
cũ → mới, kèm `unread_counts` theo chiều:
`{"user": n, "agent": n, "system": n}`.

### 3.3 Gửi trả lời

```
POST /api/agents/{id}/messages
Body: {"body": "Đã rõ, em xử lý ngay", "command_id": "9f87ecb5"}
```

- `command_id` không bắt buộc — gắn khi trả lời về một lệnh cụ thể.
- Thành công: `201 {"ok": true, "message": {...}}`.
- Lỗi: body rỗng/toàn khoảng trắng → `400`; JSON hỏng → `400`;
  body dài hơn **4000 ký tự** → `413`; `command_id` không tồn tại
  → `400`.

### 3.4 Đánh dấu đã đọc

```
POST /api/agents/{id}/messages/read
Body: {}                      → đọc hết tin user chưa đọc
Body: {"up_to_id": 42}        → đọc tới tin id 42
```

Trả `200 {"ok": true, "marked": <số tin vừa đánh dấu>}`.
**Quy ước:** Muse đánh dấu đã đọc SAU KHI đã xử lý tin (không đánh
dấu trước rồi quên), để tin chưa xử lý vẫn nằm ở `unread` và được
đánh thức lại ở nhịp sau.

## 4. Ngữ nghĩa ĐÁNH THỨC (cho hook `ccd-bridge-watch`)

- **Tin `user` chưa đọc của một agent = một lý do wake mới**, ngang
  hàng lệnh `waiting_muse`. Payload đánh thức nên kèm:
  `{"kind": "chat", "agent_id": <id>, "unread": <số tin user chưa đọc>}`.
- Cách hook kiểm tra rẻ nhất: với từng agent trong phiếu, gọi
  `GET /api/agents/{id}/messages?unread=1&wait=25` (long-poll) —
  hoặc gộp vào cùng nhịp long-poll lệnh chờ hiện có.
- Người dùng gửi tin trong app → app **tự đánh thức long-poll phía
  server ngay** (`notify_messages_changed`), nên lời gọi `wait`
  đang treo trả về gần như tức thì; hook chỉ cần giữ một lời gọi
  long-poll mở (hoặc quét theo nhịp như hiện tại) là nhận được.
- Hook KHÔNG tự trả lời tin; chỉ đánh thức phiên Muse phụ trách
  agent đó. Một phiên phục vụ nhiều agent thì xử lý lần lượt từng
  luồng.

## 5. Quy trình chuẩn cho Muse thực thi

Khi được đánh thức vì chat (hoặc ở đầu mỗi phiên làm việc):

1. **Đọc** `GET /api/agents/{id}/messages?unread=1` của agent mình.
2. **Trả lời ngắn gọn, đúng việc** qua `POST .../messages`:
   xác nhận đã hiểu, báo trạng thái/kết quả, hoặc hỏi lại đúng
   điểm còn thiếu. Gắn `command_id` khi nói về một lệnh cụ thể.
3. Nếu tin là **yêu cầu làm việc**: thực hiện như một lệnh của
   người dùng (cùng chuẩn chất lượng, cùng kỷ luật báo cáo), rồi
   trả lời kết quả vào luồng. Không lặng lẽ bỏ qua.
4. **Đánh dấu đã đọc** (`POST .../messages/read`) sau khi đã xử lý
   xong từng tin.
5. **Khi kẹt** (đăng nhập/OTP/CAPTCHA/thiếu thông tin): đặt lệnh
   sang `needs_user` NHƯ THƯỜNG (app tự chèn tin hệ thống vào
   luồng) **và** gửi thêm một tin `agent` nói rõ: đang kẹt ở đâu,
   cần người dùng làm gì trong app. TUYỆT ĐỐI không tự vượt
   OTP/CAPTCHA.
6. **Người dùng trả lời trong app** (tin `user` mới, thường gắn
   `command_id` của lệnh đang kẹt): đọc câu trả lời từ luồng,
   `resume` lệnh / chạy tiếp theo đúng nội dung trả lời, rồi báo
   lại kết quả vào luồng.

## 6. Ví dụ một vòng đời đầy đủ

```
[app]     lệnh #9f87ecb5 kẹt đăng nhập → system:
          "⏸ Lệnh #9f87ecb5 đang chờ bạn xử lý: Cần đăng nhập Studio"
[Muse]   POST messages {"body": "Em kẹt ở màn hình đăng nhập Studio
          của hồ sơ KenhHoatHinh. Anh mở mục Hồ sơ → đăng nhập giúp
          em, xong nhắn 'đã xong' tại đây.", "command_id": "9f87ecb5"}
[user]    (trong app) "đã xong"  → direction=user, command_id=9f87ecb5
[hook]    wake phiên Muse với {kind: "chat", agent_id, unread: 1}
[Muse]   GET messages?unread=1 → đọc "đã xong" → resume lệnh,
          chạy tiếp → POST messages/read {up_to_id} → xong việc thì
          POST messages {"body": "Đã chạy tiếp và hoàn thành lệnh
          #9f87ecb5 ...", "command_id": "9f87ecb5"}
```

## 7. Giới hạn & lưu ý

- Trần body **4000 ký tự**/tin (cả hai chiều; phía app cũng chặn
  khi người dùng gửi).
- Lịch sử giữ toàn bộ trong DB của app (bảng `agent_messages`,
  schema 8); xoá agent thì luồng của agent đó bị xoá theo (FK
  CASCADE).
- Độ trễ thực tế phụ thuộc nhịp của hook + phiên Muse có đang
  bận việc dài hay không — hợp đồng này đảm bảo tin KHÔNG bị mất
  (nằm ở `unread` cho tới khi được đánh dấu đọc), không đảm bảo
  trả lời tức thì như chat trực tuyến.

## 8. Đưa một agent MỚI lên "Đang hoạt động" (quy trình phiếu)

Hai lớp trạng thái KHÁC nhau — đừng nhầm (đây là câu hỏi người
dùng hay hỏi nhất: "đã đăng nhập sao vẫn ngoại tuyến"):

- **Đăng nhập muse.ai** = phiên web trong Chrome riêng của tài
  khoản (mục Tài khoản Muse, cột "Muse.ai"). Nó chỉ là phiên
  làm việc của tài khoản — **KHÔNG** làm agent online.
- **Kết nối cầu nối** = có một Muse cầm **PHIẾU KẾT NỐI** của
  agent gọi vào app. Chỉ heartbeat qua cầu nối mới đổi trạng thái
  agent thành "Đang hoạt động". Trong app, nút **🔌 Kết nối** trên
  từng dòng của bảng Tài khoản Muse mở hộp thoại tách bạch hai
  lớp này, kèm lý do ngoại tuyến và nút xuất phiếu của đúng agent.

Quy trình chuẩn để một agent mới online:

1. Trong app (mục Tài khoản Muse): **➕ Thêm tài khoản** cho
   agent (tên + email). App sinh token riêng và TỰ ghi file phiếu
   riêng `phieu-ket-noi-<tên>.txt` vào thư mục phiếu (đường dẫn
   hiện ngay trong mục; đổi được bằng "📁 Đổi thư mục phiếu…").
   Cần ghi lại/xem file: bấm nút **🔌 Kết nối** ở dòng của agent →
   **🎫 Xuất phiếu kết nối** (ghi lại file + mở thư mục phiếu).
2. Đưa **đúng file phiếu của agent đó** cho phía Muse của tài
   khoản đó (cầu nối/hook đọc file này để lấy địa chỉ app +
   `agent_id` + token — mỗi agent một file, không dùng lẫn).
3. Phía Muse bắt đầu gọi vào app bằng phiếu đó (heartbeat /
   nhận lệnh). **Heartbeat đầu tiên về tới app** → cột Trạng thái
   chuyển "Đang hoạt động" (nhịp < 2 phút = online; 2–15 phút =
   "Vừa rời đi"; quá nữa = "Ngoại tuyến"; chưa từng có heartbeat
   = "Chưa kết nối").
4. Kiểm chứng trong app: nút ở cột Kết nối của dòng đó chuyển
   thành **"Đã kết nối ✓"**; bấm vào vẫn xem được chi tiết 2 lớp
   + nhịp heartbeat cuối. Nếu vẫn "Chưa kết nối": phiếu chưa được
   nạp ở phía Muse (bước 2/3) — đăng nhập muse.ai không thay
   được bước này.
