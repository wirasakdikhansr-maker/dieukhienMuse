# CCD V6.0 — GIÁM SÁT CHÉO GIỮA CÁC TÀI KHOẢN CLAUDE

Trạng thái: PHƯƠNG ÁN — chờ chủ kênh duyệt (đề xuất 2026-10-30 23:57).
Mục tiêu: các tài khoản Muse tự kiểm soát lẫn nhau về CÔNG VIỆC, TIẾN ĐỘ và CHẤT LƯỢNG, chủ kênh chỉ xử lý các ca leo thang.

## Nguyên tắc nền

1. Việc kiểm tra là MỘT LOẠI LỆNH trong cùng hệ thống lệnh hiện có (claim/lease 120s/progress/result/needs_user) — không xây hệ thống song song; cầu nối, hook theo agent, phiếu kết nối dùng lại nguyên vẹn.
2. Giám sát viên là một tài khoản Muse thật, chấm việc qua phiên phục vụ riêng của nó. Ưu tiên xử lý trong phiên: CHAT → VIỆC KIỂM TRA → VIỆC MỚI.
3. Phần theo dõi tiến độ do APP tự làm (định kỳ, tất định, không tốn lượt Muse); phần chấm chất lượng mới dùng tới Muse giám sát.
4. Mọi kết luận kiểm tra ghi Nhật ký bất biến; chủ kênh override được mọi kết luận; tắt toàn cục bằng 1 công tắc trong Cài đặt.

## 1. Ma trận giám sát (ai chấm ai)

- Mỗi agent có đúng 1 giám sát viên được gán trong Cài đặt → Giám sát chéo.
- Mặc định vòng chéo theo danh sách agent hiện có (1→2, 2→4, 4→5, 5→6, 6→7, 7→8, 8→1): không ai tự chấm mình, tải chấm chia đều. App CHẶN gán tự giám sát ở tầng dữ liệu.
- Tuỳ chọn "một trưởng nhóm chấm tất cả" nếu chủ kênh muốn.
- Đổi ma trận chỉ áp dụng cho việc kiểm tra sinh ra sau lúc đổi.

## 2. Watchdog tiến độ (app tự chạy, không tốn lượt Muse)

Quét theo nhịp làm mới sẵn có, phát hiện:
- Lệnh running quá N phút không báo progress (mặc định 10 phút) → "nghi treo".
- Lease hết hạn mà không được gia hạn / lệnh chờ claim quá lâu.
- Agent mất heartbeat > 15 phút trong khi đang giữ lệnh.

Mỗi sự kiện: ghi Nhật ký + hiện cảnh báo ở tab Giám sát + sinh việc kiểm tra loại "treo" giao giám sát viên (nó quyết định: nhắc agent, đề xuất thu hồi lệnh, hay leo thang chủ kênh).

## 3. Hàng đợi kiểm tra chất lượng

Sự kiện sinh việc kiểm tra (loại lệnh `review`, gắn với lệnh gốc):
- Lệnh báo **failed** → kiểm tra 100% (bắt buộc).
- Lệnh báo **done** → theo tỷ lệ lấy mẫu cài được (mặc định 100% trong giai đoạn đầu; hạ xuống khi đã tin cậy).
- Sự kiện **treo** từ watchdog.

Gói bằng chứng đính kèm việc kiểm tra: nội dung lệnh gốc + skill/checklist đã gắn, toàn bộ mốc progress, result của người làm, link/file kết quả, đoạn Nhật ký liên quan.
LUẬT CỨNG: lệnh done mà result thiếu bằng chứng (link/file/báo cáo kiểm chứng) → giám sát viên trả "Chưa đạt — thiếu bằng chứng" ngay.

## 4. Cách chấm

- Lệnh có skill đính kèm: app tách các cổng QC của skill thành danh mục chấm Đạt / Chưa đạt / Không áp dụng; giám sát viên điền từng mục + nhận xét bắt buộc khi có mục Chưa đạt.
- Không có skill: bộ câu hỏi chuẩn — đúng yêu cầu lệnh? đủ bằng chứng? đúng kênh/hồ sơ? có lỗi nhìn thấy được trong kết quả?
- Giới hạn thật, nói thẳng: giám sát viên chấm trên GÓI BẰNG CHỨNG + link công khai/file kết quả; nó không dùng chung Chrome profile của người làm nên không thấy được những gì không có trong gói.

## 5. Ba kết luận + vòng làm lại

1. **Đạt** — đóng vòng kiểm tra, ghi điểm cho agent.
2. **Chưa đạt — làm lại** — kèm lỗi cụ thể + việc phải sửa; lệnh gốc quay lại hàng đợi của agent gốc (giữ nguyên toàn bộ lịch sử + ghi chú giám sát đính kèm). Tối đa **2 vòng** làm lại.
3. **Cần chủ kênh quyết định** — chuyển needs_user kèm tóm tắt ngắn gọn (việc gì, tranh chấp ở đâu, giám sát đề xuất gì).

Quá 2 vòng làm lại vẫn chưa đạt → tự động leo thang kết luận 3. Giám sát viên KHÔNG được tự sửa/xoá kết quả của người khác — chỉ chấm và trả việc.

## 6. Điểm chất lượng

Mỗi agent một thẻ điểm theo tuần: % đạt ngay lần đầu, số vòng làm lại trung bình/lệnh, số lần bị watchdog bắt treo, thời gian hoàn thành trung bình, số ca leo thang. Hiện ở tab Giám sát + tóm tắt trong tab Báo cáo.

## 7. Giao diện

- **Tab mới "Giám sát"**: (a) hàng đợi kiểm tra + kết luận gần đây; (b) cảnh báo tiến độ của watchdog kèm nút "Nhắc agent" / "Thu hồi lệnh"; (c) thẻ điểm từng agent + ma trận giám sát xem nhanh.
- **Chi tiết lệnh** thêm mục "Lịch sử kiểm tra": ai chấm, kết luận, ghi chú, số vòng; nút override của chủ kênh: "Bỏ qua kiểm tra" / "Chốt đạt".
- **Chat**: kết luận Chưa đạt / leo thang tự sinh tin nhắn tóm tắt vào ô chat của agent bị chấm (để phiên của nó thấy việc làm lại ngay) và của giám sát viên.
- **Cài đặt → Giám sát chéo**: công tắc tổng, ngưỡng treo (phút), tỷ lệ lấy mẫu done (%), số vòng làm lại tối đa, ma trận gán giám sát.

## 8. Dữ liệu / API

- Schema 8 → **9**: bảng `reviews` (id, command_id, supervisor_agent_id, worker_agent_id, trigger, checklist, verdict, notes, round, thời gian) + trường bổ sung trên lệnh gốc (review_round, last_verdict).
- API 2.6 → **2.7**: việc kiểm tra chạy qua endpoints lệnh hiện có (loại `review`); thêm `POST /api/commands/<id>/verdict`, `GET /api/agents/<id>/scorecard`. Phiếu kết nối không đổi; prompt các phiên phục vụ bổ sung mục xử lý việc kiểm tra (ưu tiên sau chat).

## 9. Lộ trình trong bản V6.0

- **Giai đoạn 1 — xương sống:** schema/API, ma trận + chống tự chấm, watchdog, hàng đợi kiểm tra, 3 kết luận + vòng làm lại có trần, tab Giám sát khối (a)(b), chi tiết lệnh có lịch sử kiểm tra, Cài đặt.
- **Giai đoạn 2 — chất lượng sâu:** checklist chấm từ skill, thẻ điểm + Báo cáo, tin nhắn chat tự động, override của chủ kênh.
- Hai giai đoạn trong cùng một bản V6.0, kiểm chứng riêng từng giai đoạn trước khi gộp.

## 10. Kiểm chứng / nghiệm thu

- Test tự động: ma trận không tự chấm; sinh việc kiểm tra đúng sự kiện + đúng tỷ lệ mẫu (hạt giống cố định); vòng làm lại đúng trần → leo thang; watchdog bắt treo bằng đồng hồ giả; verdict API bằng phiếu của từng agent; không regress toàn bộ hành vi cũ.
- Render tab Giám sát + chi tiết lệnh có lịch sử kiểm tra ở 3 cỡ cửa sổ; cổng giải nén như mọi bản.
- Máy thật (chủ kênh nghiệm thu): 1 lệnh thật chạy trọn vòng làm → chấm → Đạt; 1 lệnh cố tình báo done thiếu bằng chứng → bị trả làm lại.

## 11. Rủi ro & chốt chặn

- Tự chấm lỗi mình → app chặn ở tầng dữ liệu.
- Vòng lặp làm lại vô hạn → trần 2 vòng + leo thang người thật.
- Tốn lượt Muse của giám sát viên → lấy mẫu % tuỳ chỉnh + watchdog miễn phí gánh phần tiến độ.
- Chấm hình thức (đạt khống) → checklist bắt buộc từng mục + nhận xét khi Chưa đạt + chủ kênh xem lại/override bất cứ lúc nào; thẻ điểm lộ % đạt bất thường.
