# Channel Control Desktop — Trung tâm điều khiển kênh YouTube (bản desktop)

Phần mềm desktop riêng (Python + PySide6) chạy trên Windows — **không phải web**.
App là "buồng lái": mỗi tài khoản Google là một **hồ sơ** có trình duyệt Chrome
riêng; Muse (AI) làm việc với kênh qua đúng các trình duyệt hồ sơ đó, còn bạn
theo dõi và điều khiển mọi thứ từ app.

## Ý tưởng chính

- **Mỗi hồ sơ = một tài khoản Google = một thư mục Chrome user-data riêng**
  (`data/profiles/<slug>/`) và **một cổng remote-debugging riêng**. Nhờ vậy mỗi
  tài khoản giữ phiên đăng nhập riêng, không bao giờ lẫn phiên của nhau.
- App mở Chrome của hồ sơ bằng cổng debug đó và giao tiếp qua **CDP**
  (Chrome DevTools Protocol): điều hướng trang, chạy JavaScript, chụp hình,
  gửi chuột/phím thật.
- Slug và cổng được **suy ra tất định từ nhãn hồ sơ**:
  cổng = `19400 + crc32(slug) % 500` (lưu cố định trong DB khi tạo hồ sơ).
  Muse khi cần làm việc với một hồ sơ cũng mở Chrome bằng đúng thư mục
  user-data và cổng này — cùng một trình duyệt mà bạn thấy trong app.

## Màn hình trực tiếp (Live) là gì?

Khung hình lớn bên phải **là luồng hình trực tiếp của chính cửa sổ Chrome thật**
của hồ sơ đang chọn (lấy qua CDP `Page.captureScreenshot`), nhịp mục tiêu
**~5 khung hình/giây** khi cửa sổ app đang được focus và tự giảm xuống ~1 fps
khi bạn không nhìn (để nhẹ máy). Phía trên khung có nhãn hồ sơ và URL trang
hiện tại. Đây là cách bạn xem Muse làm việc trong trình duyệt theo thời gian
thực — cùng một cửa sổ Chrome đó, nút **"Đưa cửa sổ Chrome lên trước"** sẽ mang
ra ngoài màn hình khi bạn muốn xem/điều khiển trực tiếp ở kích thước thật.

Hai chế độ xem:

- **Xem trực tiếp** (mặc định): chỉ xem, thao tác chuột/phím không đi vào Chrome.
- **Điều khiển**: click chuột, lăn chuột và gõ phím trong khung live được
  chuyển tiếp thành thao tác THẬT vào Chrome qua CDP
  (`Input.dispatchMouseEvent` / `Input.dispatchKeyEvent`) — bạn có thể tự tay
  vận hành trình duyệt ngay trong app (ví dụ: tự đăng nhập Google cho hồ sơ).

## Tính năng v1

- **Hồ sơ**: Thêm hồ sơ (nhãn + Gmail + ghi chú), Tạm dừng/Bật hồ sơ.
- **Cây hồ sơ → kênh** ở cột trái; chọn kênh con vẫn thao tác trên hồ sơ cha.
- **Mở trình duyệt hồ sơ**: mở Chrome đúng user-data-dir + cổng của hồ sơ
  (đang chạy rồi thì dùng lại). Lần đầu mỗi hồ sơ cần bạn **tự đăng nhập Google
  một lần** trong cửa sổ Chrome đó — phiên được Chrome giữ lại cho các lần sau.
- **Quét kênh**: qua CDP, app hợp nhất **3 nguồn** để lấy đủ toàn bộ kênh
  của tài khoản: endpoint nội bộ `/youtubei/v1/account/account_menu`,
  **panel Accounts** (avatar → Switch account, có cuộn khi nhiều kênh) và
  trang **View all channels** (`youtube.com/channel_switcher`) — vì menu
  rút gọn có thể thiếu kênh. **Chỉ lấy kênh THƯƠNG HIỆU**: kênh chính cá
  nhân (kênh trùng tên tài khoản Google, đọc từ panel Accounts) được bỏ
  qua và ghi rõ vào nhật ký. Kết quả (tên, handle, URL/ID, số
  subscribers, số video) lưu vào DB, khử trùng theo channel ID.
  Nếu hồ sơ **chưa đăng nhập**, app đưa cửa sổ Chrome tới trang đăng nhập
  Google, ghi nhật ký **"chờ đăng nhập"** và dừng — bạn đăng nhập trong cửa sổ
  đó rồi bấm Quét kênh lại.
- **Bảng kênh** của hồ sơ: tên, handle, subs, số video, chủ đề, lần quét cuối.
  (Cột "Chủ đề" hiện để trống — điền tay ở bản sau; quét không ghi đè chủ đề cũ.)
- **Nhật ký**: mọi thao tác (thêm hồ sơ, mở Chrome, quét, lỗi...) được ghi
  kèm thời gian vào SQLite trong thư mục dữ liệu, mở lại app vẫn còn.
- **Đóng app không tắt Chrome** (mặc định) — các cửa sổ Chrome của hồ sơ vẫn
  sống để Muse tiếp tục làm việc. Muốn đóng app là tắt luôn các Chrome do app
  mở, sửa `data/settings.json`: `"keep_chrome_open_on_exit": false`.

## Cài đặt & chạy (Windows)

Yêu cầu: Windows 10/11, **Python 3.11+** (khi cài nhớ tick *Add python.exe to
PATH*), **Google Chrome** bản chính thức.

```bat
pip install -r requirements.txt
run.bat
```

Hoặc chạy trực tiếp: `python run.py`

Lần chạy đầu, app tạo thư mục `data\` (DB SQLite, `profiles\`, `snapshots\`,
`settings.json`) ngay trong thư mục dự án. Muốn để dữ liệu chỗ khác, đặt biến
môi trường `CCD_DATA_DIR`. Muốn ép đường dẫn Chrome, đặt `CCD_CHROME_PATH`.

## Cấu trúc thư mục

```
channel-control-desktop/
├── run.py / run.bat        # điểm chạy
├── requirements.txt
├── app/
│   ├── config.py           # đường dẫn, slug/cổng tất định, tìm Chrome, settings
│   ├── store.py            # SQLite: profiles / channels / journal
│   ├── parser.py           # parse account_menu JSON + snapshot HTML -> kênh
│   ├── cdp.py              # client CDP tối giản (websocket)
│   ├── chrome_manager.py   # mở Chrome theo hồ sơ (detached), kết nối CDP
│   ├── scanner.py          # luồng quét kênh qua CDP
│   ├── main.py             # bootstrap QApplication
│   └── ui/
│       ├── main_window.py  # cửa sổ chính + worker quét
│       ├── live_view.py    # widget live + ánh xạ phím Qt -> CDP
│       ├── live_worker.py  # luồng trực tiếp ~5fps + chuyển tiếp thao tác
│       └── dialogs.py      # hộp thoại thêm hồ sơ
├── tests/                  # pytest cho store + parser (không cần Qt)
└── data/                   # dữ liệu chạy (tự tạo)
```

## Kiểm thử

```
python -m pytest
```

62 test: kho dữ liệu (hồ sơ, slug/cổng tất định, upsert kênh, nhật ký),
parser (snapshot HTML mẫu trong `tests/fixtures/channel_list_sample.html`),
Agent API V2, và các phần V3 — bảng lệnh dùng chung + lệnh của UI, logic
lịch tự động (đến hạn/chưa đến hạn), định hình kết quả kiểm tra bằng dữ
liệu giả (stub), bộ thực thi lệnh tại chỗ, và endpoint báo cáo kết quả
của Muse (xem mục V3 bên dưới).

## Giới hạn & phần CHƯA kiểm chứng trên Windows (nói thẳng)

- App được viết và kiểm thử tự động trong môi trường Linux: toàn bộ module
  biên dịch sạch, 62/62 pytest đạt, cửa sổ chính dựng thành công ở chế độ
  offscreen (kèm kiểm tra ánh xạ phím và quy đổi toạ độ click của live view).
- **Chưa chạy thật trên Windows với Chrome thật trong môi trường kiểm thử
  này** — các phần sau cần bạn chạy thử lần đầu trên máy Windows và đối chiếu:
  mở Chrome bằng cổng debug, luồng live ~5 fps, chuyển tiếp chuột/phím, và
  quét kênh trên tài khoản thật. Nếu Chrome của một hồ sơ đang mở sẵn mà
  **không** bật cổng debug (mở tay ngoài app), app không gắn vào được — hãy
  đóng cửa sổ Chrome đó rồi bấm "Mở trình duyệt hồ sơ" để app mở lại đúng cách.
- Quét kênh dựa vào endpoint nội bộ `account_menu` của YouTube (không phải API
  công khai) — nếu YouTube đổi cấu trúc, quét sẽ báo lỗi và app lưu snapshot
  thô vào `data/snapshots/` để gỡ lỗi; số video từng kênh là best-effort
  (lấy không được thì để trống, không làm hỏng lượt quét).
- Mật khẩu Google **không bao giờ** được app lưu hay tự nhập — đăng nhập luôn
  do bạn tự làm trong cửa sổ Chrome của hồ sơ.

## V2 — Cầu nối cho Muse (Tailscale)

Từ V2, app chạy thêm một **Agent API** nhỏ (HTTP, chỉ thư viện chuẩn) trong
luồng nền. Muse ở phía bên kia mạng **Tailscale** gửi lệnh và file tới API
này; app thực thi bằng chính các module của nó (mở Chrome theo hồ sơ, quét
kênh, điều hướng CDP) và ghi nhật ký mọi thao tác với tiền tố `[API]`.

Cách nối, từng bước:

1. **Cài Tailscale trên máy Windows này** (https://tailscale.com/download) và
   **đăng nhập bằng cùng tài khoản đã duyệt thiết bị của Muse** — để máy
   này và Muse nhìn thấy nhau trong cùng một tailnet.
2. **Chạy app** như bình thường (`run.bat`). Agent API tự khởi động cùng app
   trên cổng **19500** (đổi cổng bằng `"agent_port"` trong
   `data/settings.json`; tắt hẳn bằng `"agent_enabled": false`).
3. **Lấy token + địa chỉ máy**: token riêng của bản cài nằm trong
   `data/settings.json` ở khóa **`agent_token`** (app tự sinh ở lần chạy đầu
   và lưu lại — cũng in ra cửa sổ console khi app khởi động). Địa chỉ của máy
   này trên tailnet là **tên máy Tailscale** (dạng `ten-may`) hoặc **IP
   Tailscale** (dạng `100.x.y.z`) — xem trong ứng dụng Tailscale.
4. **Muse kết nối** tới `http://<tên-máy-hoặc-IP-Tailscale>:19500`, gửi kèm
   header `X-Agent-Token: <agent_token>` trong mọi request (trừ kiểm tra
   sống `GET /api/health`). Client mẫu phía Muse: `tools/muse_client.py`.

Việc Muse làm được qua cầu nối: xem danh sách hồ sơ + kênh + trạng thái
phiên, ra lệnh **mở Chrome của một hồ sơ**, **quét kênh**, **điều hướng
trang qua CDP**, **gửi file** vào `data/inbox/` (kèm kiểm tra SHA-256), xếp
hàng lệnh bất đồng bộ (`open_browser` / `scan` / `cdp_navigate`) và theo dõi
trạng thái lệnh, đọc nhật ký của app.

**Tường lửa Windows:** lần đầu app lắng nghe mạng, Windows Firewall có thể
hỏi quyền — hãy **Allow** cho ứng dụng/Python trên mạng Private/Tailscale,
nếu không Muse sẽ không nối vào được dù Tailscale đã thông.

**Bảo mật (đọc kỹ):** token chính là chìa khoá của cầu nối — ai có token +
đường mạng tới cổng 19500 đều điều khiển được app. API bind trên mọi giao
diện mạng (`0.0.0.0`) nên **cả hai lớp đều bắt buộc**: token đúng **và** chỉ
đi qua Tailscale (đừng mở/port-forward cổng 19500 ra Internet, đừng chia sẻ
`agent_token`). Muốn thu hồi quyền: đổi/xoá `agent_token` trong
`data/settings.json` rồi khởi động lại app — token mới sẽ được sinh.

## V3 — Trung tâm lệnh, tự động hoá, kiểm tra & nhúng trình duyệt thật

V3 thêm một thanh điều hướng bên trái cửa sổ chính với 4 mục: **Hồ sơ**
(màn hình chính vốn có), **Lệnh công việc**, **Tự động**, **Kiểm tra**. Giao
diện giữ nguyên theme "Mission Control".

### 1. Nhúng trình duyệt thật vào app (Windows)

Ở panel LIVE (mục Hồ sơ) có chuyển đổi **[Trình duyệt nhúng | Luồng trực
tiếp]**. Khi Chrome của hồ sơ đang chọn đang mở, bấm **Trình duyệt nhúng**
(hoặc **Nhúng lại**): app tìm đúng cửa sổ Chrome của hồ sơ đó (đối chiếu
tiến trình đang nghe trên cổng debug riêng của hồ sơ) rồi gắn cửa sổ thật
vào trong app bằng Win32 `SetParent` (`app/docking.py`) — bạn thao tác
trực tiếp trên Chrome thật ngay trong app, không qua ảnh chụp. **Gỡ
nhúng** trả cửa sổ về trạng thái bình thường (style/vị trí cũ được khôi
phục); app tự gỡ nhúng khi đổi hồ sơ, khi Chrome bị đóng và trước khi
thoát. Không bao giờ ép tắt Chrome.

> **Nói thẳng về giới hạn:** cơ chế nhúng phụ thuộc vào hành vi của
> Windows/Chrome và **không kiểm chứng được từ môi trường phát triển
> Linux** — trên Windows thật, nếu lần nhúng đầu không thành (Chrome vừa
> đổi cửa sổ sau đăng nhập, cửa sổ bị thu nhỏ kiểu lạ...), hãy bấm
> **Nhúng lại**. Mọi lỗi nhúng đều tự rơi về **Luồng trực tiếp** (luồng ảnh
> CDP + chế độ Xem/Điều khiển vốn có) — hai chế độ xem luôn song song,
> chuyển qua lại tuỳ ý. Ngoài Windows, nút nhúng chỉ ghi nhật ký giải
> thích và giữ Luồng trực tiếp.

### 2. Trung tâm Lệnh công việc

Mục **Lệnh công việc**: tạo lệnh ngay trong app — chọn loại lệnh (Mở
trình duyệt / Quét kênh / Kiểm tra kênh / Tối ưu kênh / Tải video lên /
Lệnh tự do), hồ sơ đích (+ kênh khi liên quan), nội dung yêu cầu, hẹn giờ
tuỳ chọn. Lệnh lưu vào bảng `commands` trong SQLite (trạng thái
`queued | running | waiting_muse | done | failed`, đủ mốc thời gian +
kết quả).

- Ba loại đầu app **tự chạy tại máy** (`app/executor.py`, bộ chạy nền rà
  bảng lệnh mỗi ~1,5 giây, tôn trọng giờ hẹn).
- Ba loại sau (cần thao tác trình duyệt thật) nằm ở **`waiting_muse`** chờ
  Muse: Muse đọc qua `GET /api/commands` (nay liệt kê **cả lệnh tạo
  trong UI** lẫn lệnh qua API — cùng một bảng) và báo cáo tiến độ/kết quả
  bằng `POST /api/commands/{id}/result` với body `{status, result}` —
  danh sách trong app tự cập nhật (làm mới mỗi 4 giây).

### 3. Tự động

Mục **Tự động**: quy tắc dạng *hành động (Quét kênh / Kiểm tra kênh / Mở
trình duyệt) × hồ sơ đích hoặc tất cả × lịch (hằng ngày lúc HH:MM hoặc
mỗi N giờ) × bật/tắt*, hiển thị lần chạy cuối + lần chạy kế. Bộ máy
`app/automation.py` kiểm tra mỗi 30 giây và tạo lệnh qua đúng đường lệnh
dùng chung (nhật ký có tiền tố `[Tự động]`). Hai quy tắc mặc định được
gieo sẵn ở trạng thái **tắt**: quét kênh hằng ngày 08:00 và kiểm tra sức
khoẻ mỗi 6 giờ — bật lên khi bạn muốn dùng. Kèm công tắc **"Tự mở trình
duyệt các hồ sơ khi mở app"** (lưu trong `data/settings.json`, khóa
`auto_open_browsers_on_start`).

### 4. Kiểm tra

Mục **Kiểm tra**: **Kiểm tra tất cả** hoặc từng hồ sơ (`app/checks.py`).
Mỗi hồ sơ một thẻ checklist có mốc thời gian: Chrome có đang chạy không,
cổng điều khiển CDP nối được không, đã đăng nhập Google/YouTube chưa
(thăm dò phiên qua scanner), kênh có truy cập được không, số liệu cập
nhật lần cuối khi nào, và có video nào đang ở trạng thái Scheduled
không (đọc từ bảng `videos` trong kho — mục này báo "chưa rõ" một cách
trung thực khi chưa có dữ liệu từng video). Kết quả hiển thị ✓ / ✗ / –
theo từng mục, được lưu vào bảng `profile_checks`, ghi tóm tắt vào nhật
ký, và Muse đọc lại được qua `GET /api/profiles` (trường `last_check`
của mỗi hồ sơ).

Kiểm thử V3: toàn bộ 62 test đạt (30 test cũ giữ nguyên + 32 test mới),
mọi module biên dịch sạch, cửa sổ chính dựng thành công ở chế độ
offscreen với đủ 4 mục (ảnh xem trước `ui_preview.png` chụp ở mục Lệnh
công việc với dữ liệu demo).

## V3.1 — Chuẩn hoá giao diện + xử lý (gói tối ưu một lượt)

### A. Giao diện

- **Điều hướng 7 mục** ở thanh trái: Tổng quan / Hồ sơ / Lệnh công việc /
  Tự động / Kiểm tra / Nhật ký / Cài đặt; thanh trạng thái cố định ở đáy
  (số hồ sơ có CDP sống · trạng thái cầu nối Muse gồm cổng + lần gọi
  gần nhất · quy tắc tự động sắp tới hạn). Thanh điều hướng **thu gọn
  thành dải icon** được (nút ở chân thanh), trạng thái lưu trong cài đặt.
- **Tổng quan** (mục chủ mới): 4 thẻ KPI (tổng kênh, tổng subscribers,
  video đang Scheduled trong kho, lệnh đang chờ/chạy) + dòng hoạt động
  gần nhất (15 mục nhật ký) + banner lỗi kèm nút Thử lại khi đọc dữ
  liệu hỏng.
- **Bảng dữ liệu chuẩn hoá**: sắp xếp theo cột, ô tìm/lọc; riêng bảng
  lệnh có thêm cột **Thao tác** với nút **Huỷ** / **Thử lại** từng dòng
  và chip trạng thái có màu (kèm trạng thái mới "Bị gián đoạn").
- **Khung xem trực tiếp 3 tab**: Trình duyệt nhúng | Luồng trực tiếp |
  Ảnh chụp; nút **Lưu ảnh** chụp khung hình hiện tại vào
  `data/screenshots/` kèm mốc thời gian; tab luồng hiển thị **fps thật
  + độ phân giải khung hình**.
- **Khay hệ thống** (hiện/ẩn cửa sổ, Quét tất cả, Thoát) + **thông báo
  toast** trong app khi lệnh chạy xong/thất bại và khi quét xong.
- **Cài đặt dạng 5 tab con**: Chung | Trình duyệt và Nhúng | Cầu nối
  Muse | Dữ liệu | Giao diện — cổng + token Muse (che, có nút Hiện và
  Sinh token mới), chuyển đổi "Chỉ nghe localhost", đường dẫn Chrome
  (tự dò + ghi đè tay), nhịp fps luồng, thư mục dữ liệu, kiểm tra toàn
  vẹn kho, 4 nút xuất JSON/CSV (kênh + nhật ký), mặc định hiển thị panel.
- Trạng thái rỗng / banner lỗi được làm gọn gàng, thống nhất toàn app.

### Bố cục ưu tiên trình duyệt (theo phản hồi từ bản chạy Windows thật)

- **Chế độ toàn màn hình trình duyệt** (nút "Toàn màn hình" hoặc F11,
  Esc để thoát): ẩn thanh điều hướng, cột hồ sơ, thanh đầu và dock
  dưới — chỉ còn một thanh mỏng (tên hồ sơ + nút Thoát), trình duyệt
  chiếm ~95% cửa sổ.
- **Dock dưới dạng tab thu gọn được** [Kênh | Nhật ký | Hàng đợi lệnh]:
  thu gọn = thanh mỏng ~28px, mở rộng mặc định tối đa ~220px để trình
  duyệt được phần lớn chiều cao; cột hồ sơ ẩn/hiện bằng nút ở thanh đầu;
  trạng thái hiển thị của từng phần được nhớ trong cài đặt; lần chạy
  đầu khi kho chưa có kênh nào, dock tự thu gọn.
- **Cửa sổ Chrome nhúng được dọn dẹp**: khi gắn vào app, app đổi style
  cửa sổ Chrome (bỏ WS_CAPTION / WS_SYSMENU / WS_MINIMIZEBOX /
  WS_MAXIMIZEBOX, đặt WS_CHILD) nên các nút thu/phóng/đóng của chính
  Chrome không còn hiện bên trong app nữa; gỡ nhúng khôi phục style
  gốc. Mọi lỗi ở bước này đều lùi êm về chế độ luồng như trước.
- **Một thanh công cụ trình duyệt duy nhất**: LIVE + hồ sơ + URL + xem
  fps + chuyển Xem/Điều khiển + Nhúng/Gỡ nhúng + Lưu ảnh gộp vào một
  hàng mỏng; hành động phụ nằm trong menu "⋯". Thanh công cụ tự đổi
  theo ngữ cảnh: đang NHÚNG thì ẩn các nút chỉ-dành-cho-luồng (Xem/
  Điều khiển, fps, Đưa lên trước — lúc này thao tác là native trong
  cửa sổ nhúng), đang LUỒNG thì ẩn các nút chỉ-dành-cho-nhúng. Đoạn
  hướng dẫn dài về nhúng chuyển thành tooltip.
- Khi hồ sơ đang chọn có 0 kênh, tab Kênh hiện **một dòng trạng thái
  rỗng** thay vì bảng trống.

### Bản vá quét kênh 403 (từ bản chạy Windows thật)

Chrome bản mới từ chối bắt tay WebSocket CDP nếu thiếu cờ
`--remote-allow-origins`. App nay **luôn mở Chrome kèm
`--remote-allow-origins=*`** (cổng debug chỉ nghe localhost nên chấp
nhận được). Mục Kiểm tra có thêm **probe "Bắt tay CDP"** cho từng hồ
sơ; khi gặp 403/origin, cả lỗi quét lẫn mục kiểm tra đều hiển thị câu
tiếng Việt dễ hiểu — "Chrome của hồ sơ này đang chạy mà không có cờ
cho phép điều khiển — hãy đóng hẳn Chrome của hồ sơ (kể cả khay hệ
thống) rồi bấm Mở trình duyệt lại" — thay vì đoạn lỗi 403 thô.

### C. Xử lý

- **Bộ máy hàng đợi việc** (`app/job_engine.py`): mọi lần quét, kiểm
  tra, chạy lệnh và kích hoạt quy tắc tự động đều qua MỘT hàng đợi
  nền — tuần tự theo từng hồ sơ (không bao giờ hai việc trình duyệt
  cùng lúc trên một hồ sơ), ưu tiên lệnh tay > việc tự động, token
  huỷ, tự thử lại tối đa 2 lần (backoff) cho lỗi CDP/kết nối thoáng
  qua. Giao diện ngoài và API cho Muse không thay đổi.
- **CDP cứng cáp hơn** (`app/cdp.py`): tự nối lại kèm backoff khi
  socket rớt (chỉ nối lại với lỗi rớt kết nối — timeout thì không),
  timeout mặc định cho mỗi lệnh gọi, và **chất lượng ảnh chụp thích
  ứng**: khung hình chậm → tự hạ chất lượng JPEG/bậc nhịp, nhanh lại
  → nâng lên; luồng trực tiếp dùng chính bộ điều tiết này.
- **Watchdog nhúng** (`app/docking.py`): bộ đếm giờ phát hiện cửa sổ
  Chrome bị huỷ/tạo lại và tự nhúng lại; app bật nhận thức DPI theo
  màn hình ngay khi khởi động; mọi lỗi đều lùi êm về chế độ luồng.
- **An toàn dữ liệu** (`app/store.py`): SQLite bật **WAL** +
  `busy_timeout`; **phiên bản schema + bộ di trú idempotent** (DB cũ
  của V3 mở lên được nâng cấp êm, chạy lại di trú không đổi gì);
  kiểm tra toàn vẹn khi khởi động (kết quả nằm ở mục Kiểm tra);
  **khôi phục sự cố**: lệnh kẹt ở "Đang chạy" từ lần chạy trước được
  đánh dấu **"Bị gián đoạn"** khi mở app và Thử lại được từ mục Lệnh.
- **Tự chẩn đoán + log**: log file xoay vòng ở `data/logs/ccd.log`
  (1MB × 5); chẩn đoán khởi động (có Chrome không? cổng Agent còn
  trống? có token? thư mục dữ liệu ghi được? kho còn toàn vẹn?) hiển
  thị thành các dòng đầu tiên của mục Kiểm tra; mục **Nhật ký** có
  thêm trình xem đuôi file log trong app (nút Làm mới).

**Bản vá V3.1 (sập app khi bấm "Quét kênh" trên Windows thật)**: bản
đầu của V3.1 chết ngay khi quét xong với dòng
`QThread: Destroyed while thread '' is still running`. Nguyên nhân:
``_stop_live_worker`` cũ gọi ``wait(2500)`` rồi bỏ qua kết quả và thả
tham chiếu cuối tới worker luồng trực tiếp — trong khi worker thường
đang kẹt trong một lệnh CDP dài (timeout 15s) nên wait() quá giờ, và
QThread (không parent) bị huỷ giữa lúc còn chạy. Nay worker được
parent vào cửa sổ chính, việc dừng chờ có điều kiện: xong thì
deleteLater, chưa xong thì worker vào danh sách giữ tham chiếu riêng
và chỉ được dọn khi tín hiệu ``finished`` về thật; khi đóng app mà
vẫn còn worker chạy, quyền sở hữu được chuyển cho QApplication giữ
tới hết tiến trình. Hai cảnh báo console đi kèm cũng đã xử lý: không
còn tự đặt DPI awareness bằng shcore trước Qt (Qt 6 tự đặt
PER_MONITOR_AWARE_V2; đặt trước khiến Qt bị *Access is denied*), và
font của biểu tượng khay được dựng tường minh thay vì sao chép font
của painter rồi đặt lại cỡ (đường sao-chép đó phát cảnh báo
``QFont::setPointSize: Point size <= 0 (-1)`` trên Windows). Kiểm
thử hồi quy mới (`tests/test_thread_ownership.py`): quét qua đúng
handler của nút trong lúc worker cũ kẹt trong lệnh CDP + ép
gc.collect() vẫn hoàn thành sạch; thả mọi tham chiếu tới một việc
JobEngine đang chạy, việc vẫn xong; FuncWorker dự phòng của mục
Kiểm tra được dọn sau khi finished. Tổng kiểm thử sau bản vá:
**118 test đạt**.

Kiểm thử V3.1: **115 test đạt** (62 test cũ giữ nguyên + 53 test mới:
hàng đợi việc — tuần tự theo hồ sơ/huỷ/thử lại bằng hàm giả; di trú
idempotent + nâng cấp DB cũ + WAL + khôi phục lệnh; định hình chẩn
đoán; CDP — phân loại 403, chất lượng thích ứng, tự nối lại bằng
websocket giả; cờ mở Chrome `--remote-allow-origins=*`; watchdog bằng
dock giả; khói giao diện offscreen dựng cửa sổ chính, chuyển đủ 7 mục,
thử chế độ toàn màn hình + thu/mở dock + thu thanh điều hướng). Ảnh
xem trước: `ui_preview_overview.png`, `ui_preview_commands.png`,
`ui_preview_settings.png`, `ui_preview_browser.png` (mục Hồ sơ, dock
dưới thu gọn, vùng trình duyệt tối đa) — chụp offscreen với dữ liệu
demo.

**Giới hạn trung thực**: hành vi nhúng cửa sổ, khay hệ thống và chế
độ toàn màn hình trên **Windows thật** vẫn không kiểm chứng được từ
sandbox Linux này (chỉ kiểm chứng được logic bằng hàm giả + dựng
giao diện offscreen); cần chạy thử trên máy Windows của bạn để xác
nhận trực quan.

## V3.2 — Một Gmail một hồ sơ + cookies đăng nhập + iconbar + theo dõi tiến độ

### 1. Mỗi Gmail = một hồ sơ riêng, tự lưu cookies
- Tạo hồ sơ với Gmail đã thuộc hồ sơ khác sẽ bị **chặn** (kể cả qua Agent API: HTTP 409) — không bao giờ có hai hồ sơ dùng chung một Gmail.
- Mỗi hồ sơ có **kho cookies riêng** tại `data/cookies/<slug>.json`. Sau mỗi lần quét thành công, app **tự xuất cookies** (chỉ domain Google/YouTube) về kho; khi quét mà chưa đăng nhập, app **tự nạp cookies đã lưu** vào Chrome và kiểm tra lại trước khi yêu cầu đăng nhập tay.
- Giá trị cookie là bí mật phiên: không bao giờ ghi vào nhật ký — nhật ký chỉ ghi số lượng và TÊN cookie xác thực (SID, HSID, ...).

### 2. Đăng nhập bằng cookies có sẵn
- Trong app: chọn hồ sơ → **🍪 Nhập cookies…** (file JSON kiểu EditThisCookie / "Get cookies.txt LOCALLY", hoặc Netscape `cookies.txt`) → app lưu vào kho của hồ sơ và tự nạp ngay nếu Chrome đang chạy; chưa chạy thì tự nạp ở lần quét sau.
- Qua Agent API: `POST /api/profiles/{slug}/cookies` (body = nội dung file, header `X-File-Name`), `GET .../cookies` (trạng thái kho), `POST .../cookies/apply` (nạp vào Chrome đang chạy), `POST .../cookies/export` (xuất từ Chrome về kho). Client: `tools/muse_client.py cookies <slug> status|import|apply|export`.

### 3. Iconbar góc trái-trên + tối ưu giao diện
- Cột ngoài cùng bên trái, chạy suốt chiều cao từ góc trái-trên: logo, 7 nút điều hướng chỉ-icon (rê chuột hiện tên), thao tác nhanh 🔄 Quét tất cả / ⛶ Toàn màn hình, chấm trạng thái cầu nối Muse (xanh = đang nghe), nút » mở rộng hiện nhãn chữ. Header được gỡ hai nút đã chuyển xuống iconbar nên chỉ còn một hàng gọn.
- Cột hồ sơ có thêm dòng trạng thái cookies + hai nút Nhập/Nạp cookies ngay dưới các nút thao tác hồ sơ.

### 4. Theo dõi tiến độ công việc của Muse
- Mọi lệnh có **% tiến độ + mô tả bước hiện tại**: panel **Lệnh công việc** có cột "Tiến độ" (thanh khối + % + bước); màn **Tổng quan** có thẻ **"Muse đang làm việc"** liệt kê các lệnh đang chờ/đang chạy kèm thanh tiến độ, tự làm mới 15 giây.
- Lệnh app tự chạy (quét/kiểm tra/mở trình duyệt) tự cập nhật tiến độ theo giai đoạn. Lệnh chờ Muse: Muse báo tiến độ qua `POST /api/commands/{id}/progress` `{"progress": 0-100, "step": "..."}` — client: `tools/muse_client.py progress <id> <percent> <bước...>`; đổi bước mới ghi một dòng nhật ký ⏳. Tạo hồ sơ từ xa: `POST /api/profiles` / `muse_client.py add-profile <nhãn> <gmail>`.

### 5. Trình duyệt chạy là nhúng thẳng vào giao diện (không mở ngoài)
- Cài đặt **"Luôn nhúng trình duyệt vào app khi chạy"** (tab Trình duyệt và Nhúng, mặc định BẬT): hễ Chrome của hồ sơ đang chọn đang chạy, app tự nhúng vào khung xem trong tối đa ~0,6 giây — tab mặc định cũng là "Trình duyệt nhúng". Áp dụng cho mọi đường mở: nút Mở trình duyệt, Quét kênh, lệnh nền, tự mở khi khởi động.
- Đổi hồ sơ: app tự gỡ nhúng hồ sơ cũ, **thu nhỏ cửa sổ cũ về taskbar** (không bật ra ngoài màn hình) rồi nhúng cửa sổ của hồ sơ mới.
- Muốn gỡ ra cửa sổ riêng vẫn được: bấm **Gỡ nhúng** — app tôn trọng lựa chọn đó (không tự giành lại) cho tới khi đổi hồ sơ hoặc bấm Nhúng lại. Tắt hẳn tính năng trong Cài đặt thì quay về Luồng trực tiếp + nhúng thủ công như trước.

## V3.3 — Tài khoản Muse: thêm hàng loạt, token riêng, phân công kênh

### 1. Tài khoản Muse là thực thể riêng (DB v4)
- Mục mới **🤖 Tài khoản Muse** trên iconbar: mỗi tài khoản Muse có tên, email, **token cầu nối riêng**, trạng thái sống và phân công kênh. Bảng hiển thị: trạng thái (🟢 đang hoạt động / 🟡 vừa rời / ⚪ ngoại tuyến / 🚫 đã thu hồi), **đang làm lệnh gì cho kênh nào, % tiến độ** (qua `current_command_id` + hệ thống tiến độ), hồ sơ phụ trách, hoạt động cuối. Tự làm mới 15 giây.
- Cột hồ sơ có dòng **"🤖 Muse phụ trách: ..."**; thẻ "Muse đang làm việc" ở Tổng quan tiền tố tên Muse cho từng lệnh.

### 2. Thêm hàng loạt + phiếu kết nối
- **➕ Thêm tài khoản** (lẻ) hoặc **📥 Nhập hàng loạt**: dán danh sách mỗi dòng `Tên | email` / `tên,email` / chỉ `email` — trùng email được báo và bỏ qua, không chặn dòng khác. Token tự sinh cho từng tài khoản.
- **🎫 Xuất phiếu kết nối**: một file text gồm, cho từng Muse: `X-Agent-Id`, `X-Agent-Token` (token riêng), địa chỉ cầu nối và hồ sơ phụ trách — nạp phiếu cho từng Muse là xong khâu "đăng nhập" vào hệ thống quản lý.
- Qua API: `POST /api/agents`, `POST /api/agents/bulk`, `GET /api/agents`; client: `tools/muse_client.py agents list|add|import|assign|heartbeat|token|revoke|export`.

### 3. Phân công: một Muse — NHIỀU kênh; một hồ sơ — một Muse chính
- Phân công theo HỒ SƠ (kênh đi theo hồ sơ) bằng nút **🎯 Phân công kênh…** (checkbox; hồ sơ của Muse khác tick sang sẽ chuyển chủ) hoặc `POST /api/agents/{id}/assignments {"profile_ids": [...]}`.
- **Chống giẫm chân**: một Muse gọi cầu nối kèm `X-Agent-Id` + token riêng của nó thì CHỈ thấy các lệnh thuộc hồ sơ mình phụ trách (`GET /api/commands` tự lọc), báo progress/result cho lệnh của Muse khác bị **403**, tạo lệnh cho hồ sơ không phụ trách bị **403**. Khi báo cáo lần đầu, lệnh được ghi danh cho Muse đó (`commands.agent_id`) và nhật ký ghi tiền tố `[Muse: <tên>]`.
- **Heartbeat**: mọi lời gọi hợp lệ đều là nhịp sống; `POST /api/agents/{id}/heartbeat {"current_command_id": "..."}` khai lệnh đang giữ. Token chung của bản cài giữ vai trò quản trị (thấy/làm mọi thứ như trước). Thu hồi một Muse → token của nó bị chặn ngay (401); cấp lại token → token cũ hết hiệu lực.

> Chưa làm (GĐ3 trong phương án `PLAN_MUSE_ACCOUNTS.md`): đăng nhập muse.ai ngay trong tool bằng hồ sơ Chrome riêng cho từng tài khoản Muse. Tài khoản Muse vẫn do bạn tự đăng ký trên muse.ai.

## V3.4 — Topbar + panel phải + đăng nhập tại chỗ + logo kênh + báo cáo + tự động tạo video

### 1. Điều hướng TOPBAR + panel dữ liệu cột phải
- Sidebar dọc được thay bằng **topbar ngang trên cùng** (cùng hàng với đỉnh cột hồ sơ): logo CCD, các nút mục kèm nhãn (nút «/» thu về chỉ-icon), Quét tất cả, Toàn màn hình, chấm cầu nối, phiên bản.
- **Panel DỮ LIỆU HỒ SƠ chuyển sang cột phải** (tab Kênh / Nhật ký / Hàng đợi lệnh), kéo rộng/hẹp bằng thanh chia; ẩn/hiện bằng nút **🗂 Panel dữ liệu** trên thanh tiêu đề hoặc nút ✕ trong panel (lưu lựa chọn; chế độ toàn màn hình vẫn tự ẩn panel như cũ).

### 2. Thêm hồ sơ có sẵn đăng nhập: cookies trước, gmail|mật khẩu sau
- Form **Thêm hồ sơ** có thêm: ô **dán nhanh `ten@gmail.com|matkhau`** (tự tách vào ô Gmail + Mật khẩu), ô **Mật khẩu** (lưu vào kho riêng `data/credentials/<slug>.json` — không bao giờ ghi nhật ký/hiển thị), và **chọn file cookies** (lưu ngay vào kho cookies của hồ sơ).
- Có sẵn cookies/mật khẩu thì app **tự thử đăng nhập ngay** sau khi tạo hồ sơ. Nút **🔐 Đăng nhập** ở cột hồ sơ chạy lại quy trình bất cứ lúc nào: đã login -> thôi; **có cookies -> nạp cookies**; không -> **tự điền email + mật khẩu đã lưu** trong Chrome của hồ sơ. Gặp bước **xác minh** (2 bước/điện thoại/CAPTCHA/"Verify it's you") app **DỪNG** và để người dùng tự hoàn tất trong trình duyệt nhúng; Google báo sai mật khẩu thì app báo rõ để cập nhật lại.

### 3. Quản lý hồ sơ/kênh rõ ràng hơn: logo + tăng trưởng tại chỗ
- Quét kênh nay lấy thêm **logo kênh** (avatar từ dữ liệu account_menu), tải nền về `data/avatars/` và hiện ở cột đầu bảng kênh; bảng kênh ở panel phải hiển thị logo, tên, handle, subs **kèm ▲/▼ so với hôm qua**, số video và **chủ đề kênh**.

### 4. Báo cáo kênh hằng ngày (mục 📊 Báo cáo kênh)
- Mỗi lần quét, app ghi **snapshot theo ngày** cho từng kênh (DB v5: `channel_snapshots`). Mục Báo cáo: tổng subs/video toàn hệ thống, từng kênh có subs hiện tại, **Δ hôm qua**, **Δ 7 ngày**, Δ video 7 ngày, **xu hướng subs dạng sparkline** và dòng nhận định (kênh đang lên/xuống mạnh nhất). Kênh chưa đủ ngày dữ liệu ghi rõ "chưa đủ dữ liệu" — không bịa số; quét đều mỗi ngày là xu hướng rõ dần.

### 5. Tự động tạo video trên Muse cho từng kênh
- Mục **Tự động** có hành động mới **"Tạo video (Muse)"**: tới hạn, app tạo lệnh chờ Muse gắn **đúng tài khoản Muse đang phụ trách hồ sơ đó** (theo phân công ở mục Tài khoản Muse), nội dung lệnh yêu cầu tạo video mới đúng chủ đề kênh và cập nhật tiến độ vào app — Muse khác không thấy lệnh này (chống giẫm chân của V3.3).

### 6. Mọi thao tác chạy trong trình duyệt NHÚNG của app
- Quét kênh, đăng nhập, mở trình duyệt, lệnh nền — tất cả chạy trong Chrome riêng của từng hồ sơ thuộc app (tự nhúng vào giao diện theo cài đặt nhúng-luôn-bật) và **không liên quan tới trình duyệt Muse đang dùng trong các phiên chat**: hai hệ trình duyệt tách bạch hoàn toàn.

## V3.5 — Đăng nhập muse.ai cho từng tài khoản Muse (lớp B)

### Hai lớp kết nối — phân biệt rõ
- **Lớp A (cầu nối API)**: Muse điều khiển kênh qua app bằng `X-Agent-Id` + token riêng trong phiếu kết nối — lớp này KHÔNG cần đăng nhập web muse.ai; Muse (ở phiên chat/bản cài của nó) gọi cầu nối là vào việc, trạng thái sống hiện ở cột "Trạng thái" theo heartbeat.
- **Lớp B (đăng nhập muse.ai trong app)**: mỗi tài khoản Muse có **Chrome riêng** (`data/agents/agent-<id>/`, cổng debug riêng) để NGƯỜI DÙNG tự đăng nhập muse.ai cho đúng tài khoản đó và làm việc với Muse của tài khoản ngay trong cửa sổ của app.

### Cách dùng
- Chọn một dòng trong bảng Tài khoản Muse → bấm **🌐 Đăng nhập muse.ai**: app mở Chrome riêng của tài khoản đó tại muse.ai và **tự nhúng vào khung xem** (mục Hồ sơ), trạng thái cột **Muse.ai** chuyển "⏳ Đang chờ đăng nhập…".
- Bạn tự đăng nhập (email/mã xác minh là của tài khoản đó — app không gõ hộ). App tự dò mỗi 5 giây: thấy ô soạn chat của muse.ai thì ghi **✅ Đã đăng nhập**, trả khung nhúng về cho hồ sơ kênh; phiên đăng nhập được giữ trong thư mục Chrome riêng nên lần sau mở là còn đăng nhập. Đóng cửa sổ giữa chừng -> ghi "❌ Chưa đăng nhập". Quá 10 phút app ngừng tự dò (trạng thái vẫn cập nhật ở lần mở đăng nhập kế).
- Xoá một tài khoản Muse sẽ xoá luôn thư mục Chrome riêng của nó. DB v6 thêm `agents.web_state`; Agent API 2.3 trả thêm `web_state` trong hồ sơ agent.

## V3.6 — Trung tâm tiến độ (một màn hình cho mọi kênh) + bộ skill chuẩn

### Tab 🧭 Tiến độ
- Thay việc dò từng kênh: một màn hình tự làm mới 15 giây gồm:
  - **Dòng tổng quan**: đang chạy / chờ Muse / hàng đợi / vướng / kênh đang lên / kênh cần chú ý.
  - **Bảng Đang xử lý & hàng đợi**: công việc gì, kênh/hồ sơ nào, **AI LÀM** (tên Muse phụ trách theo ghi danh lệnh, hoặc "App tự chạy" / "Tự động (quy tắc)"), **thanh tiến độ %**, bước hiện tại, đã chạy bao lâu.
  - **Mục ⚠ Đang vướng**: lệnh lỗi (kèm lý do), lệnh chờ Muse quá 6 giờ chưa ai nhận, lệnh chạy 30 phút không báo tiến độ mới.
  - **Bảng Kênh đang lên**: kênh vừa có video mới / subs tăng (Δ 7 ngày từ snapshots quét kênh) kèm xu hướng; kênh giảm subs được nêu ở dòng chú ý.
  - **Chủ đề đang lên**: xếp hạng theo tổng Δ subs 7 ngày của các kênh trong từng chủ đề.
- Phạm vi dữ liệu ghi rõ ngay trong màn hình: chủ đề/từ khóa suy từ số liệu kênh của chính người dùng; "video nào đang được đề xuất" ở cấp video và xu hướng toàn YouTube cần dữ liệu Studio — Muse bổ sung khi quét Studio, app không tự bịa.

### Bộ skill vận hành (lưu phía Muse, áp dụng lâu dài)
- Theo yêu cầu "mọi yêu cầu là một trải nghiệm, mọi sửa lỗi là một bài học": toàn bộ quy trình đã đúc thành skill có sẵn để Muse tự tra và làm tiếp khi người dùng chỉ nêu chủ đề ngắn gọn — `video_production_standard` (phân tích đối thủ → kịch bản → sản xuất → nghiệm thu khung hình/giọng/hình → thumbnail → SEO → lịch đăng), `channel_launch_and_ops_standard` (tạo kênh mới + vận hành đa kênh + Facebook/TikTok), `ccd_dev_lessons` (bài học lỗi của chính app này).

## V3.7 — Cookies tự đăng nhập, thanh tiêu đề + logo chung, menu chuột phải, lệnh Tạo kênh cho mail, Chờ Muse minh bạch, ẩn trình duyệt ngoài màn hình

1. **Nhập cookies → tự đăng nhập + hiện kết quả**: chọn file cookies xong là app tự mở Chrome của hồ sơ, nạp cookies, kiểm tra phiên và báo kết quả ngay tại tab Hồ sơ (chip "Đã đăng nhập" trên thẻ + dòng cookies + toast). Thêm hồ sơ có cookies/mật khẩu cũng tự đăng nhập ngay như trước, nay kết quả hiện rõ như trên.
2. **Thanh tiêu đề riêng + logo chung**: cửa sổ không khung; hàng trên cùng có logo **Muse Automation** (góc trái) cùng hàng với nút − / □ / ✕ tự vẽ; kéo thanh để di chuyển, nhấn đúp để phóng to, kéo cạnh để đổi kích thước. Icon này là icon chung của MỌI cửa sổ app (chính, hộp thoại, taskbar).
3. **Cột hồ sơ gọn**: toàn bộ nút dưới thẻ (Mở trình duyệt / Đăng nhập / Quét kênh / Tạm dừng / Xoá / Nhập + Nạp cookies) chuyển thành **menu chuột phải trên thẻ hồ sơ** (và nút ⋯ trên thẻ), đủ icon + text. Cột chỉ còn thẻ + dòng trạng thái cookies/Muse phụ trách.
4. **Lệnh "Tạo kênh mới" cho MAIL**: tab Lệnh có nút **🆕 Tạo kênh đầu tiên cho mail này** — tạo lệnh cấp hồ sơ (không gắn kênh), nội dung mặc định theo chuẩn tạo kênh thương hiệu. Mọi lệnh chờ Muse khi tạo đều **tự ghi danh đúng Muse phụ trách hồ sơ** để chạy đúng tài khoản.
5. **Chuột phải + nút đủ icon/text khắp các tab**: bảng Lệnh (▶ Chạy ngay / 👤 Mở trang Hồ sơ / ✕ Huỷ / ↻ Thử lại / 🗑 Xoá), bảng Tài khoản Muse, bảng Kênh (mở YouTube/Studio, quét lại), bảng Tiến độ/Báo cáo (làm mới). Dòng bảng cao 36–40px để nút chứa trọn icon + text.
6. **"Chờ Muse" minh bạch + Chạy ngay mở trang Hồ sơ**: tab Lệnh có đoạn giải thích cố định. Bấm ▶ Chạy ngay: lệnh app tự chạy thì chạy ngay; lệnh của Muse thì app mở ngay trang Hồ sơ của mail đích và ghi rõ lệnh do Muse nào thực hiện qua cầu nối trong trình duyệt nhúng — "Chờ Muse" là đang xếp hàng chờ đúng Muse đó nhận, không phải lệnh treo.
7. **Không để trình duyệt bật ra ngoài**: checkbox trực tiếp **🙈 Ngoài màn hình** ở thanh trình duyệt (mặc định bật) — cửa sổ Chrome không đang nhúng sẽ bị đưa ra ngoài phạm vi màn hình (vẫn chạy nền) thay vì hiện trên desktop; tắt thì thu nhỏ xuống taskbar như cũ.

## Đóng gói thành EXE (buildexe.bat)

- Chạy **`buildexe.bat`** trên Windows: file tự tìm Python, tạo môi trường build riêng `.build-venv`, **tự tải thư viện còn thiếu** (PySide6/websocket-client theo requirements.txt và PyInstaller), rồi đóng gói bằng PyInstaller.
- Kết quả: `dist\ChannelControlDesktop\ChannelControlDesktop.exe` + thư mục thư viện `_internal\` ngay bên cạnh (dạng onedir — khởi động nhanh, dễ cập nhật từng phần).
- Điểm vào đóng gói là `run_exe.py`: khi chạy dạng exe, dữ liệu người dùng (SQLite, hồ sơ Chrome, cookies, nhật ký) nằm ở `data\` **ngay cạnh file exe**, không nằm trong `_internal\` — khi thay bản build mới, giữ lại thư mục `data\` là giữ nguyên toàn bộ dữ liệu.
- Icon của exe là `app/assets/app_icon.ico` (logo Muse Automation); bản PNG cùng tên được đóng gói kèm để cửa sổ/hộp thoại trong app dùng chung một icon.
- Đã kiểm chứng quy trình đóng gói tương đương trong môi trường kiểm thử: build thành công, file chạy được, tự tạo đủ thư mục dữ liệu và cơ sở dữ liệu ở lần mở đầu.

## V3.8 — Fix triệt để "ra lệnh mà Muse không chạy": cầu nối phải có bằng chứng kết nối

**Nguyên nhân gốc** (đã kiểm chứng): lệnh của Muse chạy theo cơ chế kéo — một tài khoản Muse ở ngoài phải kết nối vào Agent API của app (cổng 19500) để nhận lệnh. Nếu cầu nối chưa từng được nối (máy Windows và Muse chưa chung mạng Tailscale / thiết bị của Muse chưa được duyệt / Muse chưa có phiếu kết nối), lệnh nằm ở "Chờ Muse" vô thời hạn — và các bản trước **im lặng** về điều này nên người dùng không biết lệnh không thể chạy.

Bản này bịt lỗ hổng ở tầng app:
- **Ghi nhận bằng chứng cầu nối bền vững**: mọi lời gọi API đã xác thực được ghi vào DB (`bridge_last_poll_at`), còn nguyên sau khi khởi động lại app. `Store.bridge_state()` tính trạng thái thật: chưa từng kết nối / đang kết nối (hoạt động ≤180s hoặc có Muse online theo heartbeat) / mất kết nối.
- **Banner đỏ/vàng/xanh ở đầu tab Lệnh** nói thẳng trạng thái, kèm nút **🔌 Kết nối Muse…** mở hộp thoại 3 bước kết nối (Tailscale + duyệt thiết bị, Firewall, xuất phiếu kết nối ở tab Tài khoản Muse và gửi cho Muse).
- **Guard khi tạo/chạy lệnh của Muse**: cầu nối chết mà vẫn tạo/chạy → hộp thoại cảnh báo nói rõ hậu quả và cho chọn (xem hướng dẫn / vẫn tiếp tục / huỷ), thay vì xếp hàng im lặng.
- **Thanh trạng thái** dùng cùng bằng chứng bền này: "Cầu nối Muse: đang nghe · 0.0.0.0:19500 · CHƯA có Muse nào kết nối".

Lưu ý: app không thể tự thay người dùng duyệt thiết bị Tailscale hay gửi phiếu kết nối — đó là 3 bước một lần ở hộp thoại hướng dẫn; xong chúng, lệnh sẽ tự chạy khi Muse nhận.

## V3.8.1 — Nút trong dòng không còn bị che

- Nguyên nhân: dòng bảng Lệnh cao 40px trong khi nút (theo QSS: padding dọc 7px + chữ) cần ~36px cộng đệm của ô — vừa khít ở DPI 100% và bị cắt thật ở DPI 125–150%; bảng Tự động còn không đặt chiều cao dòng.
- Fix đo từ nút thật: `theme.button_row_height()` đo sizeHint của nút mẫu theo font/QSS/DPI hiện hành; bảng Lệnh dùng số đo này (tối thiểu 56px) làm chiều cao mặc định VÀ ép từng dòng khi vẽ lại; cột Thao tác rộng cố định 276px cho hai nút nằm trọn. Bảng Tự động áp cùng cơ chế (tối thiểu 50px), nút xoá có thêm chữ "🗑 Xoá".

## V4.0 — FULL AUTOMATION: lệnh tới là Muse biết ngay, việc không chết giữa chừng

Mục tiêu của bản này: khép kín vòng đời lệnh chờ Muse ở PHÍA APP — lệnh được tạo (UI / quy tắc tự động / API) là đi qua một hàng đợi có kỷ luật thay vì nằm chờ bị động. (Phần runner phía Muse — hook `ccd-bridge-watch` dùng long-poll — là việc riêng phía Muse, không nằm trong repo này.)

1. **Claim + Lease nguyên tử (H1, Agent API 2.4)**: `POST /api/commands/{id}/claim` chuyển `waiting_muse → running` bằng MỘT câu UPDATE có điều kiện — hai phía gọi cùng lúc chỉ một phía thắng, phía thua nhận 409 kèm trạng thái hiện tại. Claim cấp **lease** (mặc định 120 giây): progress của chính chủ lease, heartbeat kèm `current_command_id`, hoặc result "running" đều gia hạn lease. Kèm `POST /api/commands/{id}/release` để trả lệnh về hàng chờ sạch (không tính lần thử). Đường cũ vẫn tương thích: báo progress đầu tiên vẫn tự nhận việc như trước (quyết định Đ1) nhưng từ nay có lease đi kèm; Muse khác không giữ lease mà báo progress/result lên lệnh đang chạy sẽ bị 403.
2. **Sweeper lease**: trong vòng lặp worker của Agent API (mỗi ~15 giây, quyết định Đ4): lease hết hạn → lệnh về `waiting_muse`, `attempts` +1 và ghi nhật ký; vượt quá số lần giữ tối đa (mặc định 3) → `failed` với lỗi nói rõ "giữ lệnh nhưng mất dấu N lần". Lệnh `waiting_muse` chờ quá lâu (mặc định 10 phút) mà Muse phụ trách đang offline/chưa phân công → cảnh báo đúng MỘT LẦN mỗi lệnh. Lệnh chờ được quét lúc mở app nay chỉ coi là dang dở khi lease đã hết hạn/không có.
3. **Dispatcher + preflight (H2)**: lệnh Muse MỚI (mọi nguồn) vào trạng thái `queued` trước (Đ5; hàng `waiting_muse` cũ không đổi). Dispatcher xét theo thứ tự ưu tiên nguồn UI → tự động → API: tới giờ hẹn chưa, lệnh phụ thuộc (`depends_on`) đã xong chưa (phụ thuộc hỏng → lệnh con `failed` kèm lý do), mỗi hồ sơ tối đa MỘT lệnh Muse đang chạy, hồ sơ không tạm dừng, có Muse phụ trách chưa bị thu hồi; rồi preflight theo loại (upload phải có file thật trong `data/inbox/` hoặc `video_id` đã biết — thiếu là "chờ file" chứ không fail; tạo kênh chặn trùng gmail/kênh đã có). Khi Agent API chạy cùng ChromeManager (đường khởi động chính), dispatcher còn mở sẵn Chrome của hồ sơ + kiểm tra đăng nhập, thử đăng nhập bằng cookies/mật khẩu đã lưu; gặp thử thách cần người (2FA/captcha) → lệnh sang `needs_user`. Chưa đủ điều kiện = GIỮ lệnh + ghi bước chờ hiện ngay ở cột Tiến độ.
4. **Trạng thái `needs_user` — "⏸ Chờ người xử lý" (H3)**: phía Muse báo qua result `status=needs_user` (chỉ chủ lease/admin, thả lease, KHÔNG tính lần thử) khi cần người thật: đăng nhập tay, 2FA, captcha, duyệt nội dung… Tab Lệnh có banner hồng đếm số lệnh đang chờ + nút **"▶ Đã xử lý — chạy tiếp"** đưa lệnh về `queued` cho dispatcher xét lại.
5. **Gói sống sót (H4)**: **single-instance** — mở bản app thứ hai chỉ gọi cửa sổ bản đang chạy lên rồi thoát (không còn tranh cổng 19500/SQLite); cờ **`--watchdog`** (ở cả `run.py` và `run_exe.py`) — tiến trình cha giám sát, app thoát bất thường thì mở lại sau 5 giây, tối đa 5 lần/giờ, thoát sạch thì không mở lại (cờ `data/.clean_exit`); **tự khởi động cùng Windows** — công tắc trong Cài đặt (mặc định TẮT), ghi khoá Run HKCU kèm `--watchdog --autostart`, mở lên vào thẳng tray.
6. **Kiểm chứng payload + chống trùng (H5)**: schema dùng chung `app/command_schema.py` chặn lệnh sai cấu hình ngay ở cửa nhận — API trả 400 kèm danh sách lỗi (upload thiếu file/video_id, channel_id không thuộc hồ sơ, create_video/free thiếu nội dung, gmail tạo kênh sai định dạng…); form UI kiểm tra cùng schema. Mọi đường tạo lệnh tự động gắn **khoá idempotency** (quy tắc tự động theo chu kỳ, API/UI theo cửa sổ 10 phút): tạo trùng cùng khoá → trả lệnh cũ kèm `deduplicated: true`, không sinh lệnh đôi.
7. **Long-poll (H6)**: `GET /api/commands?status=waiting_muse&wait=N` (0–50 giây) — có lệnh mới đủ phạm vi là trả về NGAY. Đây là phía server của yêu cầu "lệnh gửi đến là Muse phải biết liền và phản hồi ngay"; phía Muse chuyển hook sang long-poll + claim để hoàn tất vòng khép kín.
8. **Bề mặt điều khiển tối thiểu (H7)**: phiên bản hợp nhất một nguồn `app.__version__ = "4.0.0"` (nhãn giao diện đọc từ đó, hiện "V4.0"; DB schema 7; Agent API 2.4). Tab Lệnh thêm banner `needs_user`/chưa-phân-công, cột Tiến độ hiện Muse đang giữ lease + đếm ngược hạn lease (chữ thuần trong ô). Cài đặt thêm: công tắc vòng tự động, hạn lease (giây), số lần giữ tối đa, phút cảnh báo chờ, tự khởi động cùng Windows. Toàn bộ thiết kế lại giao diện (nếu có) là việc riêng, làm sau trên nền các trạng thái/công tắc này.
9. **Client phía Muse**: `tools/muse_client.py` thêm lệnh `claim <id>`, `release <id>`, `commands --status … --wait N`; `result` chấp nhận trạng thái `needs_user`.

Kiểm thử: 255 test (211 cũ vẫn xanh + 44 mới `tests/test_v40_*.py` phủ claim/lease/sweeper/dispatcher/needs_user/schema-idempotency/sống sót/long-poll). Các hiệu ứng chỉ-Windows (single-instance gọi cửa sổ, khoá Run, watchdog trên máy thật) có test logic thuần; vẫn cần nghiệm thu một vòng trên PC Windows thật như mọi bản trước.

## V4.1 — Giao diện "Văn phòng diorama": nhìn văn phòng là biết ai đang làm gì

Theo ý tưởng của người dùng: mỗi công việc do một AI agent làm thì phải THẤY được dạng hình ảnh — ai đang làm việc gì, tiến độ bao nhiêu %, ai là quản lý — thay vì toàn chữ. Phương án đã duyệt: **Concept C — diorama công sở nhìn từ trên xuống** (xem `UI3D_OFFICE_PLAN.md` + ảnh mẫu trong `ui3d_concepts/`).

1. **Tab 🏢 Văn phòng mới — mục ĐẦU TIÊN và là màn hình mặc định khi mở app** (các tab chữ cũ giữ nguyên toàn bộ chức năng). Sàn văn phòng vẽ 2.5D thuần Qt (`QGraphicsView` + `QGraphicsItem`, không WebEngine, không file sprite): phòng kính **Điều phối viên** ở góc trái-trên với robot quản lý + bảng điều phối (trạng thái cầu nối, số lệnh hàng đợi/đang chạy/chờ người); biển tên văn phòng + góc nghỉ trang trí ở giữa; **bảng ghim 📌 Hàng đợi chờ** ở tường phải với tối đa 5 thẻ lệnh + dòng "+N lệnh nữa"; khu bàn nhân viên ở giữa.
2. **Mỗi tài khoản Muse = một bàn làm việc** (tối đa 8 bàn/trang, thừa đếm riêng): robot màu riêng ổn định theo tài khoản, ngồi sau bàn + màn hình; **bong bóng thoại** trên đầu khi có việc — tên loại lệnh + nội dung rút gọn + thanh % + số %; màu bong bóng theo trạng thái: xanh ngọc = đang làm, vàng = đang chờ việc, đỏ + dấu ❗ nhấp nháy = **chờ người xử lý**; agent ngoại tuyến = robot xám + nhãn "Ngoại tuyến"; rảnh = bàn không bong bóng. Robot đang làm nhún nhẹ (hoạt cảnh 500ms, chỉ chạy khi tab đang hiện).
3. **Ánh xạ dữ liệu thật 100%** qua tầng thuần `app/ui/office_scene.py` (không Qt, test độc lập): bàn thuộc agent nào, lệnh hiện tại là lệnh agent đang giữ lease (V4.0), % = `commands.progress`, hàng đợi sắp đúng thứ tự dispatcher (UI → tự động → API, cũ trước), số liệu tổng (online/đang chạy/hàng đợi/chờ người/xong hôm nay) đếm từ Store.
4. **Panel chi tiết bên phải**: bấm vào một bàn → avatar robot đúng màu + tên/trạng thái agent, hồ sơ + số kênh phụ trách, lệnh hiện tại (loại, nội dung, thanh %, bước đang làm, **đếm ngược lease**), 5 lệnh gần nhất và hai nút nhảy nhanh "📋 Mở tab Lệnh" / "🤖 Tài khoản Muse". Nhãn lệnh gần đây dùng pool nhãn cố định dùng lại (không xoá/tạo widget theo nhịp làm mới — tránh bóng ma chồng chữ).
5. **Nhịp làm mới 1 giây** từ cửa sổ chính, chỉ khi tab Văn phòng đang hiện hành + đang hiện trên màn hình; ẩn tab là không đọc kho.

Kiểm thử: 265 test (255 cũ vẫn xanh + 10 mới `tests/test_v41_office.py`: ánh xạ trạng thái bàn/hàng đợi/tràn bàn/số liệu + khói giao diện tab mặc định/chọn agent/nút chuyển tab/kho rỗng). Ảnh preview offscreen: `ui_preview_v41_office.png` (QC bằng mắt: đã sửa lỗi chồng chữ ở panel chi tiết và vẽ lại góc nghỉ sau lần chụp đầu). Phiên bản hiển thị "V4.1" (`app.__version__ = "4.1.0"`); DB vẫn schema 7, Agent API vẫn 2.4. Như mọi bản trước: hiệu ứng thật trên Windows (DPI cao, font hệ thống) vẫn cần người dùng nghiệm thu một vòng trên PC thật.

## V4.1.1 — Hotfix: tự phân công theo email, Chạy ngay tức thì, chọn Muse nhận lệnh ngay ở tab Lệnh, phiếu theo từng tài khoản

Sự cố thật 29/10: lệnh "Tạo video (Muse)" cho hồ sơ dabnire34@gmail.com kẹt 'queued' vĩnh viễn với bước "Chưa có Muse phụ trách hồ sơ này" — tài khoản Muse dabnire34@gmail.com ĐÃ tồn tại nhưng 0 phân công, và bấm ▶ Chạy ngay chỉ đổi trạng thái nút chứ không ai xét lại lệnh. Bốn lớp chữa:

1. **Tự phân công theo email** (`Store.auto_assign_email_matches`): tài khoản Muse có email đăng nhập trùng gmail của hồ sơ CHƯA CÓ chủ thì chính là người phụ trách hồ sơ đó — gán qua đúng đường `assign_profiles` (kèm gắn lại agent_id cho lệnh mồ côi), mỗi cặp ghi một dòng nhật ký "Tự phân công: hồ sơ … → Muse … (trùng email)". Không giật hồ sơ đã có chủ, bỏ qua agent đã thu hồi, idempotent. Được gọi ở MỌI nhịp dispatcher (trước khi xét lệnh, lỗi ở bước này không chặn điều phối), lúc mở app, và ngay sau khi thêm tài khoản Muse / thêm hồ sơ trong UI.
2. **Chạy ngay là NGAY THẬT**: `AgentServer.request_dispatch_now()` (threading.Event) đánh thức vòng worker để dispatcher xét lệnh tức thì thay vì chờ nhịp 15 giây; `CommandRunner.run_now` với lệnh của Muse nay xoá hẹn giờ (`Store.clear_command_schedule`) rồi mới ép điều phối; tab Lệnh tự làm mới sau 0.7s/3s để trạng thái mới hoặc lý do còn bị giữ hiện ngay. Lệnh app tự chạy giữ nguyên hành vi cũ.
3. **Chọn Muse nhận lệnh ngay trong tab Lệnh** (không phải sang tab Tài khoản Muse nữa): form tạo lệnh có thêm ô **"Tài khoản Muse nhận lệnh"** — mặc định "Tự động (theo phân công của hồ sơ)" giữ nguyên hành vi cũ; chọn một Muse cụ thể thì lệnh ghi danh Muse đó và app tự đảm bảo phân công hồ sơ ↔ Muse đó (`Store.ensure_agent_assignment` — chỉ định tường minh nên không cần trùng email, hồ sơ thuộc Muse khác sẽ chuyển chủ như khi tick phân công tay). Lệnh của Muse đang chờ ('queued'/'waiting_muse') có thêm nút **"🎯 Đổi Muse…"** ở cột Thao tác (và trong menu chuột phải): ghi danh lại + đảm bảo phân công + ép dispatcher xét ngay. Lệnh đang chạy/chờ người/đã xong không đổi được — quyền sở hữu/lease đã chốt. Luật sở hữu của dispatcher KHÔNG đổi.
4. **Phiếu kết nối theo từng tài khoản** (`app/tickets.py`): mỗi tài khoản một file riêng `phieu-ket-noi-<slug>.txt` (slug từ email, thiếu email thì từ tên — `config.slugify`) chỉ chứa token của đúng tài khoản đó, hết cảnh mọi tài khoản dồn vào một file một tên chung gây nhầm lẫn. Phiếu TỰ ĐƯỢC GHI LẠI ở mọi sự kiện vòng đời: thêm tài khoản (lẻ + hàng loạt), cấp lại token, thu hồi/mở lại, xoá tài khoản (file riêng của tài khoản đã xoá bị gỡ, tránh token mồ côi). File gộp `phieu-ket-noi-claude.txt` vẫn được làm tươi kèm theo và giữ NGUYÊN định dạng cũ từng dòng (khối `## <tên> (#<id>) — <email>` + `X-Agent-Id` + `X-Agent-Token`) vì parser phía Muse tách khối theo định dạng đó. Thư mục phiếu nhớ trong settings `ticket_export_dir` (mặc định `<data dir>/phieu-ket-noi`), hiện ngay ở dòng trạng thái trong tab Tài khoản Muse kèm nút đổi thư mục; nút 🎫 nay ghi vào thư mục đó (chưa đặt thì hỏi một lần). **Cấp lại token**: hộp xác nhận nói rõ phiếu của tài khoản đó đã được TỰ ĐỘNG cấp lại (tên file + thư mục) và token cũ đã chết — xoá hẳn bước "nhớ xuất lại phiếu thủ công" từng làm mù cầu nối âm thầm. Ghi phiếu lỗi (thư mục không ghi được) không làm hỏng thao tác chính — chỉ báo một dòng trạng thái.

Kiểm thử: 287 test (266 cũ vẫn xanh + 21 mới `tests/test_v411_autoassign.py`: tự phân công khớp email/idempotent/không giật chủ/revoked/nhật ký, kịch bản dabnire34 đầu-cuối qua dispatcher, giao đúng Muse được chỉ định, request_dispatch_now bỏ qua khoảng chờ + worker thức ngay, run_now xoá hẹn giờ, ô chọn + nút đổi Muse ở panel, phiếu riêng chỉ chứa token của mình, cấp lại token chỉ đổi file của tài khoản đó còn file khác nguyên từng byte, file gộp parse lại đúng định dạng cũ, ghi phiếu lỗi không ném ngoại lệ). Phiên bản hiển thị "V4.1.1" (`app.__version__ = "4.1.1"`); DB vẫn schema 7, Agent API vẫn 2.4. Như mọi bản trước: vẫn cần nghiệm thu một vòng trên PC Windows thật.

## V4.1.2 — Lệnh đi thẳng tới Muse, không qua cổng trình duyệt/đăng nhập

- Bỏ hẳn cổng preflight trình duyệt/đăng nhập khỏi đường giao lệnh: trước đây lệnh cần web (Tối ưu / Tải video / Tạo video / Tạo kênh) bị dispatcher giữ ở hàng đợi ("Chuẩn bị chưa xong…") hoặc đẩy sang Chờ người nếu Chrome của hồ sơ chưa mở/chưa đăng nhập — lệnh không bao giờ tới được Muse. Nay lệnh đã tạo/bấm chạy là được đẩy lên "Chờ Muse" ngay khi đủ các điều kiện dữ liệu thuần (có Muse phụ trách, đúng hẹn, lệnh phụ thuộc xong, mỗi hồ sơ một lệnh một lúc); việc mở web/đăng nhập do Muse tự xử lý trong lúc chạy, và chỉ Muse mới có quyền báo "Chờ người" khi thật sự cần thao tác tay (2FA, CAPTCHA, đăng nhập lại).
- Thay đổi ở cả ba điểm khởi tạo cầu nối (mở app, khởi động lại cầu nối trong Cài đặt, và ngay trong AgentServer khi chạy nhịp điều phối) nên cổng không thể quay lại do sót một đường khởi tạo. Có test hồi quy ở tầng server: hooks "độc" (probe luôn sai, mở web luôn lỗi) cũng không chặn được lệnh.

## V4.1.3 — Tạo lệnh luôn ghi, bỏ chặn theo trạng thái cầu nối

- **Bấm Tạo lệnh là lệnh PHẢI xuất hiện trong danh sách.** Bản cũ có một lỗi lặng lẽ: lệnh tạo thủ công trong app bị gắn "khoá chống trùng" tính theo loại lệnh + hồ sơ + cửa sổ 10 phút (không tính nội dung yêu cầu), nên tạo lần hai cùng loại cho cùng hồ sơ trong 10 phút thì app không thêm dòng nào mà vẫn báo "Đã tạo lệnh" với mã của lệnh cũ. Nay tạo lệnh thủ công không gắn khoá chống trùng nữa — bấm tạo bao nhiêu lần là có bấy nhiêu lệnh. Chống trùng chỉ còn áp dụng cho các lời gọi qua API có truyền khoá riêng (giữ nguyên như trước). Nếu vì lý do nào đó hệ thống vẫn phát hiện lệnh trùng, app sẽ nói rõ "Lệnh giống hệt đã có trong danh sách — không tạo trùng" và chọn đúng dòng lệnh đó, không báo thành công giả.
- **Tạo lệnh và bấm Chạy không còn bị hộp thoại cầu nối chặn.** Trước đây, khi chưa có Muse nào đang kết nối, app bật hộp thoại "Chưa có Muse nào đang kết nối" và bấm Huỷ bỏ là mất luôn thao tác tạo/chạy. Nay thao tác luôn được ghi nhận: Muse chưa kết nối thì lệnh nằm ở trạng thái "Chờ Muse" và tự được giao ngay khi Muse kết nối lại (vòng heartbeat tự kết nối lại mỗi 10 giây). Trạng thái cầu nối vẫn hiện ở banner đầu tab Lệnh và nút "🔌 Kết nối Muse…" để xem hướng dẫn — chỉ để biết thông tin, không chặn việc ra lệnh.

## V4.2 — Tối ưu theo kiểm toán: lệnh đi nhanh hơn, trạng thái thật hơn, lỗi không còn im lặng

Bản này thực thi toàn bộ phạm vi V4.2 của `PLAN_V4.2_OPTIMIZATION.md` (31 phát hiện O-01…O-31; các mục để sang V4.3 giữ nguyên). Schema DB giữ 7, Agent API giữ 2.4.

- **Điều phối theo sự kiện ở mọi đường (O-27):** tạo lệnh ở tab Lệnh (kể cả nút Tạo kênh), bấm "Đã xử lý — chạy tiếp", "Thử lại", đổi Muse nhận lệnh, lệnh sinh ra từ quy tắc tự động và lệnh tạo qua Agent API đều đánh thức dispatcher NGAY thay vì chờ nhịp 15 giây.
- **Danh sách lệnh cho Muse lọc đúng trong SQL (O-28):** trạng thái/nguồn được lọc trước giới hạn — một lệnh "Chờ Muse" cũ không còn bị 50 lệnh mới hơn trạng thái khác chen mất khỏi danh sách của Muse nữa.
- **Hook cầu nối nhắc lại lệnh chưa ai nhận (O-29):** lệnh đã được đánh thức mà vẫn nằm "Chờ Muse" sẽ được nhắc lại theo nhịp giãn dần 60s → 120s → 240s → … tối đa 600s, tới khi có Muse claim. Payload nhắc lại mang cờ `rewake` để Muse phân biệt với lệnh mới và không claim hai lần.
- **Kết quả tạo lệnh hiện ngay tại form (O-01):** thành công/lỗi hiện thành dòng trạng thái trong chính thẻ form, dòng lệnh vừa tạo được chọn nổi bật trong bảng — không còn phụ thuộc vào dòng nhật ký thoáng qua.
- **Trạng thái là sự thật hiện tại (O-03/O-04/O-07/O-08):** lệnh được đẩy lên "Chờ Muse" mang luôn bước "Đang chờ Muse nhận lệnh…" thay vì lý do bị giữ cũ; các cờ vận hành trong payload (chưa có chủ / đã cảnh báo chờ lâu…) được dọn khi điều kiện hết; banner và số đếm ở tab Lệnh + Văn phòng lấy từ truy vấn tổng toàn cục thay vì đếm trên danh sách đã cắt 100–200 dòng; lệnh phụ thuộc trỏ vào một lệnh không tồn tại chuyển thẳng "Chờ người xử lý" kèm lý do thay vì treo im lặng mãi.
- **Không còn đường tắt qua dispatcher (O-05):** báo tiến độ cho lệnh còn "Đang chờ" (queued) bị API từ chối 409 và tầng dữ liệu cũng không tự chuyển trạng thái — chỉ lệnh đã "Chờ Muse" mới giữ đường claim ngầm tương thích cũ, và mỗi lần dùng đường đó đều được ghi sổ.
- **Lỗi vòng tự động phải nhìn thấy (O-06):** dispatcher/sweeper/điều phối-ngay lỗi không còn bị nuốt lặng — app ghi log có cấu trúc + trạng thái sức khoẻ, và thanh trạng thái hiện "⚠ Vòng tự động lỗi (nguồn) lúc HH:MM — …" cho tới khi nhịp chạy sạch trở lại.
- **Văn phòng với tới mọi agent (O-24/O-25/O-09):** ô chọn agent trên đầu tab mở chi tiết của cả agent ngoài 8 bàn vẽ; panel chi tiết có mục "Tiếp theo" — hàng đợi riêng của từng Muse theo đúng thứ tự dispatcher xét; thẻ hàng đợi hiện thêm tên Muse phụ trách và thời gian đã chờ; cảnh chỉ dựng lại khi dữ liệu thật sự đổi (đếm ngược lease vẫn chạy mỗi giây từ mốc hết hạn đã lưu).
- **Bảng Lệnh nhẹ hơn (O-10/O-11):** timer tự làm mới chỉ chạy khi mục Lệnh đang hiện; combo và bảng bỏ qua dựng lại khi dữ liệu không đổi (giữ nguyên lựa chọn + vị trí cuộn); bảng hàng đợi ở dock chỉ dựng lại khi đang nhìn thấy.
- **Form và điều hướng theo người dùng (O-20/O-21/O-23/O-26):** thứ tự ô tạo lệnh đổi thành Hồ sơ đích → Muse nhận lệnh → Loại lệnh → Kênh, kèm dòng tóm tắt "Sẽ tạo: …" trực tiếp; ô Kênh chỉ bật khi loại lệnh cần kênh, ô Muse chỉ bật cho lệnh của Muse; nút Tạo kênh sang hàng riêng có chú thích; đoạn hướng dẫn rút còn đúng luật hiện tại. Bấm "▶ Chạy ngay" cho lệnh của Muse KHÔNG còn giật sang trang Hồ sơ — chỉ ghi chú không-modal (lệnh app tự chạy giữ hành vi cũ). Cửa sổ hẹp thì topbar tự chuyển dạng chỉ-icon (quyết định thu gọn tay luôn thắng, chế độ tự động không ghi cài đặt).
- **Dọn bẫy cấu trúc (O-02/O-13/O-18/O-31 + phần an toàn của O-12):** khoá chống trùng mặc định của API gồm toàn bộ yêu cầu (nội dung, kênh, Muse nhận, giờ hẹn, phụ thuộc + payload) nên hai yêu cầu khác nhau không còn bị coi là một; dispatcher/sweeper phân trang qua toàn bộ backlog thay vì chỉ 200 lệnh mới nhất; code cổng trình duyệt/đăng nhập đã chết trong dispatcher bị xoá dứt điểm (hooks truyền vào bị bỏ qua — có test ghim); cổng upload băm SHA-256 theo luồng đọc 1MB + cache theo dấu vân file, không nạp cả video vào RAM mỗi nhịp nữa; heartbeat không còn ghi trùng hai lần và danh sách agent nạp phân công bằng một truy vấn thay vì N+1.

## V5.0 — Bản gộp: chat trong app + giao việc theo dòng Agent + khoá phong cách

- **Chat trực tiếp với từng Muse ngay trong app** (API 2.6, schema DB 8 — bảng `agent_messages`): bề mặt chính là panel chi tiết agent ở **Văn phòng** (chat tại chỗ, bong bóng câu hỏi needs_user + huy hiệu 💬 trên bàn), cửa vào thứ hai ở mục Tài khoản Muse; lệnh kẹt `needs_user` tự để lại đúng một tin hệ thống trong luồng của Muse phụ trách. Hợp đồng cầu nối: `docs/AGENT_CHAT.md`.
- **Sửa lỗi Văn phòng trên máy thật:** bấm/hover làm bàn, robot, bảng tên biến mất (wrapper QGraphicsItem bị GC xoá item khỏi scene) — nay dựng cảnh nguyên tử + giữ tham chiếu mạnh + tự kiểm tra toàn vẹn và tự lành.
- **Trình duyệt nhúng đầy kích thước:** chế độ "🗗 Đầy khung" cho khung đơn (tự bật khi chỉ có một trình duyệt chạy, ⛶ từ tường lưới về khung đơn đầy), kích thước bám mọi resize; mức zoom trang 75% giữ nguyên, độc lập với kích thước khung.
- **Nút 🔌 Kết nối từng dòng agent:** hộp thoại hai lớp tách bạch (cầu nối/heartbeat ≠ đăng nhập muse.ai) + lý do ngoại tuyến + Xuất phiếu kết nối + Kiểm tra lại.
- **Giao việc theo dòng Agent:** view **Theo Agent** là view chính của mục Công việc (agent → kênh, tiến độ từ work model chung); chuột phải trên dòng kênh để Giao việc theo **checklist mẫu** (lưu/sửa được, 6 mẫu mặc định) + **đính skill** từ thư viện hoặc nhập skill mới ngay trong hộp thoại; **checklist thường trực** riêng từng kênh. Mẫu + checklist lưu file trong `data/` — xem `docs/ASSIGNMENT_MODEL.md`.
- **Khoá phong cách theo ảnh mẫu duyệt:** accent xanh tươi `#4ADE80` (viền sáng thay hiệu ứng đổ bóng để giữ hiệu năng), panel bo góc 20px sáng hơn nền một bậc, nút chính pill xanh đặc chữ đen, thanh tiến độ dày + gradient phát sáng nhẹ, avatar tròn cho agent/kênh; bộ MetaMint đời đầu chưa tuỳ biến tự di trú lên bộ mới.

## V6.1 — Trưởng phòng giám sát + hạn chót + sự cố Văn phòng + chống đơ

### 1. Trưởng phòng giám sát (tab 🔍 Giám sát)
- Thanh đầu tab: **Bật giám sát**, **Chế độ** (👔 Trưởng phòng giám sát / 🔁 Vòng chéo) và ô chọn **Trưởng phòng** — đổi là áp ngay và lưu `data/settings.json` (`supervision_mode`, `supervision_lead_agent_id`).
- Chế độ trưởng phòng: tài khoản được chọn chấm việc của MỌI tài khoản khác; việc của chính trưởng phòng do Muse kế tiếp trong vòng chấm (không ai tự chấm mình — bất biến V6.0 giữ nguyên). Trưởng phòng bị thu hồi/chưa chọn → tự về vòng chéo.
- Chỉ việc của Muse mới sinh kiểm tra chéo; lệnh app tự chạy (quét/kiểm tra/mở trình duyệt) không còn đẻ việc "Kiểm tra chéo" rác.

### 2. Hạn chót cho mọi việc
- Cột `commands.due_at` (schema 10). Không truyền thì hạn mặc định theo loại (`DEFAULT_DEADLINE_MINUTES`: tạo video 240p, tạo kênh 120p, tối ưu/tải lên 60p, lệnh tự do 120p, kiểm tra chéo 60p, quét/kiểm tra 15p…), tính từ giờ hẹn hoặc lúc tạo; ghi đè từng loại bằng setting `deadline_minutes`. Lệnh cũ đang mở được gán hạn khi mở app. Làm lại sau kiểm tra = hạn mới.
- Agent API 2.8: lệnh trả thêm `due_at`; `POST /api/commands` nhận `due_at` (ISO).
- Watchdog (nhịp sẵn có của cầu nối): việc vừa quá hạn → ghi Nhật ký + MỘT tin hệ thống cho trưởng phòng (hoặc giám sát viên) và người làm; gia hạn thì cảnh báo được bật lại.
- Tab Giám sát vẽ lại: dải chỉ số bấm-để-lọc (đang mở / đúng tiến độ / sắp trễ / trễ hạn / kẹt / chờ chấm / % xong đúng hạn tuần), **bảng tiến độ theo hạn chót** (mỗi tài khoản một làn, trưởng phòng đứng đầu; mỗi việc: thanh % + vạch thời gian đã dùng của hạn, giờ hạn + còn/trễ, nhãn sức khoẻ), chuột phải/thanh thao tác: nhắc Muse, gia hạn +30p/+1g/+4g, đặt hạn, thu hồi, mở lệnh, lịch sử kiểm tra; **sơ đồ đội**; **thẻ điểm** có cột % đúng hạn; hàng đợi kiểm tra + cảnh báo treo ở tab dưới.

### 3. Văn phòng nói rõ lỗi
- Khối **⚠ Sự cố cần xử lý** (`app/office_issues.py`, `app/ui/issues_panel.py`): cầu nối chưa nối/mất nối, vòng tự động lỗi, lệnh chờ bạn (GỘP theo hồ sơ + lý do), lệnh thất bại 24h, trễ hạn, Muse chưa nhận việc, Muse ngoại tuyến đang ôm việc, hồ sơ chưa có Muse phụ trách. Mỗi sự cố: lỗi thật + **cách xử lý** suy từ lý do (đăng nhập/OTP/CAPTCHA/quota 429/mạng/thiếu file/chính sách) + nút làm ngay (mở trình duyệt hồ sơ, chạy tiếp, thử lại, nhắn/nhắc Muse, gia hạn, kết nối, phân công). Thu gọn được.
- Bàn/ô có huy hiệu **⚠ N lỗi**; bong bóng "chờ người" hiện lý do kẹt thay cho thanh 0%.

### 4. Chống đơ / lag
- **Nguyên nhân gốc:** tab Hồ sơ dò cổng debug Chrome của MỌI hồ sơ trên luồng giao diện mỗi 600ms (`_wall_tick`/`_auto_dock_tick`) + thanh trạng thái mỗi 5s; trên Windows cổng localhost đang đóng treo tới hết timeout 0.6s → N hồ sơ chưa mở Chrome = N×0.6s đơ mỗi nhịp.
- Sửa: `ChromeManager` có luồng nền dò song song (TCP trước, HTTP sau) + bộ đệm; `is_running()` gọi từ luồng giao diện chỉ đọc đệm (MainWindow bật `ui_nonblocking`). Luồng nền/worker vẫn dò thật như cũ.
- HTTP tới Chrome localhost không qua proxy (bỏ đọc registry proxy mỗi lời gọi).
- 6 chỉ mục cho `commands`/`journal`; bộ chạy lệnh giữ một kết nối DB thay vì mở mới mỗi 1.5s; bảng nạp lô được ép vẽ lại (hết hiện tượng bảng trống tới khi rê chuột).

Kiểm thử: 631 test (615 cũ + 16 mới `tests/test_v61_lead_deadline.py`). Phiên bản hiển thị "V6.1" (`app.__version__ = "6.1.0"`); schema DB 10; Agent API 2.8.


## V6.2 — Đăng nhập hàng loạt muse.ai qua tinyhost.shop

Tab **🤖 Tài khoản Muse** có thêm nút **🔐 Đăng nhập hàng loạt**:

1. Dán danh sách email tinyhost (mỗi dòng `Tên | email`, `tên,email` hoặc chỉ
   email). Danh sách được điền sẵn các tài khoản chưa đăng nhập muse.ai; email
   chưa có trong app sẽ được tự thêm thành tài khoản Muse mới.
2. Với từng email, app làm tuần tự trong **Chrome riêng của tài khoản đó**:
   mở `tinyhost.shop` → dán email → bấm *Check Inbox* (ghi nhận thư cũ) →
   mở `muse.ai` → dán email vào ô *Mobile number or email* → bấm *Continue* →
   chờ ô nhập mã → quay lại tinyhost bấm *Check Inbox* tới khi có thư MỚI chứa
   mã → dán mã vào muse.ai → kiểm tra đã đăng nhập → đóng tab tinyhost và
   **tự thoát Chrome** (phiên vẫn được giữ trong thư mục Chrome riêng).
3. Đọc mã theo 3 đường: bảng hộp thư trên trang, API công khai của tinyhost
   gọi trong tab, và API gọi thẳng từ app (dự phòng). Mã của thư cũ bị bỏ qua.
   Sau 60 giây chưa có mã thì bấm *Resend* trên muse.ai; tối đa 150 giây.
4. Gặp bước không tự xử lý được (CAPTCHA, muse đòi điền thông tin tạo tài
   khoản, báo lỗi) → để nguyên cửa sổ Chrome cho bạn tự hoàn tất, đi tiếp
   tài khoản sau. Trong lúc chạy, nút đổi thành **⏹ Dừng đăng nhập hàng loạt**.
5. Kết quả từng tài khoản ghi vào Nhật ký và cột *Muse.ai* của bảng; cuối lượt
   có hộp tổng kết (thành công / cần tự hoàn tất / lỗi).

## V6.3 — Tự vận hành: quy tắc & KPI, trưởng phòng tự xử lý, chat tức thì, 2D/3D

- **Quy tắc & KPI** (Cài đặt → 📏 Quy tắc · KPI): hai bộ quy tắc (nhân viên / giám sát) có mặc định cụ thể,
  sửa được; 11 chỉ tiêu KPI. Quy tắc gửi kèm mọi lệnh (`rules`) + `GET /api/rules`. KPI chấm 0–100 từ dữ liệu
  thật ở Giám sát → 📊 KPI, và `GET /api/agents/{id}/kpi`.
- **Trưởng phòng tự xử lý sự cố** (`app/lead_autopilot.py`): thử lại lỗi tạm, chuyển việc chờ nhận/trễ hạn
  sang Muse rảnh, gia hạn 1 lần, phân công hồ sơ mồ côi, nhắc người làm; chỉ leo thang việc cần người thật
  (đăng nhập/OTP/CAPTCHA, mất kết nối). KPI trưởng phòng dưới ngưỡng N lần liên tiếp → tự đổi trưởng phòng.
  Nhật ký quyết định: Giám sát → 🤖 Trưởng phòng tự xử lý.
- **Công việc**: bỏ "Danh sách lệnh" + "Hàng đợi lệnh"; thay bằng **Bảng việc chi tiết từng bước** (bước đang làm,
  lịch sử mọi bước Muse báo, cột *Mô tả các bước* theo kế hoạch của loại việc). Thẻ kênh hiện cả việc cấp hồ sơ.
- Nút **🔌 Kết nối Muse** chuyển sang tab Tài khoản Muse.
- **Chat tức thì**: tin bạn gửi được gõ thẳng vào muse.ai trong Chrome riêng của tài khoản (`app/muse_push.py`).
- **Realtime**: mục đang xem tự làm mới trong ~1 giây khi DB đổi (PRAGMA data_version).
- **Văn phòng 2D/3D** (nút góc phải trên): 2D trải hết bề ngang, mỗi agent một thẻ lớn (việc, %, hạn, bước,
  kế hoạch bước, lịch sử, KPI); khối sự cố tự ẩn khi không có sự cố; panel chi tiết tự ẩn khi bấm vùng trống.
- **Hồ sơ**: tường trình duyệt có bố cục Tự động / 1–4 cột / Lấp đầy, thanh cỡ ô + kéo góc ô để đổi **đồng thời**
  mọi ô, hồ sơ Muse đang dùng lên đầu (có nhãn), tự tắt Chrome hồ sơ không ai dùng sau 15 phút.
- **Mắt cho Muse** (`app/cdp_vision.py`): lệnh `cdp_snapshot`, mọi `cdp_*` trả kèm snapshot trang + ảnh qua
  `GET /api/screenshots/{tên}`; `cdp_click` theo `element`/`label`/`text`/`selector`; lớp phủ "🤖 Muse: bấm …"
  trên trang để bạn thấy Muse đang làm gì.
- **File lớn** (`app/large_files.py`): tải lên theo khúc nối tiếp được + app tự kéo file từ link (HTTP Range).
- **Báo cáo kênh 08:00** (`app/daily_report.py`): Báo cáo → 📅 Báo cáo ngày.
- Sửa lỗi: console không còn in traceback `WinError 10054` khi Muse ngắt kết nối keep-alive.

## V6.3.1 — Giao diện đồng bộ AI Studio V31.1

- Bảng màu, nền, nút, ô nhập, tab, thẻ, bảng lấy đúng token của AI Studio V31.1 (`static/style.css`):
  nền `#0C0D0F`, panel `#16171B`, accent xanh chanh `#CEFC19` (chữ `#141A05` trên nút chính), bo góc 12px (thẻ) / 8px (nút, ô nhập).
- Header 56px kiểu AI Studio: logo MUSE AUTOMATION, tab chữ một dòng, mục đang chọn nền accent nhạt + viền accent; nút tiện ích chỉ icon.
- MỘT kiểu thanh tiến độ cho cả app: mảnh 4px, rãnh tối, phần chạy màu accent (`theme.paint_progress` cho chỗ tự vẽ).
- Màu trạng thái thống nhất: chờ = vàng, đang chạy = xanh dương, xong = xanh lá, lỗi = đỏ, chờ người = tím.
- Bộ giao diện cũ được tự sao lưu; khôi phục ở Hệ thống → Giao diện.
- Sửa: tab Tài khoản Muse "mất danh sách" sau khi rời tab Hồ sơ — chuyển mục nay luôn ép vẽ lại bảng.

## V6.4 — Văn phòng 3D mới

- Nút **🧊 3D** (góc phải trên tab Văn phòng) mở khung cảnh mới: mỗi tài khoản Muse là một khoang làm việc
  isometric — sàn thoi có vòng sáng màu trạng thái, bàn khối 3 mặt + màn hình hiện tiến độ, robot khối 3D màu
  riêng từng agent (nhấp nhô khi làm, gõ phím, mắt nháy, ăng-ten nháy; xám khi ngoại tuyến).
- Thẻ nổi trên đầu: chấm online, tên, trạng thái, ★ trưởng phòng, 💬 tin chưa đọc, ⚠ sự cố, việc đang làm,
  thanh tiến độ, bước đang làm.
- **Bấm dễ**: cả khoang (thẻ + robot + bàn + sàn) là một vùng bấm lớn; rê chuột khoang nổi lên, con trỏ bàn tay,
  tooltip ghi việc đang làm. Bấm vùng trống để ẩn panel chi tiết.
- Sàn ảnh nền của bản trước vẫn còn ở nút **🏢 Sàn cũ**; chế độ **▦ 2D** giữ nguyên.

## V6.4.1 — Văn phòng 3D nhẹ hơn

- Đo trên cùng máy, khung nhìn 1300×640: mỗi khung hình từ ~30 ms xuống ~4–6 ms (≈45–67% → ≈6–9% một nhân CPU ở 15 khung/giây).
- Cách làm: sàn + lưới, bàn, thẻ chữ vẽ một lần vào ảnh đệm (vẽ lại khi dữ liệu khoang đổi); mỗi nhịp chỉ vẽ lại vùng
  robot của khoang đang làm việc và đang nhìn thấy; khoang ngoài màn hình bỏ qua.
- Cửa sổ không được focus → 5 khung/giây; không agent nào đang làm → 2 khung/giây; rời tab → dừng hẳn.

## V6.4.2 — Tự nối lại khi mất kết nối Muse

- **Tailscale**: trước chỉ tự `tailscale up` một lần mỗi đợt mất nối; nay thử lại giãn dần 1 → 2 → 5 → 10 phút tới khi nối được.
- **Cầu nối của app**: mỗi 30 giây app tự gọi `/api/health`; 2 lần liền không trả lời → tự khởi động lại cầu nối (ghi Nhật ký).
- **Phía Muse**: Muse từng kết nối mà mất nhịp tim > 3 phút (còn việc mở, hoặc mới online trong 24 giờ) → app gõ lời nhắc
  "kết nối lại" vào khung chat muse.ai của đúng tài khoản đó, giãn dần 5 → 10 → 20 → 40 phút; nếu phiên muse.ai đã văng thì
  tự đăng nhập lại qua tinyhost trước. Tắt/bật ở Cài đặt → ⚙ Tự vận hành.
