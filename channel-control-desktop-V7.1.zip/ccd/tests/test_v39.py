"""V3.9: app TỰ kiểm tra và tự nối lớp vận chuyển Tailscale — module
tailscale_helper (phân tích trạng thái, phân lớp, gộp hai lớp cầu nối),
firewall_helper (rule mở cổng Agent API), và banner tab Lệnh phân lớp
(Tailscale hỏng nói Tailscale trước, không đổ hết cho "Muse chưa kết
nối" như trước)."""

import json
import stat
import sys

import pytest
from PySide6.QtWidgets import QApplication

from app import config, firewall_helper, tailscale_helper as ts
from app.store import Store
from app.ui.commands_panel import CommandsPanel


@pytest.fixture(scope="module", autouse=True)
def qapp():
    return QApplication.instance() or QApplication([])


# --------------------------------------------------------------------- #
# tailscale_helper — hàm thuần
# --------------------------------------------------------------------- #
def _status_json(backend="Running", muse_online=True, muse_present=True):
    peers = {}
    if muse_present:
        peers["nodekey:1"] = {
            "HostName": "muse",
            "TailscaleIPs": ["100.76.236.52"],
            "Online": muse_online,
        }
    peers["nodekey:2"] = {
        "HostName": "phone",
        "TailscaleIPs": ["100.64.0.9"],
        "Online": False,
    }
    return json.dumps(
        {
            "BackendState": backend,
            "Self": {"HostName": "htc", "TailscaleIPs": ["100.97.173.63"]},
            "User": {"111": {"LoginName": "ryro20142015@gmail.com"}},
            "Peer": peers,
        }
    )


def test_parse_status_running_with_muse():
    state = ts.parse_status_json(_status_json())
    assert state["connected"] is True
    assert state["needs_login"] is False
    assert state["self_name"] == "htc"
    assert state["self_ip"] == "100.97.173.63"
    assert state["account"] == "ryro20142015@gmail.com"
    assert state["muse_seen"] is True
    assert state["muse_online"] is True
    assert ts.classify({**state, "installed": True}) == "ok"


def test_parse_status_needs_login_and_stopped():
    state = ts.parse_status_json(_status_json(backend="NeedsLogin", muse_present=False))
    assert state["needs_login"] is True
    assert state["connected"] is False
    assert ts.classify({**state, "installed": True}) == "needs_login"

    state = ts.parse_status_json(_status_json(backend="Stopped"))
    assert ts.classify({**state, "installed": True}) == "down"


def test_parse_status_muse_offline_and_bad_json():
    state = ts.parse_status_json(_status_json(muse_online=False))
    assert ts.classify({**state, "installed": True}) == "no_muse"
    bad = ts.parse_status_json("không phải json")
    assert bad["backend"] == "Unknown"
    assert ts.classify({**bad, "installed": False}) == "missing"
    assert ts.classify(None) == "missing"


def test_extract_auth_url():
    out = "To authenticate, visit:\n\n\thttps://login.tailscale.com/a/1b3a823e01ffdb\n"
    assert ts.extract_auth_url(out) == "https://login.tailscale.com/a/1b3a823e01ffdb"
    assert ts.extract_auth_url("không có link") == ""


def test_layer_state_prefers_transport_problems():
    bridge_dead = {"connected": False, "ever": False, "seconds_ago": None}
    missing = {"installed": False, "backend": "Unknown"}
    level, msg = ts.layer_state(missing, bridge_dead)
    assert level == "bad" and "CHƯA CÀI" in msg

    login = ts.parse_status_json(_status_json(backend="NeedsLogin"))
    level, msg = ts.layer_state({**login, "installed": True}, bridge_dead)
    assert level == "bad" and "CHƯA ĐĂNG NHẬP" in msg

    down = ts.parse_status_json(_status_json(backend="Stopped"))
    level, msg = ts.layer_state({**down, "installed": True}, bridge_dead)
    assert level == "bad" and "CHƯA KẾT NỐI" in msg

    no_muse = ts.parse_status_json(_status_json(muse_online=False))
    level, msg = ts.layer_state({**no_muse, "installed": True}, bridge_dead)
    assert level == "warn" and "muse" in msg


def test_layer_state_ok_transport_then_bridge():
    ok_ts = {**ts.parse_status_json(_status_json()), "installed": True}
    level, msg = ts.layer_state(
        ok_ts, {"connected": True, "ever": True, "seconds_ago": 5}
    )
    assert level == "ok" and "ĐANG KẾT NỐI" in msg
    level, msg = ts.layer_state(
        ok_ts, {"connected": False, "ever": True, "seconds_ago": 999}
    )
    assert level == "warn" and "MẤT KẾT NỐI" in msg
    level, msg = ts.layer_state(
        ok_ts, {"connected": False, "ever": False, "seconds_ago": None}
    )
    assert level == "bad" and "PHIẾU KẾT NỐI" in msg
    # Không có trạng thái TS: hành vi V3.8 giữ nguyên.
    level, msg = ts.layer_state(
        None, {"connected": False, "ever": False, "seconds_ago": None}
    )
    assert level == "bad" and "CHƯA CÓ MUSE NÀO KẾT NỐI" in msg


# --------------------------------------------------------------------- #
# tailscale_helper — chạy CLI giả
# --------------------------------------------------------------------- #
def _fake_tailscale(tmp_path, body: str) -> str:
    script = tmp_path / "tailscale"
    script.write_text("#!/bin/sh\n" + body, encoding="utf-8")
    script.chmod(script.stat().st_mode | stat.S_IEXEC)
    return str(script)


@pytest.mark.skipif(sys.platform.startswith("win"), reason="shell script giả chỉ chạy trên *nix")
def test_run_status_and_up_with_fake_cli(tmp_path):
    exe = _fake_tailscale(
        tmp_path,
        'if [ "$1" = "status" ]; then cat <<\'EOF\'\n'
        + _status_json()
        + "\nEOF\nfi\n",
    )
    state = ts.run_status(exe)
    assert state["installed"] is True and state["connected"] is True
    assert ts.run_status(None)["installed"] is False
    result = ts.run_up(exe)
    assert result["ok"] is True and result["auth_url"] == ""


@pytest.mark.skipif(sys.platform.startswith("win"), reason="shell script giả chỉ chạy trên *nix")
def test_run_up_captures_auth_url_on_timeout(tmp_path):
    exe = _fake_tailscale(
        tmp_path,
        'echo "To authenticate, visit: https://login.tailscale.com/a/xyz123"\n'
        "sleep 10\n",
    )
    result = ts.run_up(exe, timeout=1.0)
    assert result["ok"] is False
    assert result["auth_url"] == "https://login.tailscale.com/a/xyz123"


def test_find_tailscale_env_override(tmp_path, monkeypatch):
    fake = tmp_path / "tailscale.exe"
    fake.write_text("x", encoding="utf-8")
    monkeypatch.setenv("CCD_TAILSCALE_PATH", str(fake))
    assert ts.find_tailscale() == str(fake)
    assert ts.find_tailscale(override=str(fake)) == str(fake)


# --------------------------------------------------------------------- #
# firewall_helper
# --------------------------------------------------------------------- #
def test_firewall_scripts():
    script = firewall_helper.build_add_rule_script(19500)
    assert firewall_helper.RULE_NAME in script
    assert "19500" in script and "Inbound" in script and "Any" in script
    assert "Remove-NetFirewallRule" in firewall_helper.build_remove_rule_script()
    # Không phải Windows: không khởi chạy được (và không ném lỗi).
    if not sys.platform.startswith("win"):
        assert firewall_helper.run_add_rule(19500) is False


# --------------------------------------------------------------------- #
# UI: banner phân lớp + cấu hình
# --------------------------------------------------------------------- #
def test_panel_banner_uses_tailscale_layer(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    panel = CommandsPanel(store)
    panel.set_tailscale_state({"installed": False, "backend": "Unknown"})
    assert "Tailscale" in panel.bridge_label.text()
    assert "CHƯA CÀI" in panel.bridge_label.text()
    ok_ts = {**ts.parse_status_json(_status_json()), "installed": True}
    panel.set_tailscale_state(ok_ts)
    assert "PHIẾU KẾT NỐI" in panel.bridge_label.text()
    store.note_bridge_activity()
    panel.set_tailscale_state(ok_ts)
    assert "ĐANG KẾT NỐI" in panel.bridge_label.text()


def test_auto_connect_setting_default():
    assert config.DEFAULT_SETTINGS["ts_auto_connect"] is True
