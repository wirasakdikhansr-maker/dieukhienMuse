"""V4.2 — đường lệnh: điều phối theo sự kiện ở MỌI đường tạo
(O-27), lọc danh sách API trước LIMIT (O-28), progress không tự
claim lệnh 'queued' (O-05), vòng đời cờ + step khi promote (O-03/
O-04), phụ thuộc không tồn tại (O-08), khoá chống trùng toàn yêu
cầu (O-02), công bằng backlog (O-13), sức khoẻ vòng tự động (O-06).
"""

import json

import pytest
from PySide6.QtWidgets import QApplication

from app import automation_health, config
from app.agent_server import AgentServer
from app.dispatcher import Dispatcher
from app.store import Store
from app.ui.commands_panel import CommandsPanel
from test_agent_server import FakeManager, stub_scan


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def world(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    store = Store(config.db_path(data_dir))
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    yield {"store": store, "profile": profile, "agent": agent, "data_dir": data_dir}
    store.close()


def _queued_claude(store, profile, **kwargs):
    return store.create_command(
        "optimize",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        **kwargs,
    )


# --------------------------------------------------------------------- #
# O-27 — dispatch-now ở mọi đường tạo
# --------------------------------------------------------------------- #
def test_ui_create_fires_dispatch_now(qapp, world):
    fired = []
    panel = CommandsPanel(
        world["store"], dispatch_now=lambda: fired.append(1)
    )
    panel.type_combo.setCurrentIndex(
        panel.type_combo.findData("free")
    )
    panel.instruction_edit.setPlainText("Làm việc tự do cho kênh")
    panel._on_create()
    assert fired == [1]
    assert "Đã tạo lệnh" in panel.form_status.text()
    panel.close()


def test_api_enqueue_fires_dispatch_now(world):
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    fired = []
    server.request_dispatch_now = lambda: fired.append(1)
    body = json.dumps({
        "type": "free",
        "profile": world["profile"]["slug"],
        "instruction": "Tối ưu EP01",
    }).encode("utf-8")
    status, payload = server.dispatch(
        "POST", "/api/commands",
        {"X-Agent-Token": server.token}, body,
    )
    assert status == 202
    assert payload["ok"] is True
    assert fired == [1]


# --------------------------------------------------------------------- #
# O-28 — lọc trạng thái TRƯỚC limit ở danh sách cho agent
# --------------------------------------------------------------------- #
def test_agent_listing_waiting_not_crowded_out(world):
    store = world["store"]
    profile, agent = world["profile"], world["agent"]
    old_waiting = _queued_claude(store, profile)
    store._conn.execute(
        "UPDATE commands SET status = 'waiting_muse' WHERE id = ?",
        (old_waiting["id"],),
    )
    store._conn.commit()
    # 51 lệnh MỚI HƠN ở trạng thái khác trong cùng phạm vi agent.
    for _ in range(51):
        newer = _queued_claude(store, profile)
        store.finish_command(newer["id"], "done", result="xong")
    rows = store.list_commands_for_agent(
        agent["id"], limit=50, status="waiting_muse"
    )
    assert [r["id"] for r in rows] == [old_waiting["id"]]


# --------------------------------------------------------------------- #
# O-05 — progress không tự claim lệnh queued
# --------------------------------------------------------------------- #
def test_store_progress_on_queued_does_not_claim(world):
    store = world["store"]
    cmd = _queued_claude(store, world["profile"])
    row = store.update_command_progress(
        cmd["id"], progress=50, step="đang làm",
        agent_id=world["agent"]["id"],
    )
    assert row["status"] == "queued"
    assert (row["progress"] or 0) == 0
    assert row["lease_agent_id"] is None


def test_api_progress_on_queued_is_409(world):
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    cmd = _queued_claude(world["store"], world["profile"])
    agent = world["agent"]
    status, payload = server.dispatch(
        "POST", f"/api/commands/{cmd['id']}/progress",
        {
            "X-Agent-Id": str(agent["id"]),
            "X-Agent-Token": agent["token"],
        },
        json.dumps({"progress": 30}).encode("utf-8"),
    )
    assert status == 409
    assert payload["ok"] is False
    assert world["store"].get_command(cmd["id"])["status"] == "queued"


def test_api_progress_on_waiting_still_implicitly_claims(world):
    """Đ1 giữ nguyên: waiting_muse + progress đầu tiên → running + lease."""
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    cmd = _queued_claude(world["store"], world["profile"])
    world["store"]._conn.execute(
        "UPDATE commands SET status = 'waiting_muse' WHERE id = ?",
        (cmd["id"],),
    )
    world["store"]._conn.commit()
    agent = world["agent"]
    status, payload = server.dispatch(
        "POST", f"/api/commands/{cmd['id']}/progress",
        {
            "X-Agent-Id": str(agent["id"]),
            "X-Agent-Token": agent["token"],
        },
        json.dumps({"progress": 10, "step": "bắt đầu"}).encode("utf-8"),
    )
    assert status == 200
    row = world["store"].get_command(cmd["id"])
    assert row["status"] == "running"
    assert row["lease_agent_id"] == agent["id"]


# --------------------------------------------------------------------- #
# O-03/O-04 — promote thay step + dọn cờ; resume dọn cờ
# --------------------------------------------------------------------- #
def test_promote_replaces_held_step_and_clears_flags(world):
    store = world["store"]
    cmd = _queued_claude(store, world["profile"])
    store.update_command_progress(
        cmd["id"], step="Chưa có Muse phụ trách hồ sơ này — chờ phân công…"
    )
    store.update_command_payload_flags(
        cmd["id"],
        set_flags={"dispatch_warned_no_owner": True, "warned_no_agent": True},
    )
    promoted = Dispatcher(store, data_dir=world["data_dir"]).tick()
    assert [c["id"] for c in promoted] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "waiting_muse"
    assert row["step"] == "Đang chờ Muse nhận lệnh…"
    assert "dispatch_warned_no_owner" not in (row["payload"] or {})
    assert "warned_no_agent" not in (row["payload"] or {})


def test_resume_clears_internal_flags(world):
    store = world["store"]
    cmd = _queued_claude(store, world["profile"])
    store.set_command_needs_user(cmd["id"], "Cần 2FA")
    store.update_command_payload_flags(
        cmd["id"], set_flags={"warned_no_agent": True}
    )
    row = store.resume_command(cmd["id"])
    assert row["status"] == "queued"
    assert "warned_no_agent" not in (row["payload"] or {})


# --------------------------------------------------------------------- #
# O-08 — phụ thuộc không tồn tại → needs_user
# --------------------------------------------------------------------- #
def test_missing_dependency_moves_to_needs_user(world):
    store = world["store"]
    cmd = _queued_claude(
        store, world["profile"], depends_on="deadbeef" + "0" * 24
    )
    Dispatcher(store, data_dir=world["data_dir"]).tick()
    row = store.get_command(cmd["id"])
    assert row["status"] == "needs_user"
    assert "không tồn tại" in (row["result"] or "")


# --------------------------------------------------------------------- #
# O-02 — khoá mặc định gồm toàn bộ yêu cầu
# --------------------------------------------------------------------- #
def test_default_key_distinguishes_instructions():
    base = dict(source="api", type="optimize", profile_key="slug-a", payload={})
    k1 = Store.default_idempotency_key(**base, instruction="Tối ưu EP01")
    k2 = Store.default_idempotency_key(**base, instruction="Tối ưu EP02")
    k3 = Store.default_idempotency_key(
        **base, instruction="Tối ưu EP01", channel_id="UC1"
    )
    k4 = Store.default_idempotency_key(**base, instruction="Tối ưu EP01")
    assert k1 != k2 and k1 != k3
    assert k1 == k4  # cùng yêu cầu → cùng khoá (chống trùng còn tác dụng)


def test_api_enqueue_different_instructions_not_deduplicated(world):
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )

    def enqueue(instruction):
        body = json.dumps({
            "type": "free",
            "profile": world["profile"]["slug"],
            "instruction": instruction,
        }).encode("utf-8")
        return server.dispatch(
            "POST", "/api/commands",
            {"X-Agent-Token": server.token}, body,
        )

    s1, p1 = enqueue("Tối ưu EP01")
    s2, p2 = enqueue("Tối ưu EP02")
    assert s1 == s2 == 202
    assert p1["command_id"] != p2["command_id"]
    assert not p2.get("deduplicated")


# --------------------------------------------------------------------- #
# O-13 — backlog > 200 vẫn xét tới lệnh cũ nhất
# --------------------------------------------------------------------- #
def test_dispatcher_pages_beyond_200_backlog(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    store = Store(config.db_path(data_dir))
    try:
        agent = store.create_agent("Muse A", "a@claude.ai")
        profiles = [
            store.add_profile(f"Kenh {i}", f"k{i}@gmail.com")
            for i in range(205)
        ]
        # assign_profiles GÁN TOÀN BỘ tập hồ sơ của agent — gọi một
        # lần với đủ 205 hồ sơ.
        store.assign_profiles(agent["id"], [p["id"] for p in profiles])
        ids = []
        for profile in profiles:  # lệnh cũ nhất tạo trước
            ids.append(_queued_claude(store, profile)["id"])
        promoted = Dispatcher(store, data_dir=data_dir).tick()
        assert {c["id"] for c in promoted} == set(ids)
    finally:
        store.close()


# --------------------------------------------------------------------- #
# O-12 (phần an toàn của V4.2) — heartbeat không ghi trùng, bản nhẹ
# bỏ qua UPDATE khi nhịp còn tươi, list_agents giữ nguyên kết quả
# --------------------------------------------------------------------- #
def test_heartbeat_endpoint_sets_current_command_once(world):
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    agent = world["agent"]
    headers = {
        "X-Agent-Id": str(agent["id"]),
        "X-Agent-Token": agent["token"],
    }
    status, payload = server.dispatch(
        "POST", f"/api/agents/{agent['id']}/heartbeat", headers,
        json.dumps({"current_command_id": "cmd-123"}).encode("utf-8"),
    )
    assert status == 200
    assert payload["agent"]["current_command_id"] == "cmd-123"
    row = world["store"].get_agent(agent["id"])
    assert row["current_command_id"] == "cmd-123"
    assert row["last_seen_at"]


def test_heartbeat_light_skips_write_when_fresh(world):
    store = world["store"]
    agent = world["agent"]
    first = store.touch_agent_heartbeat_light(agent["id"], "cmd-1")
    stamp1 = first["last_seen_at"]
    second = store.touch_agent_heartbeat_light(agent["id"], "cmd-1")
    assert second["last_seen_at"] == stamp1  # không UPDATE lại
    third = store.touch_agent_heartbeat_light(agent["id"], "cmd-2")
    assert third["current_command_id"] == "cmd-2"  # đổi lệnh → ghi


def test_list_agents_still_returns_assignments(world):
    agents = world["store"].list_agents()
    mine = [a for a in agents if a["id"] == world["agent"]["id"]][0]
    assert mine["profile_ids"] == [world["profile"]["id"]]


# --------------------------------------------------------------------- #
# O-06 — lỗi pipeline được ghi vào automation health; hồi phục tự xoá
# --------------------------------------------------------------------- #
def test_auto_tick_failure_recorded_and_recovery_clears(world):
    server = AgentServer(
        data_dir=world["data_dir"],
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    from app import lease_sweeper

    original = lease_sweeper.LeaseSweeper.sweep_once

    def boom(self, now=None):
        raise RuntimeError("sweeper vỡ để kiểm thử")

    lease_sweeper.LeaseSweeper.sweep_once = boom
    try:
        server._run_auto_tick()  # không được ném ra ngoài
    finally:
        lease_sweeper.LeaseSweeper.sweep_once = original
    health = automation_health.read_health(world["store"])
    assert health and health["degraded"] is True
    assert health["source"] == "sweeper"
    # Nhịp sau chạy sạch → degraded tự hết.
    server._run_auto_tick()
    health = automation_health.read_health(world["store"])
    assert health and health["degraded"] is False
