"""V4.3 — Kiểm thử giao diện mới (offscreen):

- Mục Công việc: bảng việc 3 dạng (Danh sách/Ô/Nhánh) trên work model,
  bấm một việc → chọn đúng lệnh trong bảng lệnh bên dưới.
- Hàng Skill trong form tạo lệnh: chọn skill → mẫu điền vào ô Nội dung.
- Văn phòng co giãn: mức mật độ theo số agent (24 agent → lưới vừa),
  panel chi tiết có khối việc + dải nhánh.
- Theme: áp preset qua cửa sổ chính đổi stylesheet toàn app; Mission
  Control giữ nguyên APP_QSS.
- Tab Tài khoản Muse: báo cáo Kiểm tra kết nối (G6) + cột Phiếu.
"""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import config, skills_lib  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import theme  # noqa: E402
from app.ui.main_window import SEC_WORK, MainWindow  # noqa: E402
from app.ui.office_view import TIER_MEDIUM, OfficeView, density_tier  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1", "name": "Kênh Chính",
            "handle": "@kenhchinh", "url": "https://www.youtube.com/channel/UC1",
            "subs": 10, "video_count": 3,
        },
    )
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    command = store.create_command(
        "create_video",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        channel_id="UC1",
        instruction="Làm video về chủ đề kiểm thử",
        agent_id=agent["id"],
        status="queued",
    )
    win = MainWindow(store, ChromeManager(), settings)
    win._fixture_refs = (profile, agent, command)
    yield win
    win.close()
    store.close()


# --------------------------------------------------------------------------- #
# Mục Công việc — bảng việc 3 dạng
# --------------------------------------------------------------------------- #
def test_work_panel_three_views_render(window):
    window._switch_section(SEC_WORK)
    panel = window.work_panel
    panel.refresh()
    assert panel.summary_label.text()  # dải tổng hợp có nội dung
    for mode in ("list", "cards", "tree"):
        panel._set_view(mode)
        assert panel._view_mode == mode
    panel._set_view("list")
    # Dạng Danh sách: có dòng agent + dòng lệnh con mang id lệnh.
    tree = panel.list_tree
    assert tree.topLevelItemCount() >= 1
    top = tree.topLevelItem(0)
    assert top.childCount() >= 1
    _profile, _agent, command = window._fixture_refs
    assert top.child(0).data(0, 0x0100) == command["id"] or any(
        top.child(i).data(0, 0x0100) == command["id"]
        for i in range(top.childCount())
    )


def test_work_panel_choice_selects_command_below(window):
    _profile, _agent, command = window._fixture_refs
    window._switch_section(SEC_WORK)
    window.work_panel.command_chosen.emit(command["id"])
    assert window.commands_panel._selected_command_id() == command["id"]


def test_work_view_mode_remembered(window):
    panel = window.work_panel
    panel._set_view("cards")
    assert window._settings.get("work_view_mode") == "cards"
    panel._set_view("list")


def test_open_command_in_work_from_office_signal(window):
    _profile, _agent, command = window._fixture_refs
    window._open_command_in_work(command["id"])
    assert window.sections.currentIndex() == SEC_WORK
    assert window.commands_panel._selected_command_id() == command["id"]


# --------------------------------------------------------------------------- #
# Hàng Skill trong form tạo lệnh (G3)
# --------------------------------------------------------------------------- #
def test_skill_row_fills_instruction(window, tmp_path):
    panel = window.commands_panel
    base = panel._skills_base()
    skills_lib.save_skill(
        "Mẫu kiểm thử", "Làm video cho {channel} thuộc {profile}", base
    )
    panel._refresh_skill_combo()
    index = panel.skill_combo.findData(
        skills_lib.list_skills(base)[0].slug
    )
    assert index >= 0
    panel.skill_combo.setCurrentIndex(index)
    text = panel.instruction_edit.toPlainText()
    assert "{channel}" not in text and "{profile}" not in text
    assert "Làm video cho" in text


# --------------------------------------------------------------------------- #
# Văn phòng co giãn (G2)
# --------------------------------------------------------------------------- #
def test_density_tier_thresholds():
    assert density_tier(2, "auto") == "diorama"
    assert density_tier(24, "auto") == TIER_MEDIUM
    assert density_tier(50, "auto") == "compact"
    assert density_tier(150, "auto") == "wall"
    assert density_tier(150, "roomy") == "diorama"
    assert density_tier(2, "mini") == "wall"


def test_office_scales_to_24_agents(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    store = Store(config.db_path(tmp_path))
    for i in range(24):
        store.create_agent(f"Agent{i:02d}", f"agent{i}@example.com")
    view = OfficeView(store, settings=config.load_settings(tmp_path))
    view.refresh()
    assert view._tier == TIER_MEDIUM
    assert len(view._desk_bounds) == 24
    first_id = view._model["desks_all"][0]["agent_id"]
    view.select_agent(first_id)
    assert view.selected_agent_id == first_id
    # Panel chi tiết có khối việc + dải nhánh (4 nhãn) của V4.3.
    assert len(view.work_buttons) == 6
    assert len(view.branch_labels) == 4
    view.close()
    store.close()


# --------------------------------------------------------------------------- #
# Theme (G4)
# --------------------------------------------------------------------------- #
def test_theme_apply_changes_global_stylesheet(window, qapp):
    window._apply_theme(theme.MISSION_TOKENS, save=False)
    assert qapp.styleSheet() == theme.APP_QSS
    window._apply_theme(theme.PRESETS["light"], save=False)
    assert theme.PRESETS["light"].bg in qapp.styleSheet()
    window._apply_theme(theme.MISSION_TOKENS, save=False)
    assert qapp.styleSheet() == theme.APP_QSS


def test_theme_panel_present_in_system_section(window):
    labels = [
        window.system_tabs.tabText(i) for i in range(window.system_tabs.count())
    ]
    assert labels == ["📓 Nhật ký", "⚙ Cài đặt", "🎨 Giao diện"]
    report_labels = [
        window.reports_tabs.tabText(i)
        for i in range(window.reports_tabs.count())
    ]
    assert report_labels == ["📈 Tổng quan", "📊 Báo cáo kênh", "🩺 Kiểm tra", "📅 Báo cáo ngày"]


# --------------------------------------------------------------------------- #
# Tài khoản Muse — sức khoẻ kết nối (G6)
# --------------------------------------------------------------------------- #
def test_agents_connection_report_and_ticket_column(window):
    panel = window.agents_panel
    panel.refresh()
    # V5.0 (gộp V4.6): cột "Kết nối" thêm ở cuối → 9 cột; 🎫 Phiếu
    # vẫn ở index 7.
    assert panel.table.columnCount() == 9
    assert panel.table.item(0, 7) is not None  # cột 🎫 Phiếu có dữ liệu
    _profile, agent, _command = window._fixture_refs
    report = panel._connection_report(agent)
    assert "Heartbeat" in report
    assert "Phiếu kết nối" in report
    assert "Server cầu nối" in report
    assert panel.check_button is not None


def test_agents_login_alert_shows_when_logged_out(window):
    panel = window.agents_panel
    _profile, agent, _command = window._fixture_refs
    window._store.set_agent_web_state(agent["id"], "out")
    panel.refresh()
    # isHidden() = cờ hiển thị của chính nhãn (cửa sổ test không show
    # thật nên isVisible() theo chuỗi cha luôn False).
    assert not panel.login_alert_label.isHidden()
    window._store.set_agent_web_state(agent["id"], "in")
    panel.refresh()
    assert panel.login_alert_label.isHidden()
