"""V6.8 — hình agent 3D tuỳ chỉnh: mẫu nhân vật, màu, kích thước, chung/riêng từng agent."""

from __future__ import annotations

import os

import pytest

from app.store import Store


@pytest.fixture(scope="module")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_resolve_style_default_agent_and_lead_overrides():
    from app.ui import avatars

    settings = {"office_avatar": {"default": {"model": "human", "body": "#123456"},
                                  "lead": {"model": "astronaut"},
                                  "agents": {"7": {"model": "cat", "size": 3}}}}
    assert avatars.resolve_style({})["model"] == "robot"
    assert avatars.resolve_style(settings)["model"] == "human"
    assert avatars.resolve_style(settings, None, lead=True)["model"] == "astronaut"
    style = avatars.resolve_style(settings, 7)
    assert style["model"] == "cat" and style["body"] == "#123456" and style["size"] == 1.8  # kẹp kích thước
    assert avatars.resolve_style({"office_avatar": {"default": {"model": "khong-co"}}})["model"] == "robot"
    assert avatars.top_height(avatars.resolve_style(settings, 7)) > avatars.top_height(avatars.resolve_style({}))


@pytest.mark.parametrize("model", ["robot", "human", "astronaut", "orb", "cat"])
def test_every_model_paints_every_state(qapp, model):
    from app.ui.office_iso import _IsoStage

    stage = _IsoStage()
    stage.resize(900, 640)
    stage.avatar_settings = {"office_avatar": {"default": {"model": model, "body": "#6CC7FF", "size": 1.4}}}
    desks = [{"agent_id": i, "name": f"A{i}", "state": st, "lead": False, "pct": 30, "bubble": None,
              "chip": {"icon": "•", "text": st, "tone": "working"}}
             for i, st in enumerate(["working", "receive", "report", "error", "idle", "sleep", "queued", "night"], 1)]
    lead = {"agent_id": 99, "name": "TP", "state": "lead", "lead": True, "bubble": None, "chip": None}
    stage.set_data({"mode": "work", "lead": lead, "desks": desks, "events": [], "now": ""})
    image = stage.grab()
    assert not image.isNull() and len(stage._hits) == len(desks) + 1


def test_dialog_edits_per_agent_and_saves(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.avatar_dialog import AvatarDialog

    store = Store(tmp_path / "d.db")
    agent = store.create_agent("Muse 02", "b@x.com")
    settings = {}
    dialog = AvatarDialog(settings, store)
    dialog.model.setCurrentIndex(dialog.model.findData("orb"))
    dialog.body.set_value("#C792EA")
    dialog.on_changed()
    dialog.target.setCurrentIndex(dialog.target.findData(str(agent["id"])))
    dialog.model.setCurrentIndex(dialog.model.findData("cat"))
    dialog.size.setValue(150)
    dialog.accept()
    cfg = settings["office_avatar"]
    assert cfg["default"]["model"] == "orb" and cfg["default"]["body"] == "#C792EA"
    assert cfg["agents"][str(agent["id"])]["model"] == "cat" and cfg["agents"][str(agent["id"])]["size"] == 1.5
    # bỏ tuỳ chỉnh riêng → về mặc định
    dialog2 = AvatarDialog(settings, store)
    dialog2.target.setCurrentIndex(dialog2.target.findData(str(agent["id"])))
    dialog2._reset_target()
    assert str(agent["id"]) not in dialog2.result_config()["agents"]


def test_office_view_has_avatar_button(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.office_iso import OfficeIsoView

    store = Store(tmp_path / "d.db")
    settings = {"office_avatar": {"default": {"model": "human"}}}
    view = OfficeIsoView(store, settings)
    assert view.avatar_button.text().startswith("🎨")
    assert view.stage.avatar_settings is settings


def test_office_theme_presets_overrides_and_night():
    from app.ui import office_themes

    base = office_themes.resolve_theme({})
    assert base["accent"] == "#CEFC19" and all(base["props"].values())
    wood = office_themes.resolve_theme({"office_theme": {"preset": "warm_wood", "floor": "#112233",
                                                         "props": {"plants": False}}})
    assert wood["floor"] == "#112233" and wood["pattern"] == "planks" and wood["props"]["plants"] is False
    night = office_themes.resolve_theme({"office_theme": {"preset": "light_minimal"}}, night=True)
    assert night["floor"] != office_themes.PRESETS["light_minimal"]["floor"]  # ban đêm tối đi
    assert office_themes.resolve_theme({"office_theme": {"preset": "khong-co"}})["accent"] == "#CEFC19"


@pytest.mark.parametrize("preset", ["modern_dark", "warm_wood", "corporate_blue", "light_minimal", "neon_night"])
def test_every_room_preset_paints_day_and_night(qapp, preset):
    from app.ui.office_iso import _IsoStage

    stage = _IsoStage()
    stage.resize(900, 640)
    stage.avatar_settings = {"office_theme": {"preset": preset, "pattern": "tiles"}}
    desks = [{"agent_id": 1, "name": "A", "state": "working", "lead": False, "pct": 30, "bubble": None, "chip": None}]
    for mode in ("work", "off"):
        stage.set_data({"mode": mode, "lead": None, "desks": desks, "events": [], "now": ""})
        assert not stage.grab().isNull()


def test_dialog_room_tab_saves_theme(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.avatar_dialog import AvatarDialog

    settings = {}
    dialog = AvatarDialog(settings, Store(tmp_path / "d.db"))
    dialog.preset.setCurrentIndex(dialog.preset.findData("neon_night"))
    dialog.desk_color.set_value("#445566")
    dialog.prop_checks["lounge"].setChecked(False)
    dialog.on_room_changed()
    dialog.accept()
    theme_cfg = settings["office_theme"]
    assert theme_cfg["preset"] == "neon_night" and theme_cfg["desk"] == "#445566"
    assert theme_cfg["props"]["lounge"] is False
