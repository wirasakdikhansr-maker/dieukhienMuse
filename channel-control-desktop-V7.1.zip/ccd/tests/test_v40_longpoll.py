"""V4.0 (H6) — Long-poll GET /api/commands?wait=N.

Yêu cầu sống còn của người dùng: lệnh vừa được dispatcher đẩy lên
'waiting_muse' là phía Muse đang long-poll phải nhận NGAY (không
chờ hết timeout) — kiểm chứng bằng luồng phụ gọi dispatch với wait=5
rồi tạo lệnh + notify ở luồng chính. Phạm vi agent giữ nguyên kể cả
sau khi thức dậy vì tín hiệu.
"""

import json
import threading
import time

import pytest

from app import config
from app.agent_server import AgentServer
from app.store import Store
from test_agent_server import FakeManager, stub_scan


@pytest.fixture()
def world(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("Kenh A", "a@gmail.com")
    agent_a = seed.create_agent("Muse A", "a@claude.ai")
    agent_b = seed.create_agent("Muse B", "b@claude.ai")
    seed.assign_profiles(agent_a["id"], [profile["id"]])
    seed.close()
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    return {
        "server": server,
        "data_dir": data_dir,
        "profile": profile,
        "agent_a": agent_a,
        "agent_b": agent_b,
    }


def agent_headers(agent):
    return {"X-Agent-Id": str(agent["id"]), "X-Agent-Token": agent["token"]}


def create_waiting(world):
    store = Store(config.db_path(world["data_dir"]))
    try:
        return store.create_command(
            "optimize",
            source="ui",
            profile_id=world["profile"]["id"],
            profile_slug=world["profile"]["slug"],
            status="waiting_muse",
        )
    finally:
        store.close()


def test_wait_returns_promptly_when_command_appears(world):
    outcome = {}

    def waiter():
        started = time.monotonic()
        status, payload = world["server"].dispatch(
            "GET",
            "/api/commands?status=waiting_muse&wait=5",
            agent_headers(world["agent_a"]),
            b"",
        )
        outcome["elapsed"] = time.monotonic() - started
        outcome["status"] = status
        outcome["payload"] = payload

    thread = threading.Thread(target=waiter)
    thread.start()
    time.sleep(0.4)
    cmd = create_waiting(world)
    world["server"].notify_commands_changed()
    thread.join(timeout=6)
    assert not thread.is_alive()
    assert outcome["elapsed"] < 4.0  # về sớm, không chờ cạn 5 giây
    assert outcome["status"] == 200
    assert [c["id"] for c in outcome["payload"]["commands"]] == [cmd["id"]]


def test_wait_times_out_with_empty_list(world):
    started = time.monotonic()
    status, payload = world["server"].dispatch(
        "GET",
        "/api/commands?status=waiting_muse&wait=1",
        agent_headers(world["agent_a"]),
        b"",
    )
    elapsed = time.monotonic() - started
    assert status == 200
    assert payload["commands"] == []
    assert elapsed >= 0.9


def test_longpoll_respects_agent_scope_after_wake(world):
    outcome = {}

    def waiter():
        status, payload = world["server"].dispatch(
            "GET",
            "/api/commands?status=waiting_muse&wait=3",
            agent_headers(world["agent_b"]),  # không phụ trách hồ sơ này
            b"",
        )
        outcome["payload"] = payload

    thread = threading.Thread(target=waiter)
    thread.start()
    time.sleep(0.3)
    create_waiting(world)
    world["server"].notify_commands_changed()
    thread.join(timeout=5)
    assert outcome["payload"]["commands"] == []
