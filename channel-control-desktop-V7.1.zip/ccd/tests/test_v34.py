"""Kiểm thử V3.4: kho mật khẩu + trợ lý đăng nhập (cookies trước, mật
khẩu tự điền sau, dừng ở bước xác minh), snapshots/growth cho báo cáo,
avatar trong parser, quy tắc tự động 'Tạo video (Muse)' gắn đúng
Muse phụ trách, và các hàm thuần của báo cáo/hộp thoại."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app import credentials_vault, login_helper, parser
from app.automation import AutomationEngine
from app.store import Store


# --------------------------------------------------------------------- #
# Kho mật khẩu
# --------------------------------------------------------------------- #
def test_credentials_vault_roundtrip(tmp_path):
    assert credentials_vault.load_password("ho-so", base=tmp_path) is None
    credentials_vault.save_password("ho-so", "a@gmail.com", "mat-khau", base=tmp_path)
    data = credentials_vault.load_password("ho-so", base=tmp_path)
    assert data["gmail"] == "a@gmail.com" and data["password"] == "mat-khau"
    assert credentials_vault.has_password("ho-so", base=tmp_path)
    assert credentials_vault.delete_password("ho-so", base=tmp_path)
    assert credentials_vault.load_password("ho-so", base=tmp_path) is None


# --------------------------------------------------------------------- #
# Trợ lý đăng nhập với client giả
# --------------------------------------------------------------------- #
class FakeLoginClient:
    """Giả lập các trang: youtube (chưa login) -> trang email -> trang
    mật khẩu -> youtube (đã login). mode='challenge': sau email thì
    Google đòi xác minh."""

    def __init__(self, mode="password"):
        self.mode = mode
        self.stage = "start"
        self.filled = []

    def navigate(self, url):
        if "accounts.google.com" in url:
            self.stage = "email"

    def evaluate(self, expression, timeout=None):
        if "LOGGED_IN" in expression:
            return {
                "loggedIn": self.stage == "done",
                "href": "https://www.youtube.com/" if self.stage == "done" else "https://www.youtube.com/",
            }
        if "getCookies" in expression or "Storage" in expression:
            return None
        if "ccd:login-state" in expression:
            return {
                "url": "https://accounts.google.com/",
                "hasEmail": self.stage == "email",
                "hasPassword": self.stage == "password",
                "challenge": self.stage == "challenge",
                "wrongPassword": False,
            }
        if "ccd:login-fill" in expression:
            if self.stage == "email":
                self.filled.append("email")
                self.stage = "challenge" if self.mode == "challenge" else "password"
            elif self.stage == "password":
                self.filled.append("password")
                self.stage = "done"
            return "ok"
        if "readyState" in expression:
            return "complete"
        return None


def _profile_with_password(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Ho so", "a@gmail.com")
    store.close()
    return profile


def test_login_helper_password_autofill(monkeypatch, tmp_path):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    profile = _profile_with_password(tmp_path)
    credentials_vault.save_password(profile["slug"], "a@gmail.com", "mat-khau")
    client = FakeLoginClient()
    result = login_helper.attempt_login(client, profile, lambda m: None, timeout_s=20)
    assert result["status"] == "password"
    assert client.filled == ["email", "password"]


def test_login_helper_stops_at_challenge(monkeypatch, tmp_path):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    profile = _profile_with_password(tmp_path)
    credentials_vault.save_password(profile["slug"], "a@gmail.com", "mat-khau")
    client = FakeLoginClient(mode="challenge")
    result = login_helper.attempt_login(client, profile, lambda m: None, timeout_s=20)
    assert result["status"] == "needs_user"
    # Không bao giờ điền mật khẩu sau khi gặp bước xác minh.
    assert client.filled == ["email"]


def test_login_helper_needs_manual_without_material(monkeypatch, tmp_path):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    profile = _profile_with_password(tmp_path)
    client = FakeLoginClient()
    result = login_helper.attempt_login(client, profile, lambda m: None, timeout_s=5)
    assert result["status"] == "needs_manual"


# --------------------------------------------------------------------- #
# Snapshots + growth
# --------------------------------------------------------------------- #
def test_channel_snapshots_and_growth(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    assert store.schema_version >= 5
    profile = store.add_profile("Ho so", "a@gmail.com")
    channel = {"channel_id": "UCx", "subs": 100, "video_count": 10}
    store.record_channel_snapshot(profile["id"], channel)
    # Lùi dòng hôm nay thành 8 ngày trước, rồi ghi snapshot hôm nay.
    store._conn.execute(
        "UPDATE channel_snapshots SET day = date('now', '-8 days')"
    )
    store._conn.commit()
    store.record_channel_snapshot(
        profile["id"], {"channel_id": "UCx", "subs": 150, "video_count": 13}
    )
    growth = store.channel_growth(profile["id"], "UCx")
    assert growth["subs_delta_7d"] == 50
    assert growth["videos_delta_7d"] == 3
    assert growth["series"] == [100, 150]
    # Quét lại trong ngày không tạo dòng trùng.
    store.record_channel_snapshot(
        profile["id"], {"channel_id": "UCx", "subs": 151, "video_count": 13}
    )
    assert len(store.list_channel_snapshots(profile["id"], "UCx")) == 2
    store.close()


# --------------------------------------------------------------------- #
# Parser: avatar
# --------------------------------------------------------------------- #
def test_parser_extracts_avatar_url():
    data = {
        "multiPageMenuRenderer": {
            "sections": [
                {
                    "accountItemSectionRenderer": {
                        "contents": [
                            {
                                "accountItemRenderer": {
                                    "accountId": "UC" + "a" * 22,
                                    "accountName": {"simpleText": "Kênh A"},
                                    "channelHandle": {"simpleText": "@KenhA"},
                                    "accountPhoto": {
                                        "thumbnails": [
                                            {"url": "https://yt3.ggpht.com/abc=s88-c-k"}
                                        ]
                                    },
                                }
                            }
                        ]
                    }
                }
            ]
        }
    }
    records = parser.parse_account_menu(data)
    assert len(records) == 1
    assert records[0]["avatar_url"] == "https://yt3.ggpht.com/abc=s88-c-k"


# --------------------------------------------------------------------- #
# Tự động: tạo video gắn đúng Muse phụ trách
# --------------------------------------------------------------------- #
def test_automation_create_video_targets_assigned_agent(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Ho so", "a@gmail.com")
    agent = store.create_agent("Muse Phim", "phim@example.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    rule = store.add_rule(
        "create_video", profile_id=profile["id"],
        schedule_kind="daily", daily_time="20:00", enabled=True,
    )
    engine = AutomationEngine(store)
    created = engine._fire(rule, __import__("datetime").datetime.now().astimezone())
    assert len(created) == 1
    command = created[0]
    assert command["type"] == "create_video"
    # V4.0 (Đ5): lệnh Muse của quy tắc tự động vào 'queued' trước —
    # dispatcher xét điều kiện rồi mới đẩy lên 'waiting_muse'.
    assert command["status"] == "queued"
    assert command["agent_id"] == agent["id"]
    store.close()


# --------------------------------------------------------------------- #
# Hàm thuần: sparkline + tách dòng đăng nhập
# --------------------------------------------------------------------- #
def test_sparkline_and_login_line():
    pytest.importorskip("PySide6")
    from app.ui.reports_panel import sparkline
    from app.ui.dialogs import split_login_line

    assert sparkline([5]) == "—"
    assert sparkline([3, 3, 3]) == "▬▬▬"
    line = sparkline([1, 5, 10])
    assert line[0] == "▁" and line[-1] == "█"
    assert split_login_line("ten@gmail.com|matkhau") == ("ten@gmail.com", "matkhau")
    assert split_login_line("chi@gmail.com") == ("chi@gmail.com", "")
