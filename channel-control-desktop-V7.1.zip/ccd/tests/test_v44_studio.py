"""V4.4 — Điều khiển Studio qua trình duyệt NHÚNG trong app.

Bao phủ:
- CDPClient mở rộng: navigate + chờ Page.loadEventFired (sự kiện đến
  TRƯỚC phản hồi vẫn không mất nhờ bộ đệm), wait_event timeout,
  wait_for (thấy sau vài nhịp / quá hạn báo rõ selector + giây),
  click/fill/press/read/set_file_input/scroll qua transport giả lập.
- studio_script.validate_steps: chặn action lạ, thiếu trường, tên
  file upload chứa đường dẫn/'..', sleep quá trần.
- Runner: chạy tuần tự, progress %, dừng ở bước lỗi kèm ảnh lỗi,
  require_no_login_wall → StudioNeedsUser mang kết quả dở dang.
- Tích hợp executor (UI) + Agent API (enqueue → _execute), giao file
  theo lệnh qua /api/inbox + X-Command-Id (404/409/413/chặn ../),
  dọn file khi xoá lệnh, form UI tạo lệnh studio_script.
"""

from __future__ import annotations

import base64
import json
import sys
import types
from pathlib import Path

import pytest

from app import command_schema, config, executor, studio_script
from app.agent_server import AgentServer
from app.cdp import CDPClient, CDPError
from app.store import Store


# --------------------------------------------------------------------------- #
# Transport CDP giả lập có kịch bản (cho CDPClient thật)
# --------------------------------------------------------------------------- #
class FakeWSTimeout(Exception):
    """Tên lớp chứa 'timeout' để _is_timeout_exc nhận diện."""


class FakePage:
    """Trang giả: respond() trả các message CDP theo method. Sự kiện
    loadEventFired được gửi TRƯỚC phản hồi Page.navigate — đúng ca
    khó mà bộ đệm sự kiện của V4.4 phải xử lý."""

    def __init__(self):
        self.url = "about:blank"
        self.text = ""
        self.find_sequence: list = []
        self.calls: list = []

    def respond(self, message: dict) -> list[str]:
        method = message["method"]
        params = message.get("params") or {}
        mid = message["id"]
        self.calls.append((method, params))

        def resp(result):
            return json.dumps({"id": mid, "result": result})

        if method == "Page.navigate":
            self.url = params.get("url", self.url)
            event = json.dumps(
                {"method": "Page.loadEventFired", "params": {"timestamp": 1.0}}
            )
            return [event, resp({"frameId": "F1"})]
        if method == "Runtime.evaluate":
            return [resp({"result": {"value": self._eval(params.get("expression", ""))}})]
        if method == "DOM.getDocument":
            return [resp({"root": {"nodeId": 1}})]
        if method == "DOM.querySelector":
            node_id = 0 if "missing" in params.get("selector", "") else 42
            return [resp({"nodeId": node_id})]
        if method == "Page.captureScreenshot":
            return [resp({"data": base64.b64encode(b"\x89PNG-fake").decode()})]
        return [resp({})]

    def _eval(self, expr: str):
        if "location.href" in expr and "innerText" in expr:
            return {"url": self.url, "text": self.text}
        if "getBoundingClientRect" in expr:
            if self.find_sequence:
                return self.find_sequence.pop(0)
            if "#missing" in expr or "không-có-đâu" in expr:
                return None
            return {"tag": "BUTTON", "text": "Tải lên", "x": 100.0, "y": 50.0, "visible": True}
        if "el.focus" in expr:
            return "#missing" not in expr
        if "getAttribute" in expr:
            if "#missing" in expr:
                return None
            return "Giá trị đã đọc"
        if "scrollIntoView" in expr:
            return "#missing" not in expr
        return None


class ScriptedWS:
    def __init__(self, page: FakePage, clock: dict):
        self.page = page
        self.clock = clock
        self.outbox: list[str] = []
        self.sent: list = []
        self._timeout = 0.25
        self.closed = False

    def settimeout(self, value):
        if value:
            self._timeout = value

    def send(self, payload):
        message = json.loads(payload)
        self.sent.append(message)
        self.outbox.extend(self.page.respond(message))

    def recv(self):
        if not self.outbox:
            # Mô phỏng socket hết giờ: thời gian trôi theo timeout đã đặt.
            self.clock["now"] += self._timeout
            raise FakeWSTimeout("hết giờ chờ (giả lập)")
        return self.outbox.pop(0)

    def close(self):
        self.closed = True


@pytest.fixture()
def cdp_env(monkeypatch):
    page = FakePage()
    clock = {"now": 0.0}
    holder: dict = {}
    module = types.ModuleType("websocket")

    def create_connection(url, timeout=None):
        ws = ScriptedWS(page, clock)
        holder["ws"] = ws
        return ws

    module.create_connection = create_connection
    monkeypatch.setitem(sys.modules, "websocket", module)

    def fake_sleep(seconds):
        clock["now"] += seconds

    client = CDPClient(
        "ws://fake", sleep=fake_sleep, clock=lambda: clock["now"]
    )
    return client, page, holder["ws"], clock


# --------------------------------------------------------------------------- #
# CDPClient V4.4
# --------------------------------------------------------------------------- #
def test_navigate_and_wait_uses_buffered_load_event(cdp_env):
    client, page, _ws, _clock = cdp_env
    # FakePage gửi loadEventFired TRƯỚC phản hồi navigate — client
    # phải đệm sự kiện trong lúc chờ phản hồi rồi khớp ở wait_event.
    client.navigate_and_wait("https://studio.youtube.com/", timeout=5)
    assert page.url == "https://studio.youtube.com/"
    methods = [m for m, _ in page.calls]
    assert methods[:2] == ["Page.enable", "Page.navigate"]


def test_wait_event_timeout_names_event_and_seconds(cdp_env):
    client, _page, _ws, _clock = cdp_env
    with pytest.raises(CDPError) as excinfo:
        client.wait_event("Page.frameNavigated", timeout=1.0)
    assert "Page.frameNavigated" in str(excinfo.value)
    assert "1" in str(excinfo.value)


def test_wait_event_returns_params_and_stashes_other_messages(cdp_env):
    client, _page, ws, _clock = cdp_env
    ws.outbox.append(json.dumps({"id": 999, "result": {"x": 1}}))  # phản hồi lạc
    ws.outbox.append(
        json.dumps({"method": "Page.frameNavigated", "params": {"frameId": "F9"}})
    )
    params = client.wait_event("Page.frameNavigated", timeout=5)
    assert params == {"frameId": "F9"}
    assert len(client._response_buffer) == 1  # phản hồi lạc được giữ, không vứt


def test_wait_for_found_after_polls(cdp_env):
    client, page, _ws, _clock = cdp_env
    info = {"tag": "DIV", "text": "", "x": 1.0, "y": 2.0, "visible": True}
    page.find_sequence = [None, None, info]
    found = client.wait_for(selector="#late", timeout_s=5)
    assert found == info  # qua vòng JSON của transport nên so bằng giá trị


def test_wait_for_timeout_error_is_specific(cdp_env):
    client, _page, _ws, _clock = cdp_env
    with pytest.raises(CDPError) as excinfo:
        client.wait_for(selector="#missing", timeout_s=2)
    message = str(excinfo.value)
    assert "#missing" in message and "2" in message


def test_click_element_dispatches_mouse_at_center(cdp_env):
    client, page, _ws, _clock = cdp_env
    clicked = client.click_element(text="Tải lên")
    assert clicked["x"] == 100.0 and clicked["y"] == 50.0
    mouse = [p for m, p in page.calls if m == "Input.dispatchMouseEvent"]
    assert [e["type"] for e in mouse] == ["mousePressed", "mouseReleased"]
    with pytest.raises(CDPError):
        client.click_element(selector="#missing")


def test_fill_element_focuses_and_inserts(cdp_env):
    client, page, _ws, _clock = cdp_env
    filled = client.fill_element("#title", "Tiêu đề mới")
    assert filled["chars"] == len("Tiêu đề mới")
    assert ("Input.insertText", {"text": "Tiêu đề mới"}) in page.calls
    with pytest.raises(CDPError):
        client.fill_element("#missing", "x")


def test_press_key_sends_down_up_with_virtual_code(cdp_env):
    client, page, _ws, _clock = cdp_env
    client.press_key("Enter")
    keys = [p for m, p in page.calls if m == "Input.dispatchKeyEvent"]
    assert [k["type"] for k in keys] == ["keyDown", "keyUp"]
    assert keys[0]["windowsVirtualKeyCode"] == 13
    with pytest.raises(CDPError):
        client.press_key("F13-Không-Có")


def test_read_text_and_missing(cdp_env):
    client, _page, _ws, _clock = cdp_env
    assert client.read_text("#status") == "Giá trị đã đọc"
    with pytest.raises(CDPError):
        client.read_text("#missing")


def test_set_file_input_walks_dom(cdp_env):
    client, page, _ws, _clock = cdp_env
    result = client.set_file_input('input[type="file"]', ["/data/video.mp4"])
    assert result["files"] == ["/data/video.mp4"]
    methods = [m for m, _ in page.calls]
    assert methods == ["DOM.getDocument", "DOM.querySelector", "DOM.setFileInputFiles"]
    set_call = [p for m, p in page.calls if m == "DOM.setFileInputFiles"][0]
    assert set_call == {"nodeId": 42, "files": ["/data/video.mp4"]}
    with pytest.raises(CDPError):
        client.set_file_input('input[type="file"].missing', ["/data/video.mp4"])


def test_scroll_helpers(cdp_env):
    client, _page, _ws, _clock = cdp_env
    assert client.scroll_by(300) == {"dy": 300}
    assert client.scroll_into_view("#ok") == {"selector": "#ok"}
    with pytest.raises(CDPError):
        client.scroll_into_view("#missing")


# --------------------------------------------------------------------------- #
# validate_steps
# --------------------------------------------------------------------------- #
def test_validate_steps_accepts_full_house():
    steps = [
        {"action": "goto", "url": "https://studio.youtube.com/"},
        {"action": "require_no_login_wall"},
        {"action": "wait_for", "selector": "#upload", "timeout_s": 30},
        {"action": "upload", "file": "video.mp4"},
        {"action": "fill", "selector": "#title", "text": "T"},
        {"action": "click", "text": "Tiếp"},
        {"action": "press", "key": "Enter"},
        {"action": "read", "selector": "#st", "save_as": "st"},
        {"action": "screenshot", "name": "done"},
        {"action": "sleep", "seconds": 2},
    ]
    assert studio_script.validate_steps(steps) == []
    assert studio_script.validate_steps(studio_script.EXAMPLE_STEPS) == []


@pytest.mark.parametrize(
    "steps",
    [
        [],
        [{"action": "bay_lên_trời"}],
        [{"action": "goto"}],
        [{"action": "wait_for"}],
        [{"action": "fill", "selector": "#a"}],
        [{"action": "upload", "file": "/tmp/video.mp4"}],
        [{"action": "upload", "file": "../video.mp4"}],
        [{"action": "upload", "file": "thư-mục/video.mp4"}],
        [{"action": "sleep", "seconds": 9999}],
        [{"action": "read", "selector": "#a"}],
        [{"action": "screenshot", "name": "có dấu cách"}],
        ["không-phải-object"],
    ],
)
def test_validate_steps_rejects_bad_scripts(steps):
    assert studio_script.validate_steps(steps) != []


def test_schema_registration_for_studio_script():
    assert command_schema.validate_command(
        "studio_script", payload={"steps": studio_script.EXAMPLE_STEPS}
    ) == []
    assert command_schema.validate_command("studio_script", payload={})
    errors = command_schema.validate_command(
        "studio_script", payload={"steps": [{"action": "upload", "file": "../x.mp4"}]}
    )
    assert errors and "TÊN FILE THUẦN" in errors[-1]


# --------------------------------------------------------------------------- #
# Runner với client giả lập thuần Python
# --------------------------------------------------------------------------- #
class StubStudioClient:
    def __init__(self, wall: bool = False):
        self.calls: list = []
        self.wall = wall
        self.closed = False

    def navigate_and_wait(self, url, timeout=30):
        self.calls.append(("goto", url))

    def wait_for(self, selector=None, text=None, timeout_s=10):
        self.calls.append(("wait_for", selector, text))
        if selector == "#missing":
            raise CDPError(
                f"Chờ phần tử quá {timeout_s:g} giây mà không thấy (selector='#missing')"
            )
        return {"tag": "DIV"}

    def click_element(self, selector=None, text=None):
        self.calls.append(("click", selector, text))
        return {"tag": "BUTTON", "text": text or ""}

    def fill_element(self, selector, text):
        self.calls.append(("fill", selector, text))
        return {"chars": len(text)}

    def press_key(self, key):
        self.calls.append(("press", key))
        return {"key": key}

    def read_text(self, selector, attr=None):
        self.calls.append(("read", selector, attr))
        return "Đã xử lý xong"

    def set_file_input(self, selector, files):
        self.calls.append(("upload", selector, list(files)))
        return {"files": list(files)}

    def evaluate(self, expression):
        if self.wall:
            return {
                "url": "https://accounts.google.com/v3/signin",
                "text": "Verify it's you",
            }
        return {"url": "https://studio.youtube.com/", "text": "YouTube Studio"}

    def capture_screenshot_png(self):
        return b"\x89PNG-stub"

    def close(self):
        self.closed = True


def _run(client, steps, **kwargs):
    shots: list[str] = []
    progress_calls: list = []
    kwargs.setdefault("resolve_file", lambda name: Path("/data/files") / name)
    kwargs.setdefault(
        "save_screenshot", lambda name: shots.append(name) or f"saved-{name}.png"
    )
    kwargs.setdefault("progress", lambda pct, text: progress_calls.append((pct, text)))
    kwargs.setdefault("sleep", lambda _s: None)
    return studio_script.run_studio_script(client, steps, **kwargs), shots, progress_calls


FULL_SCRIPT = [
    {"action": "goto", "url": "https://studio.youtube.com/"},
    {"action": "require_no_login_wall"},
    {"action": "wait_for", "selector": "#upload-icon", "timeout_s": 20},
    {"action": "upload", "file": "video.mp4"},
    {"action": "fill", "selector": "#title", "text": "Tiêu đề EP01"},
    {"action": "press", "key": "Enter"},
    {"action": "read", "selector": "#status", "save_as": "status_text"},
    {"action": "screenshot", "name": "final"},
]


def test_runner_full_script_success():
    client = StubStudioClient()
    result, shots, progress_calls = _run(client, FULL_SCRIPT)
    assert result["status"] == "done"
    assert result["completed_steps"] == len(FULL_SCRIPT)
    assert all(s["status"] == "ok" for s in result["steps"])
    assert result["reads"] == {"status_text": "Đã xử lý xong"}
    assert result["screenshots"] == ["saved-final.png"]
    upload = [c for c in client.calls if c[0] == "upload"][0]
    assert upload[2] == [str(Path("/data/files") / "video.mp4")]
    percents = [p for p, _ in progress_calls]
    assert percents == sorted(percents) and percents[-1] == 100


def test_runner_stops_at_failed_step_with_error_screenshot():
    client = StubStudioClient()
    steps = [
        {"action": "goto", "url": "https://studio.youtube.com/"},
        {"action": "wait_for", "selector": "#missing", "timeout_s": 3},
        {"action": "screenshot", "name": "không-bao-giờ-tới"},
    ]
    with pytest.raises(studio_script.StudioStepError) as excinfo:
        _run(client, steps)
    result = excinfo.value.result
    assert result["status"] == "failed"
    assert [s["status"] for s in result["steps"]] == ["ok", "failed"]
    assert "#missing" in result["steps"][1]["detail"]
    assert result["error_screenshot"] == "saved-error-step-2.png"
    assert "Bước 2/3" in str(excinfo.value)


def test_runner_login_wall_becomes_needs_user():
    client = StubStudioClient(wall=True)
    steps = [
        {"action": "goto", "url": "https://studio.youtube.com/"},
        {"action": "require_no_login_wall"},
        {"action": "screenshot", "name": "không-tới"},
    ]
    with pytest.raises(studio_script.StudioNeedsUser) as excinfo:
        _run(client, steps)
    result = excinfo.value.result
    assert result["status"] == "needs_user"
    assert result["steps"][1]["status"] == "needs_user"
    assert "KHÔNG tự vượt OTP/CAPTCHA" in excinfo.value.reason


def test_runner_missing_attached_file_fails_step():
    client = StubStudioClient()

    def resolve_missing(name):
        raise FileNotFoundError(f"Chưa có file '{name}' được giao kèm lệnh này")

    with pytest.raises(studio_script.StudioStepError) as excinfo:
        _run(client, [{"action": "upload", "file": "video.mp4"}], resolve_file=resolve_missing)
    assert "Chưa có file" in excinfo.value.result["steps"][0]["detail"]


# --------------------------------------------------------------------------- #
# Tích hợp: executor phía UI chạy xuyên suốt lệnh studio_script
# --------------------------------------------------------------------------- #
class FakeStudioManager:
    def __init__(self, client=None, running: bool = True):
        self.client = client or StubStudioClient()
        self.running = running
        self.launched: list[str] = []

    def is_running(self, profile):
        return self.running

    def launch(self, profile):
        self.launched.append(profile["slug"])
        self.running = True
        return "launched"

    def connect_page(self, profile):
        return self.client


def _seed_command(tmp_path, steps, client=None, running=True):
    db_path = tmp_path / "ccd.sqlite3"
    store = Store(db_path)
    profile = store.add_profile("KenhA", "a@example.com")
    command = store.create_command(
        "studio_script",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        payload={"steps": steps},
        status="queued",
    )
    store.close()
    manager = FakeStudioManager(client or StubStudioClient(), running=running)
    return db_path, profile, command, manager


def test_executor_high_level_script_end_to_end(tmp_path):
    """Kịch bản mẫu chạy XUYÊN executor: goto → wait → upload (file
    giao kèm lệnh) → fill → read → screenshot, Chrome chưa chạy thì
    executor mở lên đúng hồ sơ."""
    client = StubStudioClient()
    db_path, profile, command, manager = _seed_command(
        tmp_path, FULL_SCRIPT, client=client, running=False
    )
    files_dir = config.command_files_dir(command["id"], base=tmp_path)
    (files_dir / "video.mp4").write_bytes(b"fake-video-bytes")

    row = executor.run_command_by_id(db_path, command["id"], manager)
    assert row["status"] == "done"
    assert manager.launched == [profile["slug"]]  # Chrome mở vì chưa chạy
    data = row["result_data"]
    assert data["status"] == "done" and data["completed_steps"] == len(FULL_SCRIPT)
    assert all(step["status"] == "ok" for step in data["steps"])
    assert data["reads"] == {"status_text": "Đã xử lý xong"}
    upload = [c for c in client.calls if c[0] == "upload"][0]
    assert upload[2] == [str(files_dir / "video.mp4")]
    shot_name = data["screenshots"][0]
    assert shot_name.startswith(f"studio-{command['id'][:8]}-")
    assert (tmp_path / "screenshots" / shot_name).exists()
    assert row["progress"] == 100
    assert client.closed is True


def test_executor_studio_needs_user_and_failure_paths(tmp_path):
    # Tường đăng nhập → lệnh dừng ở needs_user với lý do rõ.
    wall_client = StubStudioClient(wall=True)
    db_path, _p, command, manager = _seed_command(
        tmp_path,
        [
            {"action": "goto", "url": "https://studio.youtube.com/"},
            {"action": "require_no_login_wall"},
        ],
        client=wall_client,
    )
    row = executor.run_command_by_id(db_path, command["id"], manager)
    assert row["status"] == "needs_user"
    assert "đăng nhập" in (row["result"] or "")

    # Bước lỗi → failed + kết quả từng bước nằm trong result_data.
    db_path2 = tmp_path / "second.sqlite3"
    store = Store(db_path2)
    profile = store.add_profile("KenhB", "b@example.com")
    bad = store.create_command(
        "studio_script",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        payload={"steps": [{"action": "wait_for", "selector": "#missing"}]},
        status="queued",
    )
    store.close()
    row2 = executor.run_command_by_id(
        db_path2, bad["id"], FakeStudioManager(StubStudioClient())
    )
    assert row2["status"] == "failed"
    assert row2["result_data"]["steps"][0]["status"] == "failed"
    assert row2["result_data"]["error_screenshot"].startswith("studio-")


# --------------------------------------------------------------------------- #
# Agent API: enqueue studio_script + giao file theo lệnh (S4)
# --------------------------------------------------------------------------- #
@pytest.fixture()
def studio_server(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("KenhA", "a@example.com")
    seed.close()
    manager = FakeStudioManager()
    server = AgentServer(data_dir=data_dir, settings={"agent_port": 0}, manager=manager)
    yield server, profile, manager, data_dir
    server.stop()


def _auth(server):
    return {"X-Agent-Token": server.token}


def _enqueue_studio(server, profile, steps):
    body = json.dumps(
        {"type": "studio_script", "profile": profile["slug"], "payload": {"steps": steps}}
    ).encode("utf-8")
    status, payload = server.dispatch("POST", "/api/commands", _auth(server), body)
    assert status == 202, payload
    return payload["command_id"]


def test_api_health_reports_version_25(studio_server):
    server, _profile, _manager, _data_dir = studio_server
    status, payload = server.dispatch("GET", "/api/health", {}, b"")
    # Pin phiên bản API: 2.5 ở V4.4 → 2.6 ở V4.6 → 2.7 ở V6.0
    # (verdict + scorecard) → 2.8 ở V6.1 (due_at) — cập nhật cùng mỗi bump như lệ.
    assert status == 200 and payload["version"] == "2.8"


def test_api_studio_script_with_attached_file_runs_done(studio_server, tmp_path):
    server, profile, manager, data_dir = studio_server
    command_id = _enqueue_studio(server, profile, FULL_SCRIPT)
    # Giao file kèm lệnh qua inbox + X-Command-Id.
    status, payload = server.dispatch(
        "POST",
        "/api/inbox",
        {
            **_auth(server),
            "X-File-Name": "video.mp4",
            "X-Command-Id": command_id,
        },
        b"fake-video-bytes",
    )
    assert status == 200, payload
    assert payload["command_id"] == command_id and payload["name"] == "video.mp4"
    saved = config.command_files_dir(command_id, base=data_dir) / "video.mp4"
    assert saved.read_bytes() == b"fake-video-bytes"

    server._execute(command_id)
    store = Store(config.db_path(data_dir))
    try:
        row = store.get_command(command_id)
    finally:
        store.close()
    assert row["status"] == "done"
    assert row["result_data"]["completed_steps"] == len(FULL_SCRIPT)
    upload = [c for c in manager.client.calls if c[0] == "upload"][0]
    assert upload[2] == [str(saved)]


def test_api_studio_script_login_wall_needs_user(studio_server):
    server, profile, manager, data_dir = studio_server
    manager.client = StubStudioClient(wall=True)
    command_id = _enqueue_studio(
        server,
        profile,
        [
            {"action": "goto", "url": "https://studio.youtube.com/"},
            {"action": "require_no_login_wall"},
        ],
    )
    server._execute(command_id)
    store = Store(config.db_path(data_dir))
    try:
        row = store.get_command(command_id)
    finally:
        store.close()
    assert row["status"] == "needs_user"


def test_api_inbox_attach_guards(studio_server, monkeypatch):
    server, profile, _manager, data_dir = studio_server
    # Lệnh không tồn tại → 404.
    status, _ = server.dispatch(
        "POST",
        "/api/inbox",
        {**_auth(server), "X-File-Name": "v.mp4", "X-Command-Id": "khong-co-123"},
        b"x",
    )
    assert status == 404
    # Mã lệnh chứa đường dẫn → 404 (không thoát thư mục).
    status, _ = server.dispatch(
        "POST",
        "/api/inbox",
        {**_auth(server), "X-File-Name": "v.mp4", "X-Command-Id": "../evil"},
        b"x",
    )
    assert status == 404
    assert not (data_dir / "evil").exists()

    command_id = _enqueue_studio(server, profile, FULL_SCRIPT)
    # Quá giới hạn dung lượng → 413.
    monkeypatch.setattr(config, "MAX_COMMAND_FILE_BYTES", 4)
    status, payload = server.dispatch(
        "POST",
        "/api/inbox",
        {**_auth(server), "X-File-Name": "v.mp4", "X-Command-Id": command_id},
        b"12345",
    )
    assert status == 413
    monkeypatch.undo()
    # Tên file chứa đường dẫn → bị bóc thành tên thuần, nằm trong thư mục lệnh.
    status, payload = server.dispatch(
        "POST",
        "/api/inbox",
        {**_auth(server), "X-File-Name": "../../evil.mp4", "X-Command-Id": command_id},
        b"data",
    )
    assert status == 200 and payload["name"] == "evil.mp4"
    assert (config.command_files_dir(command_id, base=data_dir) / "evil.mp4").exists()
    assert not (data_dir / "evil.mp4").exists()
    # Lệnh đã kết thúc → 409.
    store = Store(config.db_path(data_dir))
    store.finish_command(command_id, "done", result="x")
    store.close()
    status, _ = server.dispatch(
        "POST",
        "/api/inbox",
        {**_auth(server), "X-File-Name": "v.mp4", "X-Command-Id": command_id},
        b"x",
    )
    assert status == 409


def test_api_inbox_without_command_id_still_uses_inbox(studio_server):
    server, _profile, _manager, data_dir = studio_server
    status, payload = server.dispatch(
        "POST", "/api/inbox", {**_auth(server), "X-File-Name": "loose.txt"}, b"hello"
    )
    assert status == 200
    assert (data_dir / "inbox" / payload["name"]).exists()


def test_delete_command_removes_attached_files(tmp_path):
    store = Store(tmp_path / "ccd.sqlite3")
    profile = store.add_profile("KenhA", "a@example.com")
    command = store.create_command(
        "studio_script",
        source="ui",
        profile_id=profile["id"],
        payload={"steps": studio_script.EXAMPLE_STEPS},
        status="queued",
    )
    files_dir = config.command_files_dir(command["id"], base=tmp_path)
    (files_dir / "video.mp4").write_bytes(b"x")
    store.delete_command(command["id"])
    assert not files_dir.exists()
    store.close()


# --------------------------------------------------------------------------- #
# UI: form tạo lệnh có loại Kịch bản Studio + ô JSON
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_ui_studio_script_form(qapp, tmp_path):
    from app.ui.commands_panel import CommandsPanel

    store = Store(tmp_path / "ui.sqlite3")
    profile = store.add_profile("KenhA", "a@example.com")
    panel = CommandsPanel(store)

    index = panel.type_combo.findData("studio_script")
    assert index >= 0
    assert panel.type_combo.itemText(index) == "Kịch bản Studio (nhúng)"
    panel.type_combo.setCurrentIndex(index)
    panel._update_form_state()
    assert panel.studio_payload_edit.isVisibleTo(panel)
    # Mẫu điền sẵn là kịch bản mẫu hợp lệ.
    preset = json.loads(panel.studio_payload_edit.toPlainText())
    assert preset["steps"] == studio_script.EXAMPLE_STEPS

    # JSON hỏng → báo lỗi tại form, không tạo lệnh nào.
    panel.studio_payload_edit.setPlainText("{chưa phải json")
    panel._create_command_from_form()
    assert store.list_commands() == []

    # Kịch bản sai ngữ nghĩa (file chứa đường dẫn) → cũng bị chặn.
    panel.studio_payload_edit.setPlainText(
        json.dumps({"steps": [{"action": "upload", "file": "../v.mp4"}]})
    )
    panel._create_command_from_form()
    assert store.list_commands() == []

    # JSON đúng → lệnh được tạo với payload steps nguyên vẹn.
    panel.studio_payload_edit.setPlainText(json.dumps({"steps": FULL_SCRIPT}))
    panel._create_command_from_form()
    commands = store.list_commands()
    assert len(commands) == 1
    assert commands[0]["type"] == "studio_script"
    assert commands[0]["payload"]["steps"] == FULL_SCRIPT
    assert commands[0]["profile_id"] == profile["id"]
    store.close()
