"""V4.3.1 — Đồng bộ phong cách Concept D + Công việc 2 cột + bảng
tình trạng kênh ở section Báo cáo:

- Token Mission Control mang đúng palette Concept D (navy sâu,
  accent #2E7CF6); người đang ở Mission Control GỐC được chuyển
  sang giá trị mới, theme đã tuỳ biến thì giữ nguyên.
- Thanh điều hướng: tab lớn icon-trên/nhãn-dưới + gạch chân accent.
- Section Công việc: splitter 2 cột (hẹp < 1200px → xếp dọc), form
  tạo lệnh chảy 2×2 trong cột phải hẹp, thứ tự 4 trường không đổi.
- Báo cáo: bảng tình trạng kênh dựng từ dữ liệu thật (kiểm tra hồ
  sơ + lệnh), dòng điểm nghẽn chung chỉ hiện khi có căn cứ.
"""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication, QLabel, QComboBox  # noqa: E402

from app import automation_health, config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import theme  # noqa: E402
from app.ui.main_window import SEC_OFFICE, SEC_WORK, MainWindow  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "kenhchinh@example.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1", "name": "Kênh Chính",
            "handle": "@kenhchinh",
            "url": "https://www.youtube.com/channel/UC1",
            "subs": 1200, "video_count": 34, "niche": "Tài liệu",
        },
    )
    agent = store.create_agent("KenhChinh", "kenhchinh@example.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    win = MainWindow(store, ChromeManager(), settings)
    win._fixture_refs = (profile, agent)
    yield win
    win.close()
    store.close()


# --------------------------------------------------------------------------- #
# Theme Concept D + di trú theme đã lưu
# --------------------------------------------------------------------------- #
_TOKEN_FIELDS = (
    "bg", "panel", "card", "border", "accent", "accent2", "text",
    "muted", "faint", "input_bg", "button_bg", "button_hover",
    "button_pressed", "card_hover", "success", "warning", "danger",
    "radius", "brightness", "font_scale", "font_family",
)


def _flat(tokens) -> dict:
    return {name: getattr(tokens, name) for name in _TOKEN_FIELDS}


def test_concept_d_palette_is_mission_control():
    # V4.5 (pin mới): mặc định toàn app là palette MetaMint (một
    # màu nhấn xanh lá, nền gần-đen trung tính) — Concept D xanh
    # dương chỉ còn là preset cũ 'mission' để tương thích.
    # V5.1 (pin mới, plan §1.1): token duyệt mới thay bộ V5.0.
    assert theme.BG == "#0C0D0F"  # V5.1: nền duyệt theo plan §1.1
    assert theme.ACCENT == "#CEFC19"  # V5.1: accent giữ nguyên
    assert theme.CARD == "#1B1D22"  # V5.1: thẻ duyệt theo plan §1.1
    assert theme.MISSION_TOKENS.accent == "#CEFC19"
    assert theme.CONCEPT_D_TOKENS.accent == "#2E7CF6"
    assert "#NavTab" in theme.APP_QSS


def test_legacy_stock_mission_migrates_to_concept_d():
    # V4.5 (pin mới): bộ gốc cũ di trú sang MetaMint (trước đây
    # sang Concept D ở V4.3.1).
    saved = _flat(theme.LEGACY_MISSION_TOKENS)
    saved["bg_image"] = "C:/anh-nen.jpg"
    saved["bg_dim"] = 0.7
    migrated = theme.migrate_saved_tokens(saved)
    assert migrated.accent == "#CEFC19"
    # Ảnh nền riêng của anh được giữ khi di trú.
    assert migrated.bg_image == "C:/anh-nen.jpg"
    assert migrated.bg_dim == 0.7


def test_customised_theme_is_not_overwritten():
    saved = _flat(theme.MISSION_TOKENS)
    saved["accent"] = "#FF00AA"  # anh đã tự đổi màu nhấn
    assert theme.migrate_saved_tokens(saved).accent == "#FF00AA"


# --------------------------------------------------------------------------- #
# Thanh điều hướng lớn kiểu Concept D
# --------------------------------------------------------------------------- #
def test_nav_tabs_big_icon_over_label(window):
    # V6.3.1: header phẳng 56px kiểu AI Studio — tab chữ MỘT dòng,
    # mục đang chọn tô nền accent nhạt (QSS NavTab:checked), không gạch chân.
    window._apply_rail_state(False)
    assert window.nav_rail.maximumHeight() == 56
    office_button = window._nav_buttons[SEC_OFFICE]
    assert office_button.objectName() == "NavTab"
    assert "\n" not in office_button.text()
    assert "Văn phòng" in office_button.text()
    window._switch_section(SEC_OFFICE)
    assert office_button.isChecked()


# --------------------------------------------------------------------------- #
# Công việc 2 cột + form 2×2
# --------------------------------------------------------------------------- #
def test_work_split_two_columns_and_stack_fallback(window):
    # V4.5 (pin mới): ĐẢO CỘT — trái là cột Giao việc
    # (assign_scroll: form + hàng đợi), phải là right_splitter
    # (bảng việc trên + bảng lệnh dưới).
    panel = window.work_panel
    panel._apply_split_orientation(1500)
    assert panel.splitter.orientation() == Qt.Orientation.Horizontal
    assert panel.splitter.widget(0) is panel.assign_scroll
    assert panel.splitter.widget(1) is panel.right_splitter
    panel._apply_split_orientation(900)
    assert panel.splitter.orientation() == Qt.Orientation.Vertical
    panel._apply_split_orientation(1500)


def _combos_in_layout_order(layout) -> list:
    combos = []
    for i in range(layout.count()):
        item = layout.itemAt(i)
        widget = item.widget()
        if isinstance(widget, QComboBox):
            combos.append(widget)
        elif item.layout() is not None:
            combos.extend(_combos_in_layout_order(item.layout()))
    return combos


def test_commands_form_reflows_and_keeps_field_order(window):
    # V4.5 (pin mới): bỏ hẳn cơ chế chảy 2×2 — form MỘT CỘT DỌC
    # trong cột Giao việc, thứ tự trường đúng quy trình: Skill →
    # Muse nhận lệnh → Loại lệnh → Hồ sơ đích → Kênh CHECKBOX
    # (không còn channel_combo chọn một).
    panel = window.commands_panel
    assert not hasattr(panel, "_relayout_form_fields")
    combos = _combos_in_layout_order(panel.form_card.layout())
    assert combos == [
        panel.skill_combo, panel.agent_combo, panel.type_combo,
        panel.profile_combo,
    ]
    assert not hasattr(panel, "channel_combo")
    assert panel.channel_scroll is not None


# --------------------------------------------------------------------------- #
# Bảng tình trạng kênh (Báo cáo)
# --------------------------------------------------------------------------- #
def _all_label_texts(widget) -> str:
    return "\n".join(
        label.text() for label in widget.findChildren(QLabel)
    )


def test_channel_status_board_uses_real_data(window):
    profile, agent = window._fixture_refs
    store = window._store
    store.create_command(
        "upload", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], channel_id="UC1",
        instruction="Đăng video", agent_id=agent["id"],
        status="needs_user",
    )
    store.save_check(
        profile["id"],
        [
            {"key": "chrome", "label": "Chrome đang chạy",
             "status": "ok", "detail": "Đang mở"},
            {"key": "login", "label": "Đã đăng nhập YouTube",
             "status": "fail", "detail": "Phiên hết hạn"},
        ],
        "1/2 mục đạt",
    )
    automation_health.record_error(store, "dispatcher", "mất kết nối")
    board = window.channel_status_panel
    board.refresh()

    # Dòng điểm nghẽn chung hiện với cả hai căn cứ thật.
    assert board.alert_frame.isVisibleTo(board) or board.alert_label.text()
    alert = board.alert_label.text()
    assert "chờ người" in alert
    assert "Vòng tự động" in alert

    texts = _all_label_texts(board)
    assert "Kênh Chính" in texts
    assert "1,200 subs" in texts
    assert "Có lỗi" in texts           # pill theo kiểm tra gần nhất
    assert "Đã đăng nhập YouTube" in texts  # phát hiện từ kiểm tra
    assert "chờ người xử lý" in texts   # ghi chú đỏ needs_user

    # Bấm thẻ → Báo cáo chọn đúng dòng kênh.
    picked = []
    board.channel_chosen.connect(lambda pid, cid: picked.append((pid, cid)))
    card = board.cards_layout.itemAt(0).widget()
    card.chosen.emit(profile["id"], "UC1")
    assert picked == [(profile["id"], "UC1")]
    window._open_channel_in_reports(profile["id"], "UC1")
    assert window.reports_tabs.currentWidget() is window.reports_panel
    assert window.reports_panel.table.currentRow() >= 0


def test_channel_status_alert_hidden_without_evidence(window):
    board = window.channel_status_panel
    board.refresh()
    assert board.alert_label.text() == ""
    assert not board.alert_frame.isVisibleTo(board)
