"""Kiểm thử V4.6 — CHAT hai chiều với từng Muse ngay trong app.

- Store: migration v7 → v8 giữ nguyên dữ liệu; vòng đời tin nhắn
  (thêm/đọc chưa đọc/đánh dấu đã đọc/phân trang); tin HỆ THỐNG khi
  lệnh kẹt needs_user (đúng một tin cho một lần dừng).
- Agent API 2.6: GET/POST /api/agents/{id}/messages + /read —
  phạm vi chặt theo agent (403 chéo luồng, 404 agent lạ), validate
  body (400 rỗng/JSON hỏng, 413 quá dài), long-poll tin chưa đọc.
- UI: khung chat gửi tin + chip ngữ cảnh lệnh; panel Tài khoản hai
  cột + huy hiệu chưa đọc + open_chat; tín hiệu "Hỏi về lệnh này";
  MainWindow mở chat đúng Muse phụ trách lệnh.
"""

import json
import threading
import time

import pytest

from app import config
from app.agent_server import AgentServer
from app.store import Store


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    app = QApplication.instance() or QApplication([])
    yield app


# --------------------------------------------------------------------- #
# Store — migration + vòng đời tin nhắn
# --------------------------------------------------------------------- #
def test_migration_v7_to_v8_preserves_data(tmp_path):
    db = tmp_path / "old.db"
    store = Store(db)
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    command = store.create_command(
        "free", profile_id=profile["id"], instruction="việc cũ"
    )
    # Giả lập DB ở schema 7: bỏ bảng mới + hạ mốc phiên bản.
    store._conn.execute("DROP TABLE agent_messages")
    store._conn.execute("DROP INDEX IF EXISTS idx_agent_messages_unread")
    store._conn.execute("PRAGMA user_version = 7")
    store._conn.commit()
    store.close()

    migrated = Store(db)
    try:
        # V6.0: schema 9 (bảng reviews) — pin cập nhật cùng bump.
        assert migrated.schema_version == 12  # V7.0 (v12 = platform)
        # Dữ liệu cũ nguyên vẹn.
        assert migrated.get_agent(agent["id"])["email"] == "a@claude.ai"
        assert migrated.get_command(command["id"])["instruction"] == "việc cũ"
        # Bảng mới dùng được ngay + migration chạy lại vô hại.
        msg = migrated.add_message(agent["id"], "user", "chào")
        assert msg["direction"] == "user"
        migrated._migrate()
        assert migrated.schema_version == 12  # V7.0 (v12 = platform)
    finally:
        migrated.close()


def test_message_roundtrip_unread_and_mark_read(tmp_path):
    store = Store(tmp_path / "chat.db")
    agent = store.create_agent("Muse A", "a@claude.ai")
    other = store.create_agent("Muse B", "b@claude.ai")
    m1 = store.add_message(agent["id"], "user", "một")
    m2 = store.add_message(agent["id"], "agent", "hai")
    m3 = store.add_message(agent["id"], "user", "ba", command_id="cmd-x")
    store.add_message(other["id"], "user", "luồng khác")

    history = store.list_messages(agent["id"])
    assert [m["body"] for m in history] == ["một", "hai", "ba"]
    assert history[2]["command_id"] == "cmd-x"
    # Phân trang: 1 tin gần nhất trước mốc m3.
    page = store.list_messages(agent["id"], limit=1, before_id=m3["id"])
    assert [m["id"] for m in page] == [m2["id"]]

    counts = store.unread_counts()
    assert counts[agent["id"]] == {"user": 2, "agent": 1}
    assert counts[other["id"]] == {"user": 1}
    unread_user = store.list_unread_messages(agent["id"], "user")
    assert [m["id"] for m in unread_user] == [m1["id"], m3["id"]]

    # Đánh dấu đọc tới một mốc: chỉ m1 được đọc.
    assert store.mark_read(agent["id"], "user", up_to_id=m1["id"]) == 1
    assert store.unread_counts()[agent["id"]] == {"user": 1, "agent": 1}
    # Đọc hết chiều user; chiều agent không đụng.
    assert store.mark_read(agent["id"], "user") == 1
    assert store.unread_counts()[agent["id"]] == {"agent": 1}
    store.close()


def test_add_message_validation(tmp_path):
    store = Store(tmp_path / "chat.db")
    agent = store.create_agent("Muse A", "a@claude.ai")
    with pytest.raises(ValueError):
        store.add_message(agent["id"], "sideways", "x")
    with pytest.raises(ValueError):
        store.add_message(9999, "user", "x")
    store.close()


# --------------------------------------------------------------------- #
# Tin hệ thống khi needs_user
# --------------------------------------------------------------------- #
def test_needs_user_inserts_single_system_message(tmp_path):
    store = Store(tmp_path / "chat.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    command = store.create_command(
        "create_video", profile_id=profile["id"],
        instruction="làm video", status="running", agent_id=agent["id"],
    )
    store.set_command_needs_user(command["id"], "Cần đăng nhập Studio")
    # Đặt lại lần nữa cùng lý do (hai đường cùng báo một lần dừng)
    # → KHÔNG nhân đôi tin.
    store.set_command_needs_user(command["id"], "Cần đăng nhập Studio")
    messages = store.list_messages(agent["id"])
    system_msgs = [m for m in messages if m["direction"] == "system"]
    assert len(system_msgs) == 1
    assert system_msgs[0]["command_id"] == command["id"]
    assert "đang chờ bạn xử lý" in system_msgs[0]["body"]
    assert "Cần đăng nhập Studio" in system_msgs[0]["body"]
    # Người dùng đã trao đổi về lệnh này → lần dừng MỚI được báo tiếp.
    store.add_message(agent["id"], "user", "đã đăng nhập rồi",
                       command_id=command["id"])
    store.resume_command(command["id"])
    store.set_command_needs_user(command["id"], "Thiếu mã OTP")
    system_msgs = [
        m for m in store.list_messages(agent["id"])
        if m["direction"] == "system"
    ]
    assert len(system_msgs) == 2
    assert "Thiếu mã OTP" in system_msgs[1]["body"]
    store.close()


def test_needs_user_falls_back_to_profile_owner(tmp_path):
    """Lệnh chưa ghi danh agent_id → tin hệ thống vẫn tới đúng Muse
    chủ của hồ sơ đích."""
    store = Store(tmp_path / "chat.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    command = store.create_command(
        "upload", profile_id=profile["id"], status="running",
    )
    store.set_command_needs_user(command["id"], "kẹt")
    messages = store.list_messages(agent["id"])
    assert len(messages) == 1 and messages[0]["direction"] == "system"
    store.close()


# --------------------------------------------------------------------- #
# Agent API 2.6 — messages
# --------------------------------------------------------------------- #
class _FakeManager:
    def launch(self, profile):
        return "launched"

    def is_running(self, profile):
        return False

    def connect_page(self, profile):
        raise RuntimeError("không dùng trong test chat")


@pytest.fixture()
def world(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    agent_a = seed.create_agent("Muse A", "a@claude.ai")
    agent_b = seed.create_agent("Muse B", "b@claude.ai")
    seed.close()
    server = AgentServer(
        data_dir=data_dir, settings={"agent_port": 0},
        manager=_FakeManager(), scan_fn=lambda *a, **k: {},
    )
    yield {"server": server, "a": agent_a, "b": agent_b, "data_dir": data_dir}


def _agent_headers(agent):
    return {"X-Agent-Id": str(agent["id"]), "X-Agent-Token": agent["token"]}


def _admin_headers(world):
    return {"X-Agent-Token": world["server"].token}


def _store(world):
    return Store(config.db_path(world["data_dir"]))


def test_api_unread_reply_and_read_flow(world):
    server = world["server"]
    agent = world["a"]
    store = _store(world)
    store.add_message(agent["id"], "user", "Muse ơi, kiểm tra kênh giúp")
    store.close()

    # Muse đọc tin chưa đọc của mình.
    status, payload = server.dispatch(
        "GET", f"/api/agents/{agent['id']}/messages?unread=1",
        _agent_headers(agent), b"",
    )
    assert status == 200
    assert payload["unread"] == 1
    assert payload["messages"][0]["body"] == "Muse ơi, kiểm tra kênh giúp"

    # Muse trả lời.
    status, payload = server.dispatch(
        "POST", f"/api/agents/{agent['id']}/messages",
        _agent_headers(agent),
        json.dumps({"body": "Đã kiểm tra, kênh ổn"}).encode(),
    )
    assert status == 201
    assert payload["message"]["direction"] == "agent"

    # Muse đánh dấu đã đọc tin user → unread về 0.
    status, payload = server.dispatch(
        "POST", f"/api/agents/{agent['id']}/messages/read",
        _agent_headers(agent), b"{}",
    )
    assert status == 200 and payload["marked"] == 1
    status, payload = server.dispatch(
        "GET", f"/api/agents/{agent['id']}/messages?unread=1",
        _agent_headers(agent), b"",
    )
    assert payload["unread"] == 0

    # Admin xem lịch sử đầy đủ cả hai chiều.
    status, payload = server.dispatch(
        "GET", f"/api/agents/{agent['id']}/messages",
        _admin_headers(world), b"",
    )
    assert status == 200
    assert [m["direction"] for m in payload["messages"]] == ["user", "agent"]
    assert payload["unread_counts"] == {"agent": 1}


def test_api_scope_tight(world):
    server = world["server"]
    a, b = world["a"], world["b"]
    # B đọc luồng của A → 403 (mọi động từ).
    for method, path, body in (
        ("GET", f"/api/agents/{a['id']}/messages", b""),
        ("POST", f"/api/agents/{a['id']}/messages",
         json.dumps({"body": "x"}).encode()),
        ("POST", f"/api/agents/{a['id']}/messages/read", b"{}"),
    ):
        status, _ = server.dispatch(method, path, _agent_headers(b), body)
        assert status == 403, (method, path)
    # Admin chạm agent không tồn tại → 404.
    status, _ = server.dispatch(
        "GET", "/api/agents/9999/messages", _admin_headers(world), b""
    )
    assert status == 404
    # Không token → 401.
    status, _ = server.dispatch(
        "GET", f"/api/agents/{a['id']}/messages", {}, b""
    )
    assert status == 401


def test_api_message_validation(world):
    server = world["server"]
    agent = world["a"]
    path = f"/api/agents/{agent['id']}/messages"
    headers = _agent_headers(agent)
    # Body rỗng / toàn khoảng trắng → 400.
    for body in (b"{}", json.dumps({"body": "   "}).encode()):
        status, _ = server.dispatch("POST", path, headers, body)
        assert status == 400
    # JSON hỏng → 400.
    status, _ = server.dispatch("POST", path, headers, b"{khong phai json")
    assert status == 400
    # Quá dài → 413.
    status, _ = server.dispatch(
        "POST", path, headers,
        json.dumps({"body": "x" * (Store.MESSAGE_BODY_LIMIT + 1)}).encode(),
    )
    assert status == 413
    # Gắn lệnh không tồn tại → 400.
    status, _ = server.dispatch(
        "POST", path, headers,
        json.dumps({"body": "ok", "command_id": "khong-co"}).encode(),
    )
    assert status == 400
    # up_to_id không phải số → 400.
    status, _ = server.dispatch(
        "POST", path + "/read", headers,
        json.dumps({"up_to_id": "abc"}).encode(),
    )
    assert status == 400


def test_api_longpoll_wakes_on_new_user_message(world):
    server = world["server"]
    agent = world["a"]
    outcome = {}

    def poll():
        started = time.monotonic()
        status, payload = server.dispatch(
            "GET", f"/api/agents/{agent['id']}/messages?unread=1&wait=10",
            _agent_headers(agent), b"",
        )
        outcome["elapsed"] = time.monotonic() - started
        outcome["status"] = status
        outcome["payload"] = payload

    thread = threading.Thread(target=poll)
    thread.start()
    time.sleep(0.4)  # chắc chắn long-poll đã treo
    store = _store(world)
    store.add_message(agent["id"], "user", "tin mới nè")
    store.close()
    server.notify_messages_changed()
    thread.join(timeout=8)
    assert not thread.is_alive()
    assert outcome["status"] == 200
    assert outcome["elapsed"] < 5
    assert outcome["payload"]["unread"] == 1
    assert outcome["payload"]["messages"][0]["body"] == "tin mới nè"


# --------------------------------------------------------------------- #
# UI — khung chat + panel Tài khoản + điểm vào
# --------------------------------------------------------------------- #
def test_chat_widget_send_with_context_chip(qapp, tmp_path):
    from app.ui.agent_chat import AgentChatWidget

    store = Store(tmp_path / "ui.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    command = store.create_command(
        "free", profile_id=profile["id"], instruction="hỏi về lệnh này"
    )
    woke = []
    widget = AgentChatWidget(store, wake_bridge=lambda: woke.append(1))
    widget.set_agent(agent, context_command_id=command["id"])
    assert widget._context_command_id == command["id"]

    widget.composer.setPlainText("Lệnh này sao chậm vậy?")
    widget._send()
    messages = store.list_messages(agent["id"])
    assert len(messages) == 1
    assert messages[0]["direction"] == "user"
    assert messages[0]["command_id"] == command["id"]
    assert woke == [1]  # cầu nối được đánh thức ngay khi gửi
    # Chip ngữ cảnh chỉ gắn MỘT tin đầu — tin sau là tin thường.
    assert widget._context_command_id is None
    widget.composer.setPlainText("thêm một tin nữa")
    widget._send()
    messages = store.list_messages(agent["id"])
    assert messages[1]["command_id"] is None
    widget.close()
    store.close()


def test_agents_panel_two_columns_badge_and_open_chat(qapp, tmp_path):
    from app.ui.agents_panel import AgentsPanel

    store = Store(tmp_path / "ui.db")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.add_message(agent["id"], "agent", "báo cáo nè")
    panel = AgentsPanel(store)
    # Hai cột: splitter chứa bảng (trái) + khung chat (phải).
    assert panel.agents_splitter.count() == 2
    assert panel.agents_splitter.widget(1) is panel.chat_widget
    # Huy hiệu chưa đọc ở ô tên của agent.
    name_cell = panel.table.item(0, 0).text()
    assert "💬 1 chưa đọc" in name_cell
    # Mở chat từ điểm vào ngoài: đúng agent + chip ngữ cảnh.
    profile = store.add_profile("Kenh A", "a@gmail.com")
    command = store.create_command("free", profile_id=profile["id"])
    assert panel.open_chat(agent["id"], command["id"]) is True
    assert panel.chat_widget.agent_id == agent["id"]
    assert panel.chat_widget._context_command_id == command["id"]
    assert panel.open_chat(9999) is False
    panel.close()
    store.close()


def test_queue_row_ask_signal_reaches_panel(qapp, tmp_path):
    from app.ui.commands_panel import CommandsPanel

    store = Store(tmp_path / "ui.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    store.create_command("free", profile_id=profile["id"],
                         instruction="việc trong hàng đợi")
    panel = CommandsPanel(store)
    panel.refresh()
    asked = []
    panel.ask_about_command.connect(asked.append)
    rows = [
        panel.queue_layout.itemAt(i).widget()
        for i in range(panel.queue_layout.count())
    ]
    rows = [r for r in rows if r is not None and hasattr(r, "ask_requested")]
    assert rows, "hàng đợi phải có ít nhất một dòng lệnh"
    rows[0].ask_requested.emit(rows[0].command_id)
    assert asked == [rows[0].command_id]
    panel.close()
    store.close()


def test_office_panel_embeds_chat_in_place(qapp, tmp_path):
    """V4.6 (sửa phạm vi 10:46): panel Văn phòng NHÚNG khung chat
    ĐẦY ĐỦ — chọn agent là trò chuyện tại chỗ; KHÔNG còn nút/tín
    hiệu nhảy sang mục Tài khoản để chat."""
    from app.ui.agent_chat import AgentChatWidget
    from app.ui.office_view import OfficeView

    store = Store(tmp_path / "ui.db")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.touch_agent_heartbeat(agent["id"])
    view = OfficeView(store, settings={})
    assert isinstance(view.chat_widget, AgentChatWidget)
    assert not hasattr(view, "btn_chat")
    assert not hasattr(view, "chat_agent_requested")
    view.select_agent(agent["id"])
    assert view.chat_widget.agent_id == agent["id"]
    # Gửi tin ngay tại panel Văn phòng → vào đúng thread trong Store.
    view.chat_widget.composer.setPlainText("Chào từ văn phòng")
    view.chat_widget._send()
    bodies = [m["body"] for m in store.list_messages(agent["id"])]
    assert bodies == ["Chào từ văn phòng"]
    view.close()
    store.close()


def test_mainwindow_open_command_chat_resolves_owner(qapp, tmp_path, monkeypatch):
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow, SEC_OFFICE

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    command = store.create_command(
        "create_video", profile_id=profile["id"], instruction="làm video"
    )
    window = MainWindow(store, ChromeManager(), settings)
    try:
        # V4.6 (10:46): đích là VĂN PHÒNG (không phải Tài khoản) —
        # agent được chọn trong văn phòng, chip ngữ cảnh lệnh nằm
        # ở khung chat của văn phòng.
        window._open_command_chat(command["id"])
        assert window.sections.currentIndex() == SEC_OFFICE
        assert window.office_panel.chat_widget.agent_id == agent["id"]
        assert (
            window.office_panel.chat_widget._context_command_id
            == command["id"]
        )
    finally:
        window.close()
        store.close()
