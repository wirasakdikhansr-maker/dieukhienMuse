"""V7.1 — lưới xem trực tiếp (trình duyệt không nhúng, không che nhau) +
cột Tiến độ công việc ở Văn phòng."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import muse_control, progress_board  # noqa: E402
from app.store import Store  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


# --------------------------------------------------------------------------- #
# Trình duyệt chạy độc lập khung nhìn
# --------------------------------------------------------------------------- #
def test_chrome_never_sleeps_when_covered():
    from app.chrome_manager import ChromeManager

    flags = " ".join(ChromeManager.QUIET_FLAGS)
    for flag in ("--disable-backgrounding-occluded-windows", "--disable-renderer-backgrounding",
                 "--disable-background-timer-throttling"):
        assert flag in flags
    assert "--window-size=1366,900" in ChromeManager.HIDDEN_FLAGS


class _Client:
    def __init__(self, width):
        self.width = width
        self.calls = []

    def call(self, method, params=None):
        self.calls.append(method)
        return {}

    def evaluate(self, expr, timeout=None):
        if expr == "window.innerWidth":
            return self.width
        return {"url": "u", "title": "t", "text": "", "dialogs": [], "elements": []}

    def navigate_and_wait(self, url, timeout=30):
        pass


def test_automation_forces_focus_and_desktop_viewport_on_small_windows():
    small = _Client(420)
    muse_control.run_actions(small, [{"action": "goto", "url": "https://studio.youtube.com"}],
                             sleep=lambda s: None, visual=False)
    assert "Emulation.setFocusEmulationEnabled" in small.calls
    assert "Emulation.setDeviceMetricsOverride" in small.calls
    assert small.calls[-1] == "Emulation.clearDeviceMetricsOverride"
    big = _Client(1366)
    muse_control.run_actions(big, [{"action": "wait", "seconds": 0}], sleep=lambda s: None, visual=False)
    assert "Emulation.setDeviceMetricsOverride" not in big.calls


def test_live_grid_tiles_activity_and_take_control(qapp):
    from app.ui.live_grid import LiveGrid

    taken = []
    grid = LiveGrid(manager=None)
    grid.resize(1400, 900)
    grid.take_control.connect(taken.append)
    grid.set_entries([{"id": 2, "label": "B", "gmail": "b@x"}, {"id": 1, "label": "A", "gmail": "a@x"}])
    assert list(grid.tiles) == [1, 2] and not grid.empty.isVisibleTo(grid)
    grid.set_activity(1, "🤖 Muse 01: bước 2/5 · bấm «Đăng»")
    assert "bước 2/5" in grid.tiles[1].caption.text()
    grid.tiles[2].control_button.click()
    assert taken == [2]
    grid.set_activity(1, "")
    assert "rảnh" in grid.tiles[1].caption.text().lower()
    grid.set_entries([{"id": 1, "label": "A"}])
    assert list(grid.tiles) == [1]


def test_window_grid_mode_replaces_embedding(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    win = MainWindow(st, ChromeManager(), settings)
    try:
        profiles = [st.add_profile(f"P{i}", f"p{i}@gmail.com") for i in range(3)]
        monkeypatch.setattr(win, "_running_profiles", lambda: [st.get_profile(p["id"]) for p in profiles])
        monkeypatch.setattr(win.live_grid, "start", lambda: None)
        assert win._stream_mode()
        win._grid_tick(win._running_profiles())  # ≥2 trình duyệt → tự bật lưới
        assert win._grid_active and win.center_stack.currentWidget() is win.live_grid
        assert len(win.live_grid.tiles) == 3
        win._on_control_step({"profile_id": profiles[1]["id"], "label": "P1", "agent": "Muse 01",
                              "index": 1, "total": 3, "text": "bấm «Tạo»", "state": "run"})
        assert "bước 1/3" in win.live_grid.tiles[profiles[1]["id"]].caption.text()
        win._grid_take_control(profiles[0]["id"])
        assert not win._grid_active and win._current_profile_id == profiles[0]["id"]
        win._grid_tick(win._running_profiles())  # bạn vừa tắt tay → không tự bật lại ngay
        assert not win._grid_active
    finally:
        win.live_grid.stop()
        win.close()


# --------------------------------------------------------------------------- #
# Cột tiến độ công việc
# --------------------------------------------------------------------------- #
def test_progress_board_shows_concrete_work(store):
    a = store.create_agent("Muse 01", "a@x.com")
    b = store.create_agent("Muse 02", "b@x.com")
    p = store.add_profile("Kids", "k@gmail.com")
    store.upsert_channel(p["id"], {"channel_id": "UCk", "name": "Kênh A"})
    c = store.create_command("create_video", source="lead", profile_id=p["id"], channel_id="UCk", agent_id=a["id"],
                             instruction="Làm video kids tập 1", payload={"title": "Làm video kids tập 1"})
    store.update_command(c["id"], status="running")
    store.update_command_progress(c["id"], 60, "Tạo video: cảnh 20/30")
    store.create_command("upload", agent_id=a["id"], instruction="Đăng tập 1")
    data = progress_board.build(store, {})
    first = next(x for x in data["agents"] if x["agent_id"] == a["id"])
    cur = first["current"]
    assert cur["title"] == "Làm video kids tập 1" and cur["channel"] == "Kênh A"
    assert cur["pct"] == 60 and cur["by"] == "Trưởng phòng"
    assert cur["sub"] == {"label": "cảnh", "done": 20, "total": 30, "pct": 67}
    assert len(first["queue"]) == 1
    idle = next(x for x in data["agents"] if x["agent_id"] == b["id"])
    assert idle["current"] is None and data["busy"] == 1


def test_progress_panel_renders_and_toggles(qapp, store):
    from app.ui.office_iso import OfficeIsoView

    a = store.create_agent("Muse 01", "a@x.com")
    c = store.create_command("create_video", agent_id=a["id"], instruction="Video kids tập 2")
    store.update_command(c["id"], status="running")
    store.update_command_progress(c["id"], 35, "Dựng cảnh 7/20")
    view = OfficeIsoView(store, {})
    view.resize(1500, 800)
    view.show()
    view.refresh(force=True)
    panel = view.progress
    assert "1/1 ĐANG LÀM" in panel.title.text()
    texts = " ".join(w.text() for w in panel.findChildren(type(panel.title)))
    assert "Video kids tập 2" in texts and "cảnh 7/20" in texts
    view.progress_toggle.setChecked(False)
    assert not panel.isVisible()
    view.progress_toggle.setChecked(True)
    assert panel.isVisible()
    view.close()
