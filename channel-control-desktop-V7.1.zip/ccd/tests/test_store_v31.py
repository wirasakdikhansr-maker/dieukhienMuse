"""Kiểm thử V3.1 cho kho dữ liệu: WAL, di trú schema + idempotent,
khôi phục lệnh gián đoạn, meta, thống kê, xuất dữ liệu."""

import json
import sqlite3

import pytest

from app import store as store_module
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "test.sqlite3")
    yield s
    s.close()


def test_wal_mode_enabled(store):
    mode = store._conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert str(mode).lower() == "wal"


def test_schema_version_and_migration_idempotent(tmp_path):
    path = tmp_path / "test.sqlite3"
    s = Store(path)
    assert s.schema_version == store_module.SCHEMA_VERSION
    # Chạy lại di trú: không lỗi, phiên bản không đổi, dữ liệu còn nguyên.
    profile = s.add_profile("AwakeInTheDark", "a@gmail.com")
    s._migrate()
    s._migrate()
    assert s.schema_version == store_module.SCHEMA_VERSION
    assert s.get_profile(profile["id"])["label"] == "AwakeInTheDark"
    s.close()
    # Mở lại DB cũ: vẫn nguyên vẹn.
    s2 = Store(path)
    assert s2.schema_version == store_module.SCHEMA_VERSION
    assert s2.get_profile(profile["id"]) is not None
    s2.close()


def test_legacy_v3_database_is_migrated(tmp_path):
    """DB tạo kiểu V3 (chỉ SCHEMA gốc, user_version=0, chưa có app_meta /
    cột attempts) mở bằng Store mới phải được nâng cấp êm thấm."""
    path = tmp_path / "legacy.sqlite3"
    conn = sqlite3.connect(str(path))
    conn.executescript(store_module.SCHEMA)
    conn.execute(
        "INSERT INTO profiles (slug, label, gmail, note, port, created_at)"
        " VALUES ('legacy', 'Legacy', 'l@gmail.com', '', 19500, '2026-01-01T00:00:00+07:00')"
    )
    conn.commit()
    conn.close()

    s = Store(path)
    assert s.schema_version == store_module.SCHEMA_VERSION
    columns = {row[1] for row in s._conn.execute("PRAGMA table_info(commands)")}
    assert "attempts" in columns
    tables = {
        row[0]
        for row in s._conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }
    assert "app_meta" in tables
    assert s.get_profile_by_slug("legacy") is not None
    s.close()


def test_recover_interrupted_and_requeue(store):
    profile = store.add_profile("AwakeInTheDark", "a@gmail.com")
    cmd = store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="queued"
    )
    assert store.claim_command(cmd["id"]) is True  # -> running
    count = store.recover_interrupted_commands()
    assert count == 1
    assert store.get_command(cmd["id"])["status"] == "interrupted"
    # Không còn lệnh running nào khác -> khôi phục tiếp ra 0.
    assert store.recover_interrupted_commands() == 0
    # Thử lại: lệnh tại-chỗ về 'queued', xoá dấu vết cũ.
    row = store.requeue_command(cmd["id"])
    assert row["status"] == "queued"
    assert row["started_at"] is None and row["finished_at"] is None


def test_requeue_claude_command_goes_back_to_waiting(store):
    # V4.0 (Đ5): lệnh chờ Muse thử lại về 'queued' — dispatcher xét
    # lại điều kiện rồi mới đẩy lên 'waiting_muse' (trước V4.0 về thẳng
    # waiting_muse). Tên test giữ nguyên để truy vết lịch sử.
    profile = store.add_profile("AwakeInTheDark", "a@gmail.com")
    cmd = store.create_command(
        "optimize", source="ui", profile_id=profile["id"], status="waiting_muse"
    )
    store.finish_command(cmd["id"], "failed", error="hỏng")
    row = store.requeue_command(cmd["id"])
    assert row["status"] == "queued"
    # Lệnh done không thử lại được.
    store.finish_command(cmd["id"], "done", result="ok")
    assert store.requeue_command(cmd["id"]) is None


def test_meta_roundtrip(store):
    assert store.get_meta("startup_diagnostics") is None
    store.set_meta("startup_diagnostics", '{"ok": true}')
    assert store.get_meta("startup_diagnostics") == '{"ok": true}'
    store.set_meta("startup_diagnostics", '{"ok": false}')
    assert store.get_meta("startup_diagnostics") == '{"ok": false}'


def test_integrity_check_ok(store):
    assert store.integrity_check() == "ok"


def test_stats_counts(store):
    profile = store.add_profile("AwakeInTheDark", "a@gmail.com")
    store.upsert_channel(
        profile["id"],
        {"channel_id": "UC1", "name": "Kênh 1", "subs": 120},
    )
    store.upsert_channel(
        profile["id"],
        {"channel_id": "UC2", "name": "Kênh 2", "subs": 30},
    )
    store.upsert_video(
        profile["id"], {"video_id": "v1", "status": "scheduled", "title": "A"}
    )
    store.upsert_video(
        profile["id"], {"video_id": "v2", "status": "public", "title": "B"}
    )
    store.create_command("scan", source="ui", profile_id=profile["id"], status="queued")
    store.create_command(
        "optimize", source="ui", profile_id=profile["id"], status="waiting_muse"
    )
    stats = store.stats()
    assert stats["channels"] == 2
    assert stats["subscribers"] == 150
    assert stats["videos_scheduled"] == 1
    assert stats["commands_pending"] == 2
    assert stats["commands_running"] == 0
    assert stats["profiles"] == 1


def test_exports_json_and_csv(store):
    profile = store.add_profile("AwakeInTheDark", "a@gmail.com")
    store.upsert_channel(
        profile["id"],
        {"channel_id": "UC1", "name": "Awake in the Dark", "subs": 7},
    )
    store.append_journal("Dòng nhật ký mẫu", profile["id"])

    data = json.loads(store.export_channels("json"))
    assert data[0]["channel_id"] == "UC1"
    assert data[0]["profile_slug"] == profile["slug"]

    csv_text = store.export_channels("csv")
    assert "channel_id" in csv_text.splitlines()[0]
    assert "Awake in the Dark" in csv_text

    journal = json.loads(store.export_journal("json"))
    assert journal[-1]["message"] == "Dòng nhật ký mẫu"

    with pytest.raises(ValueError):
        store.export_channels("yaml")


def test_mark_command_attempt(store):
    cmd = store.create_command("scan", status="queued")
    assert cmd["attempts"] == 0
    store.mark_command_attempt(cmd["id"])
    store.mark_command_attempt(cmd["id"])
    assert store.get_command(cmd["id"])["attempts"] == 2
