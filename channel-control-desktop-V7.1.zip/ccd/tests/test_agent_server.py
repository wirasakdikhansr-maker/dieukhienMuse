"""Kiểm thử Agent API (V2) — server chạy trên cổng tạm (ephemeral) với thư
mục dữ liệu tạm; Chrome và bước quét được thay bằng bản giả (stub), còn
Store là bản thật trên DB tạm.
"""

import hashlib
import os
import json
import time
import urllib.error
import urllib.request

import pytest

from app import config
from app.agent_server import AgentServer, sanitize_file_name
from app.store import Store


# --------------------------------------------------------------------------- #
# Bản giả cho ChromeManager / trang CDP / bước quét
# --------------------------------------------------------------------------- #
class FakeClient:
    def __init__(self):
        self.navigated: list[str] = []
        self.closed = False

    def navigate(self, url):
        self.navigated.append(url)

    def close(self):
        self.closed = True


class FakeManager:
    def __init__(self):
        self.launched: list[str] = []
        self.client = FakeClient()

    def launch(self, profile):
        self.launched.append(profile["slug"])
        return "launched"

    def is_running(self, profile):
        return profile["slug"] in self.launched

    def connect_page(self, profile):
        return self.client


def stub_scan(store, profile, manager, log=None):
    """Bản giả của scanner.scan_profile: ghi 2 kênh mẫu rồi báo ok."""
    channels = [
        {
            "channel_id": "UC_TEST_1",
            "name": "Awake in the Dark",
            "handle": "@AwakeInTheDarkSeries",
            "url": "https://www.youtube.com/channel/UC_TEST_1",
            "subs": 0,
            "video_count": 2,
            "niche": "",
        },
        {
            "channel_id": "UC_TEST_2",
            "name": "Bonitas Viejitas 70s 80s 90s",
            "handle": "@LatinPop202x",
            "url": "https://www.youtube.com/channel/UC_TEST_2",
            "subs": 43,
            "video_count": 57,
            "niche": "",
        },
    ]
    for channel in channels:
        store.upsert_channel(profile["id"], channel)
    store.mark_profile_scanned(profile["id"])
    return {"status": "ok", "channels": channels, "message": "quét giả lập"}


# --------------------------------------------------------------------------- #
# Fixture server
# --------------------------------------------------------------------------- #
@pytest.fixture()
def agent(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    seed.close()

    manager = FakeManager()
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},  # cổng 0 = hệ điều hành chọn cổng trống
        manager=manager,
        scan_fn=stub_scan,
    )
    server.start()
    yield {
        "server": server,
        "manager": manager,
        "data_dir": data_dir,
        "slug": profile["slug"],
        "base": f"http://127.0.0.1:{server.port}",
        "token": server.token,
    }
    server.stop()


def call(agent, method, path, token="__server__", body=None, headers=None):
    hdrs = dict(headers or {})
    if token == "__server__":
        hdrs["X-Agent-Token"] = agent["token"]
    elif token:
        hdrs["X-Agent-Token"] = token
    req = urllib.request.Request(
        agent["base"] + path, data=body, method=method, headers=hdrs
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def wait_command(agent, command_id, timeout=10.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        status, payload = call(agent, "GET", f"/api/commands/{command_id}")
        assert status == 200
        record = payload["command"]
        if record["status"] in ("done", "failed"):
            return record
        time.sleep(0.05)
    raise AssertionError(f"Lệnh {command_id} không kết thúc sau {timeout}s")


# --------------------------------------------------------------------------- #
# Kiểm thử
# --------------------------------------------------------------------------- #
def test_sanitize_file_name():
    assert sanitize_file_name("../../evil.txt") == "evil.txt"
    assert sanitize_file_name("..\\..\\video ep01.mp4") == "video_ep01.mp4"
    assert sanitize_file_name("") == "file"
    assert sanitize_file_name(None) == "file"


def test_health_is_open_without_token(agent):
    status, payload = call(agent, "GET", "/api/health", token=None)
    assert status == 200
    assert payload["ok"] is True
    assert payload["version"] == "2.8"  # V6.1: due_at; V6.0: + verdict/scorecard (V4.6 từng là 2.6)


def test_auth_enforced(agent):
    status, _ = call(agent, "GET", "/api/profiles", token=None)
    assert status == 401
    status, _ = call(agent, "GET", "/api/profiles", token="sai-token")
    assert status == 401
    status, _ = call(agent, "GET", "/api/journal", token=None)
    assert status == 401
    status, payload = call(agent, "GET", "/api/profiles")
    assert status == 200
    assert payload["ok"] is True


def test_token_generated_and_persisted(agent):
    assert agent["token"]
    saved = json.loads((agent["data_dir"] / "settings.json").read_text(encoding="utf-8"))
    assert saved["agent_token"] == agent["token"]


def test_profiles_include_channels_and_session_status(agent):
    # Quét đồng bộ trước để có kênh trong DB.
    status, payload = call(agent, "POST", f"/api/profiles/{agent['slug']}/scan", body=b"")
    assert status == 200
    assert payload["status"] == "ok"
    assert payload["channels_found"] == 2

    status, payload = call(agent, "GET", "/api/profiles")
    assert status == 200
    (entry,) = payload["profiles"]
    assert entry["slug"] == agent["slug"]
    assert len(entry["channels"]) == 2
    assert "session_status" in entry
    assert entry["last_scan_at"]


def test_open_endpoint_and_channels_endpoint(agent):
    status, payload = call(agent, "POST", f"/api/profiles/{agent['slug']}/open", body=b"")
    assert status == 200
    assert payload["chrome"] == "launched"
    assert agent["manager"].launched == [agent["slug"]]

    status, payload = call(agent, "GET", f"/api/profiles/{agent['slug']}/channels")
    assert status == 200
    assert payload["channels"] == []

    status, _ = call(agent, "POST", "/api/profiles/khong-co/open", body=b"")
    assert status == 404


def test_inbox_saves_bytes_and_verifies_sha(agent):
    data = b"hello inbox \x00\x01\x02"
    digest = hashlib.sha256(data).hexdigest()
    status, payload = call(
        agent, "POST", "/api/inbox", body=data,
        headers={"X-File-Name": "clip.mp4", "X-File-Sha256": digest},
    )
    assert status == 200
    assert payload["size"] == len(data)
    assert payload["sha256"] == digest
    saved = agent["data_dir"] / "inbox" / payload["name"]
    assert saved.exists()
    assert saved.read_bytes() == data
    assert payload["name"].endswith("_clip.mp4")

    # sha sai → 400 và không có file mới.
    before = set((agent["data_dir"] / "inbox").iterdir())
    status, _ = call(
        agent, "POST", "/api/inbox", body=b"khac",
        headers={"X-File-Name": "bad.bin", "X-File-Sha256": "0" * 64},
    )
    assert status == 400
    assert set((agent["data_dir"] / "inbox").iterdir()) == before


def test_inbox_sanitizes_traversal_name(agent):
    status, payload = call(
        agent, "POST", "/api/inbox", body=b"x",
        headers={"X-File-Name": "../../evil.txt"},
    )
    assert status == 200
    saved = agent["data_dir"] / "inbox" / payload["name"]
    assert saved.exists()
    assert saved.parent == agent["data_dir"] / "inbox"
    assert saved.name.endswith("_evil.txt")


def test_command_queue_scan_runs_to_done(agent):
    body = json.dumps({"type": "scan", "profile": agent["slug"]}).encode("utf-8")
    status, payload = call(agent, "POST", "/api/commands", body=body)
    assert status == 202
    assert payload["status"] == "queued"

    record = wait_command(agent, payload["command_id"])
    assert record["status"] == "done"
    assert record["result"]["channels_found"] == 2

    status, payload = call(agent, "GET", f"/api/profiles/{agent['slug']}/channels")
    assert status == 200
    assert len(payload["channels"]) == 2


def test_command_open_browser_and_navigate(agent):
    body = json.dumps({"type": "open_browser", "profile": agent["slug"]}).encode()
    status, payload = call(agent, "POST", "/api/commands", body=body)
    record = wait_command(agent, payload["command_id"])
    assert record["status"] == "done"
    assert record["result"]["chrome"] == "launched"

    body = json.dumps({
        "type": "cdp_navigate",
        "profile": agent["slug"],
        "payload": {"url": "https://studio.youtube.com/"},
    }).encode()
    status, payload = call(agent, "POST", "/api/commands", body=body)
    record = wait_command(agent, payload["command_id"])
    assert record["status"] == "done"
    assert agent["manager"].client.navigated == ["https://studio.youtube.com/"]
    assert agent["manager"].client.closed is True


def test_command_validation_errors(agent):
    body = json.dumps({"type": "scan", "profile": "khong-co"}).encode()
    status, _ = call(agent, "POST", "/api/commands", body=body)
    assert status == 404

    body = json.dumps({"type": "xoa_het", "profile": agent["slug"]}).encode()
    status, _ = call(agent, "POST", "/api/commands", body=body)
    assert status == 400

    status, _ = call(agent, "GET", "/api/commands/khong-co-id")
    assert status == 404


def test_journal_records_api_actions(agent):
    call(agent, "POST", f"/api/profiles/{agent['slug']}/open", body=b"")
    call(agent, "POST", "/api/inbox", body=b"abc", headers={"X-File-Name": "a.txt"})
    status, payload = call(agent, "GET", "/api/journal?limit=100")
    assert status == 200
    messages = [entry["message"] for entry in payload["entries"]]
    assert any("[API]" in m and "Mở Chrome" in m for m in messages)
    assert any("[API]" in m and "Nhận file" in m for m in messages)
    assert any("[API]" in m and "khởi động" in m for m in messages)


# --------------------------------------------------------------------------- #
# V6.3: file lớn theo khúc qua HTTP (PUT ghi theo luồng) + quy tắc + ảnh chụp
# --------------------------------------------------------------------------- #
def test_v63_large_upload_over_http_and_rules(agent):
    import hashlib

    data = os.urandom(200_000)
    status, init = call(agent, "POST", "/api/files/upload", body=json.dumps(
        {"name": "big.mp4", "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    ).encode(), headers={"Content-Type": "application/json"})
    assert status == 200, init
    uid = init["upload"]["id"]
    status, part = call(agent, "PUT", f"/api/files/upload/{uid}?offset=0", body=data[:120_000])
    assert status == 200 and part["upload"]["received"] == 120_000
    status, bad = call(agent, "PUT", f"/api/files/upload/{uid}?offset=0", body=b"x")
    assert status == 409
    status, part = call(agent, "PUT", f"/api/files/upload/{uid}?offset=120000", body=data[120_000:])
    assert status == 200
    status, done = call(agent, "POST", f"/api/files/upload/{uid}/complete", body=b"")
    assert status == 200 and done["upload"]["status"] == "done"
    assert open(done["upload"]["saved"], "rb").read() == data
    status, unauth = call(agent, "PUT", f"/api/files/upload/{uid}?offset=0", token="sai", body=b"x")
    assert status == 401
    status, rules = call(agent, "GET", "/api/rules")
    assert status == 200 and "BẰNG CHỨNG" in rules["agent_rules"]
    status, listing = call(agent, "GET", "/api/commands")
    assert status == 200
