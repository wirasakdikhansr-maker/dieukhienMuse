"""V4.0 (H2) — Dispatcher: xét điều kiện trước khi giao lệnh cho Muse.

Lệnh Muse mới nằm ở 'queued'; dispatcher (logic thuần, hooks tiêm
vào) chỉ đẩy lên 'waiting_muse' khi: tới giờ hẹn, dependency xong,
mỗi hồ sơ tối đa MỘT lệnh Muse đang chạy, hồ sơ không tạm dừng, có
Muse phụ trách chưa bị thu hồi, payload sẵn sàng (upload có file
thật/video đã biết) và — khi có hooks — cổng trình duyệt/đăng nhập
xong. Chưa đủ điều kiện = GIỮ + ghi bước chờ, tuyệt đối không failed.
"""

from datetime import datetime, timedelta

import pytest

from app.dispatcher import Dispatcher
from app.store import Store


@pytest.fixture()
def world(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    yield {"store": store, "profile": profile, "agent": agent, "tmp": tmp_path}
    store.close()


def queued(store, profile, ctype="optimize", source="ui", **kw):
    return store.create_command(
        ctype,
        source=source,
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        **kw,
    )


def test_scheduled_in_future_is_held(world):
    store = world["store"]
    future = (datetime.now().astimezone() + timedelta(hours=1)).isoformat(
        timespec="seconds"
    )
    cmd = queued(store, world["profile"], scheduled_at=future)
    assert Dispatcher(store).tick() == []
    assert store.get_command(cmd["id"])["status"] == "queued"


def test_depends_on_waits_then_promotes_after_done(world):
    store = world["store"]
    dep = queued(store, world["profile"], ctype="scan")
    child = queued(store, world["profile"], depends_on=str(dep["id"]))
    Dispatcher(store).tick()
    assert store.get_command(child["id"])["status"] == "queued"
    assert "Đang chờ" in (store.get_command(child["id"])["step"] or "")
    store.finish_command(dep["id"], "done")
    Dispatcher(store).tick()
    assert store.get_command(child["id"])["status"] == "waiting_muse"


def test_depends_on_failed_fails_child_with_reason(world):
    store = world["store"]
    dep = queued(store, world["profile"], ctype="scan")
    child = queued(store, world["profile"], depends_on=str(dep["id"]))
    store.finish_command(dep["id"], "failed", error="quét lỗi")
    Dispatcher(store).tick()
    row = store.get_command(child["id"])
    assert row["status"] == "failed"
    assert f"#{dep['id']}" in (row["error"] or "")


def test_one_running_claude_command_per_profile(world):
    store = world["store"]
    first = queued(store, world["profile"])
    second = queued(store, world["profile"])
    # Chốt thứ tự tạo PHÂN BIỆT được: hai lệnh tạo trong cùng một giây
    # có created_at (độ chính xác giây) giống hệt nhau, dispatcher bẻ
    # hoà bằng id ngẫu nhiên → lệnh nào được đẩy trước thành tung
    # đồng xu (test gãy ~50% lần chạy — flaky có sẵn, không phải hồi
    # quy). Gán tay mốc cũ hơn cho lệnh đầu để thứ tự xác định.
    store._conn.execute(
        "UPDATE commands SET created_at = '2000-01-01T00:00:00+07:00'"
        " WHERE id = ?",
        (first["id"],),
    )
    store._conn.commit()
    Dispatcher(store).tick()
    assert store.get_command(first["id"])["status"] == "waiting_muse"
    assert store.get_command(second["id"])["status"] == "queued"  # 1 hồ sơ 1 lệnh/lúc
    store.claim_claude_command(first["id"], world["agent"]["id"], 120)
    Dispatcher(store).tick()
    assert store.get_command(second["id"])["status"] == "queued"
    store.finish_command(first["id"], "done")
    Dispatcher(store).tick()
    assert store.get_command(second["id"])["status"] == "waiting_muse"


def test_priority_ui_then_auto_then_api(world):
    store = world["store"]
    profiles = [
        store.add_profile(f"Kenh {n}", f"{n}@gmail.com") for n in ("b", "c", "d")
    ]
    # assign_profiles thay TOÀN BỘ danh sách mỗi lần gọi — gom một lần.
    store.assign_profiles(world["agent"]["id"], [p["id"] for p in profiles])
    c_api = queued(store, profiles[0], source="api")
    c_auto = queued(store, profiles[1], source="auto")
    c_ui = queued(store, profiles[2], source="ui")
    promoted = Dispatcher(store).tick()
    assert [c["id"] for c in promoted] == [c_ui["id"], c_auto["id"], c_api["id"]]


def test_paused_profile_held_with_step(world):
    store = world["store"]
    cmd = queued(store, world["profile"])
    store.set_profile_paused(world["profile"]["id"], True)
    assert Dispatcher(store).tick() == []
    row = store.get_command(cmd["id"])
    assert row["status"] == "queued"
    assert "tạm dừng" in (row["step"] or "")


def test_unassigned_profile_held_with_flag_and_open_promotes(world):
    store = world["store"]
    profile2 = store.add_profile("Kenh Z", "z@gmail.com")
    cmd = queued(store, profile2)
    Dispatcher(store).tick()
    row = store.get_command(cmd["id"])
    assert row["status"] == "queued"
    assert "Chưa có Muse phụ trách" in (row["step"] or "")
    payload = row["payload"] if isinstance(row["payload"], dict) else {}
    assert payload.get("dispatch_warned_no_owner") is True


def test_upload_waits_for_file_then_promotes(world):
    store = world["store"]
    store.upsert_channel(
        world["profile"]["id"],
        {"channel_id": "UCupload00000000000000", "title": "Kênh Upload"},
    )
    cmd = queued(
        store,
        world["profile"],
        ctype="upload",
        channel_id="UCupload00000000000000",
        payload={"file": "clip.mp4"},
    )
    dispatcher = Dispatcher(store, data_dir=world["tmp"] / "data")
    assert dispatcher.tick() == []
    row = store.get_command(cmd["id"])
    assert row["status"] == "queued"
    assert "chờ file" in (row["step"] or "")
    inbox = world["tmp"] / "data" / "inbox"
    inbox.mkdir(parents=True)
    (inbox / "clip.mp4").write_bytes(b"fake-video")
    promoted = dispatcher.tick()
    assert [c["id"] for c in promoted] == [cmd["id"]]
    assert store.get_command(cmd["id"])["status"] == "waiting_muse"


def test_hooks_are_ignored_dispatcher_never_gates_on_browser(world):
    """V4.2 (O-18) thay cho hai test cổng trình duyệt cũ: cổng
    trình duyệt/đăng nhập đã XOÁ DỨT ĐIỂM khỏi dispatcher — hooks
    truyền vào (kể cả hooks độc: báo chưa đăng nhập, đòi needs_user,
    hay ném lỗi) bị BỎ QUA hoàn toàn, lệnh vẫn promote theo điều
    kiện dữ liệu như thường. Lệnh đã cấp là tới thẳng Muse."""
    store = world["store"]
    cmd = queued(store, world["profile"])
    calls = []

    def poison(profile):
        calls.append(profile["id"])
        raise RuntimeError("hooks độc — không được phép chạy")

    hooks = {
        "ensure_browser_open": poison,
        "probe_logged_in": poison,
        "attempt_login": lambda profile: {
            "status": "needs_user",
            "message": "Cần xác minh 2 bước trên điện thoại",
        },
    }
    promoted = Dispatcher(store, hooks=hooks).tick()
    assert calls == []  # không hook nào được gọi
    assert [c["id"] for c in promoted] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "waiting_muse"


def test_same_second_commands_promote_in_insertion_order(world):
    """Hồi quy tận gốc cho test flaky: hai lệnh tạo CÙNG một giây
    (created_at giống hệt) phải được dispatcher xét theo thứ tự CHÈN
    (rowid/_seq), không theo id UUID ngẫu nhiên."""
    store = world["store"]
    first = queued(store, world["profile"])
    second = queued(store, world["profile"])
    same_ts = "2026-01-01T00:00:00+07:00"
    store._conn.execute(
        "UPDATE commands SET created_at = ? WHERE id IN (?, ?)",
        (same_ts, first["id"], second["id"]),
    )
    store._conn.commit()
    rows = {c["id"]: c for c in store.list_commands(status="queued")}
    assert rows[first["id"]]["_seq"] < rows[second["id"]]["_seq"]
    Dispatcher(store).tick()
    assert store.get_command(first["id"])["status"] == "waiting_muse"
    assert store.get_command(second["id"])["status"] == "queued"
