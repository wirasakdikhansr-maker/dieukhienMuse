"""V5.0 — mô hình giao việc theo dòng Agent.

Khoá: mẫu việc + checklist thường trực lưu file (tải lại đúng theo
kênh); hộp thoại Giao việc tick 3 việc + chọn skill → đúng 3 lệnh,
đúng agent/hồ sơ/kênh, payload có skill + ghi chú; nhập skill mới
(file + dán) hiện ngay trong danh sách chọn; bảng Theo Agent là view
mặc định của mục Công việc và phản ánh lệnh vừa tạo; menu chuột phải
của dòng kênh đủ 5 mục; tạm dừng đi qua cờ pause cấp hồ sơ sẵn có.
"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from app import assignments, skills_lib  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import work_model  # noqa: E402
from app.ui.agent_board import AgentBoardWidget  # noqa: E402
from app.ui.assign_dialog import (  # noqa: E402
    AssignDialog,
    StandingChecklistDialog,
)
from app.ui.commands_panel import CommandsPanel  # noqa: E402
from app.ui.work_panel import VIEW_AGENTS, WorkPanel  # noqa: E402


def _app():
    return QApplication.instance() or QApplication([])


def _world(tmp_path):
    """Store mẫu: 1 agent phụ trách 1 hồ sơ có 1 kênh."""
    store = Store(tmp_path / "ccd.db")
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.touch_agent_heartbeat(agent["id"])
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UCpip123",
            "name": "Pip Survives",
            "handle": "@PipSurvivesShow",
        },
    )
    channel = store.list_channels(profile["id"])[0]
    agent = store.get_agent(agent["id"])
    return store, agent, profile, channel


def _model(store):
    agents = store.list_agents()
    profiles = store.list_profiles()
    channels = {p["id"]: store.list_channels(p["id"]) for p in profiles}
    commands = store.list_commands(limit=500)
    return work_model.build_work_model(commands, agents, profiles, channels)


def _tick(editor, titles):
    for row in range(editor.template_list.count()):
        item = editor.template_list.item(row)
        item.setCheckState(
            Qt.CheckState.Checked
            if item.text() in titles
            else Qt.CheckState.Unchecked
        )


def test_style_lock_tokens_and_legacy_metamint_migration():
    """V5.0 khoá phong cách theo ảnh mẫu: accent #4ADE80, panel sáng
    bậc, bo góc lớn; bộ MetaMint đời đầu (chưa tuỳ biến) tự nâng lên
    bộ mới, bộ đã tuỳ biến thì giữ nguyên."""
    import dataclasses

    from app.ui import theme

    assert theme.ACCENT == "#CEFC19"
    # V5.1 (pin mới, plan §1.1): token duyệt mới thay bộ V5.0.
    assert theme.BG == "#0C0D0F"
    assert theme.PANEL == "#16171B"
    qss = theme.build_qss(theme.PRESETS["metamint"])
    assert qss == theme.APP_QSS
    assert "border-radius: 12px" in qss  # QFrame#Panel (V6.3.1: bo góc kiểu AI Studio)
    assert 'QPushButton[variant="primary"]' in qss
    assert "max-height: 4px" in qss  # V6.3.1: thanh tiến độ mảnh 4px kiểu AI Studio

    def flat(tokens):
        return {f.name: getattr(tokens, f.name) for f in dataclasses.fields(tokens)}

    migrated = theme.migrate_saved_tokens(flat(theme.LEGACY_METAMINT_TOKENS))
    assert migrated.accent == "#CEFC19"
    custom = flat(theme.METAMINT_TOKENS)
    custom["accent"] = "#FF00AA"
    kept = theme.migrate_saved_tokens(custom)
    assert kept.accent == "#FF00AA"


# --------------------------------------------------------------------- #
# Module assignments: mẫu + checklist thường trực
# --------------------------------------------------------------------- #
def test_default_templates_and_checklist_roundtrip(tmp_path):
    base = tmp_path / "data"
    templates = assignments.load_templates(base)
    titles = [t["title"] for t in templates]
    assert titles == [
        "Tạo video mới",
        "Tối ưu tiêu đề + mô tả + tags",
        "Kiểm tra tình trạng kênh",
        "Lên lịch phát hành",
        "Ghim bình luận sau khi đăng",
        "Trả lời bình luận mới",
    ]
    # Checklist lưu/tải lại đúng THEO KÊNH (hai kênh không lẫn nhau).
    assignments.save_checklist("11", ["tao-video-moi"], "skill-a", base)
    assignments.save_checklist("22", ["len-lich-phat-hanh"], None, base)
    first = assignments.load_checklist("11", base)
    second = assignments.load_checklist("22", base)
    assert first == {"template_ids": ["tao-video-moi"], "skill_slug": "skill-a"}
    assert second == {
        "template_ids": ["len-lich-phat-hanh"],
        "skill_slug": None,
    }
    assert assignments.load_checklist("33", base) is None
    # Lưu rỗng → xoá mục của kênh.
    assignments.save_checklist("11", [], None, base)
    assert assignments.load_checklist("11", base) is None


def test_create_assignments_payload_skill_and_note(tmp_path):
    store, agent, profile, channel = _world(tmp_path)
    base = tmp_path / "data"
    skill = skills_lib.save_skill(
        "Quy trình đăng video", "Luôn tối ưu tiêu đề cho {channel} trước.", base
    )
    templates = [
        t
        for t in assignments.load_templates(base)
        if t["id"]
        in ("tao-video-moi", "toi-uu-tieu-de-mo-ta-tags", "kiem-tra-tinh-trang-kenh")
    ]
    created = assignments.create_assignments(
        store,
        agent=agent,
        profile=profile,
        channel=channel,
        templates=templates,
        skill=skill,
        note="Ưu tiên video tuần này",
    )
    assert len(created) == 3
    by_type = {c["type"]: c for c in created}
    assert set(by_type) == {"create_video", "optimize", "check"}
    # Lệnh chờ Muse gắn đúng agent; lệnh app tự chạy (check) thì không.
    assert by_type["create_video"]["agent_id"] == agent["id"]
    assert by_type["optimize"]["agent_id"] == agent["id"]
    assert by_type["check"]["agent_id"] is None
    for command in created:
        assert command["profile_id"] == profile["id"]
        assert command["channel_id"] == "UCpip123"
        payload = command["payload"]
        meta = payload["assignment"]
        assert meta["source"] == "agent_board"
        assert meta["skill_slug"] == skill.slug
        assert meta["skill_name"] == "Quy trình đăng video"
        assert meta["note"] == "Ưu tiên video tuần này"
        assert payload["batch_total"] == 3
        # Skill + ghi chú + tên kênh đều vào instruction.
        assert "Quy trình đăng video" in command["instruction"]
        assert "Pip Survives" in command["instruction"]
        assert "Ưu tiên video tuần này" in command["instruction"]
    batch_ids = {c["payload"]["batch_id"] for c in created}
    assert len(batch_ids) == 1


# --------------------------------------------------------------------- #
# Hộp thoại Giao việc + khối Skill
# --------------------------------------------------------------------- #
def test_assign_dialog_ticks_skill_and_creates(tmp_path):
    _app()
    store, agent, profile, channel = _world(tmp_path)
    base = tmp_path / "data"
    skills_lib.save_skill("Skill mẫu", "Nội dung skill mẫu.", base)
    dialog = AssignDialog(
        store, agent=agent, profile=profile, channel=channel, base=base
    )
    _tick(
        dialog.editor,
        {"Tạo video mới", "Tối ưu tiêu đề + mô tả + tags", "Kiểm tra tình trạng kênh"},
    )
    index = dialog.editor.skill_combo.findData(
        skills_lib.list_skills(base)[0].slug
    )
    dialog.editor.skill_combo.setCurrentIndex(index)
    dialog.editor.note_edit.setPlainText("Ghi chú kiểm thử")
    assert dialog.assign_button.text() == "Giao 3 việc"
    dialog._on_assign()
    assert len(dialog.created) == 3
    commands = store.list_commands(limit=50)
    assert len(commands) == 3
    assert all(
        (c["payload"] or {})["assignment"]["skill_name"] == "Skill mẫu"
        for c in commands
    )
    dialog.deleteLater()


def test_skill_import_and_paste_in_editor(tmp_path):
    _app()
    store, agent, profile, channel = _world(tmp_path)
    base = tmp_path / "data"
    dialog = AssignDialog(
        store, agent=agent, profile=profile, channel=channel, base=base
    )
    editor = dialog.editor
    # Nhập từ file .md → xuất hiện trong danh sách và ĐƯỢC CHỌN ngay.
    md_file = tmp_path / "skill-ngoai.md"
    md_file.write_text("# Skill Nhập Ngoài\nBước 1: làm đúng quy trình.\n", encoding="utf-8")
    skill = editor.import_skill_from_path(md_file)
    assert skill is not None and skill.name == "Skill Nhập Ngoài"
    assert editor.skill_combo.currentData() == skill.slug
    names = [
        editor.skill_combo.itemText(i)
        for i in range(editor.skill_combo.count())
    ]
    assert any("Skill Nhập Ngoài" in n for n in names)
    # File rỗng → lỗi tại chỗ, không lưu.
    empty = tmp_path / "rong.md"
    empty.write_text("   \n", encoding="utf-8")
    assert editor.import_skill_from_path(empty) is None
    assert "rỗng" in editor.skill_error_label.text()
    # File không tồn tại → lỗi tại chỗ.
    assert editor.import_skill_from_path(tmp_path / "khong-co.md") is None
    assert editor.skill_error_label.text() != ""
    # Dán skill mới → vào thư viện, chọn ngay.
    pasted = editor.add_pasted_skill("Skill Dán Tay", "Thân skill dán.")
    assert pasted is not None
    assert editor.skill_combo.currentData() == pasted.slug
    assert editor.add_pasted_skill("", "x") is None
    assert editor.add_pasted_skill("Tên", "  ") is None
    dialog.deleteLater()


def test_standing_checklist_dialog_save_reload_create(tmp_path):
    _app()
    store, agent, profile, channel = _world(tmp_path)
    base = tmp_path / "data"
    dialog = StandingChecklistDialog(
        store, agent=agent, profile=profile, channel=channel, base=base
    )
    _tick(dialog.editor, {"Tạo video mới", "Lên lịch phát hành"})
    dialog.save_now()
    saved = assignments.load_checklist(str(channel["id"]), base)
    assert saved is not None
    assert set(saved["template_ids"]) == {"tao-video-moi", "len-lich-phat-hanh"}
    dialog.deleteLater()
    # Mở lại → checklist nạp đúng; tạo việc ngay → đủ 2 lệnh.
    again = StandingChecklistDialog(
        store, agent=agent, profile=profile, channel=channel, base=base
    )
    assert set(again.editor.checked_template_ids()) == {
        "tao-video-moi",
        "len-lich-phat-hanh",
    }
    again.create_now()
    assert len(again.created) == 2
    assert {c["type"] for c in again.created} == {"create_video", "upload"}
    again.deleteLater()


# --------------------------------------------------------------------- #
# Bảng Theo Agent
# --------------------------------------------------------------------- #
def test_board_rows_menu_and_pause(tmp_path, monkeypatch):
    _app()
    store, agent, profile, channel = _world(tmp_path)
    base = tmp_path / "data"
    assignments.save_checklist(str(channel["id"]), ["tao-video-moi"], None, base)
    board = AgentBoardWidget(store, base)
    board.set_model(_model(store))
    assert board.channel_keys() == [str(channel["id"])]
    assert board.select_channel(str(channel["id"]))
    # V5.1 (pin đổi theo plan §2.3): bảng dạng THẺ thay cây trần —
    # dữ liệu kênh đọc từ thẻ con, dòng thường trực nằm trên thẻ.
    card = board.channel_card(str(channel["id"]))
    assert card is not None
    data = board.selected_channel_data()
    assert data is not None and str(data["channel"]["id"]) == str(channel["id"])
    assert "Thường trực: 1 mục" in card.standing_label.text()
    menu = board.build_channel_menu(data)
    labels = [a.text() for a in menu.actions() if a.text()]
    assert labels == [
        "📋 Giao việc cho kênh này…",
        "🤖 Việc Muse phải làm cho kênh…",
        "📊 Xem tiến độ kênh",
        "🌐 Mở trình duyệt của kênh",
        "⏸ Tạm dừng kênh này",
    ]
    # Tạm dừng đi qua cờ pause CẤP HỒ SƠ (dispatcher tôn trọng).
    import app.ui.agent_board as board_module

    monkeypatch.setattr(
        board_module.QMessageBox,
        "question",
        staticmethod(lambda *a, **k: board_module.QMessageBox.StandardButton.Yes),
    )
    board._toggle_pause(data)
    assert store.get_profile(profile["id"])["paused"] is True
    data["profile"] = store.get_profile(profile["id"])
    menu2 = board.build_channel_menu(data)
    labels2 = [a.text() for a in menu2.actions() if a.text()]
    assert labels2[-1] == "▶ Bỏ tạm dừng kênh này"
    board.deleteLater()


def test_workpanel_agents_view_default_and_reflects_commands(tmp_path):
    _app()
    store, agent, profile, channel = _world(tmp_path)
    base = store.db_file.parent
    panel = WorkPanel(store, {}, CommandsPanel(store))
    # V6.5: lần đầu → view chính là Kanban (Theo Agent vẫn chọn được).
    assert panel._view_mode == "kanban"
    panel._set_view(VIEW_AGENTS)
    panel.refresh()
    board = panel.agent_board
    assert board.channel_keys() == [str(channel["id"])]
    assert board.queue_command_ids() == []
    # Giao 1 việc qua đường assignments → refresh → hàng đợi của kênh
    # phản ánh lệnh mới (tiến độ từ work model).
    templates = [
        t for t in assignments.load_templates(base) if t["id"] == "tao-video-moi"
    ]
    created = assignments.create_assignments(
        store,
        agent=agent,
        profile=profile,
        channel=channel,
        templates=templates,
    )
    # Đường thật: dispatcher promote → Muse claim → báo tiến độ
    # (tiến độ trên lệnh còn 'queued' bị bỏ qua theo chủ đích V4.2).
    store.promote_command_to_waiting(created[0]["id"])
    store.update_command_progress(
        created[0]["id"], 55, step="Đang dựng video", agent_id=agent["id"]
    )
    panel.refresh()
    assert board.select_channel(str(channel["id"]))
    assert board.queue_command_ids() == [str(created[0]["id"])]
    row_text = board.queue_list.item(0).text()
    assert "55%" in row_text and "Đang dựng video" in row_text
    panel.deleteLater()
