"""V4.6 — Hồi quy lỗi Văn phòng trên máy thật (báo 10:23, 30/10):
di chuột/bấm vào Phòng điều phối hoặc các ô khác → bàn, robot,
bảng tên BIẾN MẤT, chữ trạng thái rỗng hiện dù có agent.

Căn nguyên đã tái hiện trong sandbox: item của cảnh dựng bằng
object Python cục bộ bị PySide XOÁ khỏi scene khi wrapper tạm do
itemAt()/parentItem() (đường hover/click) tạo ra bị thu gom rác —
chỉ hover qua robot Điều phối viên đã mất nguyên nhóm robot (14
item: tổng 94 → 80). Bản sửa: (1) giữ tham chiếu Python mạnh tới
mọi item của cảnh đang hiện; (2) dựng cảnh vào scene MỚI rồi hoán
đổi nguyên tử — populate lỗi thì giữ nguyên cảnh cũ; (3) refresh()
tự lành khi phát hiện cảnh mất item dù vân dữ liệu không đổi.

Các test dưới đây ĐỎ trên code cũ (đã kiểm chứng bằng cách hoàn
nguyên office_view.py) và XANH trên code đã sửa.
"""

import gc

import pytest
from PySide6.QtCore import QPointF, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import (
    QApplication,
    QGraphicsItemGroup,
    QGraphicsTextItem,
)

from app.store import Store
from app.ui.office_view import OfficeView


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _pump(times=6):
    for _ in range(times):
        QApplication.processEvents()


def _make_view(tmp_path):
    store = Store(tmp_path / "office.db")
    profile = store.add_profile("KenhHoatHinh", "23shinryujin@gmail.com")
    a1 = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    a2 = store.create_agent("dabnire34", "dabnire34@gmail.com")
    store.assign_profiles(a1["id"], [profile["id"]])
    store.touch_agent_heartbeat(a1["id"])
    store.touch_agent_heartbeat(a2["id"])
    cmd = store.create_command(
        "create_video", profile_id=profile["id"],
        instruction="Tạo video EP24", status="running",
        agent_id=a1["id"],
    )
    store.update_command_progress(cmd["id"], 60, "Đang dựng")
    view = OfficeView(store, settings={})
    view.resize(1500, 900)
    view.show()
    _pump(8)
    return view


def _texts(view):
    return [
        item.toPlainText()
        for item in view._scene.items()
        if isinstance(item, QGraphicsTextItem)
    ]


def _groups(view):
    return sum(
        1 for item in view._scene.items()
        if isinstance(item, QGraphicsItemGroup)
    )


def _pixel(view, scene_x, scene_y):
    image = view.view.grab().toImage()
    point = view.view.mapFromScene(QPointF(scene_x, scene_y))
    return image.pixelColor(point.x(), point.y()).name()


def test_hover_over_manager_robot_keeps_scene(qapp, tmp_path):
    """Hover (chưa cần click) qua robot Điều phối viên + GC: cảnh
    phải nguyên vẹn — test này bắt đúng cơ chế lỗi gốc."""
    view = _make_view(tmp_path)
    total0, groups0 = len(view._scene.items()), _groups(view)
    assert any("★" in t for t in _texts(view))  # huy hiệu robot quản lý
    point = view.view.mapFromScene(QPointF(120, 120))
    QTest.mouseMove(view.view.viewport(), pos=point)
    gc.collect()
    _pump()
    assert len(view._scene.items()) == total0
    assert _groups(view) == groups0
    assert any("★" in t for t in _texts(view))
    # Điểm ảnh thân robot quản lý khác hẳn điểm ảnh sàn trống.
    assert _pixel(view, 102, 150) != _pixel(view, 530, 560)
    view.close()


def test_clicks_keep_desks_and_no_empty_note(qapp, tmp_path):
    """Click Phòng điều phối → bàn agent → vùng trống (+ GC sau
    mỗi click): bàn/robot/bảng tên còn nguyên, chữ rỗng KHÔNG
    được xuất hiện khi đang có agent."""
    view = _make_view(tmp_path)
    groups0 = _groups(view)
    for scene_x, scene_y in ((120, 120), (148, 380), (530, 560)):
        point = view.view.mapFromScene(QPointF(scene_x, scene_y))
        QTest.mouseClick(view.view.viewport(), Qt.LeftButton, pos=point)
        gc.collect()
        _pump()
        texts = _texts(view)
        assert not any("Chưa có tài khoản" in t for t in texts)
        assert any("KenhChinh" in t for t in texts)
        assert any("dabnire34" in t for t in texts)
        assert _groups(view) == groups0
    # Robot bàn 1 vẫn sơn được (điểm ảnh thân robot != sàn trống).
    assert _pixel(view, 148, 360) != _pixel(view, 530, 560)
    view.close()


def test_failed_rebuild_keeps_previous_scene(qapp, tmp_path):
    """Populate lỗi giữa chừng → cảnh cũ còn nguyên (nguyên tử),
    không lộ cảnh rỗng nửa vời."""
    view = _make_view(tmp_path)
    scene_before = view._scene
    total0 = len(scene_before.items())

    def _boom(index, desk):
        raise RuntimeError("lỗi vẽ giả lập")

    view._draw_desk = _boom
    view._rebuild_scene()  # không được ném lỗi ra ngoài
    assert view._scene is scene_before
    assert len(view._scene.items()) == total0
    assert any("KenhChinh" in t for t in _texts(view))
    view.close()


def test_refresh_heals_scene_after_item_loss(qapp, tmp_path):
    """Mô phỏng cảnh bị mất 1 item (cơ chế lỗi trên máy thật) khi
    dữ liệu KHÔNG đổi: refresh() phải tự dựng lại cho đủ."""
    view = _make_view(tmp_path)
    # Về trạng thái ổn định (đã có agent được chọn + khung chọn)
    # rồi mới lấy mốc số item.
    view._rebuild_scene()
    _pump()
    total0 = len(view._scene.items())
    victim = next(
        item for item in view._scene.items()
        if isinstance(item, QGraphicsTextItem)
        and "PHÒNG ĐIỀU PHỐI" in item.toPlainText()
    )
    view._scene.removeItem(victim)
    assert len(view._scene.items()) == total0 - 1
    view.refresh()
    _pump()
    assert len(view._scene.items()) == total0
    assert any("PHÒNG ĐIỀU PHỐI" in t for t in _texts(view))
    view.close()
