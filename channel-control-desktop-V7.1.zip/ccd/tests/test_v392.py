"""V3.9.2: sửa lỗi chết luồng ĐĂNG NHẬP — nơi gọi truyền ``log=``
trong khi attempt_login chỉ nhận ``say``: mọi lần bấm 🔐 Đăng nhập
cho hồ sơ đều văng "attempt_login() got an unexpected keyword
argument 'log'" ngay trước khi làm việc (nhật ký máy người dùng
28/10 14:49–14:51, lặp 4 lần). Chữ ký nay nhận cả hai tên, và nơi
gọi đã sửa về say= cho tường minh."""

from app import login_helper


class _FakeClient:
    """Client CDP giả tối thiểu: điều hướng không lỗi, trang không
    ở trạng thái đã đăng nhập."""

    def __init__(self):
        self.urls = []

    def navigate(self, url):
        self.urls.append(url)

    def evaluate(self, _script):
        return {}


def test_attempt_login_accepts_log_alias(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    # Bỏ nhịp chờ sẵn sàng của trang (client giả không có trang thật).
    monkeypatch.setattr(login_helper.scanner, "_wait_ready", lambda _c: None)
    profile = {"label": "dabnire34@gmail.com", "slug": "dabnire34-gmail-com",
               "gmail": "dabnire34@gmail.com"}
    # Cách gọi CŨ (log=) — từng giết cả luồng: nay phải chạy bình
    # thường tới kết quả needs_manual (không cookies/mật khẩu đã lưu
    # trong thư mục dữ liệu tạm).
    result = login_helper.attempt_login(_FakeClient(), profile, log=lambda _m: None)
    assert result["status"] == "needs_manual"
    # Cách gọi chuẩn (say=) và gọi vị trí đều chạy.
    result = login_helper.attempt_login(_FakeClient(), profile, say=lambda _m: None)
    assert result["status"] == "needs_manual"
    result = login_helper.attempt_login(_FakeClient(), profile, lambda _m: None)
    assert result["status"] == "needs_manual"
    # Không truyền callback nào cũng không được chết.
    result = login_helper.attempt_login(_FakeClient(), profile)
    assert result["status"] == "needs_manual"
