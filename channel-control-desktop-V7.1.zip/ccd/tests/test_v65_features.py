"""V6.5 — Kanban, Báo cáo, trưởng phòng toàn quyền, Muse điều khiển trình
duyệt qua chat, zoom trang, nạp skill từ thư mục, chat bám đáy."""

from __future__ import annotations

import os
from datetime import datetime, timedelta

import pytest

from app import lead_autopilot, muse_chat_bridge, muse_control, page_zoom, skills_lib, work_board
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


@pytest.fixture(scope="module")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def _world(store):
    agent = store.create_agent("Muse 01", "a@x.com")
    profile = store.add_profile("KenhNhat", "k@x.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    return agent, profile


# ----------------------------------------------------------------- Kanban
def test_kanban_columns_strip_and_detail(store):
    agent, profile = _world(store)
    now = datetime.now().astimezone()
    c1 = store.create_command("create_video", profile_id=profile["id"], instruction="Video ngủ\nchi tiết",
                              agent_id=agent["id"])
    store.update_command_progress(c1["id"], 45, "Viết kịch bản")
    c2 = store.create_command("free", instruction="Trễ", agent_id=agent["id"])
    store.set_command_due(c2["id"], (now - timedelta(minutes=30)).isoformat(timespec="seconds"))
    c3 = store.create_command("free", instruction="Xong", agent_id=agent["id"])
    store.finish_command(c3["id"], "done", result="ok")
    c4 = store.create_command("free", instruction="Chờ", agent_id=agent["id"])
    store.update_command(c4["id"], status="needs_user")
    data = work_board.kanban(store, now)
    cols = {k: [c["id"] for c in v] for k, v in data["columns"].items()}
    assert c1["id"] in cols["running"] or c1["id"] in cols["waiting"]
    assert c3["id"] in cols["done"] and c4["id"] in cols["user"]
    assert data["strip"]["overdue"] >= 1 and data["strip"]["done"] == 1
    card = next(c for v in data["columns"].values() for c in v if c["id"] == c2["id"])
    assert card["overdue"] and card["due"].startswith("Trễ")
    detail = work_board.detail(store, c1["id"], now)
    assert detail["channel"] == "KenhNhat" and detail["muse"] == "Muse 01"
    assert detail["steps"][-1]["label"] == "Viết kịch bản"
    assert work_board.kanban(store, now, search="không có")["strip"]["done"] == 0


def test_report_rows_attention_and_series(store):
    agent, profile = _world(store)
    store.upsert_channel(profile["id"], {"channel_id": "UC1", "name": "老後の心理学", "subs": 1200, "video_count": 30})
    now = datetime.now().astimezone()
    for i, subs in enumerate((1000, 1100, 1200)):
        day = (now - timedelta(days=2 - i)).date().isoformat()
        store._conn.execute(
            "INSERT INTO channel_snapshots (profile_id, channel_id, day, subs, video_count, captured_at)"
            " VALUES (?, 'UC1', ?, ?, ?, ?)", (profile["id"], day, subs, 28 + i, now.isoformat()))
    store._conn.commit()
    data = work_board.report(store, 7, now=now)
    row = data["rows"][0]
    assert row["name"] == "老後の心理学" and row["delta"] == 200 and row["state"] == "Tăng"
    assert row["videos"] == 2 and data["chart"]["lines"][0]["values"][-1] == 1200
    assert data["tiles"][1]["value"] == "1.200"
    assert data["muses"][0]["name"] == "Muse 01"


# ------------------------------------------------------- Trưởng phòng
def test_progress_watch_pings_then_reassigns(store, monkeypatch):
    sent = []
    monkeypatch.setattr(lead_autopilot, "SENDER", lambda agent, body, cid: sent.append((agent["id"], body, cid)))
    a = store.create_agent("A", "a@x.com")
    b = store.create_agent("B", "b@x.com")
    for agent in (a, b):
        store.touch_agent_heartbeat(agent["id"])
    cmd = store.create_command("free", instruction="x", agent_id=a["id"])
    store.update_command(cmd["id"], status="waiting_muse")
    old = (datetime.now().astimezone() - timedelta(minutes=30)).isoformat(timespec="seconds")
    store._conn.execute("UPDATE commands SET updated_at = ? WHERE id = ?", (old, cmd["id"]))
    store._conn.commit()
    now = datetime.now().astimezone()
    settings = {"lead_progress_minutes": 10}
    out = lead_autopilot.progress_watch(store, settings, None, now)
    assert out and out[0]["action"] == "progress_ping"
    assert sent and "TIẾN ĐỘ" in sent[-1][1] and sent[-1][2] == cmd["id"]
    # hỏi đủ số lần mà vẫn im → chuyển người
    for step in range(1, lead_autopilot.PROGRESS_PING_LIMIT + 1):
        later = now + timedelta(minutes=11 * step)
        out = lead_autopilot.progress_watch(store, settings, None, later)
    assert out[-1]["action"] == "reassign"
    assert store.get_command(cmd["id"])["agent_id"] == b["id"]


def test_self_fix_then_escalate_after_limit(store, monkeypatch):
    monkeypatch.setattr(lead_autopilot, "SENDER", None)
    monkeypatch.setattr(lead_autopilot, "_FULL_AUTHORITY", False)  # V6.7: toàn quyền thì thử nhiều vòng hơn
    a = store.create_agent("A", "a@x.com")
    cmd = store.create_command("free", instruction="x", agent_id=a["id"])
    store.update_command(cmd["id"], status="needs_user")
    issue = {"key": "k", "kind": "needs_user", "title": "Cần đăng nhập", "detail": "Lý do: cần đăng nhập Studio",
             "command_id": cmd["id"], "agent_id": a["id"]}
    for _ in range(lead_autopilot.SELF_FIX_LIMIT):
        store.update_command(cmd["id"], status="needs_user")
        record = lead_autopilot._self_fix(store, None, issue, store.get_command(cmd["id"]), a["id"], "đăng nhập")
        assert record["action"] == "self_fix"
    record = lead_autopilot._self_fix(store, None, issue, store.get_command(cmd["id"]), a["id"], "đăng nhập")
    assert record["outcome"] == "escalated"  # không còn Muse khác nhận thay


def test_progress_parse_and_classify():
    assert muse_chat_bridge.parse_progress("ok\nTIẾN ĐỘ: 40% — xong kịch bản — dựng") == (40, "xong kịch bản — dựng")
    assert muse_chat_bridge.classify_reply("TIẾN ĐỘ: 40% — hoàn thành kịch bản") == "running"
    assert muse_chat_bridge.classify_reply("KẾT QUẢ: đã đăng") == "done"
    assert "```ccd" in muse_chat_bridge.task_text({"id": "c", "type": "free", "instruction": "x", "payload": {}})


# -------------------------------------------- Muse điều khiển trình duyệt
def test_parse_actions_and_resolve_profile(store):
    agent, profile = _world(store)
    text = 'Mình mở Studio:\n```ccd\n{"action":"open","profile":"kenhnhat"}\n{"action":"goto","url":"https://studio.youtube.com"}\n{"action":"click","text":"Tạo"}\n{"action":"rm -rf"}\nkhông phải json\n```'
    actions = muse_control.parse_actions(text)
    assert [a["action"] for a in actions] == ["open", "goto", "click"]
    assert muse_control.resolve_profile(store, muse_control.wanted_profile(actions), None, agent)["id"] == profile["id"]
    assert muse_control.resolve_profile(store, None, None, store.get_agent(agent["id"]))["id"] == profile["id"]
    assert muse_control.parse_actions("không có khối") == []


class _FakePage:
    def __init__(self):
        self.calls = []

    def navigate_and_wait(self, url, timeout=30):
        self.calls.append(("goto", url))

    def click_element(self, selector=None, text=None):
        if text == "Không có":
            raise RuntimeError("Không tìm thấy phần tử")
        self.calls.append(("click", text))
        return {"text": text}

    def fill_element(self, selector, text):
        self.calls.append(("type", selector, text))

    def press_key(self, key):
        self.calls.append(("key", key))

    def evaluate(self, expr):
        return {"url": "https://studio.youtube.com", "title": "Studio", "text": "Bảng điều khiển kênh",
                "dialogs": [], "elements": [{"i": 0, "tag": "button", "text": "Tạo", "in_view": True}]}


def test_run_actions_stops_at_error_and_formats():
    page = _FakePage()
    actions = muse_control.parse_actions(
        '```ccd\n{"action":"goto","url":"https://studio.youtube.com"}\n{"action":"type","selector":"#t","text":"abc"}\n'
        '{"action":"click","text":"Không có"}\n{"action":"key","key":"Enter"}\n```')
    lines, snap = muse_control.run_actions(page, actions, sleep=lambda s: None)
    assert ("goto", "https://studio.youtube.com") in page.calls and ("key", "Enter") not in page.calls
    assert "✕" in lines[2]
    text = muse_control.format_result("KenhNhat", lines, snap)
    assert "Studio" in text and "[0] button «Tạo»" in text


def test_main_window_runs_control_round(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent, profile = _world(st)
    win = MainWindow(st, ChromeManager(), settings)
    sent = []
    opened = []
    monkeypatch.setattr(win, "_open_for_muse", lambda p: opened.append(p["id"]))
    monkeypatch.setattr(win, "_send_to_muse", lambda a, text, cid=None: sent.append(text))
    monkeypatch.setattr(muse_control, "connect", lambda port, **k: _ClosingPage())
    try:
        ran = win._maybe_run_muse_control(st.get_agent(agent["id"]),
                                         '```ccd\n{"action":"goto","url":"https://studio.youtube.com"}\n```', None)
        assert ran and opened == [profile["id"]]
        from PySide6.QtCore import QCoreApplication
        import time as _t

        deadline = _t.time() + 5
        while not sent and _t.time() < deadline:
            QCoreApplication.processEvents()
            _t.sleep(0.02)
        assert sent and sent[0].startswith("[CCD · KenhNhat]")
    finally:
        win.close()


class _ClosingPage(_FakePage):
    def close(self):
        pass


# ------------------------------------------------------------- Zoom trang
def test_page_zoom_scope_and_keeper():
    assert page_zoom.scope_ids("all", None, [1, 2, 3], {}) == [1, 2, 3]
    assert page_zoom.scope_ids("row", 2, [1, 2, 3, 4], {1: (0, 0), 2: (0, 1), 3: (1, 0), 4: (0, 2)}) == [1, 2, 4]
    assert page_zoom.scope_ids("page", 3, [1, 2, 3], {}) == [3]
    settings = {}
    assert page_zoom.set_pct(settings, ["a", "b"], 10) == 30
    assert page_zoom.get_pct(settings, "a") == 30 and page_zoom.get_pct(settings, "zz") is None

    class Client:
        def __init__(self):
            self.zoom = None

        def evaluate(self, expr):
            want = "75" if "75" in expr else "?"
            if self.zoom == want:
                return "same"
            self.zoom = want
            return "set"

        def close(self):
            pass

    pages = [{"type": "page", "url": "https://a", "webSocketDebuggerUrl": "ws://1"},
             {"type": "page", "url": "chrome://newtab", "webSocketDebuggerUrl": "ws://2"}]
    keeper = page_zoom.ZoomKeeper(interval=999, client_factory=lambda ws: Client(), lister=lambda port: pages)
    keeper.set_targets({1: (9222, 75)})
    assert keeper.tick() == 1      # áp lần đầu
    assert keeper.tick() == 0      # đã đúng → không đặt lại
    pages.append({"type": "page", "url": "https://b", "webSocketDebuggerUrl": "ws://3"})
    assert keeper.tick() == 1      # tab mới mở / trang tải lại → áp lại
    keeper.stop()


# --------------------------------------------------- Skill từ thư mục
def test_import_skill_folder(tmp_path):
    src = tmp_path / "src"
    (src / "video-skill" / "references").mkdir(parents=True)
    (src / "video-skill" / "SKILL.md").write_text(
        "---\nname: Làm video ngủ\ndescription: Quy trình 7 bước\n---\n# Bước\n1. Viết kịch bản\n", encoding="utf-8")
    (src / "video-skill" / "references" / "style.md").write_text("Giọng ấm", encoding="utf-8")
    (src / "le.md").write_text("# Tối ưu tiêu đề\nGợi ý tiêu đề", encoding="utf-8")
    saved = skills_lib.import_folder(src, tmp_path / "data")
    names = sorted(s.name for s in saved)
    assert names == ["Làm video ngủ", "Tối ưu tiêu đề"]
    body = next(s for s in saved if s.name == "Làm video ngủ").body
    assert "Quy trình 7 bước" in body and "Giọng ấm" in body
    assert len(skills_lib.list_skills(tmp_path / "data")) == 2


# ----------------------------------------------------------- Giao diện
def test_nav_order_supervision_next_to_reports():
    from app.ui.main_window import NAV_ITEMS, NAV_ORDER, SEC_REPORTS, SEC_SUPERVISION

    assert NAV_ORDER.index(SEC_SUPERVISION) == NAV_ORDER.index(SEC_REPORTS) + 1
    assert sorted(NAV_ORDER) == list(range(len(NAV_ITEMS)))


def test_chat_sticks_to_bottom(qapp, store):
    from app.ui.agent_chat import AgentChatWidget

    agent = store.create_agent("A", "a@x.com")
    for i in range(40):
        store.add_message(agent["id"], "agent" if i % 2 else "user", f"tin số {i} " * 8)
    chat = AgentChatWidget(store)
    chat.resize(420, 500)
    chat.set_agent(store.get_agent(agent["id"])) if hasattr(chat, "set_agent") else None
    chat.show()
    from PySide6.QtCore import QCoreApplication

    for _ in range(5):
        QCoreApplication.processEvents()
    bar = chat.scroll.verticalScrollBar()
    assert bar.maximum() > 0 and bar.value() == bar.maximum()
    middle = bar.maximum() // 3
    bar.setValue(middle)  # người dùng cuộn lên đọc lịch sử → thôi bám đáy
    assert chat._stick_bottom is False
    store.add_message(agent["id"], "agent", "tin mới " * 30)
    chat._fingerprint = None
    chat.refresh()
    for _ in range(3):
        QCoreApplication.processEvents()
    assert bar.value() == middle
    assert chat._jump_btn.isVisibleTo(chat)  # nút "↓ Tin mới nhất"
    chat.stick_to_bottom()
    store.add_message(agent["id"], "agent", "tin mới nữa " * 30)
    chat._fingerprint = None
    chat.refresh()
    for _ in range(3):
        QCoreApplication.processEvents()
    assert bar.value() == bar.maximum()
    chat.close()


def test_settings_matrix_combos_tall_enough(qapp, store, tmp_path):
    from app.ui.settings_panel import SettingsPanel

    for i in range(7):
        store.create_agent(f"M{i}", f"m{i}@x.com")
    panel = SettingsPanel(store, {}, apply_settings=lambda changed: "", agent_status=lambda: "")
    panel._rebuild_matrix_editor()
    assert panel._matrix_combos and all(c.minimumHeight() >= 36 for c in panel._matrix_combos.values())


def test_kanban_and_dashboard_widgets_render(qapp, store):
    from app.ui.kanban_view import KanbanView
    from app.ui.report_dashboard import ReportDashboard

    agent, profile = _world(store)
    cmd = store.create_command("upload", profile_id=profile["id"], instruction="Đăng video", agent_id=agent["id"])
    view = KanbanView(store, {})
    view.resize(1400, 800)
    view.refresh()
    assert view.tiles["waiting"].value.text() == "1"
    view.select(cmd["id"])
    assert "Đăng video" in view.d_title.text()
    view._extend()
    assert store.get_command(cmd["id"])["due_at"]
    dash = ReportDashboard(store, {})
    dash.resize(1400, 900)
    dash.refresh()
    assert dash.tiles[0][1].text() == "0"
    image = dash.grab()
    assert not image.isNull()


# ------------------------------------------- V6.5.1 nhúng Chrome thu nhỏ
class _FakeUser32:
    def __init__(self, iconic=True):
        self.iconic = iconic
        self.calls = []

    def IsIconic(self, hwnd):
        return self.iconic

    def IsZoomed(self, hwnd):
        return False

    def ShowWindow(self, hwnd, cmd):
        self.calls.append(("show", cmd))
        if cmd == 9:
            self.iconic = False
        return True

    def SetWindowPos(self, hwnd, after, x, y, w, h, flags):
        self.calls.append(("pos", w, h, self.iconic))
        return True

    def GetWindowRect(self, hwnd, rect):
        return True

    def GetParent(self, hwnd):
        return 0

    def GetWindowLongW(self, hwnd, index):
        return 0

    def SetWindowLongW(self, hwnd, index, value):
        return 0

    def SetParent(self, hwnd, parent):
        self.calls.append(("parent", parent))
        return 0

    def IsWindow(self, hwnd):
        return True


def test_dock_restores_minimized_chrome_before_sizing(monkeypatch):
    from app import docking

    fake = _FakeUser32(iconic=True)
    monkeypatch.setattr(docking, "_user32", lambda: fake)
    monkeypatch.setattr(docking, "is_window_alive", lambda hwnd: True)
    dock = docking.BrowserDock()
    assert dock.attach(111, 222, 600, 800)
    # khôi phục (SW_RESTORE=9) xảy ra TRƯỚC lần đặt kích thước đầu tiên
    restore_at = fake.calls.index(("show", 9))
    first_pos = next(i for i, c in enumerate(fake.calls) if c[0] == "pos")
    assert restore_at < first_pos
    assert all(not c[3] for c in fake.calls if c[0] == "pos")  # không còn iconic khi giãn
    # bị thu nhỏ lại sau khi đã nhúng → watchdog tự khôi phục + giãn đầy
    fake.iconic = True
    fake.calls.clear()
    assert docking.DockWatchdog(dock, lambda *a: None).tick() == "ok" if docking.IS_WINDOWS else True
    if not docking.IS_WINDOWS:
        assert dock.sync_size(600, 800)
        assert ("show", 9) in fake.calls and ("pos", 600, 800, False) in fake.calls


def test_full_authority_tries_longer_before_escalating(store, monkeypatch):
    monkeypatch.setattr(lead_autopilot, "SENDER", None)
    monkeypatch.setattr(lead_autopilot, "_FULL_AUTHORITY", True)
    a = store.create_agent("A", "a@x.com")
    cmd = store.create_command("free", instruction="x", agent_id=a["id"])
    issue = {"key": "k2", "kind": "needs_user", "title": "Kẹt", "detail": "x", "command_id": cmd["id"], "agent_id": a["id"]}
    actions = []
    for _ in range(lead_autopilot.SELF_FIX_LIMIT * 3 + 1):
        store.update_command(cmd["id"], status="needs_user")
        actions.append(lead_autopilot._self_fix(store, None, issue, store.get_command(cmd["id"]), a["id"], "x")["action"])
    assert actions[:-1] == ["self_fix"] * (lead_autopilot.SELF_FIX_LIMIT * 3) and actions[-1] == "escalate"
