"""V4.0 (H5) — Kiểm chứng payload khi nhận lệnh + chống trùng idempotency.

Lệnh sai cấu hình phải bị chặn NGAY ở cửa nhận (API trả 400 kèm danh
sách lỗi; schema dùng chung cho UI) thay vì chạy nửa chừng mới vỡ.
Mọi đường tạo lệnh tự động gắn khoá idempotency: tick trùng/tạo trùng
cùng khoá → trả lệnh cũ kèm deduplicated=True, không sinh lệnh đôi.
"""

import json

import pytest

from app import config
from app.agent_server import AgentServer
from app.automation import AutomationEngine
from app.command_schema import validate_command
from app.store import Store
from test_agent_server import FakeManager, stub_scan


def test_upload_requires_file_or_video_id():
    errors = validate_command("upload", channel_id="UC1", payload={})
    assert any("file" in e and "video_id" in e for e in errors)
    assert validate_command("upload", channel_id="UC1", payload={"file": "a.mp4"}) == []
    assert validate_command("upload", channel_id="UC1", payload={"video_id": "v9"}) == []


def test_upload_channel_must_belong_to_profile():
    errors = validate_command(
        "upload",
        channel_id="UC-khack",
        payload={"file": "a.mp4"},
        channel_ids=["UC1", "UC2"],
    )
    assert any("không thuộc hồ sơ" in e for e in errors)


def test_create_video_and_free_require_instruction():
    assert any("instruction" in e for e in validate_command("create_video"))
    assert validate_command("create_video", instruction="làm video mưa") == []
    assert any("instruction" in e for e in validate_command("free", instruction=" "))


def test_create_channel_gmail_validated_when_present():
    errors = validate_command(
        "create_channel", payload={"gmail": "khong-phai-email"}
    )
    assert any("định dạng email" in e for e in errors)
    assert validate_command("create_channel", payload={"gmail": "ok@gmail.com"}) == []
    assert any(
        "gmail" in e for e in validate_command("create_channel", payload={})
    )


def test_api_enqueue_rejects_invalid_upload(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("Kenh A", "a@gmail.com")
    seed.upsert_channel(
        profile["id"], {"channel_id": "UCapi00000000000000000", "title": "Kênh API"}
    )
    seed.close()
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    body = json.dumps(
        {
            "type": "upload",
            "profile": profile["slug"],
            "channel_id": "UCapi00000000000000000",
            "payload": {},
        }
    ).encode("utf-8")
    status, payload = server.dispatch(
        "POST", "/api/commands", {"X-Agent-Token": server.token}, body
    )
    assert status == 400
    assert payload["errors"]
    assert any("video_id" in e for e in payload["errors"])


def test_store_idempotency_duplicate_returns_existing(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    kwargs = dict(
        source="api",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        idempotency_key="khoa-1",
    )
    first = store.create_command("optimize", **kwargs)
    second = store.create_command("optimize", **kwargs)
    assert second["id"] == first["id"]
    assert second.get("deduplicated") is True
    assert "deduplicated" not in first
    assert len(store.list_commands(profile_id=profile["id"])) == 1
    store.close()


def test_automation_double_fire_same_period_creates_one_command(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    rule = store.add_rule(
        "create_video",
        profile_id=profile["id"],
        schedule_kind="daily",
        daily_time="06:00",
        enabled=True,
    )
    engine = AutomationEngine(store)
    from datetime import datetime

    now = datetime(2026, 10, 29, 6, 0).astimezone()
    engine._fire(rule, now)
    engine._fire(rule, now)  # tick trùng trong cùng kỳ — không được nhân đôi
    commands = [
        c
        for c in store.list_commands(profile_id=profile["id"])
        if c["type"] == "create_video"
    ]
    assert len(commands) == 1
    store.close()
