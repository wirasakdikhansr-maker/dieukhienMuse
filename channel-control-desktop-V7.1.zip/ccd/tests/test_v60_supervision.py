"""Kiểm thử V6.0 — GIÁM SÁT CHÉO (UI_V60_PLAN).

Bao phủ: migration 8→9 giữ dữ liệu; ma trận vòng chéo + chặn tự
chấm ở tầng dữ liệu; sinh việc kiểm tra theo sự kiện/tỉ lệ mẫu;
gói bằng chứng + luật thiếu bằng chứng; checklist từ skill /
bộ câu hỏi chuẩn; watchdog (đồng hồ giả); 3 kết luận + trần vòng
làm lại → leo thang; API verdict/scorecard bằng token TỪNG agent;
giao diện tab Giám sát + hộp thoại lịch sử + tab cài đặt.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timedelta

import pytest

from app import config, supervision
from app.agent_server import AgentServer
from app.store import Store


# --------------------------------------------------------------------------- #
# Fixture kho dùng chung
# --------------------------------------------------------------------------- #
@pytest.fixture()
def world(tmp_path, monkeypatch):
    # CCD_DATA_DIR trỏ thư mục tạm: supervision đọc settings từ
    # config.load_settings() — không để settings thật của repo
    # (data/settings.json) làm lệch kết quả test.
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setenv("CCD_DATA_DIR", str(data_dir))
    store = Store(tmp_path / "ccd.sqlite3")
    profile = store.add_profile("Kênh A", "a@gmail.com")
    a1 = store.create_agent("Muse Một", "m1@example.ai")
    a2 = store.create_agent("Muse Hai", "m2@example.ai")
    a3 = store.create_agent("Muse Ba", "m3@example.ai")
    store.assign_profiles(a1["id"], [profile["id"]])
    yield {
        "store": store, "profile": profile,
        "a1": a1, "a2": a2, "a3": a3,
    }
    store.close()


def _save_supervision_settings(**overrides):
    settings = dict(config.DEFAULT_SETTINGS)
    settings.update(overrides)
    config.save_settings(settings)


def _finish(store, agent_id, *, status="done", result="Đã xong — https://youtu.be/abc123xyz",
            profile_id=None, instruction="việc mẫu", payload=None,
            cmd_type="free"):
    command = store.create_command(
        cmd_type, source="ui", profile_id=profile_id,
        instruction=instruction, payload=payload or {}, agent_id=agent_id,
    )
    store.promote_command_to_waiting(command["id"])
    store.claim_claude_command(command["id"], agent_id)
    return store.finish_command(command["id"], status, result=result)


# --------------------------------------------------------------------------- #
# Migration
# --------------------------------------------------------------------------- #
def test_migration_v8_to_v9_preserves_data(tmp_path):
    db = tmp_path / "old.sqlite3"
    store = Store(db)
    profile = store.add_profile("Kênh Cũ", "cu@gmail.com")
    agent = store.create_agent("Muse Cũ", "cu@example.ai")
    command = store.create_command(
        "free", source="ui", profile_id=profile["id"], instruction="việc cũ"
    )
    store.close()
    # Giả lập DB ở schema 8: gỡ bảng reviews + 2 cột mới rồi hạ version.
    raw = sqlite3.connect(db)
    raw.execute("DROP TABLE reviews")
    raw.execute("ALTER TABLE commands DROP COLUMN review_round")
    raw.execute("ALTER TABLE commands DROP COLUMN last_verdict")
    raw.execute("PRAGMA user_version = 8")
    raw.commit()
    raw.close()

    migrated = Store(db)
    try:
        assert migrated.schema_version == 12  # V7.0 (v12 = platform): v11 = lịch sử bước
        assert migrated.get_command(command["id"])["instruction"] == "việc cũ"
        assert migrated.get_command(command["id"])["review_round"] == 0
        assert migrated.get_agent(agent["id"])["email"] == "cu@example.ai"
        review = migrated.create_review(
            command["id"], agent["id"], agent["id"] + 1, "done"
        )
        assert review["status"] == "open"
        migrated._migrate()  # chạy lại vô hại
        assert migrated.schema_version == 12  # V7.0 (v12 = platform): v11 = lịch sử bước
    finally:
        migrated.close()


# --------------------------------------------------------------------------- #
# Ma trận giám sát
# --------------------------------------------------------------------------- #
def test_default_ring_uses_real_agent_ids(world):
    ids = [world["a1"]["id"], world["a2"]["id"], world["a3"]["id"]]
    ring = supervision.default_ring(ids)
    assert ring == {ids[0]: ids[1], ids[1]: ids[2], ids[2]: ids[0]}
    assert supervision.default_ring([ids[0]]) == {}
    assert supervision.default_ring([]) == {}


def test_self_review_blocked_at_data_layer(world):
    store = world["store"]
    a1, a2 = world["a1"]["id"], world["a2"]["id"]
    # Ghi đè tự chấm mình → bị bỏ, quay về vòng chéo.
    settings = {"supervision_matrix": {str(a1): a1}}
    assert supervision.supervisor_for(store, a1, settings) == a2
    # Ghi đè trỏ agent không tồn tại → bị bỏ.
    settings = {"supervision_matrix": {str(a1): 9999}}
    assert supervision.supervisor_for(store, a1, settings) == a2
    # Ghi đè hợp lệ được tôn trọng.
    settings = {"supervision_matrix": {str(a1): world["a3"]["id"]}}
    assert supervision.supervisor_for(store, a1, settings) == world["a3"]["id"]


# --------------------------------------------------------------------------- #
# Sinh việc kiểm tra
# --------------------------------------------------------------------------- #
def test_failed_always_reviewed_and_done_sampled(world):
    store = world["store"]
    a1 = world["a1"]["id"]
    # Mẫu 0%: lệnh THẤT BẠI vẫn kiểm tra 100%, lệnh xong thì không.
    _save_supervision_settings(supervision_sample_percent=0)
    failed = _finish(store, a1, status="failed", result="lỗi nặng")
    review = store.open_review_for_command(failed["id"])
    assert review is not None and review["trigger_kind"] == "failed"
    assert review["supervisor_agent_id"] == world["a2"]["id"]
    assert review["worker_agent_id"] == a1
    done = _finish(store, a1, status="done")
    assert store.open_review_for_command(done["id"]) is None
    # Mẫu 100%: lệnh xong được kiểm tra.
    _save_supervision_settings(supervision_sample_percent=100)
    done2 = _finish(store, a1, status="done")
    assert store.open_review_for_command(done2["id"]) is not None
    # Tắt công tắc tổng: thất bại cũng không sinh vòng.
    _save_supervision_settings(supervision_enabled=False)
    failed2 = _finish(store, a1, status="failed", result="lỗi nữa")
    assert store.open_review_for_command(failed2["id"]) is None


def test_sampling_is_deterministic(world):
    for percent in (0, 25, 50, 75, 100):
        outcomes = {
            supervision._sampled_in(f"cmd-{i}", percent) for i in range(50)
        }
        if percent == 0:
            assert outcomes == {False}
        elif percent == 100:
            assert outcomes == {True}
        else:
            assert len(outcomes) == 2  # cả hai phía đều xuất hiện
    # cùng id → cùng kết quả mọi lần gọi
    assert supervision._sampled_in("abc", 50) == supervision._sampled_in("abc", 50)


def test_no_review_for_review_commands_or_single_agent(tmp_path):
    store = Store(tmp_path / "one.sqlite3")
    profile = store.add_profile("Kênh", "k@gmail.com")
    only = store.create_agent("Muse Đơn", "don@example.ai")
    store.assign_profiles(only["id"], [profile["id"]])
    done = _finish(store, only["id"], profile_id=profile["id"])
    assert store.open_review_for_command(done["id"]) is None  # không ai chấm
    store.close()

    # Lệnh loại 'review' chốt xong KHÔNG sinh vòng mới (chống đệ quy).
    store = Store(tmp_path / "two.sqlite3")
    p = store.add_profile("Kênh 2", "k2@gmail.com")
    w1 = store.create_agent("W1", "w1@example.ai")
    w2 = store.create_agent("W2", "w2@example.ai")
    store.assign_profiles(w1["id"], [p["id"]])
    target = _finish(store, w1["id"], profile_id=p["id"])
    review = store.open_review_for_command(target["id"])
    review_command = store.get_command(review["review_command_id"])
    store.promote_command_to_waiting(review_command["id"])
    store.claim_claude_command(review_command["id"], w2["id"])
    store.finish_command(review_command["id"], "done", result="đã chấm xong việc kiểm tra này rồi")
    assert store.open_review_for_command(review_command["id"]) is None
    store.close()


def test_review_command_carries_evidence_and_checklist(world):
    store = world["store"]
    done = _finish(
        store, world["a1"]["id"], profile_id=world["profile"]["id"],
        result="Đã đăng video, link https://youtu.be/xyz987abc",
    )
    review = store.open_review_for_command(done["id"])
    review_command = store.get_command(review["review_command_id"])
    payload = review_command["payload"]
    assert payload["target_command_id"] == done["id"]
    assert payload["evidence"]["target"]["instruction"] == "việc mẫu"
    assert "youtu.be" in payload["evidence"]["target"]["result"]
    assert payload["checklist"], "checklist không được rỗng"
    # không có skill → bộ câu hỏi chuẩn của plan
    assert any("bằng chứng" in item["item"] for item in payload["checklist"])
    # việc kiểm tra được promote dù hồ sơ bận (dispatcher miễn bận)
    from app.dispatcher import Dispatcher

    busy = store.create_command(
        "free", source="ui", profile_id=world["profile"]["id"],
        instruction="việc đang chạy",
    )
    store.promote_command_to_waiting(busy["id"])
    store.claim_claude_command(busy["id"], world["a1"]["id"])
    promoted = Dispatcher(store).tick()
    assert any(c["id"] == review_command["id"] for c in promoted)


def test_missing_evidence_rule(world):
    assert supervision.result_has_evidence({"result": "", "result_data": None}) is False
    assert supervision.result_has_evidence({"result": "xong", "result_data": None}) is False
    assert supervision.result_has_evidence(
        {"result": "Đã xong, link kiểm chứng ở đây", "result_data": None}
    ) is True
    assert supervision.result_has_evidence(
        {"result": "", "result_data": {"video_id": "abc"}}
    ) is True


def test_checklist_extraction_from_text():
    text = (
        "# Skill mẫu\n\n## Kiểm tra chất lượng (QC)\n"
        "- [ ] Có thumbnail đúng chuẩn\n"
        "- Độ dài video đạt yêu cầu\n\n"
        "## Phần khác\n- mục này không vào checklist QC\n"
        "- [x] Đã gắn thẻ đúng kênh\n"
    )
    items = supervision.extract_checklist_from_text(text)
    assert "Có thumbnail đúng chuẩn" in items
    assert "Độ dài video đạt yêu cầu" in items
    assert "Đã gắn thẻ đúng kênh" in items
    assert not any("không vào" in item for item in items)


def test_checklist_from_attached_skill(world, tmp_path, monkeypatch):
    from app import skills_lib

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path / "data"))
    skill = skills_lib.save_skill(
        "Skill Chấm Thử",
        "## QC nghiệm thu\n- [ ] Mục chấm một\n- [ ] Mục chấm hai\n",
    )
    store = world["store"]
    done = _finish(
        store, world["a1"]["id"], profile_id=world["profile"]["id"],
        payload={"assignment": {"skill_slug": skill.slug}},
    )
    review = store.open_review_for_command(done["id"])
    review_command = store.get_command(review["review_command_id"])
    texts = [item["item"] for item in review_command["payload"]["checklist"]]
    assert texts == ["Mục chấm một", "Mục chấm hai"]


# --------------------------------------------------------------------------- #
# Watchdog
# --------------------------------------------------------------------------- #
def _age_command(store, command_id, *, updated_minutes=0, lease_past=False):
    now = datetime.now().astimezone()
    updates = {}
    if updated_minutes:
        updates["updated_at"] = (now - timedelta(minutes=updated_minutes)).isoformat(timespec="seconds")
    if lease_past:
        updates["lease_expires_at"] = (now - timedelta(minutes=1)).isoformat(timespec="seconds")
    if updates:
        assignments = ", ".join(f"{key} = ?" for key in updates)
        store._conn.execute(
            f"UPDATE commands SET {assignments} WHERE id = ?",
            (*updates.values(), command_id),
        )
        store._conn.commit()


def _running(store, agent_id, profile_id):
    command = store.create_command(
        "free", source="ui", profile_id=profile_id,
        instruction="việc chạy dài", agent_id=agent_id,
    )
    store.promote_command_to_waiting(command["id"])
    store.claim_claude_command(command["id"], agent_id)
    return store.get_command(command["id"])


def test_watchdog_flags_stall_lease_and_heartbeat(world):
    store = world["store"]
    a1, profile = world["a1"]["id"], world["profile"]["id"]
    now = datetime.now().astimezone()

    stalled = _running(store, a1, profile)
    _age_command(store, stalled["id"], updated_minutes=30)
    created = supervision.watchdog_scan(store, now=now, force=True)
    assert [r["command_id"] for r in created] == [stalled["id"]]
    review = store.open_review_for_command(stalled["id"])
    assert review["trigger_kind"] == "stuck"
    # Quét lại: không sinh trùng (vòng đang mở giữ vai trò khử trùng).
    assert supervision.watchdog_scan(store, now=now, force=True) == []

    leased = _running(store, a1, profile)
    _age_command(store, leased["id"], lease_past=True)
    created = supervision.watchdog_scan(store, now=now, force=True)
    assert [r["command_id"] for r in created] == [leased["id"]]

    # Mất heartbeat: agent giữ lệnh nhưng last_seen quá cũ.
    held = _running(store, a1, profile)
    old_seen = (now - timedelta(minutes=40)).isoformat(timespec="seconds")
    store._conn.execute(
        "UPDATE agents SET last_seen_at = ? WHERE id = ?", (old_seen, a1)
    )
    store._conn.commit()
    created = supervision.watchdog_scan(store, now=now, force=True)
    assert [r["command_id"] for r in created] == [held["id"]]

    # Lệnh vừa chạy, heartbeat mới → không bị bắt.
    fresh = _running(store, world["a2"]["id"], profile)
    assert supervision.watchdog_scan(store, now=now, force=True) == []
    assert fresh["id"]


def test_watchdog_respects_off_switch_and_review_type(world):
    store = world["store"]
    a1, profile = world["a1"]["id"], world["profile"]["id"]
    stalled = _running(store, a1, profile)
    _age_command(store, stalled["id"], updated_minutes=60)
    now = datetime.now().astimezone()
    assert supervision.watchdog_scan(
        store, settings={"supervision_enabled": False}, now=now, force=True
    ) == []
    # Lệnh 'review' đang chạy treo KHÔNG bị watchdog bắt (chống đệ quy).
    review_command = store.create_command(
        "review", source="supervision", profile_id=profile, instruction="chấm",
        payload={}, agent_id=world["a2"]["id"],
    )
    store.promote_command_to_waiting(review_command["id"])
    store.claim_claude_command(review_command["id"], world["a2"]["id"])
    _age_command(store, review_command["id"], updated_minutes=60)
    created = supervision.watchdog_scan(store, now=now, force=True)
    assert [r["command_id"] for r in created] == [stalled["id"]]


# --------------------------------------------------------------------------- #
# Kết luận + vòng làm lại
# --------------------------------------------------------------------------- #
def test_verdict_pass_closes_loop(world):
    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    review = store.open_review_for_command(done["id"])
    outcome = supervision.apply_verdict(
        store, review["review_command_id"], "pass",
        notes="Đạt", checklist=[{"item": "x", "status": "pass", "note": ""}],
    )
    assert outcome["outcome"] == "passed"
    target = store.get_command(done["id"])
    assert target["status"] == "done" and target["last_verdict"] == "pass"
    closed = store.get_review(review["id"])
    assert closed["status"] == "passed"
    assert closed["checklist"][0]["status"] == "pass"
    review_command = store.get_command(review["review_command_id"])
    assert review_command["status"] == "done"
    # Chấm lần hai trên vòng đã đóng → lỗi rõ ràng.
    with pytest.raises(ValueError):
        supervision.apply_verdict(store, review["review_command_id"], "pass")


def test_verdict_rework_requeues_with_feedback_and_notifies(world):
    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"],
                   result="xong")  # kết quả cụt = thiếu bằng chứng
    review = store.open_review_for_command(done["id"])
    outcome = supervision.apply_verdict(
        store, review["review_command_id"], "rework",
        notes="Thiếu link video",
        checklist=[{"item": "bằng chứng", "status": "fail", "note": "không có link"}],
    )
    assert outcome["outcome"] == "rework"
    target = store.get_command(done["id"])
    assert target["status"] == "queued"
    assert target["review_round"] == 1
    assert target["last_verdict"] == "rework"
    feedback = target["payload"]["review_feedback"]
    assert feedback["notes"] == "Thiếu link video"
    assert feedback["missing_evidence"] is True
    assert feedback["failed_items"][0]["item"] == "bằng chứng"
    # Tin chat tự động tới CẢ người làm lẫn giám sát viên.
    for agent in (world["a1"], world["a2"]):
        bodies = [m["body"] for m in store.list_messages(agent["id"])]
        assert any("CHƯA ĐẠT" in body for body in bodies)


def test_rework_cap_escalates_to_needs_user(world):
    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    settings = {"supervision_max_rounds": 1}
    review = store.open_review_for_command(done["id"])
    supervision.apply_verdict(
        store, review["review_command_id"], "rework", notes="lần 1",
        settings=settings,
    )
    target = store.get_command(done["id"])
    assert target["review_round"] == 1
    # Làm lại xong → vòng kiểm tra mới (vòng 1).
    store.promote_command_to_waiting(done["id"])
    store.claim_claude_command(done["id"], world["a1"]["id"])
    store.finish_command(done["id"], "done", result="Đã sửa, link https://youtu.be/fixed999")
    review2 = store.open_review_for_command(done["id"])
    assert review2 is not None and review2["round"] == 1
    outcome = supervision.apply_verdict(
        store, review2["review_command_id"], "rework", notes="vẫn chưa đạt",
        settings=settings,
    )
    assert outcome["outcome"] == "escalated"  # hết trần → leo thang
    target = store.get_command(done["id"])
    assert target["status"] == "needs_user"
    assert target["last_verdict"] == "escalate"


def test_verdict_escalate_and_owner_overrides(world):
    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    review = store.open_review_for_command(done["id"])
    outcome = supervision.apply_verdict(
        store, review["review_command_id"], "escalate", notes="khó, chủ kênh quyết"
    )
    assert outcome["outcome"] == "escalated"
    assert store.get_command(done["id"])["status"] == "needs_user"

    done2 = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    review2 = store.open_review_for_command(done2["id"])
    outcome = supervision.apply_verdict(
        store, review2["review_command_id"], "skip", actor="owner"
    )
    assert outcome["outcome"] == "skipped"
    target2 = store.get_command(done2["id"])
    assert target2["status"] == "done" and target2["last_verdict"] == "skipped"

    done3 = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    review3 = store.open_review_for_command(done3["id"])
    outcome = supervision.apply_verdict(
        store, review3["review_command_id"], "pass", actor="owner"
    )
    assert outcome["outcome"] == "passed"
    assert store.get_review(review3["id"])["verdict"] == "pass_by_owner"


# --------------------------------------------------------------------------- #
# Thẻ điểm
# --------------------------------------------------------------------------- #
def test_scorecard_counts(world):
    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    review = store.open_review_for_command(done["id"])
    supervision.apply_verdict(store, review["review_command_id"], "pass")
    card = supervision.scorecard(store, world["a1"]["id"])
    assert card["first_pass_rate"] == 100.0
    assert card["commands_done"] == 1
    assert card["verdicts"].get("passed") == 1
    assert card["escalations"] == 0


# --------------------------------------------------------------------------- #
# API: verdict + scorecard bằng token từng agent
# --------------------------------------------------------------------------- #
class _FakeManager:
    def launch(self, profile):  # pragma: no cover - không dùng trong test này
        return "launched"

    def is_running(self, profile):
        return False

    def connect_page(self, profile):
        raise NotImplementedError


@pytest.fixture()
def api(tmp_path, monkeypatch):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setenv("CCD_DATA_DIR", str(data_dir))
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("Kênh API", "api@gmail.com")
    worker = seed.create_agent("Muse Làm", "lam@example.ai")
    boss = seed.create_agent("Muse Chấm", "cham@example.ai")
    seed.assign_profiles(worker["id"], [profile["id"]])
    target = seed.create_command(
        "free", source="ui", profile_id=profile["id"], instruction="việc api",
        status="waiting_muse",
    )
    seed.claim_claude_command(target["id"], worker["id"])
    seed.finish_command(target["id"], "done", result="Xong — https://youtu.be/api12345")
    review = seed.open_review_for_command(target["id"])
    seed.promote_command_to_waiting(review["review_command_id"])
    seed.close()
    server = AgentServer(
        data_dir=data_dir, settings={}, manager=_FakeManager(), scan_fn=None
    )
    yield {
        "server": server, "worker": worker, "boss": boss,
        "target": target, "review": review,
    }


def _call(api, method, path, payload=None, headers=None, admin=False):
    hdrs = {}
    if admin:
        hdrs["X-Agent-Token"] = api["server"].token
    if headers:
        hdrs.update(headers)
    body = json.dumps(payload).encode("utf-8") if payload is not None else b""
    return api["server"].dispatch(method, path, hdrs, body)


def _agent_headers(agent):
    return {"X-Agent-Id": str(agent["id"]), "X-Agent-Token": agent["token"]}


def test_api_verdict_flow_with_agent_tokens(api):
    review_command_id = api["review"]["review_command_id"]
    boss_headers = _agent_headers(api["boss"])
    # Giám sát viên claim việc kiểm tra rồi gửi kết luận qua API.
    status, _ = _call(api, "POST", f"/api/commands/{review_command_id}/claim",
                      headers=boss_headers)
    assert status == 200
    status, payload = _call(
        api, "POST", f"/api/commands/{review_command_id}/verdict",
        {"verdict": "pass", "notes": "Đạt qua API",
         "checklist": [{"item": "bằng chứng", "status": "pass", "note": ""}]},
        headers=boss_headers,
    )
    assert status == 200 and payload["outcome"] == "passed"
    assert payload["command"]["last_verdict"] == "pass"
    # Kết luận lần hai: vòng đã đóng + lease đã nhả → bị chặn
    # (403 hết lease hoặc 409 vòng đã chốt — cả hai đều là từ chối).
    status, payload = _call(
        api, "POST", f"/api/commands/{review_command_id}/verdict",
        {"verdict": "pass"}, headers=boss_headers,
    )
    assert status in (403, 409)
    # verdict sai giá trị → 400 (dùng một việc kiểm tra khác còn mở? ở
    # đây vòng đã đóng — 400 phải đến từ kiểm tra giá trị TRƯỚC).
    status, payload = _call(
        api, "POST", f"/api/commands/{review_command_id}/verdict",
        {"verdict": "tuyệt vời"}, headers=boss_headers,
    )
    assert status == 400


def test_api_verdict_wrong_agent_forbidden(api):
    review_command_id = api["review"]["review_command_id"]
    # Người LÀM không được tự gửi kết luận cho việc kiểm tra của mình.
    status, payload = _call(
        api, "POST", f"/api/commands/{review_command_id}/verdict",
        {"verdict": "pass"}, headers=_agent_headers(api["worker"]),
    )
    assert status in (403, 404)


def test_api_scorecard_scoping(api):
    worker_id = api["worker"]["id"]
    status, payload = _call(
        api, "GET", f"/api/agents/{worker_id}/scorecard",
        headers=_agent_headers(api["worker"]),
    )
    assert status == 200 and payload["scorecard"]["agent_id"] == worker_id
    # Agent khác xem thẻ của người này → 403.
    status, _ = _call(
        api, "GET", f"/api/agents/{worker_id}/scorecard",
        headers=_agent_headers(api["boss"]),
    )
    assert status == 403
    # Token quản trị xem được.
    status, _ = _call(
        api, "GET", f"/api/agents/{worker_id}/scorecard", admin=True
    )
    assert status == 200
    status, _ = _call(api, "GET", "/api/agents/9999/scorecard", admin=True)
    assert status == 404


# --------------------------------------------------------------------------- #
# Giao diện
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def qapp():
    import os

    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_supervision_panel_and_history_dialog(qapp, world):
    from app.ui.supervision_panel import ReviewHistoryDialog, SupervisionPanel

    store = world["store"]
    done = _finish(store, world["a1"]["id"], profile_id=world["profile"]["id"])
    panel = SupervisionPanel(store, settings={})
    assert panel.reviews_table.rowCount() >= 1
    assert "đạt ngay lần đầu" in panel.scorecards_label.text()
    assert "→" in panel.matrix_label.text()

    dialog = ReviewHistoryDialog(store, done["id"], settings={})
    assert dialog.history_view.count() == 1
    assert dialog.skip_button.isEnabled() and dialog.pass_button.isEnabled()
    dialog._override("skip")
    assert store.get_command(done["id"])["last_verdict"] == "skipped"
    dialog.refresh()
    assert not dialog.skip_button.isEnabled()  # hết vòng đang mở


def test_settings_panel_supervision_tab(qapp, world):
    from app.ui.settings_panel import SettingsPanel

    settings = dict(config.DEFAULT_SETTINGS)
    panel = SettingsPanel(world["store"], settings, lambda changed: None)
    panel.refresh()
    assert panel.supervision_enabled_check.isChecked() is True
    assert panel.supervision_stall_spin.value() == 10
    panel.supervision_sample_spin.setValue(40)
    combos = panel._matrix_combos
    assert set(combos) == {
        world["a1"]["id"], world["a2"]["id"], world["a3"]["id"]
    }
    # Chọn giám sát viên cụ thể cho a1 → _gather phải ghi override;
    # tự chấm (không có trong combo) là không thể chọn.
    combo = combos[world["a1"]["id"]]
    datas = [combo.itemData(i) for i in range(combo.count())]
    assert world["a1"]["id"] not in datas
    combo.setCurrentIndex(datas.index(world["a3"]["id"]))
    gathered = panel._gather()
    assert gathered["supervision_sample_percent"] == 40
    assert gathered["supervision_matrix"] == {
        str(world["a1"]["id"]): world["a3"]["id"]
    }
