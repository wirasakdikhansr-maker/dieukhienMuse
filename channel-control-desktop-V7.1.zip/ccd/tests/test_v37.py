"""V3.7: cookies nhập xong tự đăng nhập + kết quả hiện lên tab hồ sơ;
thanh tiêu đề riêng + icon chung; nút hồ sơ -> menu chuột phải; lệnh
Tạo kênh mới cho MAIL + tự ghi danh đúng Muse phụ trách; Chạy ngay mở
trang Hồ sơ + giải thích Chờ Muse; tuỳ chọn ngoài màn hình."""

import json

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication, QPushButton


@pytest.fixture(scope="module", autouse=True)
def qapp():
    return QApplication.instance() or QApplication([])

from app import docking
from app.chrome_manager import ChromeManager
from app.store import CLAUDE_COMMAND_TYPES, Store
from app.ui import main_window as mw
from app.ui.commands_panel import CommandsPanel
from app.ui.main_window import MainWindow


def _window(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    win = MainWindow(store, ChromeManager(), {}, agent_server=None)
    return store, win


def test_create_channel_type_and_auto_agent_assignment(tmp_path):
    assert "create_channel" in CLAUDE_COMMAND_TYPES
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Mail A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])

    cmd = store.create_command(
        "create_channel", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
    )
    assert cmd["agent_id"] == agent["id"]  # tự ghi danh đúng Muse phụ trách

    local = store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="queued"
    )
    assert local["agent_id"] is None  # lệnh app tự chạy không gắn Muse


def test_commands_panel_create_channel_for_profile(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Mail A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    store.note_bridge_activity()  # V3.8: có Muse đang kết nối thì guard cho qua
    panel = CommandsPanel(store)
    assert panel.create_channel_button.text().startswith("🆕")
    panel._on_create_channel()
    commands = store.list_commands()
    assert len(commands) == 1
    cmd = commands[0]
    assert cmd["type"] == "create_channel"
    # V4.0 (Đ5): lệnh tạo từ panel vào 'queued' — dispatcher đẩy lên
    # 'waiting_muse' sau khi xét đủ điều kiện.
    assert cmd["status"] == "queued"
    assert cmd["profile_id"] == profile["id"]
    assert not cmd["channel_id"]  # lệnh cấp MAIL — không gắn kênh nào
    assert cmd["agent_id"] == agent["id"]
    assert "KÊNH THƯƠNG HIỆU ĐẦU TIÊN" in cmd["instruction"]


def test_row_action_buttons_have_icon_and_text(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Mail A", "a@gmail.com")
    panel = CommandsPanel(store)
    queued = store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="queued"
    )
    widget = panel._action_widget(queued)
    texts = [b.text() for b in widget.findChildren(QPushButton)]
    assert "▶ Chạy ngay" in texts
    assert "✕ Huỷ lệnh" in texts
    # V5.3.1 (M5 — pin sót từ V5.3, parent bắt được qua full-suite
    # độc lập 544 passed / 1 failed): hai assert này từng ghim quy
    # tắc V3.8.1 "chiều cao dòng ≥ 52px". Mục A5 của V5.3 đã CHỦ
    # ĐÍCH thay quy tắc đó theo lệnh chủ kênh "giảm chiều cao các
    # bảng xuống đủ hiển thị chữ, cách trên dưới 2px" — vòng build
    # V5.3 không quét tới file này nên pin cũ còn sót. Nay ghim
    # theo công thức gọn hiện hành: chiều cao dòng KHỚP
    # theme.compact_row_height(cỡ chữ của bảng, nội dung tối
    # thiểu = độ cao nút hàng lệnh hiệu lực của panel). Hai
    # assert icon+chữ ở trên giữ nguyên — phần đó vẫn đúng.
    from app.ui import theme as _theme

    expected = _theme.compact_row_height(
        panel.table.font(), min_content=panel._action_button_height
    )
    assert panel.table.verticalHeader().defaultSectionSize() == expected
    panel.refresh()
    assert panel.table.rowHeight(0) == expected


def test_title_bar_and_common_icon(tmp_path):
    _store, win = _window(tmp_path)
    assert win.title_bar.btn_min.text() == "−"
    assert win.title_bar.btn_close.text() == "✕"
    assert not win.windowIcon().isNull()  # logo Muse Automation
    assert win.windowFlags() & Qt.FramelessWindowHint
    win._toggle_maximize()
    assert win.isMaximized()
    win._toggle_maximize()
    assert not win.isMaximized()
    win.close()


def test_profile_actions_are_context_menu_not_button_stack(tmp_path):
    _store, win = _window(tmp_path)
    # Các nút thật vẫn tồn tại (menu gọi chung) nhưng hộp chứa bị ẩn.
    assert win._profile_actions_box.isHidden()
    assert win.btn_scan.text() == "Quét kênh"
    assert win.btn_import_cookies.text().startswith("🍪")
    win.close()


def test_offscreen_option_default_on_and_parking(tmp_path, monkeypatch):
    _store, win = _window(tmp_path)
    assert win.chk_offscreen.isChecked() is True
    calls = []
    monkeypatch.setattr(docking, "move_window_offscreen", lambda h: calls.append(("off", h)) or True)
    monkeypatch.setattr(docking, "minimize_window", lambda h: calls.append(("min", h)) or True)
    win._park_window(1234)
    assert calls == [("off", 1234)]
    win.chk_offscreen.setChecked(False)
    win._park_window(55)
    assert calls[-1] == ("min", 55)
    win.close()


def test_run_now_dispatch_waiting_muse_stays_on_current_tab(tmp_path):
    """V4.2 (O-21) thay cho hành vi cũ: Chạy ngay cho lệnh của Muse
    KHÔNG ép chuyển sang trang Hồ sơ nữa — chỉ ghi chú không-modal
    (nhật ký) là lệnh chờ Muse phụ trách thực hiện."""
    store, win = _window(tmp_path)
    profile = store.add_profile("Mail A", "a@gmail.com")
    cmd = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
    )
    before = win.sections.currentIndex()
    win._run_now_dispatch(cmd["id"])
    assert win.sections.currentIndex() == before
    assert win.sections.currentIndex() != mw.SEC_PROFILES
    journal = store.list_journal()
    assert any("lệnh của Muse" in (j["message"] or "") for j in journal)
    win.close()


def test_run_now_dispatch_queued_runs_and_opens_profile(tmp_path):
    store, win = _window(tmp_path)
    profile = store.add_profile("Mail A", "a@gmail.com")
    cmd = store.create_command(
        "scan", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="queued",
    )
    ran = []
    win._runner.run_now = lambda cid: ran.append(cid)
    win._run_now_dispatch(cmd["id"])
    assert ran == [cmd["id"]]
    assert win.sections.currentIndex() == mw.SEC_PROFILES
    win.close()


def test_import_cookies_triggers_auto_login(tmp_path, monkeypatch):
    store, win = _window(tmp_path)
    profile = store.add_profile("Mail A", "a@gmail.com")
    win._current_profile_id = profile["id"]
    cookie_file = tmp_path / "cookies.json"
    cookie_file.write_text(
        json.dumps([
            {"name": "SID", "value": "x", "domain": ".google.com", "path": "/"},
            {"name": "HSID", "value": "y", "domain": ".google.com", "path": "/"},
        ]),
        encoding="utf-8",
    )
    monkeypatch.setattr(
        mw.QFileDialog, "getOpenFileName",
        staticmethod(lambda *a, **k: (str(cookie_file), "")),
    )
    logins = []
    win._submit_login = lambda p: logins.append(p["id"])
    win.on_import_cookies()
    assert logins == [profile["id"]]  # nhập xong -> TỰ đăng nhập luôn
    assert "2 cookie" in win.cookie_status.text()
    win.close()
