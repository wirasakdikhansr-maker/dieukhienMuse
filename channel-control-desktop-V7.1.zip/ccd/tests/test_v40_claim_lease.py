"""V4.0 (H1) — Claim + Lease cho lệnh chờ Muse qua Agent API 2.4.

Claim phải NGUYÊN TỬ (hai phía gọi cùng lúc chỉ một phía thắng, phía
thua nhận 409 kèm trạng thái hiện tại); lease được cấp khi claim, gia
hạn bởi chính chủ lease qua progress/heartbeat, và chốt chặn lease
ngăn Muse khác (dù cùng phạm vi hồ sơ) thao tác lên lệnh đang chạy.
Đường tương thích cũ (Đ1): báo progress đầu tiên vẫn tự claim nhưng
nay có lease đi kèm.
"""

import json

import pytest

from app import config
from app.agent_server import AgentServer
from app.store import Store
from test_agent_server import FakeManager, stub_scan


@pytest.fixture()
def world(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("Kenh A", "a@gmail.com")
    agent_a = seed.create_agent("Muse A", "a@claude.ai")
    agent_b = seed.create_agent("Muse B", "b@claude.ai")
    seed.assign_profiles(agent_a["id"], [profile["id"]])
    seed.close()
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0, "lease_seconds": 120},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    yield {
        "server": server,
        "data_dir": data_dir,
        "profile": profile,
        "agent_a": agent_a,
        "agent_b": agent_b,
    }


def call(world, method, path, agent=None, admin=False, body=None):
    headers = {}
    if agent is not None:
        headers = {
            "X-Agent-Id": str(agent["id"]),
            "X-Agent-Token": agent["token"],
        }
    elif admin:
        headers = {"X-Agent-Token": world["server"].token}
    data = json.dumps(body).encode("utf-8") if body is not None else b""
    return world["server"].dispatch(method, path, headers, data)


def make_waiting(world, agent_id=None):
    store = Store(config.db_path(world["data_dir"]))
    try:
        return store.create_command(
            "optimize",
            source="ui",
            profile_id=world["profile"]["id"],
            profile_slug=world["profile"]["slug"],
            status="waiting_muse",
            agent_id=agent_id,
        )
    finally:
        store.close()


def set_lease_past(world, command_id):
    store = Store(config.db_path(world["data_dir"]))
    try:
        store._conn.execute(
            "UPDATE commands SET lease_expires_at = '2000-01-01T00:00:00+07:00'"
            " WHERE id = ?",
            (command_id,),
        )
        store._conn.commit()
    finally:
        store.close()


def test_claim_grants_lease_and_second_claim_conflicts(world):
    cmd = make_waiting(world)
    status, payload = call(
        world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"]
    )
    assert status == 200
    got = payload["command"]
    assert got["status"] == "running"
    assert got["lease_agent_id"] == world["agent_a"]["id"]
    assert got["lease_expires_at"]
    # Claim lại (dù chính chủ hay admin) → 409 kèm trạng thái hiện tại.
    for kwargs in ({"agent": world["agent_a"]}, {"admin": True}):
        status2, payload2 = call(
            world, "POST", f"/api/commands/{cmd['id']}/claim", **kwargs
        )
        assert status2 == 409
        assert payload2["command"]["status"] == "running"


def test_claim_by_unassigned_agent_forbidden(world):
    cmd = make_waiting(world)
    status, _payload = call(
        world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_b"]
    )
    assert status == 403


def test_progress_from_lease_holder_renews_lease(world):
    cmd = make_waiting(world)
    call(world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"])
    set_lease_past(world, cmd["id"])
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/progress",
        agent=world["agent_a"],
        body={"progress": 40, "step": "Đang tối ưu"},
    )
    assert status == 200
    assert payload["command"]["lease_expires_at"] > "2000-01-01"
    assert payload["command"]["status"] == "running"


def _also_assign(world, agent):
    """Phân công thêm một Muse cho cùng hồ sơ (nhiều Muse có thể
    cùng trong phạm vi một hồ sơ; chủ hồ sơ chính vẫn là agent_a)."""
    store = Store(config.db_path(world["data_dir"]))
    try:
        store.assign_profiles(agent["id"], [world["profile"]["id"]])
    finally:
        store.close()


def test_progress_and_result_from_other_agent_blocked_by_lease(world):
    # agent_a ghi danh trên lệnh (agent_id) nên có quyền truy cập;
    # agent_b cũng trong phạm vi hồ sơ nên qua được chốt phạm vi —
    # nhưng lease thuộc về A thì B không thao tác được (chốt lease).
    _also_assign(world, world["agent_b"])
    cmd = make_waiting(world, agent_id=world["agent_a"]["id"])
    status, _ = call(
        world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"]
    )
    assert status == 200
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/progress",
        agent=world["agent_b"],
        body={"progress": 50},
    )
    assert status == 403
    assert "lease" in payload["error"]
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/result",
        agent=world["agent_b"],
        body={"status": "done", "result": "xong"},
    )
    assert status == 403
    assert "lease" in payload["error"]


def test_release_returns_command_and_keeps_attempts(world):
    cmd = make_waiting(world)
    call(world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"])
    status, payload = call(
        world, "POST", f"/api/commands/{cmd['id']}/release", agent=world["agent_a"]
    )
    assert status == 200
    got = payload["command"]
    assert got["status"] == "waiting_muse"
    assert got["lease_agent_id"] is None
    assert got["lease_expires_at"] is None
    assert got["attempts"] == 0
    # Không còn giữ lease → release tiếp là 409.
    status, _ = call(
        world, "POST", f"/api/commands/{cmd['id']}/release", agent=world["agent_a"]
    )
    assert status == 409


def test_implicit_progress_claim_still_works_and_grants_lease(world):
    # Đ1: phía Muse cũ chỉ báo progress (không gọi claim) vẫn nhận
    # được việc như trước V4.0 — nhưng từ nay có lease đi kèm.
    cmd = make_waiting(world)
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/progress",
        agent=world["agent_a"],
        body={"progress": 5, "step": "Bắt đầu"},
    )
    assert status == 200
    got = payload["command"]
    assert got["status"] == "running"
    assert got["lease_agent_id"] == world["agent_a"]["id"]
    assert got["lease_expires_at"]


def test_heartbeat_with_current_command_renews_lease(world):
    cmd = make_waiting(world)
    call(world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"])
    set_lease_past(world, cmd["id"])
    status, _payload = call(
        world,
        "POST",
        f"/api/agents/{world['agent_a']['id']}/heartbeat",
        agent=world["agent_a"],
        body={"current_command_id": cmd["id"]},
    )
    assert status == 200
    store = Store(config.db_path(world["data_dir"]))
    try:
        row = store.get_command(cmd["id"])
    finally:
        store.close()
    assert row["lease_expires_at"] > "2000-01-01"
