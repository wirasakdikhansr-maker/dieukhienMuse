"""V4.6 (sửa phạm vi 10:46) — Chat sống tại VĂN PHÒNG.

Panel chi tiết agent ở Văn phòng là khung chat đầy đủ của agent
đang chọn (component dùng chung với mục Tài khoản); trên scene,
từng bàn có huy hiệu 💬 số tin chưa đọc và bong bóng trích đoạn
CÂU HỎI khi có lệnh needs_user đang chờ — xuất hiện/biến mất đúng
theo trạng thái dữ liệu; mở luồng ở Văn phòng là hết huy hiệu ở
mọi bề mặt (cùng một Store).
"""

import pytest
from PySide6.QtCore import QPointF, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QGraphicsTextItem

from app.store import Store
from app.ui.agents_panel import AgentsPanel
from app.ui.office_view import OfficeView


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _pump(times=6):
    for _ in range(times):
        QApplication.processEvents()


def _seed(tmp_path):
    store = Store(tmp_path / "office_chat.db")
    profile = store.add_profile("KenhHoatHinh", "23shinryujin@gmail.com")
    a1 = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    a2 = store.create_agent("dabnire34", "dabnire34@gmail.com")
    store.assign_profiles(a1["id"], [profile["id"]])
    store.touch_agent_heartbeat(a1["id"])
    store.touch_agent_heartbeat(a2["id"])
    cmd = store.create_command(
        "create_video", profile_id=profile["id"],
        instruction="Tạo video EP24", status="running",
        agent_id=a1["id"],
    )
    store.update_command_progress(cmd["id"], 60, "Đang dựng")
    return store, profile, a1, a2, cmd


def _make_view(store):
    view = OfficeView(store, settings={})
    view.resize(1500, 900)
    view.show()
    _pump(8)
    return view


def _texts(view):
    return [
        item.toPlainText()
        for item in view._scene.items()
        if isinstance(item, QGraphicsTextItem)
    ]


def test_badge_and_question_bubble_follow_state(qapp, tmp_path):
    store, profile, a1, _a2, _cmd = _seed(tmp_path)
    view = _make_view(store)
    # Chưa có tin/lệnh chờ → không huy hiệu, không bong bóng câu hỏi.
    assert not any(t.startswith("💬") for t in _texts(view))
    assert not any("Câu hỏi đang chờ" in t for t in _texts(view))

    # 1 tin Muse chưa đọc → huy hiệu 💬 1 trên bàn.
    store.add_message(a1["id"], "agent", "Đã xong bản nháp, anh xem nhé")
    view.refresh()
    _pump()
    assert any(t == "💬 1" for t in _texts(view))

    # Lệnh kẹt needs_user → bong bóng trích đoạn câu hỏi + huy hiệu
    # tăng (tin hệ thống của needs_user cũng là tin chưa đọc).
    stuck = store.create_command(
        "create_video", profile_id=profile["id"],
        instruction="Đăng EP24",
    )
    store.set_command_needs_user(
        stuck["id"], "Cần mật khẩu đăng nhập Studio để tiếp tục"
    )
    view.refresh()
    _pump()
    texts = _texts(view)
    assert any("Câu hỏi đang chờ bạn trả lời" in t for t in texts)
    assert any("Cần mật khẩu đăng nhập Studio" in t for t in texts)
    # V5.2.1 — HÀNH VI MỚI thay pin cũ "💬 2": câu hỏi needs_user
    # làm khung chat trong panel TỰ BUNG và nạp luồng ngay trong
    # nhịp này (quy cách tự bung của V5.2.1) → cả hai tin (agent +
    # hệ thống) được đánh dấu đã đọc tại chỗ, đúng nghĩa "mở luồng
    # là đã đọc" của V4.6 → huy hiệu 💬 trên bàn tắt ở nhịp dựng
    # lại nối tiếp. Tín hiệu phải giữ là BONG BÓNG CÂU HỎI (lệnh
    # vẫn đang chờ), đã assert ở hai dòng trên.
    assert view.chat_widget.is_expanded
    assert not any(t.startswith("💬") for t in texts)

    # Bấm vào bong bóng câu hỏi → chọn đúng agent đó.
    point = view.view.mapFromScene(QPointF(148, 272))
    QTest.mouseClick(view.view.viewport(), Qt.LeftButton, pos=point)
    _pump()
    assert view._selected_agent_id == a1["id"]

    # Người dùng xử lý xong: lệnh chạy lại + tin đã đọc → bong bóng
    # và huy hiệu biến mất ở lần làm mới kế.
    store.update_command(stuck["id"], status="running")
    store.mark_read(a1["id"], "agent")
    store.mark_read(a1["id"], "system")
    view.refresh()
    _pump()
    texts = _texts(view)
    assert not any("Câu hỏi đang chờ" in t for t in texts)
    assert not any(t.startswith("💬") for t in texts)
    view.close()
    store.close()


def test_opening_thread_in_office_clears_badges_everywhere(qapp, tmp_path):
    store, _profile, a1, _a2, _cmd = _seed(tmp_path)
    store.add_message(a1["id"], "agent", "Tin một")
    store.add_message(a1["id"], "agent", "Tin hai")
    counts = store.unread_counts().get(a1["id"], {})
    assert counts.get("agent") == 2

    # Văn phòng mở ra là panel chat đã mở luồng của agent đầu tiên
    # (mặc định được chọn) → tin được đánh dấu đã đọc tại chỗ.
    view = _make_view(store)
    _pump()
    assert view.chat_widget.agent_id == a1["id"]
    counts = store.unread_counts().get(a1["id"], {})
    assert counts.get("agent", 0) == 0
    # Huy hiệu trên bàn ở scene cũng hết sau nhịp làm mới.
    view.refresh()
    _pump()
    assert not any(t.startswith("💬") for t in _texts(view))
    view.close()

    # Mục Tài khoản (cửa vào thứ hai, cùng dữ liệu): không còn huy
    # hiệu 💬 ở ô tên của agent đó.
    panel = AgentsPanel(store, settings={})
    panel.refresh()
    for row, agent in enumerate(panel._agents):
        if agent["id"] == a1["id"]:
            assert "💬" not in panel.table.item(row, 0).text()
    panel.close()
    store.close()
