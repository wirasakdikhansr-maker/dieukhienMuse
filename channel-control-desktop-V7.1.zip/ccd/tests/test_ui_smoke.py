"""Khói giao diện V3.1 (offscreen): dựng cửa sổ chính, chuyển qua đủ
7 mục điều hướng, thử chế độ toàn màn hình trình duyệt (theater),
thu/mở dock dưới và thanh điều hướng."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui.main_window import (  # noqa: E402
    SEC_AGENTS,
    SEC_REPORTS,
    SEC_AUTO,
    SEC_CHECKS,
    SEC_COMMANDS,
    SEC_JOURNAL,
    SEC_MONITOR,
    SEC_OFFICE,
    SEC_OVERVIEW,
    SEC_PROFILES,
    SEC_SETTINGS,
    MainWindow,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1",
            "name": "Awake in the Dark",
            "handle": "@AwakeInTheDarkSeries",
            "url": "https://www.youtube.com/channel/UC1",
            "subs": 42,
            "video_count": 11,
        },
    )
    store.append_journal("Khói kiểm thử mở app.", profile["id"])
    win = MainWindow(store, ChromeManager(), settings)
    yield win
    win.close()
    store.close()


def test_seven_sections_and_switching(window):
    # V4.3 (G1): GỘP điều hướng 11 → 7 mục (Tổng quan nhập vào Văn
    # phòng; Lệnh + Tiến độ → Công việc; Báo cáo + Kiểm tra và Nhật
    # ký + Cài đặt thành mục có tab con). Các hằng SEC_ cũ là bí danh
    # trỏ đúng mục mới nên vòng chuyển mục dưới đây vẫn chạy đủ —
    # ghim số mục đã cập nhật từ 11 (V4.1) xuống 7 trong cùng đợt này.
    # V6.0: + mục Giám sát nối ở cuối → 8 mục (7 mục cũ giữ nguyên
    # chỉ số), pin cập nhật cùng bump như lệ.
    assert window.sections.count() == 8
    assert len(window._nav_buttons) == 8
    for index in (
        SEC_OFFICE,
        SEC_OVERVIEW,
        SEC_COMMANDS,
        SEC_MONITOR,
        SEC_AGENTS,
        SEC_REPORTS,
    SEC_REPORTS,
        SEC_AUTO,
        SEC_CHECKS,
        SEC_JOURNAL,
        SEC_SETTINGS,
        SEC_PROFILES,
    ):
        window._switch_section(index)
        assert window.sections.currentIndex() == index


def test_overview_kpis_render(window):
    window._switch_section(SEC_OVERVIEW)
    window.overview_panel.refresh()
    assert window.overview_panel.kpi_channels._value_label.text() == "1"
    assert window.overview_panel.kpi_subs._value_label.text() == "42"


def test_theater_mode_hides_chrome_and_restores(window):
    # V4.3.2 (F2): panel tiêu đề CHANNEL CONTROL đã bị XOÁ hẳn nên
    # theater không còn header_bar để ẩn/khôi phục — pin cũ về
    # header_bar bỏ, giữ nguyên các khẳng định chrome còn lại.
    window._switch_section(SEC_PROFILES)
    window.enter_theater()
    assert window._theater is True
    assert window.nav_rail.isHidden()
    assert window.profile_column.isHidden()
    assert not window.theater_bar.isHidden()
    window._exit_theater()
    assert window._theater is False
    assert not window.nav_rail.isHidden()
    assert window.theater_bar.isHidden()


def test_dock_collapse_and_expand(window):
    window._set_dock_expanded(False)
    assert window.dock_tabs.isHidden()
    window._set_dock_expanded(True)
    assert not window.dock_tabs.isHidden()


def test_rail_collapse(window):
    # V3.4: điều hướng là TOPBAR ngang — thu gọn = chỉ icon, mở rộng =
    # icon + nhãn; thanh chạy ngang khắp chiều rộng cửa sổ.
    window._apply_rail_state(True)
    # V4.1: nút đầu tiên của topbar là 🏢 Văn phòng.
    assert window._nav_buttons[0].text() == "🏢"
    assert window.nav_rail.height() <= 56
    window._apply_rail_state(False)
    assert "Văn phòng" in window._nav_buttons[0].text()


def test_channel_empty_state_logic(window):
    # Hồ sơ có 1 kênh -> hiện bảng; xoá hết kênh -> hiện trạng thái rỗng.
    profile = window._store.list_profiles()[0]
    window._current_profile_id = profile["id"]
    window._refresh_right_pane(profile["id"])
    assert window.channel_stack.currentIndex() == 0
    window._store._conn.execute(
        "DELETE FROM channels WHERE profile_id = ?", (profile["id"],)
    )
    window._store._conn.commit()
    window._refresh_right_pane(profile["id"])
    assert window.channel_stack.currentIndex() == 1


def test_settings_tabs_present(window):
    window._switch_section(SEC_SETTINGS)
    tabs = window.settings_panel.tabs
    labels = [tabs.tabText(i) for i in range(tabs.count())]
    assert labels == [
        "Chung",
        "Trình duyệt và Nhúng",
        "Cầu nối Muse",
        # V6.0: tab Giám sát chéo (công tắc tổng/ngưỡng/% mẫu/trần
        # vòng/ma trận) — pin cập nhật cùng đợt thêm tab.
        "Giám sát chéo",
        # V6.3: bộ quy tắc + chỉ tiêu KPI, và các công tắc tự vận hành.
        "📏 Quy tắc · KPI",
        "⚙ Tự vận hành",
        "Dữ liệu",
        "Giao diện",
    ]
