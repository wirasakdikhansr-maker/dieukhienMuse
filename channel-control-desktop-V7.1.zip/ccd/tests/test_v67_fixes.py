"""V6.7 — sửa lỗi V6.6 + trình duyệt chạy nền/ theo nhu cầu + bảng sự cố + sổ giao việc + tạo hồ sơ hàng loạt."""

from __future__ import annotations

import os
import time
from datetime import datetime, timedelta

import pytest

from app import bulk_profiles, lead_autopilot, muse_chat_bridge as mcb, muse_control, office_feed, work_board
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


@pytest.fixture(scope="module")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


SENT = mcb.task_text({"id": "abc123def456", "type": "upload", "instruction": "Đăng video tập 13", "payload": {}},
                     "Kids 3D", "○ 1. Mở Studio", "Muse 02")


def _page(reply_html: str) -> str:
    import html as _html

    paras = "".join(f"<p>{_html.escape(line)}</p>" for line in SENT.splitlines() if line.strip())
    return (f"<html><body><main><div class=list><div class=row><div class=bubble>Tin cũ</div></div>"
            f"<div class=row><div class=bubble>{paras}</div></div>{reply_html}</div>"
            f"<div><textarea></textarea></div><footer>Muse có thể mắc lỗi.</footer></main></body></html>")


@pytest.mark.skipif(os.environ.get("CCD_SKIP_BROWSER") == "1", reason="không có Chromium")
def test_reader_never_returns_our_own_guide_text():
    playwright = pytest.importorskip("playwright.sync_api")
    with playwright.sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.set_content(_page(""))
        page.evaluate(mcb.BASELINE_JS)
        res = page.evaluate(mcb.read_expr(mcb.pick_needle(SENT), SENT))
        assert res["text"] == "", res["text"][:200]  # chưa trả lời → KHÔNG được đọc nhầm phần hướng dẫn
        page.evaluate("document.querySelector('.list').insertAdjacentHTML('beforeend',"
                      " '<div class=row><div><p>ĐÃ NHẬN việc #abc123def456 — mở Studio.</p></div></div>')")
        res = page.evaluate(mcb.read_expr(mcb.pick_needle(SENT), SENT))
        assert res["text"] == "ĐÃ NHẬN việc #abc123def456 — mở Studio."
        assert mcb.classify_reply(res["text"]) == "ack"
        browser.close()


def test_guide_samples_never_become_actions():
    assert muse_control.parse_actions(SENT) == []
    real = 'Ok\n```ccd\n{"action":"goto","url":"https://studio.youtube.com"}\n{"action":"click","text":"<chữ trên nút>"}\n```'
    assert [a["action"] for a in muse_control.parse_actions(real)] == ["goto"]


def test_missing_task_detection():
    assert mcb.says_missing_task("Đã ghi nhận chuyển giao lệnh #c12 — nhưng tin nhắn này chỉ có mã, chưa có nội dung lệnh")
    assert mcb.says_missing_task("Mình cũng chưa nhận được nội dung của lệnh #bab03 nên chưa thể bắt đầu")
    assert not mcb.says_missing_task("ĐÃ NHẬN việc #1 — mở Studio")


def test_lead_messages_carry_task_content_and_reassign_resends(store, monkeypatch):
    monkeypatch.setattr(lead_autopilot, "SENDER", None)
    a = store.create_agent("A", "a@x.com")
    b = store.create_agent("B", "b@x.com")
    for agent in (a, b):
        store.touch_agent_heartbeat(agent["id"])
    cmd = store.create_command("upload", instruction="Đăng video tập 13 lúc 19h", agent_id=a["id"])
    lead_autopilot._tell(store, a["id"], f"Báo tiến độ việc #{cmd['id']}", cmd["id"])
    body = store.list_messages(a["id"])[-1]["body"]
    assert "Đăng video tập 13 lúc 19h" in body
    store.update_command(cmd["id"], status="running")
    store.update_command_payload_flags(cmd["id"], {"chat_sent": True, "acked": True})
    target = lead_autopilot._reassign(store, store.get_command(cmd["id"]), {a["id"]})
    row = store.get_command(cmd["id"])
    assert target["id"] == b["id"] and row["status"] == "waiting_muse"
    assert not row["payload"].get("chat_sent") and not row["payload"].get("acked")


def test_window_resends_full_task_when_muse_lacks_content(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent = st.create_agent("Muse 02", "b@x.com")
    win = MainWindow(st, ChromeManager(), settings)
    try:
        cmd = st.create_command("free", instruction="Viết mô tả", agent_id=agent["id"])
        st.update_command(cmd["id"], status="needs_user")
        st.update_command_payload_flags(cmd["id"], {"chat_sent": True})
        win._apply_bridge_reply(cmd["id"], "Mình chưa nhận được nội dung của lệnh này, chỉ có mã.")
        row = st.get_command(cmd["id"])
        assert row["status"] == "waiting_muse" and not row["payload"].get("chat_sent")
        assert row["payload"]["resend_count"] == 1
    finally:
        win.close()


def test_launch_hidden_by_default_and_visible_only_on_request(tmp_path, monkeypatch):
    from app import chrome_manager

    captured = []

    class P:
        def poll(self):
            return None

    monkeypatch.setattr(chrome_manager.config, "find_chrome", lambda override=None: "chrome.exe")
    monkeypatch.setattr(chrome_manager.subprocess, "Popen", lambda args, **k: captured.append(args) or P())
    state = {"n": 0}

    def port_open(port, timeout=1.0):
        state["n"] += 1
        return state["n"] % 2 == 0

    monkeypatch.setattr(chrome_manager.cdp, "debug_port_open", port_open)
    manager = chrome_manager.ChromeManager()
    profile = {"slug": "p1", "port": 9556, "label": "P", "user_data_dir": str(tmp_path / "u")}
    manager.launch(profile)
    assert "--window-position=-32000,-32000" in captured[-1]
    manager.launch(profile, start_minimized=False)
    assert "--window-position=-32000,-32000" not in captured[-1]


def test_bridge_closes_idle_and_caps_browsers(monkeypatch):
    closed = []
    monkeypatch.setattr(mcb.cdp, "debug_port_open", lambda port, timeout=1.0: True)
    monkeypatch.setattr(mcb.cdp, "browser_call", lambda port, method, timeout=5: closed.append(port))
    bridge = mcb.ChatBridge(manager=None, emit=lambda e: None)
    now = time.monotonic()
    for aid in (1, 2, 3, 4):
        bridge._pseudo[aid] = {"port": 9000 + aid}
        bridge.last_used[aid] = now - 60 * (10 - aid)
    bridge.max_browsers = 3
    assert bridge._enforce_cap(4) == [1]  # đang mở 1,2,3 + sắp mở 4 → giữ tối đa 3, tắt cái lâu chưa dùng nhất
    closed.clear()
    bridge.last_used = {3: now - 15 * 60, 4: now - 60}
    assert bridge.close_idle(10) == [3] and closed == [9003]


def test_office_chips_names_and_fresh_bubbles(store):
    lead = store.create_agent("Muse 01", "lead@x.com")
    worker = store.create_agent("dabnire34@gmail.com", "dabnire34@gmail.com")
    settings = {"supervision_mode": "lead", "supervision_lead_agent_id": lead["id"], "office_mode": "work"}
    msg = store.add_message(worker["id"], "agent", "TIẾN ĐỘ: 40% — đang dựng")
    data = office_feed.build(store, settings)
    desk = next(d for d in data["desks"] if d["agent_id"] == worker["id"])
    assert desk["name"] == "dabnire34" and desk["chip"]["text"] == "rảnh"
    assert desk["bubble"]["fresh"] is True
    old = (datetime.now().astimezone() - timedelta(minutes=5)).isoformat(timespec="seconds")
    store._conn.execute("UPDATE agent_messages SET created_at = ? WHERE id = ?", (old, msg["id"]))
    store._conn.commit()
    desk = next(d for d in office_feed.build(store, settings)["desks"] if d["agent_id"] == worker["id"])
    assert desk["bubble"]["fresh"] is False  # cũ → tự ẩn, chỉ hiện khi rê chuột


def test_stage_bubble_alpha_hover_and_fade(qapp):
    from app.ui.office_iso import _IsoStage

    stage = _IsoStage()
    stage._built_at = time.monotonic()
    desk = {"agent_id": 5, "bubble": {"age": 2, "fresh": True}}
    assert stage._bubble_alpha(desk) == 1.0
    desk["bubble"]["age"] = office_feed.BUBBLE_FRESH_S - 3
    assert 0 < stage._bubble_alpha(desk) < 1
    desk["bubble"]["age"] = 600
    assert stage._bubble_alpha(desk) == 0.0
    stage._hover = 5
    assert stage._bubble_alpha(desk) == 1.0


def test_issue_panel_batch_buttons_and_resume_all(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent = st.create_agent("Muse 02", "b@x.com")
    win = MainWindow(st, ChromeManager(), settings)
    try:
        cmd = st.create_command("free", instruction="Viết", agent_id=agent["id"])
        st.update_command(cmd["id"], status="needs_user")
        issue = {"key": "needs:x", "severity": "critical", "title": "Cần xử lý", "kind": "needs_user",
                 "command_id": cmd["id"], "agent_id": agent["id"], "actions": [], "lead_note": "đã xử lý 10:00 — bắt tự xử lý"}
        panel = win.office_panel.issues_panel
        panel.set_issues([issue])
        assert panel.lead_all_button.isVisibleTo(panel) and panel.resume_all_button.isVisibleTo(panel)
        win._on_office_issue_action("resume_all", {"issues": [issue]})
        assert st.get_command(cmd["id"])["status"] == "queued"
        called = []
        monkeypatch.setattr(win, "_lead_tick", lambda force=False: called.append(force))
        win._on_office_issue_action("lead_all", {})
        assert called == [True]
    finally:
        win.close()


def test_assignment_ledger(store):
    a = store.create_agent("Muse 02", "b@x.com")
    cmd = store.create_command("upload", instruction="Đăng tập 13", agent_id=a["id"])
    sent = datetime.now().astimezone() - timedelta(minutes=10)
    store.update_command_payload_flags(cmd["id"], {"chat_sent": True, "chat_sent_at": sent.isoformat(timespec="seconds"),
                                                   "acked": True, "acked_at": (sent + timedelta(minutes=2)).isoformat(timespec="seconds")})
    store.update_command(cmd["id"], status="running")
    store.add_lead_decision(None, f"ack:{cmd['id']}", "ack_ping", command_id=cmd["id"], agent_id=a["id"],
                            detail="hỏi", outcome="done")
    store.create_command("free", instruction="không qua TP", agent_id=a["id"])
    data = work_board.assignment_ledger(store)
    group = data["groups"][0]
    assert data["total"] == 1 and group["name"] == "Muse 02" and group["acked"] == 1 and group["nudges"] == 1
    item = group["items"][0]
    assert item["stage"].startswith("▶") and item["ack_min"] == pytest.approx(2, abs=0.1)
    assert "hỏi đã nhận×1" in item["actions"]


def test_bulk_profiles_parse_create_and_split(store, tmp_path):
    lead = store.create_agent("Lead", "lead@x.com")
    a = store.create_agent("A", "a@x.com")
    b = store.create_agent("B", "b@x.com")
    entries, errors = bulk_profiles.parse_lines("k1@gmail.com|pw1\nk2@gmail.com|pw2|Kênh Mèo\nsai-dong\nk1@gmail.com|x\nk3@gmail.com|pw3")
    assert [e["email"] for e in entries] == ["k1@gmail.com", "k2@gmail.com", "k3@gmail.com"] and len(errors) == 2
    results = bulk_profiles.create_and_assign(store, entries, "auto", lead_id=lead["id"],
                                              task={"type": "free", "instruction": "Kiểm tra kênh"}, base=tmp_path)
    assert [r["status"] for r in results] == ["created"] * 3
    owners = [r["agent_id"] for r in results]
    assert lead["id"] not in owners and set(owners) == {a["id"], b["id"]}
    from app import credentials_vault

    profile = store.get_profile(results[1]["profile_id"])
    assert profile["label"] == "Kênh Mèo" and credentials_vault.load_password(profile["slug"], tmp_path)["password"] == "pw2"
    assert all(r["command_id"] for r in results)
    again = bulk_profiles.create_and_assign(store, entries[:1], b["id"], base=tmp_path)
    assert again[0]["status"] == "exists" and again[0]["agent_id"] == b["id"]


def test_lead_can_create_profiles_via_chat_action(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    lead = st.create_agent("Lead", "lead@x.com")
    worker = st.create_agent("Worker", "w@x.com")
    settings["supervision_mode"] = "lead"
    settings["supervision_lead_agent_id"] = lead["id"]
    win = MainWindow(st, ChromeManager(), settings)
    sent = []
    monkeypatch.setattr(win, "_send_to_muse", lambda a, text, cid=None: sent.append((a["id"], text)))
    monkeypatch.setattr(win, "_submit_login", lambda profile: None)
    try:
        text = '```ccd\n{"action":"create_profiles","accounts":["n1@gmail.com|pw"],"agent":"auto"}\n```'
        assert win._maybe_run_muse_control(st.get_agent(lead["id"]), text, None)
        assert st.find_profile_by_gmail("n1@gmail.com") is not None
        assert "pw" not in sent[-1][1] and "n1@gmail.com: created" in sent[-1][1]
        win._maybe_run_muse_control(st.get_agent(worker["id"]), text.replace("n1", "n2"), None)
        assert st.find_profile_by_gmail("n2@gmail.com") is None  # không phải trưởng phòng → từ chối
    finally:
        win.close()


def test_ledger_view_and_bulk_dialog_render(qapp, store):
    from app.ui.bulk_profiles_dialog import BulkProfilesDialog
    from app.ui.ledger_view import LedgerView

    view = LedgerView(store)
    view.refresh(force=True)
    assert view.tree.topLevelItemCount() == 1
    dialog = BulkProfilesDialog(store)
    dialog.text.setPlainText("x1@gmail.com|p\nhỏng")
    assert "1 tài khoản hợp lệ" in dialog.preview.text()
    assert dialog.values()["entries"][0]["email"] == "x1@gmail.com"
