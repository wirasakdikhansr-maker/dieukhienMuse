"""Kiểm thử quét TOÀN BỘ kênh (yêu cầu 28/10): account_menu chỉ trả
MỘT PHẦN kênh -> scanner phải hợp nhất thêm panel Accounts + trang
View all channels (channel_switcher); đồng thời BỎ kênh chính cá nhân
(kênh trùng tên tài khoản Google) — chỉ lấy kênh thương hiệu."""

from app import parser, scanner
from app.store import Store

PERSONAL_ID = "UC" + "p" * 22
AWAKE_ID = "UC" + "a" * 22
BONITAS_ID = "UC" + "b" * 22
EXTRA_ID = "UC" + "e" * 22

# account_menu chỉ thấy kênh đang active (Awake) — thiếu Bonitas + kênh chính.
MENU_DATA = {
    "multiPageMenuRenderer": {
        "sections": [
            {
                "accountItemSectionRenderer": {
                    "contents": [
                        {
                            "accountItemRenderer": {
                                "accountId": AWAKE_ID,
                                "accountName": {"simpleText": "Awake in the Dark"},
                                "channelHandle": {"simpleText": "@AwakeInTheDarkSeries"},
                                "accountByline": {"simpleText": "@AwakeInTheDarkSeries"},
                            }
                        }
                    ]
                }
            }
        ]
    }
}


class FakeClient:
    def __init__(self):
        self.navigated = []

    def navigate(self, url):
        self.navigated.append(url)

    def evaluate(self, expression, timeout=None):
        if "readyState" in expression:
            return "complete"
        if "LOGGED_IN" in expression:
            return {"loggedIn": True, "href": "https://www.youtube.com/"}
        if "ccd:menu" in expression:
            return {"ok": True, "status": 200, "data": MENU_DATA}
        if "ccd:panel" in expression:
            return {
                "ok": True,
                "accountName": "Shin Ryujin",
                "email": "23shinryujin@gmail.com",
                "items": [
                    "Shin Ryujin\n@shinryujin9478\nNo subscribers",
                    "Awake in the Dark\n@AwakeInTheDarkSeries\nNo subscribers",
                    "Bonitas Viejitas 70s 80s 90s\n@LatinPop202x\n43 subscribers",
                ],
            }
        if "ccd:switcher" in expression:
            return {
                "ok": True,
                "entries": [
                    {"href": f"/channel/{PERSONAL_ID}", "text": "Shin Ryujin\n@shinryujin9478"},
                    {"href": "/@LatinPop202x", "text": "Bonitas Viejitas 70s 80s 90s\n@LatinPop202x • 43 subscribers"},
                    {"href": f"/channel/{EXTRA_ID}", "text": "Extra Brand\n@ExtraBrand • 9 subscribers"},
                ],
            }
        if "ccd:resolve" in expression:
            if "shinryujin9478" in expression:
                return {"channelId": PERSONAL_ID, "videoCount": "0"}
            if "LatinPop202x" in expression:
                return {"channelId": BONITAS_ID, "videoCount": "57"}
            return {"channelId": None, "videoCount": None}
        return None

    def close(self):
        pass


class FakeManager:
    def __init__(self, client):
        self.client = client

    def launch(self, profile):
        return "already_running"

    def connect_page(self, profile):
        return self.client


def test_scan_merges_all_sources_and_drops_personal_channel(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("shin", "23shinryujin@gmail.com")
    logs: list[str] = []
    result = scanner.scan_profile(
        store, profile, FakeManager(FakeClient()), log=logs.append
    )
    assert result["status"] == "ok"
    ids = {c["channel_id"] for c in result["channels"]}
    # Đủ 3 kênh thương hiệu từ 3 nguồn khác nhau...
    assert ids == {AWAKE_ID, BONITAS_ID, EXTRA_ID}
    # ...và kênh chính cá nhân bị loại dù xuất hiện ở 2 nguồn.
    assert PERSONAL_ID not in ids
    names = {c["channel_id"]: c["name"] for c in result["channels"]}
    assert names[BONITAS_ID] == "Bonitas Viejitas 70s 80s 90s"
    assert "bỏ qua kênh chính cá nhân 'Shin Ryujin'" in "\n".join(logs)
    saved = store.list_channels(profile["id"])
    assert {c["channel_id"] for c in saved} == {AWAKE_ID, BONITAS_ID, EXTRA_ID}
    store.close()


def test_parse_switcher_entries_ids_handles_dedupe():
    entries = [
        {"href": f"/channel/{AWAKE_ID}", "text": "Awake in the Dark\n@AwakeInTheDarkSeries"},
        {"href": "/@LatinPop202x", "text": "Bonitas Viejitas 70s 80s 90s\n@LatinPop202x • 43 subscribers"},
        {"href": "/@LatinPop202x", "text": "Bonitas Viejitas 70s 80s 90s"},
        {"href": "/watch?v=abc", "text": "không phải kênh"},
        {"href": "/feed/subscriptions", "text": ""},
    ]
    records = parser.parse_switcher_entries(entries)
    assert len(records) == 2
    by_handle = {r["handle"]: r for r in records}
    assert by_handle["@AwakeInTheDarkSeries"]["channel_id"] == AWAKE_ID
    assert by_handle["@LatinPop202x"]["subs"] == 43


def test_merge_channel_records_fills_missing_fields():
    from_json = {
        "channel_id": AWAKE_ID, "name": "Awake in the Dark",
        "handle": "@AwakeInTheDarkSeries",
        "url": "https://www.youtube.com/@AwakeInTheDarkSeries",
        "subs": None, "video_count": None, "niche": "",
    }
    from_panel = {
        "channel_id": "", "name": "Awake in the Dark",
        "handle": "@AwakeInTheDarkSeries",
        "url": "https://www.youtube.com/@AwakeInTheDarkSeries",
        "subs": 12, "video_count": None, "niche": "",
    }
    merged = parser.merge_channel_records([from_json, from_panel])
    assert len(merged) == 1
    assert merged[0]["channel_id"] == AWAKE_ID
    assert merged[0]["subs"] == 12


def test_exclude_personal_channel_drops_at_most_one():
    records = [
        {"channel_id": PERSONAL_ID, "name": "Shin Ryujin", "handle": "@shinryujin9478"},
        {"channel_id": AWAKE_ID, "name": "Awake in the Dark", "handle": "@AwakeInTheDarkSeries"},
        {"channel_id": EXTRA_ID, "name": "Shin Ryujin", "handle": "@ShinRyujinBrand"},
    ]
    kept, dropped = parser.exclude_personal_channel(records, "Shin Ryujin")
    assert dropped["channel_id"] == PERSONAL_ID
    # Kênh thương hiệu trùng tên (bản ghi thứ hai khớp tên) vẫn được giữ.
    assert {c["channel_id"] for c in kept} == {AWAKE_ID, EXTRA_ID}
    kept2, dropped2 = parser.exclude_personal_channel(records, "")
    assert dropped2 is None and len(kept2) == 3
