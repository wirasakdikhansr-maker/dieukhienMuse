"""V5.1 — bản thiết kế lại theo phương án duyệt 2026-10-30
(UI_V51_DESIGN_PLAN.md).

Khoá:
1) KỶ NGUYÊN GIAO DIỆN: settings GIẢ LẬP MÁY THẬT của anh (token
   Concept D lệch + cỡ chữ/bán kính đã drift, KHÔNG có khoá epoch)
   — cơ chế cũ migrate_saved_tokens GIỮ NGUYÊN (đây là dữ kiện đỏ
   của sự cố "UI không đổi"), còn apply_theme_epoch áp token V5.1
   + sao lưu đúng giá trị cũ; khôi phục trả lại ĐÚNG giá trị cũ;
   lần gọi thứ hai không ghi đè (tôn trọng tuỳ biến sau epoch).
2) Panel chi tiết Văn phòng dựng lại: header cố định KHÔNG nằm
   trong vùng cuộn, khối chat ghim NGOÀI vùng cuộn ở đáy panel,
   không còn 2 nút nhảy mục, chọn agent thì header + thanh tiến
   độ điền đúng.
3) Công việc dạng thẻ: thẻ kênh tồn tại, chọn kênh → hàng đợi
   theo kênh, dòng thường trực trên thẻ.
4) Tự động dạng thẻ: thẻ quy tắc + Chạy ngay tạo lệnh thật qua
   engine (kể cả quy tắc đang tắt).
"""

import dataclasses
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from app import config  # noqa: E402
from app.ui import theme  # noqa: E402
from app.automation import AutomationEngine  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402


# --------------------------------------------------------------------------- #
# 1) Theme epoch
# --------------------------------------------------------------------------- #
def _flat(tokens) -> dict:
    return {f.name: getattr(tokens, f.name) for f in dataclasses.fields(tokens)}


def _real_machine_like_settings() -> dict:
    """Settings như máy thật của anh sau nhiều bản: token Concept D
    + vài trường đã drift (cỡ chữ, bán kính, màu) — bộ token KHÔNG
    khớp tuyệt đối bất kỳ bộ gốc nào nên cơ chế di trú cũ coi là
    'đã tuỳ biến' và giữ nguyên (sự cố 'UI không đổi')."""
    tokens = _flat(theme.CONCEPT_D_TOKENS)
    tokens["font_scale"] = 1.15
    tokens["radius"] = 22
    tokens["accent"] = "#3B82C4"
    return {"theme_tokens": tokens, "theme_preset": "mission"}


def test_old_mechanism_keeps_drifted_settings_red_baseline():
    """Dữ kiện ĐỎ của sự cố: cơ chế cũ (khớp tuyệt đối) giữ nguyên
    bộ token đã drift — đây là lý do V5.0 không đổi UI trên máy
    thật. Pin này cố ý giữ hành vi đó để đối chứng với epoch."""
    settings = _real_machine_like_settings()
    migrated = theme.migrate_saved_tokens(settings["theme_tokens"])
    assert migrated.bg == theme.CONCEPT_D_TOKENS.bg  # vẫn xanh dương cũ
    assert migrated.accent == "#3B82C4"


def test_epoch_applies_v51_unconditionally_and_backs_up():
    settings = _real_machine_like_settings()
    drifted = dict(settings["theme_tokens"])
    tokens, changed = theme.apply_theme_epoch(settings)
    assert changed is True
    assert tokens.bg == "#0C0D0F"
    assert tokens.panel == "#16171B"
    assert tokens.accent == "#CEFC19"
    assert settings["theme_epoch"] == theme.THEME_EPOCH_CURRENT
    assert settings["theme_tokens"]["bg"] == "#0C0D0F"
    # Sao lưu = ĐÚNG giá trị cũ (token đã drift).
    assert settings["theme_backup_pre_v51"] == drifted


def test_epoch_second_run_respects_user_customisation():
    settings = _real_machine_like_settings()
    theme.apply_theme_epoch(settings)
    # Sau epoch anh tự đổi màu nhấn → lần chạy sau phải tôn trọng.
    custom = _flat(theme.METAMINT_TOKENS)
    custom["accent"] = "#FF00AA"
    settings["theme_tokens"] = custom
    tokens, changed = theme.apply_theme_epoch(settings)
    assert changed is False
    assert tokens.accent == "#FF00AA"


def test_epoch_restore_returns_exact_old_values():
    settings = _real_machine_like_settings()
    drifted = dict(settings["theme_tokens"])
    theme.apply_theme_epoch(settings)
    restored = theme.restore_theme_backup(settings)
    assert restored is not None
    assert _flat(restored)["bg"] == drifted["bg"]
    assert _flat(restored)["accent"] == "#3B82C4"
    assert _flat(restored)["font_scale"] == 1.15
    assert settings["theme_tokens"] == drifted


def test_epoch_apply_v51_again():
    settings = _real_machine_like_settings()
    theme.apply_theme_epoch(settings)
    theme.restore_theme_backup(settings)
    tokens = theme.apply_v51_theme(settings)
    assert tokens.bg == "#0C0D0F"
    # Sao lưu KHÔNG bị ghi đè khi áp lại.
    assert settings["theme_backup_pre_v51"]["accent"] == "#3B82C4"


def test_epoch_fresh_install_no_backup_needed():
    settings: dict = {}
    tokens, changed = theme.apply_theme_epoch(settings)
    assert changed is True
    assert tokens.bg == "#0C0D0F"
    assert settings.get("theme_backup_pre_v51") in (None, {})
    # Khôi phục khi không có sao lưu → None, không sập.
    assert theme.restore_theme_backup(settings) is None


# --------------------------------------------------------------------------- #
# Fixtures cho các test giao diện
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    from app.ui.main_window import MainWindow

    win = MainWindow(store, ChromeManager(), settings)
    yield win, store
    win.close()
    store.close()


# --------------------------------------------------------------------------- #
# 2) Panel chi tiết Văn phòng dựng lại
# --------------------------------------------------------------------------- #
def test_detail_panel_structure(window):
    win, _store = window
    panel = win.office_panel
    # Header cố định: KHÔNG nằm trong vùng cuộn; vùng cuộn chứa
    # thân chi tiết; khối chat ghim NGOÀI vùng cuộn ở đáy panel.
    assert panel.detail_scroll.isAncestorOf(panel.detail_box)
    assert panel.header_widget.parent() is panel.detail_panel
    assert not panel.detail_scroll.isAncestorOf(panel.chat_widget)
    assert not panel.detail_scroll.isAncestorOf(panel.header_widget)
    # Ô soạn chat nằm trong khối chat ghim đáy (không cuộn theo).
    assert panel.chat_widget.isAncestorOf(panel.chat_widget.composer)
    # Nhãn "CHI TIẾT AGENT" + 2 nút nhảy mục đã bỏ (plan §2.1).
    assert not hasattr(panel, "btn_commands")
    assert not hasattr(panel, "btn_agents")
    from PySide6.QtWidgets import QLabel

    texts = [w.text() for w in panel.findChildren(QLabel)]
    assert "CHI TIẾT AGENT" not in texts


def test_detail_panel_select_fills_header_and_progress(window):
    win, store = window
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse Làm", "lam@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    store.touch_agent_heartbeat(agent["id"], "")
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="waiting_muse",
        instruction="Tải video mới",
    )
    store.claim_claude_command(cmd["id"], agent["id"], 120)
    store.update_command_progress(
        cmd["id"], progress=72, step="Đang tối ưu", agent_id=agent["id"]
    )
    win.office_panel.refresh()
    win.office_panel.select_agent(agent["id"])
    panel = win.office_panel
    assert "Muse Làm" in panel.name_label.text()
    # Mail nằm ở dòng phụ của header (cùng dòng trạng thái Online).
    assert "lam@claude.ai" in panel.agent_status_label.text()
    assert panel.cur_bar.value() == 72
    assert panel.cur_progress.text() == "72%"
    # Pill trạng thái ở header (không còn dòng chữ thường).
    assert panel.state_label.property("state") in ("run", "in")


# --------------------------------------------------------------------------- #
# 3) Công việc dạng thẻ + 4) Tự động dạng thẻ
# --------------------------------------------------------------------------- #
def _board_world(tmp_path):
    from app import assignments

    store = Store(tmp_path / "board.db")
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.touch_agent_heartbeat(agent["id"])
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UCpip123",
            "name": "Pip Survives",
            "handle": "@PipSurvivesShow",
        },
    )
    channel = store.list_channels(profile["id"])[0]
    base = tmp_path / "data"
    assignments.save_checklist(str(channel["id"]), ["tao-video-moi"], None, base)
    return store, agent, profile, channel, base


def test_agent_board_cards(qapp, tmp_path):
    from app.ui import work_model
    from app.ui.agent_board import AgentBoardWidget

    store, _agent, _profile, channel, base = _board_world(tmp_path)
    board = AgentBoardWidget(store, base)
    model = work_model.build_work_model(
        store.list_commands(limit=500),
        store.list_agents(),
        store.list_profiles(),
        {p["id"]: store.list_channels(p["id"]) for p in store.list_profiles()},
    )
    board.set_model(model)
    card = board.channel_card(str(channel["id"]))
    assert card is not None  # thẻ kênh tồn tại (không còn cây trần)
    assert not hasattr(board, "tree")
    assert "Thường trực: 1 mục" in card.standing_label.text()
    assert board.select_channel(str(channel["id"]))
    assert board._selected_channel_key == str(channel["id"])
    board.deleteLater()
    store.close()


def test_automation_cards_and_run_now(qapp, tmp_path):
    from app.ui.automation_panel import AutomationPanel

    store = Store(tmp_path / "auto.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    rule = store.add_rule(
        "scan",
        profile_id=profile["id"],
        schedule_kind="daily",
        daily_time="08:00",
        enabled=False,  # tắt — Chạy ngay vẫn phải bắn được
    )
    notes: list[str] = []
    panel = AutomationPanel(store, {}, notify=notes.append)
    panel.refresh()
    assert len(panel.rule_cards) == 1
    card = panel.rule_cards[0]
    assert card.rule_id == rule["id"]
    # Chạy ngay qua engine tạo đúng 1 lệnh cho hồ sơ đích.
    panel._on_run_rule_now(rule["id"])
    commands = store.list_commands(limit=50)
    assert len(commands) == 1
    assert commands[0]["type"] == "scan"
    assert commands[0]["source"] == "auto"
    panel.deleteLater()
    store.close()


def test_automation_engine_run_rule_now_direct(tmp_path):
    store = Store(tmp_path / "auto2.db")
    profile = store.add_profile("Kenh B", "b@gmail.com")
    rule = store.add_rule(
        "check",
        profile_id=profile["id"],
        schedule_kind="interval",
        interval_hours=6,
        enabled=True,
    )
    engine = AutomationEngine(store)
    created = engine.run_rule_now(rule["id"])
    assert len(created) == 1
    assert engine.run_rule_now(99999) == []  # quy tắc không tồn tại
    store.close()
