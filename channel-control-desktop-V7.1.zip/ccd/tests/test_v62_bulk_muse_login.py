"""V6.2 — đăng nhập hàng loạt muse.ai qua hộp thư tinyhost.shop."""

import pytest

from app import cdp, muse_autologin as ml


def test_split_address():
    assert ml.split_address(" Abc@Mail.Example.com ") == ("abc", "mail.example.com")
    with pytest.raises(ValueError):
        ml.split_address("khong-phai-email")


@pytest.mark.parametrize(
    "text,code",
    [
        ("Your verification code is 482913", "482913"),
        ("482913 is your Muse login code", "482913"),
        ("Muse code: 039211 sent 2026-10-31 08:12", "039211"),
        ("Mã xác nhận của bạn là 771204", "771204"),
        ("Hello world 2026", None),
        ("Received 10/31/2026 08:12 from noreply", None),
    ],
)
def test_extract_code(text, code):
    assert ml.extract_code(text) == code


def test_pick_new_code_ignores_old_mail_and_old_codes():
    old = {"id": 1, "subject": "Your Muse code is 111111"}
    new = {"id": 2, "subject": "Your Muse code is 222222"}
    seen = {ml._mail_key(old)}
    assert ml.pick_new_code([old], seen) is None
    assert ml.pick_new_code([old, new], seen) == "222222"
    # Dòng bảng đổi chữ nhưng vẫn là mã cũ -> bỏ qua.
    reworded = {"subject": "Muse · 1 minute ago · Your code is 111111"}
    assert ml.pick_new_code([reworded], seen, {"111111"}) is None


class FakeWorld:
    """Mô phỏng muse.ai + tinyhost: muse đi email -> code -> in."""

    def __init__(self, split_boxes=0):
        self.muse_stage = "email"
        self.mails = [{"id": 1, "subject": "Your Muse code is 111111", "sender": "Muse"}]
        self.filled = {}
        self.clicks = []
        self.closed_browser = False
        self.closed_tabs = []
        self.split_boxes = split_boxes
        self.targets = [
            {"id": "muse-tab", "type": "page", "url": "https://muse.ai/", "webSocketDebuggerUrl": "ws://muse"},
        ]

    # --- trang
    def evaluate(self, tab_id, js):
        if js == ml.READY_JS:
            return "complete"
        if "ccd:al-muse-state" in js:
            if self.muse_stage == "email":
                return {"hasEmail": True, "codeCount": 0, "url": "https://muse.ai/"}
            if self.muse_stage == "code":
                return {"hasEmail": False, "codeCount": self.split_boxes or 1, "askCode": True}
            return {"hasEmail": False, "codeCount": 0, "hasComposer": True, "url": "https://muse.ai/chat"}
        if "ccd:al-mark-button" in js:
            if tab_id == "muse-tab":
                if "continue" in js and self.muse_stage == "email":
                    return "Continue"
                if "verify" in js and self.muse_stage == "code":
                    return "Continue"
                return None
            if "check" in js:
                return "Check Inbox"
            return None
        if "ccd:al-tinyhost-prepare" in js:
            return {"ok": True, "mode": "full", "value": "abc@tiny.example"}
        if "ccd:al-tinyhost-api" in js:
            return list(self.mails)
        if "ccd:al-tinyhost-rows" in js:
            return {"rows": [], "extra": []}
        return None

    def click(self, tab_id, selector):
        self.clicks.append((tab_id, selector))
        if tab_id == "muse-tab" and "muse-continue" in selector:
            self.muse_stage = "code"
            self.mails.insert(0, {"id": 2, "subject": "Your Muse code is 222222", "sender": "Muse"})
        if tab_id == "muse-tab" and "muse-submit" in selector:
            code = "".join(v for k, v in sorted(self.filled.items()) if k.startswith("muse-code"))
            if code == "222222":
                self.muse_stage = "in"

    def fill(self, tab_id, selector, value):
        key = selector.split('"')[1]
        self.filled[key] = value


class FakeClient:
    def __init__(self, world, tab_id):
        self.world, self.tab_id = world, tab_id

    def evaluate(self, js, timeout=None):
        return self.world.evaluate(self.tab_id, js)

    def click_element(self, selector=None, text=None):
        self.world.click(self.tab_id, selector)

    def fill_element(self, selector, text):
        self.world.fill(self.tab_id, selector, text)

    def press_key(self, key):
        pass

    def navigate(self, url):
        pass

    def bring_to_front(self):
        pass

    def close(self):
        pass


class FakeManager:
    def __init__(self):
        self.launched = []

    def launch(self, profile, start_minimized=None):
        self.launched.append(profile["slug"])
        return "launched"


def _install(monkeypatch, world, tmp_path):
    monkeypatch.setattr("app.config.data_dir", lambda: tmp_path)

    def http_json(port, path, method="GET", timeout=3.0):
        if path == "/json/list":
            return list(world.targets)
        if path.startswith("/json/new?"):
            target = {"id": "mail-tab", "type": "page", "url": path[len("/json/new?"):],
                      "webSocketDebuggerUrl": "ws://mail"}
            world.targets.append(target)
            return target
        if path.startswith("/json/close/"):
            world.closed_tabs.append(path.rsplit("/", 1)[1])
            return {}
        raise AssertionError(path)

    def browser_call(port, method, params=None, timeout=15.0):
        if method == "Browser.close":
            world.closed_browser = True
        return {}

    monkeypatch.setattr(cdp, "http_json", http_json)
    monkeypatch.setattr(cdp, "browser_call", browser_call)


def _runner(world, agent, cls=None, **kw):
    now = [0.0]

    def sleep(s):
        now[0] += max(s, 0.01)

    def factory(ws, reconnect):
        return FakeClient(world, "muse-tab" if ws == "ws://muse" else "mail-tab")

    return (cls or ml.MuseAutoLogin)(
        FakeManager(), agent, sleep=sleep, clock=lambda: now[0],
        tab_factory=factory, http_get=lambda url: {"emails": []}, **kw
    )


@pytest.mark.parametrize("boxes", [0, 6])
def test_full_flow_logs_in_with_new_code(monkeypatch, tmp_path, boxes):
    world = FakeWorld(split_boxes=boxes)
    _install(monkeypatch, world, tmp_path)
    result = _runner(world, {"id": 7, "name": "Muse 7", "email": "abc@tiny.example"}).run()
    assert result["status"] == "ok", result
    code = "".join(v for k, v in sorted(world.filled.items()) if k.startswith("muse-code"))
    assert code == "222222"  # không lấy nhầm mã cũ 111111
    assert world.filled["muse-email"] == "abc@tiny.example"
    assert world.filled["th-email"] == "abc@tiny.example"
    assert "mail-tab" in world.closed_tabs
    assert world.closed_browser


def test_already_logged_in_skips(monkeypatch, tmp_path):
    world = FakeWorld()
    world.muse_stage = "in"
    _install(monkeypatch, world, tmp_path)
    result = _runner(world, {"id": 8, "name": "M", "email": "x@tiny.example"}).run()
    assert result["status"] == "already"
    assert not world.filled


def test_no_code_times_out_and_keeps_window(monkeypatch, tmp_path):
    world = FakeWorld()
    _install(monkeypatch, world, tmp_path)
    orig = world.click

    def click_no_mail(tab_id, selector):
        orig(tab_id, selector)
        world.mails = [m for m in world.mails if m["id"] != 2]

    world.click = click_no_mail
    result = _runner(world, {"id": 9, "name": "M", "email": "y@tiny.example"},
                     timeouts={"code_mail": 20, "resend_after": 10}).run()
    assert result["status"] == "no_code"
    assert not world.closed_browser


def test_run_batch_reports_each_and_stops(monkeypatch, tmp_path):
    world = FakeWorld()
    world.muse_stage = "in"
    _install(monkeypatch, world, tmp_path)
    seen = []
    agents = [{"id": 1, "name": "a", "email": "a@tiny.example"},
              {"id": 2, "name": "b", "email": "bad-email"}]
    real = ml.MuseAutoLogin
    monkeypatch.setattr(ml, "MuseAutoLogin", lambda manager, agent, **kw: _runner(world, agent, cls=real))
    results = ml.run_batch(FakeManager(), agents, on_result=lambda a, r: seen.append(r["status"]),
                           sleep=lambda s: None)
    assert seen == ["already", "error"]
    assert ml.run_batch(FakeManager(), agents, should_stop=lambda: True) == []


def test_bulk_dialog_prefills_logged_out_agents(qtbot=None):
    pytest.importorskip("PySide6")
    import os
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from app.ui.agents_panel import BulkMuseLoginDialog

    class S:
        def list_agents(self):
            return [
                {"name": "A", "email": "a@t.example", "web_state": "out", "revoked": False},
                {"name": "B", "email": "b@t.example", "web_state": "in", "revoked": False},
            ]

    dialog = BulkMuseLoginDialog(S())
    entries = dialog.entries()
    assert [e["email"] for e in entries] == ["a@t.example"]
    assert dialog.options() == {"add_missing": True, "close_on_success": True}
    assert app is not None
