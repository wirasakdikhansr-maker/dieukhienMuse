"""Kiểm thử kho dữ liệu (Store) và suy diễn slug/cổng (config)."""

import pytest

from app import config
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "test.sqlite3")
    yield s
    s.close()


def test_slugify_vietnamese_and_spaces():
    assert config.slugify("Kênh Kiểm Tiền") == "kenh-kiem-tien"
    assert config.slugify("AwakeInTheDark") == "awakeinthedark"
    assert config.slugify("Bonitas Viejitas 70s") == "bonitas-viejitas-70s"
    assert config.slugify("  --Lạ--  ") == "la"
    assert config.slugify("") == "profile"


def test_port_is_deterministic():
    slug = "awakeinthedark"
    assert config.port_for_slug(slug) == config.port_for_slug(slug)
    assert config.PORT_BASE <= config.port_for_slug(slug) < config.PORT_BASE + config.PORT_SPAN


def test_add_profile_assigns_slug_and_port(store):
    p = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com", "kênh chính")
    assert p["slug"] == "awakeinthedark"
    assert p["port"] == config.port_for_slug("awakeinthedark")
    assert p["gmail"] == "23shinryujin@gmail.com"
    assert p["paused"] is False
    assert store.get_profile(p["id"])["label"] == "AwakeInTheDark"
    assert store.get_profile_by_slug("awakeinthedark")["id"] == p["id"]


def test_add_profile_duplicate_label_gets_unique_slug_and_port(store):
    a = store.add_profile("Test", "a@gmail.com")
    b = store.add_profile("Test", "b@gmail.com")
    assert a["slug"] == "test"
    assert b["slug"] == "test-2"
    assert a["port"] != b["port"]
    assert [p["label"] for p in store.list_profiles()] == ["Test", "Test"]


def test_pause_toggle(store):
    p = store.add_profile("P", "p@gmail.com")
    store.set_profile_paused(p["id"], True)
    assert store.get_profile(p["id"])["paused"] is True
    store.set_profile_paused(p["id"], False)
    assert store.get_profile(p["id"])["paused"] is False


def _channel(cid, name, subs, videos=None, niche=""):
    return {
        "channel_id": cid,
        "name": name,
        "handle": "@" + name.replace(" ", ""),
        "url": f"https://www.youtube.com/channel/{cid}",
        "subs": subs,
        "video_count": videos,
        "niche": niche,
    }


def test_upsert_channel_create_then_update_no_duplicates(store):
    p = store.add_profile("P", "p@gmail.com")
    assert store.upsert_channel(p["id"], _channel("UC111", "Kênh Một", 10, 3)) is True
    assert store.upsert_channel(p["id"], _channel("UC222", "Kênh Hai", 20)) is True
    # Quét lại: cập nhật số liệu, không tạo trùng
    assert store.upsert_channel(p["id"], _channel("UC111", "Kênh Một", 15, 4)) is False
    channels = store.list_channels(p["id"])
    assert len(channels) == 2
    first = [c for c in channels if c["channel_id"] == "UC111"][0]
    assert first["subs"] == 15 and first["video_count"] == 4
    assert first["last_scan_at"]


def test_upsert_channel_preserves_video_count_and_niche_when_missing(store):
    p = store.add_profile("P", "p@gmail.com")
    store.upsert_channel(p["id"], _channel("UC111", "Kênh", 10, 7, niche="nhạc Latin"))
    store.upsert_channel(p["id"], _channel("UC111", "Kênh", 11, None, niche=""))
    ch = store.list_channels(p["id"])[0]
    assert ch["subs"] == 11
    assert ch["video_count"] == 7  # không bị xoá bởi giá trị None
    assert ch["niche"] == "nhạc Latin"


def test_upsert_channel_requires_channel_id(store):
    p = store.add_profile("P", "p@gmail.com")
    with pytest.raises(ValueError):
        store.upsert_channel(p["id"], {"name": "thiếu id"})


def test_channels_are_scoped_per_profile(store):
    a = store.add_profile("A", "a@gmail.com")
    b = store.add_profile("B", "b@gmail.com")
    store.upsert_channel(a["id"], _channel("UC111", "Kênh", 1))
    store.upsert_channel(b["id"], _channel("UC111", "Kênh", 2))
    assert store.list_channels(a["id"])[0]["subs"] == 1
    assert store.list_channels(b["id"])[0]["subs"] == 2


def test_journal_append_and_read_order(store):
    p = store.add_profile("P", "p@gmail.com")
    store.append_journal("dòng toàn cục")
    store.append_journal("dòng của P", p["id"])
    store.append_journal("dòng thứ hai của P", p["id"])
    all_lines = store.list_journal()
    assert [e["message"] for e in all_lines] == ["dòng toàn cục", "dòng của P", "dòng thứ hai của P"]
    scoped = store.list_journal(profile_id=p["id"])
    assert [e["message"] for e in scoped] == ["dòng toàn cục", "dòng của P", "dòng thứ hai của P"]
    assert scoped[0]["profile_id"] is None
    assert scoped[1]["profile_id"] == p["id"]
    assert all(e["ts"] for e in scoped)


def test_mark_profile_scanned(store):
    p = store.add_profile("P", "p@gmail.com")
    assert p["last_scan_at"] is None
    store.mark_profile_scanned(p["id"], "2026-10-27T23:00:00+07:00")
    assert store.get_profile(p["id"])["last_scan_at"] == "2026-10-27T23:00:00+07:00"
