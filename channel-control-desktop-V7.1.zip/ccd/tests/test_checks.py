"""Kiểm thử V3 cho định hình kết quả kiểm tra (checks.build_check_items)
và một lượt chạy kiểm tra đầy đủ với Chrome giả (stub)."""

from app import checks
from app.store import Store


def probes(**overrides):
    base = {
        "chrome_running": True,
        "cdp_ok": True,
        "logged_in": True,
        "channels": [
            {"channel_id": "UC1", "name": "Awake in the Dark"},
            {"channel_id": "UC2", "name": "Bonitas Viejitas 70s 80s 90s"},
        ],
        "last_scan_at": "2026-10-28T06:00:00+07:00",
        "scheduled_videos": [],
        "videos_known": False,
    }
    base.update(overrides)
    return base


def by_key(items):
    return {item["key"]: item for item in items}


def test_all_ok_shape():
    from datetime import datetime, timedelta, timezone

    now = datetime(2026, 10, 28, 7, 0, tzinfo=timezone(timedelta(hours=7)))
    items = checks.build_check_items(probes(), now=now)
    shaped = by_key(items)
    assert shaped["chrome"]["status"] == "ok"
    assert shaped["cdp"]["status"] == "ok"
    assert shaped["login"]["status"] == "ok"
    assert shaped["channels"]["status"] == "ok"
    assert "2 kênh" in shaped["channels"]["detail"]
    assert shaped["last_scan"]["status"] == "ok"
    # Chưa có dữ liệu từng video -> scheduled là 'na' chứ không kết luận bừa.
    assert shaped["scheduled"]["status"] == "na"
    summary = checks.summarize_items(items)
    assert summary.startswith("5 đạt")


def test_chrome_down_cascades_to_na():
    items = checks.build_check_items(
        probes(chrome_running=False, cdp_ok=None, logged_in=None)
    )
    shaped = by_key(items)
    assert shaped["chrome"]["status"] == "fail"
    assert shaped["cdp"]["status"] == "na"
    assert shaped["login"]["status"] == "na"


def test_not_logged_in_is_fail():
    items = checks.build_check_items(probes(logged_in=False))
    assert by_key(items)["login"]["status"] == "fail"


def test_stale_scan_and_scheduled_videos():
    from datetime import datetime, timedelta, timezone

    now = datetime(2026, 10, 30, 7, 0, tzinfo=timezone(timedelta(hours=7)))
    items = checks.build_check_items(
        probes(
            scheduled_videos=[{"video_id": "V1"}, {"video_id": "V2"}],
            videos_known=True,
        ),
        now=now,
    )
    shaped = by_key(items)
    assert shaped["last_scan"]["status"] == "fail"  # quá 24 giờ
    assert shaped["scheduled"]["status"] == "ok"
    assert "2 video" in shaped["scheduled"]["detail"]


def test_never_scanned_channels_na():
    items = checks.build_check_items(probes(channels=[], last_scan_at=None))
    shaped = by_key(items)
    assert shaped["channels"]["status"] == "na"
    assert shaped["last_scan"]["status"] == "na"


class FakeManager:
    def __init__(self, running=True):
        self._running = running

    def is_running(self, profile):
        return self._running


def test_run_profile_checks_with_stub_manager(tmp_path, monkeypatch):
    store = Store(tmp_path / "test.sqlite3")
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1",
            "name": "Awake in the Dark",
            "handle": "@AwakeInTheDarkSeries",
            "url": "https://www.youtube.com/channel/UC1",
            "subs": 0,
            "video_count": 6,
        },
    )
    # CDP không thật sự có -> cdp_ok False, login None (không gọi mạng thật).
    import app.cdp as cdp_module

    monkeypatch.setattr(cdp_module, "http_json", lambda *a, **k: (_ for _ in ()).throw(OSError("no")))
    saved = checks.run_profile_checks(store, profile, FakeManager(running=True))
    shaped = by_key(saved["items"])
    assert shaped["chrome"]["status"] == "ok"
    assert shaped["cdp"]["status"] == "fail"
    assert shaped["login"]["status"] == "na"
    assert shaped["channels"]["status"] == "ok"
    # Kết quả đã được lưu vào kho.
    assert store.get_last_check(profile["id"])["id"] == saved["id"]
    store.close()
