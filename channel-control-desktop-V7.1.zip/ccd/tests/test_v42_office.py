"""V4.2 — Văn phòng: agent thứ 9+ xem được chi tiết (O-25), hàng
đợi "Tiếp theo" theo agent, vân dữ liệu bỏ dựng lại cảnh (O-09),
số tổng từ aggregate (O-07), thẻ hàng đợi có tên Muse + thời gian
chờ (O-11).
"""

from datetime import datetime, timedelta

import pytest
from PySide6.QtWidgets import QApplication

from app import config
from app.store import Store
from app.ui import office_scene
from app.ui.office_view import OfficeView


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _seed_agents(store, count):
    agents = []
    for i in range(count):
        agent = store.create_agent(f"Muse {i + 1}", f"c{i + 1}@claude.ai")
        profile = store.add_profile(f"Kenh {i + 1}", f"k{i + 1}@gmail.com")
        store.assign_profiles(agent["id"], [profile["id"]])
        agents.append((agent, profile))
    return agents


def test_scene_model_has_all_desks_and_waiting_next():
    now = datetime.now().astimezone()
    agents = [
        {
            "id": i + 1, "name": f"Muse {i + 1}", "email": f"c{i+1}@x.ai",
            "status": "online", "revoked": False,
            "profile_ids": [100 + i], "current_command_id": None,
        }
        for i in range(9)
    ]
    commands = []
    # Agent 1: 1 đang chạy + 3 đang chờ (thứ tự dispatcher: ui cũ trước).
    base = {"profile_id": 100, "profile_slug": "kenh-1", "agent_id": 1}
    commands.append({
        **base, "id": "run1", "type": "optimize", "status": "running",
        "source": "ui", "progress": 40, "step": "", "instruction": "đang làm",
        "created_at": (now - timedelta(minutes=30)).isoformat(), "_seq": 1,
        "lease_expires_at": (now + timedelta(seconds=90)).isoformat(),
        "lease_agent_id": 1, "finished_at": None,
    })
    for n, (source, minutes) in enumerate((("api", 20), ("ui", 10), ("ui", 25))):
        commands.append({
            **base, "id": f"wait{n}", "type": "upload",
            "status": "waiting_muse", "source": source, "progress": 0,
            "step": "", "instruction": f"việc {n}",
            "created_at": (now - timedelta(minutes=minutes)).isoformat(),
            "_seq": 10 + n, "lease_expires_at": None,
            "lease_agent_id": None, "finished_at": None,
        })
    model = office_scene.build_office_scene(agents, commands, {}, [], now=now)
    assert len(model["desks"]) == office_scene.MAX_DESKS
    assert len(model["desks_all"]) == 9
    desk1 = model["desks_all"][0]
    # ui cũ nhất (25') → ui (10') → api (20'): nguồn thắng thời gian.
    assert [v["id"] for v in desk1["waiting_next"]] == ["wait2", "wait1", "wait0"]
    assert desk1["current"]["lease_expires_at"] is not None
    queue_first = model["queue_board"][0]
    assert queue_first["agent_name"] == "Muse 1"
    assert queue_first["waiting_seconds"] is not None


def test_scene_counts_override_list_counts():
    now = datetime.now().astimezone()
    agents = [{
        "id": 1, "name": "Muse 1", "email": "c1@x.ai", "status": "online",
        "revoked": False, "profile_ids": [], "current_command_id": None,
    }]
    counts = {
        "queued": 300, "waiting_muse": 40, "running": 7,
        "needs_user": 3, "done_today": 55,
    }
    model = office_scene.build_office_scene(
        agents, [], {}, [], now=now, counts=counts
    )
    assert model["stats"]["queued_total"] == 340
    assert model["stats"]["running"] == 7
    assert model["stats"]["needs_user"] == 3
    assert model["stats"]["done_today"] == 55
    assert model["manager"]["queue_total"] == 340


def test_office_view_ninth_agent_detail_and_fingerprint(qapp, tmp_path):
    store = Store(config.db_path(tmp_path / "data.db"))
    try:
        pairs = _seed_agents(store, 9)
        ninth_agent, ninth_profile = pairs[8]
        cmd = store.create_command(
            "optimize", source="ui",
            profile_id=ninth_profile["id"],
            profile_slug=ninth_profile["slug"],
            status="waiting_muse",
        )
        view = OfficeView(store)
        view.show()  # isVisible() cần cửa sổ cha đang hiện
        # Bộ chọn agent chứa đủ 9 agent.
        assert view.agent_picker.count() == 9
        # Fingerprint: refresh không đổi dữ liệu → CÙNG các item cảnh
        # (không clear + dựng lại).
        items_before = list(view._scene.items())
        view.refresh()
        items_after = list(view._scene.items())
        assert items_before == items_after
        # Chọn agent thứ 9 (ngoài 8 bàn) → panel chi tiết hiện đúng.
        view.select_agent(ninth_agent["id"])
        assert view.detail_box.isVisible()
        assert "Muse 9" in view.name_label.text()
        # Đổi dữ liệu thật → refresh dựng lại cảnh.
        store.finish_command(cmd["id"], "done", result="xong")
        view.refresh()
        assert list(view._scene.items()) != items_after
        view.close()
    finally:
        store.close()
