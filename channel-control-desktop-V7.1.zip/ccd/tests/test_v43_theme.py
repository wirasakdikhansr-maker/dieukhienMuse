"""V4.3 — Theme tokens: build_qss / presets / brightness / (de)serialize.

QColor không cần QApplication; vẫn đặt offscreen cho chắc như các
test UI khác trong repo.
"""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import re
from dataclasses import replace

import pytest

pytest.importorskip("PySide6")

from PySide6.QtGui import QColor  # noqa: E402

from app.ui import theme  # noqa: E402
from app.ui.theme import (  # noqa: E402
    MISSION_TOKENS,
    PRESETS,
    adjust_brightness,
    build_qss,
    tokens_from_dict,
    tokens_to_dict,
)


def test_build_qss_mission_is_verbatim():
    # 1. Giao diện mặc định không đổi một ký tự. V4.5 (pin mới):
    # preset mặc định là 'metamint' và MISSION_TOKENS chính là bộ
    # mặc định đó; preset 'mission' giờ giữ bộ Concept D CŨ để
    # tương thích ngược cho người đã lưu theme.
    assert build_qss(MISSION_TOKENS) == theme.APP_QSS
    assert build_qss(PRESETS["metamint"]) == theme.APP_QSS
    assert PRESETS["mission"] == theme.CONCEPT_D_TOKENS


def test_tokens_roundtrip_and_from_dict_defaults():
    # 2. Round-trip mọi preset; None / dict thiếu trường vẫn hợp lệ.
    for preset in PRESETS.values():
        assert tokens_from_dict(tokens_to_dict(preset)) == preset
    assert tokens_from_dict(None) == MISSION_TOKENS
    assert tokens_from_dict("not-a-dict") == MISSION_TOKENS
    partial = tokens_from_dict({"bg": "#123456"})
    assert partial.bg == "#123456"
    assert partial.panel == MISSION_TOKENS.panel
    assert partial.radius == MISSION_TOKENS.radius
    # Trường lạ bị bỏ qua, số dạng chuỗi được ép kiểu an toàn.
    weird = tokens_from_dict({"unknown_field": 1, "radius": "14"})
    assert weird.radius == 14
    assert tokens_from_dict({"radius": "abc"}).radius == MISSION_TOKENS.radius


def test_build_qss_light_preset():
    # 3. Preset sáng: bg sáng có mặt, kết quả khác stylesheet mặc định.
    qss = build_qss(PRESETS["light"])
    assert "#F2F5FA" in qss
    assert qss != theme.APP_QSS


def test_adjust_brightness():
    # 4. factor 1.0 giữ màu; 1.5 sáng hơn; 0.5 tối hơn; rác trả nguyên.
    assert adjust_brightness("#22D3EE", 1.0) == "#22D3EE"
    assert adjust_brightness("#22d3ee", 1.0) == "#22D3EE"
    base = QColor("#808080").lightnessF()
    lighter = adjust_brightness("#808080", 1.5)
    darker = adjust_brightness("#808080", 0.5)
    assert QColor(lighter).lightnessF() > base
    assert QColor(darker).lightnessF() < base
    assert adjust_brightness("not-a-color", 1.5) == "not-a-color"


def test_font_scale_scales_font_sizes():
    # 5. font_scale 1.2: 13px -> 16px (làm tròn), khác APP_QSS.
    tokens = replace(MISSION_TOKENS, font_scale=1.2)
    qss = build_qss(tokens)
    assert "font-size: 16px" in qss
    assert qss != theme.APP_QSS


def test_radius_double_scales_border_radius():
    # 6. radius gấp đôi: giá trị border-radius tối đa tăng tương ứng.
    def max_radius(qss: str) -> int:
        return max(int(v) for v in re.findall(r"border-radius: (\d+)px", qss))

    tokens = replace(MISSION_TOKENS, radius=theme.DEFAULT_RADIUS * 2)
    qss = build_qss(tokens)
    assert max_radius(qss) > max_radius(theme.APP_QSS)
    assert max_radius(qss) == max_radius(theme.APP_QSS) * 2


def test_build_qss_keeps_important_object_names():
    # 7. Các objectName quan trọng không bị mất khi đổi preset.
    qss = build_qss(PRESETS["light"])
    for name in ("#HeaderBar", "#Panel", "#NavButton"):
        assert name in qss
