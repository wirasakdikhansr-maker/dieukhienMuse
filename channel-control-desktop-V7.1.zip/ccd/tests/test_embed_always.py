"""Kiểm thử tự-nhúng trình duyệt (V3.2): Chrome chạy là nhúng thẳng vào
giao diện — tick tự nhúng theo hồ sơ đang chọn, tôn trọng gỡ-tay, đổi
hồ sơ thì thu nhỏ cửa sổ cũ; tab mặc định là 'Trình duyệt nhúng'."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import config, docking  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui.main_window import (  # noqa: E402
    SEC_OVERVIEW,
    SEC_PROFILES,
    TAB_EMBED,
    TAB_STREAM,
    MainWindow,
)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _make_window(tmp_path, monkeypatch, embed=True):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["embed_browser_always"] = embed
    store = Store(config.db_path())
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    win = MainWindow(store, ChromeManager(), settings)
    win._current_profile_id = profile["id"]
    return win, store, profile


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    win, store, profile = _make_window(tmp_path, monkeypatch, embed=True)
    yield win, store, profile
    win.close()
    store.close()


def test_default_setting_is_embed_always():
    assert config.DEFAULT_SETTINGS["embed_browser_always"] is True


def test_minimize_window_guards():
    assert docking.minimize_window(None) is False
    if not docking.IS_WINDOWS:
        assert docking.minimize_window(12345) is False


def test_default_live_tab_is_embed_when_enabled(window):
    win, _store, _profile = window
    assert win.live_tabs.currentIndex() == TAB_EMBED
    assert win._embed_always() is True


def test_default_live_tab_is_stream_when_disabled(tmp_path, monkeypatch, qapp):
    win, store, _profile = _make_window(tmp_path, monkeypatch, embed=False)
    try:
        assert win.live_tabs.currentIndex() == TAB_STREAM
        assert win._embed_always() is False
    finally:
        win.close()
        store.close()


def test_auto_dock_tick_docks_running_profile(window, monkeypatch):
    win, _store, profile = window
    monkeypatch.setattr("app.docking.IS_WINDOWS", True)
    calls = []
    monkeypatch.setattr(win, "_try_dock", lambda quiet=False: calls.append(quiet))
    monkeypatch.setattr(win._manager, "is_running", lambda p: True)
    win.sections.setCurrentIndex(SEC_PROFILES)

    win._auto_dock_tick()
    assert calls == [True]  # nhúng thầm lặng

    # Người dùng đã gỡ tay -> tick không giành lại.
    win._embed_suppressed.add(profile["id"])
    win._auto_dock_tick()
    assert calls == [True]

    # Đang ở mục khác -> không nhúng (khung chứa không hiện).
    win._embed_suppressed.clear()
    win.sections.setCurrentIndex(SEC_OVERVIEW)
    win._auto_dock_tick()
    assert calls == [True]


class _FakeDock:
    def __init__(self, hwnd):
        self.docked_hwnd = hwnd

    def is_docked(self):
        return True

    def detach(self):
        return True


def test_auto_dock_tick_swaps_profile_and_minimizes_old(window, monkeypatch):
    win, _store, profile = window
    monkeypatch.setattr("app.docking.IS_WINDOWS", True)
    win._dock = _FakeDock(999)
    win._dock_profile_id = profile["id"] + 1000  # đang nhúng hồ sơ khác
    parked = []
    monkeypatch.setattr(docking, "minimize_window", lambda hwnd: parked.append(("min", hwnd)))
    monkeypatch.setattr(docking, "move_window_offscreen", lambda hwnd: parked.append(("off", hwnd)))
    calls = []
    monkeypatch.setattr(win, "_try_dock", lambda quiet=False: calls.append(quiet))
    win.sections.setCurrentIndex(SEC_PROFILES)

    # V3.7: mặc định BẬT "ngoài màn hình" — cửa sổ cũ bị đưa ra ngoài
    # phạm vi màn hình, không hiện trên desktop.
    win._settings["ui_browser_offscreen"] = True
    win._auto_dock_tick()
    assert parked == [("off", 999)]
    assert calls == [True]

    # Tắt tuỳ chọn -> hành vi cũ: thu nhỏ về taskbar.
    parked.clear()
    calls.clear()
    win._dock = _FakeDock(888)
    win._settings["ui_browser_offscreen"] = False
    win._auto_dock_tick()
    assert parked == [("min", 888)]
    assert calls == [True]


def test_stream_tab_keeps_dock_when_embed_always(window, monkeypatch):
    win, _store, _profile = window
    undocked = []
    monkeypatch.setattr(win, "_undock", lambda: undocked.append(True))
    monkeypatch.setattr(win._dock, "is_docked", lambda: True)
    win._on_live_tab_changed(TAB_STREAM)
    assert undocked == []  # đang bật tự-nhúng: Chrome ở yên trong app


def test_manual_undock_suppresses_auto_dock(window, monkeypatch):
    win, _store, profile = window
    monkeypatch.setattr(win._dock, "is_docked", lambda: True)
    undocked = []
    monkeypatch.setattr(win, "_undock", lambda: undocked.append(True))
    win._on_dock_toggle()
    assert undocked == [True]
    assert profile["id"] in win._embed_suppressed
