"""Kiểm thử kho cookies (V3.2): đọc file JSON/Netscape, chuẩn hoá,
chuyển đổi CDP, lưu/đọc theo hồ sơ và tóm tắt an toàn (không lộ giá trị)."""

import json

import pytest

from app import cookies_vault as cv

EDIT_THIS_COOKIE = json.dumps(
    [
        {
            "name": "SID",
            "value": "secret-value-1",
            "domain": ".google.com",
            "path": "/",
            "secure": True,
            "httpOnly": True,
            "sameSite": "no_restriction",
            "expirationDate": 1893456000,
            "hostOnly": False,
            "session": False,
        },
        {
            "name": "LOGIN_INFO",
            "value": "secret-value-2",
            "domain": ".youtube.com",
            "path": "/",
            "secure": True,
            "httpOnly": True,
            "sameSite": "lax",
            "session": True,
        },
    ]
).encode("utf-8")

NETSCAPE = (
    "# Netscape HTTP Cookie File\n"
    ".google.com\tTRUE\t/\tTRUE\t1893456000\tHSID\tsecret-value-3\n"
    "#HttpOnly_.youtube.com\tTRUE\t/\tTRUE\t0\tSAPISID\tsecret-value-4\n"
    "example.com\tFALSE\t/\tFALSE\t1893456000\tother\tzzz\n"
).encode("utf-8")


def test_parse_edit_this_cookie_json():
    cookies = cv.parse_cookies_bytes(EDIT_THIS_COOKIE)
    assert len(cookies) == 2
    sid = cookies[0]
    assert sid["name"] == "SID"
    assert sid["same_site"] == "None"
    assert sid["expires"] == 1893456000.0
    login = cookies[1]
    assert login["expires"] is None  # session cookie
    assert login["same_site"] == "Lax"


def test_parse_netscape_txt():
    cookies = cv.parse_cookies_bytes(NETSCAPE)
    assert len(cookies) == 3
    by_name = {c["name"]: c for c in cookies}
    assert by_name["HSID"]["secure"] is True
    assert by_name["SAPISID"]["http_only"] is True  # tiền tố #HttpOnly_
    assert by_name["SAPISID"]["expires"] is None  # 0 = session


def test_parse_garbage_returns_empty():
    assert cv.parse_cookies_bytes(b"") == []
    assert cv.parse_cookies_bytes(b"khong phai cookies") == []
    assert cv.parse_cookies_bytes(b"[1, 2, 3]") == []


def test_to_cdp_cookie_samesite_none_forces_secure():
    cookie = cv.normalize_cookie(
        {"name": "SID", "value": "v", "domain": ".google.com", "sameSite": "no_restriction"}
    )
    params = cv.to_cdp_cookie(cookie)
    assert params["sameSite"] == "None"
    assert params["secure"] is True
    assert "expires" not in params


def test_domain_filter_keeps_google_youtube_only():
    cookies = cv.parse_cookies_bytes(NETSCAPE)
    kept = cv.filter_google_youtube(cookies)
    assert {c["name"] for c in kept} == {"HSID", "SAPISID"}
    assert cv.is_google_youtube_domain(".google.com.vn")
    assert cv.is_google_youtube_domain("accounts.google.co.uk")
    assert not cv.is_google_youtube_domain("facebook.com")


def test_save_load_summarize_roundtrip(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    cookies = cv.parse_cookies_bytes(EDIT_THIS_COOKIE)
    summary = cv.save_cookies("kenh-test", cookies, source="import:test.json")
    assert summary["exists"] is True
    assert summary["count"] == 2
    assert summary["auth_cookies"] == ["SID", "LOGIN_INFO"]
    # Tóm tắt tuyệt đối không chứa giá trị cookie.
    assert "secret-value" not in json.dumps(summary)

    payload = cv.load_cookies("kenh-test")
    assert payload is not None
    assert len(payload["cookies"]) == 2
    assert cv.summarize("kenh-test")["count"] == 2
    assert cv.summarize("ho-so-khac")["exists"] is False


def test_normalize_cdp_cookies():
    raw = [
        {
            "name": "APISID",
            "value": "v",
            "domain": ".google.com",
            "path": "/",
            "expires": -1,
            "httpOnly": True,
            "secure": True,
            "session": True,
            "sameSite": "Lax",
        },
        {"name": "", "value": "v", "domain": ".google.com"},  # hỏng -> bỏ
    ]
    cookies = cv.normalize_cdp_cookies(raw)
    assert len(cookies) == 1
    assert cookies[0]["expires"] is None
    assert cookies[0]["http_only"] is True
