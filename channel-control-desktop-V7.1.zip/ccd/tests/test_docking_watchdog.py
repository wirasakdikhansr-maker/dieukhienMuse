"""Kiểm thử V3.1 cho watchdog nhúng cửa sổ (app.docking.DockWatchdog)
bằng dock giả + hàm tìm cửa sổ giả, và hàm style con thuần dữ liệu."""

import pytest

from app import docking


def test_child_style_strips_caption_and_adds_child():
    original = (
        docking.WS_POPUP
        | docking.WS_CAPTION
        | docking.WS_THICKFRAME
        | docking.WS_MINIMIZEBOX
        | docking.WS_MAXIMIZEBOX
        | docking.WS_SYSMENU
        | 0x00000100  # một bit style khác phải được giữ lại
    )
    style = docking._child_style(original)
    for bit in (
        docking.WS_POPUP,
        docking.WS_CAPTION,
        docking.WS_THICKFRAME,
        docking.WS_MINIMIZEBOX,
        docking.WS_MAXIMIZEBOX,
        docking.WS_SYSMENU,
    ):
        assert style & bit == 0
    assert style & docking.WS_CHILD
    assert style & docking.WS_VISIBLE
    assert style & 0x00000100


class FakeDock:
    def __init__(self, alive=True, hwnd=111):
        self._hwnd = hwnd if alive else None
        self._alive = alive
        self._container = 999
        self._size = (800, 600)
        self.attach_calls = []
        self.detach_calls = 0

    @property
    def docked_hwnd(self):
        return self._hwnd

    @property
    def container_hwnd(self):
        return self._container

    def is_docked(self):
        return self._hwnd is not None and self._alive

    def kill(self):
        self._alive = False

    def attach(self, hwnd, container, width, height):
        self.attach_calls.append((hwnd, container, width, height))
        self._hwnd = hwnd
        self._alive = True
        return True

    def detach(self):
        self.detach_calls += 1
        self._hwnd = None
        self._container = None
        return True


@pytest.fixture()
def windows(monkeypatch):
    monkeypatch.setattr(docking, "IS_WINDOWS", True)


def test_watchdog_idle_when_nothing_docked(windows):
    dock = FakeDock(alive=False, hwnd=None)
    watchdog = docking.DockWatchdog(dock, lambda p, m: None)
    assert watchdog.tick() == "idle"


def test_watchdog_ok_when_window_alive(windows):
    dock = FakeDock(alive=True)
    watchdog = docking.DockWatchdog(dock, lambda p, m: None)
    watchdog.watch({"id": 1, "slug": "demo"})
    assert watchdog.tick() == "ok"


def test_watchdog_redocks_recreated_window(windows):
    dock = FakeDock(alive=True)
    watchdog = docking.DockWatchdog(dock, lambda p, m: 222)
    watchdog.watch({"id": 1, "slug": "demo"})
    dock.kill()  # Chrome huỷ cửa sổ cũ
    assert watchdog.tick() == "redocked"
    assert dock.attach_calls == [(222, 999, 800, 600)]


def test_watchdog_lost_when_no_new_window(windows):
    dock = FakeDock(alive=True)
    watchdog = docking.DockWatchdog(dock, lambda p, m: None)
    watchdog.watch({"id": 1, "slug": "demo"})
    dock.kill()
    assert watchdog.tick() == "lost"
    assert dock.detach_calls == 1


def test_enable_dpi_awareness_safe_off_windows():
    if not docking.IS_WINDOWS:
        assert docking.enable_dpi_awareness() is False
