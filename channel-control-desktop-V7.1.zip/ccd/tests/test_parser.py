"""Kiểm thử parser: snapshot HTML mẫu -> bản ghi kênh; các hàm đếm số."""

from pathlib import Path

from app import parser

FIXTURE = Path(__file__).parent / "fixtures" / "channel_list_sample.html"


def test_parse_channels_from_sample_html():
    html = FIXTURE.read_text(encoding="utf-8")
    channels = parser.parse_channels_from_html(html)
    assert len(channels) == 3
    by_id = {c["channel_id"]: c for c in channels}

    awake = by_id["UCPXOYIGAsjCrJ0pzSAY-I0g"]
    assert awake["name"] == "Awake in the Dark"
    assert awake["handle"] == "@AwakeInTheDarkSeries"
    assert awake["url"] == "https://www.youtube.com/@AwakeInTheDarkSeries"
    assert awake["subs"] == 0

    bonitas = by_id["UCKRzjR1gLSAiLMg2rzgTHFA"]
    assert bonitas["name"] == "Bonitas Viejitas 70s 80s 90s"
    assert bonitas["handle"] == "@LatinPop202x"
    assert bonitas["subs"] == 43

    shin = by_id["UCFcnfSowPSLZhCibwB9-43g"]
    assert shin["name"] == "Shin Ryujin"  # tên dạng runs cũng đọc được
    assert shin["handle"] == "@shinryujin9478"
    assert shin["subs"] == 12500  # 12.5K


def test_parse_channels_from_html_without_snapshot_returns_empty():
    assert parser.parse_channels_from_html("<html><body>không có gì</body></html>") == []
    assert parser.parse_channels_from_html("") == []


def test_snapshot_roundtrip():
    data = {
        "actions": [
            {
                "accountItemRenderer": {
                    "channelId": "UCabc123456789012345678",
                    "accountName": {"simpleText": "Kênh Test"},
                    "vanityChannelUrl": "https://www.youtube.com/@KenhTest",
                    "accountByline": {"simpleText": "@KenhTest • 7 subscribers"},
                }
            }
        ]
    }
    html = parser.build_snapshot_html(data)
    channels = parser.parse_channels_from_html(html)
    assert len(channels) == 1
    assert channels[0]["name"] == "Kênh Test"
    assert channels[0]["subs"] == 7


def test_parse_account_menu_dedupes_by_channel_id():
    node = {
        "channelId": "UCabc123456789012345678",
        "accountName": {"simpleText": "Trùng"},
        "accountByline": {"simpleText": "@Trung • 1 subscriber"},
    }
    channels = parser.parse_account_menu({"a": [node, {"wrap": node}]})
    assert len(channels) == 1
    assert channels[0]["subs"] == 1


def test_parse_account_menu_account_id_variant():
    """Cấu trúc đời mới: ID nằm ở field accountId, handle ở node channelHandle."""
    data = {
        "multiPageMenuRenderer": {
            "sections": [
                {
                    "accountItemSectionRenderer": {
                        "contents": [
                            {
                                "accountItemRenderer": {
                                    "accountId": "UCxyz123456789012345678",
                                    "accountName": {"simpleText": "Kênh Đời Mới"},
                                    "channelHandle": {"simpleText": "@KenhDoiMoi"},
                                    "accountByline": {"simpleText": "@KenhDoiMoi • 128 subscribers"},
                                }
                            }
                        ]
                    }
                }
            ]
        }
    }
    channels = parser.parse_account_menu(data)
    assert len(channels) == 1
    assert channels[0]["channel_id"] == "UCxyz123456789012345678"
    assert channels[0]["name"] == "Kênh Đời Mới"
    assert channels[0]["handle"] == "@KenhDoiMoi"
    assert channels[0]["subs"] == 128
    assert channels[0]["url"] == "https://www.youtube.com/@KenhDoiMoi"


def test_parse_account_menu_id_hidden_in_child_endpoint():
    """Renderer không còn field ID riêng: ID giấu trong endpoint lồng nhau
    của chính item đó vẫn phải đọc được."""
    data = {
        "accountItemRenderer": {
            "accountName": {"simpleText": "Kênh Giấu ID"},
            "channelHandle": {"simpleText": "@KenhGiauID"},
            "accountEndpoint": {
                "clickTrackingParams": "abc",
                "commandMetadata": {"webCommandMetadata": {"url": "/channel/UCabc123456789012345678"}},
            },
        }
    }
    channels = parser.parse_account_menu(data)
    assert len(channels) == 1
    assert channels[0]["channel_id"] == "UCabc123456789012345678"
    assert channels[0]["handle"] == "@KenhGiauID"


def test_parse_account_menu_container_without_names_yields_nothing():
    """Node cha chứa nhiều kênh nhưng không có accountName thì không được
    tự nhận bừa ID đầu tiên trong cây con của nó."""
    data = {
        "accountItemListRenderer": {
            "accounts": [
                {"accountItemRenderer": {"channelId": "UCabc123456789012345678",
                                          "accountName": {"simpleText": "A"}}},
                {"accountItemRenderer": {"channelId": "UCdef123456789012345678",
                                          "accountName": {"simpleText": "B"}}},
            ]
        }
    }
    channels = parser.parse_account_menu(data)
    assert {c["name"] for c in channels} == {"A", "B"}


def test_summarize_structure_reports_renderers_and_uc_count():
    summary = parser.summarize_structure(
        {"responseContext": {}, "actions": [{"accountItemRenderer": {"channelId": "UCabc123456789012345678"}}]}
    )
    assert "responseContext" in summary
    assert "accountItemRenderer×1" in summary
    assert "UC...) trong dữ liệu: 1" in summary


def test_parse_dom_menu_texts():
    header = "Bachata de Desamor\n@BachataDeDesamor\npanumol@gmail.com"
    items = [
        "Bachata de Desamor\n@BachataDeDesamor • 5.18K subscribers",
        "Old Country Gold\n@OldCountryGold • 4,780 subscribers",
        "Kênh Chưa Ai Theo\n@KenhChuaAiTheo • No subscribers",
    ]
    records = parser.parse_dom_menu_texts(header, items)
    assert len(records) == 3
    by_handle = {r["handle"]: r for r in records}
    assert by_handle["@BachataDeDesamor"]["name"] == "Bachata de Desamor"
    assert by_handle["@BachataDeDesamor"]["subs"] == 5180
    assert by_handle["@OldCountryGold"]["subs"] == 4780
    assert by_handle["@KenhChuaAiTheo"]["subs"] == 0
    assert all(r["channel_id"] == "" for r in records)  # scanner bổ sung sau


def test_parse_channel_id_from_html():
    assert parser.parse_channel_id_from_html('{"channelId": "UCPXOYIGAsjCrJ0pzSAY-I0g"}') == "UCPXOYIGAsjCrJ0pzSAY-I0g"
    assert parser.parse_channel_id_from_html('<meta itemprop="channelId" content="UCKRzjR1gLSAiLMg2rzgTHFA">') == "UCKRzjR1gLSAiLMg2rzgTHFA"
    assert parser.parse_channel_id_from_html("<html>không có</html>") == ""
    assert parser.parse_channel_id_from_html(None) == ""


def test_parse_subscriber_text():
    assert parser.parse_subscriber_text("No subscribers") == 0
    assert parser.parse_subscriber_text("1 subscriber") == 1
    assert parser.parse_subscriber_text("43 subscribers") == 43
    assert parser.parse_subscriber_text("1.23K subscribers") == 1230
    assert parser.parse_subscriber_text("2.5M subscribers") == 2_500_000
    assert parser.parse_subscriber_text("@handle • 99 subscribers") == 99
    assert parser.parse_subscriber_text("không rõ") is None
    assert parser.parse_subscriber_text("") is None
    assert parser.parse_subscriber_text(None) is None


def test_parse_count_text():
    assert parser.parse_count_text("1,234 videos") == 1234
    assert parser.parse_count_text("57 videos") == 57
    assert parser.parse_count_text("1 video") == 1
    assert parser.parse_count_text("chưa có") is None


def test_parse_video_count_from_html():
    html = '<script>var x = {"videosCount": {"simpleText": "57"}};</script>'
    assert parser.parse_video_count_from_html(html) == 57
    html2 = '<script>{"videoCount": "1204"}</script>'
    assert parser.parse_video_count_from_html(html2) == 1204
    assert parser.parse_video_count_from_html("<html></html>") is None
    assert parser.parse_video_count_from_html(None) is None
