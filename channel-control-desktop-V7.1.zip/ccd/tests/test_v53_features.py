"""V5.3 — vòng gọn giao diện + trình duyệt linh hoạt (UI_V53_PLAN,
chủ kênh duyệt 2026-10-30 18:10). Kiểm chứng từng mục:

- A2: KHÔNG còn đường nào dựng toast/banner thông báo — API toast
  của MainWindow đã xoá hẳn, QSS không còn #Toast, CommandsPanel
  không còn hai banner lớn (needs_user/chưa-phân-công), không còn
  đoạn hướng dẫn dài dưới form tạo lệnh.
- A3: hàng Cầu nối Muse nằm CÙNG HÀNG với bộ lọc của danh sách
  lệnh; nút "Kết nối Muse…" cao đúng 24px.
- A4: 3 nút Chạy ngay / Xoá lệnh / Làm mới dưới bảng lệnh ĐÃ
  VẮNG; menu chuột phải có đủ cả ba hành động.
- A5: đệm dọc ô bảng = 2px (hằng theme), chiều cao hàng bảng suy
  từ compact_row_height; cột Kết quả hiện TÓM TẮT NGẮN thay repr
  dict (summarize_result).
- A7: tường ô CỐ ĐỊNH 600×800, tối đa 3 ô/hàng ở các số lượng
  1/2/3/4/7 (vị trí lưới), và trình duyệt TỰ MỞ khi khởi động
  theo setting (manager giả).
- A8: chế độ CHẠY ẨN — checkbox + setting bền; bật thì _try_dock
  KHÔNG nhúng (kể cả khi docking khả dụng), tường hiện trạng
  thái ẩn và không nhúng, manager mở thu nhỏ mặc định; tắt thì
  nhúng lại như cũ.
- A9: nền Văn phòng đổi được — theme dùng ảnh tuỳ chọn, lỗi nạp
  fallback ảnh đóng gói; ThemePanel sao ảnh vào data/office_bg
  + khôi phục mặc định.

Nhúng thật (Win32) chỉ chạy trên Windows — kiểm chứng ở đúng các
seam MainWindow gọi bằng docking/manager GIẢ, như lệ V5.2.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from app import config
from app.chrome_manager import ChromeManager
from app.store import Store
from app.ui import theme


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    instance = Store(config.db_path())
    yield instance
    instance.close()


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    instance = Store(config.db_path())
    from app.ui.main_window import MainWindow

    win = MainWindow(instance, ChromeManager(), settings)
    yield win, instance
    win.close()
    instance.close()


def _spin(qapp):
    qapp.processEvents()


# --------------------------------------------------------------------------- #
# A2 — không toast, không banner
# --------------------------------------------------------------------------- #
def test_no_toast_api_or_qss(window):
    win, _store = window
    assert not hasattr(win, "show_toast")
    assert not hasattr(win, "_layout_toasts")
    assert not hasattr(win, "_dismiss_toast")
    assert not hasattr(win, "_toasts")
    qss = theme.build_qss(theme.METAMINT_TOKENS)
    assert "#Toast" not in qss
    root = Path(__file__).resolve().parent.parent
    source = (root / "app/ui/main_window.py").read_text(encoding="utf-8")
    # Không còn ĐỊNH NGHĨA/cơ chế toast nào (chữ "show_toast" chỉ
    # còn trong bình luận ghi lại việc đã xoá).
    assert "def show_toast" not in source
    assert "def _layout_toasts" not in source
    assert "QFrame#Toast" not in theme.APP_QSS


def test_commands_panel_has_no_banners_or_form_hint(qapp, store):
    from app.ui.commands_panel import CommandsPanel

    panel = CommandsPanel(store)
    assert not hasattr(panel, "needs_user_label")
    assert not hasattr(panel, "unassigned_label")
    assert not hasattr(panel, "_refresh_alerts")
    # Đoạn hướng dẫn "Cách chạy:" dưới form tạo lệnh đã bỏ.
    root = Path(__file__).resolve().parent.parent
    source = (root / "app/ui/commands_panel.py").read_text(encoding="utf-8")
    assert "Cách chạy:" not in source
    panel.close()


# --------------------------------------------------------------------------- #
# A3 — hàng cầu nối trong hàng lọc, nút 24px
# --------------------------------------------------------------------------- #
def test_bridge_row_lives_in_filter_row(qapp, store):
    from app.ui.commands_panel import CommandsPanel

    panel = CommandsPanel(store)
    panel.resize(1200, 800)
    panel.show()
    _spin(qapp)
    # Cùng widget cha = cùng hàng bố cục với ô lọc.
    assert panel.bridge_label.parentWidget() is panel.search_edit.parentWidget()
    assert panel.bridge_help_button.parentWidget() is panel.search_edit.parentWidget()
    assert panel.bridge_help_button.height() == 24
    # Nhãn cầu nối 1 dòng, không bọc chữ (cắt … có tooltip đầy đủ).
    assert panel.bridge_label.wordWrap() is False
    panel.close()


def test_row_action_buttons_use_compact_style(qapp, store):
    """Hồi quy render V5.3: nút cao 24px với padding dọc mặc định
    (8px) bị CẮT CHỮ theo chiều dọc trên ảnh nghiệm thu — mọi
    nút 24px (nút cầu nối + nút thao tác trong dòng bảng) phải
    mang kiểu RowAction của theme (padding dọc 0, font 12px)."""
    from app.ui.commands_panel import CommandsPanel

    assert "QPushButton#RowAction" in theme.APP_QSS
    panel = CommandsPanel(store)
    assert panel.bridge_help_button.objectName() == "RowAction"
    profile = store.add_profile("Kenh A", "a@gmail.com")
    cmd = store.create_command(
        "scan", profile_id=profile["id"], instruction="quét"
    )
    host = panel._action_widget(store.get_command(cmd["id"]))
    buttons = [
        host.layout().itemAt(i).widget()
        for i in range(host.layout().count())
        if host.layout().itemAt(i).widget() is not None
    ]
    assert buttons, "lệnh đang chờ phải có nút thao tác"
    for button in buttons:
        assert button.objectName() == "RowAction"
        # setFixedHeight(24) → min = max = 24.
        assert button.minimumHeight() == 24
        assert button.maximumHeight() == 24
    panel.close()


def test_elided_label_paints_without_error(qapp, store):
    """Hồi quy V5.3: _ElidedLabel.paintEvent từng import QStyle từ
    QtGui (sai module — QStyle/QStyleOption thuộc QtWidgets) nên
    văng ImportError ở MỌI lần sơn nhãn cầu nối. Gọi paintEvent
    TRỰC TIẾP để lỗi (nếu tái diễn) nổ thành exception thật."""
    from PySide6.QtCore import QRect
    from PySide6.QtGui import QPaintEvent

    from app.ui.commands_panel import _ElidedLabel

    label = _ElidedLabel("Cầu nối Muse: đang kết nối — chữ dài để cắt cụt")
    label.resize(120, 24)
    label.paintEvent(QPaintEvent(QRect(0, 0, 120, 24)))  # không được raise
    assert label.text().startswith("Cầu nối Muse:")


# --------------------------------------------------------------------------- #
# A4 — 3 nút vắng, menu chuột phải đủ cả ba
# --------------------------------------------------------------------------- #
class _FakeAction:
    def __init__(self, text):
        self._text = text

        class _Signal:
            def connect(self, _slot):
                pass

        self.triggered = _Signal()

    def text(self):
        return self._text

    def setEnabled(self, _on):
        pass

    def setToolTip(self, tip):
        # V5.3.2 (M-BULK): hai mục huỷ/xoá hàng loạt ở cuối menu đặt
        # tooltip (số lệnh / lý do mờ nút) qua API QAction THẬT này —
        # bản giả phải mô hình đủ API action mà panel dùng, thiếu là
        # test đỏ oan ở bước dựng menu chứ không phải lỗi app.
        self._tooltip = tip

    def toolTip(self):
        return getattr(self, "_tooltip", "")


class _FakeMenu:
    """QMenu giả cho test menu chuột phải: QMenu.exec THẬT của
    Shiboken không thay bằng gán thuộc tính lớp được (nó mở vòng
    lặp modal và treo test offscreen) — thay tên QMenu trong
    namespace của module panel bằng bản ghi-lại này."""

    instances: list = []

    def __init__(self, _parent=None):
        self._actions: list[_FakeAction] = []
        _FakeMenu.instances.append(self)

    def addAction(self, text):
        action = _FakeAction(text)
        self._actions.append(action)
        return action

    def addSeparator(self):
        pass

    def exec(self, _pos):
        return None


def test_action_buttons_removed_and_context_menu_complete(qapp, store, monkeypatch):
    from PySide6.QtCore import QPoint

    import app.ui.commands_panel as commands_module
    from app.ui.commands_panel import CommandsPanel

    panel = CommandsPanel(store)
    assert not hasattr(panel, "run_button")
    assert not hasattr(panel, "delete_button")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    store.create_command("scan", profile_id=profile["id"], instruction="quét")
    panel.refresh()
    panel.show()
    _spin(qapp)
    assert panel.table.rowCount() == 1
    _FakeMenu.instances = []
    monkeypatch.setattr(commands_module, "QMenu", _FakeMenu)
    # pos của menu là toạ độ VIEWPORT (header không nằm trong
    # viewport) — y nhỏ nằm ngay trong dòng đầu tiên.
    panel._on_table_menu(QPoint(6, 4))
    assert _FakeMenu.instances, "menu chuột phải phải được dựng"
    captured = [act.text() for act in _FakeMenu.instances[-1]._actions]
    assert "▶ Chạy ngay" in captured
    assert "🗑 Xoá lệnh" in captured
    assert "↻ Làm mới danh sách" in captured
    panel.close()


# --------------------------------------------------------------------------- #
# A5 — bảng gọn: đệm 2px + tóm tắt kết quả
# --------------------------------------------------------------------------- #
def test_table_item_padding_is_2px():
    assert theme.TABLE_ITEM_VPAD == 2
    match = re.search(
        r"QTableWidget::item\s*\{[^}]*?padding:\s*(\d+)px",
        theme.build_qss(theme.METAMINT_TOKENS),
    )
    assert match is not None
    assert int(match.group(1)) == theme.TABLE_ITEM_VPAD


def test_compact_row_height_formula(qapp):
    from PySide6.QtGui import QFont, QFontMetrics

    font = QFont()
    metrics = QFontMetrics(font)
    assert theme.compact_row_height(font) == metrics.height() + 2 * 2 + 2
    assert theme.compact_row_height(font, min_content=24) >= 24 + 6
    assert theme.compact_row_height(font) >= 10


def test_commands_and_agents_tables_use_compact_rows(qapp, store, window):
    from app.ui.commands_panel import CommandsPanel

    panel = CommandsPanel(store)
    panel.show()
    _spin(qapp)
    expected = theme.compact_row_height(panel.table.font(), min_content=24)
    assert panel.table.verticalHeader().defaultSectionSize() == expected
    panel.close()

    win, _store = window
    agents_table = win.agents_panel.table
    assert agents_table.verticalHeader().defaultSectionSize() == (
        theme.compact_row_height(agents_table.font(), min_content=24)
    )
    # Bảng hàng đợi dựng RẤT SỚM trong MainWindow.__init__ — TRƯỚC
    # khi font app được polish qua QSS (metrics lệch đúng 1px:
    # 17 lúc dựng, 18 lúc đo) nên pin tuyệt đối sẽ giả-dương tính.
    # Hợp đồng thị giác thật được pin thay thế: hàng không bao
    # giờ thấp hơn (chiều cao chữ + 2×đệm 2px) và không lệch
    # công thức quá 1px.
    from PySide6.QtGui import QFontMetrics

    queue_size = win.queue_table.verticalHeader().defaultSectionSize()
    formula = theme.compact_row_height(win.queue_table.font())
    assert formula - 1 <= queue_size <= formula
    assert queue_size >= (
        QFontMetrics(win.queue_table.font()).height()
        + 2 * theme.TABLE_ITEM_VPAD
    )


def test_summarize_result_cases():
    from app.ui.commands_panel import summarize_result

    studio = {
        "status": "done",
        "result_data": {
            "kind": "studio_script", "completed_steps": 8, "total_steps": 8,
        },
    }
    assert summarize_result(studio) == "studio_script · 8/8 bước · xong"

    studio_err = {
        "status": "failed",
        "result_data": {
            "kind": "studio_script", "completed_steps": 3, "total_steps": 8,
        },
    }
    assert summarize_result(studio_err) == (
        "studio_script · 3/8 bước · lỗi giữa chừng"
    )

    generic = {"status": "done", "result_data": {"summary": "Đã quét 12 kênh"}}
    assert summarize_result(generic) == "Đã quét 12 kênh"

    repr_text = {
        "status": "done",
        "result": "{'kind': 'studio_script', 'completed_steps': 2, 'total_steps': 5}",
    }
    assert summarize_result(repr_text) == (
        "studio_script · 2/5 bước · xong"
    )

    # Text thường: gộp khoảng trắng/xuống dòng thành một dòng
    # ngắn (hợp đồng thật của hàm — không phải chỉ dòng đầu).
    plain = {"status": "done", "result": "Xong việc\nchi tiết dài ở dòng hai"}
    assert summarize_result(plain) == "Xong việc chi tiết dài ở dòng hai"

    failed = {"status": "failed", "error": "Hết hạn lease", "result": ""}
    assert summarize_result(failed) == "Hết hạn lease"

    empty = {"status": "queued", "result": "", "result_data": None}
    assert summarize_result(empty) == "—"

    long_text = {"status": "done", "result": "x" * 300}
    summary = summarize_result(long_text)
    assert len(summary) == 110 and summary.endswith("…")


# --------------------------------------------------------------------------- #
# A7 — tường 600×800 ≤3/hàng + tự mở khi khởi động
# --------------------------------------------------------------------------- #
def _profiles(count):
    return [
        {"id": i + 1, "label": f"HoSo{i + 1}", "email": "", "slug": f"p{i + 1}"}
        for i in range(count)
    ]


@pytest.mark.parametrize(
    "count,expected_positions",
    [
        (1, [(0, 0)]),
        (2, [(0, 0), (0, 1)]),
        (3, [(0, 0), (0, 1), (0, 2)]),
        (4, [(0, 0), (0, 1), (0, 2), (1, 0)]),
        (7, [(0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2), (2, 0)]),
    ],
)
def test_wall_grid_positions_and_fixed_tile_size(
    qapp, store, count, expected_positions
):
    from app.ui.browser_wall import TILE_HEIGHT, TILE_WIDTH, BrowserWall

    wall = BrowserWall(store)
    wall.resize(1920, 1080)
    wall.set_entries(_profiles(count), {})
    wall.show()
    _spin(qapp)
    assert wall.column_count() == 3
    for index, pid in enumerate(range(1, count + 1)):
        assert wall.tile_position(pid) == expected_positions[index]
        tile = wall.tiles[pid]
        assert tile.width() == TILE_WIDTH == 600
        assert tile.height() == TILE_HEIGHT == 800
    wall.close()


def test_wall_two_columns_at_1300(qapp, store):
    from app.ui.browser_wall import BrowserWall

    wall = BrowserWall(store)
    wall.resize(1300, 1000)
    wall.set_entries(_profiles(4), {})
    wall.show()
    _spin(qapp)
    assert wall.column_count() == 2
    assert wall.tile_position(3) == (1, 0)
    assert wall.tile_position(4) == (1, 1)
    wall.close()


def test_browsers_auto_open_on_start_with_fake_manager(window, monkeypatch):
    """A7: _auto_open_browsers_on_start mở MỌI hồ sơ không tạm
    dừng (đúng một lần mỗi hồ sơ), hồ sơ tạm dừng bị bỏ qua; chế
    độ ẩn TẮT → mở không thu nhỏ."""
    win, store = window
    store.add_profile("HoSo1", "a@gmail.com")
    paused = store.add_profile("HoSo2", "b@gmail.com")
    store.set_profile_paused(paused["id"], True)
    store.add_profile("HoSo3", "c@gmail.com")

    launched: list[tuple[str, bool]] = []

    class FakeManager:
        def launch(self, profile, start_minimized=False, hidden=None):
            launched.append((profile["slug"], bool(hidden)))
            return "launched"

    win._manager = FakeManager()
    submitted = []
    monkeypatch.setattr(
        win._runner, "submit_custom",
        lambda fn, **kw: submitted.append(fn(None)),
    )
    win._auto_open_browsers_on_start()
    assert len(submitted) == 2
    assert sorted(slug for slug, _min in launched) == [
        p["slug"] for p in store.list_profiles() if not p["paused"]
    ]
    # V6.7: mở CẤT (ngoài màn hình + khỏi taskbar) tới khi được nhúng
    assert all(hidden is True for _slug, hidden in launched)


def test_auto_open_default_is_on_for_fresh_settings(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    # V6.7: trình duyệt chỉ mở khi agent cần → mặc định TẮT
    assert settings["auto_open_browsers_on_start"] is False
    assert config.DEFAULT_SETTINGS["auto_open_browsers_on_start"] is False


# --------------------------------------------------------------------------- #
# A8 — chạy ẩn ngoài app
# --------------------------------------------------------------------------- #
def test_hidden_mode_blocks_dock_and_persists(window, monkeypatch):
    win, store = window
    from app.ui import main_window as mw

    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    win._current_profile_id = profile["id"]
    monkeypatch.setattr(mw.docking, "IS_WINDOWS", True)
    monkeypatch.setattr(mw.docking, "find_chrome_window", lambda p, m: 4242)
    attached: list = []
    monkeypatch.setattr(
        win._dock, "attach", lambda *a, **k: attached.append(a) or True
    )
    # Các khâu sau-nhúng (watchdog Win32, zoom qua CDP) không thuộc
    # phạm vi test này — chặn để test chỉ đo CỔNG nhúng.
    monkeypatch.setattr(win._watchdog, "watch", lambda *a, **k: None)
    monkeypatch.setattr(win, "_apply_embed_zoom", lambda *a, **k: None)

    # Mặc định TẮT → nhúng được.
    assert win._browsers_hidden() is False
    win._try_dock()
    assert attached, "chế độ thường phải nhúng được"
    attached.clear()
    win._dock.detach()

    # BẬT → setting lưu bền + manager mở thu nhỏ mặc định +
    # _try_dock bị chặn ở cổng trung tâm.
    win._apply_hidden_mode(True)
    assert win._browsers_hidden() is True
    assert win._settings["browsers_hidden_mode"] is True
    saved = config.load_settings()
    assert saved["browsers_hidden_mode"] is True
    assert win._manager.launch_minimized_default is True
    assert win.chk_hidden_mode.isChecked() is True
    assert win.browser_wall._hidden_mode is True
    win._try_dock()
    assert attached == [], "chạy ẩn BẬT thì không được nhúng"

    # TẮT → nhúng lại bình thường.
    win._apply_hidden_mode(False)
    assert win._manager.launch_minimized_default is False
    win._try_dock()
    assert attached, "chạy ẩn TẮT thì nhúng lại như mặc định"


def test_wall_hidden_mode_tiles(window):
    win, store = window
    from app.ui.browser_wall import BrowserTile

    wall = win.browser_wall
    wall.set_entries(_profiles(2), {})
    wall.set_hidden_mode(True)
    for tile in wall.tiles.values():
        assert tile.placeholder.text() == BrowserTile.HIDDEN_PLACEHOLDER
        assert tile.dock_chrome(object()) is False
    # Chạy ẩn: không hồ sơ nào bị coi là "chưa nhúng phải đỗ khuất".
    assert wall.undocked_profiles() == []
    wall.set_hidden_mode(False)
    for tile in wall.tiles.values():
        assert tile.placeholder.text() == BrowserTile.DEFAULT_PLACEHOLDER


def test_launch_minimized_flag_plumbing(monkeypatch, tmp_path):
    """A8: cờ mặc định của manager → mọi launch không nói rõ đều
    kèm --start-minimized; cửa sổ đăng nhập Muse nói rõ False
    thì không kèm."""
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(
        "app.chrome_manager.config.find_chrome", lambda override=None: "/fake/chrome"
    )
    state = {"open_calls": 0}

    def fake_port_open(port, timeout=1.0):
        state["open_calls"] += 1
        return state["open_calls"] % 2 == 0

    monkeypatch.setattr("app.chrome_manager.cdp.debug_port_open", fake_port_open)
    captured: list = []
    monkeypatch.setattr(
        "app.chrome_manager.subprocess.Popen",
        lambda args, **kw: captured.append(list(args)) or _FakeProc(),
    )
    manager = ChromeManager()
    profile = {"slug": "demo", "label": "Demo", "port": 19556}
    # V6.7: mặc định mọi launch là CẤT (ngoài màn hình), không còn --start-minimized
    assert manager.launch(profile) == "launched"
    assert "--window-position=-32000,-32000" in captured[-1] and "--start-minimized" not in captured[-1]
    assert manager.launch(profile, start_minimized=False) == "launched"
    assert "--window-position=-32000,-32000" not in captured[-1]
    manager.launch_hidden_default = False
    manager.launch_minimized_default = True
    assert manager.launch(profile) == "launched"
    assert "--start-minimized" in captured[-1]
    assert manager.launch(profile, start_minimized=False) == "launched"
    assert "--start-minimized" not in captured[-1]
    manager.launch_minimized_default = False
    assert manager.launch(profile) == "launched"
    assert "--start-minimized" not in captured[-1]


class _FakeProc:
    def poll(self):
        return None


def test_hidden_checkbox_in_profiles_toolbar_and_settings(window):
    win, _store = window
    assert hasattr(win, "chk_hidden_mode")
    assert win.chk_hidden_mode.isChecked() is False
    panel = win.settings_panel
    assert panel.hidden_mode_check.isChecked() is False
    panel.hidden_mode_check.setChecked(True)
    assert panel._gather()["browsers_hidden_mode"] is True


# --------------------------------------------------------------------------- #
# A9 — nền Văn phòng đổi được
# --------------------------------------------------------------------------- #
def test_office_background_custom_and_fallback(qapp, tmp_path):
    from PySide6.QtGui import QPixmap

    custom = tmp_path / "my_bg.png"
    pixmap = QPixmap(64, 32)
    pixmap.fill()
    assert pixmap.save(str(custom))

    packaged = theme.office_floor_pixmap()
    assert packaged is not None
    try:
        theme.set_office_background_path(str(custom))
        effective = theme.office_background_pixmap()
        assert effective is not None
        assert (effective.width(), effective.height()) == (64, 32)

        # File hỏng/thiếu → fallback nền đóng gói.
        theme.set_office_background_path(str(tmp_path / "khong-co.png"))
        assert theme.office_background_pixmap() is packaged

        theme.set_office_background_path(None)
        assert theme.office_background_pixmap() is packaged
    finally:
        theme.set_office_background_path(None)


def test_theme_panel_office_bg_pick_and_reset(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from PySide6.QtGui import QPixmap
    from PySide6.QtWidgets import QFileDialog

    from app.ui.theme_panel import ThemePanel

    settings = config.load_settings()
    panel = ThemePanel(settings)
    source = tmp_path / "anh-nen.jpg"
    QPixmap(80, 40).save(str(source))
    monkeypatch.setattr(
        QFileDialog, "getOpenFileName",
        staticmethod(lambda *a, **k: (str(source), "")),
    )
    panel._on_pick_office_bg()
    saved_path = settings["office_bg_image"]
    assert saved_path
    dest = Path(saved_path)
    assert dest.exists() and dest.parent.name == "office_bg"
    assert theme.office_background_path() == str(dest)
    assert panel.office_bg_label.text() == dest.name

    panel._on_reset_office_bg()
    assert settings["office_bg_image"] == ""
    assert theme.office_background_path() is None
    panel.close()
