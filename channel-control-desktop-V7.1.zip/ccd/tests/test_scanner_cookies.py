"""Kiểm thử scanner V3.2: chưa đăng nhập -> tự nạp cookies đã lưu của
hồ sơ -> đăng nhập lại được -> quét tiếp; sau quét thành công app tự
xuất cookies (chỉ Google/YouTube) về kho của hồ sơ."""

from app import cdp, cookies_vault, scanner
from app.store import Store

CHANNEL_ID = "UC" + "c" * 22

MENU_DATA = {
    "multiPageMenuRenderer": {
        "sections": [
            {
                "accountItemSectionRenderer": {
                    "contents": [
                        {
                            "accountItemRenderer": {
                                "accountId": CHANNEL_ID,
                                "accountName": {"simpleText": "Kênh Cookies"},
                                "channelHandle": {"simpleText": "@KenhCookies"},
                                "accountByline": {"simpleText": "@KenhCookies • 12 subscribers"},
                            }
                        }
                    ]
                }
            }
        ]
    }
}


class FakeClient:
    def __init__(self):
        self.login_checks = 0

    def navigate(self, url):
        pass

    def evaluate(self, expression, timeout=None):
        if "readyState" in expression:
            return "complete"
        if "ccd:menu" in expression:
            return {"ok": True, "status": 200, "data": MENU_DATA}
        if "videosCount" in expression:
            return "57"
        if "LOGGED_IN" in expression:
            self.login_checks += 1
            # Lần đầu: chưa đăng nhập. Sau khi nạp cookies: đã đăng nhập.
            return {"loggedIn": self.login_checks > 1, "href": "https://www.youtube.com/"}
        return None

    def close(self):
        pass


class FakeManager:
    def __init__(self, client):
        self.client = client

    def launch(self, profile):
        return "already_running"

    def connect_page(self, profile):
        return self.client


def test_scan_restores_login_from_saved_cookies_and_exports(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("kenh cookies", "panumol@gmail.com")

    # Kho cookies có sẵn của hồ sơ (đăng nhập bằng cookies).
    cookies_vault.save_cookies(
        profile["slug"],
        [
            {
                "name": "SID", "value": "bi-mat", "domain": ".google.com",
                "path": "/", "expires": None, "secure": True,
                "http_only": True, "same_site": "Lax", "host_only": False,
            }
        ],
        source="import:test",
    )

    injected = {}
    monkeypatch.setattr(
        cdp, "set_cookies", lambda port, params: injected.update(params=params)
    )
    monkeypatch.setattr(
        cdp,
        "get_all_cookies",
        lambda port: [
            {"name": "HSID", "value": "moi", "domain": ".google.com", "path": "/",
             "expires": -1, "httpOnly": True, "secure": True, "session": True},
            {"name": "tracker", "value": "bo", "domain": ".example.com", "path": "/"},
        ],
    )

    result = scanner.scan_profile(store, profile, FakeManager(FakeClient()))
    assert result["status"] == "ok"
    assert len(result["channels"]) == 1
    assert result["channels"][0]["channel_id"] == CHANNEL_ID
    # Đã nạp đúng cookie đã lưu vào Chrome.
    assert [p["name"] for p in injected["params"]] == ["SID"]
    # Sau quét: kho được cập nhật bằng cookies mới từ Chrome (chỉ Google).
    summary = cookies_vault.summarize(profile["slug"])
    assert summary["count"] == 1
    assert summary["auth_cookies"] == ["HSID"]
    assert summary["source"] == "auto:scan"
    store.close()
