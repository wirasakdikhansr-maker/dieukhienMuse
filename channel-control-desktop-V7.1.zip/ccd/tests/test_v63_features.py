"""V6.3 — quy tắc & KPI, trưởng phòng tự xử lý, lịch sử bước, file lớn,
báo cáo ngày, đẩy chat, realtime, tường trình duyệt, văn phòng 2D."""

import io
import json
import os
from datetime import datetime, timedelta

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app import daily_report, kpi, lead_autopilot, large_files, muse_push
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "t.db")
    yield s
    s.close()


def _agent_online(store, name, email):
    agent = store.create_agent(name, email)
    store.touch_agent_heartbeat(agent["id"])
    return store.get_agent(agent["id"])


# ---------------------------------------------------------------- bước
def test_step_history_recorded_only_on_change(store):
    p = store.add_profile("P", "p@gmail.com")
    a = store.create_agent("A", "a@x.com")
    c = store.create_command("create_video", profile_id=p["id"], profile_slug=p["slug"],
                             instruction="x", agent_id=a["id"], status="waiting_muse")
    store.update_command_progress(c["id"], 10, "Viết kịch bản", agent_id=a["id"])
    store.update_command_progress(c["id"], 20, "Viết kịch bản", agent_id=a["id"])
    store.update_command_progress(c["id"], 50, "Render 50%", agent_id=a["id"])
    steps = store.list_command_steps(c["id"])
    assert [s["step"] for s in steps] == ["Viết kịch bản", "Render 50%"]
    assert store.steps_for_commands([c["id"]])[c["id"]][-1]["progress"] == 50


# ---------------------------------------------------------------- quy tắc & KPI
def test_rules_defaults_and_overrides():
    cfg = kpi.rules_settings({})
    assert "BẰNG CHỨNG" in cfg["agent_rules"]
    assert cfg["targets"]["pass_score"] == 70
    custom = kpi.rules_settings({"rules_agent": "Luật riêng", "kpi_targets": {"pass_score": "60", "bogus": 1}})
    assert custom["agent_rules"] == "Luật riêng"
    assert custom["targets"]["pass_score"] == 60 and "bogus" not in custom["targets"]
    assert kpi.rules_for_command({"type": "review"}, {})["role"] == "supervisor"
    assert kpi.rules_for_command({"type": "create_video"}, {})["role"] == "agent"


def test_agent_kpi_from_real_data(store):
    a = store.create_agent("A", "a@x.com")
    now = datetime.now().astimezone()
    for i in range(5):
        c = store.create_command("free", instruction=f"v{i}", agent_id=a["id"], status="running")
        store.set_command_due(c["id"], (now + timedelta(hours=1)).isoformat(timespec="seconds"))
        store.finish_command(c["id"], "done", result="ok")
    result = kpi.agent_kpi(store, a["id"], {})
    assert result["done"] == 5
    assert result["on_time_pct"] == 100.0
    assert result["score"] is not None and result["score"] >= 70
    assert result["passed"] is True


def test_chat_reply_minutes(store):
    a = store.create_agent("A", "a@x.com")
    store.add_message(a["id"], "user", "hỏi")
    store.add_message(a["id"], "agent", "đáp")
    value = kpi.chat_reply_minutes(store, a["id"], "2000-01-01T00:00:00+00:00")
    assert value is not None and value < 1


# ---------------------------------------------------------------- trưởng phòng
def test_lead_autopilot_reassigns_unclaimed_and_escalates_login(store, monkeypatch):
    lead = _agent_online(store, "Lead", "lead@x.com")
    worker = store.create_agent("Worker", "w@x.com")  # ngoại tuyến
    helper = _agent_online(store, "Helper", "h@x.com")
    settings = {"supervision_mode": "lead", "supervision_lead_agent_id": lead["id"]}
    c1 = store.create_command("free", instruction="a", agent_id=worker["id"], status="waiting_muse")
    c2 = store.create_command("free", instruction="b", agent_id=worker["id"], status="needs_user")
    issues = [
        {"key": "unclaimed:1", "kind": "unclaimed", "title": "Chờ nhận", "command_id": c1["id"],
         "agent_id": worker["id"]},
        {"key": "needs:1", "kind": "needs_user", "title": "Cần đăng nhập", "detail": "Lý do: cần đăng nhập Studio",
         "command_id": c2["id"], "agent_id": worker["id"]},
    ]
    monkeypatch.setattr(lead_autopilot.office_issues, "collect_issues", lambda *a, **k: issues)
    decided = lead_autopilot.run(store, settings, force=True)
    actions = {d["action"]: d for d in decided}
    assert actions["reassign"]["outcome"] == "done"
    assert store.get_command(c1["id"])["agent_id"] in (lead["id"], helper["id"])
    # V6.5 (toàn quyền): việc cần đăng nhập KHÔNG đẩy về người dùng ngay —
    # trưởng phòng bắt Muse tự xử lý trên trình duyệt nhúng + cho chạy tiếp.
    assert actions["self_fix"]["outcome"] == "done"
    assert store.get_command(c2["id"])["status"] == "queued"
    # nhắn cho người nhận việc mới
    receiver = store.get_command(c1["id"])["agent_id"]
    assert any("[Trưởng phòng]" in m["body"] for m in store.list_messages(receiver))
    # chống lặp: chạy lại ngay không ra quyết định trùng
    assert lead_autopilot.run(store, settings, force=True) == []


def test_lead_replaced_when_kpi_low(store, monkeypatch):
    a = _agent_online(store, "A", "a@x.com")
    b = _agent_online(store, "B", "b@x.com")
    settings = {"supervision_mode": "lead", "supervision_lead_agent_id": a["id"],
                "kpi_targets": {"lead_replace_after": 1}}
    monkeypatch.setattr(lead_autopilot.kpi, "lead_kpi", lambda *x, **k: {"score": 10})
    monkeypatch.setattr(lead_autopilot.kpi, "agent_kpi",
                        lambda store, aid, *x, **k: {"score": 90 if aid == b["id"] else 20})
    saved = {}
    record = lead_autopilot.maybe_replace_lead(store, settings, datetime.now().astimezone(),
                                               save_settings=lambda s: saved.update(s))
    assert record and record["action"] == "replace_lead"
    assert settings["supervision_lead_agent_id"] == b["id"] == saved["supervision_lead_agent_id"]


# ---------------------------------------------------------------- file lớn
def test_large_file_chunked_resume(tmp_path):
    lf = large_files.LargeFiles(tmp_path, max_bytes=10_000_000)
    data = os.urandom(300_000)
    import hashlib

    sha = hashlib.sha256(data).hexdigest()
    up = lf.init_upload({"name": "../video.mp4", "size": len(data), "sha256": sha})
    assert up["name"] == "video.mp4" and up["received"] == 0
    lf.write_chunk(up["id"], 0, io.BytesIO(data[:100_000]), 100_000)
    # mạng đứt → phiên mới cùng file trả lại phiên cũ để nối tiếp
    again = lf.init_upload({"name": "video.mp4", "size": len(data), "sha256": sha})
    assert again["id"] == up["id"] and again["received"] == 100_000
    with pytest.raises(large_files.LargeFileError):
        lf.write_chunk(up["id"], 0, io.BytesIO(b"x"), 1)  # sai offset
    lf.write_chunk(up["id"], 100_000, io.BytesIO(data[100_000:]), len(data) - 100_000)
    done = lf.complete(up["id"])
    assert done["status"] == "done"
    assert open(done["saved"], "rb").read() == data


def test_large_file_rejects_bad_sha_and_oversize(tmp_path):
    lf = large_files.LargeFiles(tmp_path, max_bytes=1000)
    with pytest.raises(large_files.LargeFileError):
        lf.init_upload({"name": "a", "size": 5000})
    up = lf.init_upload({"name": "a", "size": 3, "sha256": "00"})
    lf.write_chunk(up["id"], 0, io.BytesIO(b"abc"), 3)
    with pytest.raises(large_files.LargeFileError):
        lf.complete(up["id"])


def test_fetch_from_url_with_range_resume(tmp_path):
    payload = os.urandom(50_000)
    calls = []

    class Resp:
        def __init__(self, data, status, headers):
            self._buf = io.BytesIO(data)
            self.status = status
            self.headers = headers

        def read(self, n=-1):
            return self._buf.read(n)

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def opener(request, timeout=60):
        rng = request.headers.get("Range")
        calls.append(rng)
        if rng is None:
            # lần đầu: đứt giữa chừng sau 20k
            class Broken(Resp):
                def read(self, n=-1):
                    chunk = super().read(n)
                    if not chunk:
                        raise ConnectionResetError("đứt")
                    return chunk
            return Broken(payload[:20_000], 200, {"Content-Length": str(len(payload))})
        start = int(rng.split("=")[1].rstrip("-"))
        return Resp(payload[start:], 206, {"Content-Range": f"bytes {start}-{len(payload)-1}/{len(payload)}"})

    lf = large_files.LargeFiles(tmp_path, max_bytes=10_000_000, opener=opener)
    import app.large_files as mod

    mod.time.sleep = lambda s: None
    meta = lf.start_fetch({"url": "https://example.com/v.mp4"})
    lf._fetch_threads[meta["id"]].join(10)
    status = lf.status(meta["id"])
    assert status["status"] == "done", status
    assert open(status["saved"], "rb").read() == payload
    assert calls[0] is None and calls[1] == "bytes=20000-"


# ---------------------------------------------------------------- báo cáo ngày
def test_daily_report_due_and_generate(store):
    p = store.add_profile("Kênh Nhật", "k@gmail.com")
    store.upsert_channel(p["id"], {"channel_id": "UC1", "name": "老後の心理学", "handle": "@x",
                                   "url": "u", "subs": 100, "video_count": 3})
    a = store.create_agent("Muse 01", "m@x.com")
    store.assign_profiles(a["id"], [p["id"]])
    settings = {"daily_report_enabled": True, "daily_report_time": "08:00"}
    morning = datetime.now().astimezone().replace(hour=7, minute=59)
    assert not daily_report.due(store, settings, morning)
    later = morning.replace(hour=8, minute=1)
    assert daily_report.due(store, settings, later)
    path = daily_report.generate(store, settings, later)
    html = path.read_text("utf-8")
    assert "Muse 01" in html and "老後の心理学" in html and "Phân tích" in html
    assert not daily_report.due(store, settings, later)


# ---------------------------------------------------------------- đẩy chat
def test_wake_text_and_push_skips_when_not_logged_in():
    agent = {"id": 3, "name": "M", "email": "m@x.com", "web_state": "out"}
    text = muse_push.wake_text(agent, "Làm nhanh giúp anh")
    assert "/api/agents/3/messages" in text and "Làm nhanh" in text

    class Manager:
        def is_running(self, profile):
            return False

    result = muse_push.push_message(Manager(), agent, text, sleep=lambda s: None)
    assert result["ok"] is False


# ---------------------------------------------------------------- realtime
def test_data_version_changes_on_other_connection(tmp_path):
    a = Store(tmp_path / "rt.db")
    b = Store(tmp_path / "rt.db")
    before = a.data_version()
    b.append_journal("ghi từ kết nối khác")
    assert a.data_version() != before
    a.close()
    b.close()


# ---------------------------------------------------------------- giao diện
@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_browser_wall_priority_and_layout_modes(qapp, store):
    from app.ui.browser_wall import BrowserWall

    p1 = store.add_profile("P1", "p1@gmail.com")
    p2 = store.add_profile("P2", "p2@gmail.com")
    wall = BrowserWall(store, settings={})
    wall.resize(1400, 900)
    wall.show()
    wall.set_priority({p2["id"]: (0, 0, p2["id"]), p1["id"]: (2, 0, p1["id"])},
                      {p2["id"]: "🤖 M đang dùng · 40%"})
    wall.set_entries([p1, p2], {})
    assert wall._entry_ids[0] == p2["id"]
    assert wall.tiles[p2["id"]].busy_badge is not None
    wall.set_layout_mode("2")
    assert wall.column_count() == 2
    wall.set_layout_mode("fit")
    w0 = wall.tiles[p1["id"]].width()
    wall._on_tile_drag(500, 400)
    assert all(t.width() == 500 and t.height() == 400 for t in wall.tiles.values())
    assert w0 > 0


def test_office_2d_mode_and_steps_table(qapp, store, tmp_path):
    from app.ui.office_view import OfficeView
    from app.ui.steps_table import StepsTable, plan_text

    p = store.add_profile("P", "p@gmail.com")
    a = store.create_agent("Muse 01", "m@x.com")
    store.assign_profiles(a["id"], [p["id"]])
    c = store.create_command("create_video", profile_id=p["id"], profile_slug=p["slug"],
                             instruction="video", agent_id=a["id"], status="waiting_muse")
    store.update_command_progress(c["id"], 45, "Viết kịch bản cảnh 3/8", agent_id=a["id"])
    settings = {"office_view_mode": "2d"}
    view = OfficeView(store, settings)
    view.resize(1500, 900)
    view.show()
    view.refresh()
    qapp.processEvents()
    assert view.view_stack.currentIndex() == 1
    assert view.view2d.canvas.desks and view.view2d.canvas.desks[0]["agent_id"] == a["id"]
    view.set_view_mode("3d")
    assert view.view_stack.currentIndex() == 2 and settings["office_view_mode"] == "3d"
    # V6.4: khoang 3D — cả khoang là vùng bấm, bấm chọn đúng agent.
    from PySide6.QtCore import QPointF
    stage = view.view3d.stage
    view.refresh()
    qapp.processEvents()
    assert stage.desks and stage._hits
    hit_rect, hit_desk = stage._hits[0]
    picked = []
    stage.agent_clicked.connect(picked.append)
    assert stage._desk_at(QPointF(hit_rect.center())) is hit_desk
    assert stage._desk_at(QPointF(hit_rect.left() + 5, hit_rect.bottom() - 5)) is hit_desk
    assert stage._desk_at(QPointF(-50, -50)) is None
    view.set_view_mode("classic")
    assert view.view_stack.currentIndex() == 0
    table = StepsTable(store, {})
    table.refresh()
    top = table.topLevelItem(0)
    assert "Viết kịch bản cảnh 3/8" in top.text(5)
    assert top.child(0).text(5) == "Viết kịch bản cảnh 3/8"
    assert "✓ 1." in plan_text(store.get_command(c["id"]))


def test_switch_section_repaints_agents_table(qapp, tmp_path, monkeypatch):
    """V6.3.1: tab Tài khoản không còn 'mất danh sách' sau khi rời tab Hồ
    sơ (cửa sổ Chrome native) — chuyển mục luôn ép vẽ lại bảng."""
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import SEC_AGENTS, SEC_PROFILES, MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    st.create_agent("Muse A", "a@x.com")
    win = MainWindow(st, ChromeManager(), settings)
    try:
        win._switch_section(SEC_PROFILES)
        win.agents_panel.table.setUpdatesEnabled(False)  # mô phỏng bảng bị "đóng băng"
        win._switch_section(SEC_AGENTS)
        assert win.agents_panel.table.updatesEnabled()
        assert win.agents_panel.table.rowCount() == 1
    finally:
        win.close()


def test_office3d_caches_static_layers(qapp):
    """V6.4.1: phần tĩnh của khoang vẽ một lần vào ảnh đệm; vẽ lại không
    dựng lại ảnh đệm; nhịp chuyển động chỉ chạm khoang đang làm việc."""
    from PySide6.QtGui import QImage

    from app.ui.office_3d import Office3DView

    desks = [
        {"agent_id": 1, "name": "A", "state": "working", "agent_status": "online", "queue_count": 0,
         "profile_ids": [], "current": {"id": "c1", "type": "free", "type_label": "Việc", "instruction": "x",
                                        "progress": 30, "step": "b"}},
        {"agent_id": 2, "name": "B", "state": "idle", "agent_status": "offline", "queue_count": 0,
         "profile_ids": [], "current": None},
    ]
    view = Office3DView()
    view.resize(1200, 600)
    view.show()
    view.set_data(desks, {}, {}, {}, None, None)
    qapp.processEvents()
    stage = view.stage
    img = QImage(stage.size(), QImage.Format_ARGB32_Premultiplied)
    stage.render(img)
    cached = dict(stage._pod_cache)
    assert len(cached) == 2
    stage.render(img)
    assert all(stage._pod_cache[k] is v for k, v in cached.items())
    assert stage._animated(desks[0]) and not stage._animated(desks[1])
    view.close()


# ---------------------------------------------------------------- V6.4.2 tự nối lại
def test_reconnect_plan_wakes_only_lost_agents_with_backoff(store):
    from datetime import timedelta

    from app import reconnect

    now = datetime.now().astimezone()
    lost = store.create_agent("Lost", "l@x.com")
    fresh = store.create_agent("Fresh", "f@x.com")
    never = store.create_agent("Never", "n@x.com")
    store._conn.execute("UPDATE agents SET last_seen_at = ? WHERE id = ?",
                        ((now - timedelta(minutes=10)).isoformat(timespec="seconds"), lost["id"]))
    store._conn.commit()
    store.touch_agent_heartbeat(fresh["id"])
    store.create_command("free", instruction="x", agent_id=lost["id"], status="waiting_muse")
    clock = [1000.0]
    plan = reconnect.plan_agent_wakeups(store, {}, now, clock=lambda: clock[0])
    assert [a["id"] for a, _ in plan["wake"]] == [lost["id"]]
    assert "còn 1 việc" in plan["wake"][0][1]
    # nhịp kế tiếp ngay sau: đang giãn cách → không nhắc lại
    again = reconnect.plan_agent_wakeups(store, plan["memory"], now, clock=lambda: clock[0] + 60)
    assert again["wake"] == []
    # quá 5 phút → nhắc lần 2, lần sau giãn 10 phút
    clock[0] += 301
    third = reconnect.plan_agent_wakeups(store, plan["memory"], now, clock=lambda: clock[0])
    assert len(third["wake"]) == 1 and third["memory"][lost["id"]][0] == 2
    text = reconnect.reconnect_text(lost, {"agent_port": 19500}, "mất nhịp tim 10 phút")
    assert f"/api/agents/{lost['id']}/heartbeat" in text
    assert never["id"] not in [a["id"] for a, _ in third["wake"]]


def test_probe_bridge_detects_dead_port():
    from app import reconnect

    assert reconnect.probe_bridge(1, timeout=0.5) is False
