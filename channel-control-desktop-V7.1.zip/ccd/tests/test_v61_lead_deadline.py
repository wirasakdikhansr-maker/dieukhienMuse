"""V6.1 — Trưởng phòng giám sát + hạn chót + sự cố Văn phòng + chống đơ."""

import os
import threading
import time
from datetime import datetime, timedelta

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app import chrome_manager, office_issues, supervision
from app.store import DEFAULT_DEADLINE_MINUTES, Store


@pytest.fixture()
def world(tmp_path):
    store = Store(tmp_path / "ccd.sqlite3")
    a1 = store.create_agent("Lead", "lead@x.com")
    a2 = store.create_agent("Muse B", "b@x.com")
    a3 = store.create_agent("Muse C", "c@x.com")
    p1 = store.add_profile("Kênh 1", "k1@x.com")
    p2 = store.add_profile("Kênh 2", "k2@x.com")
    store.assign_profiles(a2["id"], [p1["id"]])
    store.assign_profiles(a3["id"], [p2["id"]])
    yield {"store": store, "a1": a1, "a2": a2, "a3": a3, "p1": p1, "p2": p2}
    store.close()


def _lead_settings(lead_id):
    return {"supervision_mode": "lead", "supervision_lead_agent_id": lead_id}


# ------------------------------------------------------------------ #
# Trưởng phòng
# ------------------------------------------------------------------ #
def test_lead_supervises_everyone_else_and_never_self(world):
    store, a1, a2, a3 = world["store"], world["a1"], world["a2"], world["a3"]
    matrix = supervision.effective_matrix(store, _lead_settings(a1["id"]))
    assert matrix[a2["id"]] == a1["id"]
    assert matrix[a3["id"]] == a1["id"]
    # Việc của chính trưởng phòng do người khác chấm (không tự chấm).
    assert matrix[a1["id"]] != a1["id"]


def test_lead_mode_without_lead_falls_back_to_ring(world):
    store = world["store"]
    ring = supervision.effective_matrix(store, {"supervision_mode": "lead", "supervision_lead_agent_id": 0})
    assert ring == supervision.default_ring(supervision.active_agent_ids(store))


def test_revoked_lead_is_ignored(world):
    store, a1 = world["store"], world["a1"]
    store.set_agent_revoked(a1["id"], True)
    assert supervision.lead_agent_id(store, _lead_settings(a1["id"])) is None


def test_review_goes_to_lead(world):
    store, a1, a2, p1 = world["store"], world["a1"], world["a2"], world["p1"]
    cmd = store.create_command("free", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x")
    store._conn.execute("UPDATE commands SET status='done', result='xong https://youtu.be/abc' WHERE id=?", (cmd["id"],))
    review = supervision.create_review_for_target(
        store, store.get_command(cmd["id"]), "done", _lead_settings(a1["id"]))
    assert review["supervisor_agent_id"] == a1["id"]
    assert review["worker_agent_id"] == a2["id"]


def test_local_commands_never_spawn_reviews(world):
    store, p1 = world["store"], world["p1"]
    for ctype in ("scan", "check", "open_browser"):
        cmd = store.create_command(ctype, profile_id=p1["id"], profile_slug=p1["slug"])
        store.finish_command(cmd["id"], "done", result="ok ok ok ok ok ok")
    assert store.list_reviews(limit=50) == []


# ------------------------------------------------------------------ #
# Hạn chót
# ------------------------------------------------------------------ #
def test_every_command_gets_default_due(world):
    store, p1 = world["store"], world["p1"]
    before = datetime.now().astimezone()
    cmd = store.create_command("create_video", profile_id=p1["id"], profile_slug=p1["slug"], instruction="v")
    due = datetime.fromisoformat(cmd["due_at"])
    expected = before + timedelta(minutes=DEFAULT_DEADLINE_MINUTES["create_video"])
    assert abs((due - expected).total_seconds()) < 5


def test_explicit_due_and_extend(world):
    store, p1 = world["store"], world["p1"]
    due = (datetime.now().astimezone() + timedelta(minutes=5)).isoformat(timespec="seconds")
    cmd = store.create_command("free", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x", due_at=due)
    assert cmd["due_at"] == due
    extended = store.extend_command_due(cmd["id"], 60)
    assert datetime.fromisoformat(extended["due_at"]) > datetime.fromisoformat(due) + timedelta(minutes=59)


def test_deadline_health_classification():
    now = datetime.now().astimezone()
    base = {"status": "running", "created_at": (now - timedelta(minutes=90)).isoformat(),
            "started_at": (now - timedelta(minutes=90)).isoformat()}
    on_track = dict(base, progress=95, due_at=(now + timedelta(minutes=10)).isoformat())
    at_risk = dict(base, progress=20, due_at=(now + timedelta(minutes=10)).isoformat())
    overdue = dict(base, progress=50, due_at=(now - timedelta(minutes=1)).isoformat())
    blocked = dict(base, status="needs_user", progress=50, due_at=(now + timedelta(hours=3)).isoformat())
    assert supervision.deadline_health(on_track, now)["health"] == supervision.HEALTH_ON_TRACK
    assert supervision.deadline_health(at_risk, now)["health"] == supervision.HEALTH_AT_RISK
    assert supervision.deadline_health(overdue, now)["health"] == supervision.HEALTH_OVERDUE
    assert supervision.deadline_health(blocked, now)["health"] == supervision.HEALTH_BLOCKED
    assert supervision.format_left(-35 * 60).startswith("trễ 35p")
    assert supervision.format_left(80 * 60) == "còn 1g20p"


def test_deadline_scan_alerts_once_then_extend_rearms(world):
    store, a1, a2, p1 = world["store"], world["a1"], world["a2"], world["p1"]
    past = (datetime.now().astimezone() - timedelta(minutes=3)).isoformat(timespec="seconds")
    cmd = store.create_command("free", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x", due_at=past)
    settings = _lead_settings(a1["id"])
    assert supervision.deadline_scan(store, settings) == [cmd["id"]]
    assert supervision.deadline_scan(store, settings) == []  # không nhắc lặp
    lead_msgs = [m for m in store.list_messages(a1["id"], limit=10) if m["direction"] == "system"]
    worker_msgs = [m for m in store.list_messages(a2["id"], limit=10) if m["direction"] == "system"]
    assert lead_msgs and worker_msgs
    store.extend_command_due(cmd["id"], 1)
    assert "deadline_alerted" not in (store.get_command(cmd["id"])["payload"] or {})


def test_backfill_due_for_old_open_commands(world):
    store, p1 = world["store"], world["p1"]
    cmd = store.create_command("free", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x")
    store._conn.execute("UPDATE commands SET due_at = NULL WHERE id = ?", (cmd["id"],))
    store._conn.commit()
    assert store.backfill_due_dates() == 1
    assert store.get_command(cmd["id"])["due_at"]


def test_hot_indexes_exist(world):
    names = {r[0] for r in world["store"]._conn.execute(
        "SELECT name FROM sqlite_master WHERE type='index'")}
    assert {"idx_commands_status_created", "idx_commands_agent", "idx_commands_due",
            "idx_journal_profile"} <= names


# ------------------------------------------------------------------ #
# Sự cố Văn phòng
# ------------------------------------------------------------------ #
def test_needs_user_grouped_with_concrete_fix(world):
    store, p1 = world["store"], world["p1"]
    ids = []
    for _ in range(3):
        cmd = store.create_command("optimize", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x")
        store._conn.execute(
            "UPDATE commands SET status='needs_user', result='Cần đăng nhập lại YouTube Studio' WHERE id=?",
            (cmd["id"],))
        ids.append(cmd["id"])
    store._conn.commit()
    issues = office_issues.collect_issues(store, bridge_enabled=False)
    needs = [i for i in issues if i["kind"] == "needs_user"]
    assert len(needs) == 1
    assert sorted(needs[0]["command_ids"]) == sorted(ids)
    assert "đăng nhập" in needs[0]["fix"].lower()
    assert ("open_profile", "🌐 Mở trình duyệt hồ sơ") in needs[0]["actions"]
    assert needs[0]["severity"] == "critical"


def test_bridge_and_unassigned_and_failed_issues(world):
    store = world["store"]
    p3 = store.add_profile("Kênh mồ côi", "orphan@x.com")
    store.create_command("free", profile_id=p3["id"], profile_slug=p3["slug"], instruction="x")
    failed = store.create_command("upload", profile_id=world["p1"]["id"],
                                  profile_slug=world["p1"]["slug"], instruction="x")
    store.finish_command(failed["id"], "failed", error="YouTube trả 429 Too Many Requests")
    issues = office_issues.collect_issues(store, bridge_enabled=True)
    kinds = {i["kind"] for i in issues}
    assert {"bridge", "unassigned", "failed"} <= kinds
    failed_issue = next(i for i in issues if i["kind"] == "failed")
    assert "giới hạn" in failed_issue["fix"].lower()
    assert issues[0]["severity"] == "critical"  # nặng nhất trước


# ------------------------------------------------------------------ #
# Chống đơ: is_running trên luồng giao diện không bao giờ chặn
# ------------------------------------------------------------------ #
def test_is_running_nonblocking_on_main_thread(monkeypatch):
    calls = []

    def slow_probe(port, timeout=0.6):
        calls.append(port)
        time.sleep(0.8)
        return port == 1

    monkeypatch.setattr(chrome_manager, "_probe_port", slow_probe)
    manager = chrome_manager.ChromeManager()
    manager.ui_nonblocking = True
    manager.PROBE_INTERVAL = 0.05
    assert threading.current_thread() is threading.main_thread()
    started = time.perf_counter()
    for port in range(1, 21):  # 20 hồ sơ
        manager.is_running({"port": port})
    assert time.perf_counter() - started < 0.2  # bản cũ: 20 × 0.6s
    deadline = time.time() + 5
    while time.time() < deadline and not manager.is_running({"port": 1}):
        time.sleep(0.05)
    assert manager.is_running({"port": 1}) is True
    assert manager.is_running({"port": 2}) is False
    manager.stop_prober()


def test_board_model_puts_lead_first(world):
    from app.ui.supervision_panel import build_board_model

    store, a1, p1 = world["store"], world["a1"], world["p1"]
    store.create_command("free", profile_id=p1["id"], profile_slug=p1["slug"], instruction="x")
    model = build_board_model(store.list_agents(), store.list_open_commands(), a1["id"],
                              owner_by_profile={p1["id"]: world["a2"]["id"]})
    assert model["lanes"][0]["is_lead"] is True
    assert model["counts"]["total"] == 1


def test_supervision_panel_lead_picker_saves(world, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QApplication

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    QApplication.instance() or QApplication([])
    from app.ui.supervision_panel import SupervisionPanel

    settings = {}
    panel = SupervisionPanel(world["store"], settings=settings)
    index = panel.lead_combo.findData(world["a1"]["id"])
    panel.mode_combo.setCurrentIndex(panel.mode_combo.findData("lead"))
    panel.lead_combo.setCurrentIndex(index)
    assert settings["supervision_lead_agent_id"] == world["a1"]["id"]
    assert "trưởng phòng" in panel.status_label.text().lower()
    assert panel.team_chart._lead is not None
