"""V6.4.3 — chat trực tiếp muse.ai qua cầu nối trình duyệt."""

from __future__ import annotations

import os

import pytest

from app import muse_chat_bridge as mcb
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    st = Store(tmp_path / "t.db")
    yield st


class Clock:
    def __init__(self):
        self.t = 0.0

    def __call__(self):
        return self.t


def test_reply_tracker_waits_for_busy_and_settle():
    clock = Clock()
    tr = mcb.ReplyTracker(settle_s=1.5, first_token_s=10, clock=clock)
    assert tr.feed({"text": "", "busy": True}) == ("", False, False)
    clock.t = 1
    assert tr.feed({"text": "Chào", "busy": True})[1:] == (True, False)
    clock.t = 5
    assert tr.feed({"text": "Chào bạn", "busy": True})[2] is False  # còn busy
    clock.t = 5.5
    assert tr.feed({"text": "Chào bạn", "busy": False})[2] is False  # chưa đứng yên đủ
    clock.t = 6.6
    assert tr.feed({"text": "Chào bạn", "busy": False}) == ("Chào bạn", False, True)


def test_reply_tracker_gives_up_without_text():
    clock = Clock()
    tr = mcb.ReplyTracker(first_token_s=10, clock=clock)
    clock.t = 11
    assert tr.feed({"text": "", "busy": False})[2] is True


class FakeClient:
    def __init__(self, samples, composer=True, loginish=True):
        self.loginish = loginish
        self.samples = list(samples)
        self.composer = composer
        self.typed = []
        self.closed = False

    def evaluate(self, expr, timeout=None):
        if "ccd:bridge-composer" in expr:
            return self.composer
        if "ccd:muse-state" in expr:
            return {"url": "https://muse.ai/", "hasComposer": False, "loginish": self.loginish}
        if "ccd:bridge-read" in expr:
            return self.samples.pop(0) if len(self.samples) > 1 else self.samples[0]
        if "data-ccd-push" in expr:
            return 0
        return "button"

    def call(self, method, params=None):
        self.typed.append(params["text"])
        return {}

    def press_key(self, key):
        return {}

    def close(self):
        self.closed = True


class FakeManager:
    def __init__(self):
        self.launched = 0

    def is_running(self, profile):
        return True

    def launch(self, profile, start_minimized=True):
        self.launched += 1


def test_chat_bridge_types_verbatim_and_streams(monkeypatch):
    import threading

    client = FakeClient([
        {"text": "", "busy": True},
        {"text": "Mình", "busy": True},
        {"text": "Mình đang làm", "busy": True},
        {"text": "Mình đang làm ngay.", "busy": False},
    ])
    monkeypatch.setattr(mcb, "_muse_page", lambda port: {"webSocketDebuggerUrl": "ws://x"})
    clock = Clock()
    real_tracker = mcb.ReplyTracker

    def fake_sleep(s):
        clock.t += s

    monkeypatch.setattr(mcb, "ReplyTracker", lambda: real_tracker(clock=clock))
    events, done = [], threading.Event()

    def emit(ev):
        events.append(ev)
        if ev["kind"] == "reply" and ev["done"]:
            done.set()

    bridge = mcb.ChatBridge(FakeManager(), emit, sleep=fake_sleep, client_factory=lambda ws: client)
    bridge.send({"id": 7, "name": "A", "email": "a@x.com"}, "Đăng video kênh 3 giúp mình")
    assert done.wait(5)
    assert client.typed == ["Đăng video kênh 3 giúp mình"]  # nguyên văn, không bọc lời nhắc phiếu
    assert events[0]["kind"] == "sent"
    finals = [e for e in events if e["kind"] == "reply" and e["done"]]
    assert finals[-1]["text"] == "Mình đang làm ngay."
    assert client.closed


def test_chat_bridge_asks_login_when_no_composer(monkeypatch):
    import threading

    client = FakeClient([{"text": "", "busy": False}], composer=False)
    monkeypatch.setattr(mcb, "_muse_page", lambda port: {"webSocketDebuggerUrl": "ws://x"})
    monkeypatch.setattr(mcb.ChatBridge, "LOGIN_WAIT_S", 8.0)
    events, done = [], threading.Event()

    def emit(ev):
        events.append(ev)
        if ev["kind"] == "error":
            done.set()

    bridge = mcb.ChatBridge(FakeManager(), emit, sleep=lambda s: None, client_factory=lambda ws: client)
    bridge.send({"id": 3, "name": "B", "email": "b@x.com"}, "hi")
    assert done.wait(5)
    kinds = [e["kind"] for e in events]
    assert kinds[0] == "login" and kinds[-1] == "error"


def test_task_text_and_classify():
    text = mcb.task_text({"id": "c1", "type": "upload", "instruction": "Đăng video A", "payload": {}},
                         "Kênh Mèo", "○ 1. Mở Studio")
    assert "giao việc #c1" in text and "Đăng video A" in text and "Kênh Mèo" in text  # V6.6: trưởng phòng giao
    assert mcb.classify_reply("KẾT QUẢ: đã đăng xong") == "done"
    assert mcb.classify_reply("Cần bạn nhập mã xác minh") == "needs_user"
    assert mcb.classify_reply("Mình đang mở Studio") == "running"


def test_store_update_message_body_changes_signature(store):
    agent = store.create_agent("A", "a@x.com")
    msg = store.add_message(agent["id"], "agent", "Mình")
    before = store.messages_signature(agent["id"])
    store.update_message_body(msg["id"], "Mình đang làm")
    after = store.messages_signature(agent["id"])
    assert before[:3] == after[:3] and before != after
    assert store.get_message(msg["id"])["body"] == "Mình đang làm"


PAGE_DIFF = """<html><body><main><div class=list>
<div class=row><div class=bubble>Tin cũ</div></div>
<div class=row><div class=bubble><p>Đăng video kênh 3 giúp mình</p></div></div>
<div class=row><div class=ans><p>Được, mình mở Studio.</p><button>Copy</button></div></div>
</div><div><textarea>nháp</textarea><button aria-label="Stop">■</button></div></main></body></html>"""

PAGE_FOOTER = """<html><body><main><div class=list>
<div class=row><div class=bubble>Tin cũ</div></div></div>
<div><textarea></textarea></div><footer>Muse có thể mắc lỗi.</footer></main></body></html>"""

PAGE_ROLE = """<html><body>
<div data-message-author-role=user>Đăng video kênh 3 giúp mình</div>
<div data-message-author-role=assistant>Xong rồi <svg></svg></div>
<div data-message-author-role=user>Tin khác</div>
<textarea></textarea></body></html>"""


@pytest.mark.skipif(os.environ.get("CCD_SKIP_BROWSER") == "1", reason="không có Chromium")
def test_read_js_on_real_chromium():
    playwright = pytest.importorskip("playwright.sync_api")
    with playwright.sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        page.set_content(PAGE_DIFF)
        res = page.evaluate(mcb.read_expr("Đăng video kênh 3 giúp mình"))
        assert res["found"] and res["mode"] == "diff"
        assert res["text"] == "Được, mình mở Studio."
        assert res["busy"] is True
        # Chưa có trả lời: chữ chân trang có sẵn TRƯỚC khi gửi không bị lấy nhầm.
        page.set_content(PAGE_FOOTER)
        page.evaluate(mcb.BASELINE_JS)
        page.evaluate("document.querySelector('.list').insertAdjacentHTML('beforeend',"
                      " '<div class=row><div class=bubble>Đăng video kênh 3 giúp mình</div></div>')")
        assert page.evaluate(mcb.read_expr("Đăng video kênh 3 giúp mình"))["text"] == ""
        page.evaluate("document.querySelector('.list').insertAdjacentHTML('beforeend',"
                      " '<div class=row><div>Ok mình làm</div></div>')")
        assert page.evaluate(mcb.read_expr("Đăng video kênh 3 giúp mình"))["text"] == "Ok mình làm"
        page.set_content(PAGE_ROLE)
        res = page.evaluate(mcb.read_expr("Đăng video kênh 3 giúp mình"))
        assert res["mode"] == "role" and res["text"] == "Xong rồi" and res["busy"] is False
        assert page.evaluate(mcb.COMPOSER_JS) is True
        browser.close()


def test_main_window_bridge_events(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent = st.create_agent("Muse A", "a@x.com")
    cmd = st.create_command("free", instruction="Viết mô tả", agent_id=agent["id"])
    win = MainWindow(st, ChromeManager(), settings)
    try:
        base = {"agent_id": agent["id"], "job_id": 1, "command_id": cmd["id"]}
        win._on_bridge_event(dict(base, kind="sent"))
        win._on_bridge_event(dict(base, kind="reply", text="Mình", done=False))
        win._on_bridge_event(dict(base, kind="reply", text="KẾT QUẢ: xong mô tả", done=True))
        msgs = [m for m in st.list_messages(agent["id"]) if m["direction"] == "agent"]
        assert len(msgs) == 1 and msgs[0]["body"] == "KẾT QUẢ: xong mô tả"
        assert st.get_command(cmd["id"])["status"] == "done"
        assert st.get_agent(agent["id"])["web_state"] == "in"
    finally:
        win.close()


def test_dispatch_tick_sends_waiting_commands_once(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent = st.create_agent("Muse A", "a@x.com")
    cmd = st.create_command("free", instruction="Viết mô tả", agent_id=agent["id"])
    st.update_command(cmd["id"], status="waiting_muse")
    win = MainWindow(st, ChromeManager(), settings)
    sent = []

    class Bridge:
        def send(self, a, text, command_id=None):
            sent.append((a["id"], text, command_id))

        def pending(self, agent_id):
            return 0

    win._chat_bridge = Bridge()
    try:
        win._bridge_dispatch_tick()
        win._bridge_dispatch_tick()
        assert len(sent) == 1 and sent[0][2] == cmd["id"] and "Viết mô tả" in sent[0][1]
    finally:
        win.close()


@pytest.fixture(scope="module")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_missing_composer_without_logout_does_not_trigger_login(monkeypatch):
    """V6.5.2: không thấy ô chat nhưng trang KHÔNG báo đăng xuất → không
    mở luồng đăng nhập lại (bản cũ mở trình duyệt đăng nhập liên tục)."""
    import threading

    client = FakeClient([{"text": "", "busy": False}], composer=False, loginish=False)
    monkeypatch.setattr(mcb, "_muse_page", lambda port: {"webSocketDebuggerUrl": "ws://x"})
    events, done = [], threading.Event()

    def emit(ev):
        events.append(ev)
        if ev["kind"] == "error":
            done.set()

    bridge = mcb.ChatBridge(FakeManager(), emit, sleep=lambda s: None, client_factory=lambda ws: client)
    bridge.send({"id": 4, "name": "C", "email": "c@x.com"}, "hi")
    assert done.wait(5)
    assert [e["kind"] for e in events] == ["error"]


def test_launch_hidden_uses_offscreen_flags(tmp_path, monkeypatch):
    from app import chrome_manager

    captured = {}

    class P:
        def poll(self):
            return None

    monkeypatch.setattr(chrome_manager.config, "find_chrome", lambda override=None: "chrome.exe")
    monkeypatch.setattr(chrome_manager.subprocess, "Popen", lambda args, **k: captured.setdefault("args", args) and P())
    opened = iter([False, True])
    monkeypatch.setattr(chrome_manager.cdp, "debug_port_open", lambda port, timeout=1.0: next(opened, True))
    manager = chrome_manager.ChromeManager()
    profile = {"slug": "agent-1", "port": 9555, "label": "Muse A", "user_data_dir": str(tmp_path / "u"),
               "start_url": "https://muse.ai/"}
    assert manager.launch(profile, hidden=True) == "launched"
    args = captured["args"]
    assert "--window-position=-32000,-32000" in args and "--disable-renderer-backgrounding" in args
    assert "--start-minimized" not in args
