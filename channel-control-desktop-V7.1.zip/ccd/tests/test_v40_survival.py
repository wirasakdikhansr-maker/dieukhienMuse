"""V4.0 (H4 + H7) — Gói sống sót & hợp nhất phiên bản.

instance_guard (thông điệp focus, dựng lệnh autostart, khoá Run qua
registry GIẢ) và watchdog (chính sách mở lại) là logic thuần — kiểm
thử không cần Windows/Qt thật. Hiệu ứng thật trên Windows (hiện cửa
số bản chính, app tự lên sau đăng nhập) vẫn cần nghiệm thu tay.
"""

from app import instance_guard
from app.watchdog import RestartPolicy, run_watchdog


def test_focus_message_roundtrip_and_garbage():
    data = instance_guard.build_focus_message(["--autostart"])
    parsed = instance_guard.parse_focus_message(data)
    assert parsed == {"action": "focus", "args": ["--autostart"]}
    assert instance_guard.parse_focus_message(b"rac{") is None
    assert instance_guard.parse_focus_message(b'{"action":"other"}') is None


def test_autostart_command_frozen_and_source():
    frozen = instance_guard.build_autostart_command("C:/CCD/app.exe", frozen=True)
    assert frozen == '"C:/CCD/app.exe" --watchdog --autostart'
    source = instance_guard.build_autostart_command(
        "C:/Python/python.exe", script_path="C:/CCD/run_exe.py", frozen=False
    )
    assert source == '"C:/Python/python.exe" "C:/CCD/run_exe.py" --watchdog --autostart'


class FakeRegistry:
    HKEY_CURRENT_USER = "HKCU"
    KEY_SET_VALUE = 0x2
    REG_SZ = 1

    def __init__(self):
        self.values = {}
        self.opened = []

    def OpenKey(self, root, path, reserved, access):
        self.opened.append((root, path))
        return "KEY"

    def SetValueEx(self, key, name, reserved, type_, value):
        self.values[name] = value

    def DeleteValue(self, key, name):
        if name not in self.values:
            raise FileNotFoundError(name)
        del self.values[name]

    def CloseKey(self, key):
        pass


def test_set_autostart_with_fake_registry():
    registry = FakeRegistry()
    assert (
        instance_guard.set_autostart(True, '"app.exe" --autostart', registry=registry)
        == "ok"
    )
    assert registry.values[instance_guard.AUTOSTART_VALUE_NAME] == '"app.exe" --autostart'
    assert instance_guard.set_autostart(False, "", registry=registry) == "ok"
    assert registry.values == {}
    # Tắt khi chưa từng bật: không lỗi.
    assert instance_guard.set_autostart(False, "", registry=registry) == "ok"


def test_set_autostart_noop_off_windows():
    # Máy chạy test là Linux: không truyền registry → noop có lý do.
    assert instance_guard.set_autostart(True, "x").startswith("noop")


def test_clean_exit_flag_roundtrip(tmp_path):
    assert instance_guard.was_clean_exit(tmp_path) is False
    instance_guard.mark_clean_exit(tmp_path)
    assert instance_guard.was_clean_exit(tmp_path) is True
    instance_guard.clear_clean_exit(tmp_path)
    assert instance_guard.was_clean_exit(tmp_path) is False


def test_watchdog_policy_caps_restarts_per_hour():
    policy = RestartPolicy(max_restarts=2, window_seconds=3600)
    assert policy.allow_restart(1000.0) is True
    assert policy.allow_restart(1010.0) is True
    assert policy.allow_restart(1020.0) is False
    # Ngoài cửa sổ một giờ -> ngân sách hồi lại.
    assert policy.allow_restart(1000.0 + 3601) is True


def test_watchdog_loop_clean_exit_stops_and_crashes_relaunch():
    codes = iter([1, 1, 0])
    calls = {"spawn": 0, "sleep": 0}

    def spawn():
        calls["spawn"] += 1
        return next(codes)

    result = run_watchdog(
        spawn,
        policy=RestartPolicy(max_restarts=5),
        sleep_fn=lambda _s: calls.__setitem__("sleep", calls["sleep"] + 1),
        now_fn=lambda: 5000.0,
        restart_delay=0,
    )
    assert result == 0
    assert calls == {"spawn": 3, "sleep": 2}

    calls2 = {"spawn": 0}
    result2 = run_watchdog(
        lambda: calls2.__setitem__("spawn", calls2["spawn"] + 1) or 7,
        policy=RestartPolicy(max_restarts=2),
        sleep_fn=lambda _s: None,
        now_fn=lambda: 5000.0,
        restart_delay=0,
    )
    assert result2 == 7
    assert calls2["spawn"] == 3  # lần đầu + 2 lần mở lại rồi dừng


def test_split_child_argv_drops_watchdog_flag():
    assert instance_guard.split_child_argv(
        ["--watchdog", "--autostart"]
    ) == ["--autostart"]


def test_versions_unified_at_v40():
    import app
    from app.agent_server import AGENT_API_VERSION
    from app.store import SCHEMA_VERSION

    # V4.3: bảng việc theo Muse + thư viện Skill + theme + zoom
    # nhúng (xem UI_V43_PLAN) — pin phiên bản cập nhật CÙNG bump.
    # V4.3.1: thống nhất giao diện Concept D + Công việc 2 cột —
    # pin cập nhật cùng bump này (chỉ đổi hình thức, schema/API giữ).
    # V4.3.2: vòng sửa lỗi nghiệm thu máy thật (nền Văn phòng, bỏ
    # panel tiêu đề, cột bảng tự lưu…) — pin cập nhật cùng bump.
    # V4.4: điều khiển Studio qua Chrome nhúng — loại lệnh mới
    # studio_script + giao file theo lệnh (bề mặt API đổi → API
    # 2.4 → 2.5); schema DB vẫn giữ 7.
    # V4.5: thiết kế MetaMint + tường trình duyệt + Công việc làm
    # lại + lô kênh checkbox + tự chạy lại 30s (trạng thái trong
    # payload) — API giữ 2.5, schema DB vẫn giữ 7.
    # V4.6: chat hai chiều theo từng Muse trong app — bề mặt API
    # đổi (endpoint messages) → API 2.6; thêm bảng agent_messages
    # → schema DB 8.
    # V5.1: bản thiết kế lại theo plan duyệt 2026-10-30 (theme
    # epoch, panel chi tiết dựng lại, Công việc dạng thẻ, thanh
    # chip Hồ sơ) — API giữ 2.6, schema giữ 8.
    # V5.2: vòng sửa lỗi máy thật — hiệu năng (QSS trước dựng UI,
    # vân rẻ cho các nhịp nền), bỏ thanh chip + focus, tường trình
    # duyệt thẳng hàng + chỉ-nhúng + zoom mọi lần nhúng, tài sản
    # ảnh thật (avatar robot + nền văn phòng) — API giữ 2.6,
    # schema giữ 8.
    # V5.2.1: bản vá một mục từ góp ý máy thật (chat thu/mở trong
    # panel chi tiết Văn phòng) — pin cập nhật cùng bump như lệ.
    # V5.3: vòng gọn giao diện + trình duyệt linh hoạt (bỏ toast/
    # banner, bảng gọn đệm 2px, tường ô 600×800 ≤3/hàng, trình
    # duyệt khởi động cùng tool, chế độ chạy ẩn ngoài app, nền
    # Văn phòng đổi được) — API giữ 2.6, schema giữ 8.
    assert app.__version__ == "7.1.0"  # pin phiên bản: cập nhật theo mỗi lần bump (V6.4.2)
    assert app.DISPLAY_VERSION == "V7.1"
    assert SCHEMA_VERSION == 12  # V7.0: v12 = đa nền tảng (platform). V6.3: v11 lịch sử bước
    assert AGENT_API_VERSION == "2.8"  # V6.1: due_at (V6.0: verdict + scorecard)
