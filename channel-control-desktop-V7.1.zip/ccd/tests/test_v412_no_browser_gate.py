"""V4.1.2 — lệnh KHÔNG bị giữ vì web/Chrome chưa mở hay chưa đăng nhập.

Yêu cầu người dùng (2026-10-29): "khi đã chạy có nghĩa là đã cấp lệnh
đầy đủ, Muse chỉ việc làm theo yêu cầu". Trước V4.1.2, AgentServer
tiêm hooks preflight (mở Chrome/kiểm tra đăng nhập/thử đăng nhập) cho
dispatcher: hồ sơ chưa mở web hoặc chưa đăng nhập là lệnh create_video
/ optimize / upload bị giữ ở 'queued' ("Chuẩn bị chưa xong…") hoặc bị
đẩy sang needs_user TRƯỚC KHI Muse thấy lệnh. Nay đường giao lệnh
của server luôn chạy không hooks — kiểm chứng ở đúng tầng server:
dù nơi khởi tạo có truyền hooks "độc" (probe luôn False, attempt luôn
ném lỗi), lệnh vẫn phải lên 'waiting_muse'.
"""

from app import config
from app.agent_server import AgentServer
from app.store import Store


def _poison_hooks():
    def boom(profile):
        raise RuntimeError("web chưa mở — hooks độc không được phép chạy")

    return {
        "ensure_browser_open": boom,
        "probe_logged_in": lambda profile: False,
        "attempt_login": boom,
    }


def test_server_tick_promotes_despite_poison_hooks(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    store = Store(config.db_path(data_dir))
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    cmd = store.create_command(
        "create_video",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        instruction="Tạo video theo yêu cầu",
    )
    store.close()

    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0, "full_auto_enabled": True},
        auto_hooks=_poison_hooks(),
    )
    server._run_auto_tick()

    check = Store(config.db_path(data_dir))
    try:
        row = check.get_command(cmd["id"])
        assert row["status"] == "waiting_muse"
        assert "Chuẩn bị" not in (row.get("step") or "")
    finally:
        check.close()
