"""V7.0 — CSDL tự sửa, Chrome muse.ai không cửa sổ, luồng trao đổi đầy đủ,
đa nền tảng (Facebook/TikTok), logo kênh, trưởng phòng trả lời thay chủ kênh,
hiển thị thao tác tự động, danh sách kênh kéo cao được."""

from __future__ import annotations

import os
import sqlite3

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import db_health, lead_answer, muse_control, office_feed, platforms  # noqa: E402
from app.store import Store  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


# --------------------------------------------------------------------------- #
# 1. CSDL hỏng → tự sửa
# --------------------------------------------------------------------------- #
def test_db_repair_salvages_and_uses_backup(tmp_path):
    db = tmp_path / "channel_control.sqlite3"
    st = Store(db)
    st.create_agent("A", "a@x.com")
    for i in range(1500):
        st.create_command("free", instruction="x" * 150 + str(i))
    st.close()
    assert db_health.backup_now(db) is not None
    st = Store(db)
    st.create_agent("B", "b@x.com")
    st.close()
    with open(db, "r+b") as f:  # phá vài trang giữa file
        f.seek(4096 * 60)
        f.write(os.urandom(4096 * 4))
    assert db_health.quick_check(db) != "ok"
    report = db_health.ensure_healthy(db)
    assert report is not None and report["ok"]
    assert "đã tự sửa" in db_health.describe(report)
    fixed = Store(db)
    names = {a["name"] for a in fixed.list_agents()}
    assert {"A", "B"} <= names
    assert len(fixed.list_commands(limit=5000)) >= 1400
    assert (tmp_path / "backups").exists()
    assert db_health.ensure_healthy(db) is None  # đã lành


def test_backup_skips_corrupt_and_prunes(tmp_path):
    db = tmp_path / "x.sqlite3"
    Store(db).close()
    for _ in range(8):
        db_health.backup_now(db, keep=3, tag="t")
    assert len(list((tmp_path / "backups").glob("x-*.sqlite3"))) <= 3


# --------------------------------------------------------------------------- #
# 2. Chrome cầu nối muse.ai không cửa sổ
# --------------------------------------------------------------------------- #
def test_bridge_launches_headless(monkeypatch):
    from app import muse_chat_bridge

    calls = []

    class Manager:
        def launch(self, profile, hidden=None, headless=False, start_minimized=None):
            calls.append((hidden, headless))
            return "launched"

    monkeypatch.setattr(muse_chat_bridge, "HEADLESS", True)
    muse_chat_bridge._launch_hidden(Manager(), {"slug": "a", "port": 1})
    assert calls[-1] == (True, True)

    class OldManager:
        def launch(self, profile, hidden=None, start_minimized=None):
            calls.append(("old", hidden))

    muse_chat_bridge._launch_hidden(OldManager(), {"slug": "a", "port": 1})
    assert calls[-1] == ("old", True)


def test_headless_user_agent_has_no_headless_word(tmp_path):
    from app import chrome_manager

    (tmp_path / "131.0.6778.86").mkdir()
    ua = chrome_manager._desktop_ua(str(tmp_path / "chrome.exe"))
    assert "Chrome/131.0.0.0" in ua and "Headless" not in ua


# --------------------------------------------------------------------------- #
# 3. Luồng trao đổi đầy đủ
# --------------------------------------------------------------------------- #
def test_feed_full_text_keeps_lines_and_panel_expands(qapp, store):
    from app.ui.office_iso import OfficeIsoView

    long = "Dòng 1: phân tích page Hilong\n\nDòng 2: " + "chi tiết " * 80 + "\nDòng 3: kết luận"
    assert office_feed.full_text(long).count("\n") == 3
    assert office_feed.full_text(long).endswith("Dòng 3: kết luận")
    view = OfficeIsoView(store, {})
    view.resize(1400, 800)
    feed = view.feed
    feed.set_feed([{"id": 1, "kind": "agent", "agent_id": 1, "agent": "A", "time": "01:26",
                    "text": "tóm tắt…", "full": long, "verdict": "running"}], "work")
    holder = feed.list.itemAt(0).widget()
    label = holder.findChild(type(feed.title).__mro__[0]) if False else holder.layout().itemAt(1).widget()
    assert "Dòng 3: kết luận" in label.text() and "<br>" in label.text()
    feed.full_button.setChecked(False)
    label = feed.list.itemAt(0).widget().layout().itemAt(1).widget()
    assert "Dòng 3" not in label.text()
    view.show()
    before = view.body_split.sizes()
    view.toggle_feed_expanded()
    after = view.body_split.sizes()
    assert after[-1] > before[-1] and feed.expand_button.text().startswith("⤡")
    view.toggle_feed_expanded()
    assert feed.expand_button.text().startswith("⤢")
    view.close()


# --------------------------------------------------------------------------- #
# 4. Đa nền tảng
# --------------------------------------------------------------------------- #
def test_cookie_header_parsing_and_session():
    cookies = platforms.parse_cookies_text("c_user=1000123; xs=33%3Aabc; datr=zz; fr=1", "facebook")
    assert {c["name"] for c in cookies} == {"c_user", "xs", "datr", "fr"}
    assert all(c["domain"] == ".facebook.com" for c in cookies)
    assert platforms.has_session(cookies, "facebook")
    assert platforms.account_id_from_cookies(cookies, "facebook") == "1000123"
    assert not platforms.has_session([c for c in cookies if c["name"] != "xs"], "facebook")
    json_text = ('[{"name":"sessionid","value":"s","domain":".tiktok.com"},'
                 '{"name":"SID","value":"g","domain":".google.com"}]')
    tt = platforms.parse_cookies_text(json_text, "tiktok")
    assert [c["name"] for c in tt] == ["sessionid"] and platforms.has_session(tt, "tiktok")
    assert platforms.detect_from_url("https://www.facebook.com/x") == "facebook"


def test_scan_parsers():
    pages = platforms.parse_fb_pages([
        {"channel_id": "fb:hilong.page", "name": "Hilong", "handle": "hilong.page",
         "url": "https://www.facebook.com/hilong.page", "avatar_url": "https://scontent/x.jpg"},
        {"channel_id": "", "name": "x"}])
    assert len(pages) == 1 and pages[0]["platform"] == "facebook"
    tt = platforms.parse_tiktok_self({"uid": "77", "uniqueId": "kenh.tt", "nickName": "Kênh TT",
                                      "avatar": "https://p16/x.jpg", "followers": 1200, "videos": 40})
    assert tt["channel_id"] == "tt:77" and tt["handle"] == "@kenh.tt" and tt["subs"] == 1200
    assert platforms.parse_tiktok_self({}) is None


def test_store_platform_profiles_and_channels(store):
    p = store.add_profile("Facebook Hilong", "hilong@x.com", platform="facebook")
    assert store.get_profile(p["id"])["platform"] == "facebook"
    store.upsert_channel(p["id"], {"channel_id": "fb:1", "name": "Hilong"})
    assert store.list_channels(p["id"])[0]["platform"] == "facebook"
    yt = store.add_profile("YT", "yt@gmail.com")
    store.upsert_channel(yt["id"], {"channel_id": "UC1", "name": "K"})
    assert store.list_channels(yt["id"])[0]["platform"] == "youtube"
    with pytest.raises(ValueError):
        store.set_profile_platform(p["id"], "myspace")


def test_platform_templates_and_task_context(qapp, store, tmp_path):
    from app.ui.assign_dialog import AssignDialog

    p = store.add_profile("TT", "tt@x.com", platform="tiktok")
    store.upsert_channel(p["id"], {"channel_id": "tt:1", "name": "Kênh TT", "url": "https://www.tiktok.com/@k"})
    channel = store.list_channels(p["id"])[0]
    dialog = AssignDialog(store, agent=None, profile=p, channel=channel, base=tmp_path / "data")
    titles = [dialog.editor.template_list.item(i).text() for i in range(dialog.editor.template_list.count())]
    assert titles[0].startswith("TikTok ·")
    context = platforms.task_context(p, channel)
    assert "TikTok" in context and "tiktok.com/@k" in context
    assert platforms.task_context(store.add_profile("Y", "y@gmail.com"), None) == ""


def test_scanner_routes_social_profiles(monkeypatch, store):
    from app import scanner

    p = store.add_profile("FB", "fb@x.com", platform="facebook")
    seen = []
    monkeypatch.setattr(platforms, "scan_profile", lambda st, prof, mgr, log=None: seen.append(prof["id"]) or
                        {"status": "ok", "channels": [], "message": "ok"})
    assert scanner.scan_profile(store, store.get_profile(p["id"]), None)["status"] == "ok"
    assert seen == [p["id"]]


# --------------------------------------------------------------------------- #
# 5. Logo kênh trên bảng Agents
# --------------------------------------------------------------------------- #
def test_agent_board_shows_real_logo(qapp, store, tmp_path, monkeypatch):
    from PySide6.QtGui import QColor, QImage

    from app.ui import agent_board, channel_logos, work_model

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    agent = store.create_agent("A", "a@x.com")
    profile = store.add_profile("P", "p@gmail.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    store.upsert_channel(profile["id"], {"channel_id": "UClogo", "name": "Kênh Logo",
                                         "avatar_url": "https://yt3.example/x.jpg"})
    image = QImage(64, 64, QImage.Format.Format_RGB32)
    image.fill(QColor("#FF0000"))
    path = channel_logos.logo_path("UClogo")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(str(path), "PNG")
    board = agent_board.AgentBoardWidget(store, tmp_path / "data")
    profiles = store.list_profiles()
    board.set_model(work_model.build_work_model(
        store.list_commands(limit=50), store.list_agents(), profiles,
        {pr["id"]: store.list_channels(pr["id"]) for pr in profiles}))
    card = board.channel_card(board.channel_keys()[0])
    assert card.logo_is_real
    assert channel_logos.pixmap({"channel_id": "UClogo", "platform": "facebook"}, 40) is not None


# --------------------------------------------------------------------------- #
# 6. Trưởng phòng trả lời thay chủ kênh
# --------------------------------------------------------------------------- #
def test_lead_answer_helpers():
    assert lead_answer.human_only("Bạn gửi giúp mã 2FA nhé")
    assert lead_answer.human_only("cần mật khẩu tài khoản")
    assert not lead_answer.human_only("Bạn cho đăng luôn hay chỉ làm nháp?")
    cmd = {"id": "abc123", "type": "free", "instruction": "Phân tích page Hilong", "payload": {}}
    prompt = lead_answer.lead_prompt(cmd, "lucas", "Đăng luôn hay nháp?", {})
    assert "TRẢ LỜI #abc123" in prompt and "CHÍNH SÁCH" in prompt
    assert lead_answer.extract_answer("TRẢ LỜI #abc123: Đăng luôn, 1 bài/ngày") == "Đăng luôn, 1 bài/ngày"
    assert "Làm tiếp NGAY" in lead_answer.forward_text(cmd, "Đăng luôn")
    assert "ĐĂNG CÔNG KHAI" in lead_answer.policy_answer(cmd, "?", {})
    assert lead_answer.policy({"lead_policy": "Chỉ đăng nháp"}) == "Chỉ đăng nháp"


def _window(tmp_path, monkeypatch, qapp):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    win = MainWindow(st, ChromeManager(), settings)
    return st, win, settings


class _Bridge:
    def __init__(self):
        self.sent = []

    def send(self, agent, text, command_id=None):
        self.sent.append((int(agent["id"]), text, command_id))

    def pending(self, agent_id):
        return 0


def test_question_goes_to_lead_and_answer_is_forwarded(qapp, tmp_path, monkeypatch):
    st, win, settings = _window(tmp_path, monkeypatch, qapp)
    try:
        worker = st.create_agent("lucas", "l@x.com")
        lead = st.create_agent("lead", "lead@x.com")
        settings["supervision_lead_id"] = lead["id"]
        from app import supervision

        monkeypatch.setattr(supervision, "lead_agent_id", lambda store, cfg: lead["id"])
        bridge = _Bridge()
        monkeypatch.setattr(win, "_ensure_chat_bridge", lambda: bridge)
        cmd = st.create_command("free", instruction="Phân tích page Hilong", agent_id=worker["id"])
        st.update_command(cmd["id"], status="running")
        question = "Bạn cho đăng luôn hay chỉ làm nháp để bạn duyệt trước?\nLàm dạng nào, bao nhiêu bài?"
        win._apply_bridge_reply(cmd["id"], question, from_agent_id=worker["id"])
        row = st.get_command(cmd["id"])
        assert row["status"] == "running" and row["payload"]["lead_q"]["lead_id"] == lead["id"]
        assert bridge.sent[-1][0] == lead["id"] and "TRẢ LỜI" in bridge.sent[-1][1]
        win._apply_bridge_reply(cmd["id"], f"TRẢ LỜI #{cmd['id']}: Đăng luôn, Reels 60 giây, 1 bài/ngày",
                                from_agent_id=lead["id"])
        assert bridge.sent[-1][0] == worker["id"] and "Đăng luôn, Reels 60 giây" in bridge.sent[-1][1]
        row = st.get_command(cmd["id"])
        assert "lead_q" not in row["payload"] and row["status"] == "running"
        # câu hỏi cần người thật (2FA) vẫn về người dùng
        cmd2 = st.create_command("free", instruction="Đăng nhập", agent_id=worker["id"])
        st.update_command(cmd2["id"], status="running")
        win._apply_bridge_reply(cmd2["id"], "CẦN BẠN: nhập mã 2FA của Studio", from_agent_id=worker["id"])
        assert st.get_command(cmd2["id"])["status"] == "needs_user"
    finally:
        win.close()


def test_no_lead_uses_policy_and_acked_resume_sends_short(qapp, tmp_path, monkeypatch):
    st, win, settings = _window(tmp_path, monkeypatch, qapp)
    try:
        worker = st.create_agent("solo", "s@x.com")
        from app import supervision

        monkeypatch.setattr(supervision, "lead_agent_id", lambda store, cfg: None)
        bridge = _Bridge()
        monkeypatch.setattr(win, "_ensure_chat_bridge", lambda: bridge)
        cmd = st.create_command("free", instruction="Làm page", agent_id=worker["id"])
        st.update_command(cmd["id"], status="running")
        win._apply_bridge_reply(cmd["id"], "Bạn muốn đăng luôn hay nháp? Bạn chọn giúp?", from_agent_id=worker["id"])
        assert bridge.sent and "chính sách tự quyết" in bridge.sent[-1][1]
        assert st.get_command(cmd["id"])["payload"].get("acked")
        # việc đã nhận rồi chạy tiếp → tin ngắn, KHÔNG gửi lại trọn việc
        st.update_command(cmd["id"], status="waiting_muse")
        st.update_command_payload_flags(cmd["id"], clear_keys=("chat_sent",))
        settings["office_mode"] = "work"
        win._bridge_dispatch_tick()
        last = bridge.sent[-1][1] if bridge.sent else ""
        if last:  # cầu nối giả có thể bị bỏ qua khi pending()
            assert "Tiếp tục việc" in last and "Nhận được việc chưa" not in last
    finally:
        win.close()


# --------------------------------------------------------------------------- #
# 7. Thao tác tự động hiển thị rõ
# --------------------------------------------------------------------------- #
class _Page:
    def __init__(self):
        self.evals = []
        self.calls = []

    def navigate_and_wait(self, url, timeout=30):
        self.calls.append(("goto", url))

    def _find_element(self, selector=None, text=None):
        return {"x": 100, "y": 200, "visible": True, "text": text}

    def click_element(self, selector=None, text=None):
        self.calls.append(("click", text))
        return {"text": text}

    def press_key(self, key):
        self.calls.append(("key", key))

    def evaluate(self, expr, timeout=None):
        self.evals.append(expr)
        return {"url": "u", "title": "t", "text": "", "dialogs": [], "elements": []}


def test_run_actions_reports_steps_and_draws_overlay():
    page = _Page()
    steps = []
    actions = muse_control.parse_actions(
        '```ccd\n{"action":"goto","url":"https://www.facebook.com"}\n{"action":"click","text":"Tạo bài viết"}\n```')
    muse_control.run_actions(page, actions, sleep=lambda s: None,
                             on_step=lambda i, n, t, s: steps.append((i, n, s)), who="lucas")
    assert (1, 2, "run") in steps and (2, 2, "ok") in steps and steps[-1][2] == "done"
    overlay = [e for e in page.evals if "__ccd_bar" in e]
    assert overlay and any("100" in e and "200" in e for e in overlay)
    assert muse_control.describe({"action": "click", "text": "Đăng"}) == "bấm «Đăng»"


def test_window_shows_automation_strip(qapp, tmp_path, monkeypatch):
    st, win, _settings = _window(tmp_path, monkeypatch, qapp)
    try:
        profile = st.add_profile("KenhNhat", "k@gmail.com")
        win.refresh_profiles()
        win._last_user_input = 0.0
        win._on_control_step({"profile_id": profile["id"], "label": "KenhNhat", "agent": "Muse 01",
                              "index": 1, "total": 3, "text": "bấm «Tạo»", "state": "run"})
        assert win.automation_strip.isVisibleTo(win) or win._automation
        assert "bước 1/3" in win._automation_caption(win._automation[profile["id"]])
        assert win._current_profile_id == profile["id"]  # tự đưa trình duyệt đang điều khiển lên
        win._on_control_step({"profile_id": profile["id"], "label": "KenhNhat", "agent": "Muse 01",
                              "index": 3, "total": 3, "text": "xong 3 thao tác", "state": "done"})
        assert win._automation[profile["id"]]["state"] == "done"
    finally:
        win.close()


# --------------------------------------------------------------------------- #
# 8. Danh sách kênh liên quan kéo cao
# --------------------------------------------------------------------------- #
def test_channel_list_height_grip(qapp, store):
    from app.ui.commands_panel import CommandsPanel

    settings = {}
    panel = CommandsPanel(store, settings=settings)
    grip = panel.channel_grip
    assert grip.set_height(400) == 400 and panel.channel_scroll.height() == 400 or panel.channel_scroll.maximumHeight() == 400
    assert grip.set_height(5) == grip.MIN_H
    panel._save_channel_list_height(320)
    assert settings["work_channel_list_h"] == 320
    again = CommandsPanel(store, settings={"work_channel_list_h": 333})
    assert again.channel_scroll.maximumHeight() == 333


# --------------------------------------------------------------------------- #
# V7.0.1 — Chrome không hiện bong bóng dịch / khôi phục trang
# --------------------------------------------------------------------------- #
def test_quiet_preferences_and_flags(tmp_path):
    import json

    from app import chrome_manager

    prefs_path = tmp_path / "Default" / "Preferences"
    prefs_path.parent.mkdir(parents=True)
    prefs_path.write_text(json.dumps({"profile": {"exit_type": "Crashed", "name": "Giữ nguyên"},
                                      "translate": {"enabled": True}}), encoding="utf-8")
    assert chrome_manager.quiet_preferences(tmp_path)
    prefs = json.loads(prefs_path.read_text(encoding="utf-8"))
    assert prefs["profile"]["exit_type"] == "Normal" and prefs["profile"]["exited_cleanly"] is True
    assert prefs["profile"]["name"] == "Giữ nguyên"
    assert prefs["translate"]["enabled"] is False and prefs["credentials_enable_service"] is False
    assert chrome_manager.quiet_preferences(tmp_path / "moi")  # hồ sơ mới chưa có Preferences
    flags = " ".join(chrome_manager.ChromeManager.QUIET_FLAGS)
    assert "Translate" in flags and "--hide-crash-restore-bubble" in flags


def test_work_splitter_moves_freely(qapp, tmp_path, monkeypatch):
    st, win, _settings = _window(tmp_path, monkeypatch, qapp)
    try:
        from PySide6.QtCore import QCoreApplication

        from app.ui import main_window as mw

        win.resize(1918, 950)
        win.show()
        win._switch_section(mw.SEC_WORK)
        for _ in range(30):
            QCoreApplication.processEvents()
        sp = win.work_panel.splitter
        total = sum(sp.sizes())
        sp.setSizes([700, total - 700])
        assert sp.sizes()[0] == 700  # trước đây kẹt ở trần 470px
        assert win.work_panel.assign_scroll.maximumWidth() > 1000
        assert not sp.childrenCollapsible()
    finally:
        win.close()


def test_fb_scan_clicks_more_and_merges_virtualized_list():
    class Fake:
        """Danh sách ảo: mỗi lần chỉ thấy 4 page; 'Xem thêm' mở tiếp 4 page mới."""

        def __init__(self):
            self.window = 0
            self.navigations = 0

        def navigate(self, url):
            self.navigations += 1

        def evaluate(self, expr, timeout=None):
            if expr == "location.href":
                return "https://www.facebook.com/home"
            if "__FB_MORE" in expr or "xem th" in expr:
                if self.window < 3:
                    self.window += 1
                    return True
                return False
            if "scrollBy" in expr:
                return None
            start = self.window * 4
            return [{"channel_id": f"fb:p{i}", "name": f"Page {i}", "url": f"https://www.facebook.com/p{i}"}
                    for i in range(start, start + 4)]

    fake = Fake()
    pages = platforms.scan_fb_pages_live(fake, sleep=lambda s: None)
    assert len(pages) == 16 and fake.navigations == 1


def test_instruction_box_height_grip(qapp, store):
    from app.ui.commands_panel import CommandsPanel

    settings = {"work_instruction_h": 240}
    panel = CommandsPanel(store, settings=settings)
    assert panel.instruction_edit.maximumHeight() == 240
    panel.instruction_grip.set_height(400)
    assert panel.instruction_edit.maximumHeight() == 400
    panel._save_height("work_instruction_h", 400)
    assert settings["work_instruction_h"] == 400



# --------------------------------------------------------------------------- #
# V7.0.1 — trưởng phòng tự giao việc đều, chống trùng, chuẩn kiếm tiền
# --------------------------------------------------------------------------- #
def test_lead_planner_spreads_work_and_avoids_duplicates(store):
    from datetime import datetime, timedelta

    from app import lead_planner

    agents = [store.create_agent(f"M{i}", f"m{i}@x.com") for i in range(3)]
    profiles = []
    for i in range(4):
        p = store.add_profile(f"P{i}", f"p{i}@gmail.com")
        store.upsert_channel(p["id"], {"channel_id": f"UC{i}", "name": f"Kênh {i}"})
        profiles.append(p)
    store.assign_profiles(agents[0]["id"], [profiles[0]["id"]])
    now = datetime.now().astimezone().replace(hour=10)
    made = lead_planner.plan(store, {}, now)
    assert len(made) == 4
    owners = {store.agent_for_profile(p["id"])["id"] for p in profiles}
    assert len(owners) == 3  # hồ sơ chưa có chủ được chia cho agent ít việc
    text = made[0]["instruction"]
    assert "CHUẨN KIẾM TIỀN" in text and "KHÔNG reup" in text and "ĐẢM BẢO CÓ VIEW" in text
    assert lead_planner.plan(store, {}, now) == []  # đang có việc mở → không giao chồng
    for row in made:
        store.finish_command(row["id"], "done", result="Tiêu đề: Bí quyết ngủ ngon tuổi 60")
    assert lead_planner.plan(store, {}, now + timedelta(hours=1)) == []  # đủ quota hôm nay
    second = lead_planner.plan(store, {"lead_plan_quota": {"youtube": 2}, "lead_plan_min_gap_hours": 2},
                               now + timedelta(hours=3))
    assert len(second) == 4 and "Bí quyết ngủ ngon" in second[0]["instruction"]  # liệt kê để không lặp
    assert lead_planner.plan(store, {"lead_autoplan": False}, now) == []


def test_kickoff_opens_browser_at_work_page(qapp, tmp_path, monkeypatch):
    st, win, _settings = _window(tmp_path, monkeypatch, qapp)
    try:
        agent = st.create_agent("A", "a@x.com")
        p = st.add_profile("KenhNhat", "k@gmail.com")
        st.upsert_channel(p["id"], {"channel_id": "UCabc", "name": "Kênh"})
        cmd = st.create_command("upload", instruction="Đăng video", agent_id=agent["id"], profile_id=p["id"],
                                channel_id="UCabc")
        calls = []
        monkeypatch.setattr(win, "_open_for_muse", lambda prof: calls.append(("open", prof["id"])))
        monkeypatch.setattr(win, "_start_control_round",
                            lambda ag, prof, actions, cid, intro="": calls.append(("round", actions, intro)))
        assert win._kickoff_browser(st.get_command(cmd["id"]), agent)
        round_call = [c for c in calls if c[0] == "round"][0]
        assert round_call[1][1]["url"] == "https://studio.youtube.com/channel/UCabc"
        assert "MỞ SẴN" in round_call[2] and "```ccd```" in round_call[2]
        assert not win._kickoff_browser(st.get_command(cmd["id"]), agent)  # chỉ một lần mỗi việc
    finally:
        win.close()


def test_collapse_toggles_on_every_splitter(qapp):
    from PySide6.QtWidgets import QLabel, QSplitter, QVBoxLayout, QWidget

    from app.ui import collapse

    root = QWidget()
    lay = QVBoxLayout(root)
    sp = QSplitter()
    sp.addWidget(QLabel("trái"))
    sp.addWidget(QLabel("phải"))
    lay.addWidget(sp)
    root.resize(800, 400)
    root.show()
    settings = {}
    assert collapse.install(root, settings) == 1
    assert collapse.install(root, settings) == 0  # gọi lại vô hại
    assert sp.count() == 2  # nút không bị biến thành panel
    sp.setSizes([200, 600])
    toggle = sp.toggles[0]
    toggle.toggle()
    assert sp.sizes()[0] == 0 and settings["collapsed_panes"]
    toggle.toggle()
    assert sp.sizes()[0] > 0 and not settings["collapsed_panes"]
    root.close()
