"""V5.3.2 — Ô chat PHẲNG theo PHƯƠNG ÁN 1 chủ kênh duyệt
(2026-10-30 21:02; ảnh duyệt ui_chat_redesign_preview/
chat_redesign_v1.png, nửa trên).

Ghim CẤU TRÚC (không chỉ nhìn render):
- Hàng tin KHÔNG có QFrame bọc, KHÔNG widget nào trong luồng
  mang stylesheet nền/viền riêng — tin là chữ trần trên panel.
- Tin Muse: hàng tên gồm avatar tròn 28px (asset robot) + tên
  "Muse · <nhãn>" + giờ — CÙNG một hàng; thân tin thụt thẳng
  hàng với tên.
- Tin người dùng: căn phải toàn bộ, tên "Bạn" màu accent, không
  avatar.
- Ô nhập: dải theme.CHAT_COMPOSER_BG không viền, ô soạn trong
  suốt không viền, nút Gửi variant primary (viên accent đặc).
- Bản Văn phòng: khung chat không còn khung Panel riêng, lề
  ngoài = 0, bề ngang chat = bề ngang panel chi tiết (sát viền).
- Trạng thái đọc ở đầu ô chat: "đã đọc · HH:MM" sau khi luồng
  đã nạp + đánh dấu đã đọc.
"""

from __future__ import annotations

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QLabel, QWidget

from app import config
from app.store import Store
from app.ui import theme
from app.ui.agent_chat import AgentChatWidget, _fmt_time_short


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    instance = Store(config.db_path())
    yield instance
    instance.close()


def _spin(qapp, times=6):
    for _ in range(times):
        qapp.processEvents()


def _rows(chat) -> list[QWidget]:
    rows = []
    for index in range(chat.thread_layout.count()):
        item = chat.thread_layout.itemAt(index)
        if item is not None and item.widget() is not None:
            rows.append(item.widget())
    return rows


def _labels(widget) -> list[QLabel]:
    return widget.findChildren(QLabel)


def _has_pixmap(label: QLabel) -> bool:
    pixmap = label.pixmap()
    return pixmap is not None and not pixmap.isNull()


def _seeded_chat(qapp, store, collapsible=False):
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.add_message(agent["id"], "agent", "Em đã xong bản nháp, anh xem giúp em nhé.")
    store.add_message(agent["id"], "user", "trả lời mày cần gì")
    store.add_message(
        agent["id"], "system", "Lệnh #abc đang chờ bạn xử lý: cần đăng nhập."
    )
    chat = AgentChatWidget(store, collapsible=collapsible)
    chat.resize(520, 640)
    chat.show()
    chat.set_agent(store.get_agent(agent["id"]))
    if collapsible:
        chat.expand_chat()
    _spin(qapp)
    return chat, agent


# ---------------------------------------------------------------------- #
# Không bong bóng — kiểm tra stylesheet/flag THẬT
# ---------------------------------------------------------------------- #
def test_message_rows_have_no_frame_or_own_background(qapp, store):
    chat, _agent = _seeded_chat(qapp, store)
    rows = _rows(chat)
    assert len(rows) == 3
    # Không QFrame nào bọc tin trong luồng. LƯU Ý kỹ thuật Qt:
    # QLabel KẾ THỪA QFrame nên findChildren(QFrame) luôn khớp
    # các nhãn — thứ cần ghim là không còn frame BỌC (type đúng
    # QFrame) và mọi QLabel đều NoFrame (không tự vẽ khung).
    frames = [
        w for w in chat.thread_host.findChildren(QFrame)
        if type(w) is QFrame
    ]
    assert frames == []
    for row in rows:
        assert type(row) is QWidget
        for label in row.findChildren(QLabel):
            assert label.frameShape() == QFrame.NoFrame
        for widget in row.findChildren(QWidget):
            sheet = widget.styleSheet()
            assert "background" not in sheet, (widget, sheet)
            assert "border" not in sheet, (widget, sheet)
    chat.close()


def test_bubble_style_constants_are_gone(qapp, store):
    from app.ui import agent_chat

    for gone in ("_USER_BUBBLE", "_AGENT_BUBBLE", "_SYSTEM_BUBBLE",
                 "_BUBBLE_MAX_WIDTH"):
        assert not hasattr(agent_chat, gone), gone


# ---------------------------------------------------------------------- #
# Tin Muse — avatar + tên + giờ cùng hàng, thân thụt thẳng hàng
# ---------------------------------------------------------------------- #
def test_agent_row_name_line_and_body_indent(qapp, store):
    chat, agent = _seeded_chat(qapp, store)
    row = _rows(chat)[0]
    labels = _labels(row)
    avatars = [l for l in labels if _has_pixmap(l)]
    assert len(avatars) == 1
    assert avatars[0].width() == 28 and avatars[0].height() == 28
    name = next(l for l in labels if l.text() == "Muse · KenhChinh")
    message = store.list_messages(agent["id"])[0]
    time_label = next(
        l for l in labels if l.text() == _fmt_time_short(message["created_at"])
    )
    # Avatar, tên, giờ CÙNG một hàng (chênh y không quá vài px —
    # avatar 28px cao hơn dòng chữ nên cho lệch tâm 6px).
    def _pos(label):
        return label.mapTo(row, label.rect().topLeft())

    assert abs(_pos(name).y() - _pos(time_label).y()) <= 2
    assert abs(_pos(avatars[0]).y() - _pos(name).y()) <= 6
    # Thứ tự trái → phải: avatar, tên, giờ.
    assert _pos(avatars[0]).x() < _pos(name).x() < _pos(time_label).x()
    # Thân tin thụt thẳng hàng với TÊN (x bằng nhau).
    body = next(
        l for l in labels if l.text().startswith("Em đã xong")
    )
    name_x = name.mapTo(row, name.rect().topLeft()).x()
    body_x = body.mapTo(row, body.rect().topLeft()).x()
    assert body_x == name_x
    assert body_x >= 35
    chat.close()


# ---------------------------------------------------------------------- #
# Tin người dùng — căn phải, tên "Bạn" accent, không avatar
# ---------------------------------------------------------------------- #
def test_user_row_right_aligned_accent_name(qapp, store):
    chat, _agent = _seeded_chat(qapp, store)
    row = _rows(chat)[1]
    labels = _labels(row)
    assert all(not _has_pixmap(l) for l in labels)  # không avatar
    name = next(l for l in labels if l.text() == "Bạn")
    assert theme.ACCENT in name.styleSheet()
    assert "font-weight:700" in name.styleSheet().replace(" ", "")
    body = next(l for l in labels if l.text() == "trả lời mày cần gì")
    assert body.alignment() & Qt.AlignmentFlag.AlignRight
    # Hàng tên chạm sát mép phải của hàng tin (căn phải thật).
    name_right = name.mapTo(row, name.rect().topRight()).x()
    assert row.width() - name_right <= 2
    chat.close()


def test_system_row_is_flat_centered_warning(qapp, store):
    chat, _agent = _seeded_chat(qapp, store)
    row = _rows(chat)[2]
    label = next(
        l for l in _labels(row) if l.text().startswith("Lệnh #abc")
    )
    assert label.alignment() & Qt.AlignmentFlag.AlignCenter
    assert theme.WARNING in label.styleSheet()
    assert "background" not in label.styleSheet()
    chat.close()


# ---------------------------------------------------------------------- #
# Ô nhập + đầu ô chat
# ---------------------------------------------------------------------- #
def test_composer_strip_borderless_and_send_pill(qapp, store):
    chat, _agent = _seeded_chat(qapp, store)
    assert chat.composer_strip.objectName() == "ChatComposerStrip"
    sheet = chat.composer_strip.styleSheet()
    assert theme.CHAT_COMPOSER_BG in sheet
    assert "border:none" in sheet.replace(" ", "")
    edit_sheet = chat.composer.styleSheet()
    assert "background: transparent" in edit_sheet
    assert "border: none" in edit_sheet
    assert chat.send_button.property("variant") == "primary"
    chat.close()


def test_read_status_shows_read_with_last_time(qapp, store):
    chat, agent = _seeded_chat(qapp, store)
    last = store.list_messages(agent["id"])[-1]
    expected = f"đã đọc · {_fmt_time_short(last['created_at'])}"
    assert chat.read_status_label.text() == expected
    chat.close()


def test_chat_root_has_no_outer_margins(qapp, store):
    chat, _agent = _seeded_chat(qapp, store)
    margins = chat.layout().contentsMargins()
    assert (margins.left(), margins.top(),
            margins.right(), margins.bottom()) == (0, 0, 0, 0)
    thread = chat.thread_layout.contentsMargins()
    assert thread.left() == 16 and thread.right() == 16
    chat.close()


def test_first_expand_lands_at_thread_bottom(qapp, store):
    """Hồi quy V5.3.2 (lộ qua render nghiệm thu): mở luồng có tin
    chưa đọc → chat TỰ BUNG và dựng lần đầu trong cùng nhịp —
    hình học chưa yên khiến vị trí cuộn "bám đáy" trôi về đầu
    luồng, các nhịp sau bị cổng vân chặn nên không tự lành.
    Sau khi layout yên, thanh cuộn phải ở ĐÁY (thấy tin mới
    nhất), không ở đầu."""
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    for index in range(6):
        store.add_message(
            agent["id"], "agent" if index % 2 == 0 else "user",
            f"Tin số {index} đủ dài để luồng phải cuộn trong "
            "khung cao 160px của panel Văn phòng.",
        )
    chat = AgentChatWidget(store, collapsible=True)
    chat.resize(360, 700)
    chat.show()
    _spin(qapp)
    chat.set_agent(store.get_agent(agent["id"]))
    _spin(qapp, times=12)
    bar = chat.scroll.verticalScrollBar()
    assert bar.maximum() > 0  # luồng thật sự phải cuộn
    assert bar.value() >= bar.maximum() - 2
    chat.close()


# ---------------------------------------------------------------------- #
# Văn phòng — không khung Panel riêng, sát viền panel chi tiết
# ---------------------------------------------------------------------- #
def test_office_chat_embed_is_frameless_and_flush(qapp, store):
    from app.ui.office_view import OfficeView

    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.add_message(agent["id"], "agent", "Em chào anh.")
    view = OfficeView(store, {})
    view.resize(1600, 900)
    view.show()
    _spin(qapp)
    chat = view.chat_widget
    assert chat.objectName() == "ChatEmbed"
    panel = view.detail_panel
    # Chat tràn hết bề ngang panel chi tiết: mép trái chat chỉ
    # cách mép panel đúng bề rộng viền (1px), bề rộng lệch ≤ 2px.
    chat_left = chat.mapTo(panel, chat.rect().topLeft()).x()
    assert chat_left <= 1
    assert panel.width() - chat.width() <= 2
    view.close()
    chat.close()
