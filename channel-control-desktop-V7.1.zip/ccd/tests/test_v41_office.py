"""V4.1 — Giao diện "Văn phòng diorama" (Concept C): tầng ánh xạ thuần
``office_scene`` (trạng thái bàn từ dữ liệu thật, thứ tự hàng đợi theo
dispatcher, tràn >8 bàn, số liệu tổng) + khói giao diện (tab Văn phòng
là mục đầu + mặc định, bấm bàn chọn đúng agent ở panel chi tiết, kho
rỗng không sập)."""

import os
from datetime import datetime, timedelta

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from app import config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import office_scene  # noqa: E402
from app.ui.main_window import SEC_AGENTS, SEC_COMMANDS, SEC_OFFICE, MainWindow  # noqa: E402

NOW = datetime(2026, 10, 29, 11, 0).astimezone()


def _agent(agent_id, status="online", profile_ids=(), current=""):
    return {
        "id": agent_id,
        "name": f"Muse {agent_id}",
        "email": f"muse{agent_id}@claude.ai",
        "status": status,
        "revoked": status == "revoked",
        "profile_ids": list(profile_ids),
        "current_command_id": current,
        "last_seen_at": None,
    }


def _cmd(cmd_id, status, agent_id=None, lease_agent_id=None, **kw):
    base = {
        "id": cmd_id,
        "type": kw.get("type", "optimize"),
        "source": kw.get("source", "ui"),
        "status": status,
        "progress": kw.get("progress", 0),
        "step": kw.get("step", ""),
        "instruction": kw.get("instruction", ""),
        "profile_id": kw.get("profile_id"),
        "profile_slug": kw.get("profile_slug", ""),
        "agent_id": agent_id,
        "lease_agent_id": lease_agent_id,
        "lease_expires_at": kw.get("lease_expires_at"),
        "created_at": kw.get("created_at", "2026-10-29T10:00:00+07:00"),
        "finished_at": kw.get("finished_at"),
    }
    return base


def _future_lease(minutes=2):
    return (NOW + timedelta(minutes=minutes)).isoformat()


# --------------------------------------------------------------------------- #
# Tầng thuần: trạng thái bàn
# --------------------------------------------------------------------------- #
def test_desk_states_from_real_data():
    agents = [
        _agent(1),                       # working (giữ lease)
        _agent(2),                       # waiting
        _agent(3),                       # needs_user
        _agent(4, status="offline"),     # offline, không việc
        _agent(5),                       # idle (online, không việc)
    ]
    commands = [
        _cmd("c1", "running", agent_id=1, lease_agent_id=1, progress=72,
             step="Đang tối ưu tiêu đề", lease_expires_at=_future_lease()),
        _cmd("c2", "waiting_muse", agent_id=2),
        _cmd("c3", "needs_user", agent_id=3, instruction="Xác minh 2 bước"),
        _cmd("c4", "queued", agent_id=2, source="auto",
             created_at="2026-10-29T10:05:00+07:00"),
    ]
    scene = office_scene.build_office_scene(agents, commands, {}, [], now=NOW)
    desks = {d["agent_id"]: d for d in scene["desks"]}
    assert desks[1]["state"] == "working"
    assert desks[1]["current"]["progress"] == 72
    assert desks[1]["current"]["step"] == "Đang tối ưu tiêu đề"
    assert desks[1]["current"]["lease_seconds_left"] == 120
    assert desks[2]["state"] == "waiting"
    assert desks[2]["queue_count"] == 1  # c2 là current, c4 còn trong hàng
    assert desks[3]["state"] == "needs_user"
    assert desks[4]["state"] == "offline"
    assert desks[5]["state"] == "idle"
    # Màu agent ổn định giữa hai lần dựng (không phụ thuộc salt tiến trình).
    again = office_scene.build_office_scene(agents, commands, {}, [], now=NOW)
    assert [d["color"] for d in again["desks"]] == [d["color"] for d in scene["desks"]]


def test_needs_user_beats_running_and_waiting():
    agents = [_agent(1)]
    commands = [
        _cmd("c1", "running", agent_id=1, lease_agent_id=1, progress=10,
             lease_expires_at=_future_lease()),
        _cmd("c2", "needs_user", agent_id=1),
    ]
    scene = office_scene.build_office_scene(agents, commands, {}, [], now=NOW)
    assert scene["desks"][0]["state"] == "needs_user"
    assert scene["stats"]["needs_user"] == 1
    assert scene["manager"]["needs_user_total"] == 1


def test_queue_board_dispatcher_order():
    commands = [
        _cmd("api1", "queued", source="api", created_at="2026-10-29T09:00:00+07:00"),
        _cmd("auto1", "waiting_muse", source="auto", created_at="2026-10-29T09:30:00+07:00"),
        _cmd("ui2", "queued", source="ui", created_at="2026-10-29T10:00:00+07:00"),
        _cmd("ui1", "waiting_muse", source="ui", created_at="2026-10-29T09:15:00+07:00"),
        _cmd("done1", "done", source="ui"),
        _cmd("run1", "running", source="ui"),
    ]
    scene = office_scene.build_office_scene([], commands, {}, [], now=NOW)
    assert [q["id"] for q in scene["queue"]] == ["ui1", "ui2", "auto1", "api1"]
    assert scene["queue_total"] == 4
    assert scene["manager"]["queue_total"] == 4
    assert scene["manager"]["running_total"] == 1


def test_desks_overflow_beyond_eight():
    agents = [_agent(i) for i in range(1, 11)]
    scene = office_scene.build_office_scene(agents, [], {}, [], now=NOW)
    assert len(scene["desks"]) == office_scene.MAX_DESKS == 8
    assert scene["desks_overflow"] == 2
    assert scene["desks_total"] == 10
    assert scene["stats"]["agents_total"] == 10


def test_header_stats_and_bridge_lines():
    agents = [_agent(1), _agent(2), _agent(3, status="offline")]
    done = _cmd(
        "d1", "done", agent_id=1,
        finished_at=NOW.isoformat(),
    )
    old_done = _cmd(
        "d2", "done", agent_id=1,
        finished_at="2026-10-28T23:00:00+07:00",
    )
    bridge = {"connected": True, "ever": True, "any_agent_online": True,
              "seconds_ago": 5.0}
    scene = office_scene.build_office_scene(
        agents, [done, old_done], bridge, [], now=NOW
    )
    stats = scene["stats"]
    assert stats["agents_online"] == 2
    assert stats["done_today"] == 1  # lệnh xong hôm qua không tính
    assert scene["manager"]["bridge_connected"] is True
    assert scene["manager"]["label"] == "Điều phối viên"
    assert scene["manager"]["lines"][0].startswith("Cầu nối: Đang nối")


def test_empty_inputs_do_not_crash():
    scene = office_scene.build_office_scene([], [], None, None, now=NOW)
    assert scene["desks"] == []
    assert scene["queue"] == []
    assert scene["stats"]["agents_total"] == 0
    assert scene["manager"]["bridge_connected"] is False


# --------------------------------------------------------------------------- #
# Khói giao diện: cửa sổ chính + tab Văn phòng
# --------------------------------------------------------------------------- #
@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    win = MainWindow(store, ChromeManager(), settings)
    yield win, store
    win.close()
    store.close()


def _seed_office(store):
    """3 agent: một đang làm 72%, một đang chờ, một chờ người."""
    profile = store.add_profile("Kenh A", "a@gmail.com")
    working = store.create_agent("Muse Làm", "lam@claude.ai")
    waiting = store.create_agent("Muse Chờ", "cho@claude.ai")
    blocked = store.create_agent("Muse Vướng", "vuong@claude.ai")
    other = store.add_profile("Kenh B", "b@gmail.com")
    third = store.add_profile("Kenh C", "c@gmail.com")
    store.assign_profiles(working["id"], [profile["id"]])
    store.assign_profiles(waiting["id"], [other["id"]])
    store.assign_profiles(blocked["id"], [third["id"]])
    for agent in (working, waiting, blocked):
        store.touch_agent_heartbeat(agent["id"], "")

    cmd = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
        instruction="Tối ưu tiêu đề + mô tả",
    )
    store.claim_claude_command(cmd["id"], working["id"], 120)
    store.update_command_progress(
        cmd["id"], progress=72, step="Đang tối ưu tiêu đề",
        agent_id=working["id"],
    )
    store.create_command(
        "upload", source="ui", profile_id=other["id"],
        profile_slug=other["slug"], status="waiting_muse",
        instruction="Tải video mới",
    )
    cmd3 = store.create_command(
        "create_video", source="ui", profile_id=third["id"],
        profile_slug=third["slug"], status="waiting_muse",
        instruction="Tạo video tập mới",
    )
    store.claim_claude_command(cmd3["id"], blocked["id"], 120)
    store.set_command_needs_user(cmd3["id"], "Cần xác minh 2 bước")
    return working, waiting, blocked


def test_office_is_first_and_default_section(window):
    win, _store = window
    assert win.sections.currentIndex() == SEC_OFFICE
    assert win.sections.widget(0) is win.office_panel
    assert win._nav_buttons[SEC_OFFICE].isChecked()


def test_office_refresh_and_click_selects_agent(window):
    win, store = window
    working, waiting, _blocked = _seed_office(store)
    win.office_panel.refresh()
    assert "Online 3/3" in win.office_panel.stats_label.text()
    assert "Chờ người 1" in win.office_panel.stats_label.text()

    win.office_panel.select_agent(working["id"])
    assert win.office_panel.selected_agent_id == working["id"]
    assert not win.office_panel.detail_box.isHidden()
    assert win.office_panel.name_label.text() == "Muse Làm"
    assert "72%" in win.office_panel.cur_progress.text()
    assert "Đang tối ưu tiêu đề" in win.office_panel.cur_step.text()

    win.office_panel.select_agent(waiting["id"])
    assert win.office_panel.name_label.text() == "Muse Chờ"
    assert "Tải video mới" in win.office_panel.cur_instruction.text()


def test_office_buttons_switch_sections(window):
    # V5.1 (pin đổi theo plan §2.1): hai nút nhảy "Mở tab Lệnh" /
    # "Tài khoản Muse" trong panel chi tiết ĐÃ BỎ (kẹt panel, anh
    # không dùng) — chuyển mục đi qua thanh điều hướng chính. Pin
    # mới: nút không còn tồn tại + chuyển mục bằng nav còn đúng.
    win, _store = window
    assert not hasattr(win.office_panel, "btn_commands")
    assert not hasattr(win.office_panel, "btn_agents")
    win._switch_section(SEC_COMMANDS)
    assert win.sections.currentIndex() == SEC_COMMANDS
    win._switch_section(SEC_AGENTS)
    assert win.sections.currentIndex() == SEC_AGENTS
    win._switch_section(SEC_OFFICE)


def test_office_refresh_with_empty_db(window):
    win, _store = window
    win.office_panel.refresh()  # không agent/lệnh nào — không được sập
    assert "Online 0/0" in win.office_panel.stats_label.text()
    assert win.office_panel.selected_agent_id is None
