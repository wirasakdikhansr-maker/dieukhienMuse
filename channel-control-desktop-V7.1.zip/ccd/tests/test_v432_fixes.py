"""V4.3.2 — Kiểm thử vòng sửa lỗi từ nghiệm thu máy thật:

- F1: Văn phòng diorama CÓ NỀN — render offscreen khẳng định pixel
  màu sàn bao quanh các bàn + kính phòng Điều phối + bảng hàng đợi;
  vỏ phòng sống sót cả khi scene bị clear() (vẽ ở drawBackground,
  không phải item). Mọi bậc mật độ đều có nền riêng.
- F2: không còn panel tiêu đề CHANNEL CONTROL; 3 nút Cột hồ sơ /
  Panel dữ liệu / Thêm hồ sơ nằm trong hàng điều hướng và còn chạy.
- F3: panel Giao diện gọn — slider bề ngang cố định 300px.
- F4: timer panel ẩn không chạy; kéo slider theme được debounce
  (không áp setStyleSheet toàn app theo từng tick).
- F5: section Báo cáo — khối Báo cáo/Kiểm tra ở TRÊN, bảng Tình
  trạng kênh ở DƯỚI.
- F6: bảng Tình trạng kênh có 3 dạng Ô/Lưới/Danh sách + cỡ thẻ,
  lựa chọn lưu settings; refresh không đổi dữ liệu = giữ nguyên thẻ.
- F7: cột bảng kéo chỉnh Interactive + bề rộng tự lưu theo bảng
  (đặt → lưu → dựng lại → khớp).
"""

import os
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtCore import QRectF  # noqa: E402
from PySide6.QtGui import QColor, QImage, QPainter  # noqa: E402
from PySide6.QtWidgets import QApplication, QHeaderView, QLabel, QTableWidget  # noqa: E402

from app import config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import table_persist, theme  # noqa: E402
from app.ui.main_window import SEC_OFFICE, SEC_SYSTEM, MainWindow  # noqa: E402
from app.ui.office_view import OfficeView  # noqa: E402
from app.ui.theme_panel import ThemePanel  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _spin(qapp, seconds=0.25):
    end = time.time() + seconds
    while time.time() < end:
        qapp.processEvents()


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    store = Store(config.db_path())
    yield store
    store.close()


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1", "name": "Kênh Chính",
            "handle": "@kenhchinh",
            "url": "https://www.youtube.com/channel/UC1",
            "subs": 1200, "video_count": 34,
        },
    )
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    win = MainWindow(store, ChromeManager(), settings)
    win._fixture_refs = (profile, agent)
    yield win
    win.close()
    store.close()


def _two_agent_store(store):
    a1 = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    p1 = store.add_profile("KenhHoatHinh", "23shinryujin@gmail.com")
    store.assign_profiles(a1["id"], [p1["id"]])
    a2 = store.create_agent("dabnire34", "dabnire34@gmail.com")
    p2 = store.add_profile("dabnire34", "dabnire34@gmail.com")
    store.assign_profiles(a2["id"], [p2["id"]])
    return a1, a2


def _render_scene(view) -> QImage:
    img = QImage(1060, 680, QImage.Format_ARGB32)
    img.fill(QColor("#000000"))
    painter = QPainter(img)
    view._scene.render(painter, QRectF(0, 0, 1060, 680), QRectF(0, 0, 1060, 680))
    painter.end()
    return img


def _close(color: QColor, hex_value: str, tol=14) -> bool:
    target = QColor(hex_value)
    return (
        abs(color.red() - target.red()) <= tol
        and abs(color.green() - target.green()) <= tol
        and abs(color.blue() - target.blue()) <= tol
    )


# --------------------------------------------------------------------------- #
# F1 — Văn phòng có nền
# --------------------------------------------------------------------------- #
def test_office_diorama_floor_rendered_around_desks(store, qapp):
    _two_agent_store(store)
    settings = config.load_settings()
    view = OfficeView(store, settings=settings)
    view.resize(1400, 900)
    view.show()
    _spin(qapp)
    assert view._tier == "diorama"
    assert view._scene.shell_diorama is True
    img = _render_scene(view)
    # V5.2 — HÀNH VI MỚI THAY HÀNH VI CŨ CÓ CHỦ ĐÍCH: nền cảnh
    # không còn là sàn/vỏ SÁNG sơn phẳng (#F7F1E3/#DCEEFF/#EBCB9B)
    # mà là ẢNH văn phòng isometric tối (app/assets/office_floor.jpg)
    # sơn trong drawBackground. Các điểm quanh khu bàn vì thế phải
    # TỐI như ảnh và KHÔNG còn là màu sàn sáng cũ.
    for x, y in ((530, 660), (60, 660), (1040, 340), (530, 470)):
        color = img.pixelColor(x, y)
        assert not _close(color, "#F7F1E3", tol=40), (x, y)
        assert color.red() < 110 and color.green() < 110 \
            and color.blue() < 110, (x, y, color)
    assert not _close(img.pixelColor(60, 60), "#DCEEFF", tol=40)
    assert not _close(img.pixelColor(800, 60), "#EBCB9B", tol=40)
    # Qua ĐƯỜNG SƠN CỦA VIEW (grab sau khi hiện + fit ổn định):
    # tâm khung nhìn sơn nền ảnh (tối), không còn sàn sáng cũ.
    grab = view.view.grab().toImage()
    pt = view.view.mapFromScene(530, 660)
    assert not _close(grab.pixelColor(pt.x(), pt.y()), "#F7F1E3", tol=40)
    view.close()


def test_office_shell_survives_scene_clear(store, qapp):
    """Khoá cơ chế: vỏ phòng KHÔNG phải item — clear() sạch item
    mà nền vẫn sơn đủ (đây là điểm gãy trên máy thật).
    V5.2: nền là ẢNH office_floor.jpg — các điểm mẫu phải khớp màu
    của CHÍNH file ảnh tại toạ độ cover-crop tương ứng (đo từ file:
    (530,455)→#868A8B vùng sáng giữa ảnh; (760,120)→#161F26;
    (530,20)→#04150D), và khác hẳn sàn sáng cũ lẫn nền app phẳng."""
    _two_agent_store(store)
    view = OfficeView(store, settings=config.load_settings())
    view._scene.clear()
    assert len(view._scene.items()) == 0
    img = _render_scene(view)
    assert _close(img.pixelColor(530, 455), "#868A8B", tol=34)
    assert _close(img.pixelColor(760, 120), "#161F26", tol=30)
    assert _close(img.pixelColor(530, 20), "#04150D", tol=30)
    assert not _close(img.pixelColor(530, 455), "#F7F1E3", tol=40)
    view.close()


def test_office_grid_tier_has_own_background(store, qapp):
    for i in range(10):
        agent = store.create_agent(f"Agent{i}", f"a{i}@gmail.com")
        profile = store.add_profile(f"HoSo{i}", f"p{i}@gmail.com")
        store.assign_profiles(agent["id"], [profile["id"]])
    view = OfficeView(store, settings=config.load_settings())
    assert view._tier != "diorama"
    assert view._scene.shell_diorama is False
    rect = view._scene.sceneRect()
    img = QImage(int(rect.width()), int(rect.height()), QImage.Format_ARGB32)
    img.fill(QColor("#FF00FF"))
    painter = QPainter(img)
    view._scene.render(painter, rect, rect)
    painter.end()
    # Ô lưới trắng hiện rõ trên nền app của bậc lưới.
    whites = 0
    for y in range(0, img.height(), 3):
        for x in range(0, img.width(), 3):
            if _close(img.pixelColor(x, y), "#FFFFFF", tol=10):
                whites += 1
    assert whites > 500
    view.close()


# --------------------------------------------------------------------------- #
# F2 — Bỏ panel tiêu đề
# --------------------------------------------------------------------------- #
def test_no_title_panel_and_buttons_in_nav(window, qapp):
    assert not hasattr(window, "header_bar")
    texts = [label.text() for label in window.findChildren(QLabel)]
    assert not any("CHANNEL CONTROL" in t for t in texts)
    assert not any("MISSION CONTROL · YOUTUBE" in t for t in texts)
    # 3 nút nằm TRONG hàng điều hướng, cùng cụm phải với phiên bản.
    for button in (
        window.btn_toggle_column,
        window.btn_toggle_panel,
        window.btn_add,
    ):
        assert window.nav_rail.isAncestorOf(button)
    assert window._nav_version.text() == "V7.1"  # pin phiên bản: cập nhật cùng mỗi bump (V6.4.2)
    # Hành vi giữ nguyên: bấm Cột hồ sơ ẩn/hiện cột thật (đo khi
    # đang ở đúng section Hồ sơ — isVisible() chịu cả tổ tiên).
    from app.ui.main_window import SEC_PROFILES

    window.show()
    window._switch_section(SEC_PROFILES)
    _spin(qapp)
    # V5.2 — HÀNH VI MỚI THAY HÀNH VI CŨ CÓ CHỦ ĐÍCH: thanh chip +
    # bố cục FOCUS của V5.1 bị chủ kênh bỏ ("thừa") → vào mục Hồ sơ
    # GIỮ NGUYÊN cột hồ sơ theo cài đặt đã lưu (mặc định HIỆN, như
    # trước V5.1), không còn tự thu gọn. Hành vi nút Cột hồ sơ giữ
    # nguyên: bấm là lật trạng thái cột.
    assert not hasattr(window, "btn_chip_sidebar")  # chip đã bỏ hẳn
    before = window.profile_column.isVisible()
    assert before  # mặc định hiện — không còn focus thu gọn
    window.btn_toggle_column.click()
    assert window.profile_column.isVisible() == (not before)


# --------------------------------------------------------------------------- #
# F5 — Thứ tự section Báo cáo
# --------------------------------------------------------------------------- #
def test_reports_order_tabs_above_status_board(window):
    splitter = window.reports_splitter
    assert splitter.widget(0) is window.reports_tabs
    assert splitter.widget(1) is window.channel_status_panel


# --------------------------------------------------------------------------- #
# F6 — Tình trạng kênh: 3 dạng + cỡ + lưu lựa chọn + vân refresh
# --------------------------------------------------------------------------- #
def test_channel_status_views_and_persistence(window, qapp):
    board = window.channel_status_panel
    board.refresh()
    cards_before = [
        board.cards_layout.itemAt(i).widget()
        for i in range(board.cards_layout.count())
    ]
    assert cards_before  # có thẻ kênh từ dữ liệu mẫu
    # Refresh không đổi dữ liệu → GIỮ NGUYÊN widget thẻ (vân F4).
    board.refresh()
    cards_after = [
        board.cards_layout.itemAt(i).widget()
        for i in range(board.cards_layout.count())
    ]
    assert cards_after == cards_before

    board._set_view_mode("tiles")
    assert window._settings["channel_status_view"] == "tiles"
    tile = board.cards_layout.itemAt(0).widget()
    tile_texts = [lb.text() for lb in tile.findChildren(QLabel)]
    assert any("Kênh Chính" in t for t in tile_texts)
    assert any("1,200" in t for t in tile_texts)
    # Đổi dạng KHÔNG để thẻ ma: số thẻ con của host == số ô layout
    # (bản đầu V4.3.2 chỉ deleteLater → thẻ cũ vẽ chồng lên thẻ mới).
    _spin(qapp)
    from app.ui.channel_status_panel import _ChannelCard

    assert len(board.cards_host.findChildren(_ChannelCard)) == (
        board.cards_layout.count()
    )

    board._set_view_mode("list")
    assert window._settings["channel_status_view"] == "list"
    row = board.cards_layout.itemAt(0).widget()
    row_texts = [lb.text() for lb in row.findChildren(QLabel)]
    assert any("Kênh Chính" in t for t in row_texts)
    assert any("@kenhchinh" in t for t in row_texts)
    _spin(qapp)
    assert len(board.cards_host.findChildren(_ChannelCard)) == (
        board.cards_layout.count()
    )

    board._set_card_size("L")
    assert window._settings["channel_status_size"] == "L"
    board._set_view_mode("cards")


# --------------------------------------------------------------------------- #
# F7 — Cột bảng tự do + tự lưu
# --------------------------------------------------------------------------- #
def test_column_widths_persist_roundtrip(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = {}
    table = QTableWidget(0, 3)
    table.setHorizontalHeaderLabels(["A", "B", "C"])
    header = table_persist.attach_column_persistence(
        table, settings, "unit_table", fixed_columns=(2,)
    )
    assert table.objectName() == "unit_table"
    assert header.sectionResizeMode(0) == QHeaderView.ResizeMode.Interactive
    assert header.sectionResizeMode(1) == QHeaderView.ResizeMode.Interactive
    assert header.sectionResizeMode(2) == QHeaderView.ResizeMode.Fixed
    table.setColumnWidth(0, 222)
    table.setColumnWidth(1, 133)
    # Ép nhịp lưu debounce chạy ngay.
    table._col_persist_timer.timeout.emit()
    assert settings["col_widths_unit_table"][0] == 222
    assert settings["col_widths_unit_table"][1] == 133

    rebuilt = QTableWidget(0, 3)
    rebuilt.setHorizontalHeaderLabels(["A", "B", "C"])
    table_persist.attach_column_persistence(
        rebuilt, settings, "unit_table", fixed_columns=(2,)
    )
    assert rebuilt.columnWidth(0) == 222
    assert rebuilt.columnWidth(1) == 133

    # Chưa có số đã lưu → bề rộng MẶC ĐỊNH phải áp đúng (đặt
    # setColumnWidth khi header còn ResizeToContents sẽ bị nuốt —
    # helper áp mặc định SAU khi chuyển Interactive).
    fresh = QTableWidget(0, 3)
    fresh.setHorizontalHeaderLabels(["A", "B", "C"])
    fresh.horizontalHeader().setSectionResizeMode(
        QHeaderView.ResizeMode.ResizeToContents
    )
    table_persist.attach_column_persistence(
        fresh, {}, "fresh_table", default_widths=(240, 150, 90)
    )
    assert [fresh.columnWidth(i) for i in range(3)] == [240, 150, 90]


def test_app_tables_interactive_with_fixed_exceptions(window):
    commands_header = window.commands_panel.table.horizontalHeader()
    assert (
        commands_header.sectionResizeMode(0)
        == QHeaderView.ResizeMode.Interactive
    )
    # Cột THAO TÁC của bảng lệnh là ngoại lệ Fixed duy nhất ở đó.
    assert (
        commands_header.sectionResizeMode(8)
        == QHeaderView.ResizeMode.Fixed
    )
    channels_header = window.table.horizontalHeader()
    # Cột avatar kênh 38px Fixed; cột tên kênh Interactive.
    assert channels_header.sectionResizeMode(0) == QHeaderView.ResizeMode.Fixed
    assert (
        channels_header.sectionResizeMode(1)
        == QHeaderView.ResizeMode.Interactive
    )
    # V5.1 (pin đổi theo plan §2.5): panel Tự động không còn bảng
    # quy tắc — quy tắc là THẺ (không header cột để pin) nên bỏ
    # khỏi danh sách bảng; các bảng còn lại giữ nguyên kỷ luật.
    for table in (
        window.agents_panel.table,
        window.reports_panel.table,
        window.queue_table,
    ):
        header = table.horizontalHeader()
        for col in range(table.columnCount()):
            assert (
                header.sectionResizeMode(col)
                == QHeaderView.ResizeMode.Interactive
            ), table.objectName()
    tree_header = window.work_panel.list_tree.header()
    assert tree_header.sectionResizeMode(0) == QHeaderView.ResizeMode.Interactive
    # Bề rộng mặc định áp đúng ngay lần mở đầu (chưa có số đã lưu).
    assert window.reports_panel.table.columnWidth(0) == 230
    assert window.commands_panel.table.columnWidth(4) == 420
    # Cột avatar Fixed: Qt đệm thêm vài px theo sizeHint (icon 28px
    # + đệm) khi bảng nằm trong cửa sổ đầy đủ — chỉ khẳng định cột
    # giữ HẸP quanh 38px, không ghim số tuyệt đối.
    assert 38 <= window.table.columnWidth(0) <= 48


# --------------------------------------------------------------------------- #
# F3 + F4 — Panel Giao diện gọn + debounce áp theme
# --------------------------------------------------------------------------- #
def test_theme_panel_compact_sliders(window):
    panel = window.theme_panel
    for slider in (
        panel.radius_slider,
        panel.brightness_slider,
        panel.font_scale_slider,
    ):
        assert slider.minimumWidth() == 300
        assert slider.maximumWidth() == 300
    assert panel.font_combo.maximumWidth() == 300


def test_theme_slider_apply_is_debounced(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    calls = []
    panel = ThemePanel(settings, apply_theme=lambda t: calls.append(t))
    for value in (11, 12, 13, 14, 15):  # kéo 5 tick liên tiếp
        panel.radius_slider.setValue(value)
    # Chưa áp lần nào ngay trong lúc kéo…
    assert calls == []
    _spin(qapp, 0.3)
    # …rồi áp ĐÚNG MỘT lần với giá trị cuối.
    assert len(calls) == 1
    assert calls[0].radius == 15
    panel.close()


def test_hidden_panel_timers_do_not_run(window, qapp):
    window.show()
    window._switch_section(SEC_OFFICE)
    _spin(qapp)
    # Đang ở Văn phòng: timer của panel Tài khoản Muse + Tổng quan
    # (không hiện) phải ĐỨNG — không làm mới vô hình nữa.
    assert not window.agents_panel._timer.isActive()
    assert not window.overview_panel._timer.isActive()
    window._switch_section(SEC_SYSTEM)
    _spin(qapp)
