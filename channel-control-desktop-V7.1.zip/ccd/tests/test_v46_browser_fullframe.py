"""V4.6 (yêu cầu 10:47) — Trình duyệt nhúng ĐƠN đầy kích thước.

Khung nhúng đơn phải lấp đầy vùng nội dung của section Hồ sơ:
panel dữ liệu thu gọn được để nhường trọn diện tích; kích thước
khung bám theo cửa sổ trực tiếp (mọi resize event — đường
DockContainer.resizeEvent → sync_size đã có, test này khoá hành
vi ở tầng bố cục); ⛶ từ tường lưới → đơn khung đầy. KÍCH THƯỚC
KHUNG khác MỨC ZOOM TRANG (75% mặc định — không được đổi).
"""

import pytest
from PySide6.QtWidgets import QApplication

from app import config
from app.store import Store


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _pump(times=8):
    for _ in range(times):
        QApplication.processEvents()


def _make_window(tmp_path, monkeypatch):
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow, SEC_PROFILES

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    window = MainWindow(store, ChromeManager(), settings)
    window.show()
    window._switch_section(SEC_PROFILES)
    _pump()
    return window, store, profile


def test_single_browser_fills_section_when_panel_collapsed(
    qapp, tmp_path, monkeypatch
):
    window, store, _profile = _make_window(tmp_path, monkeypatch)
    try:
        # Baseline: panel dữ liệu ĐANG MỞ (qua cơ chế chuẩn của app;
        # kho test mới tinh mặc định bị thu gọn ở lần chạy đầu) —
        # khung nhúng bị chia diện tích.
        window._set_dock_expanded(True)
        _pump()
        assert not window.data_panel.isHidden()
        width_with_panel = window.dock_container.width()
        zoom_before = window.zoom_label.text()

        # Bật ĐẦY KHUNG → panel thu gọn, khung nhúng chiếm trọn bề
        # ngang của vùng nội dung (center_stack).
        window._set_full_frame(True)
        _pump()
        assert window.data_panel.isHidden()
        assert window.btn_full_frame.isChecked()
        stack_width = window.center_stack.width()
        assert abs(window.dock_container.width() - stack_width) <= 4
        assert window.dock_container.width() > width_with_panel + 300
        # Chiều cao: khung nhúng = stack trừ thanh tab của live_tabs.
        assert window.dock_container.height() >= (
            window.center_stack.height() - 64
        )
        # Zoom trang KHÔNG đổi vì khung đầy (hai khái niệm tách bạch).
        assert window.zoom_label.text() == zoom_before

        # Kích thước bám theo cửa sổ: thu nhỏ rồi phóng to, khung
        # nhúng vẫn khớp vùng nội dung ở cả hai kích thước.
        window.resize(1180, 740)
        _pump()
        small = window.dock_container.width()
        assert abs(small - window.center_stack.width()) <= 4
        window.resize(1760, 1020)
        _pump()
        large = window.dock_container.width()
        assert large > small + 200
        assert abs(large - window.center_stack.width()) <= 4

        # Tắt tay → panel dữ liệu trở lại (đúng trạng thái trước
        # khi bật), ghi nhận opt-out.
        window._on_full_frame_toggled(False)
        _pump()
        assert not window.data_panel.isHidden()
        assert window._full_frame_optout is True
    finally:
        window.close()
        store.close()


def test_maximize_from_wall_goes_single_full_frame(
    qapp, tmp_path, monkeypatch
):
    window, store, profile = _make_window(tmp_path, monkeypatch)
    try:
        window._set_wall_mode(True)
        _pump()
        assert window._wall_active
        # ⛶ trên ô của hồ sơ → thoát tường về khung đơn ĐẦY kích
        # thước của đúng hồ sơ đó.
        window._exit_wall_to_profile(profile["id"])
        _pump()
        assert not window._wall_active
        assert window._full_frame is True
        assert window.btn_full_frame.isChecked()
        assert window.data_panel.isHidden()
        assert window._current_profile_id == profile["id"]
        assert (
            abs(window.dock_container.width()
                - window.center_stack.width()) <= 4
        )
    finally:
        window.close()
        store.close()
