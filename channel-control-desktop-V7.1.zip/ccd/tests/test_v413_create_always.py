"""V4.1.3 — "bấm Tạo lệnh mà lệnh không vào danh sách".

Sự cố thật 29/10 (người dùng): tạo lệnh create_video lúc 13:00:33
xong, ít phút sau bấm Tạo lệnh lại cùng loại cho cùng hồ sơ thì DANH
SÁCH KHÔNG THÊM DÒNG NÀO mà app vẫn báo "Đã tạo lệnh #<id cũ>".
Hai căn nguyên đã kiểm chứng tận nơi:

1. ``CommandsPanel._on_create`` / ``_on_create_channel`` truyền
   ``idempotency_key=Store.default_idempotency_key("ui", type, slug,
   {})`` — payload RỖNG nên khoá chỉ lẫn loại lệnh + hồ sơ + cửa sổ
   10 phút: lần tạo thứ hai trong cửa sổ bị store coi là "gửi lại"
   và trả về lệnh cũ kèm cờ deduplicated thay vì chèn dòng mới.
   Chữa: tạo lệnh THỦ CÔNG không truyền khoá chống trùng nữa (chống
   trùng chỉ còn cho lời gọi API/máy có khoá tường minh — hành vi
   store giữ nguyên, test_v40_schema_idempotency chốt phần đó); nếu
   store vẫn trả cờ deduplicated thì panel phải báo thật "không tạo
   trùng" và chọn đúng dòng cũ, không báo "Đã tạo lệnh" giả.
2. ``_on_create`` / ``_on_create_channel`` / ``_run_guarded`` bị
   ``_bridge_guard`` chặn bằng modal "Chưa có Muse nào đang kết
   nối" — bấm Huỷ bỏ là mất luôn thao tác. Trái quy tắc đứng của
   người dùng: lệnh đã tạo/bấm chạy là lệnh đã cấp đầy đủ, trạng
   thái cầu nối KHÔNG được chặn việc ghi/chạy lệnh (lệnh nằm chờ và
   được giao khi Muse kết nối lại). Chữa: gỡ hẳn _bridge_guard —
   banner cầu nối và nút "🔌 Kết nối Muse…" chỉ còn để THÔNG TIN.
"""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app.store import Store

pytest.importorskip("PySide6")


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def panel_world(tmp_path, qapp):
    from app.ui.commands_panel import CommandsPanel

    store = Store(tmp_path / "t.sqlite3")
    notes: list[str] = []
    runs: list[str] = []
    panel = CommandsPanel(
        store,
        notify=notes.append,
        run_now=runs.append,
    )
    profile = store.add_profile("Kenh A", "kenh.a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    panel.refresh()
    yield {
        "store": store,
        "panel": panel,
        "notes": notes,
        "runs": runs,
        "profile": profile,
        "agent": agent,
    }
    panel.close()
    store.close()


def _set_form(panel, type_key, instruction):
    panel.type_combo.setCurrentIndex(panel.type_combo.findData(type_key))
    panel.instruction_edit.setPlainText(instruction)


# --------------------------------------------------------------------------- #
# 1) Tạo hai lần giống hệt → HAI dòng lệnh thật
# --------------------------------------------------------------------------- #
def test_create_twice_identical_inserts_two_rows(panel_world):
    panel = panel_world["panel"]
    store = panel_world["store"]
    _set_form(panel, "create_video", "Phân tích ngách, tạo video mới")
    panel._on_create()
    # Sau lần tạo đầu, ô nội dung bị xoá — gõ lại NGUYÊN VĂN rồi tạo
    # tiếp trong cùng "cửa sổ 10 phút": đúng kịch bản lỗi của người
    # dùng (trước V4.1.3 lần hai biến mất lặng lẽ).
    _set_form(panel, "create_video", "Phân tích ngách, tạo video mới")
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 2
    assert commands[0]["id"] != commands[1]["id"]
    created_notes = [n for n in panel_world["notes"] if n.startswith("Đã tạo lệnh")]
    assert len(created_notes) == 2
    assert not any("không tạo trùng" in n for n in panel_world["notes"])


def test_create_channel_twice_inserts_two_rows(panel_world):
    panel = panel_world["panel"]
    store = panel_world["store"]
    panel._on_create_channel()
    panel._on_create_channel()
    commands = [
        c for c in store.list_commands(limit=10) if c["type"] == "create_channel"
    ]
    assert len(commands) == 2
    assert commands[0]["id"] != commands[1]["id"]


# --------------------------------------------------------------------------- #
# 2) Cầu nối mất kết nối: tạo/chạy vẫn ghi, không modal chặn
# --------------------------------------------------------------------------- #
def test_create_and_run_while_bridge_disconnected(panel_world, monkeypatch):
    from PySide6.QtWidgets import QMessageBox

    from app.ui.commands_panel import CommandsPanel

    panel = panel_world["panel"]
    store = panel_world["store"]
    # Điều kiện sự cố: chưa Muse nào từng gọi vào → cầu nối "chưa
    # kết nối" (đúng trạng thái làm bản cũ bật modal chặn).
    assert store.bridge_state()["connected"] is False
    # Cái bẫy: bất kỳ modal nào cố bật lên trong lúc tạo/chạy đều
    # làm test nổ — đường tạo/chạy mới không được dựng hộp thoại.
    def _boom(self):
        raise AssertionError("Không được bật modal chặn khi tạo/chạy lệnh")

    monkeypatch.setattr(QMessageBox, "exec", _boom)
    # Cơ chế chặn cũ phải biến mất hẳn khỏi panel.
    assert not hasattr(CommandsPanel, "_bridge_guard")

    _set_form(panel, "create_video", "Tạo video khi Muse chưa kết nối")
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 1
    assert any(n.startswith("Đã tạo lệnh") for n in panel_world["notes"])

    # Chạy lệnh đang chờ Muse trong lúc cầu nối vẫn mất: thao tác
    # phải đi thẳng tới run_now, không bị chặn giữa đường.
    waiting = store.create_command(
        "create_video",
        source="ui",
        profile_id=panel_world["profile"]["id"],
        profile_slug=panel_world["profile"]["slug"],
        status="waiting_muse",
    )
    panel._run_guarded(waiting["id"])
    assert panel_world["runs"] == [waiting["id"]]
