"""V4.3 — work_model: cây công việc THUẦN cho panel Công việc.

Khoá các luật của ``app/ui/work_model.py`` bằng dict giả đúng hình
dạng store trả về (không Qt, không DB):

- cây agent → hồ sơ → kênh → lệnh phân bổ đúng nút; ``agent_id``
  ghi danh trên lệnh thắng phân công hồ sơ; lệnh mồ côi vào bucket
  "chưa phân công" (agent None) ở CUỐI cây;
- % cuốn chiếu = trung bình % của MỌI lệnh con cháu, nút rỗng → None;
- counts gộp đúng bucket (queued + waiting_muse → waiting,
  failed + interrupted → failed);
- thứ tự lệnh trong nhóm = thứ tự dispatcher (ui > auto > api,
  cũ trước, bẻ hoà _seq);
- cửa sổ ngày: done/failed hôm qua bị loại, hôm nay giữ, lệnh đang
  sống hôm qua vẫn giữ;
- fingerprint ổn định theo nội dung, đổi khi một trường nguyên
  liệu đổi;
- quy mô 120 agent vẫn dựng nhanh (< 2 giây).
"""

import time
from datetime import datetime, timedelta, timezone

from app.ui import work_model
from app.ui.work_model import (
    build_work_model,
    command_percent,
    empty_counts,
    work_fingerprint,
)

TZ = timezone(timedelta(hours=7))
NOW = datetime(2026, 10, 29, 12, 0, tzinfo=TZ)
TODAY = "2026-10-29T08:00:00+07:00"
TODAY_LATE = "2026-10-29T23:59:00+07:00"
YESTERDAY = "2026-10-28T20:00:00+07:00"


# ---------------------------------------------------------------------- #
# Dict giả đúng hình dạng store
# ---------------------------------------------------------------------- #
def cmd(cid, **overrides):
    row = {
        "id": cid,
        "type": "optimize",
        "status": "running",
        "progress": None,
        "step": "",
        "profile_id": None,
        "profile_slug": "",
        "channel_id": "",
        "agent_id": None,
        "source": "ui",
        "created_at": TODAY,
        "updated_at": TODAY,
        "instruction": "",
        "error": None,
        "_seq": 1,
    }
    row.update(overrides)
    return row


def agent(aid, name, profile_ids=(), **overrides):
    row = {
        "id": aid,
        "name": name,
        "email": f"{name.lower()}@claude.ai",
        "last_seen_at": TODAY,
        "status": "online",
        "revoked": False,
        "profile_ids": list(profile_ids),
    }
    row.update(overrides)
    return row


def profile(pid, label=None):
    return {
        "id": pid,
        "label": label or f"Hồ sơ {pid}",
        "slug": f"ho-so-{pid}",
        "paused": False,
    }


def channel(channel_id, name=None):
    return {"channel_id": channel_id, "name": name or f"Kênh {channel_id}", "subs": 100}


def find_agent_node(model, agent_id):
    for node in model["agents"]:
        if node["agent"] is not None and node["agent"]["id"] == agent_id:
            return node
    raise AssertionError(f"không thấy agent {agent_id}")


def find_profile_node(agent_node, profile_id):
    for node in agent_node["profiles"]:
        if node["profile"] is not None and node["profile"]["id"] == profile_id:
            return node
    raise AssertionError(f"không thấy profile {profile_id}")


# ---------------------------------------------------------------------- #
# 0) Hằng số + hàm lẻ
# ---------------------------------------------------------------------- #
def test_source_priority_comes_from_dispatcher():
    # work_model phải dùng đúng SOURCE_PRIORITY của dispatcher —
    # một nguồn sự thật duy nhất cho thứ tự ưu tiên nguồn lệnh.
    assert work_model.SOURCE_PRIORITY == {"ui": 0, "auto": 1, "api": 2}


def test_command_percent_rules():
    assert command_percent(cmd("a", status="done", progress=None)) == 100
    assert command_percent(cmd("b", status="done", progress=30)) == 100
    assert command_percent(cmd("c", status="running", progress=50)) == 50
    assert command_percent(cmd("d", status="running", progress=None)) == 0
    assert command_percent(cmd("e", status="running", progress=150)) == 100
    assert command_percent(cmd("f", status="running", progress=-5)) == 0
    assert command_percent(cmd("g", status="failed", progress=40)) == 40


def test_empty_counts_shape():
    assert empty_counts() == {
        "running": 0,
        "waiting": 0,
        "needs_user": 0,
        "failed": 0,
        "done": 0,
        "total": 0,
    }


# ---------------------------------------------------------------------- #
# 1) Cấu trúc cây + phân công
# ---------------------------------------------------------------------- #
def test_tree_structure_and_assignment():
    agents = [
        agent(2, "beta", profile_ids=[11]),
        agent(1, "Alpha", profile_ids=[10]),
    ]
    profiles = [profile(10), profile(11)]
    channels = {10: [channel("UC-X")], 11: []}
    commands = [
        # Ghi danh agent 2 nhưng trỏ hồ sơ 10 (của agent 1): agent_id THẮNG.
        cmd("explicit", agent_id=2, profile_id=10, channel_id="UC-X"),
        # Không ghi danh: theo phân công hồ sơ 10 → agent 1.
        cmd("by-profile", profile_id=10, channel_id="UC-X"),
        # Hồ sơ 11, không kênh: vào commands của profile_node (agent 2).
        cmd("no-channel", profile_id=11, channel_id=""),
        # Kênh lạ không khớp kênh nào của hồ sơ 11: cũng vào profile_node.
        cmd("stray-channel", profile_id=11, channel_id="UC-KHONG-CO"),
        # Mồ côi hoàn toàn: không agent, không hồ sơ.
        cmd("orphan-loose"),
        # Mồ côi mang hồ sơ lạ 999 (không còn trong danh sách).
        cmd("orphan-unknown-profile", profile_id=999),
    ]
    model = build_work_model(commands, agents, profiles, channels, now=NOW)

    # Agent thật sắp theo tên không phân biệt hoa thường; bucket
    # None (chưa phân công) luôn CUỐI.
    assert [n["agent"]["name"] for n in model["agents"][:-1]] == ["Alpha", "beta"]
    assert model["agents"][-1]["agent"] is None
    assert len(model["agents"]) == 3

    node1 = find_agent_node(model, 1)
    prof10_of_1 = find_profile_node(node1, 10)
    chan_x = prof10_of_1["channels"][0]
    assert chan_x["channel"]["channel_id"] == "UC-X"
    assert [c["id"] for c in chan_x["commands"]] == ["by-profile"]

    node2 = find_agent_node(model, 2)
    # Lệnh ghi danh agent 2 kèm hồ sơ 10 → profile 10 hiện cả dưới agent 2.
    prof10_of_2 = find_profile_node(node2, 10)
    assert [c["id"] for c in prof10_of_2["channels"][0]["commands"]] == ["explicit"]
    prof11 = find_profile_node(node2, 11)
    assert {c["id"] for c in prof11["commands"]} == {"no-channel", "stray-channel"}

    orphan_bucket = model["agents"][-1]
    assert [c["id"] for c in orphan_bucket["loose_commands"]] == ["orphan-loose"]
    assert len(orphan_bucket["profiles"]) == 1
    unknown = orphan_bucket["profiles"][0]
    assert unknown["profile"] is None
    assert [c["id"] for c in unknown["commands"]] == ["orphan-unknown-profile"]

    assert model["summary"]["agent_count"] == 2
    assert model["summary"]["command_count"] == 6
    assert model["generated_at"] == NOW.isoformat()


def test_agent_without_any_command_still_present():
    model = build_work_model(
        [],
        [agent(1, "Solo", profile_ids=[10])],
        [profile(10)],
        {10: [channel("UC-X")]},
        now=NOW,
    )
    assert len(model["agents"]) == 1  # không có bucket None khi không mồ côi
    node = model["agents"][0]
    assert node["counts"] == empty_counts()
    assert node["percent"] is None
    prof = find_profile_node(node, 10)
    assert prof["channels"][0]["channel"]["channel_id"] == "UC-X"
    assert prof["percent"] is None
    assert model["summary"]["percent"] is None
    assert model["summary"]["command_count"] == 0


# ---------------------------------------------------------------------- #
# 2) % cuốn chiếu
# ---------------------------------------------------------------------- #
def test_rollup_percent_averages_all_descendants():
    agents = [agent(1, "A", profile_ids=[10])]
    profiles = [profile(10)]
    channels = {10: [channel("UC-X")]}
    commands = [
        cmd("done-1", status="done", profile_id=10, channel_id="UC-X"),
        cmd("run-1", status="running", progress=50, profile_id=10, channel_id=""),
    ]
    model = build_work_model(commands, agents, profiles, channels, now=NOW)
    node = model["agents"][0]
    prof = node["profiles"][0]
    # Kênh chỉ có lệnh done → 100; hồ sơ cuốn cả hai lệnh → 75;
    # agent và summary cùng 75.
    assert prof["channels"][0]["percent"] == 100
    assert prof["percent"] == 75
    assert node["percent"] == 75
    assert model["summary"]["percent"] == 75


def test_rollup_percent_rounds_and_empty_is_none():
    agents = [agent(1, "A"), agent(2, "B")]
    commands = [
        cmd("d", status="done", agent_id=1),
        cmd("r1", status="running", progress=0, agent_id=1),
        cmd("r2", status="running", progress=0, agent_id=1),
    ]
    model = build_work_model(commands, agents, [], {}, now=NOW)
    assert find_agent_node(model, 1)["percent"] == 33  # (100+0+0)/3 ≈ 33.33
    assert find_agent_node(model, 2)["percent"] is None


# ---------------------------------------------------------------------- #
# 3) Counts theo bucket
# ---------------------------------------------------------------------- #
def test_counts_bucket_grouping():
    agents = [agent(1, "A")]
    commands = [
        cmd("q", status="queued", agent_id=1),
        cmd("w", status="waiting_muse", agent_id=1),
        cmd("r", status="running", agent_id=1),
        cmd("n", status="needs_user", agent_id=1),
        cmd("f", status="failed", agent_id=1),
        cmd("i", status="interrupted", agent_id=1),
        cmd("d", status="done", agent_id=1),
    ]
    model = build_work_model(commands, agents, [], {}, now=NOW)
    expected = {
        "running": 1,
        "waiting": 2,  # queued + waiting_muse
        "needs_user": 1,
        "failed": 2,  # failed + interrupted
        "done": 1,
        "total": 7,
    }
    assert model["agents"][0]["counts"] == expected
    assert model["summary"]["counts"] == expected


# ---------------------------------------------------------------------- #
# 4) Thứ tự dispatcher trong nhóm
# ---------------------------------------------------------------------- #
def test_commands_sorted_by_dispatcher_order():
    agents = [agent(1, "A", profile_ids=[10])]
    profiles = [profile(10)]
    channels = {10: [channel("UC-X")]}
    commands = [
        cmd("api-old", source="api", created_at="2026-10-29T06:00:00+07:00",
            profile_id=10, channel_id="UC-X", _seq=1),
        cmd("auto-mid", source="auto", created_at="2026-10-29T07:00:00+07:00",
            profile_id=10, channel_id="UC-X", _seq=2),
        cmd("ui-new", source="ui", created_at="2026-10-29T09:00:00+07:00",
            profile_id=10, channel_id="UC-X", _seq=9),
        cmd("ui-tie-high-seq", source="ui", created_at="2026-10-29T08:00:00+07:00",
            profile_id=10, channel_id="UC-X", _seq=8),
        cmd("ui-tie-low-seq", source="ui", created_at="2026-10-29T08:00:00+07:00",
            profile_id=10, channel_id="UC-X", _seq=3),
        cmd("ui-no-seq", source="ui", created_at="2026-10-29T08:00:00+07:00",
            profile_id=10, channel_id="UC-X"),
    ]
    del commands[-1]["_seq"]  # _seq có thể thiếu → coi như 0, đứng đầu nhóm hoà
    model = build_work_model(commands, agents, profiles, channels, now=NOW)
    ordered = [
        c["id"]
        for c in model["agents"][0]["profiles"][0]["channels"][0]["commands"]
    ]
    assert ordered == [
        "ui-no-seq",
        "ui-tie-low-seq",
        "ui-tie-high-seq",
        "ui-new",
        "auto-mid",
        "api-old",
    ]


# ---------------------------------------------------------------------- #
# 5) Lọc theo ngày
# ---------------------------------------------------------------------- #
def test_today_window_filtering():
    agents = [agent(1, "A")]
    commands = [
        cmd("done-yesterday", status="done", agent_id=1,
            created_at=YESTERDAY, updated_at=YESTERDAY),
        cmd("done-today", status="done", agent_id=1,
            created_at=YESTERDAY, updated_at=TODAY_LATE),
        cmd("failed-today", status="failed", agent_id=1,
            created_at=YESTERDAY, updated_at=TODAY),
        cmd("failed-yesterday", status="failed", agent_id=1,
            created_at=YESTERDAY, updated_at=YESTERDAY),
        cmd("running-yesterday", status="running", agent_id=1,
            created_at=YESTERDAY, updated_at=YESTERDAY),
        cmd("queued-garbage-dates", status="queued", agent_id=1,
            created_at="không-phải-ngày", updated_at=""),
        cmd("done-fallback-created", status="done", agent_id=1,
            created_at=TODAY, updated_at="hỏng"),
        cmd("done-no-dates", status="done", agent_id=1,
            created_at=None, updated_at=None),
        cmd("done-naive-today", status="done", agent_id=1,
            created_at="2026-10-29T07:00:00", updated_at="2026-10-29T07:30:00"),
    ]
    model = build_work_model(commands, agents, [], {}, now=NOW)
    kept = {c["id"] for c in model["agents"][0]["loose_commands"]}
    assert kept == {
        "done-today",
        "failed-today",
        "running-yesterday",      # đang sống: giữ bất kể ngày
        "queued-garbage-dates",   # đang sống: ngày hỏng vẫn giữ
        "done-fallback-created",  # updated hỏng → dự phòng created (hôm nay)
        "done-naive-today",       # ISO không múi giờ vẫn parse được
    }
    assert model["summary"]["command_count"] == 6
    assert model["summary"]["counts"]["done"] == 3
    assert model["summary"]["counts"]["failed"] == 1


# ---------------------------------------------------------------------- #
# 6) Fingerprint
# ---------------------------------------------------------------------- #
def test_fingerprint_stable_and_order_insensitive():
    commands = [cmd("b", progress=10), cmd("a", progress=20)]
    agents = [agent(2, "B"), agent(1, "A")]
    fp1 = work_fingerprint(commands, agents)
    fp2 = work_fingerprint(list(reversed(commands)), list(reversed(agents)))
    assert fp1 == fp2
    assert len(fp1) == 16
    int(fp1, 16)  # phải là hex


def test_fingerprint_changes_with_material_fields():
    base_commands = [cmd("a", status="running", progress=20)]
    base_agents = [agent(1, "A")]
    fp = work_fingerprint(base_commands, base_agents)

    assert work_fingerprint([cmd("a", status="running", progress=21)], base_agents) != fp
    assert work_fingerprint([cmd("a", status="done", progress=20)], base_agents) != fp
    assert work_fingerprint(
        [cmd("a", status="running", progress=20, updated_at=TODAY_LATE)], base_agents
    ) != fp
    assert work_fingerprint(base_commands, [agent(1, "A", status="idle")]) != fp
    assert work_fingerprint(
        base_commands, [agent(1, "A", last_seen_at=TODAY_LATE)]
    ) != fp
    # Trường KHÔNG thuộc nguyên liệu (vd step) đổi thì dấu vân giữ nguyên.
    assert work_fingerprint(
        [cmd("a", status="running", progress=20, step="bước khác")], base_agents
    ) == fp


# ---------------------------------------------------------------------- #
# 7) Quy mô: 120 agent × 2 hồ sơ × 2 kênh × vài lệnh
# ---------------------------------------------------------------------- #
def test_scale_120_agents_builds_fast_and_counts_right():
    agents, profiles, channels, commands = [], [], {}, []
    seq = 0
    for a in range(120):
        agent_id = a + 1
        profile_ids = []
        for p in range(2):
            profile_id = a * 2 + p + 1
            profile_ids.append(profile_id)
            profiles.append(profile(profile_id))
            channel_dicts = []
            for k in range(2):
                channel_id = f"UC-{profile_id}-{k}"
                channel_dicts.append(channel(channel_id))
                for _ in range(3):
                    seq += 1
                    commands.append(
                        cmd(
                            f"c{seq}",
                            status="running",
                            progress=seq % 101,
                            profile_id=profile_id,
                            channel_id=channel_id,
                            _seq=seq,
                        )
                    )
            channels[profile_id] = channel_dicts
        agents.append(agent(agent_id, f"Agent {agent_id:03d}", profile_ids))

    start = time.perf_counter()
    model = build_work_model(commands, agents, profiles, channels, now=NOW)
    elapsed = time.perf_counter() - start

    assert elapsed < 2.0
    assert model["summary"]["agent_count"] == 120
    assert model["summary"]["command_count"] == 120 * 2 * 2 * 3
    assert model["summary"]["counts"]["total"] == 120 * 2 * 2 * 3
    assert model["summary"]["counts"]["running"] == 120 * 2 * 2 * 3
    assert len(model["agents"]) == 120  # không có lệnh mồ côi → không bucket None
    first = model["agents"][0]
    assert len(first["profiles"]) == 2
    assert all(len(p["channels"]) == 2 for p in first["profiles"])
    assert first["counts"]["total"] == 2 * 2 * 3
