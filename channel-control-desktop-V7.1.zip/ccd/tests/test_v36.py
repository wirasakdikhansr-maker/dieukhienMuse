"""Kiểm thử V3.6 — Trung tâm tiến độ: gom lệnh đang chạy/hàng đợi/vướng
+ kênh đang lên + chủ đề đang lên từ dữ liệu Store (hàm thuần)."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from datetime import datetime, timedelta

import pytest

pytest.importorskip("PySide6")

from app.store import Store
from app.ui.monitor_panel import build_monitor_data, owner_label, progress_text


def test_monitor_data_aggregates(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Ho so", "a@gmail.com")
    agent = store.create_agent("Muse Phim", "phim@example.ai")
    store.assign_profiles(agent["id"], [profile["id"]])

    running = store.create_command(
        "create_video", source="auto", profile_id=profile["id"],
        profile_slug=profile["slug"], status="running", agent_id=agent["id"],
    )
    store.update_command_progress(running["id"], progress=60, step="Đang dựng video")
    failed = store.create_command(
        "upload", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
    )
    store.finish_command(failed["id"], "failed", error="Hết hạn ngạch video")
    waiting = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
    )
    old = (datetime.now().astimezone() - timedelta(hours=9)).isoformat(timespec="seconds")
    store._conn.execute(
        "UPDATE commands SET created_at = ? WHERE id = ?", (old, waiting["id"])
    )
    store._conn.commit()

    channel = {"channel_id": "UCx", "name": "Kênh Nhạc", "niche": "Nhạc trữ tình"}
    store.upsert_channel(profile["id"], {**channel, "subs": 100, "video_count": 10})
    store.record_channel_snapshot(profile["id"], {"channel_id": "UCx", "subs": 100, "video_count": 10})
    store._conn.execute("UPDATE channel_snapshots SET day = date('now', '-8 days')")
    store._conn.commit()
    store.upsert_channel(profile["id"], {**channel, "subs": 160, "video_count": 12})
    store.record_channel_snapshot(profile["id"], {"channel_id": "UCx", "subs": 160, "video_count": 12})

    data = build_monitor_data(store)
    # Đang xử lý: running đứng đầu, rồi waiting.
    assert [c["id"] for c in data["active"]] == [running["id"], waiting["id"]]
    assert owner_label(data["active"][0], data["agents"]) == "🤖 Muse Phim"
    assert progress_text(data["active"][0]) == "██████░░░░ 60%"
    # Vướng: 1 lệnh lỗi + 1 chờ quá lâu.
    kinds = sorted(item["kind"] for item in data["blocked"])
    assert kinds == ["⏳ Chờ Muse quá lâu", "❌ Lệnh lỗi"]
    failed_item = next(i for i in data["blocked"] if i["kind"] == "❌ Lệnh lỗi")
    assert "Hết hạn ngạch" in failed_item["reason"]
    # Kênh đang lên + chủ đề.
    assert len(data["rising"]) == 1
    assert data["topics"] == [("Nhạc trữ tình", 60)]
    store.close()
