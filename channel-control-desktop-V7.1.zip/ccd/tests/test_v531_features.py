"""V5.3.1 — vòng góp ý MÁY THẬT đầu tiên trên V5.3 (chủ kênh
2026-10-30 19:31). Kiểm chứng từng mục:

- M1: khối đầu bảng việc "Ai đang làm gì" tối đa 2 DÒNG ở bề
  rộng 1920/1460 (đếm dòng THẬT theo tọa độ y của các widget
  trong FlowLayout), không widget nào bị cắt bề rộng; pill lọc
  là NÚT bấm được mang số đếm — bấm pill = lọc đúng trạng thái,
  đủ 6 lựa chọn (Tất cả + 5 trạng thái); summary rút gọn.
- M2: kích thước ô tường + độ cao nút hàng lệnh đọc TỪ SETTINGS
  (Cài đặt → Giao diện): tường dựng ô đúng cỡ tuỳ chỉnh,
  set_tile_size áp ngay, mặc định khôi phục đúng 600×800/24;
  helper theme.row_action_height kẹp dải 20–36; panel Lệnh áp
  chiều cao mới qua apply_action_button_height.
- M3: chat Văn phòng — bong bóng KHÔNG viền (chuỗi style không
  còn thuộc tính border ngoài border-radius), trần luồng mặc
  định 160; panel chi tiết: mép phải SÁT viền chứa (gap = 0),
  splitter ngang kéo panel trong 280–560 và LƯU settings,
  splitter dọc đặt chiều cao luồng kéo tay 100–420 và LƯU
  settings, bung lại khôi phục đúng chiều cao đã kéo.
- M4: nền Văn phòng — kiểm chứng QUA ĐƯỜNG SƠN CỦA VIEW THẬT
  (grab của office view trong MainWindow): đặt ảnh ĐỎ qua đúng
  handler người dùng dùng (ThemePanel._on_pick_office_bg với
  dialog đã stub) → pixel nền đỏ chiếm đa số; khôi phục mặc
  định → đỏ biến mất; ảnh KHÔNG nạp được → setting KHÔNG đổi,
  file sao bị dọn, thông báo lỗi (không báo thành công giả);
  nhãn hai hàng chọn ảnh phân biệt rõ (cửa sổ vs Văn phòng).
  (Chẩn đoán gốc: đường sơn V5.3 vốn ĐÚNG — lỗi ở tầng điều
  khiển/phản hồi; xem bài học §19 trong ccd_dev_lessons.)

Nhúng thật (Win32) không liên quan vòng này.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from app import config
from app.chrome_manager import ChromeManager
from app.store import Store
from app.ui import theme


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    instance = Store(config.db_path())
    yield instance
    instance.close()


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    instance = Store(config.db_path())
    from app.ui.main_window import MainWindow

    win = MainWindow(instance, ChromeManager(), settings)
    yield win, instance
    win.close()
    instance.close()


def _spin(qapp):
    qapp.processEvents()
    qapp.processEvents()


def _work_panel(qapp, store, settings=None):
    from app.ui.commands_panel import CommandsPanel
    from app.ui.work_panel import WorkPanel

    panel = WorkPanel(
        store, settings if settings is not None else {},
        CommandsPanel(store, settings={}),
    )
    return panel


def _header_rows(panel) -> int:
    """Số DÒNG thật của khối đầu bảng việc: số giá trị y khác
    nhau của mọi widget trong FlowLayout đầu board."""
    ys = set()
    layout = panel.header_flow
    for index in range(layout.count()):
        widget = layout.itemAt(index).widget()
        if widget is not None:
            ys.add(widget.y())
    return len(ys)


# --------------------------------------------------------------------------- #
# M1 — khối đầu bảng việc tối đa 2 dòng
# --------------------------------------------------------------------------- #
@pytest.mark.parametrize("width", [1920, 1460])
def test_work_header_at_most_two_rows(qapp, store, width):
    panel = _work_panel(qapp, store)
    panel.resize(width, 900)
    panel.show()
    _spin(qapp)
    assert _header_rows(panel) <= 2
    # Không widget nào bị nén dưới bề rộng tối thiểu của nó
    # (luật: không cắt chữ nút/nhãn).
    layout = panel.header_flow
    for index in range(layout.count()):
        widget = layout.itemAt(index).widget()
        if widget is not None:
            assert widget.width() >= widget.minimumSizeHint().width() - 1, (
                widget.text() if hasattr(widget, "text") else widget
            )
    panel.close()


def test_work_header_wraps_without_clipping_when_narrow(qapp, store):
    panel = _work_panel(qapp, store)
    panel.resize(1100, 900)
    panel.show()
    _spin(qapp)
    # Khổ hẹp: được xuống thêm dòng, nhưng không cắt chữ.
    layout = panel.header_flow
    for index in range(layout.count()):
        widget = layout.itemAt(index).widget()
        if widget is not None:
            assert widget.width() >= widget.minimumSizeHint().width() - 1
    panel.close()


def test_filter_pills_are_clickable_and_carry_counts(qapp, store):
    from app.ui.work_panel import FILTERS

    profile = store.add_profile("Mail A", "a@gmail.com")
    agent = store.create_agent("Claude A", "ca@example.ai")
    store.create_command(
        "scan", source="ui", profile_id=profile["id"],
        agent_id=agent["id"], status="running",
    )
    store.create_command(
        "scan", source="ui", profile_id=profile["id"],
        agent_id=agent["id"], status="done",
    )
    panel = _work_panel(qapp, store)
    panel.refresh()
    _spin(qapp)
    # Đủ 6 lựa chọn lọc như cũ; summary_pills CHÍNH LÀ 5 nút lọc
    # trạng thái (một nút vừa báo số vừa lọc).
    assert set(panel._filter_buttons) == {key for key, _label in FILTERS}
    assert set(panel.summary_pills) == {
        "running", "waiting", "needs_user", "failed", "done",
    }
    for key, button in panel.summary_pills.items():
        assert panel._filter_buttons[key] is button
    assert panel.summary_pills["running"].text() == "▶ Đang chạy · 1"
    assert panel.summary_pills["done"].text() == "✓ Đã xong · 1"
    assert panel._filter_buttons["all"].text() == "Tất cả · 2"
    # Bấm pill = lọc đúng trạng thái đó.
    panel.summary_pills["running"].click()
    assert panel._filter_bucket == "running"
    assert panel._filter_buttons["running"].isChecked()
    panel._filter_buttons["all"].click()
    assert panel._filter_bucket == "all"
    # Summary rút gọn: còn số agent + tiến độ chung, hết dòng đếm dài.
    assert "Muse" in panel.summary_label.text()
    assert "chung" in panel.summary_label.text()
    assert "đang chờ" not in panel.summary_label.text()
    panel.close()


# --------------------------------------------------------------------------- #
# M2 — kích thước ô tường + độ cao nút từ settings
# --------------------------------------------------------------------------- #
def test_wall_tile_size_from_settings_and_live_apply(qapp, store):
    from app.ui.browser_wall import BrowserWall, tile_size, wall_columns

    assert tile_size(None) == (600, 800)
    assert tile_size({"wall_tile_width": 400, "wall_tile_height": 500}) == (400, 500)
    # Ngoài dải → kẹp về dải cho phép.
    assert tile_size({"wall_tile_width": 50, "wall_tile_height": 9999}) == (320, 1200)
    # Số cột theo bề rộng ô HIỆU LỰC.
    assert wall_columns(1300, tile_width=400) == 3
    assert wall_columns(1300) == 2  # mặc định 600 như V5.3

    profile = store.add_profile("Mail A", "a@gmail.com")
    wall = BrowserWall(
        store, settings={"wall_tile_width": 400, "wall_tile_height": 500}
    )
    wall.resize(1920, 1080)
    wall.set_entries([profile], {})
    wall.show()
    _spin(qapp)
    tile = wall.tiles[profile["id"]]
    assert (tile.width(), tile.height()) == (400, 500)
    # Áp cỡ MỚI ngay (đường MainWindow gọi khi Lưu cài đặt).
    wall.set_tile_size(700, 900)
    _spin(qapp)
    assert (tile.width(), tile.height()) == (700, 900)
    assert wall.tile_size() == (700, 900)
    wall.close()


def test_row_action_height_helper_clamps():
    assert theme.row_action_height(None) == 24
    assert theme.row_action_height({}) == 24
    assert theme.row_action_height({"row_action_button_height": 32}) == 32
    assert theme.row_action_height({"row_action_button_height": 99}) == 36
    assert theme.row_action_height({"row_action_button_height": 3}) == 20


def test_commands_panel_applies_button_height_from_settings(qapp, store):
    from app.ui.commands_panel import CommandsPanel

    settings = {"row_action_button_height": 24}
    panel = CommandsPanel(store, settings=settings)
    profile = store.add_profile("Mail A", "a@gmail.com")
    queued = store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="queued"
    )
    widget = panel._action_widget(queued)
    from PySide6.QtWidgets import QPushButton

    heights = {b.height() for b in widget.findChildren(QPushButton)}
    assert heights == {24}
    # Đổi settings (như _gather của Cài đặt ghi) + áp qua đường
    # MainWindow gọi khi Lưu.
    settings["row_action_button_height"] = 32
    panel.apply_action_button_height()
    widget = panel._action_widget(queued)
    heights = {b.height() for b in widget.findChildren(QPushButton)}
    assert heights == {32}
    assert panel.bridge_help_button.height() == 32
    panel.close()


def test_settings_panel_gathers_display_sizes(qapp, store, tmp_path, monkeypatch):
    from app.ui.settings_panel import SettingsPanel

    panel = SettingsPanel(store, config.load_settings(), lambda _s: "")
    panel.wall_tile_width_spin.setValue(480)
    panel.wall_tile_height_spin.setValue(640)
    panel.row_action_height_spin.setValue(30)
    values = panel._gather()
    assert values["wall_tile_width"] == 480
    assert values["wall_tile_height"] == 640
    assert values["row_action_button_height"] == 30
    panel.close()


# --------------------------------------------------------------------------- #
# M3 — chat Văn phòng: không viền, panel kéo được, sát viền
# --------------------------------------------------------------------------- #
def test_chat_bubbles_have_no_border_and_cap_160(qapp, store):
    """V5.3.2 — PIN NÀY ĐÃ ĐỔI THEO PHƯƠNG ÁN 1 CHỦ KÊNH DUYỆT
    (2026-10-30 21:02): bong bóng tin bị BỎ HẲN (hằng
    _USER_BUBBLE/_AGENT_BUBBLE/_SYSTEM_BUBBLE đã xoá khỏi
    agent_chat), nên khẳng định cũ "stylesheet bong bóng không
    border" không còn đối tượng. Khẳng định thay thế: module
    KHÔNG còn hằng bong bóng nào và hàng tin dựng ra không mang
    stylesheet nền/viền riêng (kiểm chứng cấu trúc đầy đủ nằm ở
    test_v532_chat_redesign). Phần trần chiều cao luồng (M3b)
    giữ nguyên như V5.3.1."""
    from app.ui import agent_chat
    from app.ui.agent_chat import AgentChatWidget

    for gone in ("_USER_BUBBLE", "_AGENT_BUBBLE", "_SYSTEM_BUBBLE",
                 "_BUBBLE_MAX_WIDTH", "_BubbleBodyLabel"):
        assert not hasattr(agent_chat, gone), gone
    assert agent_chat.OFFICE_THREAD_MAX_HEIGHT == 420
    assert agent_chat.OFFICE_THREAD_MIN_HEIGHT == 200
    chat = AgentChatWidget(store, collapsible=True)
    assert chat.scroll.maximumHeight() == 420
    assert chat.scroll.minimumHeight() == 200
    # Chế độ kéo tay: dải 100–420 thắng trần mặc định.
    chat.set_user_thread_height(300)
    assert chat.scroll.minimumHeight() == 100
    assert chat.scroll.maximumHeight() == 420
    assert chat.user_thread_height() == 300
    chat.set_user_thread_height(None)
    assert chat.scroll.maximumHeight() == 420
    chat.close()


def test_chat_bubble_expands_to_message_width(qapp, store):
    """Lỗi CÓ SẴN phát hiện khi kiểm chứng M3a: sizeHint của
    QLabel wordWrap không theo độ dài câu (~122px cố định) nên
    thân tin DÀI bị bóp hẹp, phần đầu trôi khỏi vùng nhìn — chỉ
    thấy đuôi câu. V5.3.2: cơ chế giữ nguyên, nhãn đổi tên
    _MessageBodyLabel (bong bóng đã bỏ hẳn theo Phương án 1).
    Ngưỡng bề rộng hạ 200 → 185 kèm lý do: hàng tin phẳng có
    thụt đầu dòng 35px (avatar + khoảng cách, đúng ảnh duyệt) và
    đệm luồng 16px mỗi bên là một phần của thiết kế đã duyệt —
    ý nghĩa hồi quy cần ghim là "thân tin nở theo nội dung,
    không kẹt ở ~122px", không phải con số 200 tuyệt đối."""
    from PySide6.QtWidgets import QLabel

    from app.ui.agent_chat import AgentChatWidget

    agent = store.create_agent("Muse 0", "a0@example.ai")
    store.add_message(
        agent["id"], "agent", "Em đã xong bản nháp, anh xem giúp em nhé."
    )
    chat = AgentChatWidget(store, collapsible=True)
    chat.resize(278, 400)
    chat.show()
    chat.set_agent(store.get_agent(agent["id"]))
    chat.expand_chat()
    _spin(qapp)
    bodies = [
        label for label in chat.thread_host.findChildren(QLabel)
        if label.text().startswith("Em đã xong")
    ]
    assert bodies and bodies[0].width() >= 185, (
        bodies[0].width() if bodies else None
    )
    chat.close()


def _office(qapp, store, settings):
    from app.ui.office_view import OfficeView

    view = OfficeView(store, settings)
    view.resize(1600, 900)
    view.show()
    _spin(qapp)
    return view


def test_office_panel_flush_right_and_resizable(qapp, store):
    settings = {}
    view = _office(qapp, store, settings)
    panel = view.detail_panel
    # (d) SÁT VIỀN: mép phải panel == mép phải vùng chứa.
    right_edge = panel.mapTo(view, panel.rect().topRight()).x() + 1
    assert view.width() - right_edge == 0
    # (c) Khoảng kéo 280–560 + kéo thật qua splitter ngang.
    assert panel.minimumWidth() == 280
    assert panel.maximumWidth() == 560
    total = view.body_splitter.width()
    view.body_splitter.setSizes([total - 460, 460])
    _spin(qapp)
    assert abs(panel.width() - 460) <= 2
    # Lưu bề rộng khi dừng kéo (handler ghi settings).
    view._save_detail_width()
    assert abs((settings.get("office_detail_width") or 0) - panel.width()) <= 2
    view.close()


def test_office_chat_splitter_stretches_and_persists(qapp, store):
    settings = {}
    view = _office(qapp, store, settings)
    agent = store.create_agent("Claude A", "ca@example.ai")
    store.add_message(agent["id"], "agent", "Tin cần đọc")
    chat = view.chat_widget
    chat.set_agent(store.get_agent(agent["id"]))
    chat.expand_chat()
    _spin(qapp)
    assert chat.is_expanded
    # (e) Kéo splitter dọc: mô phỏng dừng kéo ở chiều cao luồng
    # ~300 — handler nới dải + hẹn lưu; gọi lưu ngay để kiểm.
    view.panel_splitter.setSizes([300, 500])
    _spin(qapp)
    view._on_panel_splitter_moved(0, 1)
    view._save_chat_thread_height()
    saved = settings.get("office_chat_thread_height")
    assert saved is not None and 100 <= saved <= 420
    assert chat.user_thread_height() == saved
    # Thu rồi bung lại: khôi phục đúng chiều cao đã kéo.
    chat.toggle_expand()
    _spin(qapp)
    assert not chat.is_expanded
    chat.toggle_expand()
    _spin(qapp)
    assert chat.is_expanded
    assert abs(chat.scroll.height() - saved) <= 24, (
        chat.scroll.height(), saved
    )
    view.close()


# --------------------------------------------------------------------------- #
# M4 — nền Văn phòng qua đường sơn của view thật
# --------------------------------------------------------------------------- #
def _red_ratio(widget) -> float:
    from PySide6.QtGui import QColor, QImage

    img = widget.grab().toImage().convertToFormat(QImage.Format.Format_RGB32)
    red = total = 0
    for y in range(0, img.height(), 6):
        for x in range(0, img.width(), 6):
            color = QColor(img.pixel(x, y))
            total += 1
            if color.red() > 180 and color.green() < 90 and color.blue() < 90:
                red += 1
    return red / max(1, total)


def test_office_background_paints_through_real_view(window, qapp, tmp_path):
    from PySide6.QtGui import QColor, QImage

    win, store = window
    for index in range(3):
        store.create_agent(f"Muse {index}", f"a{index}@example.ai")
    win.resize(1600, 950)
    win.show()
    _spin(qapp)
    office = win.office_panel
    office.refresh()
    _spin(qapp)
    assert _red_ratio(office.view) < 0.05

    # Ảnh ĐỎ qua ĐÚNG handler người dùng dùng (dialog stub).
    image = QImage(1060, 680, QImage.Format.Format_RGB32)
    image.fill(QColor(255, 0, 0))
    source = tmp_path / "red.png"
    image.save(str(source))
    import app.ui.theme_panel as theme_panel_module

    original = theme_panel_module.QFileDialog.getOpenFileName
    theme_panel_module.QFileDialog.getOpenFileName = staticmethod(
        lambda *a, **k: (str(source), "")
    )
    try:
        win.theme_panel._on_pick_office_bg()
    finally:
        theme_panel_module.QFileDialog.getOpenFileName = original
    _spin(qapp)
    office.refresh()
    _spin(qapp)
    assert win._settings.get("office_bg_image")
    assert _red_ratio(office.view) > 0.5

    # Khôi phục mặc định → đỏ biến mất khỏi view.
    win.theme_panel._on_reset_office_bg()
    _spin(qapp)
    office.refresh()
    _spin(qapp)
    assert _red_ratio(office.view) < 0.05


def test_office_background_rejects_unloadable_image(window, qapp, tmp_path):
    win, _store = window
    bad = tmp_path / "bad.png"
    bad.write_bytes(b"definitely not an image")
    notes: list[str] = []
    win.theme_panel._notify = notes.append
    import app.ui.theme_panel as theme_panel_module

    original = theme_panel_module.QFileDialog.getOpenFileName
    theme_panel_module.QFileDialog.getOpenFileName = staticmethod(
        lambda *a, **k: (str(bad), "")
    )
    try:
        win.theme_panel._on_pick_office_bg()
    finally:
        theme_panel_module.QFileDialog.getOpenFileName = original
    # Không lưu setting, không file sao sót lại, báo LỖI rõ ràng
    # (bản V5.3 báo "Đã đặt" vô điều kiện — sai sự thật).
    assert not win._settings.get("office_bg_image")
    assert not (config.data_dir() / "office_bg" / "bad.png").exists()
    assert notes and "không đọc được" in notes[-1]


def test_office_background_controls_are_unambiguous(window):
    win, _store = window
    panel = win.theme_panel
    assert panel.office_bg_button.text() == "🖼 Chọn ảnh nền Văn phòng…"
    # Hàng nền CỬA SỔ nói rõ là cửa sổ trong tooltip của nút.
    assert "Văn phòng" in panel.bg_image_button.toolTip()
