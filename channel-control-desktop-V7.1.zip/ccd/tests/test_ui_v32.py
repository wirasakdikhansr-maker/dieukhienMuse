"""Khói giao diện V3.2 (offscreen): iconbar góc trái-trên với thao tác
nhanh, trạng thái cookies ở cột hồ sơ, cột Tiến độ ở panel Lệnh và thẻ
'Muse đang làm việc' ở Tổng quan."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import config, cookies_vault  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui.commands_panel import CommandsPanel  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    win = MainWindow(store, ChromeManager(), settings)
    yield win, store, profile
    win.close()
    store.close()


def test_iconbar_top_left_with_quick_actions(window):
    win, _store, _profile = window
    # Topbar (V3.4): thu gọn = chỉ icon, có nút quét tất cả + toàn màn hình.
    win._apply_rail_state(True)
    assert win.btn_scan_all.text() == "🔄"
    assert win.btn_theater.text() == "⛶"
    assert win.icon_bridge_dot is not None
    # V6.3.1: cụm phải gọn kiểu AI Studio — nút tiện ích luôn chỉ icon,
    # nghĩa của nút nằm ở tooltip.
    win._apply_rail_state(False)
    assert "Quét tất cả" in win.btn_scan_all.toolTip()
    assert "Toàn màn hình" in win.btn_theater.toolTip()


def test_cookie_status_in_profile_column(window):
    win, _store, profile = window
    win._refresh_cookie_status(profile)
    assert "chưa có" in win.cookie_status.text()
    cookies_vault.save_cookies(
        profile["slug"],
        [
            {"name": "SID", "value": "x", "domain": ".google.com", "path": "/",
             "expires": None, "secure": True, "http_only": True,
             "same_site": "Lax", "host_only": False}
        ],
        source="import:test",
    )
    win._refresh_cookie_status(profile)
    assert "1 cookie" in win.cookie_status.text()
    assert "SID" in win.cookie_status.text()


def test_commands_table_has_progress_column(window):
    win, store, profile = window
    panel = win.commands_panel
    assert panel.table.columnCount() == 9
    headers = [panel.table.horizontalHeaderItem(i).text() for i in range(9)]
    # V4.3.1: header bảng lệnh chuyển IN HOA theo phong cách
    # Concept D (chỉ đổi hình thức, cột Tiến độ vẫn ở vị trí 5).
    assert headers[5] == "TIẾN ĐỘ"
    command = store.create_command(
        "upload", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], instruction="Tải EP08", status="waiting_muse",
    )
    store.update_command_progress(command["id"], progress=60, step="Đang tải video lên…")
    cell = CommandsPanel._progress_cell(store.get_command(command["id"]))
    assert "60%" in cell.text()
    assert "Đang tải video lên" in cell.text()


def test_overview_shows_active_work(window):
    win, store, profile = window
    command = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], instruction="Tối ưu EP01", status="waiting_muse",
    )
    store.update_command_progress(command["id"], progress=25, step="Đang phân tích kênh…")
    win.overview_panel.refresh()
    assert win.overview_panel.work_layout.count() == 1
    row = win.overview_panel.work_layout.itemAt(0).widget()
    from PySide6.QtWidgets import QProgressBar

    bar = row.findChild(QProgressBar)
    assert bar is not None
    assert bar.value() == 25
    assert "Đang phân tích kênh" in bar.format()
