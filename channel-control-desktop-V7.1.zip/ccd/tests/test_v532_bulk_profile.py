"""V5.3.2 — M-BULK (Huỷ tất cả / Xoá tất cả ở menu chuột phải bảng
lệnh) + M-PROFILE-EDIT (nút "✎ Sửa hồ sơ" trên thẻ hồ sơ).

M-BULK ghim:
- Menu còn nguyên các mục cũ và có thêm 2 mục hàng loạt ở CUỐI,
  sau vạch phân cách; trạng thái mờ + tooltip lý do khi không có
  gì để xử lý.
- Huỷ tất cả chỉ đổi trạng thái CHƯA kết thúc (queued /
  waiting_muse / running / needs_user) qua ĐÚNG đường huỷ của
  nút đơn; done/failed không bị đụng; số trong hộp xác nhận
  khớp số thực thi; từ chối ở hộp xác nhận = không đổi gì.
- Xoá tất cả giữ lại đúng lệnh running và báo số bỏ qua.

M-PROFILE-EDIT ghim:
- Mỗi thẻ hồ sơ có nút "✎ Sửa hồ sơ" nhìn thấy (RowAction, chiều
  cao theo theme.row_action_height).
- Bấm nút / gọi on_edit_profile mở AddProfileDialog CHẾ ĐỘ SỬA
  với đúng dữ liệu hồ sơ đó; lưu xong store + thẻ phản ánh giá
  trị mới; slug giữ nguyên; Gmail trùng hồ sơ khác bị chặn.
"""

from __future__ import annotations

import pytest
from PySide6.QtWidgets import QApplication, QPushButton

import app.ui.commands_panel as commands_module
from app.chrome_manager import ChromeManager
from app.store import Store
from app.ui import theme
from app.ui.commands_panel import CommandsPanel
from app.ui.main_window import MainWindow


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path):
    instance = Store(tmp_path / "v532.db")
    yield instance
    instance.close()


def _spin(qapp, times=6):
    for _ in range(times):
        qapp.processEvents()


def _seed_mixed(store):
    """6 lệnh ở 6 trạng thái; trả dict status -> id."""
    profile = store.add_profile("Kenh A", "a@gmail.com")
    ids = {}
    for status in ("queued", "waiting_muse", "needs_user",
                   "running", "done", "failed"):
        cmd = store.create_command(
            "scan", source="ui", profile_id=profile["id"],
            status=status, instruction=f"lệnh {status}",
        )
        ids[status] = cmd["id"]
    return ids


# ---------------------------------------------------------------------- #
# Hộp xác nhận giả + menu giả (mẫu test_v53: thay tên trong namespace
# module — QMenu.exec/QMessageBox thật của Shiboken không vá được
# bằng gán thuộc tính lớp và sẽ treo test offscreen).
# ---------------------------------------------------------------------- #
class _FakeStandardButton:
    Yes = "yes"
    No = "no"


class _FakeMessageBox:
    StandardButton = _FakeStandardButton
    answer = _FakeStandardButton.Yes
    calls: list = []

    @staticmethod
    def question(_parent, title, text, *_a, **_k):
        _FakeMessageBox.calls.append((title, text))
        return _FakeMessageBox.answer


class _FakeAction:
    def __init__(self, text):
        self._text = text
        self.enabled = True
        self.tooltip = ""
        self.slot = None

        outer = self

        class _Signal:
            def connect(self, slot):
                outer.slot = slot

        self.triggered = _Signal()

    def text(self):
        return self._text

    def setEnabled(self, on):
        self.enabled = bool(on)

    def setToolTip(self, text):
        self.tooltip = text


class _FakeMenu:
    instances: list = []

    def __init__(self, _parent=None):
        self.items: list = []
        _FakeMenu.instances.append(self)

    def addAction(self, text):
        action = _FakeAction(text)
        self.items.append(action)
        return action

    def addSeparator(self):
        self.items.append("---")

    def exec(self, _pos):
        return None


@pytest.fixture()
def fake_ui(monkeypatch):
    _FakeMessageBox.calls = []
    _FakeMessageBox.answer = _FakeStandardButton.Yes
    _FakeMenu.instances = []
    monkeypatch.setattr(commands_module, "QMenu", _FakeMenu)
    monkeypatch.setattr(commands_module, "QMessageBox", _FakeMessageBox)
    return _FakeMessageBox


# ---------------------------------------------------------------------- #
# M-BULK — menu
# ---------------------------------------------------------------------- #
def test_menu_has_bulk_actions_at_end(qapp, store, fake_ui):
    from PySide6.QtCore import QPoint

    ids = _seed_mixed(store)
    panel = CommandsPanel(store)
    panel.refresh()
    panel.show()
    _spin(qapp)
    panel._on_table_menu(QPoint(6, 4))
    menu = _FakeMenu.instances[-1]
    texts = [i.text() for i in menu.items if isinstance(i, _FakeAction)]
    # Mục cũ còn nguyên.
    assert "🗑 Xoá lệnh" in texts
    assert "↻ Làm mới danh sách" in texts
    # Hai mục mới ở CUỐI, sau một vạch phân cách.
    assert texts[-2] == "✕ Huỷ tất cả lệnh"
    assert texts[-1] == "🗑 Xoá tất cả"
    assert menu.items[-3] == "---"
    bulk = [i for i in menu.items if isinstance(i, _FakeAction)][-2:]
    assert all(a.enabled for a in bulk)
    assert ids  # seed đã tạo
    panel.close()


def test_menu_bulk_actions_disabled_with_reason_when_nothing_to_do(
        qapp, store, fake_ui):
    from PySide6.QtCore import QPoint

    profile = store.add_profile("Kenh A", "a@gmail.com")
    store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="done"
    )
    panel = CommandsPanel(store)
    panel.refresh()
    panel.show()
    _spin(qapp)
    panel._on_table_menu(QPoint(6, 4))
    actions = {
        i.text(): i for i in _FakeMenu.instances[-1].items
        if isinstance(i, _FakeAction)
    }
    cancel_all = actions["✕ Huỷ tất cả lệnh"]
    assert cancel_all.enabled is False
    assert "Không có lệnh nào" in cancel_all.tooltip
    panel.close()


# ---------------------------------------------------------------------- #
# M-BULK — huỷ tất cả
# ---------------------------------------------------------------------- #
def test_cancel_all_only_touches_unfinished(qapp, store, fake_ui):
    ids = _seed_mixed(store)
    notes = []
    runner_cancelled = []

    def fake_runner_cancel(command_id):
        runner_cancelled.append(command_id)
        store.finish_command(
            command_id, "failed",
            result="Đã huỷ bởi người dùng.",
            error="Đã huỷ bởi người dùng.",
        )

    panel = CommandsPanel(
        store, notify=notes.append, cancel_command=fake_runner_cancel
    )
    panel._on_cancel_all()
    # Hộp xác nhận ghi đúng số lệnh chưa kết thúc: 4.
    assert _FakeMessageBox.calls
    title, text = _FakeMessageBox.calls[-1]
    assert title == "Huỷ tất cả lệnh"
    assert "Huỷ 4 lệnh" in text
    for status in ("queued", "waiting_muse", "needs_user", "running"):
        after = store.get_command(ids[status])
        assert after["status"] == "failed", status
    # Kết thúc rồi thì giữ nguyên.
    assert store.get_command(ids["done"])["status"] == "done"
    assert store.get_command(ids["failed"])["status"] == "failed"
    # Báo cáo vào Nhật ký (notify) kèm số đã huỷ.
    assert any("đã huỷ 4 lệnh" in line for line in notes)
    panel.close()


def test_cancel_all_without_runner_skips_running(qapp, store, fake_ui):
    ids = _seed_mixed(store)
    notes = []
    panel = CommandsPanel(store, notify=notes.append)  # không runner
    panel._on_cancel_all()
    assert store.get_command(ids["running"])["status"] == "running"
    for status in ("queued", "waiting_muse", "needs_user"):
        assert store.get_command(ids[status])["status"] == "failed"
    assert any(
        "đã huỷ 3 lệnh" in line and "Bỏ qua 1" in line for line in notes
    )
    panel.close()


def test_cancel_all_declined_changes_nothing(qapp, store, fake_ui):
    ids = _seed_mixed(store)
    _FakeMessageBox.answer = _FakeStandardButton.No
    panel = CommandsPanel(store, notify=lambda _line: None)
    panel._on_cancel_all()
    for status, command_id in ids.items():
        assert store.get_command(command_id)["status"] == status
    panel.close()


# ---------------------------------------------------------------------- #
# M-BULK — xoá tất cả
# ---------------------------------------------------------------------- #
def test_delete_all_keeps_running_and_reports(qapp, store, fake_ui):
    ids = _seed_mixed(store)
    notes = []
    panel = CommandsPanel(store, notify=notes.append)
    panel._on_delete_all()
    title, text = _FakeMessageBox.calls[-1]
    assert title == "Xoá tất cả lệnh"
    assert "Xoá 5 lệnh" in text
    assert "1 lệnh đang chạy sẽ được GIỮ LẠI" in text
    remaining = store.list_commands(limit=100)
    assert [c["id"] for c in remaining] == [ids["running"]]
    assert any(
        "đã xoá 5 lệnh" in line and "Giữ lại 1 lệnh đang chạy" in line
        for line in notes
    )
    panel.close()


# ---------------------------------------------------------------------- #
# M-PROFILE-EDIT — store
# ---------------------------------------------------------------------- #
def test_update_profile_fields_and_slug_stable(store):
    profile = store.add_profile("Tên cũ", "cu@gmail.com", "ghi chú cũ")
    updated = store.update_profile(
        profile["id"], label="Tên mới", gmail="moi@gmail.com",
        note="ghi chú mới",
    )
    assert updated["label"] == "Tên mới"
    assert updated["gmail"] == "moi@gmail.com"
    assert updated["note"] == "ghi chú mới"
    assert updated["slug"] == profile["slug"]
    assert updated["port"] == profile["port"]


def test_update_profile_rejects_duplicate_gmail(store):
    store.add_profile("Hồ sơ A", "a@gmail.com")
    other = store.add_profile("Hồ sơ B", "b@gmail.com")
    with pytest.raises(ValueError):
        store.update_profile(other["id"], gmail="a@gmail.com")
    # Giữ nguyên Gmail của chính mình thì không sao.
    same = store.update_profile(other["id"], gmail="b@gmail.com",
                                label="Hồ sơ B2")
    assert same["label"] == "Hồ sơ B2"


# ---------------------------------------------------------------------- #
# M-PROFILE-EDIT — thẻ + dialog
# ---------------------------------------------------------------------- #
def _window(store):
    win = MainWindow(store, ChromeManager(), {}, agent_server=None)
    return win


def test_profile_card_has_visible_edit_button(qapp, store):
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    win = _window(store)
    win.refresh_profiles()
    win.show()
    # Cửa sổ mặc định mở ở mục Văn phòng — chuyển sang mục Hồ sơ
    # để thẻ (và nút) thật sự HIỆN, đúng điều kiện người dùng thấy.
    from app.ui.main_window import SEC_PROFILES

    win._switch_section(SEC_PROFILES)
    _spin(qapp)
    card = win._card_widgets[profile["id"]]
    buttons = [
        b for b in card.findChildren(QPushButton)
        if b.text() == "✎ Sửa hồ sơ"
    ]
    assert len(buttons) == 1
    button = buttons[0]
    assert button.objectName() == "RowAction"
    # setFixedHeight theo cài đặt → min = max = chiều cao hiệu lực.
    assert button.minimumHeight() == theme.row_action_height({})
    assert button.maximumHeight() == theme.row_action_height({})
    assert button.isVisible()
    # Luật không cắt chữ ở cột hồ sơ hẹp (~320px): nút Sửa VÀ nút
    # ⋯ phải nằm TRỌN trong thẻ (bản đầu xếp cùng hàng ngang với
    # cột chữ — nút bị cắt và ⋯ bị đẩy khỏi thẻ, bắt ở render).
    for btn in (button, card.findChild(QPushButton, "CardMenuBtn")):
        right = btn.mapTo(card, btn.rect().topRight()).x()
        assert right <= card.width(), (btn.text(), right, card.width())
    win.close()


def test_edit_button_opens_dialog_with_profile_data_and_saves(
        qapp, store, monkeypatch):
    import app.ui.main_window as main_window_module

    profile = store.add_profile(
        "KenhChinh", "lokn38666@gmail.com", "ghi chú gốc"
    )
    seen = {}

    class _FakeEditDialog:
        Accepted = 1

        def __init__(self, parent=None, profile=None):
            seen["profile"] = profile

        def exec(self):
            return _FakeEditDialog.Accepted

        def details(self):
            return {
                "label": "KenhChinh Mới",
                "gmail": "lokn38666@gmail.com",
                "note": "ghi chú mới",
                "password": "",
                "cookies_path": "",
            }

    monkeypatch.setattr(
        main_window_module, "AddProfileDialog", _FakeEditDialog
    )
    win = _window(store)
    win.refresh_profiles()
    _spin(qapp)
    # Dialog nhận ĐÚNG dữ liệu của hồ sơ này.
    win.on_edit_profile(profile["id"])
    assert seen["profile"]["id"] == profile["id"]
    assert seen["profile"]["label"] == "KenhChinh"
    assert seen["profile"]["note"] == "ghi chú gốc"
    # Store đã đổi…
    after = store.get_profile(profile["id"])
    assert after["label"] == "KenhChinh Mới"
    assert after["note"] == "ghi chú mới"
    # …và THẺ trên tab Hồ sơ phản ánh giá trị mới ngay.
    _spin(qapp)
    card = win._card_widgets[profile["id"]]
    from PySide6.QtWidgets import QLabel

    label_texts = [l.text() for l in card.findChildren(QLabel)]
    assert "KenhChinh Mới" in label_texts
    win.close()
