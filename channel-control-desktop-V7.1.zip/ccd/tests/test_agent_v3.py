"""Kiểm thử V3 cho Agent API: bảng lệnh DÙNG CHUNG với UI
(GET /api/commands liệt kê cả lệnh tạo trong UI, POST
/api/commands/{id}/result để Muse báo cáo) và last_check trong
GET /api/profiles. Tái dùng bản giả của test_agent_server.
"""

import json
import urllib.error
import urllib.request

import pytest

from app import config
from app.agent_server import AgentServer
from app.store import Store
from test_agent_server import FakeManager, stub_scan


@pytest.fixture()
def agent(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    seed.close()

    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    server.start()
    yield {
        "server": server,
        "data_dir": data_dir,
        "profile": profile,
        "base": f"http://127.0.0.1:{server.port}",
        "token": server.token,
    }
    server.stop()


def call(agent, method, path, body=None):
    data = None
    headers = {"X-Agent-Token": agent["token"]}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(agent["base"] + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.status, json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read().decode("utf-8"))


def test_commands_list_includes_ui_created(agent):
    # Người dùng tạo lệnh trong UI (ghi thẳng vào kho dùng chung).
    store = Store(config.db_path(agent["data_dir"]))
    ui_cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=agent["profile"]["id"],
        profile_slug=agent["profile"]["slug"],
        instruction="Tối ưu tiêu đề EP08",
        status="waiting_muse",
    )
    store.close()

    status, payload = call(agent, "GET", "/api/commands")
    assert status == 200
    ids = [c["id"] for c in payload["commands"]]
    assert ui_cmd["id"] in ids
    entry = [c for c in payload["commands"] if c["id"] == ui_cmd["id"]][0]
    assert entry["source"] == "ui"
    assert entry["type"] == "optimize"
    assert entry["status"] == "waiting_muse"
    assert entry["instruction"] == "Tối ưu tiêu đề EP08"

    # Lọc theo trạng thái.
    status, payload = call(agent, "GET", "/api/commands?status=waiting_muse")
    assert [c["id"] for c in payload["commands"]] == [ui_cmd["id"]]


def test_muse_reports_result_and_ui_sees_it(agent):
    store = Store(config.db_path(agent["data_dir"]))
    cmd = store.create_command(
        "upload", source="ui", profile_id=agent["profile"]["id"], status="waiting_muse"
    )
    store.close()

    status, payload = call(
        agent, "POST", f"/api/commands/{cmd['id']}/result",
        body={"status": "running", "result": "Đang tải lên bước 2/4"},
    )
    assert status == 200
    assert payload["command"]["status"] == "running"
    assert payload["command"]["result"] == "Đang tải lên bước 2/4"

    status, payload = call(
        agent, "POST", f"/api/commands/{cmd['id']}/result",
        body={"status": "done", "result": "Đã tải lên: https://youtu.be/XXXX"},
    )
    assert status == 200
    assert payload["command"]["status"] == "done"
    assert payload["command"]["finished_at"]

    # Phía UI (đọc cùng kho) thấy trạng thái mới nhất.
    store = Store(config.db_path(agent["data_dir"]))
    row = store.get_command(cmd["id"])
    store.close()
    assert row["status"] == "done"
    assert "youtu.be" in row["result"]

    # Lệnh không tồn tại -> 404; trạng thái bậy -> 400.
    status, _ = call(agent, "POST", "/api/commands/khong-co/result", body={"status": "done"})
    assert status == 404
    status, _ = call(
        agent, "POST", f"/api/commands/{cmd['id']}/result", body={"status": "bay_mau"}
    )
    assert status == 400


def test_profiles_include_last_check(agent):
    status, payload = call(agent, "GET", "/api/profiles")
    assert status == 200
    assert payload["profiles"][0]["last_check"] is None

    store = Store(config.db_path(agent["data_dir"]))
    store.save_check(
        agent["profile"]["id"],
        [{"key": "chrome", "label": "Chrome", "status": "ok", "detail": "đang chạy"}],
        "1 đạt, 0 lỗi, 0 chưa rõ (tổng 1 mục)",
    )
    store.close()

    status, payload = call(agent, "GET", "/api/profiles")
    last_check = payload["profiles"][0]["last_check"]
    assert last_check is not None
    assert last_check["summary"].startswith("1 đạt")
    assert last_check["items"][0]["key"] == "chrome"
