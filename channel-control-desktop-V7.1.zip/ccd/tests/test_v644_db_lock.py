"""V6.4.4 — 'database is locked' không còn cắt ngang lời gọi Agent API."""

from __future__ import annotations

import json
import sqlite3
import threading
import urllib.error
import urllib.request

from app import config
from app.agent_server import AgentServer
from app.store import Store


class FakeManager:
    def is_running(self, p):
        return False

    def __getattr__(self, name):
        return lambda *a, **k: None


def _server(tmp_path):
    seed = Store(config.db_path(tmp_path))
    agent = seed.create_agent("A", "a@x.com")
    token = seed.get_agent(agent["id"])["token"]
    seed.close()
    server = AgentServer(data_dir=tmp_path, settings={"agent_port": 0}, manager=FakeManager())
    server.start()
    return server, agent, token


def _get(server, agent, token, path):
    req = urllib.request.Request(
        f"http://127.0.0.1:{server.port}{path}",
        headers={"X-Agent-Id": str(agent["id"]), "X-Agent-Token": token})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read())


def test_store_uses_long_busy_timeout_and_normal_sync(tmp_path):
    st = Store(tmp_path / "x.db")
    assert st._conn.execute("PRAGMA busy_timeout").fetchone()[0] == 30000
    assert st._conn.execute("PRAGMA synchronous").fetchone()[0] == 1  # NORMAL
    st.close()


def test_locked_database_returns_503_json(tmp_path, monkeypatch):
    server, agent, token = _server(tmp_path)
    calls = []

    def boom(*args, **kwargs):
        calls.append(1)
        raise sqlite3.OperationalError("database is locked")

    monkeypatch.setattr(server, "dispatch", boom)
    try:
        status, payload = _get(server, agent, token, "/api/profiles")
        assert status == 503 and payload["error"] == "database_busy" and payload["retry_after"] == 2
        assert len(calls) == 2  # thử lại một lần
    finally:
        server.stop()


def test_heartbeat_lock_does_not_fail_request(tmp_path, monkeypatch):
    server, agent, token = _server(tmp_path)

    def locked(self, *a, **k):
        raise sqlite3.OperationalError("database is locked")

    monkeypatch.setattr(Store, "touch_agent_heartbeat_light", locked)
    try:
        status, payload = _get(server, agent, token, "/api/profiles")
        assert status == 200 and payload["ok"] is True
    finally:
        server.stop()


def test_writer_holding_lock_briefly_no_longer_errors(tmp_path):
    server, agent, token = _server(tmp_path)
    holder = sqlite3.connect(str(config.db_path(tmp_path)), timeout=30, check_same_thread=False)
    holder.execute("BEGIN IMMEDIATE")
    holder.execute("UPDATE agents SET note = 'x'")
    release = threading.Timer(6.0, holder.commit)  # giữ khoá 6 giây (> 5 giây của bản cũ)
    release.start()
    try:
        status, payload = _get(server, agent, token, "/api/profiles")
        assert status == 200 and payload["ok"] is True
    finally:
        release.join()
        holder.close()
        server.stop()
