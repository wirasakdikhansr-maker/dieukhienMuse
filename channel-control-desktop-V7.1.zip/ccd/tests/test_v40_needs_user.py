"""V4.0 (H3) — Trạng thái needs_user: chờ NGƯỜI xử lý, không tự chết.

Chỉ chủ lease (hoặc admin) được đặt needs_user; đặt trạng thái này
THẢ lease và KHÔNG tăng attempts (không phải lỗi của Muse). Người
dùng xử lý xong bấm "Đã xử lý — chạy tiếp" ở panel → lệnh về 'queued'
cho dispatcher xét lại từ đầu.
"""

import json

import pytest
from PySide6.QtWidgets import QApplication


@pytest.fixture(scope="module", autouse=True)
def qapp():
    return QApplication.instance() or QApplication([])


from app import config
from app.agent_server import AgentServer
from app.store import Store
from test_agent_server import FakeManager, stub_scan
from test_v40_claim_lease import call, make_waiting


@pytest.fixture()
def world(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("Kenh A", "a@gmail.com")
    agent_a = seed.create_agent("Muse A", "a@claude.ai")
    agent_b = seed.create_agent("Muse B", "b@claude.ai")
    seed.assign_profiles(agent_a["id"], [profile["id"]])
    seed.close()
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    return {
        "server": server,
        "data_dir": data_dir,
        "profile": profile,
        "agent_a": agent_a,
        "agent_b": agent_b,
    }


def test_result_needs_user_releases_lease_and_keeps_attempts(world):
    cmd = make_waiting(world)
    call(world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"])
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/result",
        agent=world["agent_a"],
        body={"status": "needs_user", "message": "Cần đăng nhập lại Gmail"},
    )
    assert status == 200
    got = payload["command"]
    assert got["status"] == "needs_user"
    assert got["result"] == "Cần đăng nhập lại Gmail"
    assert got["lease_agent_id"] is None
    assert got["lease_expires_at"] is None
    assert got["attempts"] == 0


def test_needs_user_from_non_holder_blocked(world):
    from test_v40_claim_lease import _also_assign

    _also_assign(world, world["agent_b"])
    cmd = make_waiting(world, agent_id=world["agent_a"]["id"])
    call(world, "POST", f"/api/commands/{cmd['id']}/claim", agent=world["agent_a"])
    # agent_b trong phạm vi hồ sơ (qua chốt phạm vi) nhưng không giữ lease.
    status, payload = call(
        world,
        "POST",
        f"/api/commands/{cmd['id']}/result",
        agent=world["agent_b"],
        body={"status": "needs_user", "message": "dừng"},
    )
    assert status == 403
    assert "lease" in payload["error"]


def test_store_resume_roundtrip(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="waiting_muse",
    )
    row = store.set_command_needs_user(cmd["id"], "Chờ người duyệt")
    assert row["status"] == "needs_user"
    resumed = store.resume_command(cmd["id"])
    assert resumed["status"] == "queued"
    assert resumed["progress"] == 0
    assert store.resume_command(cmd["id"]) is None  # không còn needs_user
    store.close()


def test_panel_resume_button_returns_command_to_queued(qapp, tmp_path):
    from app.ui.commands_panel import CommandsPanel

    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="waiting_muse",
    )
    store.set_command_needs_user(cmd["id"], "Cần xác minh")
    panel = CommandsPanel(store)
    # Hàng needs_user có ô thao tác chứa nút "chạy tiếp" (cột 8).
    widget = panel.table.cellWidget(0, 8)
    assert widget is not None
    from PySide6.QtWidgets import QPushButton

    texts = [b.text() for b in widget.findChildren(QPushButton)]
    assert any("chạy tiếp" in t for t in texts)
    panel._on_resume(cmd["id"])
    assert store.get_command(cmd["id"])["status"] == "queued"
    panel.deleteLater()
    store.close()
