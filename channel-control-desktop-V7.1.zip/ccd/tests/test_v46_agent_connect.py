"""V4.6 — Nút 🔌 Kết nối trên TỪNG dòng agent + hộp thoại 2 lớp.

Người dùng hỏi "đã đăng nhập sao vẫn ngoại tuyến" vì hai lớp bị
nhầm: ĐĂNG NHẬP muse.ai (phiên web) ≠ KẾT NỐI CẦU NỐI (Muse
cầm phiếu gọi vào app — heartbeat). Hộp thoại phải tách bạch hai
lớp, nêu đúng lý do ngoại tuyến theo dữ liệu thật, xuất đúng
phiếu của đúng agent, và "Kiểm tra lại ngay" phải làm mới.
"""

import sqlite3
from datetime import datetime, timedelta

import pytest
from PySide6.QtWidgets import QApplication, QPushButton

from app import tickets
from app.store import Store
from app.ui.agent_connect import AgentConnectDialog, bridge_state
from app.ui.agents_panel import AgentsPanel


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


def _set_last_seen(db_file, agent_id, moment):
    conn = sqlite3.connect(db_file)
    try:
        conn.execute(
            "UPDATE agents SET last_seen_at = ? WHERE id = ?",
            (moment.isoformat(), agent_id),
        )
        conn.commit()
    finally:
        conn.close()


def _seed(tmp_path):
    store = Store(tmp_path / "connect.db")
    online = store.create_agent("DangOnline", "online@claude.ai")
    never = store.create_agent("ChuaTung", "never@claude.ai")
    stale = store.create_agent("MatNhịp", "stale@claude.ai")
    store.touch_agent_heartbeat(online["id"])
    _set_last_seen(
        tmp_path / "connect.db", stale["id"],
        datetime.now().astimezone() - timedelta(minutes=42),
    )
    store.set_agent_web_state(never["id"], "in")
    store.set_agent_web_state(stale["id"], "in")
    return store, online, never, stale


def _dialog(store, agent_id, tmp_path, on_recheck=None):
    return AgentConnectDialog(
        store, agent_id, settings={}, data_dir=tmp_path,
        on_recheck=on_recheck,
    )


# --------------------------------------------------------------------- #
# Lý do ngoại tuyến theo 3 trường hợp
# --------------------------------------------------------------------- #
def test_bridge_state_three_cases(qapp, tmp_path):
    store, online, never, stale = _seed(tmp_path)
    label, reason = bridge_state(store.get_agent(online["id"]))
    assert "Đang kết nối" in label

    label, reason = bridge_state(store.get_agent(never["id"]))
    assert "Ngoại tuyến" in label
    assert "Chưa từng kết nối" in reason
    assert "phiếu chưa được nạp" in reason

    label, reason = bridge_state(store.get_agent(stale["id"]))
    assert "Ngoại tuyến" in label
    assert "Mất nhịp từ" in reason
    assert "42 phút" in reason


# --------------------------------------------------------------------- #
# Hộp thoại: hai lớp tách bạch + đúng nội dung từng trường hợp
# --------------------------------------------------------------------- #
def test_dialog_never_connected_shows_two_layers(qapp, tmp_path):
    store, _online, never, _stale = _seed(tmp_path)
    dialog = _dialog(store, never["id"], tmp_path)
    # Lớp 1 — cầu nối: ngoại tuyến + chưa từng + lý do phiếu.
    assert "Ngoại tuyến" in dialog.bridge_status_label.text()
    assert "chưa từng" in dialog.bridge_seen_label.text()
    assert "Chưa từng kết nối" in dialog.bridge_reason_label.text()
    # Lớp 2 — muse.ai: ĐÃ đăng nhập mà cầu nối vẫn ngoại tuyến —
    # đúng nghịch lý người dùng hỏi; hai lớp phải hiện đồng thời.
    assert "Đã đăng nhập" in dialog.web_status_label.text()
    dialog.close()


def test_dialog_online_shows_connected(qapp, tmp_path):
    store, online, _never, _stale = _seed(tmp_path)
    dialog = _dialog(store, online["id"], tmp_path)
    assert "Đang kết nối" in dialog.bridge_status_label.text()
    assert "chưa từng" not in dialog.bridge_seen_label.text()
    dialog.close()


def test_dialog_stale_shows_lost_beat_reason(qapp, tmp_path):
    store, _online, _never, stale = _seed(tmp_path)
    dialog = _dialog(store, stale["id"], tmp_path)
    assert "Ngoại tuyến" in dialog.bridge_status_label.text()
    assert "Mất nhịp từ" in dialog.bridge_reason_label.text()
    dialog.close()


# --------------------------------------------------------------------- #
# Xuất phiếu: đúng file của đúng agent
# --------------------------------------------------------------------- #
def test_export_ticket_writes_that_agents_file(qapp, tmp_path, monkeypatch):
    store, _online, never, _stale = _seed(tmp_path)
    opened = []
    monkeypatch.setattr(
        "app.ui.agent_connect.QDesktopServices.openUrl",
        lambda url: opened.append(url.toLocalFile()) or True,
    )
    dialog = _dialog(store, never["id"], tmp_path)
    path = dialog.export_ticket()
    folder = tickets.ticket_export_dir({}, tmp_path)
    expected = folder / tickets.agent_ticket_filename(
        store.get_agent(never["id"])
    )
    assert path == expected
    assert expected.exists()
    profiles = {p["id"]: p for p in store.list_profiles()}
    assert expected.read_text(encoding="utf-8") == tickets.agent_ticket_text(
        store.get_agent(never["id"]), profiles
    )
    # Mở đúng thư mục phiếu sau khi xuất.
    assert opened and opened[0] == str(folder)
    # Sau xuất, dòng trạng thái phiếu trong hộp thoại chuyển khớp.
    assert "khớp dữ liệu" in dialog.ticket_state_label.text()
    dialog.close()


# --------------------------------------------------------------------- #
# Kiểm tra lại ngay: gọi làm mới + tự đọc lại trạng thái
# --------------------------------------------------------------------- #
def test_recheck_refreshes_dialog_and_calls_back(qapp, tmp_path):
    store, _online, never, _stale = _seed(tmp_path)
    calls = []
    dialog = _dialog(
        store, never["id"], tmp_path,
        on_recheck=lambda: calls.append(1),
    )
    assert "Ngoại tuyến" in dialog.bridge_status_label.text()
    # Muse nạp phiếu và heartbeat về → kiểm tra lại phải thấy online.
    store.touch_agent_heartbeat(never["id"])
    dialog.recheck_button.click()
    assert calls == [1]
    assert "Đang kết nối" in dialog.bridge_status_label.text()
    dialog.close()


# --------------------------------------------------------------------- #
# Bảng Tài khoản: nút từng dòng + nhãn "Chưa kết nối"
# --------------------------------------------------------------------- #
def test_table_has_per_row_connect_buttons(qapp, tmp_path):
    store, online, never, stale = _seed(tmp_path)
    panel = AgentsPanel(store, settings={})
    panel.refresh()
    assert panel.table.columnCount() == 9
    labels = {}
    status_texts = {}
    for row, agent in enumerate(panel._agents):
        button = panel.table.cellWidget(row, 8)
        assert isinstance(button, QPushButton)
        labels[agent["id"]] = button.text()
        status_texts[agent["id"]] = panel.table.item(row, 2).text()
    assert labels[online["id"]] == "Đã kết nối ✓"
    assert labels[never["id"]] == "🔌 Kết nối"
    assert labels[stale["id"]] == "🔌 Kết nối"
    # Agent chưa từng kết nối: cột Trạng thái nói "Chưa kết nối",
    # không phải "Ngoại tuyến" trơ trụi; agent mất nhịp giữ nguyên.
    assert "Chưa kết nối" in status_texts[never["id"]]
    assert "Ngoại tuyến" in status_texts[stale["id"]]
    # Tooltip cột Trạng thái giải thích hai lớp.
    tooltip = panel.table.item(0, 2).toolTip()
    assert "PHIẾU KẾT NỐI" in tooltip and "KHÔNG" in tooltip
    # Hộp thoại dựng được từ panel cho đúng agent.
    dialog = panel.build_connect_dialog(never["id"])
    assert dialog is not None
    assert "Ngoại tuyến" in dialog.bridge_status_label.text()
    assert panel.build_connect_dialog(99999) is None
    dialog.close()
    panel.close()
