"""Kiểm thử Store V3.2: migration v3, quy tắc 1 Gmail = 1 hồ sơ riêng,
báo tiến độ lệnh và danh sách lệnh đang hoạt động."""

import pytest

from app.store import Store


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "t.sqlite3")
    yield s
    s.close()


def test_schema_version_3(store):
    # V3.3 nâng schema lên 4 (bảng agents) — mốc v3 là tối thiểu của V3.2.
    assert store.schema_version >= 3


def test_one_profile_per_gmail(store):
    profile = store.add_profile("Kênh A", "Panumol@Gmail.com")
    assert store.find_profile_by_gmail("panumol@gmail.com")["id"] == profile["id"]
    assert store.find_profile_by_gmail("  PANUMOL@GMAIL.COM ")["id"] == profile["id"]
    with pytest.raises(ValueError, match="mỗi Gmail chỉ có một hồ sơ riêng"):
        store.add_profile("Kênh A2", "panumol@gmail.com")
    # Gmail khác (hoặc rỗng) vẫn thêm bình thường.
    store.add_profile("Kênh B", "other@gmail.com")
    store.add_profile("Kênh C", "")


def test_command_progress_flow(store):
    profile = store.add_profile("Kênh A", "a@gmail.com")
    command = store.create_command(
        "upload",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        instruction="Tải EP08",
        status="waiting_muse",
    )
    assert command["progress"] == 0

    row = store.update_command_progress(command["id"], progress=35, step="Đang mở Studio…")
    assert row["progress"] == 35
    assert row["step"] == "Đang mở Studio…"
    assert row["status"] == "running"  # báo lần đầu -> chuyển sang đang chạy
    assert row["started_at"] is not None

    row = store.update_command_progress(command["id"], progress=250)
    assert row["progress"] == 100  # kẹp trần 100

    done = store.finish_command(command["id"], "done", result="Xong")
    assert done["progress"] == 100

    again = store.create_command(
        "scan", source="ui", profile_id=profile["id"], profile_slug=profile["slug"]
    )
    store.update_command_progress(again["id"], progress=50, step="Giữa chừng")
    store.finish_command(again["id"], "failed", error="Lỗi")
    store.requeue_command(again["id"])
    retried = store.get_command(again["id"])
    assert retried["progress"] == 0
    assert retried["step"] == ""


def test_list_active_commands(store):
    profile = store.add_profile("Kênh A", "a@gmail.com")
    waiting = store.create_command(
        "free", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
    )
    finished = store.create_command(
        "free", source="ui", profile_id=profile["id"], profile_slug=profile["slug"]
    )
    store.finish_command(finished["id"], "done", result="ok")
    active = store.list_active_commands()
    assert [c["id"] for c in active] == [waiting["id"]]
