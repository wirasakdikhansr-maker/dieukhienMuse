"""Kiểm thử bản vá V3.1: Chrome phải luôn được mở kèm cờ
--remote-allow-origins=* (thiếu cờ này, Chrome bản mới từ chối bắt tay
WebSocket CDP với lỗi 403) + probe bắt tay trong mục Kiểm tra."""

import pytest

from app import cdp, checks
from app.chrome_manager import ChromeManager
from app.store import Store


class FakePopen:
    captured_args = None

    def __init__(self, args, **kwargs):
        FakePopen.captured_args = list(args)

    def poll(self):
        return None


def test_launch_args_include_remote_allow_origins(monkeypatch, tmp_path):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    monkeypatch.setattr(
        "app.chrome_manager.config.find_chrome", lambda override=None: "/fake/chrome"
    )
    state = {"open_calls": 0}

    def fake_port_open(port, timeout=1.0):
        state["open_calls"] += 1
        # Lần 1: cổng chưa mở (chưa chạy). Sau Popen: mở.
        return state["open_calls"] > 1

    monkeypatch.setattr("app.chrome_manager.cdp.debug_port_open", fake_port_open)
    monkeypatch.setattr("app.chrome_manager.subprocess.Popen", FakePopen)

    manager = ChromeManager()
    profile = {"slug": "demo", "label": "Demo", "port": 19555}
    assert manager.launch(profile) == "launched"
    args = FakePopen.captured_args
    assert "--remote-allow-origins=*" in args
    assert f"--remote-debugging-port=19555" in args
    assert any("--user-data-dir=" in a for a in args)


def test_launch_flags_constant():
    assert "--remote-allow-origins=*" in ChromeManager.LAUNCH_FLAGS


# --------------------------------------------------------------------------- #
# Probe bắt tay CDP trong checks.build_check_items
# --------------------------------------------------------------------------- #
def _probes(**overrides):
    probes = {
        "chrome_running": True,
        "cdp_ok": True,
        "logged_in": True,
        "channels": [{"name": "Kênh A"}],
        "last_scan_at": None,
        "scheduled_videos": [],
        "videos_known": False,
    }
    probes.update(overrides)
    return probes


def _by_key(items):
    return {item["key"]: item for item in items}


RAW_403 = (
    "Handshake status 403 Forbidden — Rejected an incoming WebSocket "
    "connection from the http://127.0.0.1:19500 origin."
)


def test_handshake_item_ok():
    items = checks.build_check_items(_probes(ws_handshake=True, ws_error=None))
    shaped = _by_key(items)
    assert shaped["handshake"]["status"] == "ok"


def test_handshake_item_403_gives_friendly_vietnamese():
    items = checks.build_check_items(_probes(ws_handshake=False, ws_error=RAW_403))
    shaped = _by_key(items)
    assert shaped["handshake"]["status"] == "fail"
    detail = shaped["handshake"]["detail"]
    assert detail == cdp.ORIGIN_REJECTED_MESSAGE
    assert "đóng hẳn Chrome" in detail


def test_handshake_item_absent_without_probe():
    items = checks.build_check_items(_probes())  # probe cũ: không có khoá ws_*
    assert "handshake" not in _by_key(items)


def test_probe_ws_handshake_with_fake_manager(tmp_path):
    class Client:
        def evaluate(self, _expr):
            return 1

        def close(self):
            pass

    class Manager:
        def connect_page(self, _profile):
            return Client()

    ok, err = checks.probe_ws_handshake(Manager(), {"port": 1})
    assert ok is True and err is None

    class BadManager:
        def connect_page(self, _profile):
            raise ConnectionError(RAW_403)

    ok, err = checks.probe_ws_handshake(BadManager(), {"port": 1})
    assert ok is False
    assert "403" in err
