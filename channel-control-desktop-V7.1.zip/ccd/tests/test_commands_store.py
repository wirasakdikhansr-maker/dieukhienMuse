"""Kiểm thử V3 cho kho: lệnh công việc (commands), quy tắc tự động
(automation_rules), kết quả kiểm tra (profile_checks) và video."""

import pytest

from app.store import Store


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "test.sqlite3")
    yield s
    s.close()


@pytest.fixture()
def profile(store):
    return store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")


# --------------------------------------------------------------------------- #
# Commands
# --------------------------------------------------------------------------- #
def test_create_and_get_command(store, profile):
    cmd = store.create_command(
        "scan",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        instruction="Quét lại kênh",
        status="queued",
    )
    assert cmd["id"]
    assert cmd["type"] == "scan"
    assert cmd["status"] == "queued"
    assert cmd["payload"] == {}
    assert cmd["result"] is None
    assert cmd["result_data"] is None
    assert cmd["created_at"] and cmd["updated_at"]
    fetched = store.get_command(cmd["id"])
    assert fetched["instruction"] == "Quét lại kênh"
    assert fetched["profile_slug"] == profile["slug"]


def test_create_command_validates_type_and_status(store):
    with pytest.raises(ValueError):
        store.create_command("xoa_het")
    with pytest.raises(ValueError):
        store.create_command("scan", status="bay_mau")


def test_list_commands_newest_first_and_filters(store, profile):
    a = store.create_command("scan", source="ui", profile_id=profile["id"], status="queued")
    b = store.create_command(
        "optimize", source="ui", profile_id=profile["id"], status="waiting_muse"
    )
    c = store.create_command("open_browser", source="api", status="queued")
    ids = [cmd["id"] for cmd in store.list_commands()]
    assert ids[0] == c["id"] and ids[-1] == a["id"]  # mới nhất trước
    assert [cmd["id"] for cmd in store.list_commands(source="api")] == [c["id"]]
    assert [cmd["id"] for cmd in store.list_commands(status="waiting_muse")] == [b["id"]]
    assert len(store.list_commands(profile_id=profile["id"])) == 2


def test_claim_command_is_atomic(store):
    cmd = store.create_command("scan", status="queued")
    assert store.claim_command(cmd["id"]) is True
    claimed = store.get_command(cmd["id"])
    assert claimed["status"] == "running"
    assert claimed["started_at"]
    # Nhận lần hai phải trượt — lệnh không còn 'queued'.
    assert store.claim_command(cmd["id"]) is False


def test_finish_command_stamps_and_stores_result(store):
    cmd = store.create_command("scan", status="queued")
    store.claim_command(cmd["id"])
    done = store.finish_command(
        cmd["id"], "done", result="xong", result_json={"channels_found": 3}
    )
    assert done["status"] == "done"
    assert done["result"] == "xong"
    assert done["result_data"] == {"channels_found": 3}
    assert done["finished_at"]


def test_update_command_for_muse_progress(store):
    cmd = store.create_command("optimize", status="waiting_muse", instruction="SEO lại")
    updated = store.update_command(cmd["id"], status="running", result="đang làm bước 2")
    assert updated["status"] == "running"
    assert updated["started_at"]
    assert updated["result"] == "đang làm bước 2"
    done = store.update_command(cmd["id"], status="done", result="đã xong")
    assert done["finished_at"]
    assert store.update_command("khong-co", status="done") is None


def test_delete_command(store):
    cmd = store.create_command("free", status="waiting_muse")
    store.delete_command(cmd["id"])
    assert store.get_command(cmd["id"]) is None


# --------------------------------------------------------------------------- #
# Automation rules
# --------------------------------------------------------------------------- #
def test_rules_crud_and_seed_idempotent(store):
    store.seed_default_rules()
    rules = store.list_rules()
    assert len(rules) == 2
    by_action = {r["action"]: r for r in rules}
    assert by_action["scan"]["schedule_kind"] == "daily"
    assert by_action["scan"]["daily_time"] == "08:00"
    assert by_action["scan"]["enabled"] is False
    assert by_action["check"]["schedule_kind"] == "interval"
    assert by_action["check"]["interval_hours"] == 6
    # Gieo lại không nhân đôi.
    store.seed_default_rules()
    assert len(store.list_rules()) == 2

    rule = store.update_rule(rules[0]["id"], enabled=True)
    assert rule["enabled"] is True
    store.delete_rule(rules[0]["id"])
    assert store.get_rule(rules[0]["id"]) is None
    with pytest.raises(ValueError):
        store.update_rule(rules[1]["id"], truong_la=1)
    with pytest.raises(ValueError):
        store.add_rule("optimize")  # optimize không tự chạy tại app được


# --------------------------------------------------------------------------- #
# Checks storage + videos
# --------------------------------------------------------------------------- #
def test_save_and_get_last_check(store, profile):
    items = [{"key": "chrome", "label": "Chrome", "status": "ok", "detail": "đang chạy"}]
    saved = store.save_check(profile["id"], items, "1 đạt, 0 lỗi, 0 chưa rõ (tổng 1 mục)")
    assert saved["items"] == items
    assert saved["summary"].startswith("1 đạt")
    store.save_check(profile["id"], [], "mới hơn")
    last = store.get_last_check(profile["id"])
    assert last["summary"] == "mới hơn"
    assert store.get_last_check(99999) is None


def test_videos_upsert_and_scheduled_filter(store, profile):
    video = {
        "video_id": "VID1",
        "channel_id": "UC1",
        "title": "Tập 8",
        "status": "scheduled",
        "scheduled_at": "2026-11-03T19:30:00+07:00",
        "url": "https://youtu.be/VID1",
    }
    assert store.upsert_video(profile["id"], video) is True
    assert store.upsert_video(profile["id"], {**video, "title": "Tập 8 (sửa)"}) is False
    scheduled = store.list_videos(profile["id"], status="scheduled")
    assert len(scheduled) == 1
    assert scheduled[0]["title"] == "Tập 8 (sửa)"
    assert store.list_videos(profile["id"], status="public") == []
    with pytest.raises(ValueError):
        store.upsert_video(profile["id"], {"title": "thiếu id"})
