"""Kiểm thử V3.5 — đăng nhập muse.ai cho từng tài khoản Muse (lớp B):
hồ sơ Chrome riêng data/agents/, phân loại trạng thái trang muse.ai,
ChromeManager tôn trọng user_data_dir/start_url riêng, Store v6
web_state, và panel có cột Muse.ai + nút đăng nhập theo dòng chọn."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from app import agent_browser
from app.chrome_manager import ChromeManager
from app.store import Store


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_agent_browser_profile_shape(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    agent = {"id": 7, "name": "KenhChinh", "email": "lokn38666@gmail.com"}
    pseudo = agent_browser.agent_profile(agent)
    assert pseudo["id"] == -7
    assert pseudo["slug"] == "agent-7"
    assert pseudo["start_url"] == "https://muse.ai/"
    assert pseudo["user_data_dir"].endswith(os.path.join("agents", "agent-7"))
    assert pseudo["port"] > 0


def test_classify_muse_state():
    assert agent_browser.classify_muse_state(
        {"url": "https://muse.ai/", "hasComposer": True, "loginish": False}
    ) == "in"
    assert agent_browser.classify_muse_state(
        {"url": "https://muse.ai/", "hasComposer": False, "loginish": True}
    ) == "out"
    assert agent_browser.classify_muse_state(
        {"url": "https://accounts.google.com/signin", "hasComposer": False, "loginish": True}
    ) == "unknown"
    assert agent_browser.classify_muse_state(None) == "unknown"


def test_store_web_state_roundtrip(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    assert store.schema_version >= 6
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    assert agent["web_state"] == "unknown"
    updated = store.set_agent_web_state(agent["id"], "waiting")
    assert updated["web_state"] == "waiting"
    updated = store.set_agent_web_state(agent["id"], "in")
    assert updated["web_state"] == "in"
    with pytest.raises(ValueError):
        store.set_agent_web_state(agent["id"], "bậy")
    store.close()


def test_chrome_manager_honors_overrides(tmp_path, monkeypatch):
    from app import chrome_manager as cm

    captured = {}

    class FakeProcess:
        pid = 4321

        def poll(self):
            return None

    def fake_popen(args, **kwargs):
        captured["args"] = args
        return FakeProcess()

    monkeypatch.setattr(cm.subprocess, "Popen", fake_popen)
    state = {"open": False}

    def fake_port_open(port, timeout=0.6):
        return state["open"]

    def fake_popen_marked(args, **kwargs):
        state["open"] = True
        return fake_popen(args, **kwargs)

    monkeypatch.setattr(cm.subprocess, "Popen", fake_popen_marked)
    monkeypatch.setattr(cm.cdp, "debug_port_open", fake_port_open)
    monkeypatch.setattr(cm.config, "find_chrome", lambda override=None: "chrome.exe")
    manager = ChromeManager()
    custom_dir = tmp_path / "agents" / "agent-3"
    result = manager.launch(
        {
            "slug": "agent-3",
            "port": 19555,
            "label": "Muse X",
            "user_data_dir": str(custom_dir),
            "start_url": "https://muse.ai/",
        }
    )
    assert result == "launched"
    args = captured["args"]
    assert f"--user-data-dir={custom_dir}" in args
    assert args[-1] == "https://muse.ai/"
    assert custom_dir.exists()


def test_agents_panel_login_button_and_web_column(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.agents_panel import AgentsPanel

    store = Store(tmp_path / "t.sqlite3")
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.set_agent_web_state(agent["id"], "in")
    calls = []
    panel = AgentsPanel(store, login_handler=lambda a: calls.append(a["id"]))
    panel.refresh()
    # V4.3 (G6): bảng có thêm cột "🎫 Phiếu" (thời điểm xuất phiếu
    # gần nhất) → 8 cột (ghim cũ 7 cột của V3.5 đã cập nhật cùng đợt).
    # V5.0 (gộp V4.6): thêm cột "Kết nối" (nút 🔌 từng dòng) ở cuối
    # → 9 cột; các cột cũ giữ nguyên vị trí.
    assert panel.table.columnCount() == 9
    assert "Đã đăng nhập" in panel.table.item(0, 3).text()
    panel.table.setCurrentCell(0, 0)
    panel.login_button.click()
    assert calls == [agent["id"]]
    panel.close()
    store.close()
