"""V5.2 — vòng sửa lỗi máy thật bị chủ kênh bác ở V5.1:

1) HIỆU NĂNG: vân RẺ cho chat (refresh khi vân không đổi KHÔNG
   dựng lại bong bóng), timer của panel ẩn không chạy refresh
   (MonitorPanel hết mồ côi + tick chat tự gate hiển thị), vân NHẸ
   cho kho (messages_signature / list_*_light).
2) HỒ SƠ: bỏ hẳn thanh chip; tường trình duyệt MỘT CỘT DỌC
   (lệnh chủ kênh 15:57 thay quy cách lưới trong brief gốc): thứ
   tự cố định theo id, ô ≤1150px rộng, khung nhìn ~16:9 tối
   thiểu 480px cao; CHỈ-NHÚNG — nhúng lỗi thì đỗ khuất cửa sổ +
   placeholder lỗi kèm nút Nhúng lại trong app; ZOOM đã lưu áp
   qua CDP sau MỌI sự kiện nhúng.
3) TÀI SẢN THẬT: robot_avatar.png + office_floor.jpg đóng gói
   trong app/assets, pixmap nạp được + cache + vòng màu theo agent.

Đường nhúng thật (Win32 SetParent) chỉ chạy trên Windows — ở đây
kiểm chứng bằng CDP/docking GIẢ ở đúng các seam mà MainWindow gọi.
"""

from __future__ import annotations

import pytest

from app import browser_zoom, config
from app.chrome_manager import ChromeManager
from app.store import Store
from app.ui import theme


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    instance = Store(config.db_path())
    yield instance
    instance.close()


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    instance = Store(config.db_path())
    from app.ui.main_window import MainWindow

    win = MainWindow(instance, ChromeManager(), settings)
    yield win, instance
    win.close()
    instance.close()


def _spin(qapp):
    qapp.processEvents()


# --------------------------------------------------------------------------- #
# 3) Tài sản thật đóng gói
# --------------------------------------------------------------------------- #
def test_assets_exist_and_are_small():
    robot = theme.ASSETS_DIR / "robot_avatar.png"
    floor = theme.ASSETS_DIR / "office_floor.jpg"
    assert robot.exists() and floor.exists()
    # Ngân sách đóng gói của lệnh V5.2: mỗi file < 400KB.
    assert robot.stat().st_size < 400_000
    assert floor.stat().st_size < 400_000


def test_robot_avatar_pixmap_ring_grey_and_cache(qapp):
    color_a = theme.robot_avatar_pixmap(48, ring=theme.agent_ring_color(1))
    color_b = theme.robot_avatar_pixmap(48, ring=theme.agent_ring_color(2))
    grey = theme.robot_avatar_pixmap(48, grey=True)
    assert color_a is not None and not color_a.isNull()
    assert color_a.size().width() == 48
    # Vòng màu KHÁC nhau theo agent → hai pixmap khác nhau.
    assert color_a.toImage() != color_b.toImage()
    # Bản xám khác bản màu.
    assert grey is not None
    assert grey.toImage() != color_a.toImage()
    # Cache: gọi lại cùng tham số trả ĐÚNG một đối tượng (không vẽ lại).
    assert theme.robot_avatar_pixmap(48, ring=theme.agent_ring_color(1)) is color_a
    # Màu vòng tất định theo agent.
    assert theme.agent_ring_color(7) == theme.agent_ring_color(7)
    assert theme.agent_ring_color(1) != theme.agent_ring_color(2)


def test_office_floor_pixmap_loads(qapp):
    pixmap = theme.office_floor_pixmap()
    assert pixmap is not None and not pixmap.isNull()
    assert pixmap.width() >= 1000  # ảnh gốc 2048x1152


# --------------------------------------------------------------------------- #
# 1) Hiệu năng — vân rẻ + timer panel ẩn
# --------------------------------------------------------------------------- #
def test_store_light_queries_and_signature(store):
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.add_message(agent["id"], "user", "xin chào")
    store.add_message(agent["id"], "agent", "chào bạn")
    sig = store.messages_signature(agent["id"])
    assert sig[0] == 2 and sig[1] > 0 and sig[2] == 1  # 2 tin, 1 chưa đọc
    store.mark_read(agent["id"], "agent")
    assert store.messages_signature(agent["id"])[2] == 0
    # Bản nhẹ chỉ có đúng các cột vân cần.
    light_agents = store.list_agents_light()
    assert light_agents and set(light_agents[0]) >= {
        "id", "last_seen_at", "status",
    }
    assert profile["id"]  # hồ sơ tồn tại cho các test khác dùng kho


def _thread_widgets(chat):
    widgets = []
    for index in range(chat.thread_layout.count()):
        item = chat.thread_layout.itemAt(index)
        if item is not None and item.widget() is not None:
            widgets.append(item.widget())
    return widgets


def test_chat_refresh_unchanged_signature_does_not_rebuild(qapp, store):
    """Cổng hiệu năng bắt buộc của V5.2: refresh chat khi VÂN
    không đổi không được dựng lại bong bóng (đếm + đối chiếu chính
    đối tượng widget con trước/sau)."""
    from app.ui.agent_chat import AgentChatWidget

    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    for index in range(5):
        store.add_message(agent["id"], "user", f"tin {index}")
        store.add_message(agent["id"], "agent", f"trả lời {index}")
    chat = AgentChatWidget(store)
    chat.set_agent(store.get_agent(agent["id"]))
    chat.show()
    _spin(qapp)
    before = _thread_widgets(chat)
    assert len(before) >= 10
    # Nhịp thường + nhịp timer: vân không đổi → giữ nguyên widget.
    chat.refresh()
    chat._on_timer_tick()
    after = _thread_widgets(chat)
    assert len(after) == len(before)
    assert all(a is b for a, b in zip(after, before))
    # Có tin MỚI thì dựng lại thật (cổng không được nuốt dữ liệu).
    store.add_message(agent["id"], "agent", "tin mới")
    chat.refresh()
    assert len(_thread_widgets(chat)) == len(before) + 1
    chat.close()


def test_hidden_panels_timers_do_not_refresh(qapp, store, monkeypatch):
    """Timer của panel ẨN không chạy refresh (bài học §8/§15):
    MonitorPanel không còn tự start timer khi chưa từng hiện;
    tick của chat khi ẩn cũng dừng tay."""
    from app.ui.agent_chat import AgentChatWidget
    from app.ui.monitor_panel import MonitorPanel

    panel = MonitorPanel(store)
    calls = []
    monkeypatch.setattr(panel, "refresh", lambda: calls.append(1))
    # Chưa từng hiện → timer không chạy; tick gọi tay cũng bị gate.
    assert not panel._timer.isActive()
    panel._on_timer_tick()
    assert calls == []
    panel.show()
    _spin(qapp)
    assert panel._timer.isActive()
    panel.hide()
    assert not panel._timer.isActive()
    panel.close()

    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.add_message(agent["id"], "user", "alo")
    chat = AgentChatWidget(store)
    chat.set_agent(store.get_agent(agent["id"]))
    chat.show()
    _spin(qapp)
    before = _thread_widgets(chat)
    chat.hide()
    store.add_message(agent["id"], "agent", "tin trong lúc ẩn")
    chat._on_timer_tick()  # ẩn → KHÔNG refresh dù có tin mới
    assert _thread_widgets(chat) == before
    chat.show()  # hiện lại → showEvent refresh, thấy tin mới
    _spin(qapp)
    assert len(_thread_widgets(chat)) == len(before) + 1
    chat.close()


def test_commands_panel_refresh_light_gate(qapp, store, monkeypatch):
    """Cổng nạp nhẹ của bảng lệnh (V5.2): refresh khi dữ liệu
    không đổi KHÔNG nạp lại bản đầy đủ (list_commands) — trước
    đây mỗi nhịp 4s vẫn SELECT * + parse JSON 100 lệnh."""
    from app.ui.commands_panel import CommandsPanel

    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.create_command("scan", profile_id=profile["id"],
                         instruction="quét kênh")
    panel = CommandsPanel(store)  # ctor đã refresh 1 lần
    full_fetches = []
    original = store.list_commands

    def counting(*args, **kwargs):
        full_fetches.append(1)
        return original(*args, **kwargs)

    monkeypatch.setattr(store, "list_commands", counting)
    panel.refresh()
    panel.refresh()
    assert full_fetches == []  # vân nhẹ không đổi → không nạp nặng
    store.create_command("scan", profile_id=profile["id"],
                         instruction="lệnh mới")
    panel.refresh()
    assert len(full_fetches) == 1  # có lệnh mới → nạp lại thật
    panel.close()


# --------------------------------------------------------------------------- #
# 2) Hồ sơ — bỏ chip, tường (V5.3: lưới ô 600×800), chỉ-nhúng, zoom
# --------------------------------------------------------------------------- #
def test_chip_bar_removed(window):
    win, _store = window
    # Thanh chip V5.1 đã bỏ HẲN (lệnh trực tiếp của chủ kênh).
    assert not hasattr(win, "btn_chip_sidebar")
    assert not hasattr(win, "btn_chip_data")
    assert not hasattr(win, "profile_chip_pill")
    assert not hasattr(win, "_build_profile_chip_bar")
    assert not hasattr(win, "_apply_profiles_focus")
    # Khung giữ chỗ lỗi nhúng + nút Nhúng lại tồn tại trong app.
    assert hasattr(win, "dock_placeholder")
    assert win.btn_dock_retry.text() == "Nhúng lại"


def _grid_tile_ids(wall):
    """Thứ tự ô đọc từ VỊ TRÍ LƯỚI (hàng, cột) — thứ tự trực quan
    trái→phải, trên→dưới."""
    positioned = [
        (wall.tile_position(pid), pid) for pid in wall.tiles
    ]
    return [pid for _pos, pid in sorted(positioned)]


def test_wall_single_column_order_and_tile_size(qapp, store):
    """V5.3 — HÀNH VI MỚI THAY HÀNH VI CŨ CÓ CHỦ ĐÍCH: lệnh MỚI
    NHẤT của chủ kênh 2026-10-30 18:10 bỏ quy cách cột dọc V5.2
    (ô ≤1150px, cao 16:9). Quy cách nay: ô CỐ ĐỊNH 600×800, tối
    đa 3 ô/hàng, thứ tự ô theo id tăng dần dù đầu vào xáo trộn;
    refresh cùng danh sách giữ nguyên đối tượng ô."""
    from app.ui.browser_wall import (
        TILE_HEIGHT, TILE_WIDTH, BrowserWall,
    )

    wall = BrowserWall(store)
    profiles = [
        {"id": 3, "label": "HoSo3", "email": "", "slug": "c"},
        {"id": 1, "label": "HoSo1", "email": "", "slug": "a"},
        {"id": 2, "label": "HoSo2", "email": "", "slug": "b"},
    ]
    wall.set_entries(profiles, {})
    assert _grid_tile_ids(wall) == [1, 2, 3]
    # Refresh cùng danh sách (đảo thứ tự đầu vào) → giữ nguyên ô.
    tiles_before = dict(wall.tiles)
    wall.set_entries(list(reversed(profiles)), {})
    assert wall.tiles == tiles_before
    assert _grid_tile_ids(wall) == [1, 2, 3]

    # Kích thước CỐ ĐỊNH ở mọi bề rộng vùng chứa (1600 và 500px):
    # ô luôn đúng 600×800, khung nhìn luôn TILE_HOST_HEIGHT.
    from app.ui.browser_wall import TILE_HOST_HEIGHT

    for width in (1600, 500):
        wall.resize(width, 900)
        wall.show()
        _spin(qapp)
        for pid in (1, 2, 3):
            tile = wall.tiles[pid]
            assert tile.width() == TILE_WIDTH == 600
            assert tile.height() == TILE_HEIGHT == 800
            assert tile.host.height() == TILE_HOST_HEIGHT
    wall.close()


def test_dock_failure_parks_window_and_shows_placeholder(window, monkeypatch):
    """Nhúng LỖI (attach thất bại): cửa sổ bị đỗ khuất (không nổi
    ngoài app), placeholder lỗi hiện TRONG khung nhúng kèm hướng
    dẫn + nút Nhúng lại, tab ở lại tab Nhúng."""
    win, store = window
    from app.ui import main_window as mw

    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    win._current_profile_id = profile["id"]
    monkeypatch.setattr(mw.docking, "IS_WINDOWS", True)
    monkeypatch.setattr(
        mw.docking, "find_chrome_window", lambda p, m: 4242
    )
    parked = []
    monkeypatch.setattr(win, "_park_window", parked.append)
    monkeypatch.setattr(win._dock, "attach", lambda *a, **k: False)
    win._try_dock()
    assert parked == [4242]
    # Cửa sổ test không show() → kiểm cờ ẩn của chính widget.
    assert not win.dock_placeholder.isHidden()
    text = win.dock_placeholder_label.text()
    assert "Nhúng lại" in text and profile["label"] in text
    assert win.live_tabs.currentIndex() == mw.TAB_EMBED


def test_dock_success_applies_saved_zoom(window, monkeypatch):
    """Nhúng THÀNH CÔNG → zoom đã lưu được áp (ép buộc) ngay;
    placeholder lỗi ẩn đi."""
    win, store = window
    from app.ui import main_window as mw

    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    win._current_profile_id = profile["id"]
    monkeypatch.setattr(mw.docking, "IS_WINDOWS", True)
    monkeypatch.setattr(
        mw.docking, "find_chrome_window", lambda p, m: 777
    )
    monkeypatch.setattr(win._dock, "attach", lambda *a, **k: True)
    monkeypatch.setattr(win._watchdog, "watch", lambda *a, **k: None)
    zoom_calls = []
    monkeypatch.setattr(
        win, "_request_zoom_apply",
        lambda profile, force=False: zoom_calls.append(
            (profile["id"], force)
        ),
    )
    win._try_dock()
    assert zoom_calls == [(profile["id"], True)]
    assert win.dock_placeholder.isHidden()


def test_zoom_command_uses_saved_pct_with_fake_cdp():
    """Lệnh zoom phát qua CDP phải đúng % ĐÃ LƯU của hồ sơ (seam
    browser_zoom.apply_zoom_for_profile với client giả)."""
    calls = []

    class FakeClient:
        def call(self, method, params=None):
            calls.append((method, params))
            return {}

        def close(self):
            pass

    class FakeManager:
        def connect_page(self, profile):
            return FakeClient()

    settings = {}
    browser_zoom.set_zoom_pct(settings, "kenhchinh", 90)
    profile = {"id": 1, "slug": "kenhchinh"}
    pct = browser_zoom.get_zoom_pct(settings, profile["slug"])
    assert browser_zoom.apply_zoom_for_profile(
        FakeManager(), profile, pct
    )
    assert calls == [
        ("Emulation.setPageScaleFactor", {"pageScaleFactor": 0.9})
    ]
