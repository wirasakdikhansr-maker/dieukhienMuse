"""V4.5 — MetaMint + tường trình duyệt + Công việc thiết kế lại +
kênh checkbox theo LÔ + lệnh thất bại TỰ CHẠY LẠI sau 30 giây:

- Preset mặc định 'metamint' (một màu nhấn xanh lá); di trú an
  toàn từ CẢ HAI bộ gốc (Mission cyan V4.3, Concept D V4.3.1) —
  theme đã tuỳ biến giữ nguyên.
- Tường trình duyệt: V4.5 là lưới wall_columns; V5.2 thay bằng
  MỘT CỘT DỌC (lệnh chủ kênh 2026-10-30 15:57); V5.3 thay bằng
  ô CỐ ĐỊNH 600×800, tối đa 3 ô/hàng (lệnh MỚI NHẤT của chủ
  kênh 2026-10-30 18:10) — quy cách ở wall_columns của V5.3.
- Thứ tự điều hướng mới: Tài khoản Muse ở vị trí 5, cạnh Hệ
  thống (6); widget ở stack[SEC_AGENTS] đúng là AgentsPanel.
- Công việc: cột trái Giao việc (form_card + queue_panel), cột
  phải bảng việc + list_block; splitter khoá settings h2/v2.
- Checkbox kênh: tick N kênh → N lệnh chung batch_id, đúng hồ
  sơ/kênh từng lệnh; tick 1 kênh = không lô; loại bắt buộc kênh
  mà 0 tick → lỗi tại form, không tạo lệnh.
- Tự chạy lại: failed → hẹn +30s → process_auto_retries xếp lại
  (app-side về queued, Claude-side về waiting_muse); chặn bởi
  needs_user / đã huỷ / payload không hợp lệ / trần 3 lần; huỷ
  chạy lại giữ nguyên failed; trạng thái retry sống sót qua
  khởi động lại (Store mới trên cùng file DB).
"""

import dataclasses
import os
from datetime import datetime, timedelta

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import auto_retry, config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import theme  # noqa: E402
from app.ui.browser_wall import wall_columns  # noqa: E402
from app.ui.commands_panel import CommandsPanel  # noqa: E402
from app.ui.main_window import (  # noqa: E402
    NAV_ITEMS,
    SEC_AGENTS,
    SEC_SYSTEM,
    MainWindow,
)
from app.ui.work_panel import WorkPanel  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


# --------------------------------------------------------------------- #
# 1) Theme MetaMint + di trú an toàn
# --------------------------------------------------------------------- #
def _flat(tokens) -> dict:
    return {f.name: getattr(tokens, f.name) for f in dataclasses.fields(tokens)}


def test_metamint_is_default_palette():
    # V5.1 (pin mới, plan §1.1): bảng token duyệt mới — nền
    # #0B0E11, panel #15181D, chữ phụ #9BA3AB; accent giữ #4ADE80.
    assert theme.METAMINT_TOKENS.bg == "#0C0D0F"  # V5.1 style lock
    assert theme.METAMINT_TOKENS.accent == "#CEFC19"  # V5.1 style lock
    assert theme.METAMINT_TOKENS.panel == "#16171B"  # V5.1 style lock
    assert theme.METAMINT_TOKENS.text == "#ECEEF1"
    assert theme.METAMINT_TOKENS.muted == "#9AA0A8"  # V5.1 style lock
    # Preset mặc định của app là metamint.
    assert "metamint" in theme.PRESETS
    assert theme.PRESETS["metamint"].accent == "#CEFC19"
    # QSS mặc định không còn xanh dương Concept D.
    qss = theme.build_qss(theme.PRESETS["metamint"])
    assert "#2E7CF6" not in qss
    assert "#CEFC19" in qss


def test_theme_migration_concept_d_stock_to_metamint():
    migrated = theme.migrate_saved_tokens(_flat(theme.CONCEPT_D_TOKENS))
    assert migrated.accent == "#CEFC19"
    assert migrated.bg == "#0C0D0F"  # V5.1: đích di trú = token mới


def test_theme_migration_legacy_cyan_stock_to_metamint():
    migrated = theme.migrate_saved_tokens(_flat(theme.LEGACY_MISSION_TOKENS))
    assert migrated.accent == "#CEFC19"


def test_theme_migration_customized_kept():
    saved = _flat(theme.CONCEPT_D_TOKENS)
    saved["accent"] = "#FF00AA"  # người dùng đã tuỳ biến
    migrated = theme.migrate_saved_tokens(saved)
    assert migrated.accent == "#FF00AA"


# --------------------------------------------------------------------- #
# 2) Tường trình duyệt: quy cách Ô
# --------------------------------------------------------------------- #
# V5.3 — HÀNH VI MỚI THAY HÀNH VI CŨ CÓ CHỦ ĐÍCH: lệnh MỚI NHẤT
# của chủ kênh 2026-10-30 18:10 bỏ quy cách cột dọc V5.2 (ô rộng
# tối đa 1150px, cao 16:9 theo tile_host_height) — tường nay là
# LƯỚI ô CỐ ĐỊNH 600×800px, tối đa 3 ô/hàng, thừa xuống dòng.
# wall_columns: bao nhiêu ô 600px (khe 12px) vừa bề rộng vùng
# cuộn, chặn trần 3, sàn 1.
@pytest.mark.parametrize(
    "viewport_width,columns",
    [
        (500, 1),     # hẹp hơn một ô → vẫn 1 cột
        (700, 1),     # 1 ô (612) vừa, 2 ô (1224) không
        (1300, 2),    # 2 ô vừa (1224), 3 ô (1836) không
        (1920, 3),    # 3 ô vừa → trần 3
        (3000, 3),    # rất rộng vẫn trần 3 (lệnh chủ kênh)
    ],
)
def test_wall_columns(viewport_width, columns):
    assert wall_columns(viewport_width) == columns


# --------------------------------------------------------------------- #
# 3) Điều hướng: Tài khoản Muse cạnh Hệ thống
# --------------------------------------------------------------------- #
@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("KenhChinh", "lokn38666@gmail.com")
    store.upsert_channel(
        profile["id"],
        {
            "channel_id": "UC1", "name": "Kênh Chính",
            "handle": "@kenhchinh",
            "url": "https://www.youtube.com/channel/UC1",
            "subs": 10, "video_count": 3,
        },
    )
    win = MainWindow(store, ChromeManager(), settings)
    yield win
    win.close()
    store.close()


def test_nav_order_agents_next_to_system(window):
    labels = [label for _icon, label in NAV_ITEMS]
    assert labels == [
        "Văn phòng", "Hồ sơ", "Công việc", "Báo cáo",
        "Tự động", "Tài khoản Muse", "Hệ thống",
        # V6.0: mục Giám sát nối ở CUỐI (chỉ số 7) — pin cập nhật
        # cùng bump; 7 mục đầu giữ nguyên thứ tự/chỉ số.
        "Giám sát",
    ]
    assert window.sections.widget(SEC_AGENTS) is window.agents_panel
    # V5.1 (pin đổi theo plan §2.7): mục Hệ thống = THẺ CẦU NỐI ở
    # trên + các tab bên dưới → widget của section là system_page
    # bọc system_tabs (trước V5.1 section là thẳng system_tabs).
    assert window.sections.widget(SEC_SYSTEM) is window.system_page
    assert window.system_tabs.parent() is window.system_page


def test_work_panel_layout_v45(window):
    panel = window.work_panel
    # Splitter chính: [cột Giao việc | cột phải], mặc định 430px.
    assert panel.splitter.count() == 2
    assert panel.splitter.widget(0) is panel.assign_scroll
    assert panel.splitter.widget(1) is panel.right_splitter
    # Form + hàng đợi nằm trong cột trái; bảng lệnh ở cột phải.
    commands = window.commands_panel
    assert commands.form_card.parent() is not None
    assert panel.assign_scroll.widget().layout().itemAt(0).widget() is (
        commands.form_card
    )
    assert panel.assign_scroll.widget().layout().itemAt(1).widget() is (
        commands.queue_panel
    )
    # V6.3: khối "Danh sách lệnh" bị bỏ khỏi mặt hiển thị — vị trí 1 là
    # bảng việc chi tiết từng bước, list_block còn sống nhưng ẩn ở vị trí 2.
    assert panel.right_splitter.widget(2) is commands.list_block
    assert commands.list_block.isHidden()
    # Dải pill tổng quan đủ 5 trạng thái.
    assert set(panel.summary_pills) == {
        "running", "waiting", "needs_user", "failed", "done",
    }


# --------------------------------------------------------------------- #
# 4+5) Checkbox kênh → LÔ lệnh
# --------------------------------------------------------------------- #
@pytest.fixture()
def batch_panel(tmp_path, qapp):
    store = Store(tmp_path / "batch.db")
    p1 = store.add_profile("Kenh A", "a@gmail.com")
    p2 = store.add_profile("Kenh B", "b@gmail.com")
    for profile in (p1, p2):
        for j in range(2):
            store.upsert_channel(
                profile["id"],
                {
                    "channel_id": f"UC{profile['id']}_{j}",
                    "name": f"Kênh {profile['id']}-{j}",
                    "handle": f"@k{profile['id']}{j}",
                    "url": "", "subs": 1, "video_count": 1, "niche": "",
                },
            )
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [p1["id"], p2["id"]])
    panel = CommandsPanel(store)
    panel.show()
    yield store, panel, agent
    panel.close()
    store.close()


def _tick(panel, indexes):
    for i in indexes:
        panel._channel_checks[i][0].setChecked(True)


def test_batch_fanout_three_channels(batch_panel):
    store, panel, agent = batch_panel
    panel.agent_combo.setCurrentIndex(panel.agent_combo.findData(agent["id"]))
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("create_video"))
    panel.instruction_edit.setPlainText("Làm video theo lô")
    _tick(panel, [0, 2, 3])
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 3
    batch_ids = {(c["payload"] or {}).get("batch_id") for c in commands}
    assert len(batch_ids) == 1 and None not in batch_ids
    assert all(
        (c["payload"] or {}).get("batch_total") == 3 for c in commands
    )
    pairs = {(c["profile_slug"], c["channel_id"]) for c in commands}
    assert pairs == {
        ("kenh-a", "UC1_0"), ("kenh-b", "UC2_0"), ("kenh-b", "UC2_1"),
    }
    # Hàng đợi GỘP lô thành đúng 1 dòng.
    panel.refresh()
    assert panel.queue_layout.count() == 1


def test_single_channel_no_batch(batch_panel):
    store, panel, agent = batch_panel
    panel.agent_combo.setCurrentIndex(panel.agent_combo.findData(agent["id"]))
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("create_video"))
    panel.instruction_edit.setPlainText("Một kênh thôi")
    _tick(panel, [1])
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 1
    assert not (commands[0]["payload"] or {}).get("batch_id")
    assert commands[0]["channel_id"] == "UC1_1"


def test_required_channel_zero_checked_blocks(batch_panel):
    store, panel, agent = batch_panel
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("upload"))
    panel.instruction_edit.setPlainText("Đăng video X")
    panel._on_create()
    assert store.list_commands(limit=10) == []
    assert "tick ít nhất 1 kênh" in panel.form_status.text()


# --------------------------------------------------------------------- #
# 7) Tự chạy lại khi thất bại
# --------------------------------------------------------------------- #
def _failed_command(store, **kwargs):
    error = kwargs.pop("error", "lỗi tạm thời")
    command = store.create_command(
        kwargs.pop("type", "scan"),
        source=kwargs.pop("source", "ui"),
        profile_id=kwargs.pop("profile_id", None),
        profile_slug=kwargs.pop("profile_slug", "kenh-a"),
        instruction=kwargs.pop("instruction", "việc kiểm thử"),
        status="running",
        **kwargs,
    )
    store.finish_command(command["id"], "failed", error=error)
    return store.get_command(command["id"])


def test_auto_retry_schedules_and_requeues(tmp_path):
    store = Store(tmp_path / "retry.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    command = _failed_command(store, profile_id=profile["id"])
    payload = command["payload"] or {}
    assert payload.get(auto_retry.KEY_COUNT) == 1
    assert payload.get(auto_retry.KEY_AT)
    # Chưa tới hạn → chưa chạy lại.
    now = datetime.now().astimezone()
    assert store.process_auto_retries(now=now) == []
    # Tới hạn (+31s) → app-side về 'queued', giữ nguyên số lần.
    requeued = store.process_auto_retries(now=now + timedelta(seconds=31))
    assert [c["id"] for c in requeued] == [command["id"]]
    after = store.get_command(command["id"])
    assert after["status"] == "queued"
    assert (after["payload"] or {}).get(auto_retry.KEY_COUNT) == 1
    store.close()


def test_auto_retry_claude_requeues_for_dispatcher(tmp_path):
    # Lệnh Muse: tầng store xếp lại về 'queued' (đúng quy ước
    # V4.0 Đ5 — MỌI lệnh vào 'queued'), dispatcher của AgentServer
    # xét điều kiện rồi đẩy lên 'waiting_muse' đánh thức hook như
    # lệnh mới; agent_id được GIỮ để lần chạy lại về đúng Muse.
    store = Store(tmp_path / "retry2.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    command = _failed_command(
        store, type="create_video", source="api",
        profile_id=profile["id"], agent_id=agent["id"],
    )
    now = datetime.now().astimezone()
    requeued = store.process_auto_retries(now=now + timedelta(seconds=31))
    assert [c["id"] for c in requeued] == [command["id"]]
    after = store.get_command(command["id"])
    assert after["status"] == "queued"
    assert after["agent_id"] == agent["id"]
    store.close()


def test_auto_retry_blocked_by_needs_user(tmp_path):
    store = Store(tmp_path / "retry3.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    command = store.create_command(
        "scan", source="ui", profile_id=profile["id"],
        profile_slug="kenh-a", instruction="việc", status="running",
    )
    store.set_command_needs_user(command["id"], "Cần đăng nhập lại")
    store.finish_command(command["id"], "failed", error="hết phiên")
    row = store.get_command(command["id"])
    payload = row["payload"] or {}
    assert payload.get(auto_retry.KEY_BLOCKED) == "needs_user"
    assert not payload.get(auto_retry.KEY_AT)
    now = datetime.now().astimezone()
    assert store.process_auto_retries(now=now + timedelta(days=1)) == []
    store.close()


def test_auto_retry_blocked_by_cancel_and_invalid(tmp_path):
    store = Store(tmp_path / "retry4.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    cancelled = _failed_command(
        store, profile_id=profile["id"], error="Đã huỷ bởi người dùng"
    )
    assert (cancelled["payload"] or {}).get(auto_retry.KEY_BLOCKED) == "cancelled"
    invalid = _failed_command(
        store, profile_id=profile["id"],
        error="Payload lệnh không hợp lệ: thiếu steps",
    )
    assert (invalid["payload"] or {}).get(auto_retry.KEY_BLOCKED) == "invalid"
    store.close()


def test_auto_retry_cap_three_and_cancel(tmp_path):
    store = Store(tmp_path / "retry5.db")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    command = _failed_command(store, profile_id=profile["id"])
    # Huỷ chạy lại: xoá hẹn, giữ failed, process không xếp lại.
    row = store.cancel_auto_retry(command["id"])
    assert (row["payload"] or {}).get(auto_retry.KEY_CANCELLED) is True
    assert not (row["payload"] or {}).get(auto_retry.KEY_AT)
    now = datetime.now().astimezone()
    assert store.process_auto_retries(now=now + timedelta(days=1)) == []
    assert store.get_command(command["id"])["status"] == "failed"
    # Trần 3 lần: payload đã ở lần 3 → fail nữa thì KHÔNG hẹn thêm.
    capped = _failed_command(
        store, profile_id=profile["id"],
        payload={auto_retry.KEY_COUNT: 3},
    )
    payload = capped["payload"] or {}
    assert payload.get(auto_retry.KEY_BLOCKED) == "max_retries"
    assert not payload.get(auto_retry.KEY_AT)
    store.close()


def test_auto_retry_survives_restart(tmp_path):
    db = tmp_path / "retry6.db"
    store = Store(db)
    profile = store.add_profile("Kenh A", "a@gmail.com")
    command = _failed_command(store, profile_id=profile["id"])
    store.close()
    # Mở Store MỚI trên cùng file (mô phỏng khởi động lại app):
    # lịch hẹn trong payload vẫn còn và được xử lý khi tới hạn.
    store2 = Store(db)
    now = datetime.now().astimezone()
    requeued = store2.process_auto_retries(now=now + timedelta(seconds=31))
    assert [c["id"] for c in requeued] == [command["id"]]
    store2.close()
