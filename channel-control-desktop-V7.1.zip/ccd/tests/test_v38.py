"""V3.8: cầu nối phải CÓ BẰNG CHỨNG — ghi nhận hoạt động API đã xác
thực, trạng thái kết nối tính từ dữ liệu thật, banner + guard ở tab
Lệnh để lệnh của Muse không còn nằm im vô thời hạn khi chưa có
Muse nào kết nối (nguyên nhân gốc của lỗi "ra lệnh mà Muse không
chạy": cầu nối chưa từng được nối mà app im lặng)."""

from datetime import datetime, timedelta

import pytest
from PySide6.QtWidgets import QApplication

from app import config
from app.agent_server import AgentServer
from app.store import Store
from app.ui.commands_panel import CommandsPanel
from test_agent_server import FakeManager, stub_scan


@pytest.fixture(scope="module", autouse=True)
def qapp():
    return QApplication.instance() or QApplication([])


def test_bridge_state_lifecycle(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    state = store.bridge_state()
    assert state["ever"] is False
    assert state["connected"] is False

    store.note_bridge_activity()
    state = store.bridge_state()
    assert state["ever"] is True
    assert state["connected"] is True
    assert state["seconds_ago"] is not None and state["seconds_ago"] < 60

    past = (datetime.now().astimezone() - timedelta(minutes=30)).isoformat(
        timespec="seconds"
    )
    store.set_meta("bridge_last_poll_at", past)
    state = store.bridge_state()
    assert state["ever"] is True
    assert state["connected"] is False  # quá 180 giây, không agent online


def test_bridge_state_agent_online_counts(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    agent = store.create_agent("Muse A", "a@claude.ai")
    assert store.bridge_state()["connected"] is False
    store.touch_agent_heartbeat(agent["id"])
    state = store.bridge_state()
    assert state["any_agent_online"] is True
    assert state["connected"] is True


def test_authenticated_api_call_records_bridge_activity(tmp_path):
    import json
    import urllib.request

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    seed.add_profile("P", "p@gmail.com")
    assert seed.bridge_state()["ever"] is False
    seed.close()

    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
    )
    server.start()
    try:
        req = urllib.request.Request(
            f"http://127.0.0.1:{server.port}/api/commands",
            headers={"X-Agent-Token": server.token},
        )
        with urllib.request.urlopen(req, timeout=5) as resp:
            payload = json.loads(resp.read())
        assert payload["ok"] is True
    finally:
        server.stop()
    check = Store(config.db_path(data_dir))
    try:
        assert check.bridge_state()["ever"] is True
        assert check.bridge_state()["connected"] is True
    finally:
        check.close()


def test_commands_panel_banner_warns_when_no_bridge(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    panel = CommandsPanel(store)
    panel._refresh_bridge_banner()
    assert "CHƯA CÓ MUSE NÀO KẾT NỐI" in panel.bridge_label.text()
    store.note_bridge_activity()
    panel._refresh_bridge_banner()
    assert "ĐANG KẾT NỐI" in panel.bridge_label.text()


def test_create_not_blocked_when_no_bridge(tmp_path):
    # V4.1.3 thay cho test_bridge_guard_blocks_when_no_bridge của
    # V3.8: hộp thoại chặn _bridge_guard đã bị GỠ theo yêu cầu người
    # dùng — lệnh đã tạo là lệnh đã cấp đầy đủ, trạng thái cầu nối
    # không được chặn việc ghi lệnh. Banner vẫn cảnh báo như test
    # ngay trên; tạo lệnh của Muse khi cầu nối đang chết vẫn phải
    # chèn được dòng lệnh (chi tiết kịch bản ở test_v413_create_always).
    store = Store(tmp_path / "t.sqlite3")
    panel = CommandsPanel(store)
    assert not hasattr(CommandsPanel, "_bridge_guard")
    assert store.bridge_state()["connected"] is False
    profile = store.add_profile("Kenh A", "a@gmail.com")
    panel.refresh()
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("create_video"))
    panel.instruction_edit.setPlainText("Tạo video khi cầu nối đang chết")
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 1
    assert commands[0]["type"] == "create_video"
