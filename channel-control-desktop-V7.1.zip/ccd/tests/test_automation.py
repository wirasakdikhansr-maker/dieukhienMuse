"""Kiểm thử V3 cho logic lịch tự động (automation) — thuần dữ liệu + engine."""

from datetime import datetime, timedelta, timezone

import pytest

from app.automation import (
    AutomationEngine,
    compute_next_run,
    is_due,
    next_daily_run,
    next_interval_run,
    parse_daily_time,
)
from app.store import Store

TZ = timezone(timedelta(hours=7))


def at(day: int, hour: int, minute: int = 0) -> datetime:
    return datetime(2026, 10, day, hour, minute, tzinfo=TZ)


# --------------------------------------------------------------------------- #
# Logic lịch thuần
# --------------------------------------------------------------------------- #
def test_parse_daily_time():
    assert parse_daily_time("08:30").hour == 8
    assert parse_daily_time("08:30").minute == 30
    assert parse_daily_time("tào lao").hour == 8  # sai -> mặc định 08:00
    assert parse_daily_time(None).hour == 8


def test_next_daily_run_before_and_after():
    assert next_daily_run("08:00", at(28, 7, 59)) == at(28, 8, 0)
    # Đúng giờ vẫn tính là đã qua -> sang ngày mai.
    assert next_daily_run("08:00", at(28, 8, 0)) == at(29, 8, 0)
    assert next_daily_run("08:00", at(28, 23, 30)) == at(29, 8, 0)


def test_next_interval_run():
    assert next_interval_run(6, at(28, 8)) == at(28, 14)
    assert next_interval_run(None, at(28, 8)) == at(28, 14)  # mặc định 6h
    # Chu kỳ tối thiểu 0.25h.
    assert next_interval_run(0.01, at(28, 8)) == at(28, 8) + timedelta(minutes=15)


def test_is_due_requires_enabled_and_reached_time():
    rule = {"enabled": True, "schedule_kind": "daily", "daily_time": "08:00",
            "next_run_at": at(28, 8).isoformat()}
    assert is_due(rule, at(28, 8, 1)) is True
    assert is_due(rule, at(28, 7, 0)) is False
    assert is_due({**rule, "enabled": False}, at(28, 9)) is False


def test_compute_next_run_interval_first_time_is_now():
    rule = {"schedule_kind": "interval", "interval_hours": 6,
            "last_run_at": None, "next_run_at": None}
    assert compute_next_run(rule, at(28, 8)) == at(28, 8)
    ran = {**rule, "last_run_at": at(28, 8).isoformat()}
    assert compute_next_run(ran, at(28, 9)) == at(28, 14)


# --------------------------------------------------------------------------- #
# Engine
# --------------------------------------------------------------------------- #
@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "test.sqlite3")
    yield s
    s.close()


def test_engine_fires_due_rule_for_all_profiles(store):
    a = store.add_profile("A", "a@gmail.com")
    b = store.add_profile("B", "b@gmail.com")
    store.set_profile_paused(b["id"], True)
    rule = store.add_rule(
        "scan", schedule_kind="daily", daily_time="08:00", enabled=True,
        next_run_at=at(28, 8).isoformat(),
    )
    engine = AutomationEngine(store)
    created = engine.tick(at(28, 8, 5))
    # Chỉ hồ sơ A (B đang tạm dừng) -> đúng 1 lệnh, nguồn 'auto', trạng thái queued.
    assert len(created) == 1
    assert created[0]["profile_id"] == a["id"]
    assert created[0]["source"] == "auto"
    assert created[0]["status"] == "queued"
    assert created[0]["type"] == "scan"
    updated = store.get_rule(rule["id"])
    assert updated["last_run_at"] == at(28, 8, 5).isoformat(timespec="seconds")
    assert updated["next_run_at"] == at(29, 8).isoformat(timespec="seconds")
    # Tick lại ngay: chưa tới hạn nữa -> không tạo thêm.
    assert engine.tick(at(28, 8, 6)) == []


def test_engine_ignores_disabled_and_future_rules(store):
    store.add_profile("A", "a@gmail.com")
    store.add_rule("scan", schedule_kind="daily", daily_time="08:00", enabled=False,
                   next_run_at=at(28, 8).isoformat())
    store.add_rule("check", schedule_kind="interval", interval_hours=6, enabled=True,
                   next_run_at=at(29, 8).isoformat())
    engine = AutomationEngine(store)
    assert engine.tick(at(28, 12)) == []


def test_engine_specific_profile_rule(store):
    a = store.add_profile("A", "a@gmail.com")
    store.add_profile("B", "b@gmail.com")
    store.add_rule("check", profile_id=a["id"], schedule_kind="interval",
                   interval_hours=6, enabled=True, next_run_at=at(28, 8).isoformat())
    created = AutomationEngine(store).tick(at(28, 9))
    assert len(created) == 1
    assert created[0]["profile_id"] == a["id"]
    assert created[0]["type"] == "check"
