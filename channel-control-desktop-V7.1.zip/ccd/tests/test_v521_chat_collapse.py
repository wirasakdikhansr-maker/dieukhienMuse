"""V5.2.1 — Chat THU/MỞ trong panel chi tiết Văn phòng.

Góp ý máy thật trên V5.2: khung chat chiếm hơn nửa chiều cao panel
chi tiết, khối "Việc hiện tại" bị bóp không đọc được. Chuẩn mới
(chỉ bản Văn phòng — AgentChatWidget với collapsible=True; bản ở
mục Tài khoản giữ hành vi luôn mở):

- Thanh tiêu đề luôn hiện (tiêu đề + huy hiệu chưa đọc + nút
  thu/mở); mặc định THU GỌN khi không có tin chưa đọc và không có
  câu hỏi needs_user đang chờ.
- TỰ BUNG khi có tin chưa đọc (kể cả tin đến lúc panel đang mở,
  qua nhịp refresh sẵn có), có câu hỏi chờ, hoặc người dùng mở tay.
- TỰ THU sau khi đọc hết/gửi trả lời và hết chờ — trừ khi người
  dùng đang mở TAY trong cùng lượt xem.
- Khi thu gọn, refresh CHỈ dùng vân rẻ: không nạp tin, không dựng
  lại bong bóng, không đánh dấu đã đọc.
- Khi bung, luồng tin bị chặn chiều cao 120–200px (cuộn bên
  trong) — chat không đẩy được nội dung công việc khỏi panel.
"""

import pytest
from PySide6.QtWidgets import QApplication

from app.store import Store
from app.ui.agent_chat import (
    OFFICE_THREAD_MAX_HEIGHT,
    OFFICE_THREAD_MIN_HEIGHT,
    AgentChatWidget,
)
from app.ui.office_view import OfficeView


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path):
    store = Store(tmp_path / "v521.db")
    yield store
    store.close()


def _pump(times=6):
    for _ in range(times):
        QApplication.processEvents()


def _agent(store, name="KenhChinh", email="lokn38666@gmail.com"):
    return store.create_agent(name, email)


def _office_chat(store, agent):
    chat = AgentChatWidget(store, collapsible=True)
    chat.set_agent(store.get_agent(agent["id"]))
    chat.show()
    _pump()
    return chat


def _thread_widgets(chat):
    widgets = []
    for index in range(chat.thread_layout.count()):
        item = chat.thread_layout.itemAt(index)
        if item is not None and item.widget() is not None:
            widgets.append(item.widget())
    return widgets


def _unread(store, agent_id):
    counts = store.unread_counts().get(agent_id, {})
    return int(counts.get("agent", 0)) + int(counts.get("system", 0))


# ---------------------------------------------------------------------- #
# Mặc định thu gọn + thanh tiêu đề + chặn chiều cao
# ---------------------------------------------------------------------- #
def test_collapsed_by_default_when_nothing_pending(qapp, store):
    agent = _agent(store)
    store.add_message(agent["id"], "user", "Tin cũ đã đọc hai chiều")
    store.mark_read(agent["id"], "user")
    chat = _office_chat(store, agent)
    # Không tin chưa đọc, không câu hỏi chờ → THU GỌN: thân ẩn,
    # chỉ còn thanh tiêu đề (nút thu/mở + huy hiệu) trên panel.
    assert chat.is_expanded is False
    assert chat.body_widget.isVisible() is False
    assert chat.expand_button is not None
    # Nút là MŨI TÊN (không phải chữ "▸ Mở chat"): render nghiệm
    # thu cho thấy nút chữ dài bị cắt cụt trong panel 320px — đổi
    # sang mũi tên + tooltip theo luật không-cắt-chữ của chủ kênh.
    assert chat.expand_button.text() == "▸"
    assert chat.expand_button.toolTip() == "Mở khung chat"
    assert chat.unread_badge.isVisible() is False
    # Chiều cao khi thu gọn chỉ là một thanh mảnh (đo bằng
    # sizeHint — đại lượng layout của panel sẽ cấp; widget độc
    # lập chưa vào layout thì height() là cỡ cửa sổ mặc định).
    assert chat.sizeHint().height() < 90
    chat.close()


def test_thread_height_is_capped_when_expanded(qapp, store):
    agent = _agent(store)
    for index in range(20):
        store.add_message(agent["id"], "agent", f"Tin số {index} " * 6)
    chat = _office_chat(store, agent)
    chat.expand_chat()
    _pump()
    assert chat.is_expanded is True
    # Luồng bị chặn ở hằng số đã đặt tên — cuộn bên trong, không
    # bao giờ phình theo số tin.
    assert chat.scroll.minimumHeight() == OFFICE_THREAD_MIN_HEIGHT
    assert chat.scroll.maximumHeight() == OFFICE_THREAD_MAX_HEIGHT
    assert chat.scroll.height() <= OFFICE_THREAD_MAX_HEIGHT
    chat.close()


# ---------------------------------------------------------------------- #
# Tự bung
# ---------------------------------------------------------------------- #
def test_auto_expand_on_unread_and_on_timer_tick(qapp, store):
    agent = _agent(store)
    chat = _office_chat(store, agent)
    assert chat.is_expanded is False

    # Tin Muse đến trong lúc panel đang mở → nhịp tick sẵn có của
    # khung chat (5s) tự bung, nạp luồng và đánh dấu đã đọc.
    store.add_message(agent["id"], "agent", "Em vừa xong bản nháp")
    chat._on_timer_tick()
    _pump()
    assert chat.is_expanded is True
    assert _unread(store, agent["id"]) == 0
    assert chat.unread_badge.isVisible() is False
    chat.close()


def test_auto_expand_on_pending_question(qapp, store):
    agent = _agent(store)
    chat = _office_chat(store, agent)
    assert chat.is_expanded is False
    chat.set_pending_question("cmd-123")
    _pump()
    assert chat.is_expanded is True
    # Huy hiệu dạng gọn "⏸" + tooltip đầy đủ (bản chữ dài bị cắt
    # trong panel hẹp — xem test thu gọn ở trên).
    assert chat.unread_badge.text() == "⏸"
    assert "chờ bạn trả lời" in chat.unread_badge.toolTip()
    chat.close()


# ---------------------------------------------------------------------- #
# Tự thu
# ---------------------------------------------------------------------- #
def test_auto_collapse_after_read_completes(qapp, store):
    agent = _agent(store)
    chat = _office_chat(store, agent)
    store.add_message(agent["id"], "agent", "Tin cần đọc")
    chat.refresh()  # tự bung + nạp + đánh dấu đã đọc ở nhịp này
    _pump()
    assert chat.is_expanded is True
    # Không thu NGAY trong nhịp vừa đọc (chống giật — tin phải ở
    # trên màn hình ít nhất một nhịp); nhịp refresh KẾ mới thu.
    chat.refresh()
    _pump()
    assert chat.is_expanded is False
    chat.close()


def test_auto_collapse_after_reply_resolves_question(qapp, store):
    agent = _agent(store)
    chat = _office_chat(store, agent)
    chat.set_pending_question("cmd-9")
    _pump()
    assert chat.is_expanded is True
    # Người dùng trả lời cho câu hỏi — chat VẪN mở trong lúc câu
    # hỏi chưa được gỡ (Muse chưa chạy tiếp).
    chat.composer.setPlainText("Mật khẩu đã nhập, chạy tiếp đi")
    chat._send()
    _pump()
    assert chat.is_expanded is True
    # Câu hỏi được gỡ sau hành động gửi → tự thu.
    chat.set_pending_question(None)
    _pump()
    assert chat.is_expanded is False
    chat.close()


def test_send_without_pending_collapses_immediately(qapp, store):
    agent = _agent(store)
    store.add_message(agent["id"], "agent", "Anh xem bản này nhé")
    chat = _office_chat(store, agent)
    assert chat.is_expanded is True  # tự bung vì tin chưa đọc
    chat.composer.setPlainText("Ok, duyệt")
    chat._send()
    _pump()
    assert chat.is_expanded is False
    chat.close()


# ---------------------------------------------------------------------- #
# Thu/mở TAY — giữ trạng thái trong lượt xem
# ---------------------------------------------------------------------- #
def test_manual_open_blocks_auto_collapse(qapp, store):
    agent = _agent(store)
    store.add_message(agent["id"], "agent", "Tin một")
    chat = _office_chat(store, agent)
    assert chat.is_expanded is True
    # Người dùng chủ động bấm mở (dù đang mở sẵn do tự bung, cú bấm
    # qua nút là chuyển sang chế độ TAY sau khi thu→mở một vòng).
    chat.expand_button.click()
    _pump()
    assert chat.is_expanded is False  # vừa bấm THU tay
    chat.expand_button.click()
    _pump()
    assert chat.is_expanded is True  # bấm MỞ tay
    # Đọc hết + hai nhịp refresh nữa — đang mở tay thì KHÔNG tự thu.
    chat.refresh()
    chat.refresh()
    _pump()
    assert chat.is_expanded is True
    chat.close()


def test_manual_close_holds_until_new_message(qapp, store):
    agent = _agent(store)
    store.add_message(agent["id"], "agent", "Tin đầu")
    chat = _office_chat(store, agent)
    assert chat.is_expanded is True
    chat.toggle_expand()  # thu TAY
    _pump()
    assert chat.is_expanded is False
    # Refresh thường (chưa có gì mới) không phá lựa chọn thu tay.
    chat.refresh()
    _pump()
    assert chat.is_expanded is False
    # Tin MỚI (id lớn hơn mốc lúc thu) → tự bung lại.
    store.add_message(agent["id"], "agent", "Tin mới đến")
    chat.refresh()
    _pump()
    assert chat.is_expanded is True
    chat.close()


def test_collapsed_refresh_uses_cheap_signature_only(qapp, store):
    """Khi THU GỌN: refresh không dựng lại bong bóng và không đánh
    dấu đã đọc — kế thừa kỷ luật vân của V5.2 ở trạng thái thu."""
    agent = _agent(store)
    store.add_message(agent["id"], "agent", "Tin đã đọc rồi")
    chat = _office_chat(store, agent)
    assert chat.is_expanded is True
    before = _thread_widgets(chat)
    assert before  # luồng đã dựng
    chat.toggle_expand()  # thu tay
    _pump()
    # Một tin chiều 'user' từ bề mặt khác (mục Tài khoản) chen vào:
    # dữ liệu luồng đổi nhưng khung đang thu — KHÔNG dựng lại.
    store.add_message(agent["id"], "user", "Tin gửi từ tab Tài khoản")
    chat.refresh()
    _pump()
    assert chat.is_expanded is False
    assert _thread_widgets(chat) == before
    chat.close()


def test_agent_switch_resets_to_default_state(qapp, store):
    first = _agent(store)
    second = _agent(store, "dabnire34", "dabnire34@gmail.com")
    chat = _office_chat(store, first)
    chat.expand_chat()  # mở TAY ở agent đầu
    _pump()
    assert chat.is_expanded is True
    # Đổi agent: lựa chọn tay của agent trước bị xoá — agent mới
    # không có gì chờ → về mặc định THU GỌN.
    chat.set_agent(store.get_agent(second["id"]))
    _pump()
    assert chat.is_expanded is False
    chat.close()


# ---------------------------------------------------------------------- #
# Bản Tài khoản KHÔNG đổi hành vi
# ---------------------------------------------------------------------- #
def test_accounts_variant_is_not_collapsible(qapp, store):
    agent = _agent(store)
    chat = AgentChatWidget(store)  # mặc định: như mục Tài khoản dùng
    chat.set_agent(store.get_agent(agent["id"]))
    chat.show()
    _pump()
    assert chat.is_expanded is True
    assert chat.expand_button is None
    assert chat.body_widget.isVisible() is True
    # Không chặn chiều cao luồng ở bản luôn mở.
    assert chat.scroll.maximumHeight() > OFFICE_THREAD_MAX_HEIGHT
    chat.close()


# ---------------------------------------------------------------------- #
# Tích hợp Văn phòng: luồng dài + việc đang chạy → panel vẫn đọc được
# ---------------------------------------------------------------------- #
def test_office_panel_work_visible_with_long_thread(qapp, tmp_path):
    store = Store(tmp_path / "v521_office.db")
    profile = store.add_profile("KenhHoatHinh", "23shinryujin@gmail.com")
    a1 = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.assign_profiles(a1["id"], [profile["id"]])
    store.touch_agent_heartbeat(a1["id"])
    cmd = store.create_command(
        "create_video", profile_id=profile["id"],
        instruction="Tạo video EP24", status="running",
        agent_id=a1["id"],
    )
    store.update_command_progress(cmd["id"], 60, "Đang dựng")
    # Luồng chat DÀI (15 tin) nhưng đã đọc hết → không có gì chờ.
    for index in range(15):
        store.add_message(a1["id"], "agent", f"Tin cũ số {index}")
    store.mark_read(a1["id"], "agent")

    view = OfficeView(store, settings={})
    view.resize(1500, 900)
    view.show()
    _pump(10)
    # Chat THU GỌN (chỉ còn thanh tiêu đề) và nội dung việc hiện đủ:
    # tiêu đề việc hiện tại + % tiến độ đã nạp trong panel.
    assert view.chat_widget.is_expanded is False
    assert view.chat_widget.height() < 90
    assert "Tạo video" in view.cur_title.text()
    assert view.cur_progress.text() == "60%"
    # Tin mới đến → tick của khung chat tự bung ngay trong panel.
    store.add_message(a1["id"], "agent", "Có tin mới cho anh")
    view.chat_widget._on_timer_tick()
    _pump()
    assert view.chat_widget.is_expanded is True
    view.close()
    store.close()
