"""V4.0 (H1) — Sweeper lease: thu hồi lệnh Muse mất dấu.

Lease hết hạn → lệnh về waiting_muse + attempts tăng; vượt
max_attempts → failed với lỗi nói rõ. Lệnh local không bị sweeper
đụng. Cảnh báo "chờ quá lâu mà Muse phụ trách offline" chỉ ghi
ĐÚNG MỘT LẦN mỗi lệnh.
"""

from datetime import datetime, timedelta

import pytest

from app.lease_sweeper import LeaseSweeper
from app.store import Store


@pytest.fixture()
def world(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh A", "a@gmail.com")
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    yield {"store": store, "profile": profile, "agent": agent}
    store.close()


def _expire_lease(store, command_id):
    store._conn.execute(
        "UPDATE commands SET lease_expires_at = '2000-01-01T00:00:00+07:00'"
        " WHERE id = ?",
        (command_id,),
    )
    store._conn.commit()


def _claimed(world):
    store = world["store"]
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=world["profile"]["id"],
        profile_slug=world["profile"]["slug"],
        status="waiting_muse",
    )
    claimed = store.claim_claude_command(cmd["id"], world["agent"]["id"], 120)
    assert claimed is not None
    return claimed


def test_expired_lease_requeues_and_counts_attempt(world):
    store = world["store"]
    cmd = _claimed(world)
    _expire_lease(store, cmd["id"])
    sweeper = LeaseSweeper(store, max_attempts=3)
    result = sweeper.sweep_once()
    assert result["requeued"] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "waiting_muse"
    assert row["attempts"] == 1
    assert row["lease_agent_id"] is None
    assert row["lease_expires_at"] is None


def test_expired_lease_over_max_attempts_fails_with_reason(world):
    store = world["store"]
    cmd = _claimed(world)
    store._conn.execute(
        "UPDATE commands SET attempts = 3 WHERE id = ?", (cmd["id"],)
    )
    store._conn.commit()
    _expire_lease(store, cmd["id"])
    sweeper = LeaseSweeper(store, max_attempts=3)
    result = sweeper.sweep_once()
    assert result["failed"] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "failed"
    assert "mất dấu 4 lần" in (row["error"] or "")


def test_local_command_never_touched_by_sweeper(world):
    store = world["store"]
    cmd = store.create_command(
        "scan",
        source="api",
        profile_id=world["profile"]["id"],
        profile_slug=world["profile"]["slug"],
        status="queued",
    )
    store.claim_command(cmd["id"])  # -> running (đường local)
    store._conn.execute(
        "UPDATE commands SET lease_expires_at = '2000-01-01T00:00:00+07:00'"
        " WHERE id = ?",
        (cmd["id"],),
    )
    store._conn.commit()
    result = LeaseSweeper(store).sweep_once()
    assert result["requeued"] == [] and result["failed"] == []
    assert store.get_command(cmd["id"])["status"] == "running"


def test_wait_alert_warned_exactly_once(world):
    store = world["store"]
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=world["profile"]["id"],
        profile_slug=world["profile"]["slug"],
        status="waiting_muse",
    )
    old = (datetime.now().astimezone() - timedelta(minutes=30)).isoformat(
        timespec="seconds"
    )
    store._conn.execute(
        "UPDATE commands SET created_at = ?, updated_at = ? WHERE id = ?",
        (old, old, cmd["id"]),
    )
    store._conn.commit()
    sweeper = LeaseSweeper(store, wait_alert_minutes=10)
    # Muse phụ trách chưa từng heartbeat -> offline.
    assert sweeper.sweep_once()["warned"] == [cmd["id"]]
    assert sweeper.sweep_once()["warned"] == []
    journal = store.list_journal(limit=100)
    hits = [j for j in journal if "đang offline" in j["message"] and cmd["id"] in j["message"]]
    assert len(hits) == 1
