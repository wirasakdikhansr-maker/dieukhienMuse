"""V4.1.1 — Hotfix "lệnh kẹt vì chưa phân công + Chạy ngay không tức
thì + chọn Muse nhận lệnh ngay ở tab Lệnh".

Sự cố thật 29/10 (ảnh người dùng): lệnh "Tạo video (Muse)" cho hồ sơ
dabnire34@gmail.com nằm 'queued' mãi với bước "Chưa có Muse phụ
trách hồ sơ này" — trong khi agent dabnire34@gmail.com ĐÃ tồn tại,
chỉ là 0 phân công. Ba lớp chữa được kiểm chứng ở đây:

1. ``Store.auto_assign_email_matches`` — email agent trùng gmail hồ
   sơ (chưa có chủ) thì tự phân công; dispatcher tick gọi trước khi
   xét lệnh nên lệnh được giao ngay nhịp đó (kịch bản lỗi đầu-cuối).
2. ``AgentServer.request_dispatch_now`` — nút Chạy ngay ép một nhịp
   dispatcher tức thì qua threading.Event (không chờ 15 giây), và
   CommandRunner.run_now xoá hẹn giờ cho lệnh Muse.
3. Chọn Muse nhận lệnh ngay ở tab Lệnh: ô chọn ở form tạo lệnh +
   nút "🎯 Đổi Muse…" cho lệnh đang chờ — đi qua
   ``Store.ensure_agent_assignment`` (chỉ định tường minh, không cần
   trùng email), dispatcher giữ nguyên luật sở hữu.
"""

import os
import time
from datetime import datetime, timedelta

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from app import config
from app.agent_server import AgentServer
from app.dispatcher import Dispatcher
from app.store import Store
from test_agent_server import FakeManager, stub_scan


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "t.sqlite3")
    yield s
    s.close()


# --------------------------------------------------------------------------- #
# 1) Tự phân công theo email
# --------------------------------------------------------------------------- #
def test_auto_assign_matches_case_insensitive_and_idempotent(store):
    profile = store.add_profile("Kenh Dabni", "  Dabnire34@Gmail.com ")
    agent = store.create_agent("Muse Dabni", "dabnire34@gmail.com")
    added = store.auto_assign_email_matches()
    assert added == [(agent["id"], profile["id"])]
    assert store.agent_for_profile(profile["id"])["id"] == agent["id"]
    # Gọi lại: không thêm gì (đã có phân công).
    assert store.auto_assign_email_matches() == []


def test_auto_assign_never_steals_or_coassigns(store):
    profile = store.add_profile("Kenh A", "shared@gmail.com")
    owner = store.create_agent("Muse Chủ", "owner@claude.ai")
    store.assign_profiles(owner["id"], [profile["id"]])
    # Agent khác trùng email hồ sơ nhưng hồ sơ ĐÃ có chủ → không gán.
    matcher = store.create_agent("Muse Trùng Mail", "shared@gmail.com")
    assert store.auto_assign_email_matches() == []
    assert store.agent_for_profile(profile["id"])["id"] == owner["id"]
    assert store.profiles_for_agent(matcher["id"]) == []


def test_auto_assign_skips_revoked_agent(store):
    profile = store.add_profile("Kenh A", "revoked@gmail.com")
    agent = store.create_agent("Muse Thu Hồi", "revoked@gmail.com")
    store.set_agent_revoked(agent["id"], True)
    assert store.auto_assign_email_matches() == []
    assert store.agent_for_profile(profile["id"]) is None


def test_auto_assign_name_fallback_when_email_empty(store):
    profile = store.add_profile("Kenh A", "legacy@gmail.com")
    agent = store.create_agent("Tam", "tam@claude.ai")
    # Giả lập agent đời cũ: email trống, name chính là email.
    store._conn.execute(
        "UPDATE agents SET email = '', name = 'legacy@gmail.com' WHERE id = ?",
        (agent["id"],),
    )
    store._conn.commit()
    assert store.auto_assign_email_matches() == [(agent["id"], profile["id"])]


def test_auto_assign_writes_journal_line(store):
    profile = store.add_profile("Kenh A", "journal@gmail.com")
    store.create_agent("Muse Nhật Ký", "journal@gmail.com")
    store.auto_assign_email_matches()
    lines = [j["message"] for j in store.list_journal(profile_id=profile["id"])]
    assert any(
        "Tự phân công" in line and "trùng email" in line for line in lines
    )


def test_ensure_assignment_adds_once_then_transfers_on_explicit_choice(store):
    profile = store.add_profile("Kenh A", "profile@gmail.com")
    agent_a = store.create_agent("Muse A", "a@claude.ai")
    agent_b = store.create_agent("Muse B", "b@claude.ai")
    assert store.ensure_agent_assignment(agent_a["id"], profile["id"]) is True
    assert store.ensure_agent_assignment(agent_a["id"], profile["id"]) is False
    # Người dùng chỉ định lại tường minh → chuyển chủ (assign_profiles).
    assert store.ensure_agent_assignment(agent_b["id"], profile["id"]) is True
    assert store.agent_for_profile(profile["id"])["id"] == agent_b["id"]
    assert store.profiles_for_agent(agent_a["id"]) == []


# --------------------------------------------------------------------------- #
# Kịch bản lỗi thật, đầu-cuối qua dispatcher
# --------------------------------------------------------------------------- #
def test_dispatcher_promotes_after_auto_assign_email_match(store):
    """Đúng ca dabnire34: agent tồn tại, email trùng gmail hồ sơ,
    KHÔNG ai phân công tay — một nhịp dispatcher phải tự phân công
    rồi đẩy lệnh lên 'waiting_muse'."""
    profile = store.add_profile("dabnire34@gmail.com", "dabnire34@gmail.com")
    agent = store.create_agent("Muse #2", "dabnire34@gmail.com")
    cmd = store.create_command(
        "create_video",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        instruction="Phân tích ngách video, tạo video mới theo video đang lên",
        status="queued",
    )
    assert store.agent_for_profile(profile["id"]) is None
    promoted = Dispatcher(store).tick()
    assert [c["id"] for c in promoted] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "waiting_muse"
    assert store.agent_for_profile(profile["id"])["id"] == agent["id"]


def test_dispatcher_delivers_to_explicitly_chosen_agent(store):
    """Chọn Muse ở tab Lệnh (addendum): email KHÔNG trùng, không
    phân công trước — ensure + tạo lệnh ghi danh agent → dispatcher
    đẩy lên và lệnh thuộc đúng Muse đã chọn (luật sở hữu không đổi)."""
    profile = store.add_profile("Kenh A", "kenh.a@gmail.com")
    chosen = store.create_agent("Muse Được Chọn", "khac.han@claude.ai")
    cmd = store.create_command(
        "optimize",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        agent_id=chosen["id"],
    )
    assert store.ensure_agent_assignment(chosen["id"], profile["id"]) is True
    promoted = Dispatcher(store).tick()
    assert [c["id"] for c in promoted] == [cmd["id"]]
    row = store.get_command(cmd["id"])
    assert row["status"] == "waiting_muse"
    assert row["agent_id"] == chosen["id"]
    assert store.agent_for_profile(profile["id"])["id"] == chosen["id"]


# --------------------------------------------------------------------------- #
# 2) request_dispatch_now — ép nhịp dispatcher tức thì
# --------------------------------------------------------------------------- #
def _server_with_counter(tmp_path):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    # Seed DB trước (như test_v40_longpoll): migration chạy xong một
    # luồng, tránh worker của server và start() mở Store đua nhau
    # migrate trên DB trắng (duplicate column).
    seed = Store(config.db_path(data_dir))
    seed.close()
    calls = []
    server = AgentServer(
        data_dir=data_dir,
        settings={"agent_port": 0},
        manager=FakeManager(),
        scan_fn=stub_scan,
        auto_tick_fn=lambda _srv: calls.append(1),
    )
    return server, calls


def test_request_dispatch_now_bypasses_interval(tmp_path):
    server, calls = _server_with_counter(tmp_path)
    server._maybe_auto_tick()
    assert len(calls) == 1
    # Chưa đủ 15 giây → nhịp thường bị cổng chặn.
    server._maybe_auto_tick()
    assert len(calls) == 1
    # Ép ngay: event set → nhịp kế chạy bất chấp khoảng thời gian,
    # và event được tiêu thụ (không ép mãi các nhịp sau).
    server.request_dispatch_now()
    assert server._dispatch_event.is_set()
    server._maybe_auto_tick()
    assert len(calls) == 2
    assert not server._dispatch_event.is_set()
    server._maybe_auto_tick()
    assert len(calls) == 2


def test_worker_thread_wakes_promptly_on_request_dispatch_now(tmp_path):
    server, calls = _server_with_counter(tmp_path)
    server.start()
    try:
        deadline = time.monotonic() + 2.0
        while not calls and time.monotonic() < deadline:
            time.sleep(0.02)
        assert calls, "nhịp dispatcher đầu tiên không chạy sau start()"
        baseline = len(calls)
        # Giả lập "vừa mới tick" — nhịp thường sẽ bị chặn 15 giây…
        server._last_auto_tick = time.monotonic()
        server.request_dispatch_now()
        deadline = time.monotonic() + 2.0
        while len(calls) == baseline and time.monotonic() < deadline:
            time.sleep(0.02)
        # …nhưng worker phải thức và tick ngay (không chờ 15 giây).
        assert len(calls) == baseline + 1
    finally:
        server.stop()


# --------------------------------------------------------------------------- #
# Qt: CommandRunner.run_now + panel chọn Muse
# --------------------------------------------------------------------------- #
pytest.importorskip("PySide6")


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_run_now_claude_clears_schedule_and_forces_dispatch(qapp, tmp_path):
    from app.chrome_manager import ChromeManager
    from app.ui.command_runner import CommandRunner

    db_path = tmp_path / "t.sqlite3"
    store = Store(db_path)
    profile = store.add_profile("Kenh A", "a@gmail.com")
    future = (datetime.now().astimezone() + timedelta(hours=2)).isoformat(
        timespec="seconds"
    )
    cmd = store.create_command(
        "create_video",
        source="ui",
        profile_id=profile["id"],
        profile_slug=profile["slug"],
        status="queued",
        scheduled_at=future,
    )
    store.close()
    forced = []
    runner = CommandRunner(
        db_path, ChromeManager(), dispatch_now=lambda: forced.append(1)
    )
    try:
        runner.run_now(cmd["id"])
    finally:
        runner.stop()
    assert forced == [1]  # đã ép dispatcher xét ngay đúng một lần
    check = Store(db_path)
    try:
        row = check.get_command(cmd["id"])
        assert row["scheduled_at"] is None  # hẹn giờ bị xoá
        assert row["status"] == "queued"  # runner không tự thi hành lệnh Muse
    finally:
        check.close()


@pytest.fixture()
def panel_world(tmp_path, qapp):
    from app.ui.commands_panel import CommandsPanel

    store = Store(tmp_path / "t.sqlite3")
    notes: list[str] = []
    forced: list[int] = []
    panel = CommandsPanel(
        store,
        notify=notes.append,
        dispatch_now=lambda: forced.append(1),
    )
    profile = store.add_profile("Kenh A", "kenh.a@gmail.com")
    agent_a = store.create_agent("Muse A", "a@claude.ai")
    agent_b = store.create_agent("Muse B", "b@claude.ai")
    panel.refresh()
    yield {
        "store": store,
        "panel": panel,
        "notes": notes,
        "forced": forced,
        "profile": profile,
        "agent_a": agent_a,
        "agent_b": agent_b,
    }
    panel.close()
    store.close()


def test_picker_lists_auto_plus_agents(panel_world):
    panel = panel_world["panel"]
    combo = panel.agent_combo
    assert combo.count() == 3  # Tự động + 2 agent
    assert combo.itemData(0) is None
    assert "Tự động" in combo.itemText(0)
    ids = [combo.itemData(i) for i in range(combo.count())]
    assert panel_world["agent_a"]["id"] in ids
    assert panel_world["agent_b"]["id"] in ids


def test_create_with_chosen_agent_assigns_and_reports(panel_world, monkeypatch):
    panel = panel_world["panel"]
    store = panel_world["store"]
    chosen = panel_world["agent_b"]
    # V4.1.3: đường tạo lệnh không còn _bridge_guard để phải vá nữa.
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("create_video"))
    panel.agent_combo.setCurrentIndex(
        panel.agent_combo.findData(chosen["id"])
    )
    panel.instruction_edit.setPlainText("Tạo video theo ngách đang lên")
    panel._on_create()
    commands = store.list_commands(limit=10)
    assert len(commands) == 1
    assert commands[0]["agent_id"] == chosen["id"]
    assert commands[0]["status"] == "queued"
    # Phân công được đảm bảo ngay khi tạo — dispatcher sẽ giao đúng người.
    assert store.agent_for_profile(panel_world["profile"]["id"])["id"] == chosen["id"]
    assert any("Đã phân công hồ sơ" in n for n in panel_world["notes"])


def test_create_with_auto_keeps_old_behavior(panel_world, monkeypatch):
    panel = panel_world["panel"]
    store = panel_world["store"]
    # V4.1.3: đường tạo lệnh không còn _bridge_guard để phải vá nữa.
    # 'free' (lệnh tự do của Muse) không đòi kênh như 'optimize'.
    panel.type_combo.setCurrentIndex(panel.type_combo.findData("free"))
    panel.instruction_edit.setPlainText("Việc tự do cho Muse")
    panel._on_create()  # ô Muse vẫn ở 'Tự động'
    commands = store.list_commands(limit=10)
    assert len(commands) == 1
    assert commands[0]["agent_id"] is None  # chưa có chủ → store không gắn
    assert store.agent_for_profile(panel_world["profile"]["id"]) is None


def test_reassign_agent_for_waiting_commands(panel_world):
    panel = panel_world["panel"]
    store = panel_world["store"]
    profile = panel_world["profile"]
    agent_a = panel_world["agent_a"]
    agent_b = panel_world["agent_b"]
    queued = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="queued",
        agent_id=agent_a["id"],
    )
    waiting = store.create_command(
        "create_video", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], status="waiting_muse",
        agent_id=agent_a["id"],
    )
    panel._apply_reassign_agent(queued["id"], agent_b["id"])
    assert store.get_command(queued["id"])["agent_id"] == agent_b["id"]
    assert store.agent_for_profile(profile["id"])["id"] == agent_b["id"]
    panel._apply_reassign_agent(waiting["id"], agent_b["id"])
    assert store.get_command(waiting["id"])["agent_id"] == agent_b["id"]
    # Cả hai lần đổi đều ép dispatcher xét ngay.
    assert len(panel_world["forced"]) == 2
    assert any("Đã đổi Muse nhận lệnh" in n for n in panel_world["notes"])


def test_agent_picker_dialog_preselects_current(qapp):
    from app.ui.dialogs import AgentPickerDialog

    agents = [
        {"id": 1, "name": "Muse A", "email": "a@claude.ai"},
        {"id": 2, "name": "Muse B", "email": "b@claude.ai"},
    ]
    dialog = AgentPickerDialog(agents, current_agent_id=2)
    try:
        assert dialog.selected_agent_id() == 2
        dialog.agent_combo.setCurrentIndex(0)
        assert dialog.selected_agent_id() == 1
    finally:
        dialog.close()


# --------------------------------------------------------------------------- #
# 4) Phiếu kết nối RIÊNG theo tài khoản + tự cấp lại (yêu cầu 29/10 12:33)
# --------------------------------------------------------------------------- #
import re

from app import tickets


def _parse_combined_like_hook(text: str) -> dict[int, str]:
    """Parse file gộp đúng cách parser phía Muse làm: tách khối
    theo '^## ', id từ '(#<n>)', token từ 'X-Agent-Token:'."""
    found = {}
    for block in re.split(r"^## ", text, flags=re.M)[1:]:
        mid = re.search(r"\(#(\d+)\)", block)
        mtok = re.search(r"X-Agent-Token:\s*(\S+)", block)
        if mid and mtok:
            found[int(mid.group(1))] = mtok.group(1)
    return found


@pytest.fixture()
def ticket_world(tmp_path, qapp):
    from app.ui.agents_panel import AgentsPanel

    store = Store(tmp_path / "t.sqlite3")
    folder = tmp_path / "phieu"
    settings = {tickets.SETTINGS_KEY: str(folder)}
    notes: list[str] = []
    panel = AgentsPanel(store, notify=notes.append, settings=settings)
    yield {
        "store": store, "panel": panel, "folder": folder,
        "settings": settings, "notes": notes,
    }
    panel.close()
    store.close()


def test_ticket_slug_and_filename_from_email():
    agent = {"name": "Muse #2", "email": "Dabnire34@Gmail.com"}
    assert tickets.agent_ticket_filename(agent) == (
        "phieu-ket-noi-dabnire34-gmail-com.txt"
    )
    # Không email → slug từ tên (bỏ dấu tiếng Việt qua config.slugify).
    named = {"name": "Kênh Nhạc Hay", "email": ""}
    assert tickets.agent_ticket_filename(named) == (
        "phieu-ket-noi-kenh-nhac-hay.txt"
    )


def test_create_writes_per_account_ticket_with_only_own_token(ticket_world):
    store, panel, folder = (
        ticket_world["store"], ticket_world["panel"], ticket_world["folder"],
    )
    # Đúng trình tự _on_add làm: tạo agent rồi _sync_tickets(agent).
    first = store.create_agent("Muse Một", "mot@claude.ai")
    assert panel._sync_tickets(first["id"]) == folder
    second = store.create_agent("Muse Hai", "hai@claude.ai")
    assert panel._sync_tickets(second["id"]) == folder

    first_file = folder / tickets.agent_ticket_filename(first)
    second_file = folder / tickets.agent_ticket_filename(second)
    assert first_file.exists() and second_file.exists()
    first_text = first_file.read_text(encoding="utf-8")
    second_text = second_file.read_text(encoding="utf-8")
    assert first["token"] in first_text and second["token"] not in first_text
    assert second["token"] in second_text and first["token"] not in second_text
    # Tiêu đề file riêng nêu rõ tài khoản.
    assert "Muse Một" in first_text and "mot@claude.ai" in first_text
    # File gộp: parse kiểu hook phải ra đủ cả hai.
    combined = (folder / tickets.COMBINED_FILENAME).read_text(encoding="utf-8")
    assert _parse_combined_like_hook(combined) == {
        first["id"]: first["token"],
        second["id"]: second["token"],
    }
    # Dòng trạng thái thư mục phiếu hiện đúng thư mục đang dùng.
    assert str(folder) in panel.ticket_dir_label.text()


def test_regenerate_rewrites_only_that_accounts_ticket(ticket_world):
    store, panel, folder = (
        ticket_world["store"], ticket_world["panel"], ticket_world["folder"],
    )
    first = store.create_agent("Muse Một", "mot@claude.ai")
    second = store.create_agent("Muse Hai", "hai@claude.ai")
    panel._sync_tickets()
    first_file = folder / tickets.agent_ticket_filename(first)
    second_file = folder / tickets.agent_ticket_filename(second)
    second_bytes_before = second_file.read_bytes()
    old_token = first["token"]

    # Đúng trình tự _on_regenerate_token làm sau khi người dùng xác nhận.
    updated = store.regenerate_agent_token(first["id"])
    assert updated["token"] != old_token
    assert panel._sync_tickets(updated["id"]) == folder

    first_text = first_file.read_text(encoding="utf-8")
    assert updated["token"] in first_text
    assert old_token not in first_text
    # File của tài khoản KHÁC: không đổi một byte.
    assert second_file.read_bytes() == second_bytes_before
    # File gộp cập nhật token mới, vẫn parse được theo định dạng cũ.
    combined = (folder / tickets.COMBINED_FILENAME).read_text(encoding="utf-8")
    assert _parse_combined_like_hook(combined) == {
        first["id"]: updated["token"],
        second["id"]: second["token"],
    }


def test_delete_removes_ticket_file_and_refreshes_combined(ticket_world):
    store, panel, folder = (
        ticket_world["store"], ticket_world["panel"], ticket_world["folder"],
    )
    first = store.create_agent("Muse Một", "mot@claude.ai")
    second = store.create_agent("Muse Hai", "hai@claude.ai")
    panel._sync_tickets()
    first_file = folder / tickets.agent_ticket_filename(first)
    assert first_file.exists()
    store.delete_agent(first["id"])
    # _on_delete truyền dict chụp TRƯỚC khi xoá vào _sync_tickets.
    assert panel._sync_tickets(deleted_agent=first) == folder
    assert not first_file.exists()
    combined = (folder / tickets.COMBINED_FILENAME).read_text(encoding="utf-8")
    assert _parse_combined_like_hook(combined) == {
        second["id"]: second["token"]
    }


def test_ticket_write_failure_never_raises(tmp_path, qapp):
    from app.ui.agents_panel import AgentsPanel

    store = Store(tmp_path / "t.sqlite3")
    blocker = tmp_path / "blocked"
    blocker.write_text("đây là FILE, không phải thư mục", encoding="utf-8")
    settings = {tickets.SETTINGS_KEY: str(blocker / "phieu")}
    notes: list[str] = []
    panel = AgentsPanel(store, notify=notes.append, settings=settings)
    try:
        agent = store.create_agent("Muse Lỗi Ghi", "loi@claude.ai")
        # Ghi vào thư mục không tạo được: nuốt lỗi, báo trạng thái,
        # TUYỆT ĐỐI không ném ra ngoài (không làm hỏng thao tác chính).
        assert panel._sync_tickets(agent["id"]) is None
        assert panel._ticket_error
        assert any("Không ghi được phiếu" in n for n in notes)
        assert "thất bại" in panel.ticket_dir_label.text()
        # Cấp lại token vẫn chạy được dù ghi phiếu hỏng.
        updated = store.regenerate_agent_token(agent["id"])
        assert panel._sync_tickets(updated["id"]) is None
    finally:
        panel.close()
        store.close()
