"""Kiểm thử thư viện skill (V4.3): lưu/đọc/xoá file ``<slug>.md``
trong ``<base>/skills/``, parse khoan dung, render biến mẫu và
chống path traversal. Dùng ``tmp_path`` làm base — không chạm
thư mục data thật của app."""

import pytest

from app import skills_lib
from app.skills_lib import render_body, skills_dir


# --------------------------------------------------------------------------- #
# 1. save → list / load khớp
# --------------------------------------------------------------------------- #
def test_save_list_load_roundtrip(tmp_path):
    saved = skills_lib.save_skill("Viết Hook", "Mở đầu thật gắt cho {channel}", base=tmp_path)

    assert saved.slug == "viet-hook"
    assert saved.name == "Viết Hook"
    assert saved.body == "Mở đầu thật gắt cho {channel}"
    assert saved.path == skills_dir(tmp_path) / "viet-hook.md"
    assert saved.path.is_file()
    # File chuẩn hoá: dòng đầu là tiêu đề, kết thúc bằng newline.
    text = saved.path.read_text(encoding="utf-8")
    assert text.startswith("# Viết Hook\n")
    assert text.endswith("\n")
    assert not text.endswith("\n\n")

    listed = skills_lib.list_skills(base=tmp_path)
    assert len(listed) == 1
    assert listed[0].name == "Viết Hook"
    assert listed[0].body == "Mở đầu thật gắt cho {channel}"

    loaded = skills_lib.load_skill("viet-hook", base=tmp_path)
    assert loaded == saved


def test_list_missing_dir_and_load_missing(tmp_path):
    assert skills_lib.list_skills(base=tmp_path) == []
    assert skills_lib.load_skill("chua-co", base=tmp_path) is None
    assert skills_dir(tmp_path) == tmp_path / "skills"


# --------------------------------------------------------------------------- #
# 2. save trùng tên → vẫn 1 skill, nội dung mới nhất
# --------------------------------------------------------------------------- #
def test_save_same_name_overwrites(tmp_path):
    skills_lib.save_skill("Mẫu Trùng", "bản cũ", base=tmp_path)
    latest = skills_lib.save_skill("Mẫu Trùng", "bản mới nhất", base=tmp_path)

    listed = skills_lib.list_skills(base=tmp_path)
    assert len(listed) == 1
    assert listed[0].body == "bản mới nhất"
    assert skills_lib.load_skill(latest.slug, base=tmp_path).body == "bản mới nhất"


# --------------------------------------------------------------------------- #
# 3. delete
# --------------------------------------------------------------------------- #
def test_delete_existing_and_missing(tmp_path):
    skills_lib.save_skill("Skill Xoá", "nội dung", base=tmp_path)

    assert skills_lib.delete_skill("skill-xoa", base=tmp_path) is True
    assert skills_lib.list_skills(base=tmp_path) == []

    assert skills_lib.delete_skill("skill-xoa", base=tmp_path) is False
    assert skills_lib.delete_skill("khong-ton-tai", base=tmp_path) is False


# --------------------------------------------------------------------------- #
# 4. render_body
# --------------------------------------------------------------------------- #
def test_render_body_replaces_all_three_vars():
    body = "Hồ sơ {profile} / kênh {channel} / chủ đề {topic}"
    assert (
        render_body(body, profile="P1", channel="Kênh A", topic="Bóng đá")
        == "Hồ sơ P1 / kênh Kênh A / chủ đề Bóng đá"
    )


def test_render_body_unknown_var_kept_and_defaults_empty():
    assert render_body("{profile} {xyz} {topic}") == " {xyz} "
    assert render_body("{channel}-{la} {unknown}", channel="K") == "K-{la} {unknown}"
    assert render_body("không có biến") == "không có biến"


# --------------------------------------------------------------------------- #
# 5. Tên độc hại / toàn ký tự lạ
# --------------------------------------------------------------------------- #
def test_malicious_names_stay_inside_skills_dir(tmp_path):
    saved = skills_lib.save_skill("../../evil", "thân", base=tmp_path)
    assert saved.path.parent == skills_dir(tmp_path)
    assert saved.path.is_file()
    assert saved.path.resolve().is_relative_to(skills_dir(tmp_path).resolve())
    # Không tạo file ở vị trí traversal trỏ tới (ngoài thư mục skills).
    assert not (tmp_path / "evil.md").exists()
    assert not (tmp_path.parent / "evil.md").exists()

    saved2 = skills_lib.save_skill("a/b", "thân hai", base=tmp_path)
    assert saved2.slug == "a-b"
    assert saved2.path.parent == skills_dir(tmp_path)
    assert not (tmp_path / "skills" / "a").exists()


def test_all_strange_name_raises_value_error(tmp_path):
    for bad_name in ("…", "!!!", "   ", "///", "..."):
        with pytest.raises(ValueError):
            skills_lib.save_skill(bad_name, "thân", base=tmp_path)
    assert skills_lib.list_skills(base=tmp_path) == []


def test_delete_traversal_cannot_escape_skills_dir(tmp_path):
    outside = tmp_path / "outside.md"
    outside.write_text("file ngoài — không được xoá", encoding="utf-8")

    # "../outside" chuẩn hoá thành slug "outside" → chỉ nhắm
    # skills/outside.md (không tồn tại), không chạm file ngoài.
    assert skills_lib.delete_skill("../outside", base=tmp_path) is False
    assert outside.is_file()
    assert skills_lib.load_skill("../../outside", base=tmp_path) is None


# --------------------------------------------------------------------------- #
# 6. File viết tay: có / không có dòng tiêu đề
# --------------------------------------------------------------------------- #
def test_handwritten_file_without_title_line(tmp_path):
    directory = skills_dir(tmp_path)
    directory.mkdir(parents=True)
    content = "Toàn văn không tiêu đề\nDòng hai của thân"
    (directory / "file-tay.md").write_text(content, encoding="utf-8")

    skill = skills_lib.load_skill("file-tay", base=tmp_path)
    assert skill is not None
    assert skill.name == "file-tay"
    assert skill.body == content


def test_handwritten_file_with_title_line(tmp_path):
    directory = skills_dir(tmp_path)
    directory.mkdir(parents=True)
    (directory / "co-ten.md").write_text(
        "# Tên Tay Viết\nThân một\nThân hai\n", encoding="utf-8"
    )

    skill = skills_lib.load_skill("co-ten", base=tmp_path)
    assert skill is not None
    assert skill.name == "Tên Tay Viết"
    assert skill.body == "Thân một\nThân hai"
    assert "Tên Tay Viết" not in skill.body


# --------------------------------------------------------------------------- #
# 7. list sắp theo tên (casefold)
# --------------------------------------------------------------------------- #
def test_list_sorted_by_name_casefold(tmp_path):
    skills_lib.save_skill("Charlie", "c", base=tmp_path)
    skills_lib.save_skill("alpha", "a", base=tmp_path)
    skills_lib.save_skill("Bravo", "b", base=tmp_path)

    names = [s.name for s in skills_lib.list_skills(base=tmp_path)]
    assert names == ["alpha", "Bravo", "Charlie"]
