"""V6.6 — Văn phòng 3D mới: giao/nhận việc hai chiều, giờ làm việc, hiệu ứng."""

from __future__ import annotations

import os
from datetime import datetime, timedelta

import pytest

from app import lead_autopilot, muse_chat_bridge, office_feed
from app.store import Store


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


@pytest.fixture(scope="module")
def qapp():
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def _at(hour, minute=0):
    return datetime.now().astimezone().replace(hour=hour, minute=minute, second=0, microsecond=0)


def test_work_mode_hours_forced_and_overnight():
    assert office_feed.work_mode({}, _at(9)) == "work"
    assert office_feed.work_mode({}, _at(23)) == "off"
    assert office_feed.work_mode({"office_mode": "off"}, _at(9)) == "off"
    assert office_feed.work_mode({"office_mode": "work"}, _at(3)) == "work"
    night_shift = {"office_work_hours": "20:00-06:00"}
    assert office_feed.work_mode(night_shift, _at(2)) == "work"
    assert office_feed.work_mode(night_shift, _at(12)) == "off"
    assert office_feed.next_work_start({}, _at(23)).hour == 8
    assert office_feed.is_urgent({"source": "ui"}) and not office_feed.is_urgent({"source": "auto"})
    assert office_feed.is_urgent({"source": "auto", "payload": {"urgent": True}})


def test_protocol_ack_done_error():
    text = muse_chat_bridge.task_text({"id": "abc123", "type": "upload", "instruction": "Đăng tập 13", "payload": {}},
                                      "Kids 3D", "", "Muse 02")
    assert text.startswith("[Trưởng phòng] Muse 02 ơi, giao việc #abc123")
    assert "ĐÃ NHẬN việc #abc123" in text
    assert muse_chat_bridge.classify_reply("ĐÃ NHẬN việc #abc123 — mở Studio") == "ack"
    assert muse_chat_bridge.classify_reply("KẾT QUẢ #abc123: đã đăng") == "done"
    assert muse_chat_bridge.classify_reply("LỖI: Studio đăng xuất") == "needs_user"
    assert muse_chat_bridge.classify_reply("Mình xem kết quả tìm kiếm: x") == "running"


def _scene(store):
    lead = store.create_agent("Muse 01", "a@x.com")
    worker = store.create_agent("Muse 02", "b@x.com")
    idle = store.create_agent("Muse 03", "c@x.com")
    settings = {"supervision_mode": "lead", "supervision_lead_agent_id": lead["id"], "office_mode": "work"}
    cmd = store.create_command("upload", instruction="Đăng tập 13", agent_id=worker["id"])
    store.update_command(cmd["id"], status="waiting_muse")
    store.update_command_payload_flags(cmd["id"], {"chat_sent": True})
    store.add_message(worker["id"], "user", f"[Trưởng phòng] Muse 02 ơi, giao việc #{cmd['id']}: Đăng tập 13\n"
                                            "Nhận được việc chưa? Trả lời NGAY", command_id=cmd["id"])
    store.add_message(worker["id"], "system", "✓ Đã chuyển tới Muse 02 · đang đọc…", command_id=cmd["id"])
    return lead, worker, idle, settings, cmd


def test_build_states_events_and_feed(store):
    lead, worker, idle, settings, cmd = _scene(store)
    data = office_feed.build(store, settings)
    assert data["lead"]["agent_id"] == lead["id"] and data["lead"]["bubble"]["tone"] == "lead"
    desks = {d["agent_id"]: d for d in data["desks"]}
    assert desks[worker["id"]]["state"] == "receive"
    assert desks[idle["id"]]["state"] == "idle"
    assert [e["kind"] for e in data["events"]] == ["assign"]
    kinds = [e["kind"] for e in data["feed"]]
    assert kinds == ["lead", "sys"]
    assert "#" + cmd["id"][:6] in data["feed"][0]["text"] and cmd["id"] not in data["feed"][0]["text"]
    # Muse trả lời THẬT "ĐÃ NHẬN" → sự kiện ack, bong bóng là tin thật
    store.add_message(worker["id"], "agent", f"ĐÃ NHẬN việc #{cmd['id']} — mở Studio", command_id=cmd["id"])
    data = office_feed.build(store, settings)
    desk = next(d for d in data["desks"] if d["agent_id"] == worker["id"])
    assert desk["bubble"]["real"] and desk["bubble"]["tone"] == "receive"
    assert "ack" in [e["kind"] for e in data["events"]]
    assert data["feed"][-1]["kind"] == "agent" and data["feed"][-1]["verdict"] == "ack"
    # Ngoài giờ: rảnh → ngủ; việc tự động chưa gửi → xếp hàng chờ giờ
    auto = store.create_command("optimize", source="auto", instruction="Tối ưu", agent_id=idle["id"])
    store.update_command(auto["id"], status="waiting_muse")
    off = dict(settings, office_mode="off")
    data = office_feed.build(store, off)
    states = {d["agent_id"]: d["state"] for d in data["desks"]}
    assert states[idle["id"]] == "queued" and data["mode"] == "off"


def test_ack_watch_pings_then_reassigns(store, monkeypatch):
    sent = []
    monkeypatch.setattr(lead_autopilot, "SENDER", lambda a, body, cid: sent.append((a["id"], body)))
    a = store.create_agent("A", "a@x.com")
    b = store.create_agent("B", "b@x.com")
    for agent in (a, b):
        store.touch_agent_heartbeat(agent["id"])
    cmd = store.create_command("free", instruction="x", agent_id=a["id"])
    store.update_command(cmd["id"], status="waiting_muse")
    sent_at = datetime.now().astimezone() - timedelta(minutes=5)
    store.update_command_payload_flags(cmd["id"], {"chat_sent": True, "chat_sent_at": sent_at.isoformat(timespec="seconds")})
    now = datetime.now().astimezone()
    out = lead_autopilot.ack_watch(store, {}, None, now)
    assert out[0]["action"] == "ack_ping" and "đã nhận được việc" in sent[-1][1]
    assert lead_autopilot.ack_watch(store, {}, None, now + timedelta(minutes=1)) == []  # chờ giữa 2 lần hỏi
    out = lead_autopilot.ack_watch(store, {}, None, now + timedelta(minutes=4))
    assert out[0]["action"] == "ack_ping"
    out = lead_autopilot.ack_watch(store, {}, None, now + timedelta(minutes=8))
    assert out[0]["action"] == "reassign" and store.get_command(cmd["id"])["agent_id"] == b["id"]
    # đã xác nhận → không hỏi nữa
    store.update_command_payload_flags(cmd["id"], {"acked": True, "chat_sent": True})
    assert lead_autopilot.ack_watch(store, {}, None, now + timedelta(minutes=30)) == []


def test_window_ack_done_and_off_hours_dispatch(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    agent = st.create_agent("Muse 02", "b@x.com")
    win = MainWindow(st, ChromeManager(), settings)
    sent = []

    class Bridge:
        def send(self, a, text, command_id=None):
            sent.append(command_id)

        def pending(self, agent_id):
            return 0

    win._chat_bridge = Bridge()
    try:
        cmd = st.create_command("free", instruction="Viết mô tả", agent_id=agent["id"])
        st.update_command(cmd["id"], status="waiting_muse")
        win._apply_bridge_reply(cmd["id"], f"ĐÃ NHẬN việc #{cmd['id']} — bắt đầu")
        assert st.get_command(cmd["id"])["payload"]["acked"] is True
        assert "ĐÃ NHẬN" in st.list_command_steps(cmd["id"])[-1]["step"]
        win._apply_bridge_reply(cmd["id"], f"KẾT QUẢ #{cmd['id']}: xong")
        assert st.get_command(cmd["id"])["status"] == "done"
        last = st.list_messages(agent["id"])[-1]
        assert last["direction"] == "system" and last["body"].startswith("[Trưởng phòng] Đã nhận báo cáo")
        # ngoài giờ: việc tự động chờ, việc bạn tự giao vẫn đi
        settings["office_mode"] = "off"
        auto = st.create_command("optimize", source="auto", instruction="Tối ưu", agent_id=agent["id"])
        st.update_command(auto["id"], status="waiting_muse")
        mine = st.create_command("free", source="ui", instruction="Khẩn", agent_id=agent["id"])
        st.update_command(mine["id"], status="waiting_muse")
        win._bridge_dispatch_tick()
        assert mine["id"] in sent and auto["id"] not in sent
        settings["office_mode"] = "work"
        win._bridge_dispatch_tick()
        assert auto["id"] in sent
    finally:
        win.close()


def test_iso_view_renders_clicks_and_flies(qapp, store, tmp_path, monkeypatch):
    from PySide6.QtCore import QPointF

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))

    from app.ui.office_iso import OfficeIsoView

    lead, worker, idle, settings, cmd = _scene(store)
    view = OfficeIsoView(store, settings)
    view.resize(1400, 820)
    view.show()
    view.refresh(force=True)
    assert view.stage.flights == []  # lần nạp đầu không bay lại sự kiện cũ
    store.add_message(worker["id"], "agent", f"KẾT QUẢ #{cmd['id']}: đã đăng", command_id=cmd["id"])
    view.refresh(force=True)
    assert [f["label"] for f in view.stage.flights] == [f"📄 Báo cáo #{cmd['id'][:6]}"]
    image = view.grab()
    assert not image.isNull()
    picked = []
    view.agent_clicked.connect(picked.append)
    rect, key = next((r, k) for r, k in view.stage._hits if k == worker["id"])
    from PySide6.QtCore import QEvent, Qt
    from PySide6.QtGui import QMouseEvent

    pos = QPointF(rect.center())
    view.stage.mousePressEvent(QMouseEvent(QEvent.Type.MouseButtonPress, pos, pos, Qt.MouseButton.LeftButton,
                                           Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier))
    assert picked == [worker["id"]]
    assert len(view.feed._ids) == 3
    view.set_office_mode("off")
    assert view.stage.data["mode"] == "off"
    view.close()
