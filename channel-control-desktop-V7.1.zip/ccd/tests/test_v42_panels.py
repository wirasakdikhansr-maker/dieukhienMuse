"""V4.2 — Panel Lệnh: timer chỉ chạy khi mục đang hiện (O-10),
bảng/combo bỏ dựng lại khi dữ liệu không đổi (O-10), thứ tự form
theo luồng ra lệnh + bật/tắt ô theo loại lệnh (O-26), kết quả tạo
lệnh hiện tại form + chọn dòng mới (G2).
"""

import pytest
from PySide6.QtWidgets import QApplication

from app import config
from app.store import Store
from app.ui.commands_panel import CommandsPanel


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def world(tmp_path):
    store = Store(config.db_path(tmp_path / "data.db"))
    profile = store.add_profile("Kenh A", "a@gmail.com")
    channel = {
        "channel_id": "UC_TEST_1", "name": "Kenh A", "handle": "@kenha",
        "url": "https://www.youtube.com/channel/UC_TEST_1",
        "subs": 1, "video_count": 1, "niche": "",
    }
    store.upsert_channel(profile["id"], channel)
    agent = store.create_agent("Muse A", "a@claude.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    yield {"store": store, "profile": profile, "agent": agent}
    store.close()


def _combo_order(panel):
    """Thứ tự các combo trong form tạo lệnh (đi dọc layout của
    form_card, đệ quy vào các hàng con)."""
    order = []

    def walk(layout):
        for i in range(layout.count()):
            item = layout.itemAt(i)
            widget = item.widget()
            if widget is not None and hasattr(widget, "currentData"):
                order.append(widget)
            elif item.layout() is not None:
                walk(item.layout())

    walk(panel.form_card.layout())
    return order


def test_form_field_order_matches_workflow(world):
    # V4.5 (pin mới): form MỘT CỘT DỌC — Skill → Muse nhận lệnh →
    # Loại lệnh → Hồ sơ đích; kênh là danh sách CHECKBOX phía dưới
    # (không còn channel_combo).
    panel = CommandsPanel(world["store"])
    try:
        assert _combo_order(panel) == [
            panel.skill_combo,
            panel.agent_combo,
            panel.type_combo,
            panel.profile_combo,
        ]
        assert not hasattr(panel, "channel_combo")
    finally:
        panel.close()


def test_channel_and_agent_combos_follow_command_type(world):
    # V4.5 (pin mới): ô Muse chỉ bật cho lệnh Muse; danh sách
    # kênh checkbox LUÔN tick được — loại bắt buộc kênh mà chưa
    # tick kênh nào thì tóm tắt báo ⚠ ngay tại form.
    panel = CommandsPanel(world["store"])
    try:
        panel.type_combo.setCurrentIndex(panel.type_combo.findData("upload"))
        assert panel.agent_combo.isEnabled()
        assert "⚠ chưa tick kênh nào" in panel.form_summary.text()
        panel.type_combo.setCurrentIndex(panel.type_combo.findData("scan"))
        assert not panel.agent_combo.isEnabled()
        assert "Sẽ tạo:" in panel.form_summary.text()
    finally:
        panel.close()


def test_timer_only_runs_while_visible(world):
    panel = CommandsPanel(world["store"])
    try:
        assert not panel._timer.isActive()  # chưa show → không chạy
        panel.show()
        assert panel._timer.isActive()
        panel.hide()
        assert not panel._timer.isActive()
    finally:
        panel.close()


def test_create_shows_inline_status_and_selects_row(world):
    panel = CommandsPanel(world["store"])
    try:
        panel.show()  # isVisible() cần panel cha đang hiện
        panel.type_combo.setCurrentIndex(panel.type_combo.findData("scan"))
        panel._on_create()
        assert panel.form_status.isVisible()
        assert "Đã tạo lệnh" in panel.form_status.text()
        created = world["store"].list_commands(limit=1)[0]
        assert panel._selected_command_id() == created["id"]
    finally:
        panel.close()


def test_create_validation_error_is_inline(world):
    panel = CommandsPanel(world["store"])
    try:
        panel.show()
        panel.type_combo.setCurrentIndex(
            panel.type_combo.findData("create_video")
        )
        panel.instruction_edit.setPlainText("")
        panel._on_create()
        assert panel.form_status.isVisible()
        assert "Chưa tạo được lệnh" in panel.form_status.text()
        assert world["store"].list_commands(limit=5) == []
    finally:
        panel.close()


def test_table_not_rebuilt_when_data_unchanged(world):
    store = world["store"]
    cmd = store.create_command(
        "scan", source="ui",
        profile_id=world["profile"]["id"],
        profile_slug=world["profile"]["slug"],
        status="queued",
    )
    panel = CommandsPanel(store)
    try:
        widget_before = panel.table.cellWidget(0, 8)
        assert widget_before is not None
        panel.refresh()
        assert panel.table.cellWidget(0, 8) is widget_before
        store.finish_command(cmd["id"], "done", result="xong")
        panel.refresh()
        assert panel.table.cellWidget(0, 8) is not widget_before
    finally:
        panel.close()
