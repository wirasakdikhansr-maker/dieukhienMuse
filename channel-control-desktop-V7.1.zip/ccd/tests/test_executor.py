"""Kiểm thử V3 cho bộ thực thi lệnh tại chỗ (app.executor) với Chrome giả."""

import pytest

from app import executor
from app.store import Store


class FakeManager:
    def __init__(self, running=False):
        self._running = running
        self.launched = []

    def launch(self, profile):
        self.launched.append(profile["slug"])
        return "launched"

    def is_running(self, profile):
        return self._running


@pytest.fixture()
def db(tmp_path):
    path = tmp_path / "test.sqlite3"
    store = Store(path)
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    store.close()
    return path, profile


def test_open_browser_command_runs_end_to_end(db):
    path, profile = db
    store = Store(path)
    cmd = store.create_command(
        "open_browser", source="ui", profile_id=profile["id"], status="queued"
    )
    store.close()
    manager = FakeManager()
    final = executor.run_command_by_id(path, cmd["id"], manager)
    assert final["status"] == "done"
    assert "đã mở" in final["result"]
    assert final["started_at"] and final["finished_at"]
    assert manager.launched == [profile["slug"]]


def test_run_command_by_id_returns_none_when_not_queued(db):
    path, profile = db
    store = Store(path)
    cmd = store.create_command(
        "optimize", source="ui", profile_id=profile["id"], status="waiting_muse"
    )
    store.close()
    assert executor.run_command_by_id(path, cmd["id"], FakeManager()) is None
    assert executor.run_command_by_id(path, "khong-co", FakeManager()) is None


def test_execute_rejects_claude_types_and_paused(db):
    path, profile = db
    store = Store(path)
    try:
        status, text = executor.execute_local_command(
            store, {"type": "optimize", "profile_id": profile["id"]}, FakeManager()
        )
        assert status == "failed"
        assert "chờ Muse" in text
        store.set_profile_paused(profile["id"], True)
        status, text = executor.execute_local_command(
            store, {"type": "scan", "profile_id": profile["id"]}, FakeManager()
        )
        assert status == "failed"
        assert "tạm dừng" in text
        status, _ = executor.execute_local_command(
            store, {"type": "scan", "profile_id": 99999}, FakeManager()
        )
        assert status == "failed"
    finally:
        store.close()


def test_check_command_with_chrome_down(db):
    path, profile = db
    store = Store(path)
    cmd = store.create_command(
        "check", source="auto", profile_id=profile["id"], status="queued"
    )
    store.close()
    final = executor.run_command_by_id(path, cmd["id"], FakeManager(running=False))
    assert final["status"] == "done"
    assert "Kiểm tra hồ sơ" in final["result"]
    # Kết quả kiểm tra đã được lưu cho panel/API đọc lại.
    store = Store(path)
    try:
        assert store.get_last_check(profile["id"]) is not None
    finally:
        store.close()


def test_scan_command_uses_injected_scan_fn(db):
    path, profile = db
    store = Store(path)
    cmd = store.create_command(
        "scan", source="ui", profile_id=profile["id"], status="queued"
    )
    store.close()

    def stub_scan(store_, profile_, manager_, log=None):
        return {"status": "ok", "message": "Quét giả xong: 3 kênh."}

    final = executor.run_command_by_id(path, cmd["id"], FakeManager(), scan_fn=stub_scan)
    assert final["status"] == "done"
    assert final["result"] == "Quét giả xong: 3 kênh."
