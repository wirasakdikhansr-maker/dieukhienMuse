"""V4.3 — Zoom trình duyệt nhúng (G5) + lệnh hành động CDP trong trang
(cdp_evaluate/cdp_click/cdp_type): kiểm thử ở mức hàm bằng CDP client
giả lập — không cần Chrome thật (zoom trên Chrome thật + trang thật
phải nghiệm thu trên máy Windows)."""

import pytest

from app import browser_zoom, command_schema, config
from app.agent_server import AgentServer
from app.store import CDP_COMMAND_TYPES, COMMAND_TYPES, Store


# --------------------------------------------------------------------------- #
# browser_zoom — hàm thuần + áp scale qua client giả
# --------------------------------------------------------------------------- #
class FakeScaleClient:
    def __init__(self):
        self.calls = []

    def call(self, method, params=None):
        self.calls.append((method, params))
        return {}


def test_zoom_defaults_and_clamp():
    assert browser_zoom.get_zoom_pct({}, "slug-a") == 75
    assert browser_zoom.get_zoom_pct(None, "slug-a") == 75
    assert browser_zoom.get_zoom_pct({"browser_zoom_pct": {"a": 10}}, "a") == 50
    assert browser_zoom.get_zoom_pct({"browser_zoom_pct": {"a": 999}}, "a") == 150
    assert browser_zoom.clamp_zoom_pct("rác") == 75
    assert browser_zoom.page_scale_factor(75) == 0.75
    settings = {}
    assert browser_zoom.set_zoom_pct(settings, "a", 80) == 80
    assert browser_zoom.get_zoom_pct(settings, "a") == 80


def test_apply_page_scale_uses_cdp_emulation():
    client = FakeScaleClient()
    factor = browser_zoom.apply_page_scale(client, 75)
    assert factor == 0.75
    assert client.calls == [
        ("Emulation.setPageScaleFactor", {"pageScaleFactor": 0.75})
    ]


class _OkManager:
    def __init__(self):
        self.client = FakeScaleClient()
        self.client.close = lambda: None

    def connect_page(self, profile):
        return self.client


class _DeadManager:
    def connect_page(self, profile):
        raise RuntimeError("chrome chưa chạy")


def test_apply_zoom_for_profile_swallows_errors():
    assert browser_zoom.apply_zoom_for_profile(_OkManager(), {"slug": "a"}, 75)
    assert not browser_zoom.apply_zoom_for_profile(
        _DeadManager(), {"slug": "a"}, 75
    )


# --------------------------------------------------------------------------- #
# Loại lệnh CDP mới: khai báo + schema
# --------------------------------------------------------------------------- #
def test_cdp_types_registered():
    for ctype in ("cdp_evaluate", "cdp_click", "cdp_type"):
        assert ctype in CDP_COMMAND_TYPES
        assert ctype in COMMAND_TYPES


def test_cdp_schema_validation():
    assert command_schema.validate_command(
        "cdp_evaluate", payload={"expression": "1+1"}
    ) == []
    assert command_schema.validate_command("cdp_evaluate", payload={})
    assert command_schema.validate_command(
        "cdp_click", payload={"selector": "#like"}
    ) == []
    assert command_schema.validate_command(
        "cdp_click", payload={"text": "Thích"}
    ) == []
    assert command_schema.validate_command("cdp_click", payload={})
    assert command_schema.validate_command(
        "cdp_type", payload={"text": "hay quá", "selector": "#comment"}
    ) == []
    assert command_schema.validate_command("cdp_type", payload={"selector": "#c"})


# --------------------------------------------------------------------------- #
# _do_cdp_act qua manager giả — bấm/gõ/JS + ảnh xác nhận
# --------------------------------------------------------------------------- #
class FakeActClient:
    def __init__(self):
        self.mouse = []
        self.calls = []
        self.closed = False

    def evaluate(self, expression, timeout=None):
        if "getBoundingClientRect" in expression:
            return {
                "tag": "BUTTON", "text": "Thích", "x": 120.0, "y": 240.0,
                "visible": True,
            }
        if "el.focus" in expression:
            return True
        return "giá-trị-js"

    def dispatch_mouse(self, params):
        self.mouse.append(params)

    def call(self, method, params=None):
        self.calls.append((method, params))
        return {}

    def capture_screenshot_png(self):
        return b"\x89PNG-fake-bytes"

    def close(self):
        self.closed = True


class FakeActManager:
    def __init__(self):
        self.client = FakeActClient()

    def connect_page(self, profile):
        return self.client


@pytest.fixture()
def act_server(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    seed = Store(config.db_path(tmp_path))
    profile = seed.add_profile("KenhA", "a@example.com")
    seed.close()
    server = AgentServer(
        data_dir=tmp_path, settings={"agent_port": 0}, manager=FakeActManager()
    )
    yield server, profile
    server.stop()


def _record(ctype, payload):
    return {"id": "cmd-test-0001", "type": ctype, "payload": payload}


def test_cdp_evaluate_returns_value_and_screenshot(act_server, tmp_path):
    server, profile = act_server
    result = server._do_cdp_act(
        profile, _record("cdp_evaluate", {"expression": "document.title"})
    )
    assert result["value"] == "giá-trị-js"
    assert result["screenshot"] == "cdp-cmd-test.png"
    assert (tmp_path / "screenshots" / "cdp-cmd-test.png").exists()
    assert server._manager.client.closed is True


def test_cdp_click_dispatches_real_mouse_at_element_center(act_server):
    server, profile = act_server
    result = server._do_cdp_act(
        profile, _record("cdp_click", {"text": "Thích"})
    )
    assert result["clicked"]["tag"] == "BUTTON"
    events = server._manager.client.mouse
    assert [e["type"] for e in events] == ["mousePressed", "mouseReleased"]
    assert events[0]["x"] == 120.0 and events[0]["y"] == 240.0


def test_cdp_type_focuses_and_inserts_text(act_server):
    server, profile = act_server
    result = server._do_cdp_act(
        profile, _record("cdp_type", {"text": "Video hay quá!", "selector": "#c"})
    )
    assert result["typed"]["chars"] == len("Video hay quá!")
    assert ("Input.insertText", {"text": "Video hay quá!"}) in (
        server._manager.client.calls
    )


def test_cdp_act_missing_payload_fails_loudly(act_server):
    server, profile = act_server
    with pytest.raises(ValueError):
        server._do_cdp_act(profile, _record("cdp_evaluate", {}))
    with pytest.raises(ValueError):
        server._do_cdp_act(profile, _record("cdp_type", {"selector": "#c"}))
