"""Kiểm thử Agent API V3.2 qua dispatch() trực tiếp: tạo hồ sơ (chặn
trùng Gmail), báo tiến độ lệnh, kho cookies (nhập/trạng thái/nạp/xuất)."""

import json

import pytest

from app import cookies_vault
from app.agent_server import AgentServer
from app.store import Store
from app import config


class FakeManager:
    def __init__(self):
        self.running = True

    def is_running(self, profile):
        return self.running

    def launch(self, profile):
        return "launched"

    def connect_page(self, profile):  # không dùng trong các test này
        raise NotImplementedError


@pytest.fixture()
def agent(tmp_path, monkeypatch):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setenv("CCD_DATA_DIR", str(data_dir))
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    seed.close()
    server = AgentServer(
        data_dir=data_dir, settings={}, manager=FakeManager(), scan_fn=None
    )
    return {"server": server, "data_dir": data_dir, "slug": profile["slug"]}


def call(agent, method, path, payload=None, raw_body=None, headers=None):
    hdrs = {"X-Agent-Token": agent["server"].token}
    if headers:
        hdrs.update(headers)
    body = raw_body if raw_body is not None else (
        json.dumps(payload).encode("utf-8") if payload is not None else b""
    )
    return agent["server"].dispatch(method, path, hdrs, body)


def test_create_profile_and_duplicate_gmail_conflict(agent):
    status, payload = call(
        agent, "POST", "/api/profiles",
        {"label": "kenh nhieu phu de", "gmail": "panumol@gmail.com"},
    )
    assert status == 201
    assert payload["profile"]["gmail"] == "panumol@gmail.com"

    status, payload = call(
        agent, "POST", "/api/profiles",
        {"label": "trùng", "gmail": "PANUMOL@gmail.com"},
    )
    assert status == 409
    assert payload["profile"]["gmail"] == "panumol@gmail.com"

    status, payload = call(agent, "POST", "/api/profiles", {"label": "thiếu gmail"})
    assert status == 400


def test_command_progress_endpoint(agent):
    store = Store(config.db_path(agent["data_dir"]))
    profile = store.list_profiles()[0]
    command = store.create_command(
        "optimize", source="ui", profile_id=profile["id"],
        profile_slug=profile["slug"], instruction="Tối ưu EP01", status="waiting_muse",
    )
    store.close()

    status, payload = call(
        agent, "POST", f"/api/commands/{command['id']}/progress",
        {"progress": 40, "step": "Đang viết lại tiêu đề…"},
    )
    assert status == 200
    record = payload["command"]
    assert record["progress"] == 40
    assert record["step"] == "Đang viết lại tiêu đề…"
    assert record["status"] == "running"

    status, _ = call(
        agent, "POST", "/api/commands/khong-co/progress", {"progress": 10}
    )
    assert status == 404


def test_cookies_import_status_apply_export(agent, monkeypatch):
    slug = agent["slug"]
    raw = json.dumps(
        [{"name": "SID", "value": "bi-mat", "domain": ".google.com", "path": "/",
          "secure": True, "httpOnly": True, "sameSite": "lax", "expirationDate": 1893456000}]
    ).encode("utf-8")
    status, payload = call(
        agent, "POST", f"/api/profiles/{slug}/cookies",
        raw_body=raw, headers={"X-File-Name": "cookies.json"},
    )
    assert status == 200
    assert payload["cookies"]["count"] == 1
    assert payload["cookies"]["auth_cookies"] == ["SID"]
    assert "bi-mat" not in json.dumps(payload)  # không lộ giá trị cookie

    status, payload = call(agent, "GET", f"/api/profiles/{slug}/cookies")
    assert status == 200
    assert payload["cookies"]["exists"] is True

    applied = {}
    monkeypatch.setattr(
        "app.agent_server.cdp.set_cookies",
        lambda port, params: applied.update(port=port, params=params),
    )
    status, payload = call(agent, "POST", f"/api/profiles/{slug}/cookies/apply")
    assert status == 200
    assert payload["applied"] == 1
    assert applied["params"][0]["name"] == "SID"

    monkeypatch.setattr(
        "app.agent_server.cdp.get_all_cookies",
        lambda port: [
            {"name": "HSID", "value": "x", "domain": ".google.com", "path": "/",
             "expires": -1, "httpOnly": True, "secure": True, "session": True},
            {"name": "tracker", "value": "y", "domain": ".example.com", "path": "/"},
        ],
    )
    status, payload = call(agent, "POST", f"/api/profiles/{slug}/cookies/export")
    assert status == 200
    assert payload["exported"] == 1  # chỉ giữ domain Google/YouTube
    assert cookies_vault.summarize(slug, base=agent["data_dir"])["auth_cookies"] == ["HSID"]


def test_cookies_import_rejects_garbage(agent):
    status, payload = call(
        agent, "POST", f"/api/profiles/{agent['slug']}/cookies",
        raw_body=b"day khong phai cookies",
    )
    assert status == 400
