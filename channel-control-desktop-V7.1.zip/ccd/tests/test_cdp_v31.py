"""Kiểm thử V3.1 cho CDP: nhận diện lỗi 403/origin, chất lượng thích
ứng, và client tự nối lại khi socket rớt (websocket giả)."""

import json
import sys
import types

import pytest

from app import cdp


# --------------------------------------------------------------------------- #
# classify_ws_error
# --------------------------------------------------------------------------- #
RAW_403 = (
    "Handshake status 403 Forbidden — Rejected an incoming WebSocket "
    "connection from the http://127.0.0.1:19500 origin. Use the command "
    "line flag --remote-allow-origins=http://127.0.0.1:19500 to allow "
    "connections from this origin or --remote-allow-origins=* to allow "
    "all origins."
)


def test_classify_origin_rejected():
    message = cdp.classify_ws_error(RAW_403)
    assert message is not None
    assert "khay hệ thống" in message  # hướng dẫn đóng hẳn Chrome kể cả tray
    assert "--remote-allow-origins" in message


def test_classify_other_errors_return_none():
    assert cdp.classify_ws_error("Kết nối bị từ chối (connection refused)") is None
    assert cdp.classify_ws_error(None) is None
    assert cdp.classify_ws_error("") is None


def test_is_connection_drop():
    assert cdp.is_connection_drop(ConnectionError("đóng")) is True
    assert cdp.is_connection_drop(cdp.CDPConnectionDropped("rớt")) is True
    assert cdp.is_connection_drop(ValueError("sai")) is False
    assert cdp.is_connection_drop(cdp.CDPError("cdp")) is False


# --------------------------------------------------------------------------- #
# AdaptiveQuality
# --------------------------------------------------------------------------- #
def test_adaptive_quality_steps_down_when_slow():
    aq = cdp.AdaptiveQuality(levels=(60, 45, 30), target_interval=0.2)
    assert aq.quality() == 60
    for _ in range(3):
        aq.note_frame(0.9)  # chậm liên tục
    assert aq.quality() == 45
    for _ in range(3):
        aq.note_frame(0.9)
    assert aq.quality() == 30
    for _ in range(5):
        aq.note_frame(0.9)
    assert aq.quality() == 30  # không xuống dưới bậc cuối


def test_adaptive_quality_recovers_when_fast():
    aq = cdp.AdaptiveQuality(levels=(60, 45), target_interval=0.2)
    for _ in range(3):
        aq.note_frame(1.0)
    assert aq.quality() == 45
    for _ in range(10):
        aq.note_frame(0.01)  # nhanh liên tục -> nâng lại
    assert aq.quality() == 60


def test_adaptive_quality_steady_frames_no_change():
    aq = cdp.AdaptiveQuality(levels=(60, 45), target_interval=0.2)
    for _ in range(20):
        aq.note_frame(0.15)  # trong ngưỡng mục tiêu
    assert aq.quality() == 60


# --------------------------------------------------------------------------- #
# CDPClient tự nối lại
# --------------------------------------------------------------------------- #
class FakeWS:
    """WebSocket giả: recv() nhận id của lệnh vừa send (client tăng id
    sau mỗi lần thử lại, nên bản giả phải echo đúng id đó)."""

    def __init__(self, behavior):
        self._behavior = behavior
        self._last_id = None

    def settimeout(self, _timeout):
        pass

    def send(self, payload):
        self._last_id = json.loads(payload)["id"]

    def recv(self):
        return self._behavior(self._last_id)

    def close(self):
        pass


@pytest.fixture()
def fake_websocket(monkeypatch):
    module = types.ModuleType("websocket")
    module.connections = []
    module.behaviors = []

    def create_connection(url, timeout=None):
        behavior = module.behaviors[len(module.connections)]
        ws = FakeWS(behavior)
        module.connections.append((url, ws))
        return ws

    module.create_connection = create_connection
    monkeypatch.setitem(sys.modules, "websocket", module)
    return module


def _drop(_last_id):
    raise ConnectionError("Connection is already closed")


def _respond_ok(last_id):
    return json.dumps({"id": last_id, "result": {"value": 42}})


def test_client_reconnects_and_retries_on_drop(fake_websocket):
    fake_websocket.behaviors = [_drop, _respond_ok]
    reconnected = []

    def reconnect():
        reconnected.append(True)
        return "ws://fake-2"

    client = cdp.CDPClient(
        "ws://fake-1", reconnect=reconnect, sleep=lambda _s: None
    )
    result = client.call("Runtime.evaluate", {"expression": "42"})
    assert result == {"value": 42}
    assert reconnected == [True]
    assert fake_websocket.connections[1][0] == "ws://fake-2"


def test_client_without_reconnect_reraises(fake_websocket):
    fake_websocket.behaviors = [_drop]
    client = cdp.CDPClient("ws://fake-1")
    with pytest.raises(ConnectionError):
        client.call("Runtime.evaluate")


def test_client_does_not_retry_timeouts(fake_websocket):
    def slow(_last_id):
        raise TimeoutError("timed out")

    fake_websocket.behaviors = [slow, _respond_ok]
    client = cdp.CDPClient(
        "ws://fake-1", reconnect=lambda: "ws://fake-2", sleep=lambda _s: None
    )
    with pytest.raises(TimeoutError):
        client.call("Runtime.evaluate")
