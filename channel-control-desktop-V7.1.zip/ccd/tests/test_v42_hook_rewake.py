"""V4.2 (O-29) — hook canh cầu nối ccd-bridge-watch: lệnh
waiting_muse đã wake mà chưa ai claim thì được NHẮC LẠI theo cấp
số nhân (60s → 120s → … trần 600s); state cũ (waiting_ids dạng
list) được di trú không wake lại tức thì.

Kiểm thử bằng cách trích phần Python nhúng trong script (giữa hai
mốc PYEOF), nạp vào namespace riêng với opener HTTP giả — token
trong phiếu chỉ được script tự đọc trong tiến trình, test không
in/đụng vào giá trị token.
"""

import io
import json
import os
import re
import time
import urllib.request
from contextlib import redirect_stdout
from pathlib import Path

import pytest

SCRIPT = Path.home() / "hooks" / "scripts" / "ccd-bridge-watch.sh"
PHIEU = Path.home() / "workspace" / "user" / "files" / "phieu-ket-noi-claude.txt"

pytestmark = pytest.mark.skipif(
    not SCRIPT.exists() or not PHIEU.exists(),
    reason="thiếu script hook hoặc phiếu kết nối trên máy này",
)

CMD_ID = "cafef00d" + "0" * 24


def _load_hook_module():
    # Script đọc CCD_STATE_FILE ngay lúc nạp module — cho một giá
    # trị mặc định vô hại nếu test chưa đặt (không ghi thật vì
    # save_state chỉ chạy trong main()).
    os.environ.setdefault(
        "CCD_STATE_FILE", "/tmp/ccd-hook-test-state-unused.json"
    )
    text = SCRIPT.read_text(encoding="utf-8")
    match = re.search(r"<<'PYEOF'\n(.*?)\nPYEOF", text, re.S)
    assert match, "không trích được Python nhúng trong script hook"
    source = match.group(1)
    assert source.rstrip().endswith("main()")
    source = source.rstrip()[: -len("main()")]
    namespace: dict = {}
    exec(compile(source, "ccd-bridge-watch.py", "exec"), namespace)
    return namespace


class _FakeResponse:
    def __init__(self, payload):
        self._body = json.dumps(payload).encode("utf-8")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def read(self):
        return self._body


class _FakeOpener:
    def open(self, req, timeout=0):
        if "/heartbeat" in req.full_url:
            return _FakeResponse({})
        assert "/api/commands" in req.full_url
        return _FakeResponse({
            "commands": [{
                "id": CMD_ID, "type": "optimize",
                "status": "waiting_muse", "profile_slug": "kenh-a",
                "instruction": "Tối ưu EP01",
            }]
        })


def _run_main(namespace, tmp_path, monkeypatch, state):
    state_file = tmp_path / "state.json"
    state_file.write_text(json.dumps(state), encoding="utf-8")
    monkeypatch.setenv("CCD_STATE_FILE", str(state_file))
    monkeypatch.setenv("HTTPS_PROXY", "http://100.64.0.1:8080")
    # Nạp lại module với biến môi trường state mới (STATE_FILE đọc
    # lúc nạp) và opener giả.
    fresh = _load_hook_module()
    monkeypatch.setattr(
        urllib.request, "build_opener", lambda *a, **k: _FakeOpener()
    )
    out = io.StringIO()
    with redirect_stdout(out):
        fresh["main"]()
    return out.getvalue().strip()


def test_rewake_backoff_math():
    ns = _load_hook_module()
    now = 1_000_000.0
    entry = {"first_seen": now - 5000, "last_wake": now - 59, "wakes": 1}
    assert ns["rewake_due"](entry, now) is False
    entry["last_wake"] = now - 61
    assert ns["rewake_due"](entry, now) is True
    # Lần wake thứ 3 → khoảng lặng 240s.
    entry = {"first_seen": now - 5000, "last_wake": now - 200, "wakes": 3}
    assert ns["rewake_due"](entry, now) is False
    entry["last_wake"] = now - 241
    assert ns["rewake_due"](entry, now) is True
    # Trần 600s dù wakes rất lớn.
    entry = {"first_seen": now - 90000, "last_wake": now - 601, "wakes": 12}
    assert ns["rewake_due"](entry, now) is True


def test_legacy_state_migrates_without_immediate_rewake():
    ns = _load_hook_module()
    now = time.time()
    tracked = ns["tracked_waiting"]({"waiting_ids": [CMD_ID]}, now)
    assert CMD_ID in tracked
    assert tracked[CMD_ID]["wakes"] == 1
    assert ns["rewake_due"](tracked[CMD_ID], now) is False


def test_main_rewakes_stale_waiting_command(tmp_path, monkeypatch):
    now = time.time()
    state = {
        "waiting": {
            CMD_ID: {
                "first_seen": now - 7200, "last_wake": now - 3600,
                "wakes": 1,
            }
        },
        "last_kind": "ok",
        "auth_wake_sent": False,
    }
    output = _run_main(_load_hook_module(), tmp_path, monkeypatch, state)
    decision, _reason, payload = output.split("\t", 2)
    assert decision == "wake"
    commands = json.loads(payload)["commands"]
    assert [c["id"] for c in commands] == [CMD_ID]
    assert commands[0].get("rewake") is True


def test_main_silent_when_rewake_not_due(tmp_path, monkeypatch):
    now = time.time()
    state = {
        "waiting": {
            CMD_ID: {
                "first_seen": now - 7200, "last_wake": now - 5,
                "wakes": 1,
            }
        },
        "last_kind": "ok",
        "auth_wake_sent": False,
    }
    output = _run_main(_load_hook_module(), tmp_path, monkeypatch, state)
    assert output.startswith("silent\t")
