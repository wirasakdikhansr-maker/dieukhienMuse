"""V3.9.1: chữa LỆNH MỒ CÔI — lệnh "Chờ Muse" tạo TRƯỚC khi hồ sơ có
người phụ trách (agent_id trống) cộng với id hồ sơ có thể đã mục khi
hồ sơ bị xoá/tạo lại, khiến lệnh nằm ngoài phạm vi của MỌI Muse dù
cầu nối đã thông (sự cố thật 28/10: lệnh tạo kênh #27049736dfac cho
mail dabnire34 — banner xanh, heartbeat 200, nhưng GET /api/commands
rỗng và GET từng lệnh trả 403).

Quy tắc chữa: slug hồ sơ chụp tại lúc tạo lệnh là danh tính bền của
mail. Lệnh chưa ghi danh ai + slug khớp hồ sơ của Muse nào → thuộc
phạm vi Muse đó (liệt kê + truy cập + nhận qua báo tiến độ). Phân
công mới cũng tự gắn lại agent_id cho các lệnh đang chờ khớp id/slug.
"""

import pytest
from PySide6.QtWidgets import QApplication

from app import config
from app.agent_server import AgentServer
from app.store import Store
from test_agent_server import FakeManager, stub_scan


@pytest.fixture(scope="module", autouse=True)
def qapp():
    return QApplication.instance() or QApplication([])


def _seed(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("dabnire34@gmail.com", "dabnire34@gmail.com")
    other = store.add_profile("KenhHoatHinh", "23shinryujin@gmail.com")
    agent = store.create_agent("dabnire34@gmail.com", "dabnire34@gmail.com")
    return store, profile, other, agent


def _orphan(store, profile, **kw):
    """Tạo lệnh mồ côi đúng như bản cũ: agent_id trống (tạo trước khi
    có phân công — nơi tạo truyền profile nhưng store không gắn được
    vì lúc đó chưa có chủ), trạng thái waiting_muse."""
    kw.setdefault("profile_id", profile["id"])
    kw.setdefault("profile_slug", profile["slug"])
    cmd = store.create_command(
        "create_channel", source="ui", instruction="Tạo kênh đầu tiên",
        status="waiting_muse", **kw,
    )
    # create_command tự gắn chủ NẾU đã có phân công; mô phỏng thời
    # điểm tạo lệnh khi CHƯA phân công: xoá trắng agent_id.
    store.set_command_agent(cmd["id"], None)
    return store.get_command(cmd["id"])


def test_orphan_visible_by_slug_after_assignment(tmp_path):
    store, profile, _other, agent = _seed(tmp_path)
    cmd = _orphan(store, profile)
    assert store.list_commands_for_agent(agent["id"]) == []
    store.assign_profiles(agent["id"], [profile["id"]])
    ids = [c["id"] for c in store.list_commands_for_agent(agent["id"])]
    assert cmd["id"] in ids
    assert store.agent_can_access_command(agent["id"], store.get_command(cmd["id"]))


def test_orphan_with_null_profile_id_still_visible(tmp_path):
    store, profile, _other, agent = _seed(tmp_path)
    # Sự cố thật: profile_id TRỐNG (bản tạo lệnh cũ chỉ lưu slug) —
    # khoá ngoại của bảng lệnh khiến id mục không tồn tại được, nên
    # mồ côi ngoài phạm vi luôn là dạng profile_id NULL + slug còn.
    cmd = _orphan(store, profile, profile_id=None)
    store.assign_profiles(agent["id"], [profile["id"]])
    ids = [c["id"] for c in store.list_commands_for_agent(agent["id"])]
    assert cmd["id"] in ids
    assert store.agent_can_access_command(agent["id"], store.get_command(cmd["id"]))


def test_orphan_of_other_profile_not_visible(tmp_path):
    store, profile, other, agent = _seed(tmp_path)
    cmd = _orphan(store, other)  # mồ côi của hồ sơ KHÁC
    store.assign_profiles(agent["id"], [profile["id"]])
    ids = [c["id"] for c in store.list_commands_for_agent(agent["id"])]
    assert cmd["id"] not in ids
    assert not store.agent_can_access_command(
        agent["id"], store.get_command(cmd["id"])
    )


def test_claimed_command_of_unowned_profile_not_visible(tmp_path):
    # Lệnh đã ghi danh Muse khác, thuộc hồ sơ agent này KHÔNG phụ
    # trách (id lẫn slug đều không khớp): ngoài phạm vi, đúng chốt
    # chống giẫm chân. (Lệnh trên hồ sơ MÌNH phụ trách thì luôn thuộc
    # phạm vi của mình — một hồ sơ chỉ có một Muse chính.)
    store, profile, other, agent = _seed(tmp_path)
    rival = store.create_agent("Rival", "rival@claude.ai")
    cmd = _orphan(store, other)
    store.set_command_agent(cmd["id"], rival["id"])
    store.assign_profiles(agent["id"], [profile["id"]])
    ids = [c["id"] for c in store.list_commands_for_agent(agent["id"])]
    assert cmd["id"] not in ids
    assert not store.agent_can_access_command(
        agent["id"], store.get_command(cmd["id"])
    )


def test_assign_backfills_agent_id_by_id_and_slug(tmp_path):
    store, profile, _other, agent = _seed(tmp_path)
    by_id = _orphan(store, profile)
    by_slug = _orphan(store, profile, profile_id=None)
    store.assign_profiles(agent["id"], [profile["id"]])
    assert store.get_command(by_id["id"])["agent_id"] == agent["id"]
    assert store.get_command(by_slug["id"])["agent_id"] == agent["id"]


def test_api_orphan_end_to_end(tmp_path):
    import json
    import urllib.request

    data_dir = tmp_path / "data"
    data_dir.mkdir()
    seed = Store(config.db_path(data_dir))
    profile = seed.add_profile("dabnire34@gmail.com", "dabnire34@gmail.com")
    agent = seed.create_agent("dabnire34@gmail.com", "dabnire34@gmail.com")
    cmd = seed.create_command(
        "create_channel", source="ui", profile_id=None,
        profile_slug=profile["slug"], instruction="Tạo kênh đầu tiên",
        status="waiting_muse",
    )
    seed.assign_profiles(agent["id"], [profile["id"]])
    token = seed.get_agent(agent["id"])["token"]
    seed.close()

    server = AgentServer(
        data_dir=data_dir, settings={"agent_port": 0},
        manager=FakeManager(), scan_fn=stub_scan,
    )
    server.start()
    try:
        headers = {"X-Agent-Id": str(agent["id"]), "X-Agent-Token": token}

        def call(method, path, payload=None):
            req = urllib.request.Request(
                f"http://127.0.0.1:{server.port}{path}",
                method=method,
                headers=headers,
                data=json.dumps(payload).encode() if payload is not None else None,
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                return json.loads(resp.read())

        listing = call("GET", "/api/commands")
        assert [c["id"] for c in listing["commands"]] == [cmd["id"]]
        single = call("GET", f"/api/commands/{cmd['id']}")
        assert single["ok"] is True
        progress = call(
            "POST", f"/api/commands/{cmd['id']}/progress",
            {"progress": 10, "step": "Đã nhận lệnh"},
        )
        assert progress["ok"] is True
    finally:
        server.stop()
    check = Store(config.db_path(data_dir))
    try:
        saved = check.get_command(cmd["id"])
        assert saved["agent_id"] == agent["id"]  # báo tiến độ = nhận lệnh
        assert saved["status"] == "running"
    finally:
        check.close()
