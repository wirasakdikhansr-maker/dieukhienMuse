"""V6.9 — menu chuột phải + hàng loạt ở Bảng việc chi tiết, popup "kẹt gì",
chọn nhiều kênh (viền nổi), mọi nút có trạng thái xử lý, thanh công cụ Hồ sơ."""

from __future__ import annotations

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication, QPushButton  # noqa: E402

from app import command_actions as ca  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui import work_model  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path):
    return Store(tmp_path / "d.db")


def _world(store, n_channels=3):
    agent = store.create_agent("Muse A", "a@x.com")
    other = store.create_agent("Muse B", "b@x.com")
    for a in (agent, other):
        store.touch_agent_heartbeat(a["id"])
    profile = store.add_profile("Kids", "kids@x.com")
    store.assign_profiles(agent["id"], [profile["id"]])
    for i in range(n_channels):
        store.upsert_channel(profile["id"], {"channel_id": f"UC{i}", "name": f"Kênh {i}", "handle": f"@k{i}"})
    return store.get_agent(agent["id"]), store.get_agent(other["id"]), profile


# --------------------------------------------------------------------------- #
# Thao tác hàng loạt (dữ liệu)
# --------------------------------------------------------------------------- #
def test_bulk_delete_keeps_running(store):
    a, _b, p = _world(store)
    c1 = store.create_command("free", instruction="1", agent_id=a["id"], profile_id=p["id"])
    c2 = store.create_command("free", instruction="2", agent_id=a["id"], profile_id=p["id"])
    store.update_command(c2["id"], status="running")
    r = ca.bulk_delete(store, [c1["id"], c2["id"]])
    assert r == {"deleted": 1, "kept_running": 1}
    assert store.get_command(c1["id"]) is None and store.get_command(c2["id"]) is not None


def test_bulk_assign_moves_and_resends(store):
    a, b, p = _world(store)
    c1 = store.create_command("free", instruction="1", agent_id=a["id"], profile_id=p["id"])
    c2 = store.create_command("free", instruction="2", agent_id=a["id"], profile_id=p["id"])
    store.update_command(c2["id"], status="running")
    store.update_command_payload_flags(c2["id"], {"chat_sent": True, "acked": True})
    done = store.create_command("free", instruction="3", agent_id=a["id"])
    store.finish_command(done["id"], "done", result="ok")
    r = ca.bulk_assign(store, [c1["id"], c2["id"], done["id"]], b["id"])
    assert r["assigned"] == 2 and r["skipped"] == 1
    moved = store.get_command(c2["id"])
    assert moved["agent_id"] == b["id"] and moved["status"] == "waiting_muse"
    assert "chat_sent" not in (moved.get("payload") or {}) and "acked" not in (moved.get("payload") or {})
    assert store.get_command(done["id"])["agent_id"] == a["id"]


def test_bulk_resume_resend_extend_cancel(store):
    a, _b, p = _world(store)
    c1 = store.create_command("free", instruction="1", agent_id=a["id"])
    store.update_command(c1["id"], status="needs_user")
    c2 = store.create_command("free", instruction="2", agent_id=a["id"])
    store.finish_command(c2["id"], "failed", error="Lỗi mạng")
    assert ca.bulk_resume(store, [c1["id"], c2["id"]])["resumed"] == 2
    assert store.get_command(c2["id"])["status"] in ("queued", "waiting_muse")
    store.update_command_payload_flags(c1["id"], {"chat_sent": True})
    assert ca.bulk_resend(store, [c1["id"]])["resent"] == 1
    assert not (store.get_command(c1["id"]).get("payload") or {}).get("chat_sent")
    store.set_command_due(c1["id"], "2030-01-01T10:00:00+07:00")
    assert ca.bulk_extend(store, [c1["id"]], 60)["extended"] == 1
    calls = []
    r = ca.bulk_cancel(store, [c1["id"], c2["id"]], lambda row: calls.append(row["id"]) or True)
    assert r["cancelled"] == 2 and calls == [c1["id"], c2["id"]]


def test_explain_command_says_what_is_stuck(store):
    a, _b, p = _world(store)
    c = store.create_command("upload", instruction="Đăng video", agent_id=a["id"], profile_id=p["id"])
    store.update_command(c["id"], status="needs_user", error="Thiếu file thumbnail.png")
    store.add_message(a["id"], "agent", "CẦN BẠN: gửi giúp thumbnail", command_id=c["id"])
    info = ca.explain_command(store, c["id"])
    assert "Thiếu file thumbnail.png" in info["reason"]
    assert any(k == "💬 Muse nói" and "thumbnail" in v for k, v in info["lines"])
    assert info["next"]
    w = store.create_command("free", instruction="x", agent_id=a["id"])
    store.update_command(w["id"], status="waiting_muse")
    store.update_command_payload_flags(w["id"], {"chat_sent": True, "chat_sent_at": "2020-01-01T00:00:00+00:00"})
    assert "ĐÃ NHẬN" in ca.explain_command(store, w["id"])["reason"]
    html = ca.group_html(store, "Đang kẹt", [c["id"], w["id"]])
    assert "2 việc" in html and "thumbnail" in html
    assert "Không có việc" in ca.group_html(store, "Trễ hạn", [])


# --------------------------------------------------------------------------- #
# Bảng việc chi tiết: chọn nhiều + menu chuột phải
# --------------------------------------------------------------------------- #
def test_steps_table_multiselect_and_menu(qapp, store, monkeypatch):
    from PySide6.QtWidgets import QAbstractItemView

    from app.ui.steps_table import StepsTable

    a, b, p = _world(store)
    ids = [store.create_command("free", instruction=f"Việc {i}", agent_id=a["id"], profile_id=p["id"])["id"]
           for i in range(4)]
    table = StepsTable(store, {})
    table.refresh()
    assert table.selectionMode() == QAbstractItemView.SelectionMode.ExtendedSelection
    assert table.contextMenuPolicy() == Qt.ContextMenuPolicy.CustomContextMenu
    table.select_command_ids(ids[:3])
    assert set(table.selected_command_ids()) == set(ids[:3])
    labels = [act.text() for act in table.build_menu(table.selected_command_ids()).actions() if act.text()]
    joined = "\n".join(labels)
    for needle in ("3 việc đã chọn", "🎯 Giao cho Muse", "🗑 Xoá 3 lệnh", "📨 Gửi lại", "✕ Huỷ", "☑ Chọn tất cả"):
        assert needle in joined, needle
    r = table.do_assign(ids[:2], b["id"])
    assert r["assigned"] == 2 and store.get_command(ids[0])["agent_id"] == b["id"]
    r = table.do_delete(ids[:3], confirm=False)
    assert r["deleted"] == 3
    table.refresh()
    assert table.topLevelItemCount() == 1
    single = [act.text() for act in table.build_menu([ids[3]]).actions() if act.text()]
    assert "▶ Chạy ngay" in single and "📋 Xem chi tiết lệnh" in single


# --------------------------------------------------------------------------- #
# Theo Agent: chọn kênh nổi viền + chọn nhiều + menu hàng loạt
# --------------------------------------------------------------------------- #
def _model(store):
    agents = store.list_agents()
    profiles = store.list_profiles()
    channels = {pr["id"]: store.list_channels(pr["id"]) for pr in profiles}
    return work_model.build_work_model(store.list_commands(limit=500), agents, profiles, channels)


def test_agent_board_selection_highlight_and_bulk(qapp, store, tmp_path, monkeypatch):
    from app.ui import agent_board

    _world(store)
    board = agent_board.AgentBoardWidget(store, tmp_path / "data")
    board.set_model(_model(store))
    keys = board.channel_keys()
    assert len(keys) == 3
    board._on_card_clicked(keys[0], Qt.KeyboardModifier.NoModifier)
    assert board.selected_keys() == [keys[0]]
    card = board.channel_card(keys[0])
    assert card.property("selected") is True and "2px solid" in card.styleSheet()
    board._on_card_clicked(keys[2], Qt.KeyboardModifier.ControlModifier)
    assert board.selected_keys() == [keys[0], keys[2]]
    board._on_card_clicked(keys[1], Qt.KeyboardModifier.ControlModifier)
    board._on_card_clicked(keys[0], Qt.KeyboardModifier.NoModifier)
    board._on_card_clicked(keys[2], Qt.KeyboardModifier.ShiftModifier)
    assert board.selected_keys() == keys
    assert "Đã chọn 3 kênh" in board.selection_label.text()
    assert board.bulk_assign_button.isVisibleTo(board)
    labels = [a.text() for a in board.build_bulk_menu(board.selected_channels_data()).actions() if a.text()]
    assert labels[0] == "3 kênh đã chọn" and "📋 Giao việc cho 3 kênh…" in labels
    # selection survives a model rebuild
    board.set_model(_model(store))
    assert board.selected_keys() == keys
    assert all(board.channel_card(k).property("selected") for k in keys)
    board.clear_selection()
    assert board.selected_keys() == [] and not board.channel_card(keys[0]).property("selected")


def test_assign_dialog_extra_targets_creates_for_every_channel(qapp, store, tmp_path):
    from app.ui.assign_dialog import AssignDialog

    a, _b, p = _world(store)
    channels = store.list_channels(p["id"])
    dialog = AssignDialog(store, agent=a, profile=p, channel=channels[0], base=tmp_path / "data",
                          extra_targets=[{"agent": a, "profile": p, "channel": ch} for ch in channels[1:]])
    lst = dialog.editor.template_list
    lst.item(0).setCheckState(Qt.CheckState.Checked)
    for row in range(1, lst.count()):
        lst.item(row).setCheckState(Qt.CheckState.Unchecked)
    assert "× 3 kênh" in dialog.assign_button.text()
    dialog._on_assign()
    assert len(dialog.created) == 3
    assert {c["channel_id"] for c in dialog.created} == {ch["channel_id"] for ch in channels}


# --------------------------------------------------------------------------- #
# Popup giải thích + phản hồi nút
# --------------------------------------------------------------------------- #
def test_lazy_tooltip_and_deadline_board_explain(qapp, store):
    from app.ui.supervision_panel import DeadlineBoard

    btn = QPushButton("Đang kẹt · 1")
    ca.attach_lazy_tooltip(btn, lambda: "<qt>hello</qt>")
    assert btn._ccd_tip_provider() == "<qt>hello</qt>"
    board = DeadlineBoard()
    assert hasattr(board, "explain")


def test_button_busy_and_flash(qapp):
    from app.ui import button_feedback

    btn = QPushButton("Quét")
    done = button_feedback.busy(btn, "⏳ Đang quét…")
    assert btn.text() == "⏳ Đang quét…" and not btn.isEnabled() and btn.property("ccd_busy")
    done(True)  # không có chữ kết quả → khôi phục ngay
    assert btn.text() == "Quét" and btn.isEnabled() and not btn.property("ccd_busy")
    done2 = button_feedback.busy(btn, "⏳")
    done2(True, "✓ Xong", hold_ms=10)
    assert btn.text() == "✓ Xong"
    button_feedback.flash(QPushButton("x"))
    button_feedback.install()
    button_feedback.install()  # gọi lại vô hại


# --------------------------------------------------------------------------- #
# Thanh công cụ Hồ sơ: nút ra ngoài, trạng thái chạy ẩn, zoom theo Tường
# --------------------------------------------------------------------------- #
def test_profiles_toolbar_hidden_status_and_wall_zoom(qapp, tmp_path, monkeypatch):
    from app import config
    from app.chrome_manager import ChromeManager
    from app.ui.main_window import MainWindow

    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    settings["agent_enabled"] = False
    st = Store(config.db_path())
    win = MainWindow(st, ChromeManager(), settings)
    try:
        for name in ("btn_open_browser", "btn_scan_profile", "btn_redock", "btn_check_profile"):
            assert isinstance(getattr(win, name), QPushButton), name
        win._apply_hidden_mode(True)
        assert win.hidden_status.isVisibleTo(win) or win.hidden_status.text()
        assert "Đang chạy ẩn" in win.hidden_status.text()
        win._apply_hidden_mode(False)
        assert "Nhúng trong app" in win.hidden_status.text()
        scopes = []
        monkeypatch.setattr(win, "_apply_page_zoom", lambda scope, pct: scopes.append((scope, pct)))
        win._wall_active = True
        win.page_zoom_single.setValue(80)
        win._apply_strip_zoom()
        assert scopes[-1] == ("all", 80)
        win._on_zoom_step(10)
        assert win.page_zoom_single.value() == 90
        assert win.zoom_label.text() == "90%"
    finally:
        win.close()
