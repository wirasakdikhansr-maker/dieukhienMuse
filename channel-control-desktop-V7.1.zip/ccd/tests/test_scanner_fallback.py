"""Kiểm thử scanner: khi account_menu đổi cấu trúc (parse ra 0 kênh),
scanner phải dự phòng bằng DOM menu tài khoản + tra ID theo @handle;
khi cả hai cách đều rỗng, thông báo lỗi phải kèm chẩn đoán cấu trúc."""

from app import scanner
from app.store import Store

BACHATA_ID = "UC" + "a" * 22
COUNTRY_ID = "UC" + "b" * 22


class FakeClient:
    def __init__(self, menu_data, dom=None, resolve=None):
        self.menu_data = menu_data
        self.dom = dom
        self.resolve = resolve or {}
        self.navigated = []

    def navigate(self, url):
        self.navigated.append(url)

    def evaluate(self, expression, timeout=None):
        if "ccd:menu" in expression:
            return {"ok": True, "status": 200, "data": self.menu_data}
        if "ccd:dom" in expression:
            return self.dom
        if "ccd:resolve" in expression:
            for marker, payload in self.resolve.items():
                if marker in expression:
                    return payload
            return {"channelId": None, "videoCount": None}
        if "readyState" in expression:
            return "complete"
        if "LOGGED_IN" in expression:
            return {"loggedIn": True, "href": "https://www.youtube.com/"}
        return None

    def close(self):
        pass


class FakeManager:
    def __init__(self, client):
        self.client = client

    def launch(self, profile):
        return "already_running"

    def connect_page(self, profile):
        return self.client


def _profile(store):
    return store.add_profile("kenh test", "panumol@gmail.com")


def test_scan_falls_back_to_dom_when_account_menu_structure_changed(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = _profile(store)
    client = FakeClient(
        menu_data={"responseContext": {}, "multiPageMenuRenderer": {"sections": []}},
        dom={
            "ok": True,
            "header": "Bachata de Desamor\n@BachataDeDesamor\npanumol@gmail.com",
            "items": [
                "Bachata de Desamor\n@BachataDeDesamor • 5.18K subscribers",
                "Old Country Gold\n@OldCountryGold • 4,780 subscribers",
            ],
        },
        resolve={
            "BachataDeDesamor": {"channelId": BACHATA_ID, "videoCount": "119"},
            "OldCountryGold": {"channelId": COUNTRY_ID, "videoCount": "57"},
        },
    )
    result = scanner.scan_profile(store, profile, FakeManager(client))
    assert result["status"] == "ok"
    channels = {c["channel_id"]: c for c in result["channels"]}
    assert set(channels) == {BACHATA_ID, COUNTRY_ID}
    assert channels[BACHATA_ID]["name"] == "Bachata de Desamor"
    assert channels[BACHATA_ID]["subs"] == 5180
    assert channels[BACHATA_ID]["video_count"] == 119
    assert channels[COUNTRY_ID]["subs"] == 4780
    saved = store.list_channels(profile["id"])
    assert len(saved) == 2


def test_scan_error_includes_structure_diagnosis_when_all_strategies_fail(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    profile = _profile(store)
    client = FakeClient(
        menu_data={"responseContext": {}, "multiPageMenuRenderer": {"sections": []}},
        dom={"ok": False, "error": "no_avatar_btn"},
    )
    result = scanner.scan_profile(store, profile, FakeManager(client))
    assert result["status"] == "error"
    assert "Chẩn đoán cấu trúc" in result["message"]
    assert "multiPageMenuRenderer" in result["message"]
    assert "HTTP 200" in result["message"]
