"""Kiểm thử V3.1 cho chẩn đoán khởi động (app.diagnostics) — phần định
hình thuần dữ liệu + lưu/đọc qua app_meta."""

import pytest

from app import diagnostics
from app.store import Store


def _probes(**overrides):
    probes = {
        "chrome_path": "/usr/bin/google-chrome",
        "agent_port": 19500,
        "bind_host": "0.0.0.0",
        "port_free": True,
        "token_present": True,
        "data_writable": True,
        "db_integrity": "ok",
    }
    probes.update(overrides)
    return probes


def _by_key(items):
    return {item["key"]: item for item in items}


def test_shape_all_ok():
    items = diagnostics.shape_diagnostics(_probes())
    shaped = _by_key(items)
    assert set(shaped) == {"chrome", "agent_port", "token", "data_writable", "db_integrity"}
    assert all(item["status"] == "ok" for item in items)
    assert "/usr/bin/google-chrome" in shaped["chrome"]["detail"]


def test_shape_failures_and_unknowns():
    items = diagnostics.shape_diagnostics(
        _probes(
            chrome_path=None,
            port_free=False,
            token_present=False,
            data_writable=False,
            db_integrity="page 4 is corrupt",
        )
    )
    shaped = _by_key(items)
    assert shaped["chrome"]["status"] == "fail"
    assert shaped["agent_port"]["status"] == "fail"
    assert "19500" in shaped["agent_port"]["detail"]
    assert shaped["token"]["status"] == "na"  # chưa có token không phải lỗi — sẽ tự sinh
    assert shaped["data_writable"]["status"] == "fail"
    assert shaped["db_integrity"]["status"] == "fail"
    assert "corrupt" in shaped["db_integrity"]["detail"]


def test_shape_port_unknown():
    items = diagnostics.shape_diagnostics(_probes(port_free=None, db_integrity=None))
    shaped = _by_key(items)
    assert shaped["agent_port"]["status"] == "na"
    assert shaped["db_integrity"]["status"] == "na"


def test_summarize_counts():
    items = diagnostics.shape_diagnostics(_probes(chrome_path=None))
    summary = diagnostics.summarize_diagnostics(items)
    assert "4 đạt" in summary and "1 lỗi" in summary


@pytest.fixture()
def store(tmp_path):
    s = Store(tmp_path / "test.sqlite3")
    yield s
    s.close()


def test_run_and_load_roundtrip(store, tmp_path):
    settings = {"agent_port": 19777, "agent_bind_localhost": True}
    items = diagnostics.run_startup_diagnostics(store, settings, tmp_path)
    keys = {item["key"] for item in items}
    assert "db_integrity" in keys
    saved = diagnostics.load_saved_diagnostics(store)
    assert saved is not None
    assert saved["items"] and saved["summary"]
    assert saved["ts"]


def test_port_is_free_helper():
    import socket

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    try:
        assert diagnostics.port_is_free("127.0.0.1", port) is False
    finally:
        sock.close()
    assert diagnostics.port_is_free("127.0.0.1", port) is True
