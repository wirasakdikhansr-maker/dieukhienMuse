"""Hồi quy sở hữu QThread (bản vá V3.1 — sập app khi bấm "Quét kênh").

Sự cố trên Windows thật: ``MainWindow._stop_live_worker`` cũ gọi
``wait(2500)`` rồi BỎ QUA kết quả và gán ``self._live_worker = None``
luôn. Worker luồng trực tiếp lại thường xuyên kẹt trong lệnh CDP dài
(timeout 15s) nên wait() quá giờ là chuyện thường; QThread (không có
parent) mất tham chiếu Python cuối trong lúc còn chạy → Qt huỷ C++
QThread giữa chừng → "QThread: Destroyed while thread '' is still
running" → tiến trình chết. Hoàn tất quét gọi ``_restart_live_worker``
nên bấm Quét kênh là sập.

Các test ở đây khoá chặt hành vi mới:
- Quét (qua ĐÚNG handler của nút) trong lúc worker cũ đang kẹt trong
  một lệnh CDP: worker cũ phải vào danh sách "đang nghỉ hưu", sống sót
  qua gc.collect(), và được dọn sạch khi finished thật sự.
- JobEngine giữ việc trong kho nội bộ: thả mọi tham chiếu ngoài tới
  một việc đang chạy, việc vẫn hoàn thành.
- FuncWorker của panel Kiểm tra (đường dự phòng) được dọn (reap) sau
  khi finished — không giữ tham chiếu xác chết, không mất chủ.
"""

import base64
import gc
import os
import threading
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

pytest.importorskip("PySide6")

from PySide6.QtWidgets import QApplication  # noqa: E402

from app import config  # noqa: E402
from app.chrome_manager import ChromeManager  # noqa: E402
from app.job_engine import JobEngine  # noqa: E402
from app.store import Store  # noqa: E402
from app.ui.main_window import MainWindow  # noqa: E402

# JPEG 1x1 hợp lệ cho khung hình giả của client CDP.
_TINY_JPEG_B64 = base64.b64encode(
    bytes.fromhex(
        "ffd8ffe000104a46494600010100000100010000ffdb004300"
        "080606070605080707070909080a0c140d0c0b0b0c1912130f"
        "141d1a1f1e1d1a1c1c20242e2720222c231c1c2837292c3031"
        "3434341f27393d38323c2e333432ffc0001108000100010301"
        "2200021101031101ffc4001500010100000000000000000000"
        "00000000000affc40014100100000000000000000000000000"
        "0000000000000000ffc4001411010000000000000000000000"
        "000000000000000000ffc40014100100000000000000000000"
        "0000000000000000ffc4001411010000000000000000000000"
        "000000000000000000ffda0008010100003f00fb d2 8a280003ffd9".replace(" ", "")
    )
).decode()


class _GatedClient:
    """Client CDP giả: ``Page.captureScreenshot`` CHẶN tới khi cổng
    (threading.Event) được mở — mô phỏng lệnh CDP dài trên Windows
    thật khiến wait() của bản cũ quá giờ."""

    def __init__(self, gate: threading.Event, entered: threading.Event):
        self._gate = gate
        self._entered = entered

    def call(self, method, params=None):
        if method == "Page.captureScreenshot":
            self._entered.set()
            self._gate.wait(timeout=20)
            return {"data": _TINY_JPEG_B64}
        return {}

    def evaluate(self, _expression):
        return "https://www.youtube.com/"

    def bring_to_front(self):
        pass

    def close(self):
        pass


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    yield app


def _pump_until(app, predicate, timeout=25.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        app.processEvents()
        if predicate():
            return True
        time.sleep(0.03)
    app.processEvents()
    return predicate()


@pytest.fixture()
def window(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    settings = config.load_settings()
    store = Store(config.db_path())
    profile = store.add_profile("AwakeInTheDark", "23shinryujin@gmail.com")
    manager = ChromeManager()
    manager.is_running = lambda _profile: False  # hermetic: không có Chrome
    win = MainWindow(store, manager, settings)
    yield win, store, profile, manager
    win.close()
    store.close()


def test_scan_restart_with_blocked_live_worker_survives_gc(
    window, monkeypatch, qapp, capfd
):
    win, _store, profile, manager = window
    gate = threading.Event()      # đóng: mọi capture đều kẹt
    entered = threading.Event()   # worker A đã vào trong capture
    clients = []

    def fake_connect_page(_profile):
        client = _GatedClient(gate, entered)
        clients.append(client)
        return client

    manager.connect_page = fake_connect_page

    scan_calls = []

    def fake_scan(store, prof, mgr, log=None):
        scan_calls.append(prof["id"])
        return {"status": "ok", "channels": [], "message": "Đã quét (giả)."}

    monkeypatch.setattr("app.scanner.scan_profile", fake_scan)

    # 1) Chọn hồ sơ -> worker luồng trực tiếp A khởi động và kẹt trong
    #    lệnh chụp khung hình (đúng trạng thái trên máy Windows thật).
    win._on_card_clicked(profile["id"])
    worker_a = win._live_worker
    assert worker_a is not None
    assert _pump_until(qapp, entered.is_set, timeout=10)
    assert worker_a.isRunning()

    # 2) Bấm ĐÚNG nút "Quét kênh": quét (stub) xong -> handler hoàn tất
    #    -> restart live worker -> dừng A trong lúc A còn kẹt.
    win.btn_scan.click()
    assert _pump_until(
        qapp,
        lambda: profile["id"] not in win._scan_inflight
        and win._live_worker is not None
        and win._live_worker is not worker_a,
        timeout=25,
    )
    assert scan_calls == [profile["id"]]
    worker_b = win._live_worker

    # 3) A chưa chạy xong (cổng còn đóng) nhưng KHÔNG được mất chủ:
    #    nó phải nằm trong danh sách giữ tham chiếu "đang nghỉ hưu".
    assert worker_a.isRunning()
    assert worker_a in win._retiring_live_workers

    # 4) Thu gom rác quyết liệt — bản cũ chết ngay tại đây trên Windows
    #    ("QThread: Destroyed while thread '' is still running").
    gc.collect()
    assert worker_a.isRunning()
    assert worker_a in win._retiring_live_workers

    # 5) Kết quả quét đã được áp dụng hết: hết trạng thái đang quét,
    #    nút quét bật lại.
    assert win._scan_inflight == set()
    assert win.btn_scan.isEnabled()

    # 6) Mở cổng: A thoát vòng lặp, finished về -> reaper dọn sạch.
    gate.set()
    assert _pump_until(
        qapp, lambda: win._retiring_live_workers == [], timeout=15
    )
    assert not worker_a.isRunning()
    assert worker_b is win._live_worker

    # stderr sạch: không cảnh báo QThread / font / DPI nào lọt ra.
    err = capfd.readouterr().err
    assert "QThread" not in err
    assert "setPointSize" not in err
    assert "DpiAwareness" not in err


def test_job_engine_survives_dropped_job_reference():
    events: list[str] = []
    engine = JobEngine(
        num_workers=1,
        on_event=lambda job, event: events.append(event),
        sleep=lambda _s: None,
    )
    gate = threading.Event()

    def fn(_token):
        gate.wait(timeout=10)
        return {"ok": True}

    job = engine.submit(fn, kind="scan")
    job_id = job.id
    # Thả MỌI tham chiếu ngoài tới việc đang chạy + ép thu gom rác:
    # engine phải tự giữ việc trong kho nội bộ cho tới khi xong.
    del job
    gc.collect()
    gate.set()

    deadline = time.time() + 10
    fetched = None
    while time.time() < deadline:
        fetched = engine.get(job_id)
        if fetched is not None and fetched.status == "done":
            break
        time.sleep(0.02)
    engine.shutdown()
    assert fetched is not None
    assert fetched.status == "done"
    assert fetched.result == {"ok": True}
    assert "finished" in events


def test_checks_panel_funcworker_reaped_after_finish(tmp_path, monkeypatch, qapp):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.checks_panel import ChecksPanel

    store = Store(config.db_path())
    profile = store.add_profile("KenhTest", "a@b.c")
    manager = ChromeManager()

    def fake_checks(store_, prof, mgr):
        return {"summary": "Ổn (giả)", "items": [], "profile_id": prof["id"]}

    monkeypatch.setattr("app.checks.run_profile_checks", fake_checks)
    notes: list[str] = []
    # submit_custom=None -> đường dự phòng FuncWorker.
    panel = ChecksPanel(store, config.db_path(), manager, notify=notes.append)
    panel._run_one(profile["id"])
    assert panel._worker is not None
    assert _pump_until(qapp, lambda: panel._worker is None, timeout=15)
    assert any("Kiểm tra xong" in note for note in notes)
    panel.deleteLater()
    store.close()
