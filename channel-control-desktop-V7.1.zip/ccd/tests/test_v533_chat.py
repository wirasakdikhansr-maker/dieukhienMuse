"""V5.3.3 — ô nhập theo ảnh duyệt chat_redesign_v3 + diệt viền
trắng mờ + sát đáy 1px + sửa lệch 28px chiều cao luồng kéo tay.

- V1: dải ô nhập CAO CỐ ĐỊNH (theme.chat_composer_height từ
  line-height thật), chữ CĂN GIỮA THEO CHIỀU CAO khi nội dung
  ngắn (đo thật theo block layout của ô nhập THẬT), gõ nhiều
  dòng → chiều cao không đổi + thanh cuộn xuất hiện + cuộn tới
  được dòng cuối; Enter gửi qua đường phím thật (QTest).
- V2: đường chat KHÔNG còn khung native/hộp viền: ô nhập
  NoFrame ở mức C++ (bản cũ StyledPanel chìm — widget duy nhất
  còn khung trên đường chat), nút thu/mở + nút ✕ chip phẳng
  (bỏ "ghost"), huy hiệu chưa đọc bỏ viền/nền; pixel cạnh nút
  thu/mở KHÔNG còn màu viền (bản cũ sơn đúng #262B33).
- V3: mép dưới khối chat cách viền dưới panel Văn phòng đúng
  1px (margin layout + đo hình học thật); tab Tài khoản tương
  tự cho thẻ chat.
- V4 (hồi quy full-suite V5.3.2): kịch bản splitter của
  test_v531 chạy trong môi trường CÓ APP_QSS trên QApplication
  (điều kiện full suite — MainWindow của các test trước áp
  theme lên qApp). Bản cũ: lưu 160 → khôi phục 132 (lệch 28 >
  dung sai 24). Nguyên nhân đã chẩn đoán bằng probe: (a) dải ô
  nhập không trần chiều cao nên phần cao thừa khi kéo đọng vào
  dải (150 → 292px) thay vì luồng; (b) khôi phục đo phần cố
  định bằng hiệu số hình học thoáng qua lúc layout chưa yên
  (170 thay vì 198). Sửa ở gốc: dải nhập cao cố định (V1) +
  fixed_chrome_height() đo bằng sizeHint + xả LayoutRequest
  đồng bộ khi đổi dải/lưu. Test này ghim: số LƯU = chiều cao
  luồng THẬT sau kéo, khôi phục chênh ≤ 6px.
"""

from __future__ import annotations

import pytest
from PySide6.QtCore import QPoint, Qt
from PySide6.QtWidgets import QAbstractScrollArea, QFrame

from app import config
from app.store import Store
from app.ui import theme


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


@pytest.fixture()
def store(tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    instance = Store(config.db_path())
    yield instance
    instance.close()


def _spin(qapp):
    qapp.processEvents()
    qapp.processEvents()


def _chat(qapp, store, collapsible=True):
    from app.ui.agent_chat import AgentChatWidget

    chat = AgentChatWidget(store, collapsible=collapsible)
    chat.resize(460, 700)
    chat.show()
    _spin(qapp)
    return chat


def _seeded(qapp, store, collapsible=True):
    chat = _chat(qapp, store, collapsible=collapsible)
    agent = store.create_agent("KenhChinh", "lokn38666@gmail.com")
    store.add_message(agent["id"], "agent", "Tin của Muse")
    store.add_message(agent["id"], "user", "Tin của người dùng")
    chat.set_agent(store.get_agent(agent["id"]))
    if collapsible:
        chat.expand_chat()
    _spin(qapp)
    return chat, agent


def _office(qapp, store, settings):
    from app.ui.office_view import OfficeView

    view = OfficeView(store, settings)
    view.resize(1600, 900)
    view.show()
    _spin(qapp)
    return view


# ---------------------------------------------------------------------- #
# V1 — ô nhập cao cố định, căn giữa chiều cao, cuộn khi tràn
# ---------------------------------------------------------------------- #
def test_composer_strip_fixed_height_from_theme(qapp, store):
    chat, _agent = _seeded(qapp, store)
    expected = theme.chat_composer_height(chat.font())
    strip = chat.composer_strip
    assert strip.minimumHeight() == expected
    assert strip.maximumHeight() == expected
    assert strip.height() == expected
    composer_height = chat.composer.height()
    # Gõ 6 dòng: cả dải lẫn ô soạn KHÔNG đổi chiều cao.
    chat.composer.setPlainText("\n".join(f"Dòng {i}" for i in range(6)))
    _spin(qapp)
    assert strip.height() == expected
    assert chat.composer.height() == composer_height
    chat.close()


def _first_block_center_offset(chat) -> float:
    """Độ lệch (px) giữa tâm dòng chữ đầu tiên và tâm chiều cao
    của ô soạn, đo trên layout tài liệu THẬT của ô nhập."""
    composer = chat.composer
    document = composer.document()
    rect = document.documentLayout().blockBoundingRect(
        document.findBlockByNumber(0)
    )
    top = (
        composer.viewportMargins().top()
        + rect.y()
        - composer.verticalScrollBar().value()
    )
    center = top + rect.height() / 2
    return center - composer.height() / 2


def test_composer_text_vertically_centered_when_short(qapp, store):
    chat, _agent = _seeded(qapp, store)
    # Trống (placeholder): lề trên viewport > 0 — chữ được đẩy
    # xuống giữa ô thay vì dính mép trên.
    assert chat.composer.viewportMargins().top() > 0
    chat.composer.setPlainText("Đóng lệnh đó luôn đi")
    _spin(qapp)
    assert abs(_first_block_center_offset(chat)) <= 3
    chat.close()


def test_composer_scrolls_and_reaches_last_line_when_long(qapp, store):
    from PySide6.QtGui import QTextCursor

    chat, _agent = _seeded(qapp, store)
    chat.composer.setPlainText(
        "\n".join(f"Dòng nội dung số {i}" for i in range(6))
    )
    _spin(qapp)
    composer = chat.composer
    # Nội dung tràn: lề căn giữa rút về 0, thanh cuộn có việc.
    assert composer.viewportMargins().top() == 0
    bar = composer.verticalScrollBar()
    assert bar.maximum() > 0
    # Cuộn tới dòng cuối bằng ĐƯỜNG TƯƠNG TÁC THẬT của Qt (đặt
    # con trỏ ở cuối văn bản + ensureCursorVisible): con trỏ
    # cuối phải nằm TRONG viewport. (Đo blockBoundingRect của
    # block cuối không dùng được — layout văn bản thuần chưa
    # bố cục block ngoài vùng nhìn, rect trả y=0.)
    cursor = composer.textCursor()
    cursor.movePosition(QTextCursor.MoveOperation.End)
    composer.setTextCursor(cursor)
    composer.ensureCursorVisible()
    _spin(qapp)
    rect = composer.cursorRect()
    assert rect.top() >= 0
    assert rect.bottom() <= composer.viewport().height() + 1
    chat.close()


def test_composer_typing_and_enter_sends(qapp, store):
    from PySide6.QtTest import QTest

    chat, agent = _seeded(qapp, store)
    chat.composer.setFocus()
    QTest.keyClicks(chat.composer, "Chao Muse")
    assert chat.composer.toPlainText() == "Chao Muse"
    QTest.keyClick(chat.composer, Qt.Key.Key_Return)
    _spin(qapp)
    bodies = [
        m["body"] for m in store.list_messages(agent["id"])
        if m["direction"] == "user"
    ]
    assert bodies[-1] == "Chao Muse"
    assert chat.composer.toPlainText() == ""
    chat.close()


def test_composer_placeholder_short_and_keys_in_tooltip(qapp, store):
    chat, _agent = _seeded(qapp, store)
    assert chat.composer.placeholderText() == "Nhắn cho Muse…"
    tooltip = chat.composer.toolTip()
    assert "Enter" in tooltip and "Shift+Enter" in tooltip
    chat.close()


# ---------------------------------------------------------------------- #
# V2 — không khung native, không hộp viền trên đường chat
# ---------------------------------------------------------------------- #
def test_composer_has_no_native_frame(qapp, store):
    chat, _agent = _seeded(qapp, store)
    # QPlainTextEdit mặc định StyledPanel chìm — nguồn viền
    # native quanh ô nhập trên Windows (V5.3.2 bị chụp).
    assert chat.composer.frameShape() == QFrame.Shape.NoFrame
    chat.close()


def test_chat_scroll_areas_have_no_frame(qapp, store):
    chat, _agent = _seeded(qapp, store)
    areas = chat.findChildren(QAbstractScrollArea)
    assert areas  # ít nhất luồng tin + chính ô soạn
    for area in areas:
        assert area.frameShape() == QFrame.Shape.NoFrame, (
            type(area).__name__
        )
    chat.close()


def test_only_designed_frames_exist_in_chat(qapp, store):
    chat, _agent = _seeded(qapp, store)
    chat.set_context_command("abc123")
    _spin(qapp)
    exact_frames = [
        w for w in chat.findChildren(QFrame) if type(w) is QFrame
    ]
    # §20: QLabel KẾ THỪA QFrame nên phải ghim type ĐÚNG QFrame.
    # Hai frame thiết kế duy nhất: dải ô nhập (border:none) và
    # thẻ chip ngữ cảnh (thẻ điều khiển, giữ nguyên thiết kế).
    assert set(exact_frames) == {chat.composer_strip, chat.chip_row}
    sheet = chat.composer_strip.styleSheet().replace(" ", "")
    assert "border:none" in sheet
    chat.close()


def test_header_controls_are_flat(qapp, store):
    chat, _agent = _seeded(qapp, store)
    # Nút thu/mở: bỏ variant "ghost" (viền 1px BORDER), style
    # riêng khẳng định border: none.
    assert chat.expand_button.property("variant") is None
    sheet = chat.expand_button.styleSheet().replace(" ", "")
    assert "border:none" in sheet
    # Huy hiệu chưa đọc/đang chờ: KHÔNG còn border trong style.
    chat.set_pending_question("cmd-1")
    _spin(qapp)
    assert chat.unread_badge.isVisible()
    assert "border" not in chat.unread_badge.styleSheet()
    chat.close()


def test_expand_button_edges_paint_no_border_color(qapp, store):
    qapp.setStyleSheet(theme.APP_QSS)
    try:
        chat, _agent = _seeded(qapp, store)
        image = chat.grab().toImage()
        button = chat.expand_button
        top_left = button.mapTo(chat, QPoint(0, 0))
        from PySide6.QtGui import QColor

        border = QColor(theme.BORDER)
        probes = [
            QPoint(top_left.x() + button.width() // 2, top_left.y()),
            QPoint(top_left.x(), top_left.y() + button.height() // 2),
        ]
        for point in probes:
            pixel = QColor(image.pixel(point))
            assert (pixel.red(), pixel.green(), pixel.blue()) != (
                border.red(), border.green(), border.blue()
            ), f"cạnh nút thu/mở vẫn sơn màu viền tại {point}"
    finally:
        qapp.setStyleSheet("")
    chat.close()


# ---------------------------------------------------------------------- #
# V3 — sát đáy 1px
# ---------------------------------------------------------------------- #
def _bottom_gap(inner, outer) -> int:
    top = inner.mapTo(outer, QPoint(0, 0)).y()
    return outer.height() - (top + inner.height())


def test_office_chat_flush_to_panel_bottom(qapp, store):
    settings = {}
    view = _office(qapp, store, settings)
    panel = view.detail_panel
    margins = panel.layout().contentsMargins()
    assert margins.bottom() == 1
    # Thu gọn: đáy khối chat (đáy splitter) cách viền dưới 1px.
    assert _bottom_gap(view.chat_widget, panel) == 1
    agent = store.create_agent("Claude A", "ca@example.ai")
    store.add_message(agent["id"], "agent", "Tin cần đọc")
    view.chat_widget.set_agent(store.get_agent(agent["id"]))
    view.chat_widget.expand_chat()
    _spin(qapp)
    assert _bottom_gap(view.chat_widget, panel) == 1
    view.close()


def test_agents_chat_flush_to_bottom(qapp, store):
    from app.ui.agents_panel import AgentsPanel

    panel = AgentsPanel(store, settings={})
    panel.resize(1200, 800)
    panel.show()
    _spin(qapp)
    assert panel.layout().contentsMargins().bottom() == 1
    assert _bottom_gap(panel.chat_widget, panel) == 1
    panel.close()


# ---------------------------------------------------------------------- #
# V4 — hồi quy lệch 28px trong môi trường full-suite (có APP_QSS)
# ---------------------------------------------------------------------- #
def test_splitter_restore_exact_with_app_qss(qapp, store):
    qapp.setStyleSheet(theme.APP_QSS)
    try:
        settings = {}
        view = _office(qapp, store, settings)
        agent = store.create_agent("Claude A", "ca@example.ai")
        store.add_message(agent["id"], "agent", "Tin cần đọc")
        chat = view.chat_widget
        chat.set_agent(store.get_agent(agent["id"]))
        chat.expand_chat()
        _spin(qapp)
        assert chat.is_expanded
        view.panel_splitter.setSizes([300, 500])
        _spin(qapp)
        view._on_panel_splitter_moved(0, 1)
        view._save_chat_thread_height()
        saved = settings.get("office_chat_thread_height")
        assert saved is not None and 100 <= saved <= 420
        assert chat.user_thread_height() == saved
        # Số đã LƯU phải là chiều cao luồng THẬT sau cú kéo
        # (bản cũ lưu 160 — số bị kẹp trần mặc định — trong khi
        # luồng thật đã được kéo lên ~386 ở khổ này).
        _spin(qapp)
        assert abs(chat.scroll.height() - saved) <= 6, (
            chat.scroll.height(), saved
        )
        chat.toggle_expand()
        _spin(qapp)
        assert not chat.is_expanded
        chat.toggle_expand()
        _spin(qapp)
        assert chat.is_expanded
        # Khôi phục: bản cũ hụt đúng 28px (132 vs 160) ở đúng
        # môi trường này; nay phải khớp gần như tuyệt đối.
        assert abs(chat.scroll.height() - saved) <= 6, (
            chat.scroll.height(), saved
        )
        view.close()
    finally:
        qapp.setStyleSheet("")
