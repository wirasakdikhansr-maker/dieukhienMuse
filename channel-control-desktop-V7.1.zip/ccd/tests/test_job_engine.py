"""Kiểm thử V3.1 cho bộ máy hàng đợi việc (app.job_engine) bằng hàm giả:
tuần tự theo hồ sơ, song song khác hồ sơ, ưu tiên, huỷ, thử lại."""

import threading
import time

from app.job_engine import (
    PRIORITY_AUTO,
    PRIORITY_MANUAL,
    JobCancelled,
    JobEngine,
    TransientJobError,
)


def _engine(**kwargs):
    kwargs.setdefault("sleep", lambda _s: None)  # backoff không chờ thật
    return JobEngine(**kwargs)


def _wait_status(engine, job, status, timeout=5.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if job.status == status:
            return True
        time.sleep(0.01)
    return job.status == status


def test_same_profile_jobs_never_run_concurrently():
    engine = _engine(num_workers=3)
    order = []
    lock = threading.Lock()
    running_now = 0
    max_running = 0

    def make(name):
        def fn(_token):
            nonlocal running_now, max_running
            with lock:
                running_now += 1
                max_running = max(max_running, running_now)
            time.sleep(0.05)
            with lock:
                running_now -= 1
                order.append(name)
            return name

        return fn

    j1 = engine.submit(make("a"), profile_id=7)
    j2 = engine.submit(make("b"), profile_id=7)
    assert _wait_status(engine, j1, "done")
    assert _wait_status(engine, j2, "done")
    assert max_running == 1  # cùng hồ sơ: không bao giờ chồng nhau
    assert order == ["a", "b"]  # FIFO trong cùng hồ sơ + ưu tiên
    engine.shutdown()


def test_different_profiles_can_run_in_parallel():
    engine = _engine(num_workers=2)
    started = threading.Event()
    release = threading.Event()

    def blocker(_token):
        started.set()
        release.wait(timeout=5)
        return "blocked-done"

    def quick(_token):
        return "quick-done"

    j1 = engine.submit(blocker, profile_id=1)
    j2 = engine.submit(quick, profile_id=2)
    assert started.wait(timeout=5)
    # Hồ sơ 2 không bị khoá bởi hồ sơ 1.
    assert _wait_status(engine, j2, "done")
    release.set()
    assert _wait_status(engine, j1, "done")
    engine.shutdown()


def test_manual_priority_beats_auto_when_busy():
    engine = _engine(num_workers=1)
    gate = threading.Event()
    order = []

    def first(_token):
        gate.wait(timeout=5)
        order.append("first")
        return 1

    def auto(_token):
        order.append("auto")
        return 2

    def manual(_token):
        order.append("manual")
        return 3

    j0 = engine.submit(first, profile_id=None, priority=PRIORITY_MANUAL)
    ja = engine.submit(auto, profile_id=None, priority=PRIORITY_AUTO)
    jm = engine.submit(manual, profile_id=None, priority=PRIORITY_MANUAL)
    gate.set()
    assert _wait_status(engine, j0, "done")
    assert _wait_status(engine, ja, "done")
    assert _wait_status(engine, jm, "done")
    # Worker duy nhất bận với 'first' -> hàng chờ xử lý manual trước auto.
    assert order == ["first", "manual", "auto"]
    engine.shutdown()


def test_cancel_queued_job_never_runs():
    engine = _engine(num_workers=1)
    gate = threading.Event()
    ran = []

    def blocker(_token):
        gate.wait(timeout=5)
        return "b"

    def queued(_token):
        ran.append(True)
        return "q"

    j1 = engine.submit(blocker)
    j2 = engine.submit(queued)
    assert engine.cancel(j2.id) is True
    assert j2.status == "cancelled"
    gate.set()
    assert _wait_status(engine, j1, "done")
    time.sleep(0.1)
    assert ran == []  # việc đã huỷ không bao giờ chạy
    engine.shutdown()


def test_cancel_running_job_via_token():
    engine = _engine(num_workers=1)

    def loop(token):
        for _ in range(200):
            token.raise_if_cancelled()
            time.sleep(0.01)
        return "finished-anyway"

    job = engine.submit(loop)
    # Chờ việc thật sự bắt đầu rồi mới huỷ.
    deadline = time.time() + 5
    while job.status != "running" and time.time() < deadline:
        time.sleep(0.01)
    assert job.status == "running"
    assert engine.cancel(job.id) is True
    assert _wait_status(engine, job, "cancelled")
    engine.shutdown()


def test_transient_error_retried_with_backoff():
    engine = _engine(num_workers=1)
    attempts = {"n": 0}

    def flaky(_token):
        attempts["n"] += 1
        if attempts["n"] < 3:
            raise TransientJobError("CDP socket rớt")
        return "ok-sau-3-lan"

    job = engine.submit(flaky, max_retries=2)
    assert _wait_status(engine, job, "done")
    assert job.result == "ok-sau-3-lan"
    assert attempts["n"] == 3
    engine.shutdown()


def test_transient_error_exhausts_retries():
    engine = _engine(num_workers=1)

    def always_down(_token):
        raise TransientJobError("websocket đóng")

    job = engine.submit(always_down, max_retries=2)
    assert _wait_status(engine, job, "failed")
    assert job.attempts == 3  # 1 lần đầu + 2 lần thử lại
    assert "websocket" in (job.error or "")
    engine.shutdown()


def test_normal_error_not_retried():
    engine = _engine(num_workers=1)
    attempts = {"n": 0}

    def bad(_token):
        attempts["n"] += 1
        raise ValueError("lỗi logic")

    job = engine.submit(bad, max_retries=2)
    assert _wait_status(engine, job, "failed")
    assert attempts["n"] == 1
    engine.shutdown()


def test_job_cancelled_exception_marks_cancelled():
    engine = _engine(num_workers=1)

    def self_cancel(_token):
        raise JobCancelled("dừng")

    job = engine.submit(self_cancel)
    assert _wait_status(engine, job, "cancelled")
    engine.shutdown()
