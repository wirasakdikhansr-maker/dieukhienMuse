"""Kiểm thử V3.3 — tài khoản Muse (agents): Store (migration v4,
thêm lẻ/hàng loạt, phân công 1 Muse–nhiều hồ sơ, heartbeat/trạng
thái, thu hồi), Agent API (auth theo token riêng từng Muse, lọc lệnh
theo phân công, chống giẫm chân) và khói giao diện panel agents."""

import json
from datetime import datetime, timedelta

import pytest

from app.agent_server import AgentServer
from app.store import Store, agent_status
from app import config


# --------------------------------------------------------------------- #
# Store
# --------------------------------------------------------------------- #
def test_store_agents_crud_bulk_assign_heartbeat(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    assert store.schema_version >= 4  # v4 = agents; V3.4 nâng tiếp lên 5
    p1 = store.add_profile("Hồ sơ 1", "a@gmail.com")
    p2 = store.add_profile("Hồ sơ 2", "b@gmail.com")
    p3 = store.add_profile("Hồ sơ 3", "c@gmail.com")

    agent = store.create_agent("Muse Nhạc", "Nhac@Example.ai")
    assert agent["email"] == "nhac@example.ai"  # chuẩn hoá chữ thường
    assert agent["token"]
    assert agent["status"] == "offline"
    with pytest.raises(ValueError):
        store.create_agent("Trùng", "nhac@example.ai")

    results = store.bulk_create_agents(
        [
            {"name": "Muse Phim", "email": "phim@example.ai"},
            {"name": "Trùng nữa", "email": "PHIM@example.ai"},
            {"name": "Hỏng", "email": "khong-phai-email"},
        ]
    )
    assert [r["status"] for r in results] == ["created", "duplicate", "error"]
    phim = results[0]["agent"]

    # Phân công: Muse Nhạc ôm 2 hồ sơ; chuyển p2 sang Muse Phim.
    store.assign_profiles(agent["id"], [p1["id"], p2["id"]])
    assert store.agent_for_profile(p2["id"])["id"] == agent["id"]
    store.assign_profiles(phim["id"], [p2["id"], p3["id"]])
    assert store.agent_for_profile(p2["id"])["id"] == phim["id"]
    assert store.profiles_for_agent(agent["id"]) == [p1["id"]]
    assert store.profiles_for_agent(phim["id"]) == [p2["id"], p3["id"]]

    # Heartbeat + trạng thái sống.
    store.touch_agent_heartbeat(agent["id"], "cmd-abc")
    me = store.get_agent(agent["id"])
    assert me["status"] == "online"
    assert me["current_command_id"] == "cmd-abc"
    old = (datetime.now().astimezone() - timedelta(minutes=30)).isoformat(timespec="seconds")
    assert agent_status(old) == "offline"
    recent = (datetime.now().astimezone() - timedelta(minutes=5)).isoformat(timespec="seconds")
    assert agent_status(recent) == "idle"
    assert agent_status(recent, revoked=True) == "revoked"

    # Token: xác thực đúng/sai; cấp lại làm token cũ hết hiệu lực; thu hồi chặn hẳn.
    assert store.authenticate_agent(agent["id"], agent["token"]) is not None
    assert store.authenticate_agent(agent["id"], "sai-token") is None
    renewed = store.regenerate_agent_token(agent["id"])
    assert renewed["token"] != agent["token"]
    assert store.authenticate_agent(agent["id"], agent["token"]) is None
    assert store.authenticate_agent(agent["id"], renewed["token"]) is not None
    store.set_agent_revoked(agent["id"], True)
    assert store.authenticate_agent(agent["id"], renewed["token"]) is None
    store.close()


def test_store_agent_command_scope(tmp_path):
    store = Store(tmp_path / "t.sqlite3")
    p1 = store.add_profile("Hồ sơ 1", "a@gmail.com")
    p2 = store.add_profile("Hồ sơ 2", "b@gmail.com")
    a1 = store.create_agent("Muse 1", "m1@example.ai")
    a2 = store.create_agent("Muse 2", "m2@example.ai")
    store.assign_profiles(a1["id"], [p1["id"]])
    store.assign_profiles(a2["id"], [p2["id"]])
    c1 = store.create_command("optimize", source="ui", profile_id=p1["id"], status="waiting_muse")
    c2 = store.create_command("optimize", source="ui", profile_id=p2["id"], status="waiting_muse")
    assert [c["id"] for c in store.list_commands_for_agent(a1["id"])] == [c1["id"]]
    assert store.agent_can_access_command(a1["id"], c1)
    assert not store.agent_can_access_command(a1["id"], c2)
    store.close()


# --------------------------------------------------------------------- #
# Agent API
# --------------------------------------------------------------------- #
class FakeManager:
    def is_running(self, profile):
        return True

    def launch(self, profile):
        return "launched"

    def connect_page(self, profile):
        raise NotImplementedError


@pytest.fixture()
def api(tmp_path, monkeypatch):
    data_dir = tmp_path / "data"
    data_dir.mkdir()
    monkeypatch.setenv("CCD_DATA_DIR", str(data_dir))
    seed = Store(config.db_path(data_dir))
    p1 = seed.add_profile("Kenh Mot", "mot@gmail.com")
    p2 = seed.add_profile("Kenh Hai", "hai@gmail.com")
    a1 = seed.create_agent("Muse Một", "m1@example.ai")
    a2 = seed.create_agent("Muse Hai", "m2@example.ai")
    seed.assign_profiles(a1["id"], [p1["id"]])
    seed.assign_profiles(a2["id"], [p2["id"]])
    cmd = seed.create_command(
        "optimize", source="ui", profile_id=p1["id"], status="waiting_muse",
        instruction="tối ưu kênh 1",
    )
    other = seed.create_command(
        "optimize", source="ui", profile_id=p2["id"], status="waiting_muse",
        instruction="tối ưu kênh 2",
    )
    seed.close()
    server = AgentServer(data_dir=data_dir, settings={}, manager=FakeManager(), scan_fn=None)
    return {
        "server": server, "a1": a1, "a2": a2, "p1": p1, "p2": p2,
        "cmd": cmd, "other": other,
    }


def call(api, method, path, payload=None, headers=None, use_admin=True):
    hdrs = {}
    if use_admin:
        hdrs["X-Agent-Token"] = api["server"].token
    if headers:
        hdrs.update(headers)
    body = json.dumps(payload).encode("utf-8") if payload is not None else b""
    return api["server"].dispatch(method, path, hdrs, body)


def agent_headers(agent):
    return {"X-Agent-Id": str(agent["id"]), "X-Agent-Token": agent["token"]}


def test_api_agents_admin_flow_and_bulk(api):
    status, payload = call(api, "POST", "/api/agents", {"name": "Muse Ba", "email": "m3@example.ai"})
    assert status == 201 and payload["agent"]["token"]
    status, payload = call(api, "POST", "/api/agents", {"name": "Trùng", "email": "M3@example.ai"})
    assert status == 409
    status, payload = call(
        api, "POST", "/api/agents/bulk",
        {"agents": [{"name": "Muse Bốn", "email": "m4@example.ai"},
                    {"name": "Trùng", "email": "m1@example.ai"},
                    {"name": "Hỏng", "email": "sai"}]},
    )
    assert status == 200 and payload["created"] == 1
    assert [r["status"] for r in payload["results"]] == ["created", "duplicate", "error"]
    status, payload = call(api, "GET", "/api/agents")
    assert status == 200 and len(payload["agents"]) == 4
    m3 = next(a for a in payload["agents"] if a["email"] == "m3@example.ai")
    status, payload = call(
        api, "POST", f"/api/agents/{m3['id']}/assignments",
        {"profile_ids": [api["p1"]["id"], api["p2"]["id"]]},
    )
    assert status == 200
    assert payload["agent"]["profile_ids"] == [api["p1"]["id"], api["p2"]["id"]]


def test_api_agent_identity_scoping_and_antihijack(api):
    a1, a2 = api["a1"], api["a2"]
    # Muse 1 chỉ thấy lệnh của hồ sơ mình phụ trách.
    status, payload = call(api, "GET", "/api/commands", headers=agent_headers(a1), use_admin=False)
    assert status == 200
    assert [c["id"] for c in payload["commands"]] == [api["cmd"]["id"]]
    # Muse 2 báo tiến độ lệnh của Muse 1 -> 403 (chống giẫm chân).
    status, _ = call(
        api, "POST", f"/api/commands/{api['cmd']['id']}/progress",
        {"progress": 10, "step": "đang làm"}, headers=agent_headers(a2), use_admin=False,
    )
    assert status == 403
    # Muse 1 báo được; lệnh được ghi danh cho Muse 1 + có heartbeat.
    status, payload = call(
        api, "POST", f"/api/commands/{api['cmd']['id']}/progress",
        {"progress": 40, "step": "đang viết mô tả"}, headers=agent_headers(a1), use_admin=False,
    )
    assert status == 200
    assert payload["command"]["agent_id"] == a1["id"]
    assert payload["command"]["progress"] == 40
    # Token sai của agent -> 401; agent gọi endpoint quản trị -> 403.
    bad = {"X-Agent-Id": str(a1["id"]), "X-Agent-Token": "sai"}
    status, _ = call(api, "GET", "/api/commands", headers=bad, use_admin=False)
    assert status == 401
    status, _ = call(api, "POST", "/api/agents", {"name": "X", "email": "x@example.ai"},
                     headers=agent_headers(a1), use_admin=False)
    assert status == 403
    # Heartbeat cho chính mình OK; cho người khác 403.
    status, payload = call(
        api, "POST", f"/api/agents/{a1['id']}/heartbeat",
        {"current_command_id": api["cmd"]["id"]}, headers=agent_headers(a1), use_admin=False,
    )
    assert status == 200 and payload["agent"]["status"] == "online"
    status, _ = call(
        api, "POST", f"/api/agents/{a2['id']}/heartbeat", {},
        headers=agent_headers(a1), use_admin=False,
    )
    assert status == 403
    # Danh sách agents qua mắt agent chỉ có chính mình, không lộ token người khác.
    status, payload = call(api, "GET", "/api/agents", headers=agent_headers(a1), use_admin=False)
    assert status == 200 and len(payload["agents"]) == 1
    assert "token" not in payload["agents"][0]


def test_api_agent_revoke_blocks_auth(api):
    a1 = api["a1"]
    status, _ = call(api, "POST", f"/api/agents/{a1['id']}/revoke", {"revoked": True})
    assert status == 200
    status, _ = call(api, "GET", "/api/commands", headers=agent_headers(a1), use_admin=False)
    assert status == 401


# --------------------------------------------------------------------- #
# UI khói
# --------------------------------------------------------------------- #
import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

pytest.importorskip("PySide6")


@pytest.fixture(scope="module")
def qapp():
    from PySide6.QtWidgets import QApplication

    return QApplication.instance() or QApplication([])


def test_agents_panel_lists_and_bulk_parse(qapp, tmp_path, monkeypatch):
    monkeypatch.setenv("CCD_DATA_DIR", str(tmp_path))
    from app.ui.agents_panel import AgentsPanel, parse_agent_lines

    assert parse_agent_lines("Tên A | a@x.ai\nb@x.ai\n# bỏ qua\nC,c@x.ai\n") == [
        {"name": "Tên A", "email": "a@x.ai"},
        {"name": "", "email": "b@x.ai"},
        {"name": "C", "email": "c@x.ai"},
    ]
    store = Store(tmp_path / "t.sqlite3")
    profile = store.add_profile("Kenh Mot", "mot@gmail.com")
    agent = store.create_agent("Muse Một", "m1@example.ai")
    store.assign_profiles(agent["id"], [profile["id"]])
    panel = AgentsPanel(store)
    panel.refresh()
    assert panel.table.rowCount() == 1
    assert "Muse Một" in panel.table.item(0, 0).text()
    assert "Kenh Mot" in panel.table.item(0, 5).text()
    panel.close()
    store.close()
