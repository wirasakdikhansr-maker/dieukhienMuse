# Phương án CCD V5.3 — TỐC ĐỘ + GỌN (góp ý máy thật 2026-10-30 17:50)

Cơ sở: bản V5.2.1 đã dựng (mục 1) làm nền; vòng này đổi tên thành **V5.3**. Mọi mục đều là lệnh trực tiếp của chủ kênh kèm 6 ảnh chụp máy thật.

## A. Các mục giao diện (lệnh trực tiếp)

1. **[ĐÃ XONG ở bản dựng V5.2.1]** Ô chat panel Văn phòng giảm chiều cao + tự động ẩn/hiện. Giữ nguyên vào V5.3.
2. **Bỏ HẾT label thông báo:** banner hồng "lệnh đang chờ bạn xử lý" (dù dài bao nhiêu chữ), toast bật lên, đoạn chữ hướng dẫn dài dưới form tạo lệnh — thông tin đã có trong Nhật ký. Trạng thái chờ-người vẫn hiện bằng pill/huy hiệu ngắn như cũ.
3. **Hàng cầu nối gộp vào hàng lọc:** nhãn "Cầu nối Muse: …" + nút "Kết nối Muse…" đưa lên CÙNG HÀNG với bộ lọc của danh sách lệnh; toàn bộ nút ở khu vực này cao **24px**.
4. **Xoá 3 nút** Chạy ngay / Xoá lệnh / Làm mới ở tab Công việc (đã có trong menu chuột phải).
5. **Bảng gọn:** chiều cao hàng chỉ đủ chữ, đệm trên/dưới **2px**; cột Kết quả hiện tóm tắt ngắn thay cho đoạn dict thô; bảng nằm trong thẻ nổi, chiều cao vùng bảng kéo chỉnh được qua splitter.
6. **Bỏ mọi label không cần thiết ở TẤT CẢ các tab** (chữ giải thích dài, nhãn trùng lặp) — chỉ giữ nhãn chức năng ngắn. Nguyên tắc chung: nhiều nút/nhãn cùng một hàng để tiết kiệm diện tích.
7. **Trình duyệt khởi động CÙNG tool.** Tường trình duyệt đổi quy cách (LỆNH MỚI NHẤT — thay quy cách cột dọc 15:57 và lưới cũ): ô cố định **600×800px**, tối đa **3 ô/hàng**, thừa tự xuống dòng, cuộn dọc.
8. **Checkbox "Chạy ẩn ngoài app"** (tab Hồ sơ + lưu vào cài đặt): bật → trình duyệt chạy cửa sổ riêng/thu nhỏ ngoài khung nhúng, điều khiển qua CDP, các Muse không tranh nhau bề mặt nhúng; tắt → nhúng trong app như hiện tại (mặc định). Đây là ngoại lệ do chủ kênh trực tiếp ra lệnh, thay cho quy tắc "chỉ nhúng" ở chế độ mặc định.
9. **Hình nền Văn phòng thay đổi được:** mục Giao diện có nút chọn ảnh nền riêng + khôi phục mặc định; ảnh đã chọn lưu trong data và áp cho scene (đường cover-crop hiện có).

## B. Phương án TỐC ĐỘ (phần chủ kênh yêu cầu đề xuất)

**Nguyên nhân thật của "chat chậm" (bằng chứng sống 30/10):** (i) MỘT phiên Muse duy nhất phục vụ cả 7 tài khoản theo thứ tự — khi phiên đó đang chìm trong việc dài (dựng video), tin chat phải xếp hàng chờ dù hook đã đánh thức đúng; (ii) cầu nối PC↔Muse từng mất sóng dài (00:07→07:14 và ~17:23) khiến mọi phản hồi tắc ở đường truyền; (iii) phía app không phải nút thắt: API chat theo từng agent đã sẵn từ V5.0.

**Cách tối ưu:**
- B1. **Tách phiên phục vụ theo từng agent:** mỗi tài khoản Muse một phiên phục vụ riêng; hook định tuyến wake (lệnh + chat) theo đúng agent. 7 luồng chạy song song thật, tốc độ của Muse này không phụ thuộc Muse kia. (Việc phía Muse — không nằm trong file zip; làm song song với V5.3.)
- B2. **Luật ưu tiên chat trong mọi phiên:** tin chat chưa đọc xử lý TRƯỚC việc dài; việc dài phải kiểm tra chat giữa các bước. Trả lời chat NGẮN (kết luận + việc cần chủ kênh làm), chi tiết dài để trong Nhật ký/báo cáo — sửa tình trạng một bong bóng chat dài kín màn hình như ảnh 5.
- B3. **Trong app:** bỏ toast/banner (bớt widget + bớt layout mỗi sự kiện); bảng gọn 2px (ít vùng sơn lại hơn); trình duyệt chạy ẩn (B-mục A8) loại hẳn chi phí nhúng cửa sổ native khỏi tab Hồ sơ khi bật; giữ nguyên toàn bộ cổng vân V5.2 (không regress ngân sách tick < 50ms / chuyển tab < 200ms đo trên fixture).
- B4. **Khởi động:** trình duyệt tự mở cùng tool theo đúng chế độ đã chọn (ẩn → mở thu nhỏ sẵn sàng cho CDP; nhúng → như hiện tại), không bắt chủ kênh mở tay từng hồ sơ.

## C. Kiểm chứng (theo skill ui_code_professional_standard)
Fixture dữ liệu thật (7 agent/20 kênh/200 lệnh) đo lại ngân sách sau khi gỡ label/toast; render app thật mọi tab ở 1920/1460/1100 + tường 600×800 với 2/3/4/7 trình duyệt; test hồi quy cho: không còn toast/banner, nút 24px, 3 nút đã xoá, hàng bảng 2px, nền văn phòng đổi được, checkbox chạy ẩn (đường mở trình duyệt rẽ đúng nhánh bằng CDP giả); cổng giải nén từ zip; full suite do parent chạy độc lập sau giao.

## D. Giới hạn nói thẳng
- Song song 7 phiên phụ thuộc cầu nối Tailscale sống; PC ngủ = mọi phiên chờ như nhau (đã có mẹo Sleep=Never).
- Chế độ chạy ẩn: chủ kênh không nhìn thấy trình duyệt trong app khi đang bật — đánh đổi có chủ đích để lấy tốc độ, tắt checkbox là quay về nhúng.
- Ô tường 600×800 là kích thước HIỂN THỊ của ô; cửa sổ Chrome thật giữ kích thước riêng của nó.
