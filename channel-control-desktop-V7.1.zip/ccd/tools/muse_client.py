#!/usr/bin/env python3
"""Client dòng lệnh cho Muse gọi Agent API (V2) của Channel Control Desktop.

Chỉ dùng thư viện chuẩn (urllib). Ví dụ (máy đích là PC Windows trên cùng
mạng Tailscale với Muse):

    python tools/muse_client.py --base http://win-pc:19500 --token XXX health
    python tools/muse_client.py --base http://100.x.y.z:19500 --token XXX profiles
    python tools/muse_client.py ... open awakeinthedark
    python tools/muse_client.py ... scan awakeinthedark
    python tools/muse_client.py ... channels awakeinthedark
    python tools/muse_client.py ... journal --limit 20
    python tools/muse_client.py ... send-file ./video.mp4
    python tools/muse_client.py ... command scan --profile awakeinthedark
    python tools/muse_client.py ... command cdp_navigate --profile awakeinthedark --url https://studio.youtube.com/
    python tools/muse_client.py ... status <command_id>

Token cũng đọc được từ biến môi trường CCD_AGENT_TOKEN. Mọi output là JSON.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


class Client:
    def __init__(self, base: str, token: str = "", agent_id: str = ""):
        self.base = base.rstrip("/")
        self.token = token
        self.agent_id = agent_id

    def request(self, method: str, path: str, body: bytes | None = None,
                extra_headers: dict | None = None) -> dict:
        headers = {}
        if self.token:
            headers["X-Agent-Token"] = self.token
        if self.agent_id:
            # Gọi với danh tính một tài khoản Muse cụ thể: token lúc này
            # là TOKEN RIÊNG của tài khoản đó (xem phiếu kết nối).
            headers["X-Agent-Id"] = str(self.agent_id)
        if extra_headers:
            headers.update(extra_headers)
        req = urllib.request.Request(
            self.base + path, data=body, method=method, headers=headers
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", errors="replace")
            try:
                payload = json.loads(raw)
            except json.JSONDecodeError:
                payload = {"ok": False, "error": raw}
            payload["_http_status"] = exc.code
            return payload
        except urllib.error.URLError as exc:
            return {"ok": False, "error": f"Không nối được tới {self.base}: {exc.reason}"}


def send_large(client: "Client", file_path: Path, command_id: str = "", chunk_mb: int = 16) -> dict:
    """Gửi file theo khúc: khởi tạo (hoặc lấy lại phiên cũ cùng tên +
    cỡ + sha256), hỏi offset đã nhận, gửi tiếp phần còn lại, rồi chốt."""
    size = file_path.stat().st_size
    digest = hashlib.sha256()
    with open(file_path, "rb") as fh:
        for block in iter(lambda: fh.read(4 * 1024 * 1024), b""):
            digest.update(block)
    sha = digest.hexdigest()
    init = client.request(
        "POST", "/api/files/upload",
        body=json.dumps({"name": file_path.name, "size": size, "sha256": sha,
                         "command_id": command_id or None}).encode("utf-8"),
        extra_headers={"Content-Type": "application/json"},
    )
    if not init.get("ok"):
        return init
    upload = init["upload"]
    uid = upload["id"]
    offset = int(upload.get("received") or 0)
    chunk = max(1, chunk_mb) * 1024 * 1024
    with open(file_path, "rb") as fh:
        fh.seek(offset)
        while offset < size:
            data = fh.read(chunk)
            for attempt in range(5):
                reply = client.request(
                    "PUT", f"/api/files/upload/{uid}?offset={offset}", body=data,
                    extra_headers={"Content-Type": "application/octet-stream"},
                )
                if reply.get("ok"):
                    break
                status = client.request("GET", f"/api/files/upload/{uid}")
                if status.get("ok"):
                    server_offset = int(status["upload"]["received"])
                    if server_offset != offset:
                        offset = server_offset
                        fh.seek(offset)
                        data = fh.read(chunk)
            else:
                return {"ok": False, "error": f"Gửi khúc tại {offset} thất bại 5 lần — chạy lại lệnh để nối tiếp", "upload_id": uid}
            offset += len(data)
            print(f"  {offset * 100 // max(1, size)}% ({offset}/{size})", file=sys.stderr)
    return client.request("POST", f"/api/files/upload/{uid}/complete", body=b"")


def _print(payload: dict) -> int:
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return 0 if payload.get("ok") else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Client cho Agent API của Channel Control Desktop")
    parser.add_argument("--base", default="http://127.0.0.1:19500",
                        help="Địa chỉ app, vd http://<pc-tailscale>:19500")
    parser.add_argument("--token", default=os.environ.get("CCD_AGENT_TOKEN", ""),
                        help="X-Agent-Token (hoặc biến môi trường CCD_AGENT_TOKEN)")
    parser.add_argument("--agent-id", default=os.environ.get("CCD_AGENT_ID", ""),
                        help="Gọi với danh tính tài khoản Muse này (kèm --token là token RIÊNG của nó)")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("health", help="Kiểm tra app còn sống (không cần token)")
    sub.add_parser("profiles", help="Danh sách hồ sơ + kênh + trạng thái phiên")

    p_open = sub.add_parser("open", help="Mở Chrome của một hồ sơ")
    p_open.add_argument("slug")

    p_scan = sub.add_parser("scan", help="Quét kênh của một hồ sơ (đồng bộ)")
    p_scan.add_argument("slug")

    p_channels = sub.add_parser("channels", help="Danh sách kênh của một hồ sơ")
    p_channels.add_argument("slug")

    p_journal = sub.add_parser("journal", help="Đọc nhật ký gần nhất")
    p_journal.add_argument("--limit", type=int, default=50)

    p_send = sub.add_parser("send-file", help="Gửi một file vào inbox của app")
    p_send.add_argument("path")

    # V6.3: file LỚN (hàng GB) — gửi theo khúc, đứt mạng chạy lại là nối tiếp.
    p_big = sub.add_parser("send-large", help="Gửi file lớn theo khúc (nối tiếp được) vào app")
    p_big.add_argument("path")
    p_big.add_argument("--command-id", default="", help="Gắn file vào một lệnh")
    p_big.add_argument("--chunk-mb", type=int, default=16)
    p_fetch = sub.add_parser("fetch-url", help="Bảo app tự TẢI file từ một link (Drive/S3/server Muse)")
    p_fetch.add_argument("url")
    p_fetch.add_argument("--name", default="")
    p_fetch.add_argument("--command-id", default="")
    p_fstat = sub.add_parser("file-status", help="Trạng thái một phiên gửi/tải file lớn")
    p_fstat.add_argument("file_id")
    p_fstat.add_argument("--kind", choices=["upload", "fetch"], default="upload")
    sub.add_parser("rules", help="Đọc bộ quy tắc + chỉ tiêu KPI hiện hành")

    p_cmd = sub.add_parser("command", help="Xếp hàng một lệnh bất đồng bộ")
    p_cmd.add_argument("type", choices=["open_browser", "scan", "cdp_navigate"])
    p_cmd.add_argument("--profile", required=True, help="Slug của hồ sơ")
    p_cmd.add_argument("--url", default="", help="URL cho lệnh cdp_navigate")
    p_cmd.add_argument("--payload", default="", help="JSON payload bổ sung")

    p_status = sub.add_parser("status", help="Trạng thái một lệnh đã xếp hàng")
    p_status.add_argument("command_id")

    p_add = sub.add_parser("add-profile", help="Tạo hồ sơ riêng cho một Gmail mới")
    p_add.add_argument("label")
    p_add.add_argument("gmail")
    p_add.add_argument("--note", default="")

    p_prog = sub.add_parser("progress", help="Báo tiến độ một công việc đang làm (hiện trong app)")
    p_prog.add_argument("command_id")
    p_prog.add_argument("percent", type=int, help="0–100")
    p_prog.add_argument("step", nargs="*", help="Mô tả bước hiện tại")

    p_result = sub.add_parser("result", help="Báo kết quả cuối của một lệnh chờ Muse")
    p_result.add_argument("command_id")
    p_result.add_argument("status", choices=["done", "failed", "running", "waiting_muse", "needs_user"])
    p_result.add_argument("--message", default="")

    # V4.0: claim/release nguyên tử + long-poll danh sách lệnh.
    p_claim = sub.add_parser("claim", help="Nhận (claim) một lệnh chờ Muse — kèm lease")
    p_claim.add_argument("command_id")

    p_release = sub.add_parser("release", help="Trả (release) một lệnh đang giữ lease về hàng chờ")
    p_release.add_argument("command_id")

    p_commands = sub.add_parser("commands", help="Danh sách lệnh (lọc theo trạng thái; --wait = long-poll)")
    p_commands.add_argument("--status", default="", help="vd waiting_muse")
    p_commands.add_argument("--wait", type=int, default=0,
                            help="Long-poll tối đa N giây (0–50) khi chưa có lệnh waiting_muse")

    p_cookies = sub.add_parser("cookies", help="Kho cookies của một hồ sơ")
    p_cookies.add_argument("slug")
    p_cookies.add_argument("action", choices=["status", "import", "apply", "export"])
    p_cookies.add_argument("--file", default="", help="File cookies cho action=import")

    p_agents = sub.add_parser("agents", help="Quản lý tài khoản Muse (V3.3)")
    agents_sub = p_agents.add_subparsers(dest="agents_cmd", required=True)
    agents_sub.add_parser("list", help="Danh sách tài khoản Muse + trạng thái + phân công")
    p_ag_add = agents_sub.add_parser("add", help="Thêm một tài khoản Muse")
    p_ag_add.add_argument("name")
    p_ag_add.add_argument("email")
    p_ag_add.add_argument("--note", default="")
    p_ag_import = agents_sub.add_parser(
        "import", help="Nhập HÀNG LOẠT từ file (mỗi dòng: Tên | email, hoặc email, hoặc CSV tên,email; hoặc JSON)"
    )
    p_ag_import.add_argument("file")
    p_ag_assign = agents_sub.add_parser("assign", help="Phân công hồ sơ cho một Muse (1 Muse nhiều hồ sơ)")
    p_ag_assign.add_argument("agent_id", type=int)
    p_ag_assign.add_argument("--profiles", default="", help="Id hồ sơ cách nhau dấu phẩy, vd 1,2,3 (rỗng = bỏ hết)")
    p_ag_hb = agents_sub.add_parser("heartbeat", help="Gửi nhịp sống của một Muse")
    p_ag_hb.add_argument("agent_id", type=int)
    p_ag_hb.add_argument("--command", default="", help="Id lệnh đang giữ (rỗng = không giữ lệnh)")
    p_ag_token = agents_sub.add_parser("token", help="Cấp lại token riêng cho một Muse")
    p_ag_token.add_argument("agent_id", type=int)
    p_ag_revoke = agents_sub.add_parser("revoke", help="Thu hồi (hoặc mở lại) quyền của một Muse")
    p_ag_revoke.add_argument("agent_id", type=int)
    p_ag_revoke.add_argument("--undo", action="store_true", help="Mở lại thay vì thu hồi")
    p_ag_export = agents_sub.add_parser("export", help="Xuất phiếu kết nối cho mọi tài khoản Muse")
    p_ag_export.add_argument("--out", default="", help="Ghi ra file thay vì in màn hình")

    args = parser.parse_args(argv)
    client = Client(args.base, args.token, agent_id=args.agent_id)

    if args.cmd == "health":
        return _print(client.request("GET", "/api/health"))
    if args.cmd == "profiles":
        return _print(client.request("GET", "/api/profiles"))
    if args.cmd == "open":
        return _print(client.request("POST", f"/api/profiles/{args.slug}/open", body=b""))
    if args.cmd == "scan":
        return _print(client.request("POST", f"/api/profiles/{args.slug}/scan", body=b""))
    if args.cmd == "channels":
        return _print(client.request("GET", f"/api/profiles/{args.slug}/channels"))
    if args.cmd == "journal":
        return _print(client.request("GET", f"/api/journal?limit={args.limit}"))
    if args.cmd == "send-file":
        file_path = Path(args.path)
        data = file_path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        return _print(client.request(
            "POST", "/api/inbox", body=data,
            extra_headers={"X-File-Name": file_path.name, "X-File-Sha256": digest},
        ))
    if args.cmd == "send-large":
        return _print(send_large(client, Path(args.path), args.command_id, args.chunk_mb))
    if args.cmd == "fetch-url":
        body = json.dumps({"url": args.url, "name": args.name, "command_id": args.command_id}).encode("utf-8")
        return _print(client.request("POST", "/api/files/fetch", body=body,
                                     extra_headers={"Content-Type": "application/json"}))
    if args.cmd == "file-status":
        return _print(client.request("GET", f"/api/files/{args.kind}/{args.file_id}"))
    if args.cmd == "rules":
        return _print(client.request("GET", "/api/rules"))
    if args.cmd == "command":
        payload: dict = {}
        if args.payload:
            payload = json.loads(args.payload)
        if args.url:
            payload["url"] = args.url
        body = json.dumps(
            {"type": args.type, "profile": args.profile, "payload": payload}
        ).encode("utf-8")
        return _print(client.request(
            "POST", "/api/commands", body=body,
            extra_headers={"Content-Type": "application/json"},
        ))
    if args.cmd == "status":
        return _print(client.request("GET", f"/api/commands/{args.command_id}"))
    if args.cmd == "add-profile":
        body = json.dumps(
            {"label": args.label, "gmail": args.gmail, "note": args.note}
        ).encode("utf-8")
        return _print(client.request(
            "POST", "/api/profiles", body=body,
            extra_headers={"Content-Type": "application/json"},
        ))
    if args.cmd == "progress":
        body = json.dumps(
            {"progress": args.percent, "step": " ".join(args.step)}
        ).encode("utf-8")
        return _print(client.request(
            "POST", f"/api/commands/{args.command_id}/progress", body=body,
            extra_headers={"Content-Type": "application/json"},
        ))
    if args.cmd == "result":
        payload: dict = {"status": args.status}
        if args.message:
            if args.status == "needs_user":
                payload["message"] = args.message
            else:
                payload["result" if args.status != "failed" else "error"] = args.message
        body = json.dumps(payload).encode("utf-8")
        return _print(client.request(
            "POST", f"/api/commands/{args.command_id}/result", body=body,
            extra_headers={"Content-Type": "application/json"},
        ))
    if args.cmd == "claim":
        return _print(client.request(
            "POST", f"/api/commands/{args.command_id}/claim", body=b""
        ))
    if args.cmd == "release":
        return _print(client.request(
            "POST", f"/api/commands/{args.command_id}/release", body=b""
        ))
    if args.cmd == "commands":
        query = []
        if args.status:
            query.append(f"status={args.status}")
        if args.wait:
            query.append(f"wait={max(0, min(args.wait, 50))}")
        suffix = ("?" + "&".join(query)) if query else ""
        return _print(client.request("GET", f"/api/commands{suffix}"))
    if args.cmd == "cookies":
        if args.action == "status":
            return _print(client.request("GET", f"/api/profiles/{args.slug}/cookies"))
        if args.action == "import":
            if not args.file:
                return _print({"ok": False, "error": "import cần --file <đường dẫn file cookies>"})
            file_path = Path(args.file)
            return _print(client.request(
                "POST", f"/api/profiles/{args.slug}/cookies",
                body=file_path.read_bytes(),
                extra_headers={"X-File-Name": file_path.name},
            ))
        return _print(client.request(
            "POST", f"/api/profiles/{args.slug}/cookies/{args.action}", body=b""
        ))
    if args.cmd == "agents":
        return _run_agents(client, args)
    return 2


def _parse_agents_file(path: Path) -> list[dict]:
    """Đọc file danh sách tài khoản Muse: JSON (list object) hoặc text
    mỗi dòng 'Tên | email' / 'tên,email' / chỉ 'email'. Dòng trống và
    dòng bắt đầu bằng # được bỏ qua."""
    raw = path.read_text(encoding="utf-8-sig").strip()
    if raw.startswith("["):
        data = json.loads(raw)
        return [
            {"name": str(item.get("name") or ""), "email": str(item.get("email") or "")}
            for item in data
            if isinstance(item, dict)
        ]
    entries = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "|" in line:
            name, email = line.split("|", 1)
        elif "," in line:
            name, email = line.split(",", 1)
        else:
            name, email = "", line
        entries.append({"name": name.strip(), "email": email.strip()})
    return entries


def _run_agents(client: Client, args) -> int:
    json_headers = {"Content-Type": "application/json"}
    if args.agents_cmd == "list":
        return _print(client.request("GET", "/api/agents"))
    if args.agents_cmd == "add":
        body = json.dumps(
            {"name": args.name, "email": args.email, "note": args.note}
        ).encode("utf-8")
        return _print(client.request("POST", "/api/agents", body=body, extra_headers=json_headers))
    if args.agents_cmd == "import":
        entries = _parse_agents_file(Path(args.file))
        if not entries:
            return _print({"ok": False, "error": "File không có mục hợp lệ nào"})
        body = json.dumps({"agents": entries}).encode("utf-8")
        return _print(client.request("POST", "/api/agents/bulk", body=body, extra_headers=json_headers))
    if args.agents_cmd == "assign":
        profile_ids = [int(x) for x in args.profiles.split(",") if x.strip()]
        body = json.dumps({"profile_ids": profile_ids}).encode("utf-8")
        return _print(client.request(
            "POST", f"/api/agents/{args.agent_id}/assignments",
            body=body, extra_headers=json_headers,
        ))
    if args.agents_cmd == "heartbeat":
        body = json.dumps({"current_command_id": args.command}).encode("utf-8")
        return _print(client.request(
            "POST", f"/api/agents/{args.agent_id}/heartbeat",
            body=body, extra_headers=json_headers,
        ))
    if args.agents_cmd == "token":
        return _print(client.request("POST", f"/api/agents/{args.agent_id}/regenerate-token", body=b""))
    if args.agents_cmd == "revoke":
        body = json.dumps({"revoked": not args.undo}).encode("utf-8")
        return _print(client.request(
            "POST", f"/api/agents/{args.agent_id}/revoke",
            body=body, extra_headers=json_headers,
        ))
    if args.agents_cmd == "export":
        payload = client.request("GET", "/api/agents")
        if not payload.get("ok"):
            return _print(payload)
        lines = [
            "PHIẾU KẾT NỐI TÀI KHOẢN MUSE — Channel Control Desktop",
            f"Cầu nối: {client.base}",
            "(Mỗi Muse gọi API kèm header X-Agent-Id + X-Agent-Token = token riêng dưới đây.)",
            "",
        ]
        for agent in payload.get("agents", []):
            lines.append(f"## {agent['name']} (#{agent['id']}) — {agent['email']}")
            lines.append(f"X-Agent-Id: {agent['id']}")
            lines.append(f"X-Agent-Token: {agent.get('token', '')}")
            lines.append(f"Hồ sơ phụ trách (id): {agent.get('profile_ids', [])}")
            lines.append("")
        text = "\n".join(lines)
        if args.out:
            Path(args.out).write_text(text, encoding="utf-8")
            return _print({"ok": True, "written": args.out, "agents": len(payload.get("agents", []))})
        print(text)
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
